﻿Public Class DataReader
    Inherits DataHandlerBase
    Implements IDataReader

    Private _退避データ種別 As Integer
    Private _退避データ種類 As Integer
    Private _退避データ種類略称 As String
    Private _退避明細区分 As Integer
    Private _存在チェック As Boolean

#Region "インターフェイスメソッド"

    ''' <summary>
    ''' データを取得する
    ''' </summary>
    ''' <param name="settingInfo">システム共通設定情報</param>
    ''' <param name="readParamInfo">読込パラメータ</param>
    ''' <param name="exDA">例外情報</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetData(ByVal settingInfo As System.Collections.IDictionary, _
                            ByRef readParamInfo As IDictionary(Of IReadParam.取得区分型, IReadParam), _
                            ByRef exDA As System.Exception) As IDictionary(Of IReadParam.取得区分型, DataTable) Implements IDataReader.GetData
        Return GetDataTable(readParamInfo, exDA)
    End Function

#End Region

#Region "内部メソッド"
    Private Function GetDataTable(ByRef readParamInfo As IDictionary(Of IReadParam.取得区分型, IReadParam), ByRef exDA As Exception) As IDictionary(Of IReadParam.取得区分型, DataTable)
        Try
            Initialize(SettingInfo)

            SetUpDAC()

            Dim result As IDictionary(Of IReadParam.取得区分型, DataTable) = New Dictionary(Of IReadParam.取得区分型, DataTable)
            Using connection As DbConnection = OpenConnection()

                If readParamInfo.ContainsKey(IReadParam.取得区分型.属性情報テーブル取得) = True Then
                    result.Add(IReadParam.取得区分型.属性情報テーブル取得, GetData_拡張項目属性情報テーブル(connection, readParamInfo(IReadParam.取得区分型.属性情報テーブル取得)))
                End If

                If readParamInfo.ContainsKey(IReadParam.取得区分型.属性情報表示用データ取得) = True Then
                    result.Add(IReadParam.取得区分型.属性情報表示用データ取得, GetData_属性情報表示用(connection, readParamInfo(IReadParam.取得区分型.属性情報表示用データ取得)))
                End If
                'A-20101213_2}
                CloseConnection(connection)
            End Using

            Return result
        Catch ex As Exception
            exDA = ex
        End Try

        Return Nothing
    End Function

    ''次データ・前データで使用するデータ種類を管理オプションに合わせて生成する
    'Private Function MakeSQLKubunSelect(ByVal readParam As IReadParam) As String
    '    Dim SQL As String = ""
    '    Dim getMasterKubunList As New List(Of String)
    '    Dim masterKubunList As String
    '    getMasterKubunList.Add("1")
    '    getMasterKubunList.Add("2")
    '    getMasterKubunList.Add("3")
    '    getMasterKubunList.Add("4")
    '    getMasterKubunList.Add("5")

    '    If CType(readParam, IReadParam).部門管理 = オプション区分定義型.区分型.行う Then
    '        getMasterKubunList.Add("6")
    '    End If
    '    If CType(readParam, IReadParam).売上処理_お届け先 = 売上処理定義型.お届け先使用区分型.使用する Then
    '        getMasterKubunList.Add("7")
    '    End If
    '    If CType(readParam, IReadParam).倉庫別在庫管理 = 機能区分定義型.倉庫別在庫管理型.行う Then
    '        getMasterKubunList.Add("8")
    '    End If
    '    If CType(readParam, IReadParam).営業所管理 = 機能区分定義型.営業所管理区分型.行う Then
    '        getMasterKubunList.Add("9")
    '    End If
    '    getMasterKubunList.Add("10")
    '    getMasterKubunList.Add("11")

    '    If CType(readParam, IReadParam).強化区分 >= 3 AndAlso _
    '       CType(readParam, IReadParam).原価管理 = オプション区分定義型.区分型.行う Then                    'A-20080709_2
    '        getMasterKubunList.Add("12")                                                                    'A-20080709_2
    '    End If                                                                                              'A-20080709_2

    '    If CType(readParam, IReadParam).強化区分 >= 4 AndAlso _
    '       CType(readParam, IReadParam).ロット管理 = オプション区分定義型.区分型.行う Then                  'A-20091125_1
    '        getMasterKubunList.Add("13")                                                                    'A-20091125_1
    '    End If                                                                                              'A-20091125_1

    '    masterKubunList = Join(getMasterKubunList.ToArray, ", ")

    '    SQL &= "  AND HANZ030002 IN(" & masterKubunList & ")"

    '    Return SQL
    'End Function


    '次データ・前データで使用するデータ種類を管理オプションに合わせて生成する
    Private Function MakeSQLKanriSelect_2(ByVal param As IReadParam,
                                          ByRef parameters As OSK.X1.DataAccess.ParamInfoList) As String    'A-20080709_2    'X1変換Tool-20160427
        Dim SQL As String = ""

        SQL &= " ( CUSZE01001 = " & SetParameter(parameters, "CUSZE01001", DbType.Decimal, 0, 2, 0, param.データ種類) & " ) "

        SQL = "  WHERE (" & SQL & ")"

        Return SQL
    End Function

    Private Function GetData_拡張項目属性情報テーブル(ByVal connection As DbConnection, ByVal readParam As IReadParam) As DataTable

        Dim SQL As String = ""
        Dim parameters As ParamInfoList = New ParamInfoList
        SQL = MakeSQLSelect_ZE01(readParam, parameters)

        Dim table As DataTable = DataAccess.GetDataTable(connection, SQL, parameters)

        Return table
    End Function

    Private Function GetData_属性情報表示用(ByVal connection As DbConnection, ByVal readParam As IReadParam) As DataTable

        'Dim SQL As String = ""
        'Dim hasRow As Boolean = False
        'Dim parameters As ParamInfoList = New ParamInfoList
        'Dim lastParameter As ParamInfoList = New ParamInfoList
        'Dim isGetData As Boolean
        'Dim dataReader As DbDataReader = Nothing
        'Dim command As DbCommand = Nothing
        'Dim getTable As DataTable = Nothing

        '_存在チェック = False

        'If CType(readParam, ReadParam).データ取得型 <> 0 Then  ' "データ取得型 → 0:通常読込　1:次データ　2:前データ"

        'Dim firstSQL As String = ""
        'Dim firstParameter As ParamInfoList = New ParamInfoList
        'Dim chainFieldName() As String = Nothing
        'Dim chainParameter As ParamInfoList = New ParamInfoList
        'Dim lastSQL As String = ""

        'Dim target As IChainFieldDataAccess
        'Dim paramTypeObject(1) As Type
        'Dim paramObject(1) As Object
        'paramTypeObject(0) = GetType(OSK.X1.DataAccess.IDataAccess)    'X1変換Tool-20160427
        'paramObject(0) = DataAccess
        'paramTypeObject(1) = GetType(System.Data.Common.DbConnection)
        'paramObject(1) = connection
        'target = CMN.LIB.PartReplacement.CommonFactory.CreateInstance(Of IChainFieldDataAccess)(Me, GetType(ChainFieldDataAccess), paramTypeObject, paramObject)

        'firstSQL = ""
        'firstSQL &= MakeSQLNextUriageSelect_ZE01(readParam, parameters)
        'firstSQL &= MakeSQLKubunSelect(parameters, connection)
        ''firstSQL &= "WHERE HANZ030001 < 5"

        ''firstSQL &= " AND ((HANZ030001 = 0 " & MakeSQLKubunSelect(readParam) & ")"
        ''firstSQL &= " OR (HANZ030001 = 1 " & MakeSQLKanriMultiSelect(readParam) & "))"

        'Dim newParameter As New ParamInfo

        'ReDim chainFieldName(1)
        'chainFieldName(0) = "CUSZE01001"
        'chainFieldName(1) = "CUSZE01002"

        'If readParam.データ種別 = 0 Then
        '    SetParameter(chainParameter, "CUSZE01001", DbType.Decimal, 0, 2, 0, readParam.データ種類)
        '    SetParameter(chainParameter, "CUSZE01002", DbType.Decimal, 0, 1, 0, readParam.明細区分)
        'Else
        '    SetParameter(chainParameter, "CUSZE01001", DbType.Decimal, 0, 2, 0, readParam.データ種類)
        '    SetParameter(chainParameter, "CUSZE01002", DbType.Decimal, 0, 1, 0, readParam.明細区分)
        'End If

        '' 1:次データ 2:前データ に合わせてデータを取得する。
        'If CType(readParam, ReadParam).データ取得型 = 1 Then
        '    SQL = " ORDER BY CUSZE01001, CUSZE01002"
        '    SQL &= QueryWrapper.AddUR()
        '    lastSQL &= SQL
        '    dataReader = target.GetNextDataReader(firstSQL, firstParameter, chainFieldName, chainParameter, lastSQL, lastParameter, isGetData, command)
        'Else
        '    SQL = " ORDER BY CUSZE01001 DESC, CUSZE01002 DESC"
        '    SQL &= QueryWrapper.AddUR()
        '    lastSQL &= SQL
        '    dataReader = target.GetPreviousDataReader(firstSQL, firstParameter, chainFieldName, chainParameter, lastSQL, lastParameter, isGetData, command)
        'End If

        'If dataReader.HasRows = True Then _存在チェック = True

        'If CType(readParam, ReadParam).データ取得型 <> 0 Then
        '    If _存在チェック = True Then
        '        _退避データ種類 = CInt(dataReader.Item("CUSZE01001").ToString.TrimEnd)
        '        _退避明細区分 = CInt(dataReader.Item("CUSZE01002").ToString.TrimEnd)
        '        _退避データ種類略称 = CStr(dataReader.Item("CUSCE03004").ToString.TrimEnd)
        '    Else
        '        _退避データ種別 = readParam.データ種別
        '        _退避データ種類 = 99                ' ← 絶対存在しないコードを入れる(今回は99)
        '        _退避明細区分 = readParam.明細区分
        '    End If
        '    readParam.データ種別 = _退避データ種別
        '    readParam.データ種類 = _退避データ種類
        '    readParam.明細区分 = _退避明細区分
        '    readParam.存在チェック = _存在チェック
        'End If
        'DataAccess.CancelCommand(command)
        'DataAccess.CloseReader(dataReader)
        'End If

        Dim SQL As String = ""
        Dim parameters As ParamInfoList = New ParamInfoList

        If CType(readParam, ReadParam).データ取得型 <> 0 Then
            readParam.データ種別 = _退避データ種別
            readParam.データ種類 = _退避データ種類
            readParam.データ種類略称 = _退避データ種類略称
            readParam.明細区分 = _退避明細区分
        End If


        Dim xmlTable As DataTable = Nothing
        Dim xmlEx As Exception = Nothing
        Dim getTable As DataTable

        If XmlExtItemReader.TryLoadZokuseiTable(readParam.データ種類略称,
                                               CInt(readParam.明細区分),
                                               xmlTable,
                                               xmlEx) Then
            getTable = xmlTable
            ''xmlから取得した場合、更新番号用のカラムを取得してDataTableへ追加
            SQL = MakeSQLDisplaySelect_ZE01(readParam, parameters)

            Dim getUPDTable As DataTable = DataAccess.GetDataTable(connection, SQL, parameters)
            Dim srcCol As DataColumn = getUPDTable.Columns("CUSZE01999")
            Dim col As New DataColumn
            col.ColumnName = srcCol.ColumnName
            col.DataType = srcCol.DataType
            getTable.Columns.Add(col)
            For q As Integer = 0 To getUPDTable.Rows.Count - 1
                getTable.Rows(q).Item("CUSZE01999") = getUPDTable.Rows(q).Item("CUSZE01999")
            Next
        Else
            SQL = MakeSQLDisplaySelect_ZE01(readParam, parameters)

            getTable = DataAccess.GetDataTable(connection, SQL, parameters)
        End If
        Dim newEntry As DataTable = getTable.Clone

        For i As Integer = 0 To 29
            newEntry.Rows.Add(0, 0, 0, 0, "", 0)
        Next

        For i As Integer = 0 To newEntry.Columns.Count - 1
            newEntry.Columns(i).ReadOnly = False
            newEntry.Columns(i).AllowDBNull = True
        Next

        For i As Integer = 0 To 29
            newEntry.Rows(i)("CUSZE01005") = DBNull.Value
            newEntry.Rows(i)("CUSZE01006") = DBNull.Value
            'newEntry.Rows(i)("CUSZE01010") = -1
        Next

        If getTable.Rows.Count > 0 Then
            For i As Integer = 0 To 29
                For j As Integer = 0 To getTable.Rows.Count - 1
                    If i + 1 = CInt(getTable.Rows(j).Item("CUSZE01003").ToString) Then
                        SetRowDataUpd(i, j, readParam, newEntry, getTable)
                    End If
                Next
            Next
        End If


        Return newEntry
    End Function


    ''' <summary>
    ''' SetRowDataUpd() 一行のデータリーダーをデータテーブルへセット（上書き）
    ''' </summary>
    ''' <param name="i">現在対象となっているnewEntryの行番号</param>
    ''' <param name="j">上書きする為の行番号</param>
    ''' <param name="newEntry">取得データリーダー</param>
    ''' <param name="getTable">SQLを実行して取得したデータテーブル</param>
    ''' <remarks></remarks>
    Private Sub SetRowDataUpd(ByVal i As Integer, ByVal j As Integer, ByVal readParam As IReadParam, ByVal newEntry As DataTable, ByRef getTable As DataTable)

        newEntry.Rows(i)("CUSZE01003") = getTable.Rows(j)("CUSZE01003").ToString.TrimEnd
        newEntry.Rows(i)("CUSZE01004") = getTable.Rows(j)("CUSZE01004").ToString.TrimEnd

        If getTable.Rows(j)("CUSZE01004").ToString = "7" Then
            newEntry.Rows(i)("CUSZE01005") = getTable.Rows(j)("CUSZE01005").ToString.TrimEnd
            'newEntry.Rows(i)("CUSZE01008") = getTable.Rows(j)("HANZ032004").ToString.TrimEnd
            newEntry.Rows(i)("CUSZE01007") = getTable.Rows(j)("CUSZE01007").ToString.TrimEnd
        ElseIf getTable.Rows(j)("CUSZE01004").ToString = "4" OrElse getTable.Rows(j)("CUSZE01004").ToString = "5" OrElse
               getTable.Rows(j)("CUSZE01004").ToString = "6" Then
            newEntry.Rows(i)("CUSZE01005") = getTable.Rows(j)("CUSZE01005").ToString.TrimEnd
            newEntry.Rows(i)("CUSZE01007") = getTable.Rows(j)("CUSZE01007").ToString.TrimEnd
        Else
            'newEntry.Rows(i)("CUSZE01005") = ""

            If Not IsDBNull(getTable.Rows(j)("CUSZE01005")) Then
                newEntry.Rows(i)("CUSZE01005") = getTable.Rows(j)("CUSZE01005")
            End If
            If Val(getTable.Rows(j)("CUSZE01004")) = 0 Then
                newEntry.Rows(i)("CUSZE01007") = DBNull.Value
            Else
                newEntry.Rows(i)("CUSZE01007") = getTable.Rows(j)("CUSZE01007").ToString.TrimEnd
            End If

        End If

        If getTable.Rows(j)("CUSZE01004").ToString = "3" Then

            If Not IsDBNull(getTable.Rows(j)("CUSZE01006")) Then
                newEntry.Rows(i)("CUSZE01006") = getTable.Rows(j)("CUSZE01006")
            End If

        Else
            If Val(getTable.Rows(j)("CUSZE01006").ToString) <> 0 Then
                newEntry.Rows(i)("CUSZE01006") = getTable.Rows(j)("CUSZE01006").ToString.TrimEnd
            End If

        End If
        If Not IsDBNull(getTable.Rows(j)("CUSZE01999")) Then
            newEntry.Rows(i)("CUSZE01999") = getTable.Rows(j)("CUSZE01999").ToString.TrimEnd
        Else
            newEntry.Rows(i)("CUSZE01999") = 0
        End If
    End Sub


#End Region

#Region "MakeSQL"


    Private Function MakeSQLSelect_ZE01(ByVal param As IReadParam,
                                        ByRef parameters As OSK.X1.DataAccess.ParamInfoList) As String
        Dim SQL As String

        SQL = ""
        SQL &= "SELECT "

        SQL &= "CUSZE01003, "
        SQL &= "CUSZE01004, "

        SQL &= "CUSZE01005, "
        SQL &= "CUSZE01006, "

        SQL &= QueryWrapper.AddIsNull() & "(CUSZE01007,' ') ""CUSZE01007"","
        SQL &= "CUSZE01999 "

        SQL &= "FROM " & Me.ExchangeTableName("CUS98ZE01ZOKUSEI") & " " & QueryWrapper.AddNoLock


        SQL &= "  WHERE CUSZE01001 = " & SetParameter(parameters, "CUSZE01001", DbType.Decimal, 0, 2, 0, param.データ種類)
        SQL &= "  AND CUSZE01002 = " & SetParameter(parameters, "CUSZE01002", DbType.Decimal, 0, 1, 0, param.明細区分)
        SQL &= QueryWrapper.AddUR()

        Return SQL
    End Function

    Private Function MakeSQLDisplaySelect_ZE01(ByVal param As IReadParam, ByRef parameters As OSK.X1.DataAccess.ParamInfoList) As String
        Dim SQL As String

        SQL = ""
        SQL &= "SELECT "

        SQL &= "CUSZE01003, "
        SQL &= "CUSZE01004, "

        SQL &= "CUSZE01005, "
        SQL &= "CUSZE01006, "
        SQL &= QueryWrapper.AddIsNull() & "(CUSZE01007,' ') ""CUSZE01007"","
        SQL &= "CUSZE01999 "
        SQL &= "FROM " & Me.ExchangeTableName("CUS98ZE01ZOKUSEI") & " " & QueryWrapper.AddNoLock

        SQL &= MakeSQLKanriSelect_2(param, parameters)
        SQL &= "  AND CUSZE01002 = " & SetParameter(parameters, "CUSZE01002_3", DbType.Decimal, 0, 1, 0, param.明細区分)
        SQL &= "ORDER BY CUSZE01003, CUSZE01001"

        SQL &= QueryWrapper.AddUR()

        Return SQL
    End Function

    Private Function MakeSQLNextUriageSelect_ZE01(ByVal param As IReadParam, ByRef parameters As OSK.X1.DataAccess.ParamInfoList) As String    'X1変換Tool-20160427
        Dim SQL As String

        SQL = ""
        SQL &= " SELECT "
        SQL &= " CUSZE01001, CUSZE01002,CUSCE03004 "
        SQL &= " FROM " & Me.ExchangeTableName("CUS98ZE01ZOKUSEI") & " " & QueryWrapper.AddNoLock    'X1変換Tool-20160427
        SQL &= " INNER JOIN " & Me.ExchangeTableName("CUS98CE03KUBUN ") & " " & QueryWrapper.AddNoLock
        SQL &= " ON CUSZE01001 =CUSCE03002"

        Return SQL
    End Function

    ''次データ・前データで使用するデータ種類を管理オプションに合わせて生成する
    'Private Function MakeSQLKubunSelect(ByVal parameters As ParamInfoList, ByVal connection As DbConnection) As String
    '    Dim SQL As String = ""
    '    Dim getMasterKubunList As New List(Of String)
    '    Dim masterKubunList As String
    '    Dim SQL_CE03 As String = ""
    '    Dim dt As New DataTable

    '    SQL_CE03 &= " SELECT COUNT(*) KUBUN_CNT FROM "
    '    SQL_CE03 &= Me.ExchangeTableName("CUS98CE03KUBUN")
    '    SQL_CE03 &= " INNER JOIN " & Me.ExchangeTableName("CUS98CE02KUBUNSHUBETSU") & " " & Me.QueryWrapper.AddNoLock
    '    SQL_CE03 &= " ON CUSCE03001 = CUSCE02001 "
    '    SQL_CE03 &= " WHERE CUSCE03001  = '0701' "
    '    SQL_CE03 &= QueryWrapper.AddUR()

    '    dt = DataAccess.GetDataTable(connection, SQL_CE03, parameters)

    '    If CType(dt.Rows(0).Item("KUBUN_CNT"), Integer) > 0 Then
    '        For i As Integer = 1 To CType(dt.Rows(0).Item("KUBUN_CNT"), Integer)
    '            getMasterKubunList.Add(i.ToString("D2"))
    '        Next

    '    End If


    '    masterKubunList = Join(getMasterKubunList.ToArray, ", ")

    '    SQL &= "  WHERE CUSZE01001 IN(" & masterKubunList & ")"

    '    Return SQL
    'End Function

#Region "パラメータ"
    ''' <summary>
    ''' ﾊﾟﾗﾒｰﾀｾｯﾄ
    ''' </summary>
    ''' <param name="parameters">ﾊﾟﾗﾒｰﾀ格納用</param>
    ''' <param name="name">名称</param>
    ''' <param name="type">ﾀｲﾌﾟ</param>
    ''' <param name="size">桁数(Decimal型以外)</param>
    ''' <param name="precision">桁数(Decimal型)</param>
    ''' <param name="scale">小数点以下桁数(Decimal型)</param>
    ''' <param name="value">値</param>
    ''' <param name="カンマを付ける">True:付ける,False:Space</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function SetParameter(ByRef parameters As ParamInfoList, _
                                  ByVal name As String, _
                                  ByVal type As DbType, _
                                  ByVal size As Integer, _
                                  ByVal precision As Byte, _
                                  ByVal scale As Byte, _
                                  ByVal value As Object, _
                                  Optional ByVal カンマを付ける As Boolean = False _
                                  ) As String

        If parameters Is Nothing Then
            parameters = New ParamInfoList
        End If

        Dim param As New ParamInfo
        With param
            .Name = name
            .Type = type
            .Size = size
            .Precision = precision
            .Scale = scale
            .Value = value
        End With
        parameters.Add(param)

        Return "?" & IIf(カンマを付ける = True, ", ", " ").ToString
    End Function
#End Region

#End Region

End Class
