﻿''' <summary>
''' 読込パラメータ
''' </summary>
''' <remarks></remarks>
<CLSCompliant(True)> _
Public Interface IReadParam

#Region "列挙型"
    Enum 取得区分型
        属性情報テーブル取得 = 0
        属性情報表示用データ取得
        付箋売上表示用データ取得
        付箋受注表示用データ取得
        付箋見積表示用データ取得
        付箋経費表示用データ取得                                                        'A-20080709_2
        付箋入出荷表示用データ取得            'A-20101213_2
    End Enum

#End Region

#Region "プロパティ"

    ''' <summary>
    ''' データ種類
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property 処理モード() As Integer

    ''' <summary>
    ''' データ種類
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property データ種類() As Integer

    Property データ種類略称() As String

    ''' <summary>
    ''' 請求グループコード
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property データ種別() As Integer

    ''' <summary>
    '''明細区分
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property 明細区分() As Integer

    ''' <summary>
    ''' データ取得型
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks>0:通常 1:次データ 2:前データ</remarks>
    Property データ取得型() As Integer

    ''' <summary>
    '''取得区分
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property 取得区分() As 取得区分型

    ''' <summary>
    '''存在チェック
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property 存在チェック() As Boolean

#End Region

#Region "管理オプション"

    ''' <summary>
    '''強化区分
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property 強化区分() As Decimal                                                      'A-20080709_2 & A-20080709_3 & A-20080709_4

    '''' <summary>
    ''''見積管理
    '''' </summary>
    '''' <value></value>
    '''' <returns></returns>
    '''' <remarks></remarks>
    'Property 見積管理() As オプション区分定義型.区分型

    '''' <summary>
    ''''受発注管理
    '''' </summary>
    '''' <value></value>
    '''' <returns></returns>
    '''' <remarks></remarks>
    'Property 受発注管理() As オプション区分定義型.区分型

    '''' <summary>
    ''''原価管理
    '''' </summary>
    '''' <value></value>
    '''' <returns></returns>
    '''' <remarks></remarks>
    'Property 原価管理() As オプション区分定義型.区分型                                  'A-20080709_2

    '''' <summary>
    ''''ロット管理
    '''' </summary>
    '''' <value></value>
    '''' <returns></returns>
    '''' <remarks></remarks>
    'Property ロット管理() As オプション区分定義型.区分型                                'A-20091125_1

    '''' <summary>
    ''''拡張項目データリンク機能
    '''' </summary>
    '''' <value></value>
    '''' <returns></returns>
    '''' <remarks></remarks>
    'Property 拡張項目データリンク機能() As 機能区分定義型.拡張項目データリンク機能型    'A-20080709_3

    '''' <summary>
    ''''定期取引作成機能
    '''' </summary>
    '''' <value></value>
    '''' <returns></returns>
    '''' <remarks></remarks>
    'Property 定期取引作成機能() As 機能区分定義型.定期取引作成機能型                    'A-20080709_4

    ''A-20101213_2{
    '''' <summary>
    ''''Is検収基準_出荷
    '''' </summary>
    '''' <value></value>
    '''' <returns></returns>
    '''' <remarks></remarks>
    Property Is検収基準_出荷() As Boolean

    ''' <summary>
    '''Is検収基準_入荷
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property Is検収基準_入荷() As Boolean

    ''' <summary>
    '''Is検収基準
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property Is検収基準() As Boolean
    'A-20101213_2}

    'A-20121120_1{
    ''' <summary>
    '''Is予定在庫区分_入出庫
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property Is予定在庫区分_入出庫() As Boolean
    'A-20121120_1}

#End Region

#Region "コントロール情報"

    '''' <summary>
    ''''部門管理
    '''' </summary>
    '''' <value></value>
    '''' <returns></returns>
    '''' <remarks></remarks>
    'Property 部門管理() As オプション区分定義型.区分型

    '''' <summary>
    ''''売上処理_お届け先
    '''' </summary>
    '''' <value></value>
    '''' <returns></returns>
    '''' <remarks></remarks>
    'Property 売上処理_お届け先() As 売上処理定義型.お届け先使用区分型

    '''' <summary>
    ''''倉庫別在庫管理
    '''' </summary>
    '''' <value></value>
    '''' <returns></returns>
    '''' <remarks></remarks>
    'Property 倉庫別在庫管理() As 機能区分定義型.倉庫別在庫管理型

    '''' <summary>
    ''''営業所管理
    '''' </summary>
    '''' <value></value>
    '''' <returns></returns>
    '''' <remarks></remarks>
    'Property 営業所管理() As 機能区分定義型.営業所管理区分型

#End Region

End Interface
