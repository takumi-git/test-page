﻿''' <summary>
''' 読込パラメータ
''' </summary>
''' <remarks></remarks>
<Serializable()> _
Public Class ReadParam
    Implements IReadParam

#Region "プロパティ"

    Private _処理モード As Integer
    Public Property 処理モード() As Integer Implements IReadParam.処理モード
        Get
            Return _処理モード
        End Get
        Set(ByVal value As Integer)
            _処理モード = value
        End Set
    End Property

    Private _データ種別 As Integer
    Public Property データ種別() As Integer Implements IReadParam.データ種別
        Get
            Return _データ種別
        End Get
        Set(ByVal value As Integer)
            _データ種別 = value
        End Set
    End Property

    Private _データ種類 As Integer
    Public Property データ種類() As Integer Implements IReadParam.データ種類
        Get
            Return _データ種類
        End Get
        Set(ByVal value As Integer)
            _データ種類 = value
        End Set
    End Property

    Private _データ種類略称 As String
    Public Property データ種類略称() As String Implements IReadParam.データ種類略称
        Get
            Return _データ種類略称
        End Get
        Set(ByVal value As String)
            _データ種類略称 = value
        End Set
    End Property


    Private _明細区分 As Integer
    Public Property 明細区分() As Integer Implements IReadParam.明細区分
        Get
            Return _明細区分
        End Get
        Set(ByVal value As Integer)
            _明細区分 = value
        End Set
    End Property

    Private _データ取得型 As Integer
    Public Property データ取得型() As Integer Implements IReadParam.データ取得型
        Get
            Return _データ取得型
        End Get
        Set(ByVal value As Integer)
            _データ取得型 = value
        End Set
    End Property

    Private _取得区分 As IReadParam.取得区分型
    Public Property 取得区分() As IReadParam.取得区分型 Implements IReadParam.取得区分
        Get
            Return _取得区分
        End Get
        Set(ByVal value As IReadParam.取得区分型)
            _取得区分 = value
        End Set
    End Property

    Private _存在チェック As Boolean
    Public Property 存在チェック() As Boolean Implements IReadParam.存在チェック
        Get
            Return _存在チェック
        End Get
        Set(ByVal value As Boolean)
            _存在チェック = value
        End Set
    End Property

#End Region

#Region "コントロール情報"

#Region "取引系"

    Private _強化区分 As Decimal                                                                    'A-20080709_2 & A-20080709_3 & A-20080709_4
    Public Property 強化区分() As Decimal Implements IReadParam.強化区分                            'A-20080709_2 & A-20080709_3 & A-20080709_4 
        Get
            Return _強化区分
        End Get
        Set(ByVal value As Decimal)
            _強化区分 = value
        End Set
    End Property

    'A-20101213_2{
    Private _Is検収基準 As Boolean
    Public Property Is検収基準() As Boolean Implements IReadParam.Is検収基準
        Get
            Return _Is検収基準
        End Get
        Set(ByVal value As Boolean)
            _Is検収基準 = value
        End Set
    End Property

    Private _Is検収基準_出荷 As Boolean
    Public Property Is検収基準_出荷() As Boolean Implements IReadParam.Is検収基準_出荷
        Get
            Return _Is検収基準_出荷
        End Get
        Set(ByVal value As Boolean)
            _Is検収基準_出荷 = value
        End Set
    End Property

    Private _Is検収基準_入荷 As Boolean
    Public Property Is検収基準_入荷() As Boolean Implements IReadParam.Is検収基準_入荷
        Get
            Return _Is検収基準_入荷
        End Get
        Set(ByVal value As Boolean)
            _Is検収基準_入荷 = value
        End Set
    End Property
    'A-20101213_2}

    'A-20121120_1{
    Private _Is予定在庫区分_入出庫 As Boolean
    Public Property Is予定在庫区分_入出庫() As Boolean Implements IReadParam.Is予定在庫区分_入出庫
        Get
            Return _Is予定在庫区分_入出庫
        End Get
        Set(ByVal value As Boolean)
            _Is予定在庫区分_入出庫 = value
        End Set
    End Property
    'A-20121120_1}

#End Region

#Region "マスター系"

    'Private _部門管理 As オプション区分定義型.区分型
    'Public Property 部門管理() As オプション区分定義型.区分型 Implements IReadParam.部門管理
    '    Get
    '        Return _部門管理
    '    End Get
    '    Set(ByVal value As オプション区分定義型.区分型)
    '        _部門管理 = value
    '    End Set
    'End Property

    'Private _売上処理_お届け先 As 売上処理定義型.お届け先使用区分型
    'Public Property 売上処理_お届け先() As 売上処理定義型.お届け先使用区分型 Implements IReadParam.売上処理_お届け先
    '    Get
    '        Return _売上処理_お届け先
    '    End Get
    '    Set(ByVal value As 売上処理定義型.お届け先使用区分型)
    '        _売上処理_お届け先 = value
    '    End Set
    'End Property

    'Private _倉庫別在庫管理 As 機能区分定義型.倉庫別在庫管理型
    'Public Property 倉庫別在庫管理() As 機能区分定義型.倉庫別在庫管理型 Implements IReadParam.倉庫別在庫管理
    '    Get
    '        Return _倉庫別在庫管理
    '    End Get
    '    Set(ByVal value As 機能区分定義型.倉庫別在庫管理型)
    '        _倉庫別在庫管理 = value
    '    End Set
    'End Property

    'Private _営業所管理 As 機能区分定義型.営業所管理区分型
    'Public Property 営業所管理() As 機能区分定義型.営業所管理区分型 Implements IReadParam.営業所管理
    '    Get
    '        Return _営業所管理
    '    End Get
    '    Set(ByVal value As 機能区分定義型.営業所管理区分型)
    '        _営業所管理 = value
    '    End Set
    'End Property

    'Private _ロット管理 As オプション区分定義型.区分型                                                                                          'A-20091125_1
    'Public Property ロット管理() As オプション区分定義型.区分型 Implements IReadParam.ロット管理                                                'A-20091125_1
    '    Get
    '        Return _ロット管理
    '    End Get
    '    Set(ByVal value As オプション区分定義型.区分型)
    '        _ロット管理 = value
    '    End Set
    'End Property
#End Region

#End Region

End Class
