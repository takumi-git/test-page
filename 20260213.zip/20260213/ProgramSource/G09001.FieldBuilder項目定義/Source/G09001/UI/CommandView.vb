﻿Public Class CommandView
    Inherits CommandViewBase

#Region "列挙型"
    Enum 処理区分
        登録 = 0
        修正
        削除
    End Enum

    Public Enum キー属性型
        数値 = 0
        文字
    End Enum

    Friend Enum GridItem As Integer
        属性 = 0

        桁数
        小数
        項目名称
    End Enum

    Enum キーセル移動方向型
        同
        右
        左
        上
        下
        前行最終項目
    End Enum

#End Region

#Region "定数定義"
    '<<個別プログラム固有情報>>
    Const _limitMaxRowCount As Integer = 30                 '最大表示可能行数(30)
    Private _強制実行フラグ As Integer = 0
    Private _初期属性データ As DataTable                    '整合性の必要有無チェック用の退避テーブル
    Private _初期使用区分(4) As CheckState                  '0:区分売上 1:区分受注 2:区分見積 3:区分経費 4:区分入出荷                       'A-20101213_2
    Private _実行ID枝番 As Integer = 0                      '更新時ログを出力する際に使用する枝番
    Private _executeDoClearFlg As Boolean = False           'F5:クリアを実行して移動しようとしているかどうかの状態フラグ
    Private _executeAfter As Boolean = False                '更新後のクリア処理かを判断するためのフラグ
    Private _statusClearFlag As Boolean = False             'チェック前処理でステータスバーのクリア処理を行うはどうかの状態フラグ
    Private 取得属性データ As DataTable = Nothing
    '前回値セット用の退避テーブル
    Private _前回属性データ As DataTable
    Private _前回使用区分(5) As CheckState                        '0:区分売上 1:区分受注 2:区分見積 3:個別設定 4:消費税明細  5:区分入出荷   'A-20101213_2 
    Private _属性変更フラグ As Integer = 0
    Private _定義処理更新回数 As Integer         '
    'データ種類の区分検索と存在チェック用
    Private _データ種類_取引 As New List(Of String)
    Private _データ種類_取引名称 As IDictionary = New Hashtable
    Private _データ種類_区分データ As DataTable
    Private _targetTorihiki As IDivisionSelecter
    'データアクセス処理の終了判断用のフラグ
    Private _isEndFlag As Boolean
    Private _completeClickFlag As Boolean = False
    Private _MoveOtherGroup0Flag As Boolean = False
    'データ読込み判定時の最終確定値保存用の変数
    Private _lastDataShurui As String
    Private _lastMeisaiKubun As Integer
    Private _lastShoriMode As Integer
    Private _changeShoriMode As Boolean = False
    Private _oldDataShurui As String
    Private _bufferDataShurui As String
    Private _bufferMeisaiKubun As Integer

    'フォーカス可能先頭カラム
    Private Const _startCol As Integer = 1
    Private _contextMenu As SmartControl.ContextMenu.ContextMenu
    Private _personalMessageViewer As PersonalMessageViewer
    Private _focusSwitcher As IFocusSwitcher
    Private _throwException As Boolean
    Private _checkBoxState As Boolean
    Private _取得区分 As IReadParam.取得区分型

    Private _メニューバー整合処理より実行 As Boolean = False                    'A-20110408_1

#End Region

#Region "変数定義"
    Private _maxRowCount As Integer                         '最大入力行数(実データ)
    Private _prevRowIndex As Integer                        '移動元RowIndex
    Private _prevColIndex As Integer                        '移動元ColIndex
    Private _newRowIndex As Integer                         '移動先RowIndex
    Private _newColIndex As Integer                         '移動先ColIndex
    Private _gridFocusLost As Boolean = False               'グリッドから他コントロールへ移動しようとしているかの状態フラグ
    Private _キー属性 As キー属性型                         'キーコード属性
    '<<グリッド補助クラス>>
    Private _gridHelper As IGridHelper                      'グリッドヘルパー
    Private _gridMoveCellManager As IGridMoveCellManager    '移動補助
    Private _GridGetStateInfo As IGridGetStateInfo          'グリッドの状態判断補助
    Private _columnInfoList As ColumnInfoListBase           'グリッドのプロパティ設定
    '<<コントロール情報型>>
    'Private _myコントロール情報型 As New Myコントロール情報型
    Private _my項目名称型 As New My項目名称型
    '<<<セル位置情報>>>
    Private _targetControl As System.Windows.Forms.Control
    '<<<グリッドプロパティ>>>
    Private _MoveEnterKey As OSK.X1.Foundation.Controls.Grid.Edit.MoveDirectionOnEnter    'X1変換Tool-20160427
    Private _MoveArrowMode As Boolean

    Private _myコントロール情報型_基準 As New Myコントロール情報型_基準
    'Private _rendoHelper As IRendoHelper
#End Region

#Region "プロパティ"

    Private _systemController As SystemController
    ''' <summary>
    ''' 一覧型保守システム情報
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property SystemController() As SystemController
        Get
            Return _systemController
        End Get
        Set(ByVal value As SystemController)
            _systemController = value
        End Set
    End Property

#End Region

#Region "コンストラクタ"

    Sub New()
        ' この呼び出しは、Windows フォーム デザイナで必要です。
        InitializeComponent()
        'コンテキストメニュー用
        _contextMenu = New OSK.X1.Foundation.SmartControl.ContextMenu.ContextMenu()    'X1変換Tool-20160427
        'メニューバーの"設定"用
        _systemController = New SystemController
    End Sub

#End Region

#Region "継承メソッド"

#Region "初期処理"

    ''' <summary>
    ''' コントロール情報の取得
    ''' </summary>
    ''' <remarks>２番目の起動処理。主に初期処理で取得した値を変数に格納する。コントロール情報など。</remarks>
    Protected Overrides Sub startImpl()
        MyBase.StartImpl()

        Me.Text = Me.システム環境情報.プログラム情報.名称
        If Me.システム環境情報.プログラム制御情報.会社名表示 = True Then
            Me.Text &= "－"
            Me.Text &= Me.システム環境情報.会社情報.名称
        End If

        '_myコントロール情報型.Initialize(SettingInfo)
        '_myコントロール情報型.InitializeMyControlInfo(InitInfo)
        _my項目名称型 = New My項目名称型
        _my項目名称型.Initialize(InitInfo)

        'A-20101014_1{
        _myコントロール情報型_基準.Initialize(InitInfo, Me)

        Dim systemController As New SystemController
        systemController.Initialize(Me)
        systemController.SetUpSystemController()

        '<<表示ボタンイメージ対応>>
        Dim imageManager As IImageManager
        imageManager = CommonFactory.CreateInstance(Of IImageManager)(Me, GetType(ImageManager))
        Dim library As IImageLibrary = CommonFactory.CreateInstance(Of IImageLibrary)(Me, GetType(Library))
        imageManager.SetupLibrary(library)
        complete.Image = imageManager.GetImage("最新表示")


    End Sub

    ''' <summary>
    ''' 初期設定３
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks>３番目の起動処理。主にコントロールの初期位置・設定制御を行なう。ファンクションバーなど。</remarks>
    Public Overrides Sub LoadImpl(ByVal sender As Object, ByVal e As System.EventArgs)
        MyBase.LoadImpl(sender, e)

        'デザイン時は処理を抑制する
        If DesignMode = True Then
            Return
        End If
        'メッセージ情報取得
        _personalMessageViewer = New PersonalMessageViewer(SettingInfo, statusBar)
        'コンテキストメニューの設定
        SetUpContextMenu()
        ' メニューバーの"設定"用
        _systemController = New SystemController
        _systemController.Initialize(Me)
        _systemController.SetUpSystemController()
        'MenuBarの設定
        Call SetupMenuBarStandard()
        SaveSystemController()
        'ヘルプメニュー表示しない
        Me.menuBar.Items.RemoveByKey("_help")
        Me.HelpViewer = Nothing


        SetupFocusSwitch()
        SetUpStatusBar()
        InitForm()
        SetUpFunctionBar()
        SetFunctionBarShori()
        ClearAll()
        'SetLastKubunParam()
    End Sub

    ''' <summary>
    ''' フォームが開いたときの処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks>４番目の起動処理。フォーカスセットを主に行なう</remarks>
    Private Sub CommandView_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        shori.Focus()
    End Sub

#End Region

    ''' <summary>
    ''' 項目の初期設定
    ''' </summary>
    ''' <remarks>画面の項目の初期設定を行う(属性・桁数やフォントなど)</remarks>
    Private Sub InitForm()

        _bufferDataShurui = ""
        _bufferMeisaiKubun = -1
        _属性変更フラグ = 0

        'meisaiKubun.Enabled = False
        shoriModeLabel.Visible = False
        _MoveOtherGroup0Flag = False

        '上書きモード設定
        dataShurui.InputTextControl.Insert = False
        'テキストのcaretを左側に設定
        dataShurui.InputTextControl.FocusCaretPosition = InputText.FocusCaretPositionType.Left


        '区分マスター保守から値を取得する
        Dim getDatatype As DataTable = Nothing
        If GetMasterSelector.GetDatatype(SettingInfo, getDatatype, IMasterSelector.マスター区分型.データ種類) = True Then
            With _データ種類_取引名称
                For i As Integer = 0 To getDatatype.Rows.Count - 1
                    Select Case CStr(getDatatype.Rows(i).Item("CUSCE03002"))
                        Case "01"
                            .Add(CStr(getDatatype.Rows(i).Item("CUSCE03002")),
                                 CStr(getDatatype.Rows(i).Item("CUSCE03003")) & GetUriagedenpyoName())
                        Case "03"
                            .Add(CStr(getDatatype.Rows(i).Item("CUSCE03002")),
                                 CStr(getDatatype.Rows(i).Item("CUSCE03003")) & GetShiiredenpyoName())
                        Case "05"
                            .Add(CStr(getDatatype.Rows(i).Item("CUSCE03002")),
                                CStr(getDatatype.Rows(i).Item("CUSCE03003")) & GetNyuusyukkodenpyoName())
                        Case Else
                            .Add(CStr(getDatatype.Rows(i).Item("CUSCE03002")),
                                CStr(getDatatype.Rows(i).Item("CUSCE03003")))
                    End Select
                    '.Add("01", "売上伝票" & GetUriagedenpyoName())
                    '.Add("03", "仕入伝票" & GetShiiredenpyoName())
                    '.Add("02", "入金伝票")
                    '.Add("04", "支払伝票")                           'D-20121120_1
                    '.Add("05", "入出庫伝票" & GetNyuusyukkodenpyoName())    'A-20121120_1
                Next
                _データ種類_区分データ = getDatatype
            End With
        End If

        SetupDivisionSelecter()                        '区分検索の初期処理

        execute.Enabled = False
        InitGrid()                                     'グリッドの初期処理
    End Sub

    ''' <summary>
    ''' 管理オプション別の取引名称取得(売上伝票用)
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetUriagedenpyoName() As String
        Dim getName As String = ""
        Dim getNameList As New List(Of String)

        getNameList.Add("受注")
        getNameList.Add("見積")

        If getNameList.Count = 0 Then
            getName = ""
        Else
            getName = "(" & Join(getNameList.ToArray, "/") & ")"
        End If
        Return getName
    End Function

    ''' <summary>
    ''' 管理オプション別の取引名称取得(仕入伝票用)
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetShiiredenpyoName() As String
        Dim getName As String = ""
        Dim getNameList As New List(Of String)



        getNameList.Add("発注")
        getNameList.Add("経費")

        If getNameList.Count = 0 Then
            getName = ""
        Else
            getName = "(" & Join(getNameList.ToArray, "/") & ")"
        End If
        Return getName
    End Function

    'A-20121120_1{
    ''' <summary>
    ''' 管理オプション別の取引名称取得(入出庫伝票用)
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetNyuusyukkodenpyoName() As String
        Dim getName As String = ""
        Dim getNameList As New List(Of String)


        If getNameList.Count = 0 Then
            getName = ""
        Else
            getName = "(" & Join(getNameList.ToArray, "/") & ")"
        End If
        Return getName
    End Function
    'A-20121120_1}

    ''' <summary>
    ''' 処理区分を渡す
    ''' </summary>
    ''' <param name="mode">処理区分</param>
    ''' <remarks></remarks>
    Public Sub GetShoriMode(ByRef mode As IShoriMode)
        mode = New ShoriMode

        Select Case shori.Value - 1
            Case IShoriMode.処理モード区分.登録
                mode.SetShoriMode(IShoriMode.処理モード区分.登録)
            Case IShoriMode.処理モード区分.修正
                mode.SetShoriMode(IShoriMode.処理モード区分.修正)
            Case IShoriMode.処理モード区分.削除
                mode.SetShoriMode(IShoriMode.処理モード区分.削除)
        End Select
    End Sub

    Private Sub InitGrid()
        InitializeGridHelper()
        gridEntry.TreatDataType = 1    ' グリッドにコンボやチェックボックスがある時は必要
    End Sub

#Region "グリッドヘルパー初期化関連"

    ''' <summary>
    ''' グリッドヘルパーの初期化
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub InitializeGridHelper()

        '属性情報処理*****************************************************************************************
        Dim itemInfoList As New ColumnInfoList(InitInfo, SettingInfo, Me)

        itemInfoList.SetGridEntry(gridEntry)
        _gridHelper = New GridHelper(gridEntry, itemInfoList, _limitMaxRowCount, Me)
        _gridHelper.SetupGridHelper()
        InitializeGridEntry()

        Dim zokuseiTable As DataTable
        zokuseiTable = CType(InitInfo.Item("プログラム専用.属性情報のデータテーブル"), DataTable).Clone

        _gridHelper.SetDataTable(zokuseiTable)

        _前回属性データ = zokuseiTable.Clone
        For i As Integer = 1 To _limitMaxRowCount
            _前回属性データ.Rows.Add(0, 0, 0, 0, "", 0)
        Next

        _maxRowCount = gridEntry.DataTable.Rows.Count
    End Sub

    ''' <summary>
    ''' グリッドの初期化
    ''' </summary>
    ''' <remarks>必ずグリッドヘルパーの初期化後に行う。</remarks>
    Private Sub InitializeGridEntry()
        '<グリッド設定>
        With gridEntry
            .ColsFixed = 0                                     '固定表示列数(１列目からカウント)
            .FocusEditPosition = 1                             'グリッドにフォーカスするとき前回編集時のセルにカーソルが行く
            .UseLineNumber = True
            .LineNumberAlignment = HorzAlign.Right
            .AllowUserColumnResize = True
            'ソートモードの設定
            For i As Integer = 0 To 3
                .Columns(i).SortMode = OSK.X1.Foundation.Controls.Grid.Common.GridSortMode.NotSort    'X1変換Tool-20160427
            Next
        End With

        _キー属性 = キー属性型.数値

        _GridGetStateInfo = New GridGetStateInfo
        _GridGetStateInfo.Initialize(gridEntry, GridItem.属性, CType(_キー属性, IGridGetStateInfo.キー属性型))
        _gridMoveCellManager = New GridMoveCellManager
        _gridMoveCellManager.Initialize(gridEntry, GridItem.属性, CType(_キー属性, IGridGetStateInfo.キー属性型))
    End Sub
#End Region
#End Region

#Region "画面制御"

    ''' <summary>
    ''' 画面の初期化
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub ClearAll()

        _lastDataShurui = ""
        _lastMeisaiKubun = -1
        _lastShoriMode = -1
        _oldDataShurui = ""
        _changeShoriMode = False

        If _executeAfter = False Then
            dataShurui.TextValue = ""
            dataShurui.DispNameText = ""
            meisaiKubun.Value = 1

        End If
        _executeAfter = False


        SetRedraw(False)

        gridEntry.RowCount = 0
        For i As Integer = 1 To _limitMaxRowCount
            _gridHelper.Insert(-1, CreateNewRow)
        Next
        For i As Integer = 0 To _limitMaxRowCount - 1
            _gridHelper.ChangeRowForeColor(i, _gridHelper.ForeColorUnchanged)
        Next

        SetRedraw(True)

        _属性変更フラグ = 0
        _強制実行フラグ = 0
        _定義処理更新回数 = 0
        '_更新再実行フラグ = False
        _実行ID枝番 = 0

        statusBar.StatusLabelControl.Text = ""
    End Sub

    ''' <summary>
    ''' 処理モードのSelChangeイベント
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub shoriMode_SelChange(ByVal sender As Object, ByVal e As System.EventArgs) Handles shori.SelChange
        Dim mode As IShoriMode = New ShoriMode

        GetShoriMode(mode)
        SetFunctionBarShori()

        Select Case shori.Value - 1
            Case IShoriMode.処理モード区分.登録
                shoriModeLabel.Text = "新規データ"
                shoriModeLabel.BackColor = Drawing.Color.GreenYellow

            Case IShoriMode.処理モード区分.修正
                shoriModeLabel.Text = "データ修正"
                shoriModeLabel.BackColor = Drawing.Color.Yellow

            Case IShoriMode.処理モード区分.削除
                shoriModeLabel.Text = "データ削除"
                shoriModeLabel.BackColor = Drawing.Color.Red
        End Select
    End Sub

    ''' <summary>
    ''' 属性の値によっての画面制御（ReadOnly）
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub ControlReadOnly(ByVal targetRowIndex As Integer, ByVal zokuseiTpyeValue As Integer)

        '--- 初期値（必要に応じて Case 側で上書き）
        gridEntry.Cells(targetRowIndex)(GridItem.小数).ReadOnly = Grid.Common.Boolean.True
        gridEntry.Cells(targetRowIndex)(GridItem.桁数).ReadOnly = Grid.Common.Boolean.False
        gridEntry.Cells(targetRowIndex)(GridItem.項目名称).ReadOnly = Grid.Common.Boolean.False

        Select Case zokuseiTpyeValue

            Case 0
                '未使用：桁数・項目名称は編集不可
                gridEntry.Cells(targetRowIndex)(GridItem.桁数).ReadOnly = Grid.Common.Boolean.True
                gridEntry.Cells(targetRowIndex)(GridItem.項目名称).ReadOnly = Grid.Common.Boolean.True

            Case 3
                '数値：小数のみ編集可（桁数・項目名称は編集可）
                gridEntry.Cells(targetRowIndex)(GridItem.小数).ReadOnly = Grid.Common.Boolean.False

            Case 4, 5, 6
                '年月日/年月度/年度：桁数は固定のため編集不可（項目名称は編集可）
                gridEntry.Cells(targetRowIndex)(GridItem.桁数).ReadOnly = Grid.Common.Boolean.True

            Case Else
                'その他：初期値のまま（小数は編集不可、桁数・項目名称は編集可）

        End Select

    End Sub


#End Region

#Region "フォーカス制御"

    ''' <summary>
    ''' 入力制御の初期化を行う。(フォーカススイッチの初期化)
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetupFocusSwitch()
        _focusSwitcher = New Foundation.FocusSwitch.FocusSwitcher
        _focusSwitcher.SetForm(Me)

        shori.GroupNo = 0
        shori.SubGroupNo = 0
        shori.RemarkString = "shori"

        dataShurui.InputTextControl.GroupNo = 0
        dataShurui.InputTextControl.SubGroupNo = 0
        dataShurui.InputTextControl.RemarkString = "CUSZE01001"

        meisaiKubun.GroupNo = 0
        meisaiKubun.SubGroupNo = 0
        meisaiKubun.RemarkString = "CUSZE01002"

        complete.GroupNo = 0
        complete.SubGroupNo = 0
        complete.RemarkString = "complete"

        gridEntry.GroupNo = 1
        gridEntry.SubGroupNo = 0
        gridEntry.RemarkString = gridEntry.Name

        execute.GroupNo = 2
        execute.SubGroupNo = 0
        execute.RemarkString = execute.Name

        _focusSwitcher.AddAllControl(Me)

        _focusSwitcher.AddPreviousCheckDefaultMethod(AddressOf Check前処理)
        _focusSwitcher.AddGridCheckMethod(gridEntry, AddressOf GridEntry_DoCheck)
        _focusSwitcher.AddCheckMethod(shori, FocusSwitch.CheckModeType.移動先チェック, AddressOf CheckMethodMoveIn_Shori)
        _focusSwitcher.AddCheckMethod(dataShurui.InputTextControl, FocusSwitch.CheckModeType.移動先チェック, AddressOf CheckMethodMoveIn_DataShurui)
        _focusSwitcher.AddCheckMethod(dataShurui.InputTextControl, FocusSwitch.CheckModeType.移動元チェック, AddressOf CheckMethodMoveOther_DataShurui)
        _focusSwitcher.AddCheckMethod(meisaiKubun, FocusSwitch.CheckModeType.移動先チェック, AddressOf CheckMethodMoveIn_MeisaiKubun)
        _focusSwitcher.AddCheckMethod(execute, FocusSwitch.CheckModeType.移動元チェック, AddressOf CheckMethodMoveOther_Execute)
        _focusSwitcher.AddGroupCheckMethod(0, FocusSwitch.CheckModeType.移動元チェック, AddressOf CheckMethodMoveOther_Group0)
        _focusSwitcher.AddGroupCheckMethod(1, FocusSwitch.CheckModeType.移動元チェック, AddressOf CheckMethodMoveOther_Group1)
        _focusSwitcher.AddGroupCheckMethod(2, FocusSwitch.CheckModeType.移動元チェック, AddressOf CheckMethodMoveOther_Group2)
    End Sub

    ''' <summary>
    ''' 移動前のデフォルトの処理。ステータスラベルをクリアする。
    ''' </summary>
    ''' <param name="args"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function Check前処理(ByVal args As CheckMethodArgs) As Boolean
        If _statusClearFlag = True Then
            _statusClearFlag = False
            Return True
        End If
        statusBar.StatusLabelControl.Text = ""
        Return True
    End Function

    Public Function CheckMethodMoveIn_UriageShiyouKubun(ByVal args As CheckMethodArgs) As Boolean
        statusBar.StatusLabelControl.Text = ""
        Return True
    End Function

    Public Function CheckMethodMoveIn_Shori(ByVal args As CheckMethodArgs) As Boolean
        If Val(_lastMeisaiKubun) <> -1 Then
            If MessageViewer.Show(48, IMessageViewer.DefaultButtonType.No, "", "") = IMessageViewer.ShowResultType.Yes Then
                Call ClearAll()
                shori.Focus()
            Else
                args.移動先コントロール = args.移動元コントロール
                args.失敗時動作 = CheckMethodArgs.失敗時動作型.移動する
                If args.移動元グループ番号 <> 0 Then
                    execute.Enabled = True
                    complete.Enabled = False
                    _MoveOtherGroup0Flag = True
                    shoriModeLabel.Visible = True
                End If
            End If
        End If
        Return True
    End Function

    Public Function CheckMethodMoveOther_DataShurui(ByVal args As CheckMethodArgs) As Boolean
        If CheckDataShurui() = True Then
            GetDataShuruiDisplayName()
        Else
            If args.移動方向 = CheckMethodArgs.移動方向型.後へ Then
                If dataShurui.TextValue.TrimEnd = "" Then
                    MyBase.MessageViewer.Show(72)        ' この項目は省略できません。
                Else
                    _personalMessageViewer.Show(6, PersonalMessageViewer.MessageType.StatusBar)
                End If
                dataShurui.InputTextControl.SelectAll()
                dataShurui.InputTextControl.UpdateCaretPos(0)
                Return False
            Else
                dataShurui.TextValue = _oldDataShurui
            End If
        End If
        Return True
    End Function

    Public Function CheckMethodMoveIn_DataShurui(ByVal args As CheckMethodArgs) As Boolean
        statusBar.StatusLabelControl.Text = ""
        Return True
    End Function

    Public Function CheckMethodMoveIn_MeisaiKubun(ByVal args As CheckMethodArgs) As Boolean
        If CheckDataShurui() = False Then
            dataShurui.InputTextControl.Focus()
        Else
            GetDataShuruiDisplayName()
        End If
        Return True
    End Function

    Public Function CheckMethodMoveOther_Execute(ByVal args As CheckMethodArgs) As Boolean
        If (args.移動元グループ番号 > args.移動先グループ番号) AndAlso shori.Value = 3 Then
            shoriModeLabel.Visible = False
            _MoveOtherGroup0Flag = False
            complete.Enabled = True
            execute.Enabled = False
            SetReadOnly(False)
            _completeClickFlag = False

            dataShurui.InputTextControl.Focus()
        End If
        Return True
    End Function

    Public Function CheckMethodMoveOther_Group0(ByVal args As CheckMethodArgs) As Boolean
        If (args.移動元グループ番号 < args.移動先グループ番号) Then
            '表示ボタンを押下して明細へ移動する場合はチェックしない。
            If _completeClickFlag = True Then Return True

            'キーが前回確定値と同じだったら再読み込みしない
            If IsChangedNewKey() = False Then
                execute.Enabled = True
                shoriModeLabel.Visible = True

                If shori.Value = 3 Then
                    SetReadOnly(True)
                    execute.Focus()
                Else
                    args.移動先コントロール.Focus()
                End If
                _MoveOtherGroup0Flag = True
                complete.Enabled = False
                SetReadOnly(False)
                Return True
            End If

            If CheckDataShurui() = False Then
                args.移動先コントロール = dataShurui.InputTextControl
                args.失敗時動作 = CheckMethodArgs.失敗時動作型.移動する
                Me.MessageViewer.Show(72)
                dataShurui.InputTextControl.SelectAll()
                dataShurui.InputTextControl.UpdateCaretPos(0)
                Return False
            Else
                GetDataShuruiDisplayName()
            End If

            SetRedraw(False)
            If GetMeisaiData(0) Then
                execute.Enabled = True
                '画面の各項目の表示状態を変更する
                ChangeDisplayView()
                SetLastParams()
                SetReadOnly(True)
                SetReadOnlyEternal()

                If shori.Value = 3 Then
                    RestoreReadOnly()
                    execute.Focus()
                Else
                    RestoreReadOnly()
                    SetReadOnly(False)
                    Dim targetControl As Control = args.移動先コントロール

                    If args.移動先コントロール.Equals(gridEntry) = True Then
                        '移動先がグリッドの場合、一旦フォーカスを先頭行先頭列に設定しておく..
                        gridEntry.Enabled = False
                        gridEntry.SetCellEdit(0, GridItem.属性)
                        gridEntry.Enabled = True
                    End If
                    'A-20131023_1}
                    args.移動先コントロール.Focus()
                End If
                complete.Enabled = False
            Else
                If shori.Value - 1 = IShoriMode.処理モード区分.登録 Then

                    args.移動先コントロール = meisaiKubun
                    args.失敗時動作 = CheckMethodArgs.失敗時動作型.移動する
                    _personalMessageViewer.Show(5, PersonalMessageViewer.MessageType.StatusBar)
                    Return False
                ElseIf shori.Value - 1 <> IShoriMode.処理モード区分.登録 Then
                    args.移動先コントロール = meisaiKubun
                    args.失敗時動作 = CheckMethodArgs.失敗時動作型.移動する
                    _personalMessageViewer.Show(6, PersonalMessageViewer.MessageType.StatusBar)
                    Return False
                End If
            End If
            SetRedraw(True)
            If shori.Value <> 1 Then
                _bufferDataShurui = dataShurui.TextValue
                _bufferMeisaiKubun = meisaiKubun.Value

            End If
            SetLastParams()
            shoriModeLabel.Visible = True
            _MoveOtherGroup0Flag = True
        End If
        Return True
    End Function

    Public Function CheckMethodMoveOther_Group1(ByVal args As CheckMethodArgs) As Boolean
        If _gridFocusLost = False Then Return True
        If args.移動先グループ番号 = 0 Then
            shoriModeLabel.Visible = False
            _MoveOtherGroup0Flag = False
            complete.Enabled = True
            execute.Enabled = False
            SetReadOnly(False)
            _completeClickFlag = False
        End If
        Return True
    End Function

    Public Function CheckMethodMoveOther_Group2(ByVal args As CheckMethodArgs) As Boolean
        If args.移動先グループ番号 = 0 Then
            shoriModeLabel.Visible = False
            _MoveOtherGroup0Flag = False
            complete.Enabled = True
            execute.Enabled = False
            SetReadOnly(False)
            _completeClickFlag = False
        End If
        Return True
    End Function

    Private Function CheckDataShurui() As Boolean
        If _データ種類_取引.Contains(dataShurui.TextValue) = True Then Return True
        Return False
    End Function

    Private Sub GetDataShuruiDisplayName()
        dataShurui.DispNameText = _データ種類_取引名称(dataShurui.TextValue).ToString
        _oldDataShurui = dataShurui.TextValue
    End Sub

    ''' <summary>
    ''' 各項目の表示状態を変更
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub ChangeDisplayView()
        Dim checkShubetu As Boolean = True
        Dim checkMitumori As Boolean = True
        Dim checkKeihi As Boolean = True
        Dim checkNyuusyukka As Boolean = True

        If dataShurui.TextValue = "05" Then
                checkShubetu = False

        End If

        gridEntry.Redraw = False

        '読込んだグリッド情報に合わせて行単位にセルのReadOnly制御を行う
        For i As Integer = 0 To 29
            ControlReadOnly(i, CInt(gridEntry.GetData(i, 0).ToString))
        Next
        gridEntry.Redraw = True

    End Sub

#End Region

#Region "内部メソッドグリッドチェック用"

    ''' <summary>
    ''' グリッドのチェックメソッド
    ''' </summary>
    ''' <param name="args">パラメータ</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GridEntry_DoCheck(ByVal args As GridCheckMethodArgs) As Boolean
        _gridFocusLost = False
        Dim 実行ボタン移動 As Boolean = False

        'F5:クリアを実行した場合はチェックしない
        If _executeDoClearFlg = True Then
            _executeDoClearFlg = False
            _gridFocusLost = True
            Return True
        End If
        '同一セルの移動で発生したValidateCellイベントは実行しない。
        If _GridGetStateInfo.IsMovingSameCell(args.GridEventArgs) = True Then
            statusBar.StatusLabelControl.Text = ""
            args.GridEventArgs.Cancel = True
            Return True
        End If

        If _GridGetStateInfo.IsNothingEditCell() = True Then Return False
        'グリッドの内部の移動の場合、移動先セルのチェックおよび移動先補正を行う。
        If _GridGetStateInfo.IsMovingOtherControl(args.GridEventArgs) = False Then
            'グリッド内移動時
            If _gridMoveCellManager.GetCanMoveNextCell(args) = False Then
                '属性が"0:未使用"か"9:参照定義"の場合に最終行・入力可能最終列からEnterキーで
                '移動しようとしたに移動先がなかったら実行ボタンにフォーカスを移動させる為のフラグを立てる。
                If args.GridEventArgs.FromRowIndex = args.GridEventArgs.ToRowIndex AndAlso
                   args.GridEventArgs.FromColIndex < args.GridEventArgs.ToColIndex AndAlso
                   gridEntry.EditRowIndex = gridEntry.RowCount - 1 Then
                    _gridFocusLost = True
                    実行ボタン移動 = True
                Else
                    Call GridCellCheck(args.GridEventArgs.FromRowIndex, args.GridEventArgs.FromColIndex)
                    args.GridEventArgs.Cancel = True
                    Return False
                End If
            End If
            statusBar.StatusLabelControl.Text = ""
        Else
            '他コントロール移動時
            _gridFocusLost = True
            statusBar.StatusLabelControl.Text = ""

            If _gridMoveCellManager.MoveDirectionFromGrid(args) = 0 Then
                '前方向移動はチェックなし
                If args.GridEventArgs.FromRowIndex = gridEntry.RowCount - 1 AndAlso
                   _GridGetStateInfo.IsKeyInputNull(args.GridEventArgs.FromRowIndex) = True Then
                    Return True
                End If

                _prevRowIndex = args.GridEventArgs.FromRowIndex
                _prevColIndex = args.GridEventArgs.FromColIndex
                _newRowIndex = args.GridEventArgs.ToRowIndex
                _newColIndex = args.GridEventArgs.ToColIndex
                If GridCellCheck(args.GridEventArgs.FromRowIndex, args.GridEventArgs.FromColIndex) = False Then
                    args.GridEventArgs.Cancel = True
                    gridEntry.SelectAll()
                    Return False
                End If
            Else
                If args.GridEventArgs.FromRowIndex = gridEntry.RowCount - 1 AndAlso
                       args.GridEventArgs.FromColIndex = GridItem.属性 AndAlso
                       _GridGetStateInfo.IsKeyInputNull(args.GridEventArgs.FromRowIndex) = True Then

                    Call ClearRow(args.GridEventArgs.FromRowIndex)
                    gridEntry.CurrentEditValue = ""
                    Return True
                End If
                '後方向移動は最終行までチェック

                args.GridEventArgs.ToColIndex = GridItem.項目名称

                args.GridEventArgs.ToRowIndex = gridEntry.RowCount - 1
            End If
        End If
        '移動元および移動先情報をいったん退避
        _prevRowIndex = args.GridEventArgs.FromRowIndex
        _prevColIndex = args.GridEventArgs.FromColIndex
        _newRowIndex = args.GridEventArgs.ToRowIndex
        _newColIndex = args.GridEventArgs.ToColIndex

        Dim errColIndex As Integer = 0
        Dim errRowIndex As Integer = 0

        '移動元のセルチェック

        _checkBoxState = True

        If args.GridEventArgs.FromRowIndex > args.GridEventArgs.ToRowIndex Then
            '<前行移動=============================================================================================>
            If GridCellCheck(args.GridEventArgs.FromRowIndex, args.GridEventArgs.FromColIndex) = False Then
                args.GridEventArgs.Cancel = True
                gridEntry.SelectAll()
                Return False
            End If
            '同一行で残りカラムチェック
            If GridColumnRangeCheck(args.GridEventArgs.FromRowIndex, 0, gridEntry.ColumnCount - 1, errColIndex) = False Then
                args.GridEventArgs.ToRowIndex = args.GridEventArgs.FromRowIndex
                args.GridEventArgs.ToColIndex = errColIndex
                DisplayGuide(gridEntry.EditColIndex)
                Return False
            End If
            '移動先行のフォーカス可能チェック (※カラム0～移動先カラムまで)
            If GridColumnRangeCheck(args.GridEventArgs.ToRowIndex, 0, args.GridEventArgs.FromColIndex, errColIndex) = False Then
                args.GridEventArgs.ToColIndex = errColIndex
                Return False
            End If
        ElseIf args.GridEventArgs.FromRowIndex = args.GridEventArgs.ToRowIndex Then
            '<同一行移動=============================================================================================>
            If GridCellCheck(args.GridEventArgs.FromRowIndex, args.GridEventArgs.FromColIndex) = False Then
                args.GridEventArgs.Cancel = True
                gridEntry.SelectAll()
                Return False
            End If
            '同一行で残りカラムチェック
            If GridColumnRangeCheck(args.GridEventArgs.FromRowIndex, args.GridEventArgs.FromColIndex + 1, args.GridEventArgs.ToColIndex - 1, errColIndex) = False Then
                errRowIndex = args.GridEventArgs.FromRowIndex
                args.GridEventArgs.ToColIndex = errColIndex
            End If
        ElseIf args.GridEventArgs.FromRowIndex < args.GridEventArgs.ToRowIndex Then
            '<後行移動=============================================================================================>
            'セルチェック
            If GridCellCheck(args.GridEventArgs.FromRowIndex, args.GridEventArgs.FromColIndex) = False Then
                args.GridEventArgs.Cancel = True
                gridEntry.SelectAll()
                Return False
            End If
            '行間のチェック
            If GridRowRangeCheck(args.GridEventArgs.FromRowIndex, args.GridEventArgs.FromColIndex + 1, args.GridEventArgs.ToRowIndex, args.GridEventArgs.ToColIndex, errRowIndex, errColIndex) = False Then
                args.GridEventArgs.ToColIndex = errColIndex
                args.GridEventArgs.ToRowIndex = errRowIndex
            End If

        End If
        '他のコントロールへ移動
        If _gridFocusLost = True Then
            args.GridEventArgs.ToColIndex = -1
            args.GridEventArgs.ToRowIndex = -1

            If errRowIndex <> 0 OrElse errColIndex <> 0 Then
                _newRowIndex = errRowIndex
                _newColIndex = errColIndex
                _gridFocusLost = False
            End If
        End If

        If 実行ボタン移動 = True Then
            RequestDoComplete(gridEntry, gridEntry.EditColName)
        End If

        Return True
    End Function

    Private Sub GridEntry_Validating(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles gridEntry.Validating
        If _gridFocusLost = False Then
            e.Cancel = True
            gridEntry.SetCellEdit(_newRowIndex, _newColIndex)
        End If
    End Sub

    ''' <summary>
    ''' カラム間チェック
    ''' </summary>
    ''' <param name="targetRowIndex">対象行</param>
    ''' <param name="targetStartColIndex">チェック開始列番号</param>
    ''' <param name="targetEndColIndex">チェック終了列番号</param>
    ''' <param name="errColIndex">エラー発生列番号</param>
    ''' <returns>TRUE：OK、FALSE：NG</returns>
    ''' <remarks></remarks>
    Public Function GridColumnRangeCheck(ByVal targetRowIndex As Integer, ByVal targetStartColIndex As Integer, ByVal targetEndColIndex As Integer,
                                          ByRef errColIndex As Integer) As Boolean

        For i As Integer = targetStartColIndex To targetEndColIndex
            If GridCellCheck(targetRowIndex, i) = False Then
                errColIndex = i
                Return False
            End If
        Next
        Return True
    End Function

    ''' <summary>
    ''' 行間のチェック
    ''' </summary>
    ''' <param name="fromRowIndex">移動元行番号</param>
    ''' <param name="fromColIndex">移動元列番号</param>
    ''' <param name="toRowIndex">移動先行番号</param>
    ''' <param name="toColIndex">移動先列番号</param>
    ''' <param name="errorRowIndex">エラー発生行番号</param>
    ''' <param name="errorColIndex">エラー発生列番号</param>
    ''' <returns>チェックＯＫフラグ</returns>
    ''' <remarks></remarks>
    Public Function GridRowRangeCheck(ByVal fromRowIndex As Integer, ByVal fromColIndex As Integer,
                                           ByVal toRowIndex As Integer, ByVal toColIndex As Integer,
                                           ByRef errorRowIndex As Integer, ByRef errorColIndex As Integer) As Boolean
        Dim checkFromCol As Integer
        Dim checkToCol As Integer

        If toRowIndex > gridEntry.RowCount - 1 Then
            toRowIndex = gridEntry.RowCount - 1
        End If

        For i As Integer = fromRowIndex To toRowIndex
            If i = fromRowIndex Then
                checkFromCol = fromColIndex
                checkToCol = gridEntry.ColumnCount - 1
            ElseIf i = toRowIndex Then
                checkFromCol = GridItem.属性
                checkToCol = toColIndex
                If checkFromCol = checkToCol Then Return True
            Else
                checkFromCol = GridItem.属性
                checkToCol = gridEntry.ColumnCount - 1
            End If

            If GridColumnRangeCheck(i, checkFromCol, checkToCol, errorColIndex) = False Then
                errorRowIndex = i
                Return False
            End If
        Next
        Return True
    End Function

    ''' <summary>
    ''' グリッドのEnter処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub gridEntry_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles gridEntry.Enter
        'クリックなどの場合、対象セルがフォーカス可能かをチェック(Enter時Varidatingが走らない)
        If gridEntry.IsMouseEnter = True Then
            Dim newColIndex As Integer = 0
            Dim newRowIndex As Integer = 0
            If gridEntry.ClickedCol = -1 OrElse gridEntry.ClickedRow = -1 Then
                newColIndex = GridItem.属性
                newRowIndex = 0
            Else
                newColIndex = gridEntry.ClickedCol
                newRowIndex = gridEntry.ClickedRow
            End If

            If _gridMoveCellManager.GetCanMoveNextCell(0, GridItem.属性, newRowIndex, newColIndex) = True Then
                gridEntry.SetCellEdit(newRowIndex, newColIndex)
            Else
                If _gridMoveCellManager.GetCanMoveNextCell(newRowIndex, newColIndex) = True Then
                    gridEntry.SetCellEdit(newRowIndex, newColIndex)
                Else
                    newColIndex = GridItem.属性
                    gridEntry.SetCellEdit(newRowIndex, newColIndex)
                End If
            End If
            _prevColIndex = newColIndex
            _prevRowIndex = newRowIndex
        Else
            _prevColIndex = gridEntry.EditColIndex
            _prevRowIndex = gridEntry.EditRowIndex
        End If
        SetUpGridFunction(CType(_prevColIndex, GridItem))
        functionBar.Update()
    End Sub

    ''' <summary>
    ''' グリッドセル移動完了後処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub gridEntry_ValidatedCell(ByVal sender As Object, ByVal e As OSK.X1.Foundation.Controls.Grid.Common.ValidatedCellEventArgs) Handles gridEntry.ValidatedCell    'X1変換Tool-20160427
        SetUpGridFunction(CType(e.ToColIndex, GridItem))
    End Sub

    ''' <summary>
    ''' グリッドのファンクション設定
    ''' </summary>
    ''' <param name="colIndex">列番号</param>
    ''' <remarks></remarks>
    Private Sub SetUpGridFunction(ByVal colIndex As GridItem)

        If colIndex = -1 Then Exit Sub
        Dim rowIndex As Integer = 0
        rowIndex = gridEntry.EditRowIndex
        If rowIndex = -1 Then Exit Sub

        Dim nowRowState As System.Data.DataRowState
        nowRowState = gridEntry.GetDataRowState(rowIndex)

        DisplayGuide(colIndex)

        FunctionBar1.Update()
        FunctionBar1.SetTargetGridControl(gridEntry, gridEntry.EditColName)
    End Sub

    ''' <summary>
    ''' 行の値(DataTable値)をデフォルト値にする。
    ''' </summary>
    ''' <param name="curRowIndex"></param>
    ''' <remarks></remarks>
    Private Sub ClearRow(ByVal curRowIndex As Integer)
        gridEntry.SetData(curRowIndex, "CUSZE01004", 0)
        gridEntry.SetData(curRowIndex, "CUSZE01005", DBNull.Value)
        gridEntry.SetData(curRowIndex, "CUSZE01006", DBNull.Value)
        gridEntry.SetData(curRowIndex, "CUSZE01007", "")

        gridEntry.Refresh()
    End Sub

    ''' <summary>
    '''　グリッドにこれ以上移動可能なセルがない。
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks>今回は先頭行から上、最終行から下でこのイベントが走る</remarks>
    Private Sub gridEntry_NoMoreMoveableCell(ByVal sender As Object, ByVal e As OSK.X1.Foundation.Controls.Grid.Common.NoMoreMoveableCellEventArgs) Handles gridEntry.NoMoreMoveableCell    'X1変換Tool-20160427
        '先頭行先頭セルから前移動
        If e.RowIndex = 0 AndAlso e.ColIndex = GridItem.属性 AndAlso e.Direction = 0 Then
            _focusSwitcher.GetPrevControl(gridEntry).Focus()
            Exit Sub
        End If
        '最終行から後移動
        If gridEntry.EditRowIndex = gridEntry.RowCount - 1 AndAlso e.Direction = 1 Then
            'フォーカスが属性にあって最終行から下へ行こうとしたかどうかを判断する。
            If gridEntry.EditColIndex = GridItem.属性 AndAlso e.Direction = 1 Then
                Dim errColIndex As Integer = 0
                Dim errRowIndex As Integer = 0
                '最終行入力チェック
                'If GridRowRangeCheck(gridEntry.EditRowIndex, GridItem.属性, gridEntry.EditRowIndex, GridItem.見積, errRowIndex, errColIndex) = False Then      'D-20080709_2
                If GridRowRangeCheck(gridEntry.EditRowIndex, GridItem.属性, gridEntry.EditRowIndex, GridItem.項目名称, errRowIndex, errColIndex) = False Then       'A-20080709_2
                    gridEntry.SetCellEdit(errRowIndex, errColIndex)
                    Exit Sub
                End If
                gridEntry.SetData(gridEntry.EditRowIndex, gridEntry.EditColIndex, gridEntry.CurrentEditValue)
                _focusSwitcher.GetNextControl(gridEntry).Focus()
            End If
        End If
    End Sub

    ''' <summary>
    ''' セルのチェックメソッドを選抜
    ''' </summary>
    ''' <param name="ColumnIndex">対象列番号</param>
    ''' <param name="Method">チェックメソッド</param>
    ''' <returns>TRUE：メソッドあり　False：メソッドなし</returns>
    ''' <remarks></remarks>
    Private Function GetItemCheckMethod(ByVal ColumnIndex As Integer, ByRef Method As CheckCellItem) As Boolean
        Select Case ColumnIndex
            Case GridItem.属性
                Method = New CheckCellItem(AddressOf CheckMethodCol_属性)
            Case GridItem.桁数
                Method = New CheckCellItem(AddressOf CheckMethodCol_桁数)
            Case GridItem.小数
                Method = New CheckCellItem(AddressOf CheckMethodCol_小数)
            Case GridItem.項目名称
                Method = New CheckCellItem(AddressOf CheckMethodCol_項目名称)
            Case Else
                Return False
        End Select
        Return True
    End Function

    ''' <summary>
    ''' Delegate　チェックメソッド
    ''' </summary>
    ''' <param name="targetRowIndex">対象行番号</param>
    ''' <param name="targetColIndex">対象列番号</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Delegate Function CheckCellItem(ByVal targetRowIndex As Integer, ByVal targetColIndex As Integer) As Boolean

    ''' <summary>
    ''' セル単位のチェック
    ''' </summary>
    ''' <param name="targetRowIndex">対象行番号</param>
    ''' <param name="targetColIndex">対象列番号</param>
    ''' <returns>TRUE：OK、FALSE：NG</returns>
    ''' <remarks></remarks>
    Public Function GridCellCheck(ByVal targetRowIndex As Integer, ByVal targetColIndex As Integer) As Boolean
        'チェック対象のセルかをチェック
        If _GridGetStateInfo.IsCheckTargetCell(targetRowIndex, targetColIndex) = False Then
            Return True
        End If
        '各セルのチェックメソッドを実行(Delegate)
        Dim Method As CheckCellItem = Nothing
        If GetItemCheckMethod(targetColIndex, Method) = True Then
            If Method.Invoke(targetRowIndex, targetColIndex) = False Then
                Return False
            End If
        End If
        Return True
    End Function

    ''' <summary>
    ''' グリッドのコンボボックスのSelchangeイベント
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub gridEntry_ComboBoxSelChange(ByVal sender As Object, ByVal e As System.EventArgs) Handles gridEntry.ComboBoxSelChange
        'チェック対象が現在編集行だった場合
        If _GridGetStateInfo.IsCurrentEditCell(gridEntry.EditRowIndex, gridEntry.EditColIndex) = True Then
            Select Case gridEntry.EditColIndex
                Case GridItem.属性
                    ControlReadOnly(gridEntry.EditRowIndex, CInt(gridEntry.CurrentEditValue.ToString))
                Case Else
            End Select
        End If
    End Sub

#End Region

#Region "セル用チェックメソッド"

    ''' <summary>
    ''' 属性セル用チェックメソッド
    ''' </summary>
    ''' <param name="targetRowIndex">対象行</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CheckMethodCol_属性(ByVal targetRowIndex As Integer, ByVal targetColIndex As Integer) As Boolean
        'チェック対象が現在編集行だった場合
        If _GridGetStateInfo.IsCurrentEditCell(targetRowIndex, targetColIndex) = True Then
            '属性が"未使用"の場合、属性以降の行を初期表示にする。
            If CInt(gridEntry.CurrentEditValue.ToString) = 0 Then
                '属性が変更されてなかったらチェックしない
                If gridEntry.CurrentEditValue.ToString.Equals(gridEntry.GetData(targetRowIndex, GridItem.属性).ToString) = True Then
                    Return True
                End If
                Call ClearRow(targetRowIndex)
                Return True

            End If
            '属性が数値だったら、桁数・小数・ｶﾝﾏ編集に初期値をセットする。
            If CInt(gridEntry.CurrentEditValue.ToString) = 3 Then
                If gridEntry.GetData(targetRowIndex, GridItem.桁数).ToString = "" Then gridEntry.SetData(targetRowIndex, GridItem.桁数, 0)
                If gridEntry.GetData(targetRowIndex, GridItem.小数).ToString = "" Then gridEntry.SetData(targetRowIndex, GridItem.小数, 0)
            ElseIf CInt(gridEntry.CurrentEditValue.ToString) = 4 Then
                gridEntry.SetData(targetRowIndex, GridItem.桁数, 8)
            ElseIf CInt(gridEntry.CurrentEditValue.ToString) = 5 Then
                gridEntry.SetData(targetRowIndex, GridItem.桁数, 6)
            ElseIf CInt(gridEntry.CurrentEditValue.ToString) = 6 Then
                gridEntry.SetData(targetRowIndex, GridItem.桁数, 4)
                'gridEntry.SetData(targetRowIndex, GridItem.桁数, DBNull.Value)
                'gridEntry.SetData(targetRowIndex, GridItem.小数, DBNull.Value)
            Else
                gridEntry.SetData(targetRowIndex, GridItem.小数, DBNull.Value)
            End If

            If CInt(gridEntry.CurrentEditValue.ToString) = 8 OrElse
               CInt(gridEntry.CurrentEditValue.ToString) = 9 OrElse
               CInt(gridEntry.CurrentEditValue.ToString) = 10 OrElse
               CInt(gridEntry.CurrentEditValue.ToString) = 11 OrElse
               CInt(gridEntry.CurrentEditValue.ToString) = 12 OrElse
               CInt(gridEntry.CurrentEditValue.ToString) = 13 Then
                gridEntry.SetData(targetRowIndex, GridItem.小数, DBNull.Value)
            End If
            '必須項目チェック(行終了・マウスクリック用)
            If CheckMoveExecute() = False Then Return False
        End If
        Return True
    End Function

    ''' <summary>
    ''' 必須入力チェック
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CheckMoveExecute() As Boolean

        If _newRowIndex = -1 OrElse _newColIndex = -1 Then
            If gridEntry.EditColIndex = GridItem.属性 Then

                If (gridEntry.GetData(gridEntry.EditRowIndex, GridItem.属性).ToString.TrimEnd <> "1" OrElse
                   gridEntry.GetData(gridEntry.EditRowIndex, GridItem.属性).ToString.TrimEnd <> "2" OrElse
                   gridEntry.GetData(gridEntry.EditRowIndex, GridItem.属性).ToString.TrimEnd <> "3") AndAlso
                   gridEntry.GetData(gridEntry.EditRowIndex, GridItem.桁数).ToString.TrimEnd = "0" Then Return False


            End If
        End If
        Return True
    End Function

    ''' <summary>
    ''' 桁数セル用チェックメソッド
    ''' </summary>
    ''' <param name="targetRowIndex">対象行</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CheckMethodCol_桁数(ByVal targetRowIndex As Integer, ByVal targetColIndex As Integer) As Boolean
        If _GridGetStateInfo.IsCurrentEditCell(targetRowIndex, targetColIndex) = True Then
            If _prevColIndex < _newColIndex OrElse _prevRowIndex <> _newRowIndex Then
                If CheckPrecisiondigits(targetRowIndex, targetColIndex, True) = False Then Return False
            End If
        Else
            If _prevColIndex < _newColIndex OrElse _prevRowIndex <> _newRowIndex Then
                If CheckPrecisiondigits(targetRowIndex, targetColIndex, False) = False Then Return False
            End If
        End If
        Return True
    End Function

    ''' <summary>
    ''' 小数セル用チェックメソッド
    ''' </summary>
    ''' <param name="targetRowIndex">対象行</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CheckMethodCol_小数(ByVal targetRowIndex As Integer, ByVal targetColIndex As Integer) As Boolean
        If gridEntry.GetDisplayCellInfo(targetRowIndex, targetColIndex).ReadOnly = Grid.Common.Boolean.True Then Return False

        If _GridGetStateInfo.IsCurrentEditCell(targetRowIndex, targetColIndex) = True Then
            If _prevColIndex < _newColIndex OrElse _prevRowIndex <> _newRowIndex Then
                If CheckScaledigits(targetRowIndex, targetColIndex, True) = False Then Return False
            End If
        Else
            If _prevColIndex < _newColIndex OrElse _prevRowIndex <> _newRowIndex Then
                If CheckScaledigits(targetRowIndex, GridItem.小数, False) = False Then Return False
            End If
        End If
        Return True
    End Function

    ''' <summary>
    ''' 項目名セル用チェックメソッド
    ''' </summary>
    ''' <param name="targetRowIndex">対象行</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CheckMethodCol_項目名称(ByVal targetRowIndex As Integer, ByVal targetColIndex As Integer) As Boolean
        If _GridGetStateInfo.IsCurrentEditCell(targetRowIndex, targetColIndex) = True Then
            If _prevColIndex < _newColIndex OrElse _prevRowIndex <> _newRowIndex Then
                If gridEntry.CurrentEditValue.ToString.TrimEnd = "" Then
                    If _prevRowIndex <> _newRowIndex OrElse (_prevColIndex < _newColIndex AndAlso _prevRowIndex = _newRowIndex) Then MessageViewer.Show(72) 'この項目は省略できません。
                    Return False
                End If
            End If
        Else
            If _prevRowIndex <> _newRowIndex OrElse (_prevColIndex < _newColIndex OrElse _prevRowIndex = _newRowIndex) OrElse
               (targetRowIndex = gridEntry.RowCount - 1 AndAlso _newRowIndex = -1) Then

                If gridEntry.GetData(targetRowIndex, GridItem.項目名称).ToString.TrimEnd = "" Then
                    If _prevRowIndex < _newRowIndex OrElse (_prevColIndex < _newColIndex AndAlso GridItem.項目名称 < _newColIndex AndAlso _prevRowIndex = _newRowIndex) Then
                        MessageViewer.Show(72) 'この項目は省略できません。
                        _statusClearFlag = True
                    End If
                    Return False
                End If
            End If
        End If
        Return True
    End Function

    ''' <summary>
    ''' 桁数セルの桁数チェック
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CheckPrecisiondigits(ByVal targetRowIndex As Integer, ByVal targetColIndex As Integer, ByVal currentFlag As Boolean) As Boolean
        If currentFlag = True Then
            If Val(gridEntry.CurrentEditValue.ToString.TrimEnd) = 0 Then
                DisplayGuide(targetColIndex)
                Return False
            End If
        Else
            If Val(gridEntry.GetData(targetRowIndex, targetColIndex).ToString) = 0 Then
                DisplayGuide(targetColIndex)
                Return False
            End If
        End If


        Dim 数値項目桁数 As Integer = 14


        Dim attr As Integer = GetZokuseiValue(targetRowIndex, currentFlag)
        Dim inputPrec As Integer
        If currentFlag Then
            inputPrec = CInt(Val(gridEntry.CurrentEditValue.ToString()))
        Else
            inputPrec = CInt(Val(gridEntry.GetData(targetRowIndex, targetColIndex).ToString()))
        End If
        Select Case attr
            Case 4 ' 年月日
                If inputPrec <> 8 Then
                    DisplayGuide(targetColIndex)
                    Return False
                End If
                Return True

            Case 5 ' 年月度
                If inputPrec <> 6 Then
                    DisplayGuide(targetColIndex)
                    Return False
                End If
                Return True

            Case 6 ' 年度
                If inputPrec <> 4 Then
                    DisplayGuide(targetColIndex)
                    Return False
                End If
                Return True
        End Select


        '選ばれている属性によって入力桁数の制御を行う。
        Select Case GetZokuseiValue(targetRowIndex, currentFlag)
            Case 3
                If currentFlag = True Then

                    If Val(gridEntry.CurrentEditValue.ToString) > 0 AndAlso
                       Val(gridEntry.CurrentEditValue.ToString) < 数値項目桁数 Then Return True
                Else

                    If Val(gridEntry.GetData(targetRowIndex, targetColIndex).ToString) > 0 AndAlso
                       Val(gridEntry.GetData(targetRowIndex, targetColIndex).ToString) < 数値項目桁数 Then Return True
                End If
            Case 7
                Return True
            Case Else

                Dim maxLength As Integer = 65
                '全角文字と半角文字の最大桁数の設定箇所
                If GetZokuseiValue(targetRowIndex, currentFlag) = 1 OrElse
                   GetZokuseiValue(targetRowIndex, currentFlag) = 2 Then
                    maxLength = 257
                End If

                If currentFlag = True Then
                    If Val(gridEntry.CurrentEditValue.ToString) > 0 AndAlso
                       Val(gridEntry.CurrentEditValue.ToString) < maxLength Then Return True
                Else
                    If Val(gridEntry.GetData(targetRowIndex, targetColIndex).ToString) > 0 AndAlso
                       Val(gridEntry.GetData(targetRowIndex, targetColIndex).ToString) < maxLength Then Return True
                End If


                '↓A-20160817-X1-桁数拡張
                'If _myコントロール情報型.拡張項目データリンク桁数拡張 = True AndAlso
                If GetZokuseiValue(targetRowIndex, currentFlag) >= 8 AndAlso
                    GetZokuseiValue(targetRowIndex, currentFlag) <= 13 Then
                    If currentFlag = True Then
                        If Val(gridEntry.CurrentEditValue.ToString) > 0 AndAlso
                           Val(gridEntry.CurrentEditValue.ToString) < 257 Then Return True
                    Else
                        If Val(gridEntry.GetData(targetRowIndex, targetColIndex).ToString) > 0 AndAlso
                           Val(gridEntry.GetData(targetRowIndex, targetColIndex).ToString) < 257 Then Return True
                    End If
                End If
                '↑A-20160817-X1-桁数拡張
        End Select
        DisplayGuide(targetColIndex)
        Return False
    End Function

    ''' <summary>
    ''' 小数セルの桁数チェック
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CheckScaledigits(ByVal targetRowIndex As Integer, ByVal targetColIndex As Integer, ByVal currentFlag As Boolean) As Boolean
        '選ばれている属性によって入力桁数の制御を行う。
        Select Case CInt(gridEntry.GetData(targetRowIndex, 0).ToString)
            Case 3
                If currentFlag = True Then
                    If Val(gridEntry.CurrentEditValue.ToString) >= 0 AndAlso
                       Val(gridEntry.CurrentEditValue.ToString) < 7 Then Return True
                Else
                    If Val(gridEntry.GetData(targetRowIndex, targetColIndex).ToString) >= 0 AndAlso
                       Val(gridEntry.GetData(targetRowIndex, targetColIndex).ToString) < 7 Then Return True
                End If
            Case Else
                Return True
        End Select
        DisplayGuide(targetColIndex)
        Return False
    End Function

    ''' <summary>
    ''' 移動時の属性を取得
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetZokuseiValue(ByVal targetRowIndex As Integer, ByVal currentFlag As Boolean) As Integer
        If targetRowIndex = gridEntry.EditRowIndex AndAlso gridEntry.EditColIndex = GridItem.属性 AndAlso currentFlag = False Then
            Return CInt(gridEntry.CurrentEditValue.ToString)
        Else
            Return CInt(gridEntry.GetData(targetRowIndex, 0).ToString)
        End If
    End Function

#End Region

#Region "内部メソッド"

    ''' <summary>
    ''' 新規行情報を作成する。
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CreateNewRow() As DataRow
        For i As Integer = 0 To gridEntry.DataTable.Columns.Count - 1
            gridEntry.DataTable.Columns(i).ReadOnly = False
            gridEntry.DataTable.Columns(i).AllowDBNull = True
        Next
        Dim newRow As DataRow = gridEntry.DataTable.NewRow

        newRow.Item("CUSZE01004") = 0
        newRow.Item("CUSZE01005") = DBNull.Value
        newRow.Item("CUSZE01006") = DBNull.Value
        newRow.Item("CUSZE01007") = ""

        Return newRow
    End Function

    ''' <summary>
    ''' 区分選択のリスト作成
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetupDivisionSelecter()
        _targetTorihiki = CommonFactory.CreateInstance(Of IDivisionSelecter)(Me, GetType(DivisionSelecter))
        _targetTorihiki.Initialize(SettingInfo, InitInfo, SaveInfo)
        '取引データ用リスト作成***************************************************************************************
        For k As Integer = 0 To _データ種類_区分データ.Rows.Count - 1
            '    _データ種類_取引.Add("01")
            '_データ種類_取引.Add("02")
            '_データ種類_取引.Add("03")
            '_データ種類_取引.Add("04")
            '_データ種類_取引.Add("05")
            _データ種類_取引.Add(CStr(_データ種類_区分データ.Rows(k).Item("CUSCE03002")))
        Next
        Dim torihikiList As New List(Of String)
        Dim i As Integer
        For i = 0 To _データ種類_取引.Count - 1
            torihikiList.Add("  " & _データ種類_取引(i) & "  " & _データ種類_取引名称(_データ種類_取引(i)).ToString)
        Next
        _targetTorihiki.SetupSelectForm("データ種類", torihikiList.ToArray)
    End Sub

    ''' <summary>
    ''' MasterSelector用メソッド
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetMasterSelector() As IMasterSelector
        Return DataAccessFactory(Of IMasterSelector).CreateInstance(Me, "MasterSelector")
    End Function

    ''' <summary>
    ''' 補助
    ''' </summary>
    ''' <param name="i"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function AutoCount(ByRef i As Integer) As Integer
        i += 1
        Return i
    End Function

    'Private Function Is検収基準_出荷() As Boolean
    '    If _myコントロール情報型.強化区分 >= 5.0 Then
    '        If (_myコントロール情報型.検収基準 = 機能区分定義型.検収基準型.売上and仕入行う OrElse
    '            _myコントロール情報型.検収基準 = 機能区分定義型.検収基準型.売上のみ) OrElse
    '           (_myコントロール情報型.着荷基準 = 機能区分定義型.着荷基準型.売上and仕入行う OrElse
    '            _myコントロール情報型.着荷基準 = 機能区分定義型.着荷基準型.売上のみ) Then
    '            Return True
    '        End If
    '    End If
    '    Return False
    'End Function

    'Private Function Is検収基準_入荷() As Boolean
    '    If _myコントロール情報型.強化区分 >= 5.0 Then
    '        If (_myコントロール情報型.検収基準 = 機能区分定義型.検収基準型.売上and仕入行う OrElse
    '            _myコントロール情報型.検収基準 = 機能区分定義型.検収基準型.仕入のみ) OrElse
    '           (_myコントロール情報型.着荷基準 = 機能区分定義型.着荷基準型.売上and仕入行う OrElse
    '            _myコントロール情報型.着荷基準 = 機能区分定義型.着荷基準型.仕入のみ) Then
    '            Return True
    '        End If
    '    End If
    '    Return False
    'End Function

    'Private Function Is検収基準() As Boolean
    '    If _myコントロール情報型.強化区分 >= 5.0 Then
    '        If _myコントロール情報型.検収基準 <> 機能区分定義型.検収基準型.行わない OrElse
    '           _myコントロール情報型.着荷基準 <> 機能区分定義型.着荷基準型.行わない Then
    '            Return True
    '        End If
    '    End If
    '    Return False
    'End Function

    'Private Function Is予定在庫区分_入出庫() As Boolean
    '    If _myコントロール情報型.強化区分 >= 7.0 Then
    '        If _myコントロール情報型.予定在庫区分_入出庫 = その他定義型.予定在庫区分_入出庫型.行う Then
    '            Return True
    '        End If
    '    End If
    '    Return False
    'End Function

    'Private Function Is受発注消費税あり() As Boolean
    '    If _myコントロール情報型.強化区分 >= 10D AndAlso
    '       _myコントロール情報型.受発注_入出荷_消費税入力 = 機能区分定義型.受発注_入出荷_消費税入力型.行う Then
    '        Return True
    '    End If
    '    Return False
    'End Function

    'Private Function Is受発注伝票申請承認機能あり() As Boolean
    '    If _myコントロール情報型.強化区分 >= 5D AndAlso
    '       _myコントロール情報型.伝票承認機能使用区分 = 伝票承認定義型.区分型.使用する AndAlso
    '      (_myコントロール情報型.受注伝票承認使用区分 = 伝票承認定義型.区分型.使用する OrElse
    '       _myコントロール情報型.発注伝票承認使用区分 = 伝票承認定義型.区分型.使用する) Then
    '        Return True
    '    End If
    '    Return False
    'End Function


    'Private Function Isスマートサーチ機能あり() As Boolean
    '    If _myコントロール情報型.強化区分 >= 26D AndAlso
    '       _myコントロール情報型.スマートサーチ機能 = スマートサーチ定義型.スマートサーチ機能使用区分型.使用する Then
    '        Return True
    '    End If
    '    Return False
    'End Function
    'Private Function Is検収＿着荷基準仕入あり() As Boolean
    '    If _myコントロール情報型.強化区分 >= 5D Then
    '        If _myコントロール情報型.検収基準 = 機能区分定義型.検収基準型.売上and仕入行う OrElse
    '           _myコントロール情報型.検収基準 = 機能区分定義型.検収基準型.仕入のみ OrElse
    '           _myコントロール情報型.着荷基準 = 機能区分定義型.着荷基準型.売上and仕入行う OrElse
    '           _myコントロール情報型.着荷基準 = 機能区分定義型.着荷基準型.仕入のみ Then
    '            Return True
    '        End If
    '    End If
    '    Return False
    'End Function
    'Private Function Is検収＿着荷基準売上あり() As Boolean
    '    If _myコントロール情報型.強化区分 >= 5D Then
    '        If _myコントロール情報型.検収基準 = 機能区分定義型.検収基準型.売上and仕入行う OrElse
    '           _myコントロール情報型.検収基準 = 機能区分定義型.検収基準型.売上のみ OrElse
    '           _myコントロール情報型.着荷基準 = 機能区分定義型.着荷基準型.売上and仕入行う OrElse
    '           _myコントロール情報型.着荷基準 = 機能区分定義型.着荷基準型.売上のみ Then
    '            Return True
    '        End If
    '    End If
    '    Return False
    'End Function
    ''↑A-20191213-X1-スマートサーチ機能


    ''↓A-20220926-X1-仕入データ自動入力
    'Private Function Is仕入データ自動入力機能あり() As Boolean
    '    With _myコントロール情報型
    '        If .強化区分 >= 32D AndAlso
    '           .外部データ取込機能 = 機能区分定義型.外部データ取込機能型.行う AndAlso
    '           .仕入データ自動入力 = 外部データ自動入力定義型.仕入データ自動入力型.使用する Then
    '            Return True
    '        End If
    '    End With
    '    Return False
    'End Function
    ''↑A-20220926-X1-仕入データ自動入力

    Private Function Getデータ種類略称(ByVal datashuriCode As String) As String
        Dim rows As DataRow() = _データ種類_区分データ.Select("CUSCE03002 = '" & datashuriCode & "'")
        Dim kubunRyaku As String = ""
        If rows IsNot Nothing AndAlso rows.Length > 0 Then
            Dim o As Object = rows(0)("CUSCE03004")
            If o IsNot Nothing AndAlso Not IsDBNull(o) Then
                kubunRyaku = o.ToString()
            End If
        End If
        Return kubunRyaku
    End Function
#End Region

#Region "コンテキストメニュー関連処理"

    ''' <summary>
    ''' コンテキストメニューの初期化
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetUpContextMenu()
        _contextMenu.FunctionBar = FunctionBar1
    End Sub

#End Region

#Region "メニューバー関連処理"

    ''' <summary>
    ''' メニューバーの設定
    ''' </summary>
    ''' <remarks></remarks>
    Protected Sub SetupMenuBarStandard()
        '' => 整合処理
        'Call SetupMenuBar_Adjustment()
        ' => 表示
        Call SetupMenuBar_menuView()

        Call SetUpMenuBar()
        Call SetUpGrid()
        Call SaveSystemController()
        '' => ヘルプ - FWのメソッドを使用
        'Call menuBar.SetupHelp(SettingInfo)

    End Sub


#Region "メニューバー.表示の設定"

    Protected WithEvents menuSetteiView As New System.Windows.Forms.ToolStripMenuItem
    Protected WithEvents EnterDirection As New System.Windows.Forms.ToolStripMenuItem
    Protected WithEvents moveRight As New System.Windows.Forms.ToolStripMenuItem
    Protected WithEvents moveDown As New System.Windows.Forms.ToolStripMenuItem
    Protected WithEvents actionLeftRight As New System.Windows.Forms.ToolStripMenuItem
    Protected WithEvents moveBetween As New System.Windows.Forms.ToolStripMenuItem
    Protected WithEvents moveInside As New System.Windows.Forms.ToolStripMenuItem

    ''' <summary>
    ''' メニューバー.表示の設定
    ''' </summary>
    ''' <remarks></remarks>
    Protected Sub SetupMenuBar_menuView()

        menuBar.Items.AddRange(New System.Windows.Forms.ToolStripItem() {menuSetteiView})

        With menuSetteiView
            .DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {EnterDirection, actionLeftRight})
            .Name = "config"
            .Text = "設定(&S)"
        End With

        With EnterDirection
            .Name = "EnterDirection"
            .Text = "Enterキー移動方向(&C)"
            .DropDownDirection = ToolStripDropDownDirection.Right
            .DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {moveRight, moveDown})
        End With
        With moveRight
            .Checked = True
            .CheckOnClick = True
            .CheckState = System.Windows.Forms.CheckState.Checked
            .Name = "moveRight"
            .Size = New System.Drawing.Size(122, 22)
            .Text = "→移動(&R)"
            AddHandler EnterDirection.DropDownItems("moveRight").Click, AddressOf ChangeMenuEnterDirection
        End With
        With moveDown
            .CheckOnClick = True
            .Name = "moveDown"
            .Size = New System.Drawing.Size(122, 22)
            .Text = "↓移動(&D)"
            AddHandler EnterDirection.DropDownItems("moveDown").Click, AddressOf ChangeMenuEnterDirection
        End With

        With actionLeftRight
            .Name = "actionLeftRight"
            .Text = "左右矢印キーの動作(&A)"
            .Size = New System.Drawing.Size(210, 22)
            .DropDownDirection = ToolStripDropDownDirection.Right
            .DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {moveBetween, moveInside})
        End With
        With moveBetween
            .CheckOnClick = True
            .Name = "moveBetween"
            .Size = New System.Drawing.Size(146, 22)
            .Text = "項目間移動(&O)"
            AddHandler actionLeftRight.DropDownItems("moveBetween").Click, AddressOf ChangeMenuActionLeftRight
        End With
        With moveInside
            .Checked = True
            .CheckOnClick = True
            .CheckState = System.Windows.Forms.CheckState.Checked
            .Name = "moveInside"
            .Size = New System.Drawing.Size(146, 22)
            .Text = "項目内移動(&I)"
            AddHandler actionLeftRight.DropDownItems("moveInside").Click, AddressOf ChangeMenuActionLeftRight
        End With
    End Sub

    ''' <summary>
    ''' メニューバーの設定
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetUpMenuBar()

        Dim menuConfig As System.Windows.Forms.ToolStripMenuItem = CType(menuBar.Items("config"), System.Windows.Forms.ToolStripMenuItem)

        If SystemController.Enterキー移動方向 = ISystemController.Enterキー移動方向型.右 Then
            Dim menuEnterDirection As System.Windows.Forms.ToolStripMenuItem = CType(menuConfig.DropDownItems("EnterDirection"), System.Windows.Forms.ToolStripMenuItem)

            CType(menuEnterDirection.DropDownItems("moveRight"), System.Windows.Forms.ToolStripMenuItem).Checked = True
            CType(menuEnterDirection.DropDownItems("moveDown"), System.Windows.Forms.ToolStripMenuItem).Checked = False
        Else
            Dim menuEnterDirection As System.Windows.Forms.ToolStripMenuItem = CType(menuConfig.DropDownItems("EnterDirection"), System.Windows.Forms.ToolStripMenuItem)

            CType(menuEnterDirection.DropDownItems("moveRight"), System.Windows.Forms.ToolStripMenuItem).Checked = False
            CType(menuEnterDirection.DropDownItems("moveDown"), System.Windows.Forms.ToolStripMenuItem).Checked = True
        End If

        If SystemController.左右矢印キー = ISystemController.左右矢印型.項目間 Then
            Dim menuactionLeftRight As System.Windows.Forms.ToolStripMenuItem = CType(menuConfig.DropDownItems("actionLeftRight"), System.Windows.Forms.ToolStripMenuItem)

            CType(menuactionLeftRight.DropDownItems("moveBetween"), System.Windows.Forms.ToolStripMenuItem).Checked = True
            CType(menuactionLeftRight.DropDownItems("moveInside"), System.Windows.Forms.ToolStripMenuItem).Checked = False
        Else
            Dim menuactionLeftRight As System.Windows.Forms.ToolStripMenuItem = CType(menuConfig.DropDownItems("actionLeftRight"), System.Windows.Forms.ToolStripMenuItem)

            CType(menuactionLeftRight.DropDownItems("moveBetween"), System.Windows.Forms.ToolStripMenuItem).Checked = False
            CType(menuactionLeftRight.DropDownItems("moveInside"), System.Windows.Forms.ToolStripMenuItem).Checked = True
        End If
    End Sub

    ''' <summary>
    ''' グリッドの設定
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetUpGrid()
        If SystemController.Enterキー移動方向 = ISystemController.Enterキー移動方向型.右 Then
            gridEntry.MoveDirectionOnEnterKey = Grid.Edit.MoveDirectionOnEnter.Right
        Else
            gridEntry.MoveDirectionOnEnterKey = Grid.Edit.MoveDirectionOnEnter.Down
        End If

        If SystemController.左右矢印キー = ISystemController.左右矢印型.項目間 Then
            gridEntry.MoveEditCellOnArrowKey = True
        Else
            gridEntry.MoveEditCellOnArrowKey = False
        End If

    End Sub

    ''' <summary>
    ''' 左右矢印移動方向を切り替える
    ''' </summary>
    ''' <remarks></remarks>
    Protected Sub ChangeMenuActionLeftRight(ByVal sender As System.Object, ByVal e As System.EventArgs)

        Dim menuConfig As System.Windows.Forms.ToolStripMenuItem = CType(menuBar.Items("config"), System.Windows.Forms.ToolStripMenuItem)
        Dim menuactionLeftRight As System.Windows.Forms.ToolStripMenuItem = CType(menuConfig.DropDownItems("actionLeftRight"), System.Windows.Forms.ToolStripMenuItem)
        Dim moveBetween As System.Windows.Forms.ToolStripMenuItem = CType(menuactionLeftRight.DropDownItems("moveBetween"), System.Windows.Forms.ToolStripMenuItem)
        Dim moveInside As System.Windows.Forms.ToolStripMenuItem = CType(menuactionLeftRight.DropDownItems("moveInside"), System.Windows.Forms.ToolStripMenuItem)

        If sender.ToString = "項目内移動(&I)" Then
            moveBetween.Checked = False
            moveInside.Checked = True
            gridEntry.MoveEditCellOnArrowKey = False
        Else
            moveBetween.Checked = True
            moveInside.Checked = False
            gridEntry.MoveEditCellOnArrowKey = True
        End If
        Call SaveSystemController()

    End Sub

    ''' <summary>
    ''' Enterキーの移動方向を切り替える
    ''' </summary>
    ''' <remarks></remarks>
    Protected Sub ChangeMenuEnterDirection(ByVal sender As System.Object, ByVal e As System.EventArgs)

        Dim menuConfig As System.Windows.Forms.ToolStripMenuItem = CType(menuBar.Items("config"), System.Windows.Forms.ToolStripMenuItem)
        Dim menuEnterDirection As System.Windows.Forms.ToolStripMenuItem = CType(menuConfig.DropDownItems("EnterDirection"), System.Windows.Forms.ToolStripMenuItem)
        Dim moveRight As System.Windows.Forms.ToolStripMenuItem = CType(menuEnterDirection.DropDownItems("moveRight"), System.Windows.Forms.ToolStripMenuItem)
        Dim moveDown As System.Windows.Forms.ToolStripMenuItem = CType(menuEnterDirection.DropDownItems("moveDown"), System.Windows.Forms.ToolStripMenuItem)

        If sender.ToString = "↓移動(&D)" Then
            moveRight.Checked = False
            moveDown.Checked = True
            gridEntry.MoveDirectionOnEnterKey = Edit.MoveDirectionOnEnter.Down
        Else
            moveRight.Checked = True
            moveDown.Checked = False
            gridEntry.MoveDirectionOnEnterKey = Edit.MoveDirectionOnEnter.Right
        End If
        Call SaveSystemController()

    End Sub

    ''' <summary>
    ''' システムコントロール情報を保存
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SaveSystemController()
        Dim menuConfig As System.Windows.Forms.ToolStripMenuItem = CType(menuBar.Items("config"), System.Windows.Forms.ToolStripMenuItem)
        Dim menuEnterDirection As System.Windows.Forms.ToolStripMenuItem = CType(menuConfig.DropDownItems("EnterDirection"), System.Windows.Forms.ToolStripMenuItem)
        If CType(menuEnterDirection.DropDownItems("moveRight"), System.Windows.Forms.ToolStripMenuItem).Checked = True Then
            SystemController.Enterキー移動方向 = ISystemController.Enterキー移動方向型.右
        Else
            SystemController.Enterキー移動方向 = ISystemController.Enterキー移動方向型.下
        End If

        Dim menuactionLeftRight As System.Windows.Forms.ToolStripMenuItem = CType(menuConfig.DropDownItems("actionLeftRight"), System.Windows.Forms.ToolStripMenuItem)
        If CType(menuactionLeftRight.DropDownItems("moveBetween"), System.Windows.Forms.ToolStripMenuItem).Checked = True Then
            SystemController.左右矢印キー = ISystemController.左右矢印型.項目間
        Else
            SystemController.左右矢印キー = ISystemController.左右矢印型.項目内
        End If
    End Sub

#End Region

#End Region

#Region "ファンクション関連処理"

    ''' <summary>
    ''' ファンクションの設定
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetUpFunctionBar()

        'グリッド以外用ファンクション**********************************************************************************************
        FunctionBar1.Items.SetControls(FunctionControl.KeyType.F3, "コード検索", AddressOf RequestCodeSearch,
                                      dataShurui.InputTextControl)

        FunctionBar1.Items.SetControls(FunctionControl.KeyType.F5, "クリア", AddressOf DoClear,
                                      dataShurui.InputTextControl, meisaiKubun)
        ''A-20101213_2}
        'FunctionBar1.Items.SetControls(FunctionControl.KeyType.F6, "次データ", AddressOf DoNextMethod,
        '                              dataShurui.InputTextControl, meisaiKubun)

        'FunctionBar1.Items.SetControls(FunctionControl.KeyType.F7, "前データ", AddressOf DoPrevMethod,
        '                              dataShurui.InputTextControl, meisaiKubun)
        'A-20101213_2}
        '属性グリッド用ファンクション**********************************************************************************************
        FunctionBar1.Items.SetGridColumns(gridEntry, FunctionControl.KeyType.F3, "選択一覧", AddressOf RequestItemSelect,
                                         "CUSZE01004", "HANZ031010")

        FunctionBar1.Items.SetGridColumns(gridEntry, FunctionControl.KeyType.F5, "クリア", AddressOf RequestDoClear,
                                         "CUSZE01004", "CUSZE01005", "CUSZE01006", "CUSZE01007")
        FunctionBar1.Items.SetGridColumns(gridEntry, FunctionControl.KeyType.F8, "前回値セット", AddressOf SetDefaultCellValue,
                                         "CUSZE01004", "CUSZE01005", "CUSZE01006", "CUSZE01007")
        FunctionBar1.Items.SetGridColumns(gridEntry, FunctionControl.KeyType.F9, "以下省略", AddressOf RequestDoComplete,
                                         "CUSZE01004", "CUSZE01005", "CUSZE01006", "CUSZE01007")
        FunctionBar1.Items.SetGridColumns(gridEntry, FunctionControl.KeyType.F12, "左右矢印キーの動作", AddressOf RequestChangeMenuActionLeftRight,
                                         "CUSZE01005", "CUSZE01006", "CUSZE01007")

        FunctionBar1.SetUpFunctionEvent(Me)
    End Sub

    ''' <summary>
    ''' ファンクションバーのセット
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetFunctionBarShori()
        Select Case shori.Value - 1
            Case IShoriMode.処理モード区分.登録

                FunctionBar1.Items.Mode(dataShurui.InputTextControl, FunctionControl.KeyType.F3).Visible = True
                FunctionBar1.Items.Mode(dataShurui.InputTextControl, FunctionControl.KeyType.F5).Visible = True
                FunctionBar1.Items.Mode(dataShurui.InputTextControl, FunctionControl.KeyType.F6).Visible = False
                FunctionBar1.Items.Mode(dataShurui.InputTextControl, FunctionControl.KeyType.F7).Visible = False

                FunctionBar1.Items.Mode(meisaiKubun, FunctionControl.KeyType.F5).Visible = True
                FunctionBar1.Items.Mode(meisaiKubun, FunctionControl.KeyType.F6).Visible = False
                FunctionBar1.Items.Mode(meisaiKubun, FunctionControl.KeyType.F7).Visible = False
            Case IShoriMode.処理モード区分.修正
                FunctionBar1.Items.Mode(dataShurui.InputTextControl, FunctionControl.KeyType.F3).Visible = True
                FunctionBar1.Items.Mode(dataShurui.InputTextControl, FunctionControl.KeyType.F5).Visible = True
                FunctionBar1.Items.Mode(dataShurui.InputTextControl, FunctionControl.KeyType.F6).Visible = True
                FunctionBar1.Items.Mode(dataShurui.InputTextControl, FunctionControl.KeyType.F7).Visible = True

                FunctionBar1.Items.Mode(meisaiKubun, FunctionControl.KeyType.F5).Visible = True
                FunctionBar1.Items.Mode(meisaiKubun, FunctionControl.KeyType.F6).Visible = True
                FunctionBar1.Items.Mode(meisaiKubun, FunctionControl.KeyType.F7).Visible = True
            Case IShoriMode.処理モード区分.削除

                FunctionBar1.Items.Mode(dataShurui.InputTextControl, FunctionControl.KeyType.F3).Visible = True
                FunctionBar1.Items.Mode(dataShurui.InputTextControl, FunctionControl.KeyType.F5).Visible = True
                FunctionBar1.Items.Mode(dataShurui.InputTextControl, FunctionControl.KeyType.F6).Visible = True
                FunctionBar1.Items.Mode(dataShurui.InputTextControl, FunctionControl.KeyType.F7).Visible = True

                FunctionBar1.Items.Mode(meisaiKubun, FunctionControl.KeyType.F5).Visible = True
                FunctionBar1.Items.Mode(meisaiKubun, FunctionControl.KeyType.F6).Visible = True
                FunctionBar1.Items.Mode(meisaiKubun, FunctionControl.KeyType.F7).Visible = True
        End Select
    End Sub

    ''' <summary>
    ''' ステータスバーの初期化
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetUpStatusBar()
        statusBar.SetUpAutoClear(Me)
    End Sub


    ''' <summary>
    ''' 【F3:コード検索】
    ''' </summary>
    ''' <param name="targetControl">対象コントロール</param>
    ''' <remarks></remarks>
    Private Sub RequestCodeSearch(ByVal targetControl As Control)
        Dim selectedIndex As Integer
        Dim result As Boolean

        For i As Integer = 0 To _データ種類_取引.Count - 1
            If _データ種類_取引(i) = String.Format("{0:00}", dataShurui.TextValue) Then
                selectedIndex = i
                Exit For
            End If
        Next
        result = _targetTorihiki.SelectDivision(selectedIndex, selectedIndex)


        If result = True Then
            dataShurui.TextValue = _データ種類_取引(selectedIndex)
            _focusSwitcher.GetNextControl(targetControl).Focus()
        End If
    End Sub


    ''' <summary>
    ''' 【F3:選択一覧】
    ''' </summary>
    ''' <param name="control">グリッド</param>
    ''' <param name="columnName">列の名前</param>
    ''' <remarks></remarks>
    Private Sub RequestItemSelect(ByVal control As Foundation.SimpleControl.GridEdit, ByVal columnName As String)
        If gridEntry.IsComboBoxListOpen = False Then
            gridEntry.ShowComboBoxList()
        End If
    End Sub

    ''' <summary>
    ''' 【F5:クリア】
    ''' </summary>
    ''' <param name="targetControl">前回処理内容</param>
    ''' <remarks></remarks>
    Private Sub DoClear(ByVal targetControl As Control)
        If MessageViewer.Show(48, IMessageViewer.DefaultButtonType.No, "", "") = IMessageViewer.ShowResultType.Yes Then
            Call ClearAll()
            dataShurui.Focus()
        End If
    End Sub

    ''' <summary>
    ''' 【F6:次データ】
    ''' </summary>
    ''' <param name="control">項目</param>
    ''' <remarks></remarks>
    Private Sub DoNextMethod(ByVal control As System.Windows.Forms.Control)
        _targetControl = control
        SetRedraw(False)
        If GetMeisaiData(1) Then
            '画面の各項目の表示状態を変更する
            ChangeDisplayView()
            SetLastParams()
        Else
            MessageViewer.Show(41)
        End If
        SetRedraw(True)
        If control.Name <> "meisaiKubun" OrElse meisaiKubun.Enabled = True Then
            control.Focus()
        Else
            dataShurui.Focus()
        End If
    End Sub

    ''' <summary>
    ''' 【F7:前データ】
    ''' </summary>
    ''' <param name="control">項目</param>
    ''' <remarks></remarks>
    Private Sub DoPrevMethod(ByVal control As System.Windows.Forms.Control)
        _targetControl = control
        SetRedraw(False)
        If GetMeisaiData(2) Then
            '画面の各項目の表示状態を変更する
            ChangeDisplayView()
            SetLastParams()
        Else
            MessageViewer.Show(41)
        End If
        SetRedraw(True)
        If control.Name <> "meisaiKubun" OrElse meisaiKubun.Enabled = True Then
            control.Focus()
        Else
            dataShurui.Focus()
        End If
    End Sub

    ''' <summary>
    ''' 【F8:前回値セット】
    ''' </summary>
    ''' <param name="control"></param>
    ''' <remarks></remarks>
    Private Sub SetDefaultValue(ByVal control As System.Windows.Forms.Control)
        Select Case CType(control, OSK.X1.Foundation.SimpleControl.CheckBox).RemarkString    'X1変換Tool-20160427
        End Select
        '移動先を設定
        _focusSwitcher.GetNextControl(control).Focus()
    End Sub


    ''' <summary>
    ''' 【F8:前回値セット】(グリッド用)
    ''' </summary>
    ''' <param name="control"></param>
    ''' <param name="columnName"></param>
    ''' <remarks></remarks>
    Private Sub SetDefaultCellValue(ByVal control As OSK.X1.Foundation.SimpleControl.GridEdit, ByVal columnName As String)    'X1変換Tool-20160427
        Dim editRowIndex As Integer = control.EditRowIndex
        Dim editColIndex As Integer = control.EditColIndex

        Select Case CType(control, OSK.X1.Foundation.SimpleControl.GridEdit).RemarkString    'X1変換Tool-20160427
            Case "gridEntry"
                'gridEntry.CurrentEditValue = _前回属性データ.Rows(editRowIndex).Item(columnName).ToString      'D-20130404_2
                'A-20130404_2{
                If gridEntry.Columns(editColIndex).EditType = GridEditType.CheckBox Then
                    gridEntry.CurrentEditValue = CType(_前回属性データ.Rows(editRowIndex).Item(columnName), CheckState)
                Else
                    gridEntry.CurrentEditValue = _前回属性データ.Rows(editRowIndex).Item(columnName).ToString
                End If
                'A-20130404_2}
                '属性の列だった場合、対象行のReadOnly設定を行う。
                If editColIndex = 0 Then ControlReadOnly(editRowIndex, CInt(control.CurrentEditValue.ToString))
                '桁数列で前回値が"0"の場合、移動出来ないのでガイドの再表示だけ行う。
                If editColIndex = 2 AndAlso Val(gridEntry.CurrentEditValue.ToString) = 0 Then
                    DisplayGuide(editColIndex)
                    Exit Sub
                End If
                '移動先を設定
                If _gridMoveCellManager.GetCanMoveNextCell(editRowIndex, editColIndex) = True Then
                    gridEntry.SetCellEdit(editRowIndex, editColIndex)
                Else
                    RequestDoComplete(gridEntry, columnName)
                End If

        End Select
    End Sub

    ''' <summary>
    ''' 【F9:以下省略】 
    ''' </summary>
    ''' <param name="control">グリッド</param>
    ''' <remarks></remarks>
    Private Sub RequestDoComplete(ByVal control As System.Windows.Forms.Control)
        execute.Focus()
    End Sub

    ''' <summary>
    ''' 【F9:以下省略】(グリッド用)
    ''' </summary>
    ''' <param name="control">グリッド</param>
    ''' <param name="columnName">列の名前</param>
    ''' <remarks></remarks>
    Private Sub RequestDoComplete(ByVal control As OSK.X1.Foundation.SimpleControl.GridEdit, ByVal columnName As String)    'X1変換Tool-20160427
        If control.Name = "gridEntry" AndAlso control.EditRowIndex = 19 AndAlso control.EditColIndex = GridItem.属性 Then
            gridEntry.SetData(gridEntry.EditRowIndex, gridEntry.EditColIndex, gridEntry.CurrentEditValue)
            execute.Focus()
        Else
            execute.Focus()
        End If
    End Sub

    ''' <summary>
    ''' 【F5:クリア】
    ''' </summary>
    ''' <param name="control">グリッド</param>
    ''' <param name="columnName">列の名前</param>
    ''' <remarks></remarks>
    Private Sub RequestDoClear(ByVal control As OSK.X1.Foundation.SimpleControl.GridEdit, ByVal columnName As String)    'X1変換Tool-20160427
        If MessageViewer.Show(48, IMessageViewer.DefaultButtonType.No, "", "") = IMessageViewer.ShowResultType.Yes Then
            _targetControl = dataShurui
            _executeDoClearFlg = True
            _gridFocusLost = True
            'dataShubetu.Value = 1
            'dataShubetu.Focus()
            'Call ClearAll()
            'dataShurui.InputTextControl.Focus()

            Dim invoker As MethodInvoker = Sub()
                                               _targetControl = dataShurui
                                               Call ClearAll()

                                               'フォーカス先は実体（InputTextControl）にする
                                               dataShurui.InputTextControl.Focus()
                                           End Sub
            Me.BeginInvoke(invoker)

        End If
    End Sub

    ''' <summary>
    ''' 【F12:左右矢印キーモードの切替】
    ''' </summary>
    ''' <param name="control"></param>
    ''' <param name="columnName"></param>
    ''' <remarks></remarks>
    Private Sub RequestChangeMenuActionLeftRight(ByVal control As OSK.X1.Foundation.SimpleControl.GridEdit, ByVal columnName As String)    'X1変換Tool-20160427
        Dim menuConfig As System.Windows.Forms.ToolStripMenuItem = CType(Me.menuBar.Items("config"), System.Windows.Forms.ToolStripMenuItem)
        Dim menuactionLeftRight As System.Windows.Forms.ToolStripMenuItem = CType(menuConfig.DropDownItems("actionLeftRight"), System.Windows.Forms.ToolStripMenuItem)
        Dim moveBetween As System.Windows.Forms.ToolStripMenuItem = CType(menuactionLeftRight.DropDownItems("moveBetween"), System.Windows.Forms.ToolStripMenuItem)
        Dim moveInside As System.Windows.Forms.ToolStripMenuItem = CType(menuactionLeftRight.DropDownItems("moveInside"), System.Windows.Forms.ToolStripMenuItem)

        If moveBetween.Checked = True Then
            moveBetween.Checked = False
            moveInside.Checked = True
            gridEntry.MoveEditCellOnArrowKey = False
        Else
            moveBetween.Checked = True
            moveInside.Checked = False
            gridEntry.MoveEditCellOnArrowKey = True
        End If
    End Sub

#End Region

#Region "イベント"

    ''' <summary>
    ''' 表示ボタンクリック
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub complete_Click(ByVal sender As System.Object, ByVal e As EventArgs) Handles complete.Click
        _lastDataShurui = ""
        _focusSwitcher.GetNextControl(complete).Focus()
    End Sub

    ''' <summary>
    ''' 実行ボタンクリック
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub 実行_Click(ByVal sender As Object, ByVal e As EventArgs) Handles execute.Click
        Static nowExecute As Boolean = False
        If nowExecute = True Then Exit Sub

        If CheckUpdateExecute() = False Then
            If shori.Value - 1 = IShoriMode.処理モード区分.登録 Then
                _personalMessageViewer.Show(4, PersonalMessageViewer.MessageType.MessageBox, IMessageViewer.DefaultButtonType.OK, , , IMessageViewer.IconType.Exclamation)
                Exit Sub
            ElseIf shori.Value - 1 = IShoriMode.処理モード区分.修正 Then
                If _personalMessageViewer.Show(12, PersonalMessageViewer.MessageType.MessageBox,
                    IMessageViewer.DefaultButtonType.No, , , IMessageViewer.IconType.Exclamation) = IMessageViewer.ShowResultType.No Then
                    Exit Sub
                End If
                _changeShoriMode = True
            End If
        End If

        Dim rowIndex As Integer = 0
        If GridFinalCheck(rowIndex) = False Then
            _personalMessageViewer.Show(11, PersonalMessageViewer.MessageType.MessageBox, IMessageViewer.DefaultButtonType.OK, , , IMessageViewer.IconType.Exclamation)
            gridEntry.Focus()
            Exit Sub
        End If

        Dim logInfo As ILogInfo = CommonFactory.CreateInstance(Of ILogInfo)(Me, GetType(LogInfo))
        logInfo.処理状態 = 処理状態型.処理開始
        logInfo.処理内容 = "処理を開始しました。"
        logInfo.詳細情報 = GetCommandViewCondition()

        Select Case shori.Value
            Case 1
                If _personalMessageViewer.Show(7, PersonalMessageViewer.MessageType.MessageBox, IMessageViewer.DefaultButtonType.No, , ,
                                              IMessageViewer.IconType.Question) = IMessageViewer.ShowResultType.No Then Exit Sub
            Case 2
                If _changeShoriMode = False Then
                    If _personalMessageViewer.Show(8, PersonalMessageViewer.MessageType.MessageBox, IMessageViewer.DefaultButtonType.No, , ,
                                                  IMessageViewer.IconType.Question) = IMessageViewer.ShowResultType.No Then Exit Sub
                End If
            Case 3
                If _personalMessageViewer.Show(9, PersonalMessageViewer.MessageType.MessageBox, IMessageViewer.DefaultButtonType.No, , ,
                                              IMessageViewer.IconType.Question) = IMessageViewer.ShowResultType.No Then Exit Sub
        End Select

        'D-CUST20251208↓ '2026/01/22
        ''拡張項目画面設定のデータと比較して不整合データがある場合は警告を表示する。
        'If CheckGamenSetteiExist() = False Then
        '    Exit Sub
        'End If
        'D-CUST20251208↑ '2026/01/22

        Call CheckZokuseiChange()
        nowExecute = True
        _メニューバー整合処理より実行 = False
        RaiseEventDoUpdate(GetCommandParam(), logInfo)
        nowExecute = False
    End Sub

    Private Function GridFinalCheck(ByRef rowIndex As Integer) As Boolean
        '条件部が以下の条件の時はＯＫ

        Dim returnFlag As Boolean = True
        If Val(dataShurui.TextValue) = 1 Then returnFlag = False
        If Val(dataShurui.TextValue) = 3 Then returnFlag = False
        If Val(dataShurui.TextValue) = 5 Then returnFlag = False
        If returnFlag = True Then Return True
        'End If
        'A-20121120_1}

        For i As Integer = 0 To 29
            If gridEntry.GetData(i, "CUSZE01004").ToString <> "0" Then
            End If
        Next
        Return True
    End Function

    Private Function CheckUpdateExecute() As Boolean

        For i As Integer = 0 To 29
            If gridEntry.GetData(i, GridItem.属性).ToString.TrimEnd <> "0" Then Return True
        Next

        Return False
    End Function

    ''' <summary>
    ''' 属性変更判定
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub CheckZokuseiChange()

        For i As Integer = 0 To 29
            Select Case CInt(_初期属性データ.Rows(i).Item("CUSZE01004").ToString)
                Case 1, 2   '元々の属性が文字の場合 -----------------------------------------------------------------------------------------------------
                    '未使用、数値、日付、参照定義コードに変更された場合
                    If CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 0 OrElse
                       CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 3 OrElse
                       CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 4 OrElse
                       CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 5 OrElse
                       CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 6 OrElse
                       CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 7 Then
                        _属性変更フラグ = 1
                        Exit For
                    End If

                    '画像、実行ファイル、ファイル、フォルダ、URL、メールアドレスに変更された場合        'A-20080709_3
                    If CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 8 OrElse
                       CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 9 OrElse
                       CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 10 OrElse
                       CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 11 OrElse
                       CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 12 OrElse
                       CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 13 Then                     'A-20080709_3
                        _属性変更フラグ = 1                                                             'A-20080709_3
                        Exit For                                                                        'A-20080709_3
                    End If                                                                              'A-20080709_3

                    '属性が文字で桁数が減少した場合
                    If CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 1 OrElse
                       CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 2 Then
                        If CInt(Val(gridEntry.GetData(i, GridItem.桁数).ToString)) < CInt(Val(_初期属性データ.Rows(i).Item(GridItem.桁数).ToString)) Then
                            _属性変更フラグ = 1
                            Exit For
                        End If
                    End If

                Case 3      '元々の属性が数値の場合 -----------------------------------------------------------------------------------------------------
                    '未使用、日付、参照定義コードに変更された場合
                    If CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 0 OrElse
                       CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 4 OrElse
                       CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 5 OrElse
                       CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 6 OrElse
                       CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 7 Then
                        _属性変更フラグ = 1
                        Exit For
                    End If

                    '画像、実行ファイル、ファイル、フォルダ、URL、メールアドレスに変更された場合        'A-20080709_3
                    If CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 8 OrElse
                       CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 9 OrElse
                       CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 10 OrElse
                       CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 11 OrElse
                       CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 12 OrElse
                       CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 13 Then                     'A-20080709_3
                        _属性変更フラグ = 1                                                             'A-20080709_3
                        Exit For                                                                        'A-20080709_3
                    End If                                                                              'A-20080709_3

                    Dim 初期整数部 As Integer = CInt(Val(_初期属性データ.Rows(i).Item(GridItem.桁数).ToString))
                    Dim 初期小数部 As Integer = CInt(Val(_初期属性データ.Rows(i).Item(GridItem.小数).ToString))
                    Dim 最終整数部 As Integer = CInt(Val(gridEntry.GetData(i, GridItem.桁数).ToString))
                    Dim 最終小数部 As Integer = CInt(Val(gridEntry.GetData(i, GridItem.小数).ToString))

                    '数値に変更された場合、桁数減少・整数・小数点も含んで判定
                    If CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 3 Then
                        If 最終整数部 < 初期整数部 Or 最終小数部 < 初期小数部 Then
                            _属性変更フラグ = 1
                            Exit For
                        End If
                    End If

                    初期整数部 += 1 '符号分+1
                    If 初期小数部 > 0 Then
                        初期小数部 += 1 '小数点分+1
                    End If

                    '文字に変更された場合、桁数減少・符号・小数点も含んで判定
                    If CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 1 OrElse
                       CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 2 Then
                        If 最終整数部 < 初期整数部 + 初期小数部 Then
                            _属性変更フラグ = 1
                            Exit For
                        End If
                    End If

                Case 4, 5, 6    '元々の属性が日付の場合 -----------------------------------------------------------------------------------------------------
                    '未使用、参照定義コードに変更された場合
                    If CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 0 OrElse
                       CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 7 Then
                        _属性変更フラグ = 1
                        Exit For
                    End If

                    '画像、実行ファイル、ファイル、フォルダ、URL、メールアドレスに変更された場合        'A-20080709_3
                    If CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 8 OrElse
                       CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 9 OrElse
                       CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 10 OrElse
                       CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 11 OrElse
                       CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 12 OrElse
                       CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 13 Then                     'A-20080709_3
                        _属性変更フラグ = 1                                                             'A-20080709_3
                        Exit For                                                                        'A-20080709_3
                    End If                                                                              'A-20080709_3

                    '日付の形式を他の形式に変更した場合
                    If CInt(_初期属性データ.Rows(i).Item(0).ToString) = 4 AndAlso
                      (CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 5 OrElse CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 6) Then
                        _属性変更フラグ = 1
                        Exit For
                    End If
                    If CInt(_初期属性データ.Rows(i).Item(0).ToString) = 5 AndAlso
                      (CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 4 OrElse CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 6) Then
                        _属性変更フラグ = 1
                        Exit For
                    End If
                    If CInt(_初期属性データ.Rows(i).Item(0).ToString) = 6 AndAlso
                      (CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 4 OrElse CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 5) Then
                        _属性変更フラグ = 1
                        Exit For
                    End If

                    '属性が文字か数値で桁数が減少していた場合
                    If CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 1 OrElse
                       CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 2 OrElse
                       CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 3 Then
                        Dim 日付桁数 As Integer = 0
                        Select Case CInt(_初期属性データ.Rows(i).Item(0).ToString)
                            Case 4 : 日付桁数 = 8
                            Case 5 : 日付桁数 = 6
                            Case 6 : 日付桁数 = 4
                        End Select
                        If CInt(Val(gridEntry.GetData(i, GridItem.桁数).ToString)) < 日付桁数 Then
                            _属性変更フラグ = 1
                            Exit For
                        End If
                    End If

                Case 7      '元々の属性が参照定義コードの場合 -----------------------------------------------------------------------------------------------------
                    '未使用、日付に変更された場合
                    If CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 0 OrElse
                       CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 4 OrElse
                       CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 5 OrElse
                       CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 6 Then
                        _属性変更フラグ = 1
                        Exit For
                    End If

                    '画像、実行ファイル、ファイル、フォルダ、URL、メールアドレスに変更された場合        'A-20080709_3
                    If CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 8 OrElse
                       CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 9 OrElse
                       CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 10 OrElse
                       CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 11 OrElse
                       CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 12 OrElse
                       CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 13 Then                     'A-20080709_3
                        _属性変更フラグ = 1                                                             'A-20080709_3
                        Exit For                                                                        'A-20080709_3
                    End If                                                                              'A-20080709_3

                    '属性が文字で桁数が減少した場合
                    If CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 1 OrElse
                       CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 2 Then
                        If CInt(Val(gridEntry.GetData(i, GridItem.桁数).ToString)) < CInt(Val(_初期属性データ.Rows(i).Item(GridItem.桁数).ToString)) Then
                            _属性変更フラグ = 1
                            Exit For
                        End If
                    End If

                    'Select Case CInt(Val(_初期属性データ.Rows(i).Item("HANZ032003").ToString))  '元々のコード属性
                    Select Case CInt(Val(_初期属性データ.Rows(i).Item("CUSZE01004").ToString))  '元々のコード属性
                        Case 1  '元々のコード属性が数字の場合
                            '属性が数値に変更されて、かつ桁数が減少した場合
                            If CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 3 Then
                                If CInt(Val(gridEntry.GetData(i, GridItem.桁数).ToString)) < CInt(Val(_初期属性データ.Rows(i).Item(GridItem.桁数).ToString)) Then
                                    _属性変更フラグ = 1
                                    Exit For
                                End If
                            End If
                        Case 2  '元々のコード属性が文字の場合
                            '属性が数値に変更された場合
                            If CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 3 Then
                                _属性変更フラグ = 1
                                Exit For
                            End If
                    End Select

                Case 8      '元々の属性が画像の場合 ----------------------------------------------------
                    '画像以外に変更された場合                                                           
                    If CInt(gridEntry.GetData(i, GridItem.属性).ToString) <> 8 Then
                        _属性変更フラグ = 1
                        Exit For
                    End If

                    '画像で桁数が減少した場合                                                           
                    If CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 8 Then
                        If CInt(Val(gridEntry.GetData(i, GridItem.桁数).ToString)) _
                         < CInt(Val(_初期属性データ.Rows(i).Item(GridItem.桁数).ToString)) Then
                            _属性変更フラグ = 1
                            Exit For
                        End If
                    End If

                Case 9      '元々の属性が実行ファイルの場合 --------------------------------------------
                    '実行ファイル以外に変更された場合                                                   
                    If CInt(gridEntry.GetData(i, GridItem.属性).ToString) <> 9 Then
                        _属性変更フラグ = 1
                        Exit For
                    End If

                    '実行ファイルで桁数が減少した場合                                                   
                    If CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 9 Then
                        If CInt(Val(gridEntry.GetData(i, GridItem.桁数).ToString)) _
                         < CInt(Val(_初期属性データ.Rows(i).Item(GridItem.桁数).ToString)) Then
                            _属性変更フラグ = 1
                            Exit For
                        End If
                    End If

                Case 10     '元々の属性がファイルの場合 ------------------------------------------------
                    '実行ファイル以外に変更された場合                                                   
                    If CInt(gridEntry.GetData(i, GridItem.属性).ToString) <> 10 Then
                        _属性変更フラグ = 1
                        Exit For
                    End If

                    'ファイルで桁数が減少した場合                                                       
                    If CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 10 Then
                        If CInt(Val(gridEntry.GetData(i, GridItem.桁数).ToString)) _
                         < CInt(Val(_初期属性データ.Rows(i).Item(GridItem.桁数).ToString)) Then
                            _属性変更フラグ = 1
                            Exit For
                        End If
                    End If

                Case 11     '元々の属性がフォルダの場合 ------------------------------------------------
                    'フォルダ以外に変更された場合                                                       
                    If CInt(gridEntry.GetData(i, GridItem.属性).ToString) <> 11 Then
                        _属性変更フラグ = 1
                        Exit For
                    End If

                    'フォルダで桁数が減少した場合                                                       
                    If CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 11 Then
                        If CInt(Val(gridEntry.GetData(i, GridItem.桁数).ToString)) _
                         < CInt(Val(_初期属性データ.Rows(i).Item(GridItem.桁数).ToString)) Then
                            _属性変更フラグ = 1
                            Exit For
                        End If
                    End If

                Case 12     '元々の属性がURLの場合 -----------------------------------------------------
                    'URL以外に変更された場合                                                            
                    If CInt(gridEntry.GetData(i, GridItem.属性).ToString) <> 12 Then
                        _属性変更フラグ = 1
                        Exit For
                    End If

                    'URLで桁数が減少した場合                                                            
                    If CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 12 Then
                        If CInt(Val(gridEntry.GetData(i, GridItem.桁数).ToString)) _
                         < CInt(Val(_初期属性データ.Rows(i).Item(GridItem.桁数).ToString)) Then
                            _属性変更フラグ = 1
                            Exit For
                        End If
                    End If

                Case 13     '元々の属性がメールアドレスの場合 ------------------------------------------
                    'メールアドレス以外に変更された場合                                                 
                    If CInt(gridEntry.GetData(i, GridItem.属性).ToString) <> 13 Then
                        _属性変更フラグ = 1
                        Exit For
                    End If

                    'メールアドレスで桁数が減少した場合                                                 
                    If CInt(gridEntry.GetData(i, GridItem.属性).ToString) = 13 Then
                        If CInt(Val(gridEntry.GetData(i, GridItem.桁数).ToString)) _
                         < CInt(Val(_初期属性データ.Rows(i).Item(GridItem.桁数).ToString)) Then
                            _属性変更フラグ = 1
                            Exit For
                        End If
                    End If

            End Select
        Next
    End Sub

    ''' <summary>
    ''' キー項目に対する変更判定
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function IsChangedNewKey() As Boolean
        Dim isChangeKey As Boolean
        If _lastDataShurui = dataShurui.TextValue AndAlso CInt(_lastShoriMode) + 1 = shori.Value Then
            If CInt(_lastMeisaiKubun) = 0 OrElse CInt(_lastMeisaiKubun) = meisaiKubun.Value Then
                isChangeKey = False
            Else
                isChangeKey = True
            End If
        Else
            isChangeKey = True
        End If
        Return isChangeKey
    End Function

    ''' <summary>
    ''' 画面のReadOnly制御
    ''' </summary>
    ''' <remarks>キー項目と処理区分を保存</remarks>
    Public Sub SetReadOnly(ByVal isReadOnly As Boolean)
        gridEntry.DisplayOnly = isReadOnly
    End Sub

    ''' <summary>
    ''' 確定値の保存
    ''' </summary>
    ''' <remarks>キー項目と処理区分を保存</remarks>
    Public Sub SetLastParams()

        Select Case shori.Value - 1
            Case IShoriMode.処理モード区分.登録
                _lastShoriMode = IShoriMode.処理モード区分.登録
            Case IShoriMode.処理モード区分.修正
                _lastShoriMode = IShoriMode.処理モード区分.修正
            Case IShoriMode.処理モード区分.削除
                _lastShoriMode = IShoriMode.処理モード区分.削除
        End Select

        _lastDataShurui = dataShurui.TextValue
        _lastMeisaiKubun = meisaiKubun.Value
    End Sub
    Private Sub CommandView_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'RemoveHandler dataShubetu.KeyDown, AddressOf Code_KeyDown
        RemoveHandler dataShurui.InputTextControl.KeyDown, AddressOf Code_KeyDown
        RemoveHandler meisaiKubun.KeyDown, AddressOf Code_KeyDown
        'AddHandler dataShubetu.KeyDown, AddressOf Code_KeyDown
        AddHandler dataShurui.InputTextControl.KeyDown, AddressOf Code_KeyDown
        AddHandler meisaiKubun.KeyDown, AddressOf Code_KeyDown
    End Sub

    Private Sub Code_KeyDown(ByVal sender As Object, ByVal e As KeyEventArgs)
        If e.Shift = True Then Exit Sub

        Select Case e.KeyCode
            Case Keys.PageUp
                _targetControl = CType(sender, Control)
                DoPrevMethod(_targetControl)

            Case Keys.PageDown
                _targetControl = CType(sender, Control)
                DoNextMethod(_targetControl)
        End Select
    End Sub

    Private Sub CommandView_Closing(ByVal sender As Object, ByVal e As FormClosingEventArgs) Handles Me.FormClosing
        '表示ボタンが非活性の時は条件部以外にフォーカスがあるので、終了時、確認メッセージを表示する。
        If complete.Enabled = False AndAlso CheckCancelClose() = False Then
            If MyBase.MessageViewer.Show(1, IMessageViewer.DefaultButtonType.No) = IMessageViewer.ShowResultType.No Then
                e.Cancel = True
                Exit Sub
            End If
        End If
        SystemController.GetSaveInfo(SaveInfo)
    End Sub


    ''' <summary>
    ''' ガイド表示
    ''' </summary>
    ''' <param name="columnIndex"></param>
    ''' <remarks></remarks>
    Private Sub DisplayGuide(ByVal columnIndex As Integer)
        If shori.Value - 1 = IShoriMode.処理モード区分.削除 Then Exit Sub

        Select Case columnIndex
            Case GridItem.属性
                DisplayComboGuide(columnIndex)
            Case GridItem.桁数
                Select Case Val(gridEntry.GetData(gridEntry.EditRowIndex, 0).ToString)
                    Case 1, 2
                        _personalMessageViewer.Show(15, PersonalMessageViewer.MessageType.StatusBar)
                    Case 3

                        _personalMessageViewer.Show(16, PersonalMessageViewer.MessageType.StatusBar)

                    Case 4, 5, 6
                        _personalMessageViewer.Show(17, PersonalMessageViewer.MessageType.StatusBar)
                    Case 8, 9, 10, 11, 12, 13
                        _personalMessageViewer.Show(15, PersonalMessageViewer.MessageType.StatusBar)
                End Select
            Case GridItem.小数
                _personalMessageViewer.Show(3, PersonalMessageViewer.MessageType.StatusBar)
                'Case GridItem.ｶﾝﾏ編集
                '    DisplayComboGuide(columnIndex)
            Case Else

        End Select
    End Sub

    ''' <summary>
    ''' コンボボックス内容値表示
    ''' </summary>
    ''' <param name="columnIndex"></param>
    ''' <param name="removeSpace"></param>
    ''' <remarks></remarks>
    Private Sub DisplayComboGuide(ByVal columnIndex As Integer, Optional ByVal removeSpace As Boolean = False)
        Dim message As String = ""
        If gridEntry.Columns(columnIndex).ListDataCount > 0 Then
            For i As Integer = 0 To gridEntry.Columns(columnIndex).ListDataCount - 1
                If i = 8 Then
                    message &= vbCrLf
                    message = ""
                    Exit For
                End If
                If removeSpace = True Then
                    message &= gridEntry.Columns(columnIndex).ListData(i).ToString.Trim.Replace(" ", "") & "  "
                Else
                    message &= gridEntry.Columns(columnIndex).ListData(i).ToString.TrimEnd & "  "
                End If
            Next
            message = message.Replace(":", "..").TrimEnd
            statusBar.StatusLabelControl.Text = message
        End If
    End Sub

    ''' <summary>
    ''' データ取得時のRedraw制御
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetRedraw(ByVal SetRed As Boolean)

        gridEntry.Redraw = SetRed
    End Sub

#End Region

#Region "読込み処理"

    Private Function DoRead(ByRef readParamInfo As IDictionary(Of IReadParam.取得区分型, IReadParam), ByRef resultParam As IResultParam) As IDictionary(Of IReadParam.取得区分型, DataTable)

        Dim dataReader As New DataAccessorReader
        dataReader.Initialize(Me)

        Dim reader As IDataReader = DataAccessFactory(Of IDataReader).CreateInstance(Me, "DataReader")
        dataReader.SetupDataAccessor(reader)

        dataReader.SetupWaitProcessMethod(AddressOf WaitProcess)    'A-20130404_1

        _isEndFlag = False

        Dim 取得データ As IDictionary(Of IReadParam.取得区分型, DataTable) = New Dictionary(Of IReadParam.取得区分型, DataTable)
        取得データ = dataReader.GetData(readParamInfo)

        If 取得データ Is Nothing Then
            resultParam.Set結果情報("データが存在しません。")
            Return 取得データ
        End If

        Return 取得データ
    End Function


    Private Sub WaitProcess(ByVal accessorBase As DataAccessorBase)
        Do While accessorBase.GetEndFlag(accessorBase) = False
            Me.statusBar.DoProgress()
            Me.statusBar.Refresh()
        Loop
    End Sub


    ''' <summary>
    ''' データ読込み
    ''' </summary>
    ''' <remarks>条件に合ったデータを取得する</remarks>
    Private Function GetMeisaiData(ByVal データ取得型 As Integer) As Boolean
        Dim resultMitumoriParam As IResultParam = New ResultParam
        Dim paramInfo As IDictionary(Of IReadParam.取得区分型, IReadParam) = New Dictionary(Of IReadParam.取得区分型, IReadParam)
        Dim husenDataFlag As Boolean = False
        Dim zokuseiDataFlag As Boolean = False

        '属性用グリッドのデータ取得*************************************
        Dim paramInfoZokusei As IReadParam = New ReadParam
        Dim resultParam As IResultParam = New ResultParam
        paramInfoZokusei = GetReadZokuseiParam(データ取得型)
        paramInfo.Add(IReadParam.取得区分型.属性情報表示用データ取得, paramInfoZokusei)



        Dim 表示データ取得 As IDictionary(Of IReadParam.取得区分型, DataTable) = New Dictionary(Of IReadParam.取得区分型, DataTable)

        '同期型スレッドの対応{
        SetEventIssue(True, 9)

        表示データ取得 = DoRead(paramInfo, resultParam)

        取得属性データ = 表示データ取得(IReadParam.取得区分型.属性情報表示用データ取得)

        '属性のオリジナルデータを退避する。
        _初期属性データ = Nothing
        _初期属性データ = 取得属性データ.Copy

        'If paramInfo.Item(IReadParam.取得区分型.付箋売上表示用データ取得).存在チェック = True Then husenDataFlag = True

        For i As Integer = 0 To 29
            If CInt(Val(取得属性データ.Rows(i).Item("CUSZE01004").ToString)) <> 0 Then
                zokuseiDataFlag = True
                Exit For
            End If
        Next

        If shori.Value - 1 = 0 AndAlso (zokuseiDataFlag = True) Then

            gridEntry.Redraw = True

            SetEventIssue(False)
            Return False
        ElseIf shori.Value - 1 <> 0 AndAlso (zokuseiDataFlag = False) Then

            gridEntry.Redraw = True

            SetEventIssue(False)
            Return False
        End If

        Display(0, 取得属性データ)

        SetLastParams()

        SetEventIssue(False)

        If データ取得型 <> 0 Then

            dataShurui.TextValue = _bufferDataShurui
            If _bufferMeisaiKubun = 2 Then
                meisaiKubun.Value = 2
            Else
                meisaiKubun.Value = 1
            End If
            GetDataShuruiDisplayName()
        End If

        Return True
    End Function

    ''' <summary>
    ''' データテーブルの表示
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub Display(ByVal gridNamber As Integer, ByVal newEntry As DataTable)

        Select Case gridNamber
            Case 0
                gridEntry.RowCount = 0
                _gridHelper.SetDataTable(newEntry)
                For i As Integer = 0 To gridEntry.DataTable.Columns.Count - 1
                    gridEntry.DataTable.Columns(i).ReadOnly = False
                    gridEntry.DataTable.Columns(i).AllowDBNull = True
                Next
        End Select

    End Sub

    '同期型スレッドの対応
    Private Sub SetEventIssue(ByVal setSwitch As Boolean, ByVal startIssueMessageNo As Integer)
        If startIssueMessageNo > 0 Then
            MessageViewer.Show(startIssueMessageNo)
        Else
            Me.statusBar.StatusLabelControl.Text = ""
        End If

        SetEventIssue(setSwitch)
    End Sub

    '同期型スレッドの対応
    Private Sub SetEventIssue(ByVal setSwitch As Boolean)
        If setSwitch = True Then
            Me.statusBar.StartProgress()
            SetFocusSwitchEnableEvent(False)
        Else
            Me.statusBar.StopProgress()
            Me.statusBar.StatusLabelControl.Text = ""
            SetFocusSwitchEnableEvent(True)
            'System.Windows.Forms.Application.DoEvents()    'D-20130404_1
        End If
    End Sub

    Private Sub SetReadOnlyEternal()
        CType(Me, OSK.X1.Foundation.UIDesign.UserInterface.DesignFormBase).ResetManagedControls()
        CType(Me, OSK.X1.Foundation.UIDesign.UserInterface.DesignFormBase).SetReadOnlyExpand()
    End Sub

    Private Overloads Sub RestoreReadOnly()
        CType(Me, OSK.X1.Foundation.UIDesign.UserInterface.DesignFormBase).RestoreReadOnly()
    End Sub

    '同期型スレッドの対応
    Private Sub SetFormReadOnly(ByVal setSwitch As Boolean)
        FormDesignHelper.SetReadOnly(setSwitch, CType(Me, System.Windows.Forms.Form))
    End Sub

    '同期型スレッドの対応
    Private Sub SetFocusSwitchEnableEvent(ByVal setSwitch As Boolean)
        _focusSwitcher.EnableEvent(setSwitch)
    End Sub


    Private Function CreateStateClient() As IStateClient
        If _stateClient Is Nothing Then
            _stateClient = New StateClient
            _stateClient.Initialize(SettingInfo)
            _stateClient.SetProgressChangedMethod(AddressOf ProgressChanged)
            _stateClient.ViewForm = Me
        End If
        Return _stateClient
    End Function

#End Region

#Region "更新終了"

    ''' <summary>
    ''' 更新終了後に呼ばれる(処理の結果を判断する。)
    ''' </summary>
    ''' <param name="resultParam"></param>
    ''' <param name="executeCheckInfo"></param>
    ''' <remarks></remarks>
    Protected Overrides Sub CompleteUpdateImpl(ByVal resultParam As IResultParam, ByVal executeCheckInfo As IExecuteCheckInfo)

        Select Case resultParam.UpdateResult
            Case ResultType.成功
                statusBar.StatusLabelControl.Text = ""
                If Val(resultParam.ResultInfo.Item("処理件数").ToString) = 0 Then
                    MessageViewer.Show(22)
                Else
                    Dim processCount As String = " (処理件数：" & CStr(resultParam.ResultInfo.Item("処理件数")) & "件)"
                    MessageViewer.Show(8, "CMN", IMessageViewer.DefaultButtonType.OK, "", processCount, IMessageViewer.IconType.Information, IMessageViewer.StyleType.MessageBox, SettingInfo.Item("プログラム情報.名称").ToString)
                End If
                '前回確定値セット用にグリッドデータをコピーしておく
                _前回属性データ = 取得属性データ.Copy
                _executeAfter = True
                Call ClearAll()
                dataShurui.InputTextControl.Focus()

            Case ResultType.同時実行不可
                Dim dlg As New ExecuteCheckDialog
                dlg.ShowMessage(Me, executeCheckInfo)
                _executeAfter = True
                Call ClearAll()
                dataShurui.InputTextControl.Focus()

            Case ResultType.一意制約違反
                MessageViewer.Show(15, IMessageViewer.DefaultButtonType.OK, "", "")
                _executeAfter = True
                Call ClearAll()
                dataShurui.InputTextControl.Focus()

            Case ResultType.他で更新済
                Select Case resultParam.ResultInfo.Item("更新番号エラー").ToString.TrimEnd
                    Case "参照定義更新番号エラー"
                        MessageViewer.Show(2509, "HAN", IMessageViewer.DefaultButtonType.OK, "", "", IMessageViewer.IconType.Exclamation, IMessageViewer.StyleType.MessageBox, システム環境情報.プログラム情報.名称)
                    Case "メイン更新番号エラー"
                        _personalMessageViewer.Show(10, PersonalMessageViewer.MessageType.MessageBox, IMessageViewer.DefaultButtonType.OK, , , IMessageViewer.IconType.Exclamation)
                End Select
                _executeAfter = True
                Call ClearAll()
                dataShurui.InputTextControl.Focus()
            Case ResultType.レコード無し
                MessageViewer.Show(60, IMessageViewer.DefaultButtonType.OK, "", "")

            Case ResultType.想定された失敗
                statusBar.StatusLabelControl.Text = ""
                Select Case resultParam.ResultInfo.Item("想定された失敗").ToString.TrimEnd
                    Case "登録・修正モードで不整合あり"
                        Dim 不整合画面_削除以外 As WarningDeleteOtherView
                        不整合画面_削除以外 = New WarningDeleteOtherView
                        不整合画面_削除以外.InitialiseWarningDeleteView(Me)
                        不整合画面_削除以外.ShowDialog()
                        If 不整合画面_削除以外.強制実行 = 1 Then
                            Dim logInfo As ILogInfo = CommonFactory.CreateInstance(Of ILogInfo)(Me, GetType(LogInfo))
                            logInfo.処理状態 = 処理状態型.処理開始
                            logInfo.処理内容 = ""
                            logInfo.詳細情報 = GetCommandViewCondition()
                            _強制実行フラグ = 1
                            '_更新再実行フラグ = True
                            _メニューバー整合処理より実行 = False                                                'A-20110408_1
                            _実行ID枝番 = CInt(resultParam.ResultInfo.Item("実行ID枝番").ToString)
                            RaiseEventDoUpdate(GetCommandParam(), logInfo)
                            shori.Focus()
                        End If

                    Case "削除モードで不整合あり"
                        Dim 不整合画面_削除 As WarningDeleteView
                        不整合画面_削除 = New WarningDeleteView
                        不整合画面_削除.InitialiseWarningDeleteOtherView(Me)
                        不整合画面_削除.ShowDialog()
                        If 不整合画面_削除.強制実行 = 1 Then
                            Dim logInfo As ILogInfo = CommonFactory.CreateInstance(Of ILogInfo)(Me, GetType(LogInfo))
                            logInfo.処理状態 = 処理状態型.処理開始
                            logInfo.処理内容 = ""
                            logInfo.詳細情報 = GetCommandViewCondition()
                            _強制実行フラグ = 1
                            '_更新再実行フラグ = True
                            _メニューバー整合処理より実行 = False                                                'A-20110408_1
                            _実行ID枝番 = CInt(resultParam.ResultInfo.Item("実行ID枝番").ToString)
                            RaiseEventDoUpdate(GetCommandParam(), logInfo)
                            shori.Focus()
                        Else
                            SetReadOnly(True)
                        End If
                    Case Else
                End Select
                'A-20090107_1{
            Case ResultType.ロック中
                Me.MessageViewer.Show(85)
                _executeAfter = True
                Call ClearAll()
                dataShurui.InputTextControl.Focus()
                'A-20090107_1}
        End Select
    End Sub

#End Region

#Region "パラメータ"

    '''' <summary>
    '''' 属性データ取得用のパラメータ生成
    '''' </summary>
    '''' <returns></returns>
    '''' <remarks>必要なコントロール情報をセットする</remarks>
    'Private Function GetControlParam(ByVal param As IReadParam) As IReadParam
    '    CType(param, ReadParam).部門管理 = _myコントロール情報型.部門管理
    '    CType(param, ReadParam).売上処理_お届け先 = _myコントロール情報型.売上処理_お届け先
    '    CType(param, ReadParam).倉庫別在庫管理 = _myコントロール情報型.倉庫管理
    '    CType(param, ReadParam).営業所管理 = _myコントロール情報型.営業所管理

    '    CType(param, ReadParam).受発注管理 = _myコントロール情報型.受発注管理
    '    CType(param, ReadParam).見積管理 = _myコントロール情報型.見積管理
    '    CType(param, ReadParam).強化区分 = _myコントロール情報型.強化区分
    '    CType(param, ReadParam).原価管理 = _myコントロール情報型.原価管理
    '    CType(param, ReadParam).ロット管理 = _myコントロール情報型.ロット管理
    '    CType(param, ReadParam).拡張項目データリンク機能 = _myコントロール情報型.拡張項目データリンク機能
    '    CType(param, ReadParam).Is検収基準_出荷 = Is検収基準_出荷()
    '    CType(param, ReadParam).Is検収基準_入荷 = Is検収基準_入荷()
    '    CType(param, ReadParam).Is検収基準 = Is検収基準()
    '    CType(param, ReadParam).Is予定在庫区分_入出庫 = Is予定在庫区分_入出庫()
    '    Return param
    'End Function

    ''' <summary>
    ''' 属性データ取得用のパラメータ生成
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetReadZokuseiParam(ByVal データ取得型 As Integer) As IReadParam
        Dim param As IReadParam = New ReadParam
        'データ取得用パラメータ
        CType(param, ReadParam).取得区分 = IReadParam.取得区分型.属性情報表示用データ取得
        CType(param, ReadParam).処理モード = shori.Value - 1
        CType(param, ReadParam).データ種別 = 1
        If データ取得型 = 0 Then
            CType(param, ReadParam).データ種類 = CInt(Val(dataShurui.TextValue))
            CType(param, ReadParam).明細区分 = meisaiKubun.Value
        Else
            CType(param, ReadParam).データ種類 = CInt(Val(_bufferDataShurui))
            CType(param, ReadParam).明細区分 = _bufferMeisaiKubun
        End If

        CType(param, ReadParam).データ種類略称 = Getデータ種類略称(CType(param, ReadParam).データ種類.ToString("00"))

        CType(param, ReadParam).データ取得型 = データ取得型

        'GetControlParam(param)
        Return param
    End Function

    ''' <summary>
    ''' 更新用の確定値保存
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetCommandParam() As ICommandParam
        Dim param As ICommandParam = New CommandParam

        CType(param, CommandParam).項目属性LIST = New List(Of CommandParam.項目属性)
        Dim 項目属性(29) As CommandParam.項目属性

        '更新用パラメータ　更新番号
        If _changeShoriMode = True Then
            CType(param, CommandParam).処理モード = IShoriMode.処理モード区分.削除
        Else
            CType(param, CommandParam).処理モード = _lastShoriMode
        End If
        CType(param, CommandParam).データ種別名 = "取引データ"
        CType(param, CommandParam).データ種類名 = dataShurui.DispNameText

        CType(param, CommandParam).データ種類 = CInt(_lastDataShurui)

        CType(param, CommandParam).データ種類略称 = Getデータ種類略称(_lastDataShurui)

        CType(param, CommandParam).明細区分 = _lastMeisaiKubun

        CType(param, CommandParam).実行ID枝番 = 0


        'CType(param, CommandParam).強化区分 = _myコントロール情報型.強化区分
        'CType(param, CommandParam).定期取引作成 = _myコントロール情報型.定期取引作成機能

        'If _myコントロール情報型.受発注管理 = オプション区分定義型.区分型.行う Then
        '    If Val(dataShurui.TextValue) = 1 Then
        '        CType(param, CommandParam).売上受発注区分 = 1
        '    ElseIf Val(dataShurui.TextValue) = 3 Then
        '        CType(param, CommandParam).売上受発注区分 = 2

        '    ElseIf Val(dataShurui.TextValue) = 5 Then
        '        If Is予定在庫区分_入出庫() = True Then
        '            CType(param, CommandParam).売上受発注区分 = 5
        '        Else
        '            CType(param, CommandParam).売上受発注区分 = 0
        '        End If

        '    Else
        '        CType(param, CommandParam).売上受発注区分 = 0
        '    End If

        'ElseIf Is予定在庫区分_入出庫() = True Then

        '    If Val(dataShurui.TextValue) = 5 Then
        '        CType(param, CommandParam).売上受発注区分 = 5
        '    Else
        '        CType(param, CommandParam).売上受発注区分 = 0
        '    End If

        'Else
        '    CType(param, CommandParam).売上受発注区分 = 0
        'End If
        'If _myコントロール情報型.見積管理 = オプション区分定義型.区分型.行う Then
        '    If Val(dataShurui.TextValue) = 1 Then
        '        CType(param, CommandParam).売上見積区分 = 1
        '    Else
        '        CType(param, CommandParam).売上見積区分 = 0
        '    End If
        'Else
        '    CType(param, CommandParam).売上見積区分 = 0
        'End If
        'If _myコントロール情報型.強化区分 >= 3 AndAlso
        '   _myコントロール情報型.原価管理 = オプション区分定義型.区分型.行う Then
        '    If Val(dataShurui.TextValue) = 3 Then
        '        CType(param, CommandParam).仕入経費区分 = 1
        '    Else
        '        CType(param, CommandParam).仕入経費区分 = 0
        '    End If
        'Else
        '    CType(param, CommandParam).仕入経費区分 = 0
        'End If


        'If Val(dataShurui.TextValue) = 1 Then '取引データかつ売上伝票の場合
        '    If Is検収基準_出荷() = True Then
        '        CType(param, CommandParam).入出荷区分 = 1
        '    Else
        '        CType(param, CommandParam).入出荷区分 = 0
        '    End If
        'ElseIf Val(dataShurui.TextValue) = 3 Then '取引データかつ仕入伝票の場合
        '    If Is検収基準_入荷() = True Then
        '        CType(param, CommandParam).入出荷区分 = 2
        '    Else
        '        CType(param, CommandParam).入出荷区分 = 0
        '    End If
        'Else
        '    CType(param, CommandParam).入出荷区分 = 0
        'End If

        For i As Integer = 0 To 29

            項目属性(i).属性 = CInt(Val(gridEntry.GetData(i, 0).ToString))
            項目属性(i).整数部桁数 = CInt(Val(gridEntry.GetData(i, 1).ToString))
            項目属性(i).項目名 = gridEntry.GetData(i, 3).ToString.TrimEnd
            項目属性(i).小数部桁数 = CInt(Val(gridEntry.GetData(i, 2).ToString))
            If CType(param, CommandParam).処理モード = IShoriMode.処理モード区分.修正 Then
                If CInt(_初期属性データ.Rows(i).Item("CUSZE01004")) = 0 Then
                    項目属性(i).項目更新番号 = 0
                Else
                    項目属性(i).項目更新番号 = CInt(_初期属性データ.Rows(i).Item("CUSZE01999")) + 1
                End If
            ElseIf CType(param, CommandParam).処理モード = IShoriMode.処理モード区分.登録 Then
                    項目属性(i).項目更新番号 = 0
            End If
            CType(param, CommandParam).項目属性LIST.Add(項目属性(i))
        Next


        'If _myコントロール情報型.強化区分 >= 5 AndAlso
        '   _myコントロール情報型.伝票承認機能使用区分 = 伝票承認定義型.区分型.使用する Then

        '    If _myコントロール情報型.見積管理 = オプション区分定義型.区分型.行う AndAlso
        '       _myコントロール情報型.見積伝票承認使用区分 = 伝票承認定義型.区分型.使用する Then
        '        CType(param, CommandParam).販売_伝票申請承認機能_見積整合性チェック = CommandParam.整合性チェック型.行う
        '    End If

        '    If _myコントロール情報型.受発注管理 = オプション区分定義型.区分型.行う AndAlso
        '      (_myコントロール情報型.受注伝票承認使用区分 = 伝票承認定義型.区分型.使用する OrElse
        '       _myコントロール情報型.発注伝票承認使用区分 = 伝票承認定義型.区分型.使用する) Then
        '        CType(param, CommandParam).販売_伝票申請承認機能_受発注整合性チェック = CommandParam.整合性チェック型.行う
        '    End If

        'End If


        'CType(param, CommandParam).メニューバー整合処理より実行 = _メニューバー整合処理より実行
        'CType(param, CommandParam).Is受発注消費税あり = Is受発注消費税あり()

        'CType(param, CommandParam).Isスマートサーチ機能あり = Isスマートサーチ機能あり()
        'CType(param, CommandParam).Is検収＿着荷基準仕入あり = Is検収＿着荷基準仕入あり()
        'CType(param, CommandParam).Is検収＿着荷基準売上あり = Is検収＿着荷基準売上あり()
        'CType(param, CommandParam).Is予定在庫区分_入出庫 = Is予定在庫区分_入出庫()



        'CType(param, CommandParam).Is仕入データ自動入力機能あり = Is仕入データ自動入力機能あり()


        Return param
    End Function

    Private _paramInfo As IDictionary
    ''' <summary>
    ''' パラメータ情報
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overloads Property ParamInfo() As System.Collections.IDictionary
        Get
            Return _paramInfo
        End Get
        Set(ByVal value As IDictionary)
            _paramInfo = value
        End Set
    End Property

    Private WithEvents _stateClient As IStateClient
    ''' <summary>
    ''' クライアント側の状態管理
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overloads Property StateClient() As IStateClient
        Get
            Return _stateClient
        End Get
        Set(ByVal value As IStateClient)
            _stateClient = value
        End Set
    End Property

#End Region

#Region "操作ログ"

    Private Function GetCommandViewCondition() As String
        Dim result As String
        Dim logInfoHelper As ILogInfoHelper = CommonFactory.CreateInstance(Of ILogInfoHelper)(Me, GetType(LogInfoHelper))
        result = ""

        result &= logInfoHelper.MakeLog("処理", CType(shori.Value - 1, IShoriMode.処理モード区分).ToString)

        'result &= logInfoHelper.MakeLog("データ種別", "取引データ")
        result &= logInfoHelper.MakeLog("データ種類", dataShurui.DispNameText)
        If meisaiKubun.Value = 1 Then
            result &= logInfoHelper.MakeLog("明細区分", "伝票")
        Else
            result &= logInfoHelper.MakeLog("明細区分", "明細")
        End If
        'End If

        Return result
    End Function


#Region "DPI200対応"

    ''' <summary>
    ''' DPI倍率の取得
    ''' </summary>
    ''' <remarks></remarks>
    Private Function GetDPIScale() As Double

        If DPI < 100 Then
            Return 1.0
        End If

        Return (DPI / 100)
    End Function

    ''' <summary>
    ''' オリジナル値をDPI倍率で変換
    ''' </summary>
    ''' <param name="originalValue">オリジナル値</param>
    ''' <remarks></remarks>
    Private Function GetValueConvertedToDpiScale(originalValue As Integer) As Integer

        Return CInt(Math.Ceiling(originalValue * GetDPIScale()))

    End Function

    Private Sub mainPanel_Paint(sender As Object, e As PaintEventArgs) Handles mainPanel.Paint

    End Sub

#End Region


#End Region
End Class
