あなたはVB.NETおよび業務アプリケーション仕様書レビューに精通したシニアエンジニアです。
以下のソースコード群と仕様書を比較し、A00570.見積処理（FieldBuilder）のPG機能仕様書に不足している内容、不整合な内容、共通仕様書側に記載すべき内容を抽出してください。

回答は日本語で行ってください。
推測で断定しないでください。
ソース上確認できない内容は「ソース上未確認」と明記してください。
コメントアウトされている旧処理は、現行仕様として扱わないでください。
仕様書に記載すべき内容は、できるだけそのままExcelへ貼れる文言で提示してください。

# 目的

対象PG：
ProgramSource\A00570.見積処理（FieldBuilder）\Source\A00570

対象仕様書：
EO販売_3-2.(1567)見積処理（FieldBuilder)_PG機能仕様書.xlsx

関連する共通仕様書：
EO販売_3-1.共通機能仕様書_20260610_Ver20260610.xlsx

参考として確認してよい関連PG/部品：
ProgramSource\LIB.FieldBuilder\Source\LIB.FieldBuilder
EO販売_3-2.(1566)FieldBuilder_PG機能仕様書.xlsx

今回の比較では、A00570見積処理がLIB.FieldBuilderのクラス・メソッドを呼び出している可能性を前提にしてください。
そのため、A00570側に書くべき内容、LIB.FieldBuilder仕様書または共通仕様書に書くべき内容を切り分けてください。

# 対象ソース構造

## A00570.見積処理（FieldBuilder）

主な確認対象：

ProgramSource\A00570.見積処理（FieldBuilder）\Source\A00570

A00570
- A00570\A00570.vbproj
- A00570\IReadParam.vb
- A00570\Class\CommonEnums.vb
- A00570\Class\ReadParam.vb
- A00570\Class\Result.vb
- A00570\Class\UpdateParam.vb
- A00570\Class\定義情報型.vb
- A00570\Interface\IControlReader.vb
- A00570\Interface\IDenpyouReader.vb
- A00570\Interface\IDenpyouUpdater.vb
- A00570\Interface\IMasterReader.vb
- A00570\Interface\IXmlFileExist.vb

DA
- DA\Class\ControlReader.vb
- DA\Class\DenpyouReader.vb
- DA\Class\DenpyouUpdater.vb
- DA\Class\Initializer.vb
- DA\Class\MasterReader.vb
- DA\Class\ReadSQLCreator.vb
- DA\Class\UpdateSQLCreater.vb
- DA\Class\XmlFileExist.vb
- DA\Class\更新情報型.vb

UI
- UI\EntryForm.vb
- UI\PrintForm.vb
- UI\Class\ColumnInfoList.vb
- UI\Class\Controller.vb
- UI\Class\DataAccessor.vb
- UI\Class\ExpandItemHeaderColumnInfoList.vb
- UI\Class\ExpandItemMeisaiColumnInfoList.vb
- UI\Class\FocusSwitch.vb
- UI\Class\メッセージ定数型.vb
- UI\Class\伝票発行情報型.vb
- UI\Class\退避情報型.vb
- UI\GridHelper 配下
- UI\Interface\IEntryForm.vb

TestApp配下のXMLサンプルも必要に応じて参照してください。
ただし、TestAppのサンプルXMLは仕様判断の補助として扱い、現行実装の根拠は本体ソースを優先してください。

## LIB.FieldBuilder

主な確認対象：

ProgramSource\LIB.FieldBuilder\Source\LIB.FieldBuilder

LIB.FieldBuilder
- LIB.FieldBuilder\Class\ExpandItemParam.vb
- LIB.FieldBuilder\Class\FieldBuilderDataHelper.vb
- LIB.FieldBuilder\Class\FieldBuilderLayoutHelper.vb
- LIB.FieldBuilder\Class\Result.vb
- LIB.FieldBuilder\Class\UpdateParam.vb
- LIB.FieldBuilder\Interface\IControlReader.vb
- LIB.FieldBuilder\Interface\IDataReader.vb
- LIB.FieldBuilder\Interface\IDataUpdater.vb
- LIB.FieldBuilder\Interface\IResult.vb

DA
- DA\Class\ControlReader.vb
- DA\Class\DataReader.vb

UI
- UI\SubForm.vb
- UI\Class\DataAccessor.vb
- UI\Class\ExpandItemGridFunctionHelper.vb
- UI\Class\ItemWidth.vb
- UI\Class\PanelExpandItemAccessor.vb
- UI\Class\UIHelper.vb
- UI\Class\退避情報型.vb
- UI\Interface\IExpandItemAccessor.vb
- UI\Interface\ISubForm.vb

# 重点確認ポイント

## 1. A00570見積処理からLIB.FieldBuilderへの呼び出し

以下を確認してください。

- A00570からLIB.FieldBuilderのどのクラス、メソッド、インターフェースを呼び出しているか
- FieldBuilder項目定義XMLをどのタイミングで読み込むか
- 読み込むXMLファイル名、配置場所、存在確認方法
- XMLが存在しない場合の挙動
- FieldBuilder用サブ画面または入力パネルをどの画面・タイミングで表示するか
- 見積ヘッダー、見積明細、サブ明細など、どの単位でFieldBuilder項目を扱うか
- FieldBuilder項目の値を登録・修正・削除・印刷・画面表示のどこで使用するか
- FieldBuilder項目の値をDBへ保存するか、見積伝票データと紐づけるか
- LIB.FieldBuilder側で共通的に処理している内容と、A00570側で個別に処理している内容の境界

出力では、以下のように整理してください。

- A00570仕様書に記載すべき内容
- LIB.FieldBuilder仕様書に記載済みであればA00570では参照でよい内容
- 共通機能仕様書に記載すべき内容
- ソース上は存在するが仕様書に記載不要な実装詳細

## 2. 画面項目・画面レイアウト

A00570の画面項目説明と比較してください。

特に確認する項目：

- 見積ヘッダー部の通常項目
- 見積明細部の通常項目
- FieldBuilderで追加される拡張項目
- FieldBuilder項目の表示位置
- FieldBuilder項目の行位置、表示順、表示桁数の扱い
- 入力可否制御
- 必須チェック
- 桁数チェック
- 数値・日付・コード・ファイル系項目の扱い
- フォーカス制御
- Fキー・ボタン操作
- サブ画面表示
- 明細グリッドとの関係

画面レイアウト系については、共通仕様書とLIB.FieldBuilder側の実装を踏まえて、
A00570側へどこまで書くべきかを判断してください。

A00570側では、
「見積処理がどのタイミングでFieldBuilder項目を表示・入力・保存するか」
を中心に記載し、
FieldBuilder共通の配置制御、幅調整、行位置制御などは共通仕様書またはLIB.FieldBuilder仕様書参照でよいか判断してください。

## 3. 実行時チェック

A00570見積処理側のチェックと、FieldBuilder側のチェックを分けて確認してください。

確認対象：

- 通常の見積入力チェック
- FieldBuilder項目の入力チェック
- 必須チェック
- 属性別チェック
- 桁数チェック
- 小数チェック
- 日付チェック
- 参照定義コードチェック
- マスター検索・マスター取得の引数チェック
- 計算式項目の扱い
- 入力可否制御
- XMLファイル存在チェック
- XML読込失敗時の扱い
- DB更新時の排他チェック
- 更新番号チェック
- 登録・修正・削除時の整合性チェック

出力では、仕様書の「5.実行時チェック」に不足している内容をシート向けに整理してください。

## 4. 表示メッセージ

A00570側のメッセージと、LIB.FieldBuilder側のメッセージを確認してください。

確認対象：

- MessageX1OTS.xml
- MessageX1CMN.xml
- 個別メッセージ定数
- メッセージ定数型.vb
- EntryForm / Controller / DataAccessor / DA側で表示されるメッセージ
- FieldBuilder関連のエラー・警告・確認メッセージ
- XMLファイルなし
- XML読込失敗
- FieldBuilder項目入力エラー
- 登録確認
- 修正確認
- 削除確認
- 排他・他者更新
- 更新完了
- 処理失敗

仕様書の「6.表示メッセージ一覧」に不足しているメッセージがあれば、
以下の形式で出してください。

- メッセージID
- 表示タイミング
- 条件
- メッセージ内容
- 形式：MSG / STS
- アイコン：？ / ！ / 情報 / なし
- ボタン
- 初期値
- 備考
- 修正必須 or 修正推奨

ただし、流用元PGの名残で現行処理から到達しないものは「追加不要」としてください。
到達可能性が不明なものは「到達可能性未確認」としてください。

## 5. データ取得条件

A00570のデータ取得条件を確認してください。

確認対象：

- 見積ヘッダー取得
- 見積明細取得
- FieldBuilder項目値取得
- FieldBuilder XML存在確認
- マスター取得
- コード検索
- 設定値取得
- 印刷/プレビュー時の取得
- 修正時表示データ取得
- 削除時確認データ取得
- LIB.FieldBuilder側で取得しているデータ

仕様書の「14.データ取得条件」に不足しているものを抽出してください。

特に、
A00570側で取得する見積データと、
LIB.FieldBuilder側で取得するFieldBuilder定義・入力値を分けて整理してください。

## 6. テーブル更新仕様

A00570の更新仕様を確認してください。

確認対象：

- 見積ヘッダー更新
- 見積明細更新
- FieldBuilder項目値更新
- 削除時のFieldBuilder項目値削除
- 更新順序
- トランザクション範囲
- 更新番号
- 排他ロック
- XMLとの関係
- LIB.FieldBuilder側の更新処理呼び出し

仕様書の「12.テーブル更新仕様」に不足、不一致、過剰記載があれば抽出してください。

## 7. 使用テーブル一覧

A00570とLIB.FieldBuilderで実際に参照・更新するテーブルを確認してください。

以下を区別してください。

- A00570自身が直接参照・更新するテーブル
- LIB.FieldBuilder経由で参照・更新するテーブル
- 共通部品が内部的に使用するがPG仕様書には不要なテーブル
- TestAppや旧処理のみに出てくるテーブル

仕様書の「9.使用テーブル一覧」に不足があれば指摘してください。

出力形式：

- テーブルID
- テーブル名
- 参照/更新区分
- SEL/INS/UPD/DEL
- 排他ロック/更新ロック
- A00570直接利用 or LIB.FieldBuilder経由
- 仕様書への記載要否
- 根拠ファイル/メソッド

## 8. 利用部品一覧

A00570で利用している部品を確認してください。

確認対象：

- ログ出力部品
- 排他制御部品
- マスター検索部品
- 区分選択部品
- FieldBuilder部品
- 印刷部品
- 伝票更新部品
- グリッド補助部品
- XML存在確認処理
- 共通機能部品

仕様書の「10.利用部品一覧」に不足または過剰があれば指摘してください。

特にLIB.FieldBuilderは、A00570が呼び出す主要部品として記載すべきか確認してください。

## 9. 実行時処理順序

A00570の処理順を確認してください。

対象：

- 画面起動時
- 新規登録時
- 修正時
- 削除時
- 表示時
- 明細入力時
- FieldBuilder項目表示時
- FieldBuilder項目保存時
- 印刷/プレビュー時
- XML存在確認時
- エラー発生時

仕様書の「11.実行時処理順序」に不足または順序不整合があれば指摘してください。

特に、
A00570通常処理とLIB.FieldBuilder呼び出しの順序を明確にしてください。

## 10. 共通仕様書に記載すべき内容

EO販売_3-1.共通機能仕様書_20260610_Ver20260610.xlsx を読み、
FieldBuilder共通仕様として記載すべき内容を抽出してください。

特に以下を確認してください。

- FieldBuilder XMLの基本構造
- FieldBuilder項目タグの属性
- 画面表示、行位置、表示順、表示桁数の共通配置ルール
- 入力項目の幅計算
- 明細区分別の配置制御
- 親画面への埋め込み方法
- サブ画面表示方法
- FieldBuilder項目の値保持方法
- XMLが存在しない場合の共通挙動
- コード検索、マスター取得、計算式の扱い
- 項目変数 @K1 等の扱い
- 既存XMLの手修正属性の保持方針
- 呼出元処理側が実装すべき責務
- LIB.FieldBuilder側が共通で担う責務

出力では、以下の3区分で整理してください。

1. 共通仕様書へ記載すべき内容
2. LIB.FieldBuilder_PG機能仕様書へ記載すべき内容
3. A00570見積処理仕様書へ記載すべき内容

# Excel仕様書の確認対象シート

以下のシートを優先して確認してください。

## A00570仕様書
EO販売_3-2.(1567)見積処理（FieldBuilder)_PG機能仕様書.xlsx

優先確認シート：
- 1.処理概要・主要機能
- 3.画面項目説明
- 5.実行時チェック
- 6.表示メッセージ一覧
- 7.補足説明
- 8.プログラム基本情報
- 9.使用テーブル一覧
- 10.利用部品一覧
- 11.実行時処理順序
- 12.テーブル更新仕様
- 14.データ取得条件

## 共通仕様書
EO販売_3-1.共通機能仕様書_20260610_Ver20260610.xlsx

優先確認シート：
- FieldBuilder共通仕様に関係するシート
- 画面配置、入力制御、XML定義、共通部品、共通メッセージ、共通処理順序に関係するシート
- シート名が不明な場合は、全シート名を確認し、FieldBuilder関連シートを優先して読むこと

## 参考仕様書
EO販売_3-2.(1566)FieldBuilder_PG機能仕様書.xlsx

必要に応じて、LIB.FieldBuilderの仕様確認に利用してよい。
ただし、最終的な修正対象は以下とする。
- A00570見積処理仕様書
- 共通機能仕様書
- 必要に応じてLIB.FieldBuilder仕様書

# Excel読取について

.xlsxを直接読める場合は、直接読んでください。
Pythonを使用する場合は、環境に応じて利用可能なPythonを確認してください。

py / python が使用できない場合は、以下を試してください。

C:\ProgramData\chocolatey\bin\python3.13.exe

それも使えない場合は、PowerShell/.NET標準機能またはPython標準ライブラリのzipfile/xml.etree.ElementTreeで、.xlsxをZIPとして読み取ってください。

Excelが読めない場合は、読めなかった理由を明記し、必要なシート名を列挙してください。
読めないまま推測で仕様書比較を完了しないでください。

# 出力形式

以下の形式で回答してください。

## 1. 総合判定

- A00570仕様書の完成度
- ソースとの整合性
- LIB.FieldBuilder呼び出し観点の不足有無
- 共通仕様書へ移すべき内容の有無
- 重大な不整合の有無

## 2. 修正必須一覧

表形式で出してください。

列：
- 対象仕様書
- 対象シート
- 指摘No
- 指摘区分
- 現状記載
- ソース実装
- 問題点
- 修正案
- 根拠ファイル
- 根拠クラス/メソッド
- 重要度

## 3. 修正推奨一覧

表形式で出してください。

列：
- 対象仕様書
- 対象シート
- 指摘No
- 指摘区分
- 現状記載
- ソース実装
- 推奨理由
- 修正案
- 根拠ファイル
- 根拠クラス/メソッド
- 重要度

## 4. シート別レビュー結果

以下のシートごとに出してください。

- 1.処理概要・主要機能
- 3.画面項目説明
- 5.実行時チェック
- 6.表示メッセージ一覧
- 7.補足説明
- 8.プログラム基本情報
- 9.使用テーブル一覧
- 10.利用部品一覧
- 11.実行時処理順序
- 12.テーブル更新仕様
- 14.データ取得条件

各シートについて、
- 不足
- 不整合
- 過剰記載
- 修正不要
を判定してください。

## 5. A00570側に追記すべきFieldBuilder関連仕様

A00570見積処理仕様書に追記すべき内容を、Excelへ貼れる文言で出してください。

## 6. 共通仕様書へ追記すべきFieldBuilder共通仕様

共通仕様書に追記すべき内容を、Excelへ貼れる文言で出してください。

## 7. LIB.FieldBuilder仕様書に寄せるべき内容

A00570ではなく、LIB.FieldBuilder仕様書に記載すべき内容があれば出してください。

## 8. 追加確認が必要なファイル

追加で見るべきソースがあれば、以下の形式で出してください。

- ファイルパス
- 確認理由
- 確認できる内容

# 判断ルール

- ソースコードを正とする。
- 仕様書の内容とソースが矛盾する場合は「修正必須」とする。
- 仕様書にないが、外部レビューで説明が必要そうな内容は「修正推奨」とする。
- 実装詳細すぎる内容は仕様書に書かず、「記載不要」とする。
- 共通仕様として複数PGにまたがる内容は、A00570ではなく共通仕様書またはLIB.FieldBuilder仕様書へ寄せる。
- A00570固有の呼び出しタイミング、画面操作、保存タイミング、見積データとの連携はA00570仕様書に書く。
- コメントアウトされた旧処理は現行仕様に含めない。
- TestApp配下のファイルは参考扱いとし、現行本体実装の根拠にはしない。
- 不明な場合は「不明」または「ソース上未確認」と明記する。