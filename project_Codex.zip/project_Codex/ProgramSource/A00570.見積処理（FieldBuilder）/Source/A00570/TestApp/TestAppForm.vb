﻿Public Class TestAppForm

    Private _target As ILocalLoader

    Private Sub CommandButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CommandButton1.Click
        _target = Nothing

        Dim settingInfo As IDictionary = New Hashtable
        Dim paramInfo As IDictionary = New Hashtable

        SetSettingInfo(settingInfo, 構成形態型.スタンドアロン)

        'CTI連携情報の設定
        If CTI.CheckState = System.Windows.Forms.CheckState.Checked Then    'X1変換Tool-20160511
            paramInfo.Add("CTI連携", True)
            paramInfo.Add("CTI_得意先", tokCode.TextValue.TrimEnd)
        End If
        'paramInfo.Add("DENPYONO", 8)
        'paramInfo.Add("GYONO", 1)
        Dim startupLoader As New OSK.X1.Foundation.ProgramLoad.UserInterface.Loader    'X1変換Tool-20160511
        startupLoader.Run(settingInfo, paramInfo)

    End Sub

    Private Sub CommandButton2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CommandButton2.Click
        _target = Nothing

        Dim settingInfo As IDictionary = New Hashtable

        SetSettingInfo(settingInfo, 構成形態型.分散)

        Dim brokerInfo As OSK.X1.Foundation.UserInterface.BrokerInfo = New OSK.X1.Foundation.UserInterface.BrokerInfo(settingInfo)    'X1変換Tool-20160511
        brokerInfo.サーバー接続URI = "http://localhost:8181/RemotingBrokerService"
        brokerInfo.プロキシアセンブリ名 = "OSK.X1.Broker.UserInterface"    'X1変換Tool-20160511
        brokerInfo.プロキシクラス名 = "OSK.X1.Broker.UserInterface.RemotingProxyHandler"    'X1変換Tool-20160511

        Dim stateInfo As OSK.X1.Foundation.StateServerInfo = New OSK.X1.Foundation.StateServerInfo(settingInfo)    'X1変換Tool-20160511
        stateInfo.URI = "tcp://localhost:8180/RemotingStateManagerService"

        Dim paramInfo As IDictionary = New Hashtable()

        Dim startupLoader As New OSK.X1.Foundation.ProgramLoad.UserInterface.Loader    'X1変換Tool-20160511
        startupLoader.Run(settingInfo, paramInfo)

    End Sub

    Private Sub CommandButton3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CommandButton3.Click
        Dim settingInfo As IDictionary = New Hashtable
        Dim paramInfo As IDictionary = New Hashtable

        SetSettingInfo(settingInfo, 構成形態型.スタンドアロン)

        If _target Is Nothing Then
            _target = New LocalLoader
            Dim testCaller As New TestCaller
            testCaller.Initialize(settingInfo)
            _target.Startup(testCaller, "OSK.X1.OTS.A00560", 0)    'X1変換Tool-20160511
        End If

        paramInfo.Add("RENBAN", 7790)
        'paramInfo.Add("GYONO", 3)

        '出荷計上処理からのドリルダウン用
        'With paramInfo
        '    .Add("出荷売上_出荷連番", 10004)
        '    .Add("出荷売上_計上モード", 0)
        '    .Add("出荷売上_売上日付", 20111010)
        '    .Add("出荷売上_売上伝票№", 510)
        'End With
        If ddRenban.Value <> 0 Then
            paramInfo.Item("RENBAN") = ddRenban.Value
        End If
        If 削除自動実行.CheckState = Windows.Forms.CheckState.Checked Then
            paramInfo.Add("処理", "削除")

            If 画面表示.CheckState = Windows.Forms.CheckState.Checked Then
                paramInfo.Add("自動削除時_画面表示", "する")
            Else
                paramInfo.Add("自動削除時_画面表示", "しない")
            End If
            paramInfo.Add("自動削除時_ログ出力", "する")

            paramInfo.Add("与信チェック対象外", 0)
        End If

        _target.Run(paramInfo)

    End Sub

    Private Sub SetSettingInfo(ByRef settingInfoValue As IDictionary, ByVal 構成形態 As OSK.X1.Foundation.構成形態型)    'X1変換Tool-20160511
        Dim info As New SettingInfo(settingInfoValue)

        info.データベース情報.接続ID = Me.接続DB.現在表示文字
        info.データベース情報.ログ接続ID = Me.接続DB.現在表示文字
        info.データベース情報.接続ID = "cnnSQL"
        info.データベース情報.ログ接続ID = "cnnSQL"
        info.プログラム情報.ID = "OSK.X1.OTS.A00570"    'X1変換Tool-20160511
        'info.プログラム情報.枝番 = 100   'X1変換Tool-20160511
        info.プログラム情報.オリジナルID = info.プログラム情報.ID
        info.プログラム情報.実行ID = System.Guid.NewGuid.ToString()
        info.プログラム情報.名称 = "見積処理（汎用サブ対応）"
        info.プログラム情報.オリジナル名称 = "見積処理"
        info.業務情報.ID = "CUS"
        info.会社情報.名称 = "株式会社　テスト"
        info.ログオンユーザー情報.ID = "ADMINISTRATOR" 'System.Environment.UserName
        If 業務管理者.CheckState = System.Windows.Forms.CheckState.Unchecked Then    'X1変換Tool-20160511
            info.ログオンユーザー情報.業務管理者権限 = False
        Else
            info.ログオンユーザー情報.業務管理者権限 = True
        End If
        info.コンピュータ情報.名前 = System.Environment.MachineName

        info.システム構成情報.構成形態 = 構成形態
        info.システム構成情報.動作モード = 動作モード型.デバッグ

        info.プログラム制御情報.Escキー終了機能 = True
        info.プログラム制御情報.処理状況更新間隔 = 1
        info.プログラム制御情報.ウィンドウサイズ保存機能 = True
        info.プログラム制御情報.起動ログ出力 = True
        info.プログラム制御情報.会社名表示 = True

        info.プログラム制御情報.フォント変更 = True
        'info.プログラム制御情報.表示用フォント名 = "HG創英角ﾎﾟｯﾌﾟ体"
        info.プログラム制御情報.表示用フォント名 = "MS UI Gothic"
        'info.プログラム制御情報.表示用フォント名 = "ＭＳ ゴシック"
        info.プログラム制御情報.入力用フォント名 = "ＭＳ ゴシック"

        info.プログラム制御情報.日付入力スピン拡大機能 = True
        info.プログラム制御情報.ファンクションバーアイコン表示 = True
        info.プログラム制御情報.ファンクションバーサイズ拡大 = True

        info.色情報.プログラムID = info.プログラム情報.ID
        info.色情報.プログラム枝番 = info.プログラム情報.枝番
        info.色情報.業務区分 = info.業務情報.ID
        info.色情報.色パターン設定区分 = True
    End Sub

    Private Sub CheckBox1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CTI.Click
        If CTI.CheckState = System.Windows.Forms.CheckState.Checked Then    'X1変換Tool-20160511
            tokCode.Enabled = True
            CommandButton3.Enabled = False
        Else
            tokCode.Enabled = False
            CommandButton3.Enabled = True
        End If
    End Sub

    Private Sub TestAppForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        CTI.CheckState = System.Windows.Forms.CheckState.Unchecked    'X1変換Tool-20160511
        tokCode.TextValue = ""
        tokCode.Enabled = False

        Dim files As New ArrayList
        GetAllFiles("..\..\", "*dbinfo*.xml", files)

        Dim 初期表示番号 As Integer = -1
        With Me.接続DB
            With .ComboBoxControl
                .Clear()
                For i As Integer = 0 To files.Count - 1
                    .AddRow()
                    Dim fileName As String = ""
                    fileName = System.IO.Path.GetFileName(files(i).ToString)
                    fileName = fileName.Replace(".XML", "")
                    fileName = fileName.Replace(".xml", "")
                    fileName = fileName.Replace("dbinfo.", "")
                    If 初期表示番号 = -1 AndAlso fileName.Contains("SQL") Then
                        If fileName.Contains("PSQL") = False Then
                            初期表示番号 = i
                        End If
                    End If
                    .Items(.RowCount - 1) = fileName
                Next
                .DisplayRowCount = .RowCount
                .ClearSelected()
            End With
            .表示項目番号 = 初期表示番号
        End With

    End Sub

    Public Sub GetAllFiles(ByVal folder As String, ByVal searchPattern As String, ByRef files As ArrayList)
        Dim fs As String() = System.IO.Directory.GetFiles(folder, searchPattern)
        files.AddRange(fs)
    End Sub

End Class

Public Class TestCaller
    Inherits InsideJobBase
End Class
