﻿''' <summary>
''' グリッド編集補助
''' </summary>
''' <remarks></remarks>
Public Class EditManager

    Private _gridEdit As SimpleControl.GridEdit

#Region "コンストラクタ"

    Sub New(ByVal gridEdit As SimpleControl.GridEdit)
        _gridEdit = gridEdit
    End Sub

#End Region

#Region "プロパティ"

    ''' <summary>
    ''' グリッドエディット
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property GridEdit() As SimpleControl.GridEdit
        Get
            Return _gridEdit
        End Get
        Set(ByVal value As SimpleControl.GridEdit)
            _gridEdit = value
        End Set
    End Property

    Private _itemInfoList As ColumnInfoListBase
    ''' <summary>
    ''' 項目情報一覧
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property ItemInfoList() As ColumnInfoListBase
        Get
            Return _itemInfoList
        End Get
        Set(ByVal value As ColumnInfoListBase)
            _itemInfoList = value
        End Set
    End Property

#End Region

#Region "メソッド"

    ''' <summary>
    ''' グリッドエディットを初期設定する
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub SetupEdit()
        InitEdit()
    End Sub

#End Region

#Region "内部メソッド"

    ''' <summary>
    ''' グリッドの初期化
    ''' </summary>
    ''' <remarks>カラムリストからカラムを生成</remarks>
    Private Sub InitEdit()

        Dim list() As IColumnInfo
        Dim count As Integer

        list = ItemInfoList.GetItemInfoList
        count = list.Length
        GridEdit.ColumnCount = count

        For i As Integer = 0 To count - 1

            With GridEdit.Columns(i)
                .Alignment = list(i).ItemAlign
                .AlignmentHeader = list(i).TitleAlign
                .DspName = list(i).TitleName
                .Hide = list(i).Hide
                .Name = list(i).Name
                .Width = list(i).ColumnWidth

                SetupControlAttribute(list(i), GridEdit.Columns(i))

                .TabIndex = list(i).TabIndex
                If String.IsNullOrEmpty(list(i).Format) = False Then
                    .Format = list(i).Format
                End If
                .ReadOnly = Grid.Common.Boolean.False
                If .TabIndex < 0 Then
                    .BackColor = System.Drawing.SystemColors.Control
                    .ReadOnly = Grid.Common.Boolean.True
                    .EditType = GridEditType.Nothing
                End If
                If list(i).ControlKind = ControlKindType.数値 Then
                    .ZeroSaples = True
                End If
                .SortMode = GridSortMode.NotSort
                .DisplayOnly = Grid.Common.Boolean.False
                Select Case list(i).ControlKind
                    Case ControlKindType.数値
                        If .Hide = True Then
                            Exit Select
                        End If
                        If CType(.ControlAttribute, NumericalControlAttribute).TextDisplayMode = InputNumerical.TextDisplayModeType.AdjustFontWidth Then
                            If .ReadOnly = Grid.Common.Boolean.True Then
                                .ReadOnly = Grid.Common.Boolean.False
                                .DisplayOnly = Grid.Common.Boolean.True
                                .EditType = GridEditType.InputNumeric
                            End If
                        End If
                End Select
                .DispToolTipMode = OSK.X1.Foundation.Controls.Common.DispToolTipModeType.OverflowOnly  'A-CUST20260407 ツールチップ（文字見切れ時のみ表示）
            End With

        Next

    End Sub

    ''' <summary>
    ''' 各カラムのコントロール情報を設定する。
    ''' </summary>
    ''' <param name="itemInfo">カラム情報</param>
    ''' <param name="columnAttribute">カラムのコントロール情報</param>
    ''' <remarks></remarks>
    Private Sub SetupControlAttribute(ByVal itemInfo As IColumnInfo, ByRef columnAttribute As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo)

        Select Case itemInfo.ControlKind
            Case ControlKindType.状態
                SetupState(itemInfo, columnAttribute)

            Case ControlKindType.ラベル
                SetupLabelAttribute(itemInfo, columnAttribute)

            Case ControlKindType.テキスト
                SetupTextAttribute(itemInfo, columnAttribute)

            Case ControlKindType.数値
                SetupNumericalAttribute(itemInfo, columnAttribute)

            Case ControlKindType.コード
                SetupCodeAttribute(itemInfo, columnAttribute)

            Case ControlKindType.コンボボックス
                SetupComboBoxAttribute(itemInfo, columnAttribute)

            Case ControlKindType.チェックボックス
                SetupCheckBoxAttribute(itemInfo, columnAttribute)

            Case ControlKindType.コマンドボタン
                SetupCommandButtonAttribute(itemInfo, columnAttribute)

            Case ControlKindType.時間
                SetupInputTimeAttribute(itemInfo, columnAttribute)

            Case ControlKindType.設定なし
                SetupNothingAttribute(itemInfo, columnAttribute)

            Case ControlKindType.特殊日付
                SetupSpecificDateAttribute(itemInfo, columnAttribute)

            Case ControlKindType.日付
                SetupInputDateAttribute(itemInfo, columnAttribute)

        End Select

    End Sub

    ''' <summary>
    ''' テキスト列の設定を行なう
    ''' </summary>
    ''' <param name="itemInfo">カラム情報</param>
    ''' <param name="columnAttribute">カラムコントロール情報</param>
    ''' <remarks></remarks>
    Private Sub SetupTextAttribute(ByVal itemInfo As IColumnInfo, ByRef columnAttribute As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo)

        Dim settingText As SettingInputText = Nothing
        itemInfo.GetSetting(settingText)

        Dim textAttribute As New TextControlAttribute

        With textAttribute
            .Insert = settingText.Insert
            .MaxLength = settingText.MaxLength
            .MaxLengthMode = settingText.MaxLengthMode
            .ZeroFill = settingText.ZeroFill
            .ImeMode = settingText.ImeMode
            .AllCharacters = settingText.AllCharacters
            If .AllCharacters = True Then
                .InputCodeChar = True
                .InputDoubleByte = True
                .InputKana = True
                .InputUpper = True
                .InputLower = True
                .InputNumber = True
                .InputSpace = True
                .InputSymbol = True
            Else
                .InputCodeChar = settingText.InputCodeChar
                .InputDoubleByte = settingText.InputDoubleByte
                .InputKana = settingText.InputKana
                .InputUpper = settingText.InputUpper
                .InputLower = settingText.InputLower
                .InputNumber = settingText.InputNumber
                .InputSpace = settingText.InputSpace
                .InputSymbol = settingText.InputSymbol
            End If
            .FocusCaretPosition = settingText.FocusCaretPosition
            If .FocusCaretPosition = FocusCaretPosType.Right Then
                .FocusAllSelect = False
            End If
            .TextDisplayMode = settingText.TextDisplayMode
            .DispTextToolTip = settingText.DispTextToolTip
        End With

        columnAttribute.EditType = GridEditType.InputText
        columnAttribute.ColumnType = GridColumnType.Data
        columnAttribute.ControlAttribute = textAttribute

    End Sub

    ''' <summary>
    ''' コード列の設定を行なう
    ''' </summary>
    ''' <param name="itemInfo">カラム情報</param>
    ''' <param name="columnAttribute">カラムコントロール情報</param>
    ''' <remarks></remarks>
    Private Sub SetupCodeAttribute(ByVal itemInfo As IColumnInfo, ByRef columnAttribute As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo)

        Dim settingCode As SettingCode = Nothing
        itemInfo.GetSetting(settingCode)

        Dim textAttribute As New TextControlAttribute

        With textAttribute
            .MaxLength = settingCode.MaxLength
            .Insert = False
            .MaxLengthMode = OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CustomLength
            .ImeMode = settingCode.Imemode

            Select Case settingCode.InputType
                Case SettingCode.InputItemType.数値_ゼロフィルあり
                    .ZeroFill = True
                    .AllCharacters = False
                    .InputCodeChar = False
                    .InputDoubleByte = False
                    .InputKana = False
                    .InputLower = False
                    .InputNumber = True
                    .InputSpace = False
                    .InputSymbol = False
                    .InputUpper = False

                Case SettingCode.InputItemType.数値_ゼロフィルなし
                    .AllCharacters = False
                    .InputDoubleByte = False
                    .InputKana = False
                    .InputLower = False
                    .InputNumber = True
                    .InputCodeChar = False
                    .InputSpace = False
                    .InputSymbol = False
                    .InputUpper = False
                    .ZeroFill = False

                Case SettingCode.InputItemType.半角英数のみ
                    .AllCharacters = False
                    .InputDoubleByte = False
                    .InputKana = False
                    .InputLower = True
                    .InputNumber = True
                    .InputCodeChar = True
                    .InputSpace = False
                    .InputSymbol = True
                    .InputUpper = True
                    .ZeroFill = False

                Case SettingCode.InputItemType.すべての半角
                    .AllCharacters = False
                    .InputDoubleByte = False
                    .InputKana = True
                    .InputLower = True
                    .InputNumber = True
                    .InputCodeChar = True
                    .InputSpace = True
                    .InputSymbol = True
                    .InputUpper = True
                    .ZeroFill = False

            End Select

        End With

        columnAttribute.EditType = GridEditType.InputText
        columnAttribute.ColumnType = GridColumnType.Data
        columnAttribute.ControlAttribute = textAttribute

    End Sub

    ''' <summary>
    ''' 数値列の設定を行なう
    ''' </summary>
    ''' <param name="itemInfo">カラム情報</param>
    ''' <param name="columnAttribute">カラムコントロール情報</param>
    ''' <remarks></remarks>
    Private Sub SetupNumericalAttribute(ByVal itemInfo As IColumnInfo, ByRef columnAttribute As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo)

        Dim settingNumerical As SettingInputNumerical = Nothing
        itemInfo.GetSetting(settingNumerical)

        Dim numericalAttribute As New NumericalControlAttribute

        With numericalAttribute
            .AcceptMinusKey = settingNumerical.AcceptMinusKey
            .CommaDisplay = settingNumerical.CommaDisplay
            .DecimalDigits = settingNumerical.DecimalDigits
            .IntegerDigits = settingNumerical.IntegerDigits
            .PermitNull = settingNumerical.PermitNull
            .DispSpinButton = settingNumerical.DispSpinButton

            Dim keta As Decimal = CDec(New String(CChar("9"), .IntegerDigits + .DecimalDigits))
            .MaxValue = CDec(keta / 10 ^ .DecimalDigits)
            If .AcceptMinusKey = False Then
                .MinValue = 0
            Else
                .MinValue = .MaxValue * -1
            End If
            .TextDisplayMode = settingNumerical.TextDisplayMode
        End With

        columnAttribute.ControlAttribute = numericalAttribute
        columnAttribute.EditType = GridEditType.InputNumeric
        columnAttribute.ColumnType = GridColumnType.Data
        columnAttribute.Alignment = HorzAlign.Right

    End Sub

    ''' <summary>
    ''' チェックボックス列の設定を行なう
    ''' </summary>
    ''' <param name="itemInfo">カラム情報</param>
    ''' <param name="columnAttribute">カラムコントロール情報</param>
    ''' <remarks></remarks>
    Private Sub SetupCheckBoxAttribute(ByVal itemInfo As IColumnInfo, ByRef columnAttribute As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo)
        Dim settingCheck As SettingCheckBox = Nothing
        itemInfo.GetSetting(settingCheck)

        Dim checkAttribute As New CheckControlAttribute

        With checkAttribute
            .DisplayName = settingCheck.DisplayName
        End With
        columnAttribute.EditType = GridEditType.CheckBox
        columnAttribute.ColumnType = GridColumnType.Data
        columnAttribute.ControlAttribute = checkAttribute
    End Sub

    ''' <summary>
    ''' コマンドボタン列の設定を行なう
    ''' </summary>
    ''' <param name="itemInfo"></param>
    ''' <remarks></remarks>
    Private Sub SetupCommandButtonAttribute(ByVal itemInfo As IColumnInfo, ByRef columnAttribute As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo)
        columnAttribute.EditType = GridEditType.CommandButton
        columnAttribute.ColumnType = GridColumnType.Data
    End Sub

    ''' <summary>
    ''' 日付の設定を行なう
    ''' </summary>
    ''' <param name="itemInfo">カラム情報</param>
    ''' <param name="columnAttribute">カラムコントロール情報</param>
    ''' <remarks></remarks>
    Private Sub SetupInputDateAttribute(ByVal itemInfo As IColumnInfo, ByRef columnAttribute As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo)

        Dim settingDate As SettingDate = Nothing
        itemInfo.GetSetting(settingDate)

        Dim dateAttribute As New DateControlAttribute

        With dateAttribute
            .DisplayFormat = settingDate.DisplayFormat
            .DisplayItems = settingDate.DisplayItems
            .DispSpinButton = settingDate.DispSpinButton
            .Separator = settingDate.Separator
            .ZeroFill = settingDate.Zerofill
            .RemainColor = Me.GridEdit.BackColor
        End With

        columnAttribute.EditType = GridEditType.InputDate
        columnAttribute.ColumnType = GridColumnType.Data
        columnAttribute.ControlAttribute = dateAttribute

    End Sub

    ''' <summary>
    ''' 特定日付の設定を行なう
    ''' </summary>
    ''' <param name="itemInfo">カラム情報</param>
    ''' <param name="columnAttribute">カラムコントロール情報</param>
    ''' <remarks></remarks>
    Private Sub SetupSpecificDateAttribute(ByVal itemInfo As IColumnInfo, ByRef columnAttribute As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo)
        Dim settingSDate As SettingSpecificDate = Nothing
        itemInfo.GetSetting(settingSDate)

        Dim SDateAttribute As New SpecificDateControlAttribute

        With SDateAttribute
            .EraDigit = settingSDate.EraDigit
            .EraList = settingSDate.EraList
            .EraStyle = settingSDate.EraStyle
            .Separator = settingSDate.Separator
            .DispSpinButton = settingSDate.DisplaySpinButton
            .ZeroFill = settingSDate.Zerofill
            .RemainColor = Me.GridEdit.BackColor
        End With

        columnAttribute.EditType = GridEditType.SpecificDate
        columnAttribute.ColumnType = GridColumnType.Data
        columnAttribute.ControlAttribute = SDateAttribute
    End Sub

    ''' <summary>
    ''' 時刻の設定を行なう
    ''' </summary>
    ''' <param name="itemInfo">カラム情報</param>
    ''' <param name="columnAttribute">カラムコントロール情報</param>
    ''' <remarks></remarks>
    Private Sub SetupInputTimeAttribute(ByVal itemInfo As IColumnInfo, ByRef columnAttribute As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo)

        Dim settingTime As SettingTime = Nothing
        itemInfo.GetSetting(settingTime)

        Dim timeAttribute As New TimeControlAttribute

        With timeAttribute
            .DisplayItems = settingTime.DisplayItems
            .DispSpinButton = settingTime.DisplaySpinButton
            .Separator = settingTime.Separator
            .ZeroFill = settingTime.Zerofill
            .RemainColor = Me.GridEdit.BackColor
        End With

        columnAttribute.EditType = GridEditType.InputTime
        columnAttribute.ColumnType = GridColumnType.Data
        columnAttribute.ControlAttribute = timeAttribute

    End Sub

    ''' <summary>
    ''' コンボボックスの設定を行なう
    ''' </summary>
    ''' <param name="itemInfo">カラム情報</param>
    ''' <param name="columnAttribute">カラムコントロール情報</param>
    ''' <remarks></remarks>
    Private Sub SetupComboBoxAttribute(ByVal itemInfo As IColumnInfo, ByRef columnAttribute As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo)

        Dim settingComboBox As SettingComboBox = Nothing
        itemInfo.GetSetting(settingComboBox)

        Dim ComboBoxAttribute As New ComboControlAttribute
        With ComboBoxAttribute
            .Style = settingComboBox.Style
            .DisplayRowCount = settingComboBox.DisplayRowCount
        End With

        If settingComboBox.ListData.Length > 0 Then
            columnAttribute.ListData = settingComboBox.ListData
        End If

        columnAttribute.EditType = GridEditType.ComboBox
        columnAttribute.ColumnType = GridColumnType.Data
        columnAttribute.ControlAttribute = ComboBoxAttribute

    End Sub

    ''' <summary>
    ''' ラベル列の設定を行なう
    ''' </summary>
    ''' <param name="itemInfo">カラム情報</param>
    ''' <param name="columnAttribute">カラムコントロール情報</param>
    ''' <remarks></remarks>
    Private Sub SetupLabelAttribute(ByVal itemInfo As IColumnInfo, ByRef columnAttribute As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo)
        columnAttribute.EditType = GridEditType.Empty
        columnAttribute.ColumnType = GridColumnType.Data
    End Sub

    ''' <summary>
    ''' Nothing列の設定を行なう
    ''' </summary>
    ''' <param name="itemInfo">カラム情報</param>
    ''' <param name="columnAttribute">カラムコントロール情報</param>
    ''' <remarks></remarks>
    Private Sub SetupNothingAttribute(ByVal itemInfo As IColumnInfo, ByRef columnAttribute As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo)
        columnAttribute.EditType = GridEditType.Nothing
        columnAttribute.ColumnType = GridColumnType.Data
    End Sub

    ''' <summary>
    ''' 状態列の設定を行なう
    ''' </summary>
    ''' <param name="itemInfo">カラム情報</param>
    ''' <param name="columnAttribute">カラムコントロール情報</param>
    ''' <remarks></remarks>
    Private Sub SetupState(ByVal itemInfo As IColumnInfo, ByRef columnAttribute As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo)
        columnAttribute.EditType = GridEditType.Empty
        columnAttribute.ColumnType = GridColumnType.RowState
    End Sub

#End Region

End Class
