﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class EntryForm
    Inherits OSK.X1.Foundation.UIDesign.UserInterface.DesignFormBase

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim ColumnAttributeInfo1 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo2 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo3 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo4 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo5 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo6 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo7 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo8 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo9 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo10 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo11 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo12 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo13 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo14 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo15 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo16 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo17 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo18 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo19 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo20 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo21 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo22 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo23 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo24 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo25 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo26 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo27 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo28 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo29 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo30 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo31 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo32 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo33 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo34 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo35 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo36 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo37 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo38 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo39 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo40 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo41 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo42 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(EntryForm))
        Dim RowAttributeInfo1 As OSK.X1.Foundation.Controls.Grid.Common.RowAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.RowAttributeInfo()
        Dim SortRange1 As OSK.X1.Foundation.Controls.Grid.Common.SortRange = New OSK.X1.Foundation.Controls.Grid.Common.SortRange()
        Dim SortRange2 As OSK.X1.Foundation.Controls.Grid.Common.SortRange = New OSK.X1.Foundation.Controls.Grid.Common.SortRange()
        Dim Item1 As OSK.X1.Foundation.Controls.GroupOptionImpl.Item = New OSK.X1.Foundation.Controls.GroupOptionImpl.Item()
        Dim Item2 As OSK.X1.Foundation.Controls.GroupOptionImpl.Item = New OSK.X1.Foundation.Controls.GroupOptionImpl.Item()
        Dim Item3 As OSK.X1.Foundation.Controls.GroupOptionImpl.Item = New OSK.X1.Foundation.Controls.GroupOptionImpl.Item()
        Dim FunctionControlList1 As OSK.X1.Foundation.SmartControl.FunctionBar.FunctionControlList = New OSK.X1.Foundation.SmartControl.FunctionBar.FunctionControlList()
        Dim RowAttributeInfo2 As OSK.X1.Foundation.Controls.Grid.Common.RowAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.RowAttributeInfo()
        Dim SortRange3 As OSK.X1.Foundation.Controls.Grid.Common.SortRange = New OSK.X1.Foundation.Controls.Grid.Common.SortRange()
        Me.entryContainer = New System.Windows.Forms.ToolStripContainer()
        Me.StatusBar = New OSK.X1.Foundation.SmartControl.StatusBar.StatusBar(Me.components)
        Me.expandItemHeader = New OSK.X1.Foundation.SimpleControl.GridEdit(Me.components)
        Me.ExpandItemButton = New OSK.X1.Foundation.SimpleControl.CommandButton()
        Me.nohinsaki = New OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemNameAndInputName()
        Me.ArariRitulbl = New OSK.X1.Foundation.SimpleControl.Label()
        Me.ArariRitu = New OSK.X1.Foundation.SimpleControl.InputNumerical()
        Me.TotalArarilbl = New OSK.X1.Foundation.SimpleControl.Label()
        Me.TotalArari = New OSK.X1.Foundation.SimpleControl.InputNumerical()
        Me.Yuuokokigenlbl = New OSK.X1.Foundation.SimpleControl.Label()
        Me.yuukoukigen = New OSK.X1.Foundation.SimpleControl.InputText()
        Me.ShiharaiHoholbl = New OSK.X1.Foundation.SimpleControl.Label()
        Me.shiharaiHoho = New OSK.X1.Foundation.SimpleControl.InputText()
        Me.Noukilbl = New OSK.X1.Foundation.SimpleControl.Label()
        Me.nouki = New OSK.X1.Foundation.SimpleControl.InputText()
        Me.Youkenlbl = New OSK.X1.Foundation.SimpleControl.Label()
        Me.youken = New OSK.X1.Foundation.SimpleControl.InputText()
        Me.CloseButton = New OSK.X1.Foundation.SimpleControl.CommandButton()
        Me.Kakutei = New OSK.X1.Foundation.SimpleControl.CommandButton()
        Me.printModeLabel = New OSK.X1.Foundation.SimpleControl.Label()
        Me.RowStatelbl = New OSK.X1.Foundation.SimpleControl.Label()
        Me.Bikolbl = New OSK.X1.Foundation.SimpleControl.Label()
        Me.Syouhizeilbl = New OSK.X1.Foundation.SimpleControl.Label()
        Me.Syouhizeigaku = New OSK.X1.Foundation.SimpleControl.InputNumerical()
        Me.TaisyoKingakulbl = New OSK.X1.Foundation.SimpleControl.Label()
        Me.TaisyoKingaku = New OSK.X1.Foundation.SimpleControl.InputNumerical()
        Me.ZensyaGenzaikolbl = New OSK.X1.Foundation.SimpleControl.Label()
        Me.ZensyaGenzaiko = New OSK.X1.Foundation.SimpleControl.InputNumerical()
        Me.SokoGenzaikolbl = New OSK.X1.Foundation.SimpleControl.Label()
        Me.SokoGenzaiko = New OSK.X1.Foundation.SimpleControl.InputNumerical()
        Me.ShouhizeiCode = New OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemNameAndInputName()
        Me.bumon = New OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemNameAndInputName()
        Me.tantousha = New OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemNameAndInputName()
        Me.taxRate = New OSK.X1.Foundation.SmartControl.InputTextWithItemName.ComboBoxWithItemName()
        Me.DetailGridView = New OSK.X1.Foundation.SimpleControl.GridView(Me.components)
        Me.TotalKingakulbl = New OSK.X1.Foundation.SimpleControl.Label()
        Me.totalKingaku = New OSK.X1.Foundation.SimpleControl.InputNumerical()
        Me.denpyouDate = New OSK.X1.Foundation.SimpleControl.InputDate()
        Me.biko = New OSK.X1.Foundation.SimpleControl.InputText()
        Me.execute = New OSK.X1.Foundation.SimpleControl.CommandButton()
        Me.shoriModeLabel = New OSK.X1.Foundation.SimpleControl.Label()
        Me.TokuisakiName2 = New OSK.X1.Foundation.SimpleControl.InputText()
        Me.TokuisakiName1 = New OSK.X1.Foundation.SimpleControl.InputText()
        Me.TokuisakiCode = New OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemName()
        Me.headerPanel = New OSK.X1.Foundation.SimpleControl.Panel(Me.components)
        Me.display = New OSK.X1.Foundation.SimpleControl.CommandButton()
        Me.shoriRenban = New OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputNumericalWithItemName()
        Me.shori = New OSK.X1.Foundation.SimpleControl.GroupOption()
        Me.functionBar = New OSK.X1.Foundation.SmartControl.FunctionBar.FunctionBar()
        Me.DetailGridEdit = New OSK.X1.Foundation.SimpleControl.GridEdit(Me.components)
        Me.MenuBar = New OSK.X1.Foundation.SmartControl.MenuBar.MenuBar(Me.components)
        Me.endMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.pageMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.printMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.entryContainer.BottomToolStripPanel.SuspendLayout()
        Me.entryContainer.ContentPanel.SuspendLayout()
        Me.entryContainer.TopToolStripPanel.SuspendLayout()
        Me.entryContainer.SuspendLayout()
        Me.headerPanel.SuspendLayout()
        Me.MenuBar.SuspendLayout()
        Me.SuspendLayout()
        '
        'entryContainer
        '
        '
        'entryContainer.BottomToolStripPanel
        '
        Me.entryContainer.BottomToolStripPanel.Controls.Add(Me.StatusBar)
        '
        'entryContainer.ContentPanel
        '
        Me.entryContainer.ContentPanel.BackColor = System.Drawing.Color.Transparent
        Me.entryContainer.ContentPanel.Controls.Add(Me.expandItemHeader)
        Me.entryContainer.ContentPanel.Controls.Add(Me.ExpandItemButton)
        Me.entryContainer.ContentPanel.Controls.Add(Me.nohinsaki)
        Me.entryContainer.ContentPanel.Controls.Add(Me.ArariRitulbl)
        Me.entryContainer.ContentPanel.Controls.Add(Me.ArariRitu)
        Me.entryContainer.ContentPanel.Controls.Add(Me.TotalArarilbl)
        Me.entryContainer.ContentPanel.Controls.Add(Me.TotalArari)
        Me.entryContainer.ContentPanel.Controls.Add(Me.Yuuokokigenlbl)
        Me.entryContainer.ContentPanel.Controls.Add(Me.yuukoukigen)
        Me.entryContainer.ContentPanel.Controls.Add(Me.ShiharaiHoholbl)
        Me.entryContainer.ContentPanel.Controls.Add(Me.shiharaiHoho)
        Me.entryContainer.ContentPanel.Controls.Add(Me.Noukilbl)
        Me.entryContainer.ContentPanel.Controls.Add(Me.nouki)
        Me.entryContainer.ContentPanel.Controls.Add(Me.Youkenlbl)
        Me.entryContainer.ContentPanel.Controls.Add(Me.youken)
        Me.entryContainer.ContentPanel.Controls.Add(Me.CloseButton)
        Me.entryContainer.ContentPanel.Controls.Add(Me.Kakutei)
        Me.entryContainer.ContentPanel.Controls.Add(Me.printModeLabel)
        Me.entryContainer.ContentPanel.Controls.Add(Me.RowStatelbl)
        Me.entryContainer.ContentPanel.Controls.Add(Me.Bikolbl)
        Me.entryContainer.ContentPanel.Controls.Add(Me.Syouhizeilbl)
        Me.entryContainer.ContentPanel.Controls.Add(Me.Syouhizeigaku)
        Me.entryContainer.ContentPanel.Controls.Add(Me.TaisyoKingakulbl)
        Me.entryContainer.ContentPanel.Controls.Add(Me.TaisyoKingaku)
        Me.entryContainer.ContentPanel.Controls.Add(Me.ZensyaGenzaikolbl)
        Me.entryContainer.ContentPanel.Controls.Add(Me.ZensyaGenzaiko)
        Me.entryContainer.ContentPanel.Controls.Add(Me.SokoGenzaikolbl)
        Me.entryContainer.ContentPanel.Controls.Add(Me.SokoGenzaiko)
        Me.entryContainer.ContentPanel.Controls.Add(Me.ShouhizeiCode)
        Me.entryContainer.ContentPanel.Controls.Add(Me.bumon)
        Me.entryContainer.ContentPanel.Controls.Add(Me.tantousha)
        Me.entryContainer.ContentPanel.Controls.Add(Me.taxRate)
        Me.entryContainer.ContentPanel.Controls.Add(Me.DetailGridView)
        Me.entryContainer.ContentPanel.Controls.Add(Me.TotalKingakulbl)
        Me.entryContainer.ContentPanel.Controls.Add(Me.totalKingaku)
        Me.entryContainer.ContentPanel.Controls.Add(Me.denpyouDate)
        Me.entryContainer.ContentPanel.Controls.Add(Me.biko)
        Me.entryContainer.ContentPanel.Controls.Add(Me.execute)
        Me.entryContainer.ContentPanel.Controls.Add(Me.shoriModeLabel)
        Me.entryContainer.ContentPanel.Controls.Add(Me.TokuisakiName2)
        Me.entryContainer.ContentPanel.Controls.Add(Me.TokuisakiName1)
        Me.entryContainer.ContentPanel.Controls.Add(Me.TokuisakiCode)
        Me.entryContainer.ContentPanel.Controls.Add(Me.headerPanel)
        Me.entryContainer.ContentPanel.Controls.Add(Me.functionBar)
        Me.entryContainer.ContentPanel.Controls.Add(Me.DetailGridEdit)
        Me.entryContainer.ContentPanel.Size = New System.Drawing.Size(1184, 646)
        Me.entryContainer.Dock = System.Windows.Forms.DockStyle.Fill
        Me.entryContainer.LeftToolStripPanelVisible = False
        Me.entryContainer.Location = New System.Drawing.Point(0, 0)
        Me.entryContainer.Name = "entryContainer"
        Me.entryContainer.RightToolStripPanelVisible = False
        Me.entryContainer.Size = New System.Drawing.Size(1184, 692)
        Me.entryContainer.TabIndex = 0
        Me.entryContainer.Text = "ToolStripContainer1"
        '
        'entryContainer.TopToolStripPanel
        '
        Me.entryContainer.TopToolStripPanel.Controls.Add(Me.MenuBar)
        '
        'StatusBar
        '
        Me.StatusBar.AutoGuideMessageClearFlag = False
        Me.StatusBar.Dock = System.Windows.Forms.DockStyle.None
        Me.StatusBar.Location = New System.Drawing.Point(0, 0)
        Me.StatusBar.MarqueeAnimationSpeed = 100
        Me.StatusBar.Name = "StatusBar"
        Me.StatusBar.ProgressStep = 5
        Me.StatusBar.ProgressStyle = System.Windows.Forms.ProgressBarStyle.Blocks
        Me.StatusBar.Size = New System.Drawing.Size(1184, 22)
        Me.StatusBar.SizingGrip = False
        Me.StatusBar.StatusContainer = Me.entryContainer
        Me.StatusBar.TabIndex = 0
        Me.StatusBar.Tag = "@Exception@"
        Me.StatusBar.Text = "StatusBar1"
        '
        'expandItemHeader
        '
        Me.expandItemHeader.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.expandItemHeader.BackColorSpace = System.Drawing.SystemColors.Control
        Me.expandItemHeader.ButtonBackColor = System.Drawing.Color.Empty
        Me.expandItemHeader.ButtonForeColor = System.Drawing.Color.Empty
        Me.expandItemHeader.ColumnCount = 42
        ColumnAttributeInfo1.DispToolTipMode = Nothing
        ColumnAttributeInfo1.ImageAlignment = Nothing
        ColumnAttributeInfo1.ImageDisplayMode = Nothing
        ColumnAttributeInfo2.DispToolTipMode = Nothing
        ColumnAttributeInfo2.ImageAlignment = Nothing
        ColumnAttributeInfo2.ImageDisplayMode = Nothing
        ColumnAttributeInfo2.TabIndex = 1
        ColumnAttributeInfo3.DispToolTipMode = Nothing
        ColumnAttributeInfo3.ImageAlignment = Nothing
        ColumnAttributeInfo3.ImageDisplayMode = Nothing
        ColumnAttributeInfo3.TabIndex = 2
        ColumnAttributeInfo4.DispToolTipMode = Nothing
        ColumnAttributeInfo4.ImageAlignment = Nothing
        ColumnAttributeInfo4.ImageDisplayMode = Nothing
        ColumnAttributeInfo4.TabIndex = 3
        ColumnAttributeInfo5.DispToolTipMode = Nothing
        ColumnAttributeInfo5.ImageAlignment = Nothing
        ColumnAttributeInfo5.ImageDisplayMode = Nothing
        ColumnAttributeInfo5.TabIndex = 4
        ColumnAttributeInfo6.DispToolTipMode = Nothing
        ColumnAttributeInfo6.ImageAlignment = Nothing
        ColumnAttributeInfo6.ImageDisplayMode = Nothing
        ColumnAttributeInfo6.TabIndex = 5
        ColumnAttributeInfo7.DispToolTipMode = Nothing
        ColumnAttributeInfo7.ImageAlignment = Nothing
        ColumnAttributeInfo7.ImageDisplayMode = Nothing
        ColumnAttributeInfo7.TabIndex = 6
        ColumnAttributeInfo8.DispToolTipMode = Nothing
        ColumnAttributeInfo8.ImageAlignment = Nothing
        ColumnAttributeInfo8.ImageDisplayMode = Nothing
        ColumnAttributeInfo8.TabIndex = 7
        ColumnAttributeInfo9.DispToolTipMode = Nothing
        ColumnAttributeInfo9.ImageAlignment = Nothing
        ColumnAttributeInfo9.ImageDisplayMode = Nothing
        ColumnAttributeInfo9.TabIndex = 8
        ColumnAttributeInfo10.DispToolTipMode = Nothing
        ColumnAttributeInfo10.ImageAlignment = Nothing
        ColumnAttributeInfo10.ImageDisplayMode = Nothing
        ColumnAttributeInfo10.TabIndex = 9
        ColumnAttributeInfo11.DispToolTipMode = Nothing
        ColumnAttributeInfo11.ImageAlignment = Nothing
        ColumnAttributeInfo11.ImageDisplayMode = Nothing
        ColumnAttributeInfo11.TabIndex = 10
        ColumnAttributeInfo12.DispToolTipMode = Nothing
        ColumnAttributeInfo12.ImageAlignment = Nothing
        ColumnAttributeInfo12.ImageDisplayMode = Nothing
        ColumnAttributeInfo12.TabIndex = 11
        ColumnAttributeInfo13.DispToolTipMode = Nothing
        ColumnAttributeInfo13.ImageAlignment = Nothing
        ColumnAttributeInfo13.ImageDisplayMode = Nothing
        ColumnAttributeInfo13.TabIndex = 12
        ColumnAttributeInfo14.DispToolTipMode = Nothing
        ColumnAttributeInfo14.ImageAlignment = Nothing
        ColumnAttributeInfo14.ImageDisplayMode = Nothing
        ColumnAttributeInfo14.TabIndex = 13
        ColumnAttributeInfo15.DispToolTipMode = Nothing
        ColumnAttributeInfo15.ImageAlignment = Nothing
        ColumnAttributeInfo15.ImageDisplayMode = Nothing
        ColumnAttributeInfo15.TabIndex = 14
        ColumnAttributeInfo16.DispToolTipMode = Nothing
        ColumnAttributeInfo16.ImageAlignment = Nothing
        ColumnAttributeInfo16.ImageDisplayMode = Nothing
        ColumnAttributeInfo16.TabIndex = 15
        ColumnAttributeInfo17.DispToolTipMode = Nothing
        ColumnAttributeInfo17.ImageAlignment = Nothing
        ColumnAttributeInfo17.ImageDisplayMode = Nothing
        ColumnAttributeInfo17.TabIndex = 16
        ColumnAttributeInfo18.DispToolTipMode = Nothing
        ColumnAttributeInfo18.ImageAlignment = Nothing
        ColumnAttributeInfo18.ImageDisplayMode = Nothing
        ColumnAttributeInfo18.TabIndex = 17
        ColumnAttributeInfo19.DispToolTipMode = Nothing
        ColumnAttributeInfo19.ImageAlignment = Nothing
        ColumnAttributeInfo19.ImageDisplayMode = Nothing
        ColumnAttributeInfo19.TabIndex = 18
        ColumnAttributeInfo20.DispToolTipMode = Nothing
        ColumnAttributeInfo20.ImageAlignment = Nothing
        ColumnAttributeInfo20.ImageDisplayMode = Nothing
        ColumnAttributeInfo20.TabIndex = 19
        ColumnAttributeInfo21.DispToolTipMode = Nothing
        ColumnAttributeInfo21.ImageAlignment = Nothing
        ColumnAttributeInfo21.ImageDisplayMode = Nothing
        ColumnAttributeInfo21.TabIndex = 20
        ColumnAttributeInfo22.DispToolTipMode = Nothing
        ColumnAttributeInfo22.ImageAlignment = Nothing
        ColumnAttributeInfo22.ImageDisplayMode = Nothing
        ColumnAttributeInfo22.TabIndex = 21
        ColumnAttributeInfo23.DispToolTipMode = Nothing
        ColumnAttributeInfo23.ImageAlignment = Nothing
        ColumnAttributeInfo23.ImageDisplayMode = Nothing
        ColumnAttributeInfo23.TabIndex = 22
        ColumnAttributeInfo24.DispToolTipMode = Nothing
        ColumnAttributeInfo24.ImageAlignment = Nothing
        ColumnAttributeInfo24.ImageDisplayMode = Nothing
        ColumnAttributeInfo24.TabIndex = 23
        ColumnAttributeInfo25.DispToolTipMode = Nothing
        ColumnAttributeInfo25.ImageAlignment = Nothing
        ColumnAttributeInfo25.ImageDisplayMode = Nothing
        ColumnAttributeInfo25.TabIndex = 24
        ColumnAttributeInfo26.DispToolTipMode = Nothing
        ColumnAttributeInfo26.ImageAlignment = Nothing
        ColumnAttributeInfo26.ImageDisplayMode = Nothing
        ColumnAttributeInfo26.TabIndex = 25
        ColumnAttributeInfo27.DispToolTipMode = Nothing
        ColumnAttributeInfo27.ImageAlignment = Nothing
        ColumnAttributeInfo27.ImageDisplayMode = Nothing
        ColumnAttributeInfo27.TabIndex = 26
        ColumnAttributeInfo28.DispToolTipMode = Nothing
        ColumnAttributeInfo28.ImageAlignment = Nothing
        ColumnAttributeInfo28.ImageDisplayMode = Nothing
        ColumnAttributeInfo28.TabIndex = 27
        ColumnAttributeInfo29.DispToolTipMode = Nothing
        ColumnAttributeInfo29.ImageAlignment = Nothing
        ColumnAttributeInfo29.ImageDisplayMode = Nothing
        ColumnAttributeInfo29.TabIndex = 28
        ColumnAttributeInfo30.DispToolTipMode = Nothing
        ColumnAttributeInfo30.ImageAlignment = Nothing
        ColumnAttributeInfo30.ImageDisplayMode = Nothing
        ColumnAttributeInfo30.TabIndex = 29
        ColumnAttributeInfo31.DispToolTipMode = Nothing
        ColumnAttributeInfo31.ImageAlignment = Nothing
        ColumnAttributeInfo31.ImageDisplayMode = Nothing
        ColumnAttributeInfo31.TabIndex = 30
        ColumnAttributeInfo32.DispToolTipMode = Nothing
        ColumnAttributeInfo32.ImageAlignment = Nothing
        ColumnAttributeInfo32.ImageDisplayMode = Nothing
        ColumnAttributeInfo32.TabIndex = 31
        ColumnAttributeInfo33.DispToolTipMode = Nothing
        ColumnAttributeInfo33.ImageAlignment = Nothing
        ColumnAttributeInfo33.ImageDisplayMode = Nothing
        ColumnAttributeInfo33.TabIndex = 32
        ColumnAttributeInfo34.DispToolTipMode = Nothing
        ColumnAttributeInfo34.ImageAlignment = Nothing
        ColumnAttributeInfo34.ImageDisplayMode = Nothing
        ColumnAttributeInfo34.TabIndex = 33
        ColumnAttributeInfo35.DispToolTipMode = Nothing
        ColumnAttributeInfo35.ImageAlignment = Nothing
        ColumnAttributeInfo35.ImageDisplayMode = Nothing
        ColumnAttributeInfo35.TabIndex = 34
        ColumnAttributeInfo36.DispToolTipMode = Nothing
        ColumnAttributeInfo36.ImageAlignment = Nothing
        ColumnAttributeInfo36.ImageDisplayMode = Nothing
        ColumnAttributeInfo36.TabIndex = 35
        ColumnAttributeInfo37.DispToolTipMode = Nothing
        ColumnAttributeInfo37.ImageAlignment = Nothing
        ColumnAttributeInfo37.ImageDisplayMode = Nothing
        ColumnAttributeInfo37.TabIndex = 36
        ColumnAttributeInfo38.DispToolTipMode = Nothing
        ColumnAttributeInfo38.ImageAlignment = Nothing
        ColumnAttributeInfo38.ImageDisplayMode = Nothing
        ColumnAttributeInfo38.TabIndex = 37
        ColumnAttributeInfo39.DispToolTipMode = Nothing
        ColumnAttributeInfo39.ImageAlignment = Nothing
        ColumnAttributeInfo39.ImageDisplayMode = Nothing
        ColumnAttributeInfo39.TabIndex = 38
        ColumnAttributeInfo40.DispToolTipMode = Nothing
        ColumnAttributeInfo40.ImageAlignment = Nothing
        ColumnAttributeInfo40.ImageDisplayMode = Nothing
        ColumnAttributeInfo40.TabIndex = 39
        ColumnAttributeInfo41.DispToolTipMode = Nothing
        ColumnAttributeInfo41.ImageAlignment = Nothing
        ColumnAttributeInfo41.ImageDisplayMode = Nothing
        ColumnAttributeInfo41.TabIndex = 40
        ColumnAttributeInfo42.DispToolTipMode = Nothing
        ColumnAttributeInfo42.ImageAlignment = Nothing
        ColumnAttributeInfo42.ImageDisplayMode = Nothing
        ColumnAttributeInfo42.TabIndex = 41
        Me.expandItemHeader.Columns.AddRange(New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo() {ColumnAttributeInfo1, ColumnAttributeInfo2, ColumnAttributeInfo3, ColumnAttributeInfo4, ColumnAttributeInfo5, ColumnAttributeInfo6, ColumnAttributeInfo7, ColumnAttributeInfo8, ColumnAttributeInfo9, ColumnAttributeInfo10, ColumnAttributeInfo11, ColumnAttributeInfo12, ColumnAttributeInfo13, ColumnAttributeInfo14, ColumnAttributeInfo15, ColumnAttributeInfo16, ColumnAttributeInfo17, ColumnAttributeInfo18, ColumnAttributeInfo19, ColumnAttributeInfo20, ColumnAttributeInfo21, ColumnAttributeInfo22, ColumnAttributeInfo23, ColumnAttributeInfo24, ColumnAttributeInfo25, ColumnAttributeInfo26, ColumnAttributeInfo27, ColumnAttributeInfo28, ColumnAttributeInfo29, ColumnAttributeInfo30, ColumnAttributeInfo31, ColumnAttributeInfo32, ColumnAttributeInfo33, ColumnAttributeInfo34, ColumnAttributeInfo35, ColumnAttributeInfo36, ColumnAttributeInfo37, ColumnAttributeInfo38, ColumnAttributeInfo39, ColumnAttributeInfo40, ColumnAttributeInfo41, ColumnAttributeInfo42})
        Me.expandItemHeader.FocusEditPosition = 1
        Me.expandItemHeader.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.expandItemHeader.HeaderAreaBorderHeight = 1
        Me.expandItemHeader.KeyDownButtonBackColor = System.Drawing.Color.Empty
        Me.expandItemHeader.Location = New System.Drawing.Point(9, 171)
        Me.expandItemHeader.MoveDirectionOnUpKey = OSK.X1.Foundation.Controls.Grid.Edit.MoveDirectionOnUp.Left
        Me.expandItemHeader.Name = "expandItemHeader"
        Me.expandItemHeader.PrevByLeftKey = True
        Me.expandItemHeader.RecordBorderColor = System.Drawing.SystemColors.ControlDarkDark
        Me.expandItemHeader.RecordBorderHeight = 1
        Me.expandItemHeader.RowCount = 1
        RowAttributeInfo1.DispToolTipMode = Nothing
        RowAttributeInfo1.ImageAlignment = Nothing
        RowAttributeInfo1.ImageDisplayMode = Nothing
        RowAttributeInfo1.ImagePath = Nothing
        Me.expandItemHeader.Rows.AddRange(New OSK.X1.Foundation.Controls.Grid.Common.RowAttributeInfo() {RowAttributeInfo1})
        Me.expandItemHeader.Size = New System.Drawing.Size(1170, 68)
        Me.expandItemHeader.SortRange = SortRange1
        Me.expandItemHeader.TabIndex = 19
        Me.expandItemHeader.Text = "GridEdit1"
        Me.expandItemHeader.UseToolTip = True
        '
        'ExpandItemButton
        '
        Me.ExpandItemButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ExpandItemButton.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.ExpandItemButton.FocusBackColor = System.Drawing.Color.Empty
        Me.ExpandItemButton.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.ExpandItemButton.Image = Nothing
        Me.ExpandItemButton.Location = New System.Drawing.Point(1145, 150)
        Me.ExpandItemButton.Name = "ExpandItemButton"
        Me.ExpandItemButton.NextByEnterKey = False
        Me.ExpandItemButton.RemarkString = Nothing
        Me.ExpandItemButton.Size = New System.Drawing.Size(33, 18)
        Me.ExpandItemButton.TabIndex = 18
        Me.ExpandItemButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'nohinsaki
        '
        Me.nohinsaki.AllowBottomPosition = True
        Me.nohinsaki.AutoResizeDispName = True
        Me.nohinsaki.AutoResizeInputControl = True
        Me.nohinsaki.BackColor = System.Drawing.Color.Transparent
        Me.nohinsaki.DispNameAreaHeight = 19
        Me.nohinsaki.DispNameAreaWidth = 345
        Me.nohinsaki.DispNameBorderColor = System.Drawing.SystemColors.Window
        Me.nohinsaki.DispNameBorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.nohinsaki.DispNameSpace = 3
        Me.nohinsaki.DispNameText = "X-----------------( 4 8 )---------------------X"
        Me.nohinsaki.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.nohinsaki.GroupNo = 0
        Me.nohinsaki.Indent = 0
        Me.nohinsaki.InnerSpace = 3
        Me.nohinsaki.InputAreaFont = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.nohinsaki.InputControlReadOnly = False
        Me.nohinsaki.InputControlSize = New System.Drawing.Size(51, 19)
        Me.nohinsaki.InputTextImeMode = OSK.X1.Foundation.Controls.InputText.ImeModeType.NoControl
        Me.nohinsaki.InputType = OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemNameAndInputName.InputModeType.全文字入力可
        Me.nohinsaki.ItemName = "納品先"
        Me.nohinsaki.ItemNameAreaHeight = 19
        Me.nohinsaki.ItemNameAreaWidth = 50
        Me.nohinsaki.ItemNameBorderColor = System.Drawing.SystemColors.Window
        Me.nohinsaki.ItemNameBorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.nohinsaki.ItemNameFont = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.nohinsaki.ItemNameTextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Equal
        Me.nohinsaki.Location = New System.Drawing.Point(12, 149)
        Me.nohinsaki.Margin = New System.Windows.Forms.Padding(0)
        Me.nohinsaki.MaxLength = 6
        Me.nohinsaki.MaxLengthMode = OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CharCount
        Me.nohinsaki.Name = "nohinsaki"
        Me.nohinsaki.RemarkString = Nothing
        Me.nohinsaki.Size = New System.Drawing.Size(452, 19)
        Me.nohinsaki.SubGroupNo = 0
        Me.nohinsaki.TabIndex = 12
        Me.nohinsaki.TextValue = "123456"
        Me.nohinsaki.ZeroFill = False
        Me.nohinsaki.ZeroFillAlways = False
        '
        'ArariRitulbl
        '
        Me.ArariRitulbl.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.ArariRitulbl.BorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.ArariRitulbl.Font = New System.Drawing.Font("MS UI Gothic", 10.5!)
        Me.ArariRitulbl.Location = New System.Drawing.Point(616, 542)
        Me.ArariRitulbl.Name = "ArariRitulbl"
        Me.ArariRitulbl.Size = New System.Drawing.Size(65, 19)
        Me.ArariRitulbl.TabIndex = 1032
        Me.ArariRitulbl.Text = "粗利率"
        Me.ArariRitulbl.TextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Center
        '
        'ArariRitu
        '
        Me.ArariRitu.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.ArariRitu.BackColor = System.Drawing.SystemColors.Control
        Me.ArariRitu.BorderColor = System.Drawing.SystemColors.Window
        Me.ArariRitu.BorderStyle = OSK.X1.Foundation.Controls.Common.InputControl.BorderStyleType.Narrow
        Me.ArariRitu.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.ArariRitu.DecimalDigits = 1
        Me.ArariRitu.FocusBackColor = System.Drawing.Color.Empty
        Me.ArariRitu.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.ArariRitu.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ArariRitu.IntegerDigits = 4
        Me.ArariRitu.KeyDownButtonBackColor = System.Drawing.Color.Empty
        Me.ArariRitu.Location = New System.Drawing.Point(616, 563)
        Me.ArariRitu.MinusColor = System.Drawing.SystemColors.ControlText
        Me.ArariRitu.Name = "ArariRitu"
        Me.ArariRitu.ReadOnly = True
        Me.ArariRitu.RemarkString = Nothing
        Me.ArariRitu.Size = New System.Drawing.Size(65, 19)
        Me.ArariRitu.TabIndex = 1031
        Me.ArariRitu.TabStop = False
        Me.ArariRitu.Tag = "@OArea@"
        Me.ArariRitu.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ArariRitu.Value = New Decimal(New Integer() {1234, 0, 0, -2147418112})
        Me.ArariRitu.ZeroDisplay = False
        '
        'TotalArarilbl
        '
        Me.TotalArarilbl.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.TotalArarilbl.BorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.TotalArarilbl.Font = New System.Drawing.Font("MS UI Gothic", 10.5!)
        Me.TotalArarilbl.Location = New System.Drawing.Point(488, 542)
        Me.TotalArarilbl.Name = "TotalArarilbl"
        Me.TotalArarilbl.Size = New System.Drawing.Size(125, 19)
        Me.TotalArarilbl.TabIndex = 1030
        Me.TotalArarilbl.Text = "粗利額合計"
        Me.TotalArarilbl.TextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Center
        '
        'TotalArari
        '
        Me.TotalArari.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.TotalArari.BackColor = System.Drawing.SystemColors.Control
        Me.TotalArari.BorderColor = System.Drawing.SystemColors.Window
        Me.TotalArari.BorderStyle = OSK.X1.Foundation.Controls.Common.InputControl.BorderStyleType.Narrow
        Me.TotalArari.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TotalArari.FocusBackColor = System.Drawing.Color.Empty
        Me.TotalArari.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.TotalArari.ForeColor = System.Drawing.SystemColors.ControlText
        Me.TotalArari.IntegerDigits = 9
        Me.TotalArari.KeyDownButtonBackColor = System.Drawing.Color.Empty
        Me.TotalArari.Location = New System.Drawing.Point(488, 563)
        Me.TotalArari.MinusColor = System.Drawing.SystemColors.ControlText
        Me.TotalArari.Name = "TotalArari"
        Me.TotalArari.ReadOnly = True
        Me.TotalArari.RemarkString = Nothing
        Me.TotalArari.Size = New System.Drawing.Size(125, 19)
        Me.TotalArari.TabIndex = 1029
        Me.TotalArari.TabStop = False
        Me.TotalArari.Tag = "@OArea@"
        Me.TotalArari.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.TotalArari.Value = New Decimal(New Integer() {123456789, 0, 0, -2147483648})
        Me.TotalArari.ZeroDisplay = False
        '
        'Yuuokokigenlbl
        '
        Me.Yuuokokigenlbl.BorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.Yuuokokigenlbl.Font = New System.Drawing.Font("MS UI Gothic", 10.5!)
        Me.Yuuokokigenlbl.Location = New System.Drawing.Point(535, 128)
        Me.Yuuokokigenlbl.Name = "Yuuokokigenlbl"
        Me.Yuuokokigenlbl.Size = New System.Drawing.Size(80, 19)
        Me.Yuuokokigenlbl.TabIndex = 1027
        Me.Yuuokokigenlbl.Text = "有効期限"
        Me.Yuuokokigenlbl.TextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Equal
        '
        'yuukoukigen
        '
        Me.yuukoukigen.AutoResize = True
        Me.yuukoukigen.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.yuukoukigen.FocusBackColor = System.Drawing.Color.Empty
        Me.yuukoukigen.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.yuukoukigen.ImeMode = OSK.X1.Foundation.Controls.InputText.ImeModeType.Hiragana
        Me.yuukoukigen.Insert = False
        Me.yuukoukigen.KeyDownButtonBackColor = System.Drawing.Color.Empty
        Me.yuukoukigen.Location = New System.Drawing.Point(618, 128)
        Me.yuukoukigen.MaxLength = 32
        Me.yuukoukigen.MaxLengthMode = OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CustomLength
        Me.yuukoukigen.Name = "yuukoukigen"
        Me.yuukoukigen.RemarkString = Nothing
        Me.yuukoukigen.Size = New System.Drawing.Size(239, 19)
        Me.yuukoukigen.TabIndex = 16
        Me.yuukoukigen.Text = "X-----------( 3 2 )-----------X"
        Me.yuukoukigen.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'ShiharaiHoholbl
        '
        Me.ShiharaiHoholbl.BorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.ShiharaiHoholbl.Font = New System.Drawing.Font("MS UI Gothic", 10.5!)
        Me.ShiharaiHoholbl.Location = New System.Drawing.Point(535, 107)
        Me.ShiharaiHoholbl.Name = "ShiharaiHoholbl"
        Me.ShiharaiHoholbl.Size = New System.Drawing.Size(80, 19)
        Me.ShiharaiHoholbl.TabIndex = 1025
        Me.ShiharaiHoholbl.Text = "支払方法"
        Me.ShiharaiHoholbl.TextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Equal
        '
        'shiharaiHoho
        '
        Me.shiharaiHoho.AutoResize = True
        Me.shiharaiHoho.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.shiharaiHoho.FocusBackColor = System.Drawing.Color.Empty
        Me.shiharaiHoho.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.shiharaiHoho.ImeMode = OSK.X1.Foundation.Controls.InputText.ImeModeType.Hiragana
        Me.shiharaiHoho.Insert = False
        Me.shiharaiHoho.KeyDownButtonBackColor = System.Drawing.Color.Empty
        Me.shiharaiHoho.Location = New System.Drawing.Point(618, 107)
        Me.shiharaiHoho.MaxLength = 32
        Me.shiharaiHoho.MaxLengthMode = OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CustomLength
        Me.shiharaiHoho.Name = "shiharaiHoho"
        Me.shiharaiHoho.RemarkString = Nothing
        Me.shiharaiHoho.Size = New System.Drawing.Size(239, 19)
        Me.shiharaiHoho.TabIndex = 15
        Me.shiharaiHoho.Text = "X-----------( 3 2 )-----------X"
        Me.shiharaiHoho.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Noukilbl
        '
        Me.Noukilbl.BorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.Noukilbl.Font = New System.Drawing.Font("MS UI Gothic", 10.5!)
        Me.Noukilbl.Location = New System.Drawing.Point(535, 86)
        Me.Noukilbl.Name = "Noukilbl"
        Me.Noukilbl.Size = New System.Drawing.Size(80, 19)
        Me.Noukilbl.TabIndex = 1023
        Me.Noukilbl.Text = "納期"
        Me.Noukilbl.TextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Equal
        '
        'nouki
        '
        Me.nouki.AutoResize = True
        Me.nouki.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.nouki.FocusBackColor = System.Drawing.Color.Empty
        Me.nouki.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.nouki.ImeMode = OSK.X1.Foundation.Controls.InputText.ImeModeType.Hiragana
        Me.nouki.Insert = False
        Me.nouki.KeyDownButtonBackColor = System.Drawing.Color.Empty
        Me.nouki.Location = New System.Drawing.Point(618, 86)
        Me.nouki.MaxLength = 32
        Me.nouki.MaxLengthMode = OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CustomLength
        Me.nouki.Name = "nouki"
        Me.nouki.RemarkString = Nothing
        Me.nouki.Size = New System.Drawing.Size(239, 19)
        Me.nouki.TabIndex = 14
        Me.nouki.Text = "X-----------( 3 2 )-----------X"
        Me.nouki.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Youkenlbl
        '
        Me.Youkenlbl.BorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.Youkenlbl.Font = New System.Drawing.Font("MS UI Gothic", 10.5!)
        Me.Youkenlbl.Location = New System.Drawing.Point(535, 65)
        Me.Youkenlbl.Name = "Youkenlbl"
        Me.Youkenlbl.Size = New System.Drawing.Size(80, 19)
        Me.Youkenlbl.TabIndex = 1021
        Me.Youkenlbl.Text = "要件"
        Me.Youkenlbl.TextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Equal
        '
        'youken
        '
        Me.youken.AutoResize = True
        Me.youken.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.youken.FocusBackColor = System.Drawing.Color.Empty
        Me.youken.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.youken.ImeMode = OSK.X1.Foundation.Controls.InputText.ImeModeType.Hiragana
        Me.youken.Insert = False
        Me.youken.KeyDownButtonBackColor = System.Drawing.Color.Empty
        Me.youken.Location = New System.Drawing.Point(618, 65)
        Me.youken.MaxLength = 32
        Me.youken.MaxLengthMode = OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CustomLength
        Me.youken.Name = "youken"
        Me.youken.RemarkString = Nothing
        Me.youken.Size = New System.Drawing.Size(239, 19)
        Me.youken.TabIndex = 13
        Me.youken.Text = "X-----------( 3 2 )-----------X"
        Me.youken.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'CloseButton
        '
        Me.CloseButton.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CloseButton.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.CloseButton.FocusBackColor = System.Drawing.Color.Empty
        Me.CloseButton.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.CloseButton.Image = Nothing
        Me.CloseButton.Location = New System.Drawing.Point(1099, 19)
        Me.CloseButton.Name = "CloseButton"
        Me.CloseButton.NextByDownKey = False
        Me.CloseButton.NextByEnterKey = False
        Me.CloseButton.NextByTabKey = False
        Me.CloseButton.RemarkString = Nothing
        Me.CloseButton.Size = New System.Drawing.Size(80, 24)
        Me.CloseButton.TabIndex = 0
        Me.CloseButton.Text = "CLOSE"
        Me.CloseButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Kakutei
        '
        Me.Kakutei.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Kakutei.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Kakutei.FocusBackColor = System.Drawing.Color.Empty
        Me.Kakutei.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Kakutei.Image = Nothing
        Me.Kakutei.Location = New System.Drawing.Point(1092, 510)
        Me.Kakutei.Name = "Kakutei"
        Me.Kakutei.NextByEnterKey = False
        Me.Kakutei.RemarkString = Nothing
        Me.Kakutei.Size = New System.Drawing.Size(80, 24)
        Me.Kakutei.TabIndex = 22
        Me.Kakutei.Text = "行確定"
        Me.Kakutei.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'printModeLabel
        '
        Me.printModeLabel.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.printModeLabel.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.printModeLabel.BorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.SingleBold
        Me.printModeLabel.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.printModeLabel.Location = New System.Drawing.Point(1097, 7)
        Me.printModeLabel.Name = "printModeLabel"
        Me.printModeLabel.Size = New System.Drawing.Size(81, 19)
        Me.printModeLabel.TabIndex = 1019
        Me.printModeLabel.Tag = "@Exception@"
        Me.printModeLabel.Text = "本発行"
        Me.printModeLabel.TextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Center
        '
        'RowStatelbl
        '
        Me.RowStatelbl.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.RowStatelbl.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.RowStatelbl.BorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.SingleBold
        Me.RowStatelbl.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.RowStatelbl.Location = New System.Drawing.Point(1091, 476)
        Me.RowStatelbl.Name = "RowStatelbl"
        Me.RowStatelbl.Size = New System.Drawing.Size(81, 19)
        Me.RowStatelbl.TabIndex = 1017
        Me.RowStatelbl.Tag = "@Exception@"
        Me.RowStatelbl.Text = "新規行"
        Me.RowStatelbl.TextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Center
        '
        'Bikolbl
        '
        Me.Bikolbl.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Bikolbl.BorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.Bikolbl.Font = New System.Drawing.Font("MS UI Gothic", 10.5!)
        Me.Bikolbl.Location = New System.Drawing.Point(9, 589)
        Me.Bikolbl.Name = "Bikolbl"
        Me.Bikolbl.Size = New System.Drawing.Size(50, 19)
        Me.Bikolbl.TabIndex = 1016
        Me.Bikolbl.Text = "備考"
        Me.Bikolbl.TextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Equal
        '
        'Syouhizeilbl
        '
        Me.Syouhizeilbl.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Syouhizeilbl.BorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.Syouhizeilbl.Font = New System.Drawing.Font("MS UI Gothic", 10.5!)
        Me.Syouhizeilbl.Location = New System.Drawing.Point(831, 542)
        Me.Syouhizeilbl.Name = "Syouhizeilbl"
        Me.Syouhizeilbl.Size = New System.Drawing.Size(95, 19)
        Me.Syouhizeilbl.TabIndex = 1015
        Me.Syouhizeilbl.Text = "消費税額"
        Me.Syouhizeilbl.TextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Center
        '
        'Syouhizeigaku
        '
        Me.Syouhizeigaku.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Syouhizeigaku.BackColor = System.Drawing.SystemColors.Control
        Me.Syouhizeigaku.BorderColor = System.Drawing.SystemColors.Window
        Me.Syouhizeigaku.BorderStyle = OSK.X1.Foundation.Controls.Common.InputControl.BorderStyleType.Narrow
        Me.Syouhizeigaku.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Syouhizeigaku.FocusBackColor = System.Drawing.Color.Empty
        Me.Syouhizeigaku.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Syouhizeigaku.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Syouhizeigaku.IntegerDigits = 9
        Me.Syouhizeigaku.KeyDownButtonBackColor = System.Drawing.Color.Empty
        Me.Syouhizeigaku.Location = New System.Drawing.Point(831, 563)
        Me.Syouhizeigaku.MinusColor = System.Drawing.SystemColors.ControlText
        Me.Syouhizeigaku.Name = "Syouhizeigaku"
        Me.Syouhizeigaku.ReadOnly = True
        Me.Syouhizeigaku.RemarkString = Nothing
        Me.Syouhizeigaku.Size = New System.Drawing.Size(95, 19)
        Me.Syouhizeigaku.TabIndex = 1014
        Me.Syouhizeigaku.TabStop = False
        Me.Syouhizeigaku.Tag = "@OArea@"
        Me.Syouhizeigaku.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.Syouhizeigaku.Value = New Decimal(New Integer() {123456789, 0, 0, -2147483648})
        Me.Syouhizeigaku.ZeroDisplay = False
        '
        'TaisyoKingakulbl
        '
        Me.TaisyoKingakulbl.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.TaisyoKingakulbl.BorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.TaisyoKingakulbl.Font = New System.Drawing.Font("MS UI Gothic", 10.5!)
        Me.TaisyoKingakulbl.Location = New System.Drawing.Point(733, 542)
        Me.TaisyoKingakulbl.Name = "TaisyoKingakulbl"
        Me.TaisyoKingakulbl.Size = New System.Drawing.Size(95, 19)
        Me.TaisyoKingakulbl.TabIndex = 1013
        Me.TaisyoKingakulbl.Text = "対象金額"
        Me.TaisyoKingakulbl.TextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Center
        '
        'TaisyoKingaku
        '
        Me.TaisyoKingaku.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.TaisyoKingaku.BackColor = System.Drawing.SystemColors.Control
        Me.TaisyoKingaku.BorderColor = System.Drawing.SystemColors.Window
        Me.TaisyoKingaku.BorderStyle = OSK.X1.Foundation.Controls.Common.InputControl.BorderStyleType.Narrow
        Me.TaisyoKingaku.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TaisyoKingaku.FocusBackColor = System.Drawing.Color.Empty
        Me.TaisyoKingaku.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.TaisyoKingaku.ForeColor = System.Drawing.SystemColors.ControlText
        Me.TaisyoKingaku.IntegerDigits = 9
        Me.TaisyoKingaku.KeyDownButtonBackColor = System.Drawing.Color.Empty
        Me.TaisyoKingaku.Location = New System.Drawing.Point(733, 563)
        Me.TaisyoKingaku.MinusColor = System.Drawing.SystemColors.ControlText
        Me.TaisyoKingaku.Name = "TaisyoKingaku"
        Me.TaisyoKingaku.ReadOnly = True
        Me.TaisyoKingaku.RemarkString = Nothing
        Me.TaisyoKingaku.Size = New System.Drawing.Size(95, 19)
        Me.TaisyoKingaku.TabIndex = 1012
        Me.TaisyoKingaku.TabStop = False
        Me.TaisyoKingaku.Tag = "@OArea@"
        Me.TaisyoKingaku.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.TaisyoKingaku.Value = New Decimal(New Integer() {123456789, 0, 0, -2147483648})
        Me.TaisyoKingaku.ZeroDisplay = False
        '
        'ZensyaGenzaikolbl
        '
        Me.ZensyaGenzaikolbl.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.ZensyaGenzaikolbl.BorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.ZensyaGenzaikolbl.Font = New System.Drawing.Font("MS UI Gothic", 10.5!)
        Me.ZensyaGenzaikolbl.Location = New System.Drawing.Point(345, 542)
        Me.ZensyaGenzaikolbl.Name = "ZensyaGenzaikolbl"
        Me.ZensyaGenzaikolbl.Size = New System.Drawing.Size(117, 19)
        Me.ZensyaGenzaikolbl.TabIndex = 1011
        Me.ZensyaGenzaikolbl.Text = "全社現在庫"
        Me.ZensyaGenzaikolbl.TextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Center
        '
        'ZensyaGenzaiko
        '
        Me.ZensyaGenzaiko.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.ZensyaGenzaiko.BackColor = System.Drawing.SystemColors.Control
        Me.ZensyaGenzaiko.BorderColor = System.Drawing.SystemColors.Window
        Me.ZensyaGenzaiko.BorderStyle = OSK.X1.Foundation.Controls.Common.InputControl.BorderStyleType.Narrow
        Me.ZensyaGenzaiko.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.ZensyaGenzaiko.FocusBackColor = System.Drawing.Color.Empty
        Me.ZensyaGenzaiko.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.ZensyaGenzaiko.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ZensyaGenzaiko.IntegerDigits = 9
        Me.ZensyaGenzaiko.KeyDownButtonBackColor = System.Drawing.Color.Empty
        Me.ZensyaGenzaiko.Location = New System.Drawing.Point(345, 563)
        Me.ZensyaGenzaiko.MinusColor = System.Drawing.SystemColors.ControlText
        Me.ZensyaGenzaiko.Name = "ZensyaGenzaiko"
        Me.ZensyaGenzaiko.ReadOnly = True
        Me.ZensyaGenzaiko.RemarkString = Nothing
        Me.ZensyaGenzaiko.Size = New System.Drawing.Size(117, 19)
        Me.ZensyaGenzaiko.TabIndex = 1010
        Me.ZensyaGenzaiko.TabStop = False
        Me.ZensyaGenzaiko.Tag = "@OArea@"
        Me.ZensyaGenzaiko.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.ZensyaGenzaiko.Value = New Decimal(New Integer() {1912276171, 287, 0, -2147287040})
        Me.ZensyaGenzaiko.ZeroDisplay = False
        '
        'SokoGenzaikolbl
        '
        Me.SokoGenzaikolbl.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.SokoGenzaikolbl.BorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.SokoGenzaikolbl.Font = New System.Drawing.Font("MS UI Gothic", 10.5!)
        Me.SokoGenzaikolbl.Location = New System.Drawing.Point(225, 542)
        Me.SokoGenzaikolbl.Name = "SokoGenzaikolbl"
        Me.SokoGenzaikolbl.Size = New System.Drawing.Size(117, 19)
        Me.SokoGenzaikolbl.TabIndex = 1009
        Me.SokoGenzaikolbl.Text = "倉庫別現在庫"
        Me.SokoGenzaikolbl.TextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Center
        '
        'SokoGenzaiko
        '
        Me.SokoGenzaiko.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.SokoGenzaiko.BackColor = System.Drawing.SystemColors.Control
        Me.SokoGenzaiko.BorderColor = System.Drawing.SystemColors.Window
        Me.SokoGenzaiko.BorderStyle = OSK.X1.Foundation.Controls.Common.InputControl.BorderStyleType.Narrow
        Me.SokoGenzaiko.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.SokoGenzaiko.FocusBackColor = System.Drawing.Color.Empty
        Me.SokoGenzaiko.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.SokoGenzaiko.ForeColor = System.Drawing.SystemColors.ControlText
        Me.SokoGenzaiko.IntegerDigits = 9
        Me.SokoGenzaiko.KeyDownButtonBackColor = System.Drawing.Color.Empty
        Me.SokoGenzaiko.Location = New System.Drawing.Point(225, 563)
        Me.SokoGenzaiko.MinusColor = System.Drawing.SystemColors.ControlText
        Me.SokoGenzaiko.Name = "SokoGenzaiko"
        Me.SokoGenzaiko.ReadOnly = True
        Me.SokoGenzaiko.RemarkString = Nothing
        Me.SokoGenzaiko.Size = New System.Drawing.Size(117, 19)
        Me.SokoGenzaiko.TabIndex = 1008
        Me.SokoGenzaiko.TabStop = False
        Me.SokoGenzaiko.Tag = "@OArea@"
        Me.SokoGenzaiko.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.SokoGenzaiko.Value = New Decimal(New Integer() {1912276171, 287, 0, -2147287040})
        Me.SokoGenzaiko.ZeroDisplay = False
        '
        'ShouhizeiCode
        '
        Me.ShouhizeiCode.AllowBottomPosition = True
        Me.ShouhizeiCode.AutoResizeDispName = True
        Me.ShouhizeiCode.AutoResizeInputControl = True
        Me.ShouhizeiCode.BackColor = System.Drawing.Color.Transparent
        Me.ShouhizeiCode.DispNameAreaHeight = 19
        Me.ShouhizeiCode.DispNameAreaWidth = 85
        Me.ShouhizeiCode.DispNameBorderColor = System.Drawing.SystemColors.Window
        Me.ShouhizeiCode.DispNameBorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.ShouhizeiCode.DispNameSpace = 3
        Me.ShouhizeiCode.DispNameText = "X--(10)--X"
        Me.ShouhizeiCode.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.ShouhizeiCode.GroupNo = 0
        Me.ShouhizeiCode.Indent = 0
        Me.ShouhizeiCode.InnerSpace = 3
        Me.ShouhizeiCode.InputAreaFont = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.ShouhizeiCode.InputControlReadOnly = False
        Me.ShouhizeiCode.InputControlSize = New System.Drawing.Size(23, 19)
        Me.ShouhizeiCode.InputTextImeMode = OSK.X1.Foundation.Controls.InputText.ImeModeType.NoControl
        Me.ShouhizeiCode.InputType = OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemNameAndInputName.InputModeType.全文字入力可
        Me.ShouhizeiCode.ItemName = "消費税"
        Me.ShouhizeiCode.ItemNameAreaHeight = 19
        Me.ShouhizeiCode.ItemNameAreaWidth = 80
        Me.ShouhizeiCode.ItemNameBorderColor = System.Drawing.SystemColors.Window
        Me.ShouhizeiCode.ItemNameBorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.ShouhizeiCode.ItemNameFont = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.ShouhizeiCode.ItemNameTextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Equal
        Me.ShouhizeiCode.Location = New System.Drawing.Point(535, 149)
        Me.ShouhizeiCode.Margin = New System.Windows.Forms.Padding(0)
        Me.ShouhizeiCode.MaxLength = 2
        Me.ShouhizeiCode.MaxLengthMode = OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CharCount
        Me.ShouhizeiCode.Name = "ShouhizeiCode"
        Me.ShouhizeiCode.RemarkString = Nothing
        Me.ShouhizeiCode.Size = New System.Drawing.Size(194, 19)
        Me.ShouhizeiCode.SubGroupNo = 0
        Me.ShouhizeiCode.TabIndex = 17
        Me.ShouhizeiCode.TextValue = "12"
        Me.ShouhizeiCode.ZeroFill = False
        Me.ShouhizeiCode.ZeroFillAlways = False
        '
        'bumon
        '
        Me.bumon.AllowBottomPosition = True
        Me.bumon.AutoResizeDispName = True
        Me.bumon.AutoResizeInputControl = True
        Me.bumon.BackColor = System.Drawing.Color.Transparent
        Me.bumon.DispNameAreaHeight = 19
        Me.bumon.DispNameAreaWidth = 160
        Me.bumon.DispNameBorderColor = System.Drawing.SystemColors.Window
        Me.bumon.DispNameBorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.bumon.DispNameSpace = 3
        Me.bumon.DispNameText = "X------(20)--------X"
        Me.bumon.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.bumon.GroupNo = 0
        Me.bumon.Indent = 0
        Me.bumon.InnerSpace = 3
        Me.bumon.InputAreaFont = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.bumon.InputControlReadOnly = False
        Me.bumon.InputControlSize = New System.Drawing.Size(51, 19)
        Me.bumon.InputTextImeMode = OSK.X1.Foundation.Controls.InputText.ImeModeType.NoControl
        Me.bumon.InputType = OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemNameAndInputName.InputModeType.全文字入力可
        Me.bumon.ItemName = "部門"
        Me.bumon.ItemNameAreaHeight = 19
        Me.bumon.ItemNameAreaWidth = 50
        Me.bumon.ItemNameBorderColor = System.Drawing.SystemColors.Window
        Me.bumon.ItemNameBorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.bumon.ItemNameFont = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.bumon.ItemNameTextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Equal
        Me.bumon.Location = New System.Drawing.Point(12, 128)
        Me.bumon.Margin = New System.Windows.Forms.Padding(0)
        Me.bumon.MaxLength = 6
        Me.bumon.MaxLengthMode = OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CharCount
        Me.bumon.Name = "bumon"
        Me.bumon.RemarkString = Nothing
        Me.bumon.Size = New System.Drawing.Size(267, 19)
        Me.bumon.SubGroupNo = 0
        Me.bumon.TabIndex = 11
        Me.bumon.TextValue = "123456"
        Me.bumon.ZeroFill = False
        Me.bumon.ZeroFillAlways = False
        '
        'tantousha
        '
        Me.tantousha.AllowBottomPosition = True
        Me.tantousha.AutoResizeDispName = True
        Me.tantousha.AutoResizeInputControl = True
        Me.tantousha.BackColor = System.Drawing.Color.Transparent
        Me.tantousha.DispNameAreaHeight = 19
        Me.tantousha.DispNameAreaWidth = 160
        Me.tantousha.DispNameBorderColor = System.Drawing.SystemColors.Window
        Me.tantousha.DispNameBorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.tantousha.DispNameSpace = 3
        Me.tantousha.DispNameText = "X------(20)--------X"
        Me.tantousha.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.tantousha.GroupNo = 0
        Me.tantousha.Indent = 0
        Me.tantousha.InnerSpace = 3
        Me.tantousha.InputAreaFont = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.tantousha.InputControlReadOnly = False
        Me.tantousha.InputControlSize = New System.Drawing.Size(51, 19)
        Me.tantousha.InputTextImeMode = OSK.X1.Foundation.Controls.InputText.ImeModeType.NoControl
        Me.tantousha.InputType = OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemNameAndInputName.InputModeType.全文字入力可
        Me.tantousha.ItemName = "担当者"
        Me.tantousha.ItemNameAreaHeight = 19
        Me.tantousha.ItemNameAreaWidth = 50
        Me.tantousha.ItemNameBorderColor = System.Drawing.SystemColors.Window
        Me.tantousha.ItemNameBorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.tantousha.ItemNameFont = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.tantousha.ItemNameTextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Equal
        Me.tantousha.Location = New System.Drawing.Point(12, 107)
        Me.tantousha.Margin = New System.Windows.Forms.Padding(0)
        Me.tantousha.MaxLength = 6
        Me.tantousha.MaxLengthMode = OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CharCount
        Me.tantousha.Name = "tantousha"
        Me.tantousha.RemarkString = Nothing
        Me.tantousha.Size = New System.Drawing.Size(267, 19)
        Me.tantousha.SubGroupNo = 0
        Me.tantousha.TabIndex = 10
        Me.tantousha.TextValue = "123456"
        Me.tantousha.ZeroFill = False
        Me.tantousha.ZeroFillAlways = False
        '
        'taxRate
        '
        Me.taxRate.AllowBottomPosition = True
        Me.taxRate.AutoResizeInputControl = False
        Me.taxRate.BackColor = System.Drawing.Color.Transparent
        Me.taxRate.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.taxRate.GroupNo = 3
        Me.taxRate.Indent = 0
        Me.taxRate.InnerSpace = 3
        Me.taxRate.InputAreaFont = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.taxRate.InputControlReadOnly = False
        Me.taxRate.InputControlSize = New System.Drawing.Size(60, 19)
        Me.taxRate.ItemName = "税率"
        Me.taxRate.ItemNameAreaHeight = 19
        Me.taxRate.ItemNameAreaWidth = 50
        Me.taxRate.ItemNameBorderColor = System.Drawing.SystemColors.Window
        Me.taxRate.ItemNameBorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.taxRate.ItemNameFont = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.taxRate.ItemNameTextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Equal
        Me.taxRate.Location = New System.Drawing.Point(609, 40)
        Me.taxRate.Name = "taxRate"
        Me.taxRate.RemarkString = Nothing
        Me.taxRate.Size = New System.Drawing.Size(113, 19)
        Me.taxRate.SubGroupNo = 0
        Me.taxRate.TabIndex = 6
        Me.taxRate.TabStop = False
        Me.taxRate.表示スタイル = OSK.X1.Foundation.Controls.Combo.Common.Control.StyleType.DropDownList
        Me.taxRate.表示項目数 = 0
        Me.taxRate.表示項目番号 = -1
        '
        'DetailGridView
        '
        Me.DetailGridView.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DetailGridView.ButtonBackColor = System.Drawing.Color.Empty
        Me.DetailGridView.ButtonForeColor = System.Drawing.Color.Empty
        Me.DetailGridView.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.DetailGridView.Location = New System.Drawing.Point(9, 245)
        Me.DetailGridView.Name = "DetailGridView"
        Me.DetailGridView.NextByDownKey = False
        Me.DetailGridView.PrevByUpKey = False
        Me.DetailGridView.RecordBorderHeight = 1
        Me.DetailGridView.Size = New System.Drawing.Size(1170, 202)
        Me.DetailGridView.SortRange = SortRange2
        Me.DetailGridView.TabIndex = 20
        Me.DetailGridView.Text = "GridView1"
        Me.DetailGridView.UseCurrentRowColor = True
        '
        'TotalKingakulbl
        '
        Me.TotalKingakulbl.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.TotalKingakulbl.BorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.TotalKingakulbl.Font = New System.Drawing.Font("MS UI Gothic", 10.5!)
        Me.TotalKingakulbl.Location = New System.Drawing.Point(929, 542)
        Me.TotalKingakulbl.Name = "TotalKingakulbl"
        Me.TotalKingakulbl.Size = New System.Drawing.Size(125, 19)
        Me.TotalKingakulbl.TabIndex = 1001
        Me.TotalKingakulbl.Text = "合計金額"
        Me.TotalKingakulbl.TextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Center
        '
        'totalKingaku
        '
        Me.totalKingaku.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.totalKingaku.BackColor = System.Drawing.SystemColors.Control
        Me.totalKingaku.BorderColor = System.Drawing.SystemColors.Window
        Me.totalKingaku.BorderStyle = OSK.X1.Foundation.Controls.Common.InputControl.BorderStyleType.Narrow
        Me.totalKingaku.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.totalKingaku.FocusBackColor = System.Drawing.Color.Empty
        Me.totalKingaku.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.totalKingaku.ForeColor = System.Drawing.SystemColors.ControlText
        Me.totalKingaku.IntegerDigits = 9
        Me.totalKingaku.KeyDownButtonBackColor = System.Drawing.Color.Empty
        Me.totalKingaku.Location = New System.Drawing.Point(929, 563)
        Me.totalKingaku.MinusColor = System.Drawing.SystemColors.ControlText
        Me.totalKingaku.Name = "totalKingaku"
        Me.totalKingaku.ReadOnly = True
        Me.totalKingaku.RemarkString = Nothing
        Me.totalKingaku.Size = New System.Drawing.Size(125, 19)
        Me.totalKingaku.TabIndex = 1000
        Me.totalKingaku.TabStop = False
        Me.totalKingaku.Tag = "@OArea@"
        Me.totalKingaku.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.totalKingaku.Value = New Decimal(New Integer() {123456789, 0, 0, -2147483648})
        Me.totalKingaku.ZeroDisplay = False
        '
        'denpyouDate
        '
        Me.denpyouDate.CalendarOpenKey = System.Windows.Forms.Keys.F12
        Me.denpyouDate.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.denpyouDate.Date = 20061130
        Me.denpyouDate.DisplayFormat = OSK.X1.Foundation.Controls.InputDate.DisplayFormatType.gggEE
        Me.denpyouDate.DispSpinButton = True
        Me.denpyouDate.EraName = OSK.X1.Foundation.Controls.InputDate.EraNametype.Heisei
        Me.denpyouDate.FocusBackColor = System.Drawing.Color.Empty
        Me.denpyouDate.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.denpyouDate.KeyDownButtonBackColor = System.Drawing.Color.Empty
        Me.denpyouDate.Location = New System.Drawing.Point(428, 40)
        Me.denpyouDate.Name = "denpyouDate"
        Me.denpyouDate.RemarkString = Nothing
        Me.denpyouDate.Separator = OSK.X1.Foundation.Controls.InputDate.SeparatorType.BusinessYear
        Me.denpyouDate.Size = New System.Drawing.Size(175, 19)
        Me.denpyouDate.TabIndex = 5
        Me.denpyouDate.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'biko
        '
        Me.biko.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.biko.AutoResize = True
        Me.biko.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.biko.FocusBackColor = System.Drawing.Color.Empty
        Me.biko.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.biko.ImeMode = OSK.X1.Foundation.Controls.InputText.ImeModeType.Hiragana
        Me.biko.Insert = False
        Me.biko.KeyDownButtonBackColor = System.Drawing.Color.Empty
        Me.biko.Location = New System.Drawing.Point(62, 589)
        Me.biko.MaxLength = 48
        Me.biko.MaxLengthMode = OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CustomLength
        Me.biko.Name = "biko"
        Me.biko.RemarkString = Nothing
        Me.biko.Size = New System.Drawing.Size(355, 19)
        Me.biko.TabIndex = 23
        Me.biko.Text = "X-----------------( 4 8 )---------------------X"
        Me.biko.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'execute
        '
        Me.execute.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.execute.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.execute.FocusBackColor = System.Drawing.Color.Empty
        Me.execute.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.execute.Image = Nothing
        Me.execute.Location = New System.Drawing.Point(1101, 589)
        Me.execute.Name = "execute"
        Me.execute.NextByDownKey = False
        Me.execute.NextByEnterKey = False
        Me.execute.NextByTabKey = False
        Me.execute.RemarkString = Nothing
        Me.execute.Size = New System.Drawing.Size(80, 24)
        Me.execute.TabIndex = 24
        Me.execute.Text = "実行"
        Me.execute.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'shoriModeLabel
        '
        Me.shoriModeLabel.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.shoriModeLabel.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.shoriModeLabel.BorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.SingleBold
        Me.shoriModeLabel.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.shoriModeLabel.Location = New System.Drawing.Point(1097, 31)
        Me.shoriModeLabel.Name = "shoriModeLabel"
        Me.shoriModeLabel.Size = New System.Drawing.Size(81, 19)
        Me.shoriModeLabel.TabIndex = 999
        Me.shoriModeLabel.Tag = "@Exception@"
        Me.shoriModeLabel.Text = "新規伝票"
        Me.shoriModeLabel.TextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Center
        '
        'TokuisakiName2
        '
        Me.TokuisakiName2.AutoResize = True
        Me.TokuisakiName2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TokuisakiName2.FocusBackColor = System.Drawing.Color.Empty
        Me.TokuisakiName2.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.TokuisakiName2.ImeMode = OSK.X1.Foundation.Controls.InputText.ImeModeType.Hiragana
        Me.TokuisakiName2.Insert = False
        Me.TokuisakiName2.KeyDownButtonBackColor = System.Drawing.Color.Empty
        Me.TokuisakiName2.Location = New System.Drawing.Point(156, 86)
        Me.TokuisakiName2.MaxLength = 48
        Me.TokuisakiName2.MaxLengthMode = OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CustomLength
        Me.TokuisakiName2.Name = "TokuisakiName2"
        Me.TokuisakiName2.RemarkString = Nothing
        Me.TokuisakiName2.Size = New System.Drawing.Size(355, 19)
        Me.TokuisakiName2.TabIndex = 9
        Me.TokuisakiName2.Text = "X-----------------( 4 8 )---------------------X"
        Me.TokuisakiName2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TokuisakiName1
        '
        Me.TokuisakiName1.AutoResize = True
        Me.TokuisakiName1.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.TokuisakiName1.FocusBackColor = System.Drawing.Color.Empty
        Me.TokuisakiName1.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.TokuisakiName1.ImeMode = OSK.X1.Foundation.Controls.InputText.ImeModeType.Hiragana
        Me.TokuisakiName1.Insert = False
        Me.TokuisakiName1.KeyDownButtonBackColor = System.Drawing.Color.Empty
        Me.TokuisakiName1.Location = New System.Drawing.Point(156, 65)
        Me.TokuisakiName1.MaxLength = 48
        Me.TokuisakiName1.MaxLengthMode = OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CustomLength
        Me.TokuisakiName1.Name = "TokuisakiName1"
        Me.TokuisakiName1.RemarkString = Nothing
        Me.TokuisakiName1.Size = New System.Drawing.Size(355, 19)
        Me.TokuisakiName1.TabIndex = 8
        Me.TokuisakiName1.Text = "X-----------------( 4 8 )---------------------X"
        Me.TokuisakiName1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TokuisakiCode
        '
        Me.TokuisakiCode.AllowBottomPosition = True
        Me.TokuisakiCode.AutoResizeInputControl = True
        Me.TokuisakiCode.BackColor = System.Drawing.Color.Transparent
        Me.TokuisakiCode.Font = New System.Drawing.Font("MS UI Gothic", 10.5!)
        Me.TokuisakiCode.GroupNo = 0
        Me.TokuisakiCode.Indent = 0
        Me.TokuisakiCode.InnerSpace = 3
        Me.TokuisakiCode.InputAreaFont = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.TokuisakiCode.InputControlReadOnly = False
        Me.TokuisakiCode.InputControlSize = New System.Drawing.Size(88, 19)
        Me.TokuisakiCode.InputTextImeMode = OSK.X1.Foundation.Controls.InputText.ImeModeType.NoControl
        Me.TokuisakiCode.InputType = OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemName.InputTypeList.全文字入力可
        Me.TokuisakiCode.ItemName = "得意先"
        Me.TokuisakiCode.ItemNameAreaHeight = 19
        Me.TokuisakiCode.ItemNameAreaWidth = 50
        Me.TokuisakiCode.ItemNameBorderColor = System.Drawing.SystemColors.Window
        Me.TokuisakiCode.ItemNameBorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.TokuisakiCode.ItemNameFont = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.TokuisakiCode.ItemNameTextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Equal
        Me.TokuisakiCode.Location = New System.Drawing.Point(12, 65)
        Me.TokuisakiCode.MaxLength = 11
        Me.TokuisakiCode.MaxLengthMode = OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CharCount
        Me.TokuisakiCode.Name = "TokuisakiCode"
        Me.TokuisakiCode.RemarkString = Nothing
        Me.TokuisakiCode.Size = New System.Drawing.Size(141, 19)
        Me.TokuisakiCode.SubGroupNo = 0
        Me.TokuisakiCode.TabIndex = 7
        Me.TokuisakiCode.TextValue = "12345678901"
        Me.TokuisakiCode.ZeroFill = False
        Me.TokuisakiCode.ZeroFillAlways = False
        '
        'headerPanel
        '
        Me.headerPanel.BackColor = System.Drawing.SystemColors.Info
        Me.headerPanel.BorderColor = System.Drawing.SystemColors.Window
        Me.headerPanel.BorderStyle = OSK.X1.Foundation.Controls.Panel.BorderStyleType.Narrow
        Me.headerPanel.Controls.Add(Me.display)
        Me.headerPanel.Controls.Add(Me.shoriRenban)
        Me.headerPanel.Controls.Add(Me.shori)
        Me.headerPanel.Location = New System.Drawing.Point(9, 7)
        Me.headerPanel.Name = "headerPanel"
        Me.headerPanel.Size = New System.Drawing.Size(410, 51)
        Me.headerPanel.TabIndex = 0
        Me.headerPanel.Tag = "@KEYAREA@"
        '
        'display
        '
        Me.display.CausesValidation = False
        Me.display.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.display.FocusBackColor = System.Drawing.Color.Empty
        Me.display.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.display.GroupNo = 2
        Me.display.Image = Nothing
        Me.display.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.display.Location = New System.Drawing.Point(341, 24)
        Me.display.Name = "display"
        Me.display.NextByEnterKey = False
        Me.display.RemarkString = Nothing
        Me.display.Size = New System.Drawing.Size(60, 21)
        Me.display.TabIndex = 3
        Me.display.TabStop = False
        Me.display.Tag = "アイコン=最新表示"
        Me.display.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'shoriRenban
        '
        Me.shoriRenban.AllowBottomPosition = True
        Me.shoriRenban.AutoResizeInputControl = True
        Me.shoriRenban.BackColor = System.Drawing.Color.Transparent
        Me.shoriRenban.Font = New System.Drawing.Font("MS UI Gothic", 10.5!)
        Me.shoriRenban.GroupNo = 2
        Me.shoriRenban.Indent = 0
        Me.shoriRenban.InnerSpace = 3
        Me.shoriRenban.InputAreaFont = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.shoriRenban.InputControlReadOnly = False
        Me.shoriRenban.InputControlSize = New System.Drawing.Size(80, 19)
        Me.shoriRenban.ItemName = "伝票№"
        Me.shoriRenban.ItemNameAreaHeight = 19
        Me.shoriRenban.ItemNameAreaWidth = 50
        Me.shoriRenban.ItemNameBorderColor = System.Drawing.SystemColors.Window
        Me.shoriRenban.ItemNameBorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.shoriRenban.ItemNameFont = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.shoriRenban.ItemNameTextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Equal
        Me.shoriRenban.Location = New System.Drawing.Point(199, 26)
        Me.shoriRenban.Minus = "-"
        Me.shoriRenban.Name = "shoriRenban"
        Me.shoriRenban.RemarkString = Nothing
        Me.shoriRenban.Size = New System.Drawing.Size(133, 19)
        Me.shoriRenban.SubGroupNo = 0
        Me.shoriRenban.TabIndex = 2
        Me.shoriRenban.Value = New Decimal(New Integer() {1234567890, 0, 0, 0})
        Me.shoriRenban.カンマ表示 = False
        Me.shoriRenban.スピンボタンの値 = Nothing
        Me.shoriRenban.スピンボタンの表示 = False
        Me.shoriRenban.ゼロ表示 = False
        Me.shoriRenban.マイナス入力 = False
        Me.shoriRenban.マイナス入力時の色 = System.Drawing.SystemColors.WindowText
        Me.shoriRenban.小数桁数 = 0
        Me.shoriRenban.整数桁数 = 10
        Me.shoriRenban.最大値 = New Decimal(New Integer() {-469762049, -590869294, 5421010, 393216})
        Me.shoriRenban.最小値 = New Decimal(New Integer() {-469762049, -590869294, 5421010, -2147090432})
        '
        'shori
        '
        Me.shori.BorderStyle = OSK.X1.Foundation.Controls.GroupOption.BorderStyleType.Normal
        Me.shori.FocusBackColor = System.Drawing.Color.Empty
        Me.shori.Font = New System.Drawing.Font("MS UI Gothic", 10.5!)
        Me.shori.GroupNo = 1
        Me.shori.ItemCount = 3
        Item1.Enabled = True
        Item1.Text = "登録"
        Item1.Visible = True
        Item2.Enabled = True
        Item2.Text = "修正"
        Item2.Visible = True
        Item3.Enabled = True
        Item3.Text = "削除"
        Item3.Visible = True
        Me.shori.Items = New OSK.X1.Foundation.Controls.GroupOptionImpl.Item() {Item1, Item2, Item3}
        Me.shori.Location = New System.Drawing.Point(9, 6)
        Me.shori.Name = "shori"
        Me.shori.PrevByShiftTabKey = False
        Me.shori.PrevByUpKey = False
        Me.shori.RemarkString = Nothing
        Me.shori.Size = New System.Drawing.Size(184, 39)
        Me.shori.TabIndex = 1
        Me.shori.Tag = "@KEYAREA@"
        Me.shori.Title = "処理モード"
        '
        'functionBar
        '
        Me.functionBar.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.functionBar.F1でヘルプ = OSK.X1.Foundation.SmartControl.FunctionBar.FunctionBar.ヘルプタイプ.実行する
        Me.functionBar.ForeColor = System.Drawing.SystemColors.ControlText
        Me.functionBar.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.functionBar.GroupNo = 0
        FunctionControlList1.個別指定ファンクションキー = OSK.X1.Foundation.SmartControl.FunctionBar.FunctionControl.KeyType.F7
        FunctionControlList1.個別指定表示状態 = False
        Me.functionBar.Items = FunctionControlList1
        Me.functionBar.Location = New System.Drawing.Point(0, 621)
        Me.functionBar.Name = "functionBar"
        Me.functionBar.ShowItemToolTips = False
        Me.functionBar.Size = New System.Drawing.Size(1184, 25)
        Me.functionBar.Stretch = True
        Me.functionBar.SubGroupNo = 0
        Me.functionBar.TabIndex = 900
        Me.functionBar.Tag = ""
        Me.functionBar.個別指定ファンクションキー = OSK.X1.Foundation.SmartControl.FunctionBar.FunctionControl.KeyType.F7
        '
        'DetailGridEdit
        '
        Me.DetailGridEdit.Anchor = CType(((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DetailGridEdit.BackColorSpace = System.Drawing.SystemColors.Control
        Me.DetailGridEdit.ButtonBackColor = System.Drawing.Color.Empty
        Me.DetailGridEdit.ButtonForeColor = System.Drawing.Color.Empty
        Me.DetailGridEdit.FocusEditPosition = 1
        Me.DetailGridEdit.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.5!)
        Me.DetailGridEdit.HeaderAreaBorderHeight = 1
        Me.DetailGridEdit.KeyDownButtonBackColor = System.Drawing.Color.Empty
        Me.DetailGridEdit.Location = New System.Drawing.Point(9, 451)
        Me.DetailGridEdit.MoveCommandButtonCellOnEnterKey = False
        Me.DetailGridEdit.Name = "DetailGridEdit"
        Me.DetailGridEdit.NextByDownKey = False
        Me.DetailGridEdit.NextByEnterKey = False
        Me.DetailGridEdit.NextByTabKey = False
        Me.DetailGridEdit.PrevByShiftTabKey = False
        Me.DetailGridEdit.PrevByUpKey = False
        Me.DetailGridEdit.RecordBorderColor = System.Drawing.SystemColors.ControlDarkDark
        Me.DetailGridEdit.RecordBorderHeight = 1
        Me.DetailGridEdit.RowCount = 1
        RowAttributeInfo2.DispToolTipMode = Nothing
        RowAttributeInfo2.ImageAlignment = Nothing
        RowAttributeInfo2.ImageDisplayMode = Nothing
        RowAttributeInfo2.ImagePath = Nothing
        Me.DetailGridEdit.Rows.AddRange(New OSK.X1.Foundation.Controls.Grid.Common.RowAttributeInfo() {RowAttributeInfo2})
        Me.DetailGridEdit.Size = New System.Drawing.Size(1170, 88)
        Me.DetailGridEdit.SortRange = SortRange3
        Me.DetailGridEdit.TabIndex = 21
        '
        'MenuBar
        '
        Me.MenuBar.CanOverflow = True
        Me.MenuBar.Dock = System.Windows.Forms.DockStyle.None
        Me.MenuBar.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.endMenu, Me.pageMenu, Me.printMenu})
        Me.MenuBar.Location = New System.Drawing.Point(0, 0)
        Me.MenuBar.MenuContainer = Me.entryContainer
        Me.MenuBar.Name = "MenuBar"
        Me.MenuBar.Padding = New System.Windows.Forms.Padding(0, 1, 0, 2)
        Me.MenuBar.Size = New System.Drawing.Size(1184, 24)
        Me.MenuBar.TabIndex = 0
        Me.MenuBar.Tag = "@Exception@"
        '
        'endMenu
        '
        Me.endMenu.Name = "endMenu"
        Me.endMenu.Overflow = System.Windows.Forms.ToolStripItemOverflow.AsNeeded
        Me.endMenu.Size = New System.Drawing.Size(58, 21)
        Me.endMenu.Text = "終了(&X)"
        '
        'pageMenu
        '
        Me.pageMenu.Name = "pageMenu"
        Me.pageMenu.Overflow = System.Windows.Forms.ToolStripItemOverflow.AsNeeded
        Me.pageMenu.Size = New System.Drawing.Size(87, 21)
        Me.pageMenu.Tag = "アイコン=ページ設定"
        Me.pageMenu.Text = "ページ設定(&U)"
        '
        'printMenu
        '
        Me.printMenu.Name = "printMenu"
        Me.printMenu.Overflow = System.Windows.Forms.ToolStripItemOverflow.AsNeeded
        Me.printMenu.Size = New System.Drawing.Size(82, 21)
        Me.printMenu.Tag = "アイコン=設定"
        Me.printMenu.Text = "伝票発行(&P)"
        '
        'EntryForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1184, 692)
        Me.Controls.Add(Me.entryContainer)
        Me.Font = New System.Drawing.Font("MS UI Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.KeyPreview = True
        Me.Name = "EntryForm"
        Me.Text = ""
        Me.entryContainer.BottomToolStripPanel.ResumeLayout(False)
        Me.entryContainer.BottomToolStripPanel.PerformLayout()
        Me.entryContainer.ContentPanel.ResumeLayout(False)
        Me.entryContainer.ContentPanel.PerformLayout()
        Me.entryContainer.TopToolStripPanel.ResumeLayout(False)
        Me.entryContainer.TopToolStripPanel.PerformLayout()
        Me.entryContainer.ResumeLayout(False)
        Me.entryContainer.PerformLayout()
        Me.headerPanel.ResumeLayout(False)
        Me.MenuBar.ResumeLayout(False)
        Me.MenuBar.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Protected WithEvents MenuBar As OSK.X1.Foundation.SmartControl.MenuBar.MenuBar
    Protected WithEvents entryContainer As System.Windows.Forms.ToolStripContainer
    Protected WithEvents endMenu As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StatusBar As OSK.X1.Foundation.SmartControl.StatusBar.StatusBar
    Friend WithEvents functionBar As OSK.X1.Foundation.SmartControl.FunctionBar.FunctionBar
    Friend WithEvents headerPanel As OSK.X1.Foundation.SimpleControl.Panel
    Friend WithEvents TokuisakiName1 As OSK.X1.Foundation.SimpleControl.InputText
    Friend WithEvents TokuisakiCode As OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemName
    Friend WithEvents TokuisakiName2 As OSK.X1.Foundation.SimpleControl.InputText
    Friend WithEvents shoriModeLabel As OSK.X1.Foundation.SimpleControl.Label
    Friend WithEvents DetailGridEdit As OSK.X1.Foundation.SimpleControl.GridEdit
    Protected WithEvents execute As OSK.X1.Foundation.SimpleControl.CommandButton
    Friend WithEvents biko As OSK.X1.Foundation.SimpleControl.InputText
    Friend WithEvents shoriRenban As OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputNumericalWithItemName
    Protected WithEvents display As OSK.X1.Foundation.SimpleControl.CommandButton
    Friend WithEvents shori As OSK.X1.Foundation.SimpleControl.GroupOption
    Friend WithEvents denpyouDate As OSK.X1.Foundation.SimpleControl.InputDate
    Friend WithEvents TotalKingakulbl As OSK.X1.Foundation.SimpleControl.Label
    Friend WithEvents totalKingaku As OSK.X1.Foundation.SimpleControl.InputNumerical
    Friend WithEvents ShouhizeiCode As InputTextWithItemNameAndInputName
    Friend WithEvents bumon As InputTextWithItemNameAndInputName
    Friend WithEvents tantousha As InputTextWithItemNameAndInputName
    Friend WithEvents taxRate As ComboBoxWithItemName
    Friend WithEvents DetailGridView As SimpleControl.GridView
    Friend WithEvents Syouhizeilbl As SimpleControl.Label
    Friend WithEvents Syouhizeigaku As SimpleControl.InputNumerical
    Friend WithEvents TaisyoKingakulbl As SimpleControl.Label
    Friend WithEvents TaisyoKingaku As SimpleControl.InputNumerical
    Friend WithEvents ZensyaGenzaikolbl As SimpleControl.Label
    Friend WithEvents ZensyaGenzaiko As SimpleControl.InputNumerical
    Friend WithEvents SokoGenzaikolbl As SimpleControl.Label
    Friend WithEvents SokoGenzaiko As SimpleControl.InputNumerical
    Friend WithEvents Bikolbl As SimpleControl.Label
    Protected WithEvents Kakutei As SimpleControl.CommandButton
    Friend WithEvents RowStatelbl As SimpleControl.Label
    Friend WithEvents pageMenu As ToolStripMenuItem
    Friend WithEvents printMenu As ToolStripMenuItem
    Friend WithEvents printModeLabel As SimpleControl.Label
    Protected WithEvents CloseButton As SimpleControl.CommandButton
    Friend WithEvents Yuuokokigenlbl As SimpleControl.Label
    Friend WithEvents yuukoukigen As SimpleControl.InputText
    Friend WithEvents ShiharaiHoholbl As SimpleControl.Label
    Friend WithEvents shiharaiHoho As SimpleControl.InputText
    Friend WithEvents Noukilbl As SimpleControl.Label
    Friend WithEvents nouki As SimpleControl.InputText
    Friend WithEvents Youkenlbl As SimpleControl.Label
    Friend WithEvents youken As SimpleControl.InputText
    Friend WithEvents ArariRitulbl As SimpleControl.Label
    Friend WithEvents ArariRitu As SimpleControl.InputNumerical
    Friend WithEvents TotalArarilbl As SimpleControl.Label
    Friend WithEvents TotalArari As SimpleControl.InputNumerical
    Friend WithEvents nohinsaki As InputTextWithItemNameAndInputName
    Friend WithEvents ExpandItemButton As SimpleControl.CommandButton
    Friend WithEvents expandItemHeader As SimpleControl.GridEdit
End Class
