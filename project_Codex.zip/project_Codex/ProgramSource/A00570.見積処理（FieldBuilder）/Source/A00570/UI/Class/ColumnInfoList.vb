﻿Public Class ColumnInfoList
    Inherits ColumnInfoListBase

#Region "内部変数"

    Private _myコントロール情報 As New Myコントロール情報型
    Private _退避情報 As New 退避情報型

    Private _gridEntry As OSK.X1.Foundation.SimpleControl.GridEdit
    Private _tabIndex As IDictionary

    Private _tabIndexKey As String
    Private _inputItemType As SettingCode.InputItemType
    Private _columWidth As Integer
    Private _focusCaretPosition As OSK.X1.Foundation.Controls.Grid.Common.FocusCaretPosType

    Private _columnIndex As Integer
    Private _textDisplayMode_Numerical As OSK.X1.Foundation.Controls.InputNumerical.TextDisplayModeType

#End Region

#Region "プロパティ"

    Private _lineStartColumu As New List(Of String)
    Friend ReadOnly Property LineStartColumu() As List(Of String)
        Get
            Return _lineStartColumu
        End Get
    End Property

    Private _lineFixedColumu As New List(Of Integer)
    Friend ReadOnly Property LineFixedColumu() As List(Of Integer)
        Get
            Return _lineFixedColumu
        End Get
    End Property

    Private _最終項目TabIndex As Integer = 0
    Friend ReadOnly Property 最終項目TabIndex() As Integer
        Get
            Return _最終項目TabIndex
        End Get
    End Property

    'A-CUST20260407↓
    Private _lineWidthLine1 As Integer = 0
    Private _lineWidthLine2 As Integer = 0
    ''' <summary>
    ''' Line1/Line2 の GetColSize 合計の最大値。
    ''' FBMeisaiColumnInfoList.SetMeisaiGrid の maxLineWidth に渡し、空白の列幅計算に活用する。
    ''' SetDetailGrid() 呼び出し後に有効になる。
    ''' </summary>
    Friend ReadOnly Property DetailMaxLineWidth As Integer
        Get
            Return Math.Max(_lineWidthLine1, _lineWidthLine2)
        End Get
    End Property

    Private _allMeisaiConfigured As Boolean = False
    Friend Property AllMeisaiConfigured() As Boolean
        Get
            Return _allMeisaiConfigured
        End Get
        Set(value As Boolean)
            _allMeisaiConfigured = value
        End Set
    End Property
    'A-CUST20260407↑

#End Region

#Region "コンストラクタ"

    Sub New(ByVal initInfo As IDictionary, ByVal settingInfo As IDictionary)
        MyBase.New(initInfo, settingInfo)

    End Sub

#End Region

#Region "公開メソッド"

    Friend Sub SetDetailGrid(ByVal gridEntry As OSK.X1.Foundation.SimpleControl.GridEdit)
        _gridEntry = gridEntry

        _columnIndex = 退避情報型.明細項目型.Detailcnt2 - 1

        SetUpControlInfo()
        SetUpItemTabIndex()
        SetUpDetailItemInfo()

    End Sub
    'A-CUST20260407↓
    ''' <summary>
    ''' FB (ExpandItem) 明細列の定義を明細行に追加
    ''' </summary>
    Friend Sub AppendFBColumns(ByVal expandList As ExpandItemMeisaiColumnInfoList)
        If expandList Is Nothing OrElse expandList.ColumnInfos.Count = 0 Then Return

        ' ExpandItem 明細列の折り返し行を登録
        For Each lineStartName As String In expandList.ExpandItemLineStartColumnNames
            _lineStartColumu.Add(lineStartName)
            _lineFixedColumu.Add(1)
        Next

        ' 各 ColumnInfo をベースリストに追記
        For Each ci As ColumnInfo In expandList.ColumnInfos
            AddItemInfo(ci)
        Next

        ' 最終TabIndex を 列数だけ更新
        _最終項目TabIndex += expandList.ColumnInfos.Count
    End Sub
    'A-CUST20260407↑

#End Region

#Region "内部メソッド"

    ''' <summary>
    ''' コントロール初期化
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetUpControlInfo()

        _myコントロール情報 = New Myコントロール情報型
        _myコントロール情報.InitializeCUSCE01(Me.InitInfo)

    End Sub

    ''' <summary>
    ''' 列の追加
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetUpDetailItemInfo()

        SetUpDetailItemInfoLine1()
        SetUpDetailItemInfoLine2()
        ComputeLineWidths() 'A-CUST20260407


    End Sub

    ''' <summary>
    ''' 列の追加（折り返し１行目）
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetUpDetailItemInfoLine1()

        _lineStartColumu.Add(退避情報型.明細項目型.行.ToString)
        _lineFixedColumu.Add(1)

        AddItemInfo(New ColumnInfo(
                    退避情報型.明細項目型.行.ToString, GetColSize(4), 退避情報型.明細項目型.行.ToString, 0, False, "0",
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Right,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    GetTabIndex(退避情報型.明細項目型.行.ToString), "",
                    New SettingInputNumerical(True, 3, 0, False)))

        AddItemInfo(New ColumnInfo(
                    退避情報型.明細項目型.区分.ToString, GetColSize(4), 退避情報型.明細項目型.区分.ToString, 0, False, "",
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Right,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    GetTabIndex(退避情報型.明細項目型.区分.ToString),
                    New SettingCode(SettingCode.InputItemType.数値_ゼロフィルあり, 2, OSK.X1.Foundation.Controls.InputText.ImeModeType.Off)))

        AddItemInfo(New ColumnInfo(
                    退避情報型.明細項目型.商品コード.ToString, GetColSize(22, 0), 退避情報型.明細項目型.商品コード.ToString, 0, False, "",
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Left,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    GetTabIndex(退避情報型.明細項目型.商品コード.ToString),
                    New SettingCode(SettingCode.InputItemType.半角英数のみ, 20, OSK.X1.Foundation.Controls.InputText.ImeModeType.Off)))

        AddItemInfo(New ColumnInfo(
                    退避情報型.明細項目型.課税区分.ToString, GetColSize(3, 0), 退避情報型.明細項目型.課税区分.ToString, 0, False, "",
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Left,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    GetTabIndex(退避情報型.明細項目型.課税区分.ToString),
                    New SettingCode(SettingCode.InputItemType.数値_ゼロフィルあり, 2, OSK.X1.Foundation.Controls.InputText.ImeModeType.Off)))

        AddItemInfo(New ColumnInfo(
                    退避情報型.明細項目型.課税区分名.ToString, GetColSize(26, 4), 退避情報型.明細項目型.課税区分名.ToString, 0, False, "",
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Left,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    GetTabIndex(""),
                    New SettingLabel()))

        AddItemInfo(New ColumnInfo(
                    退避情報型.明細項目型.倉庫コード.ToString, GetColSize(6, 0), "倉庫", 0, False, "",
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Left,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    GetTabIndex(退避情報型.明細項目型.倉庫コード.ToString),
                    New SettingCode(SettingCode.InputItemType.数値_ゼロフィルあり, 6, OSK.X1.Foundation.Controls.InputText.ImeModeType.Off)))

        AddItemInfo(New ColumnInfo(
                    退避情報型.明細項目型.倉庫名.ToString, GetColSize(8, 2), "", 0, False, "",
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Left,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    GetTabIndex(""),
                    New SettingLabel()))

        'D-CUST20211110_01↓
        'AddItemInfo(New ColumnInfo(
        '            退避情報型.明細項目型.原単価.ToString, GetColSize(15), 退避情報型.明細項目型.原単価.ToString, 0, False, "0",
        '            OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Right,
        '            OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
        '            GetTabIndex(退避情報型.明細項目型.原単価.ToString), "",
        '            New SettingInputNumerical(True, 8, _myコントロール情報.小数桁_仕入単価)))
        'D-CUST20211110_01↑
        'A-CUST20211110_01↓
        AddItemInfo(New ColumnInfo(
                    退避情報型.明細項目型.原単価.ToString, GetColSize(15), 退避情報型.明細項目型.原単価.ToString, 0, False, "0",
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Right,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    GetTabIndex(退避情報型.明細項目型.原単価.ToString), "",
                    New SettingInputNumerical(True, 10, _myコントロール情報.小数桁_仕入単価, InputNumerical.TextDisplayModeType.AdjustFontWidth)))
        'A-CUST20211110_01↑
        'D-CUST20211110_01↓
        'AddItemInfo(New ColumnInfo(
        '            退避情報型.明細項目型.原価金額.ToString, GetColSize(15), 退避情報型.明細項目型.原価金額.ToString, 0, False, "0",
        '            OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Right,
        '            OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
        '            GetTabIndex(退避情報型.明細項目型.原価金額.ToString), "",
        '            New SettingInputNumerical(True, 9, 0)))
        'D-CUST20211110_01↑
        'A-CUST20211110_01↓
        AddItemInfo(New ColumnInfo(
                    退避情報型.明細項目型.原価金額.ToString, GetColSize(15), 退避情報型.明細項目型.原価金額.ToString, 0, False, "0",
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Right,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    GetTabIndex(退避情報型.明細項目型.原価金額.ToString), "",
                    New SettingInputNumerical(True, 10, 0)))
        'A-CUST20211110_01↑

        AddItemInfo(New ColumnInfo(
                    退避情報型.明細項目型.ラベル1_01.ToString, GetColSize(24), "", 0, False, "",
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Left,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    GetTabIndex(""),
                    New SettingLabel()))

        AddItemInfo(New ColumnInfo(
                   退避情報型.明細項目型.小計.ToString, GetColSize(4), 退避情報型.明細項目型.小計.ToString, 0, False, "0",
                   OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                   OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                   GetTabIndex(退避情報型.明細項目型.小計.ToString),
                   New SettingCheckBox()))

        'A-CUST20251104↓
        'If CType(InitInfo.Item("プログラム専用.FieldBuilder.明細.有効"), Boolean) Then    'D-CUST20260407
        If CType(InitInfo.Item("プログラム専用.FieldBuilder.明細.有効"), Boolean) AndAlso Not _allMeisaiConfigured Then  'A-CUST20260407
            AddItemInfo(New ColumnInfo(
                    退避情報型.明細項目型.ラベル1_02.ToString, GetColSize(4), "", 0, False, "",
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Left,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    GetTabIndex(""),
                    New SettingLabel()))
        End If
        'A-CUST20251104↑



    End Sub

    ''' <summary>
    ''' 列の追加（折り返し２行目）
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetUpDetailItemInfoLine2()

        _lineStartColumu.Add(退避情報型.明細項目型.ラベル2_01.ToString)
        _lineFixedColumu.Add(1)

        AddItemInfo(New ColumnInfo(
                    退避情報型.明細項目型.ラベル2_01.ToString, GetColSize(4), "", 0, False, "",
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Left,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    GetTabIndex(""),
                    New SettingLabel()))

        AddItemInfo(New ColumnInfo(
                    退避情報型.明細項目型.区分名.ToString, GetColSize(4), "", 0, False, "",
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Left,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    GetTabIndex(""),
                    New SettingLabel()))

        AddItemInfo(New ColumnInfo(
                    退避情報型.明細項目型.商品名.ToString, GetColSize(48, 2), 退避情報型.明細項目型.商品名.ToString, 0, False, "",
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Left,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    GetTabIndex(退避情報型.明細項目型.商品名.ToString),
                    New SettingInputText(48, OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CustomLength,
                                         OSK.X1.Foundation.Controls.InputText.ImeModeType.Hiragana, False, False, True, True, True, True, True, True, True, True, True,
                                         _focusCaretPosition)))

        AddItemInfo(New ColumnInfo(
                    退避情報型.明細項目型.単位.ToString, GetColSize(4), 退避情報型.明細項目型.単位.ToString, 0, False, "",
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Left,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    GetTabIndex(退避情報型.明細項目型.単位.ToString),
                    New SettingInputText(4, OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CustomLength,
                                         OSK.X1.Foundation.Controls.InputText.ImeModeType.Hiragana, False, False, True, True, True, True, True, True, True, True, True)))

        'D-CUST20211110_01↓
        '_textDisplayMode_Numerical = InputNumerical.TextDisplayModeType.Normal
        'If _myコントロール情報.数量拡張表示 = True Then
        '    _textDisplayMode_Numerical = InputNumerical.TextDisplayModeType.AdjustFontWidth
        'End If
        'AddItemInfo(New ColumnInfo(
        '            退避情報型.明細項目型.数量.ToString, GetColSize(15), 退避情報型.明細項目型.数量.ToString, 0, False, "0",
        '            OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Right,
        '            OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
        '            GetTabIndex(退避情報型.明細項目型.数量.ToString), "",
        '            New SettingInputNumerical(True, 8, _myコントロール情報.小数桁_数量, _textDisplayMode_Numerical)))
        'D-CUST20211110_01↑
        'A-CUST20211110_01↓
        AddItemInfo(New ColumnInfo(
                    退避情報型.明細項目型.数量.ToString, GetColSize(15), 退避情報型.明細項目型.数量.ToString, 0, False, "0",
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Right,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    GetTabIndex(退避情報型.明細項目型.数量.ToString), "",
                    New SettingInputNumerical(True, 10, _myコントロール情報.小数桁_数量, InputNumerical.TextDisplayModeType.AdjustFontWidth)))
        'A-CUST20211110_01↑

        'D-CUST20211110_01↓
        'AddItemInfo(New ColumnInfo(
        '            退避情報型.明細項目型.単価.ToString, GetColSize(15), 退避情報型.明細項目型.単価.ToString, 0, False, "0",
        '            OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Right,
        '            OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
        '            GetTabIndex(退避情報型.明細項目型.単価.ToString), "",
        '            New SettingInputNumerical(True, 8, _myコントロール情報.小数桁_売上単価)))
        'D-CUST20211110_01↑
        'A-CUST20211110_01↓
        AddItemInfo(New ColumnInfo(
                    退避情報型.明細項目型.単価.ToString, GetColSize(15), 退避情報型.明細項目型.単価.ToString, 0, False, "0",
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Right,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    GetTabIndex(退避情報型.明細項目型.単価.ToString), "",
                    New SettingInputNumerical(True, 10, _myコントロール情報.小数桁_売上単価, InputNumerical.TextDisplayModeType.AdjustFontWidth)))
        'A-CUST20211110_01↑

        'D-CUST20211110_01↓
        'AddItemInfo(New ColumnInfo(
        '            退避情報型.明細項目型.金額.ToString, GetColSize(15), 退避情報型.明細項目型.金額.ToString, 0, False, "0",
        '            OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Right,
        '            OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
        '            GetTabIndex(退避情報型.明細項目型.金額.ToString), "",
        '            New SettingInputNumerical(True, 9, 0)))
        'D-CUST20211110_01↑
        'A-CUST20211110_01↓
        AddItemInfo(New ColumnInfo(
                    退避情報型.明細項目型.金額.ToString, GetColSize(15), 退避情報型.明細項目型.金額.ToString, 0, False, "0",
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Right,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    GetTabIndex(退避情報型.明細項目型.金額.ToString), "",
                    New SettingInputNumerical(True, 10, 0)))
        'A-CUST20211110_01↑

        AddItemInfo(New ColumnInfo(
                    退避情報型.明細項目型.行摘要.ToString, GetColSize(24), 退避情報型.明細項目型.行摘要.ToString, 0, False, "",
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Left,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    GetTabIndex(退避情報型.明細項目型.行摘要.ToString),
                    New SettingInputText(24, OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CustomLength,
                                         OSK.X1.Foundation.Controls.InputText.ImeModeType.Hiragana, False, False, True, True, True, True, True, True, True, True, True)))

        AddItemInfo(New ColumnInfo(
                   退避情報型.明細項目型.改頁.ToString, GetColSize(4), 退避情報型.明細項目型.改頁.ToString, 0, False, "",
                   OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                   OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                   GetTabIndex(退避情報型.明細項目型.改頁.ToString),
                   New SettingCheckBox("")))

        'A-CUST20251104↓
        'If CType(InitInfo.Item("プログラム専用.FieldBuilder.明細.有効"), Boolean) Then    'D-CUST20260407
        If CType(InitInfo.Item("プログラム専用.FieldBuilder.明細.有効"), Boolean) AndAlso Not _allMeisaiConfigured Then  'A-CUST20260407 全30配置時は追加しない
            AddItemInfo(New ColumnInfo(
                    退避情報型.明細項目型.FieldBuilder.ToString, GetColSize(4), "", 0, False, "",
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Left,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                   GetTabIndex(退避情報型.明細項目型.FieldBuilder.ToString),
                    New SettingCommandButton()))
        End If
        'A-CUST20251104↑

    End Sub

    ''' <summary>
    ''' TabIndex定義
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetUpItemTabIndex()

        _tabIndex = New Hashtable
        _tabIndex.Add("", -1)
        _tabIndex.Add(退避情報型.明細項目型.行.ToString, _tabIndex.Count)
        _tabIndex.Add(退避情報型.明細項目型.区分.ToString, _tabIndex.Count)
        _tabIndex.Add(退避情報型.明細項目型.商品コード.ToString, _tabIndex.Count)
        _tabIndex.Add(退避情報型.明細項目型.商品名.ToString, _tabIndex.Count)
        _tabIndex.Add(退避情報型.明細項目型.課税区分.ToString, _tabIndex.Count)
        _tabIndex.Add(退避情報型.明細項目型.単位.ToString, _tabIndex.Count)
        _tabIndex.Add(退避情報型.明細項目型.倉庫コード.ToString, _tabIndex.Count)
        _tabIndex.Add(退避情報型.明細項目型.数量.ToString, _tabIndex.Count)
        _tabIndex.Add(退避情報型.明細項目型.原単価.ToString, _tabIndex.Count)
        _tabIndex.Add(退避情報型.明細項目型.原価金額.ToString, _tabIndex.Count)
        _tabIndex.Add(退避情報型.明細項目型.単価.ToString, _tabIndex.Count)
        _tabIndex.Add(退避情報型.明細項目型.金額.ToString, _tabIndex.Count)
        _tabIndex.Add(退避情報型.明細項目型.行摘要.ToString, _tabIndex.Count)
        _tabIndex.Add(退避情報型.明細項目型.小計.ToString, _tabIndex.Count)
        _tabIndex.Add(退避情報型.明細項目型.改頁.ToString, _tabIndex.Count)
        'If CType(InitInfo.Item("プログラム専用.FieldBuilder.明細.有効"), Boolean) Then    'D-CUST20260407
        If CType(InitInfo.Item("プログラム専用.FieldBuilder.明細.有効"), Boolean) AndAlso Not _allMeisaiConfigured Then  'A-CUST20260407 
            _tabIndex.Add(退避情報型.明細項目型.FieldBuilder.ToString, _tabIndex.Count)   'A-CUST20251104
        End If
        _最終項目TabIndex = _tabIndex.Count

    End Sub

    'A-CUST20260407↓
    ''' <summary>
    ''' SetUpDetailItemInfoLine1/2 と同じ GetColSize 引数を使って各行の合計ピクセル幅を計算し、
    ''' _lineWidthLine1 / _lineWidthLine2 に保持する。
    ''' SetUpDetailItemInfo の完了後に呼び出すこと。
    ''' </summary>
    Private Sub ComputeLineWidths()
        ' --- Line1（折り返し 1 行目）の合計幅 ---
        _lineWidthLine1 =
            GetColSize(4) +      ' 行
            GetColSize(4) +      ' 区分
            GetColSize(22, 0) +  ' 商品コード
            GetColSize(3, 0) +   ' 課税区分
            GetColSize(26, 4) +  ' 課税区分名
            GetColSize(6, 0) +   ' 倉庫コード
            GetColSize(8, 2) +   ' 倉庫名
            GetColSize(15) +     ' 原単価
            GetColSize(15) +     ' 原価金額
            GetColSize(24) +     ' ラベル1_01
            GetColSize(4)        ' 小計
        If CType(InitInfo.Item("プログラム専用.FieldBuilder.明細.有効"), Boolean) AndAlso Not _allMeisaiConfigured Then
            _lineWidthLine1 += GetColSize(4)  ' ラベル1_02
        End If

        ' --- Line2（折り返し 2 行目）の合計幅 ---
        _lineWidthLine2 =
            GetColSize(4) +      ' ラベル2_01
            GetColSize(4) +      ' 区分名
            GetColSize(48, 2) +  ' 商品名
            GetColSize(4) +      ' 単位
            GetColSize(15) +     ' 数量
            GetColSize(15) +     ' 単価
            GetColSize(15) +     ' 金額
            GetColSize(24) +     ' 行摘要
            GetColSize(4)        ' 改頁
        If CType(InitInfo.Item("プログラム専用.FieldBuilder.明細.有効"), Boolean) AndAlso Not _allMeisaiConfigured Then
            _lineWidthLine2 += GetColSize(4)  ' FieldBuilder ボタン
        End If
    End Sub
    'A-CUST20260407↑

    ''' <summary>
    ''' カラム幅の算出
    ''' </summary>
    ''' <param name="maxlength"></param>
    ''' <param name="padWidth"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetColSize(ByVal maxlength As Integer, Optional ByVal padWidth As Integer = 0) As Integer
        Dim utilitty As OSK.X1.Foundation.Utility.UserInterface.WidthCalculator
        utilitty = New OSK.X1.Foundation.Utility.UserInterface.WidthCalculator
        Return utilitty.GetSize(_gridEntry, maxlength, padWidth + 1, 0).Width
    End Function

    ''' <summary>
    ''' TabIndexの取得
    ''' </summary>
    ''' <param name="key"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetTabIndex(ByVal key As String) As Integer
        Dim tabIndex As Integer = 0

        If _tabIndex.Contains(key) Then
            tabIndex = CInt(_tabIndex(key))
        End If

        Return tabIndex

    End Function

#End Region

End Class
