Public Class ExpandItemHeaderColumnInfoList
    Inherits ColumnInfoListBase

    Private _gridEntry As OSK.X1.Foundation.SimpleControl.GridEdit

    Sub New()
        MyBase.New(New Hashtable)
    End Sub

    ''' <summary>
    ''' 条件リストに基づき GridEdit の列を定義する
    ''' （画面表示=True かつ表示順ソート済みのリストを渡すこと）
    ''' </summary>
    Friend Sub SetHeaderGrid(ByVal gridEntry As OSK.X1.Foundation.SimpleControl.GridEdit,
                             ByVal items As List(Of ExpandItemParam.FieldBuilder定義型))
        _gridEntry = gridEntry
        Dim tabIdx As Integer = 1
        For Each item As ExpandItemParam.FieldBuilder定義型 In items
            Dim tabIndexValue As Integer = If(item.入力可否 = 0, -1, tabIdx)
            AddColumn(item, tabIndexValue)
            If item.入力可否 <> 0 Then tabIdx += 1
        Next
    End Sub

    Private Sub AddColumn(ByVal item As ExpandItemParam.FieldBuilder定義型, ByVal tabIndexValue As Integer)
        ' DB列名を CUSRE11Kxxx 形式に変換（K001 → CUSRE11K001）
        Dim kNum As Integer = CInt(item.DB列名.TrimStart("K"c))
        Dim colName As String = "CUSRE11K" & kNum.ToString("D3")

        'Grid列幅: 表示桁数 > 0 で表示桁数>64であれば64固定、でなければ専用値、でなければ固定最小値を設定
        Dim displayWidth As Integer = If(item.表示桁数 > 0, If(item.表示桁数 > 64, 64, item.表示桁数), 16)

        Dim colWidth As Integer = GetColSize(displayWidth)

        Select Case item.属性
            Case ExpandItemParam.属性型.数値
                ' 数値型（ColumnInfo 11引数版: defaultValue付き + SettingInputNumerical）
                AddItemInfo(New ColumnInfo(
                    colName, colWidth, item.タイトル, 0, False, "0",
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Right,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    tabIndexValue, "",
                    New SettingInputNumerical(False, item.桁数, item.小数)))
            Case ExpandItemParam.属性型.日付
                AddItemInfo(New ColumnInfo(
                    colName, colWidth, item.タイトル, 0, False, "",
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Right,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    tabIndexValue,
                    New SettingDate(InputDate.DisplayFormatType.YYYY, InputDate.DisplayItemsType.YearMonthDay, True, CType(item.区切り文字, InputDate.SeparatorType), True)))

            Case ExpandItemParam.属性型.日付_年月
                AddItemInfo(New ColumnInfo(
                    colName, colWidth, item.タイトル, 0, False, "",
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Right,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    tabIndexValue,
                    New SettingDate(InputDate.DisplayFormatType.YYYY, InputDate.DisplayItemsType.YearMonth, True, CType(item.区切り文字, InputDate.SeparatorType), True)))

            Case ExpandItemParam.属性型.日付_年度
                AddItemInfo(New ColumnInfo(
                    colName, colWidth, item.タイトル, 0, False, "",
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Right,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    tabIndexValue,
                    New SettingDate(InputDate.DisplayFormatType.YYYY, InputDate.DisplayItemsType.Year, True, CType(item.区切り文字, InputDate.SeparatorType), True)))

            Case ExpandItemParam.属性型.全角文字
                ' 全角テキスト（ColumnInfo 10引数版: SettingInputText + IME On）
                AddItemInfo(New ColumnInfo(
                    colName, colWidth, item.タイトル, 0, False, "",
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Left,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    tabIndexValue,
                    New SettingInputText(item.桁数,
                        OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CustomLength,
                        OSK.X1.Foundation.Controls.InputText.ImeModeType.Hiragana,
                        False, False, True, True, True, True, True, True, True, True, True,
                        OSK.X1.Foundation.Controls.Grid.Common.FocusCaretPosType.Left,
                        OSK.X1.Foundation.Controls.InputText.TextDisplayModeType.Normal,
                        True)))

                    'A-CUST20260501↓
            Case ExpandItemParam.属性型.参照定義コード
                If item.タイプ = 0 Then
                    AddItemInfo(New ColumnInfo(
                  colName, colWidth, item.タイトル, 0, False, "",
                  OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Left,
                   OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                   tabIndexValue,
                  New SettingInputText(item.桁数,
                      OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CustomLength,
                      OSK.X1.Foundation.Controls.InputText.ImeModeType.Off,
                      False, True, False, False, False, False, False, True, False, False, False,
                      OSK.X1.Foundation.Controls.Grid.Common.FocusCaretPosType.Left,
                      OSK.X1.Foundation.Controls.InputText.TextDisplayModeType.Normal,
                      True)))
                Else
                    AddItemInfo(New ColumnInfo(
                  colName, colWidth, item.タイトル, 0, False, "",
                  OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Left,
                   OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                   tabIndexValue,
                  New SettingInputText(item.桁数,
                      OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CustomLength,
                      OSK.X1.Foundation.Controls.InputText.ImeModeType.Off,
                      False, False, False, False, True, True, False, True, True, True, False,
                      OSK.X1.Foundation.Controls.Grid.Common.FocusCaretPosType.Left,
                      OSK.X1.Foundation.Controls.InputText.TextDisplayModeType.Normal,
                      True)))
                End If

                'A-CUST20260501↑
            Case Else
                ' 半角文字(2)
                AddItemInfo(New ColumnInfo(
                    colName, colWidth, item.タイトル, 0, False, "",
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Left,
                     OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                     tabIndexValue,
                    New SettingInputText(item.桁数,
                        OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CustomLength,
                        OSK.X1.Foundation.Controls.InputText.ImeModeType.Off,
                        False, False, False, False, True, True, False, True, True, True, True,
                        OSK.X1.Foundation.Controls.Grid.Common.FocusCaretPosType.Left,
                        OSK.X1.Foundation.Controls.InputText.TextDisplayModeType.Normal,
                        True)))
        End Select
    End Sub

    ''' <summary>
    ''' 文字数 → ピクセル幅変換（既存 ColumnInfoList と同じ実装）
    ''' </summary>
    Private Function GetColSize(ByVal maxlength As Integer,
                                Optional ByVal padWidth As Integer = 0) As Integer
        Dim util As New OSK.X1.Foundation.Utility.UserInterface.WidthCalculator
        Return util.GetSize(_gridEntry, maxlength, padWidth + 1, 0).Width
    End Function

End Class