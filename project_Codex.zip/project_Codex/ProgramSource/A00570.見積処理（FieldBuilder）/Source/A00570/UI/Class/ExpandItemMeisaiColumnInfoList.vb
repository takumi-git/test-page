﻿'A-CUST20260407↓
Public Class ExpandItemMeisaiColumnInfoList

    Private _gridEntry As OSK.X1.Foundation.SimpleControl.GridEdit
    Private _columnInfos As New List(Of ColumnInfo)()
    Private _expandItemLineStartColumnNames As New List(Of String)()
    Private _expandItemLineStartDataColumnNames As New List(Of String)()

    Private _expandItemOrderedItems As New List(Of ExpandItemParam.FieldBuilder定義型)() '行位置/表示順ソート後の実際の列表示順を保持

    'A-CUST20260407↓
    Private _expandItemLineFillerColumnNames As New List(Of String)()
    Private _expandItemLineFillerWidths As New List(Of Integer)()
    'A-CUST20260407↑

    ''' <summary>
    ''' 折り返し行ごとの先頭列名リスト（"CUSRE12Kxxx" 形式）。
    ''' 要素数 = FB列の折り返し行数。ColumnInfoList.AppendFBColumns() に渡す。
    ''' </summary>
    Friend ReadOnly Property ExpandItemLineStartColumnNames As List(Of String)
        Get
            Return _expandItemLineStartColumnNames
        End Get
    End Property

    ''' <summary>生成された ColumnInfo リスト（ColumnInfoList.AppendFBColumns に渡す）</summary>
    Friend ReadOnly Property ColumnInfos As List(Of ColumnInfo)
        Get
            Return _columnInfos
        End Get
    End Property

    ''' <summary>
    ''' 折り返し行ごとの先頭データ列名リスト（"CUSRE12Kxxx" 形式）。
    ''' GridView 用の行境界判定に使用（スペーサー列を含まない）。
    ''' </summary>
    Friend ReadOnly Property ExpandItemLineStartDataColumnNames As List(Of String)
        Get
            Return _expandItemLineStartDataColumnNames
        End Get
    End Property

    ''' <summary>
    ''' 行位置/表示順ソート後の実際の列表示順を保持する項目リスト。
    ''' </summary>
    Friend ReadOnly Property ExpandItemOrderedItems As List(Of ExpandItemParam.FieldBuilder定義型)
        Get
            Return _expandItemOrderedItems
        End Get
    End Property


    'A-CUST20260407↓
    ''' <summary>
    ''' 折り返し行ごとの filler 列名リスト（"FBFILLER_Lxx" 形式）。
    ''' filler がない行は空文字を格納する。
    ''' </summary>
    Friend ReadOnly Property ExpandItemLineFillerColumnNames As List(Of String)
        Get
            Return _expandItemLineFillerColumnNames
        End Get
    End Property

    ''' <summary>
    ''' 折り返し行ごとの filler 幅リスト。
    ''' filler がない行は 0 を格納する。
    ''' </summary>
    Friend ReadOnly Property ExpandItemLineFillerWidths As List(Of Integer)
        Get
            Return _expandItemLineFillerWidths
        End Get
    End Property
    'A-CUST20260407↑


    ''' <summary>
    ''' GridEdit と FB定義リストを受け取り、明細Grid用の ColumnInfo を生成する。
    ''' maxLineWidth には DetailGridEdit.Width（ピクセル）を渡すこと。
    ''' FieldBuilder項目は行位置・表示順に従って配置する。
    ''' maxLineWidth は filler 列の幅計算に使用する。
    ''' </summary>
    Friend Sub SetMeisaiGrid(ByVal gridEntry As OSK.X1.Foundation.SimpleControl.GridEdit,
                              ByVal items As List(Of ExpandItemParam.FieldBuilder定義型),
                              ByVal tabIndexStart As Integer,
                              ByVal maxLineWidth As Integer)
        _gridEntry = gridEntry
        _columnInfos.Clear()
        _expandItemLineStartColumnNames.Clear()
        _expandItemLineStartDataColumnNames.Clear()
        _expandItemOrderedItems.Clear() '行位置/表示順ソート後の実際の列表示順を保持するリストの初期化
        'A-CUST20260501↓
        _expandItemLineFillerColumnNames.Clear()
        _expandItemLineFillerWidths.Clear()
        'A-CUST20260501↑        
        ' If items.Count = 0 Then Return 'D-CUST20260501
        If items Is Nothing OrElse items.Count = 0 Then Return 'A-CUST20260501

        '各 FB 行先頭のスペーサー2列分
        Dim spWidth As Integer = GetColSize(4) * 2
        Dim dataWidthLimit As Integer = maxLineWidth - spWidth


        'FieldBuilderLayoutHelper でソート・行振り分け（A00570から共通化）
        Dim layoutHelper As New FieldBuilderLayoutHelper()
        Dim sorted As List(Of ExpandItemParam.FieldBuilder定義型) =
            layoutHelper.SortItems(items)
        'D-CUST20260501↓
        ' Dim rows As List(Of List(Of ExpandItemParam.FieldBuilder定義型)) =
        '     layoutHelper.DistributeIntoRows(
        '         sorted, dataWidthLimit, Function(it) GetActualColumnWidth(it))
        'D-CUST20260501↑
        'A-CUST20260501↓
        Dim rows As List(Of List(Of ExpandItemParam.FieldBuilder定義型)) =
            layoutHelper.DistributeIntoRows(
                sorted,
                Function(it As ExpandItemParam.FieldBuilder定義型) As Integer
                    Return GetActualColumnWidth(it)
                End Function)
        'A-CUST20260501↑
        'ColumnInfo 生成（行順 → スペーサー列 → データ列）
        Dim tabIdx As Integer = tabIndexStart
        For rowIdx As Integer = 0 To rows.Count - 1
            Dim rowItems As List(Of ExpandItemParam.FieldBuilder定義型) = rows(rowIdx)
            If rowItems.Count = 0 Then Continue For

            ' スペーサー列（各 FB 折り返し行の先頭）
            Dim spIdx As Integer = _expandItemLineStartColumnNames.Count
            Dim spRowName As String = "FBSPROW" & spIdx.ToString("D2")
            Dim spSecName As String = "FBSPSEC" & spIdx.ToString("D2")
            _expandItemLineStartColumnNames.Add(spRowName)
            _columnInfos.Add(New ColumnInfo(
                spRowName, GetColSize(4), "", 0, False, "",
                OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Left,
                OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                -1, New SettingLabel()))
            _columnInfos.Add(New ColumnInfo(
                spSecName, GetColSize(4), "", 0, False, "",
                OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Left,
                OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                -1, New SettingLabel()))

            ' 先頭データ列名（GridView 行境界判定用）
            Dim firstKNum As Integer = CInt(rowItems(0).DB列名.TrimStart("K"c))
            _expandItemLineStartDataColumnNames.Add("CUSRE12K" & firstKNum.ToString("D3"))

            ' データ列
            Dim usedWidth As Integer = 0    'A-CUST20260407
            For Each rowItem As ExpandItemParam.FieldBuilder定義型 In rowItems
                _expandItemOrderedItems.Add(rowItem)  'ソート後の順序を保持
                Dim tabIndexValue As Integer = If(rowItem.入力可否 = 0, -1, tabIdx)
                '_columnInfos.Add(CreateColumnInfo(rowItem, tabIndexValue))    'D-CUST20260407
                'A-CUST20260407↓
                Dim ci As ColumnInfo = CreateColumnInfo(rowItem, tabIndexValue)
                _columnInfos.Add(ci)
                usedWidth += CInt(ci.ColumnWidth)
                'A-CUST20260407↑
                If rowItem.入力可否 <> 0 Then tabIdx += 1
            Next
            'A-CUST20260407↓
            '合計幅に余分なスペースがある場合は、末尾に 1 列の空白ラベル列を追加する
            Dim fillerWidth As Integer = dataWidthLimit - usedWidth
            If fillerWidth > 0 Then
                _columnInfos.Add(New ColumnInfo(
                "FBFILLER_L" & rowIdx.ToString("D2"),
                fillerWidth, "", 0, False, "",
                OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Left,
                OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                -1, New SettingLabel()))


                _expandItemLineFillerColumnNames.Add("FBFILLER_L" & rowIdx.ToString("D2"))
                _expandItemLineFillerWidths.Add(fillerWidth)
            Else
                _expandItemLineFillerColumnNames.Add("")
                _expandItemLineFillerWidths.Add(0)
            End If
            'A-CUST20260407↑
        Next
    End Sub

    Private Function CreateColumnInfo(ByVal item As ExpandItemParam.FieldBuilder定義型,
                                       ByVal tabIndexValue As Integer) As ColumnInfo
        ' DB列名を CUSRE12Kxxx 形式に変換（K001 → CUSRE12K001）
        Dim kNum As Integer = CInt(item.DB列名.TrimStart("K"c))
        Dim colName As String = "CUSRE12K" & kNum.ToString("D3")

        Dim colWidth As Integer = GetActualColumnWidth(item)

        Select Case item.属性
            Case ExpandItemParam.属性型.数値
                '数値型
                Return New ColumnInfo(
                    colName, colWidth, item.タイトル, 0, False, "0",
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Right,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    tabIndexValue, "",
                    New SettingInputNumerical(False, item.桁数, item.小数))

            Case ExpandItemParam.属性型.日付
                '日付型(年月日)
                Return New ColumnInfo(
                    colName, colWidth, item.タイトル, 0, False, "",
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Right,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    tabIndexValue,
                    New SettingDate(InputDate.DisplayFormatType.YYYY, InputDate.DisplayItemsType.YearMonthDay, True, CType(item.区切り文字, InputDate.SeparatorType), True))

            Case ExpandItemParam.属性型.日付_年月
                '日付型(年月)
                Return New ColumnInfo(
                    colName, colWidth, item.タイトル, 0, False, "",
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Right,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    tabIndexValue,
                    New SettingDate(InputDate.DisplayFormatType.YYYY, InputDate.DisplayItemsType.YearMonth, True, CType(item.区切り文字, InputDate.SeparatorType), True))

            Case ExpandItemParam.属性型.日付_年度
                '日付型(年度）
                Return New ColumnInfo(
                    colName, colWidth, item.タイトル, 0, False, "",
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Right,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    tabIndexValue,
                    New SettingDate(InputDate.DisplayFormatType.YYYY, InputDate.DisplayItemsType.Year, True, CType(item.区切り文字, InputDate.SeparatorType), True))

            Case ExpandItemParam.属性型.全角文字,
                 ExpandItemParam.属性型.画像,
                 ExpandItemParam.属性型.実行ファイル,
                 ExpandItemParam.属性型.ファイル,
                 ExpandItemParam.属性型.フォルダ,
                 ExpandItemParam.属性型.URL,
                 ExpandItemParam.属性型.メールアドレス
                '文字型
                Return New ColumnInfo(
                    colName, colWidth, item.タイトル, 0, False, "",
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Left,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    tabIndexValue,
                    New SettingInputText(item.桁数,
                        OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CustomLength,
                        OSK.X1.Foundation.Controls.InputText.ImeModeType.Hiragana,
                        False, False, True, True, True, True, True, True, True, True, True,
                        OSK.X1.Foundation.Controls.Grid.Common.FocusCaretPosType.Left,
                        OSK.X1.Foundation.Controls.InputText.TextDisplayModeType.Normal,
                        True))

                'A-CUST20260501↓
            Case ExpandItemParam.属性型.参照定義コード
                If item.タイプ = 0 Then
                    '数字コード
                    Return New ColumnInfo(
                        colName, colWidth, item.タイトル, 0, False, "",
                        OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Left,
                        OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                        tabIndexValue,
                        New SettingInputText(item.桁数,
                            OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CustomLength,
                            OSK.X1.Foundation.Controls.InputText.ImeModeType.Off,
                            False, True, False, False, False, False, False, True, False, False, False,
                            OSK.X1.Foundation.Controls.Grid.Common.FocusCaretPosType.Left,
                            OSK.X1.Foundation.Controls.InputText.TextDisplayModeType.Normal,
                            True))
                Else
                    '文字コード
                    Return New ColumnInfo(
                        colName, colWidth, item.タイトル, 0, False, "",
                        OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Left,
                        OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                        tabIndexValue,
                        New SettingInputText(item.桁数,
                            OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CustomLength,
                            OSK.X1.Foundation.Controls.InputText.ImeModeType.Off,
                            False, False, False, False, True, True, False, True, True, True, False,
                            OSK.X1.Foundation.Controls.Grid.Common.FocusCaretPosType.Left,
                            OSK.X1.Foundation.Controls.InputText.TextDisplayModeType.Normal,
                            True))
                End If

                'A-CUST20260501↑

            Case Else
                ' 半角文字・参照定義コード
                Return New ColumnInfo(
                    colName, colWidth, item.タイトル, 0, False, "",
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Left,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    tabIndexValue,
                    New SettingInputText(item.桁数,
                        OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CustomLength,
                        OSK.X1.Foundation.Controls.InputText.ImeModeType.Off,
                        False, False, False, False, True, True, False, True, True, True, True,
                        OSK.X1.Foundation.Controls.Grid.Common.FocusCaretPosType.Left,
                        OSK.X1.Foundation.Controls.InputText.TextDisplayModeType.Normal,
                        True))
        End Select
    End Function

    ''' <summary>
    ''' 属性型に応じた実際の列幅（ピクセル）を返す。
    ''' SetMeisaiGrid の折り返し判定と CreateColumnInfo の列幅設定で同じ値を使うため共用する。
    ''' </summary>
    Private Function GetActualColumnWidth(ByVal item As ExpandItemParam.FieldBuilder定義型) As Integer
        'D-CUST20260407↓ '2026/04/22 打ち合わせ後折り返し無しのためコメントアウト        'Select Case item.属性
        '    Case ExpandItemParam.属性型.日付
        '        Return GetColSize(16)
        '    Case ExpandItemParam.属性型.日付_年月
        '        Return GetColSize(12)
        '    Case ExpandItemParam.属性型.日付_年度
        '        Return GetColSize(8)
        '    Case Else
        '        '日付項目以外に関して、表示桁数を持たない場合はデフォルト24桁。表示桁数指定時も上限24桁。
        '        Dim displayWidth As Integer = Math.Min(If(item.表示桁数 > 0, item.表示桁数, item.桁数), 16)
        '        Return GetColSize(displayWidth)
        'End Select
        'D-CUST20260407↑ '2026/04/22 打ち合わせ後折り返し無しのためコメントアウト
        '明細は桁数と行数ｍ表示順を必ず設定する方針なので設定している正しく、行位置を配置していればこれでOK
        '表示桁数が >0 であり、64を超えている場合は64、そうでない場合は設定した値。<0である場合は固定値16
        Dim displayWidth As Integer = If(item.表示桁数 > 0, If(item.表示桁数 > 64, 64, item.表示桁数), 16)
        Return GetColSize(displayWidth)

    End Function

    ''' <summary>
    ''' 文字数 → ピクセル幅変換（FBHeaderColumnInfoList と同じ実装）
    ''' </summary>
    Private Function GetColSize(ByVal maxlength As Integer,
                                Optional ByVal padWidth As Integer = 0) As Integer
        Dim util As New OSK.X1.Foundation.Utility.UserInterface.WidthCalculator
        Return util.GetSize(_gridEntry, maxlength, padWidth + 1, 0).Width
    End Function

End Class
'A-CUST20260407↑