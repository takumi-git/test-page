﻿Public Class Initializer
    Inherits InitializerBase

    Public Overrides Function Startup(ByVal connection As System.Data.Common.DbConnection, ByRef initInfo As System.Collections.IDictionary, ByRef resultMessage As String, ByRef checkInfo As Foundation.ExecuteCheck.IExecuteCheckInfo) As Foundation.Startup.IStarter.AccessResultType

        Dim accessResultType As Startup.IStarter.AccessResultType = IStarter.AccessResultType.成功

        '排他処理   
        If Me.システム環境情報.プログラム情報.枝番 <> 100 Then
            Dim executeControlerForStartup As IExecuteControlerForStartup = New ExecuteControlerForStartup
            executeControlerForStartup.Initialize(Me)
            If executeControlerForStartup.CheckExecution(checkInfo, CheckCondition.通常チェック) = ExecuteCheckResult.排他エラー Then
                Return IStarter.AccessResultType.同時実行不可
            End If
        End If

        'コントロールテーブル情報取得
        initInfo.Add(IControlReader.テーブル一覧型.コントロールテーブル.ToString, GetControlInfo(IControlReader.テーブル一覧型.コントロールテーブル))
        initInfo.Add(IControlReader.テーブル一覧型.日付管理テーブル.ToString, GetControlInfo(IControlReader.テーブル一覧型.日付管理テーブル))

        '消費税情報取得
        Dim taxControlReader As New OSK.X1.OTS.LIB.TaxControl.DataAccess.CUSTaxControlReader
        taxControlReader.Initialize(Me)
        taxControlReader.SetTaxControlInfo(connection, initInfo)

        'プログラム個別情報取得
        SetPrivateInitInfo(initInfo, connection)

        '見積伝票－印刷情報取得
        SetPrintInfo(initInfo, connection)

        '機能制御情報取得
        SetOperationSecurityInfo(initInfo, connection)

        'A-CUST20251104↓
        ' FieldBuilderXMLの存在チェック（追加）
        SetExtensionItemInfo(initInfo)

        'A-CUST20251104↑

        Return accessResultType

    End Function

    ''' <summary>
    ''' プログラム個別情報をInitInfoに設定
    ''' </summary>
    ''' <param name="initInfo"></param>
    ''' <param name="connection"></param>
    ''' <remarks></remarks>
    Private Sub SetPrivateInitInfo(ByRef initInfo As System.Collections.IDictionary, ByVal connection As System.Data.Common.DbConnection)

        initInfo.Add("プログラム専用.空のデータテーブル", GetEmptyDenpyou)
        initInfo.Add("プログラム専用.空の見積書データ", GetEmpty見積書(connection, initInfo))
    End Sub

    ''' <summary>
    ''' 見積書印刷情報取得
    ''' </summary>
    ''' <param name="initInfo"></param>
    ''' <param name="connection"></param>
    ''' <remarks></remarks>
    Private Sub SetPrintInfo(
                            ByRef initInfo As System.Collections.IDictionary,
                            ByVal connection As System.Data.Common.DbConnection)

        If Me.システム環境情報.プログラム情報.枝番 = 100 Then
            Exit Sub
        End If

        Dim printItemInfoReader As New PrintItemReader
        printItemInfoReader.Initialize(Me)

        printItemInfoReader.Read帳票タイトル識別(connection, initInfo, "見積書")

    End Sub

    Private Sub SetOperationSecurityInfo(ByRef initInfo As System.Collections.IDictionary, ByVal connection As System.Data.Common.DbConnection)

        Dim operationSecurity As New CMN.LIB.OperationSecurity.Reader
        operationSecurity.Initialize(Me)
        operationSecurity.Read印刷クリップボードコピー区分(connection, initInfo)

    End Sub

    Private Function GetEmptyDenpyou() As DataSet

        Dim exDA As Exception = Nothing

        Dim param As New ReadParam
        param.Container(ReadParam.項目名型.読込種別) = ReadParam.読込種別型.一伝票
        param.Container(ReadParam.項目名型.伝票番号) = -1

        Dim dataAccess As IDenpyouReader
        dataAccess = New DenpyouReader
        dataAccess.Initialize(SettingInfo)
        Return dataAccess.DenpyouRead(IDenpyouReader.テーブル一覧型.見積伝票, param)

    End Function

    ''' <summary>
    ''' 見積書データ読込
    ''' </summary>
    ''' <param name="connection"></param>
    ''' <param name="initInfo"></param>
    ''' <returns></returns>
    ''' <remarks>空の見積書データを作成</remarks>
    Private Function GetEmpty見積書(
                                    ByVal connection As System.Data.Common.DbConnection,
                                    ByVal initInfo As System.Collections.IDictionary) As DataTable

        Dim makeSql As PrintSqlCreator
        Dim parameter As New ParamInfoList
        Dim sql As String = ""

        'パラメータセット
        Dim param As New ReadParam

        makeSql = New PrintSqlCreator
        makeSql.Initialize(Me, param)
        makeSql.MakeSQL即時発行用(sql, parameter)
        Dim table As DataTable = DataAccess.GetDataTable(connection, sql, parameter)

        Return table

    End Function

    Private Function GetControlInfo(ByVal targetTable As IControlReader.テーブル一覧型) As IDictionary

        Dim exDA As Exception = Nothing
        Dim param As New ReadParam

        Dim dataAccess As IControlReader
        dataAccess = New ControlReader
        dataAccess.Initialize(SettingInfo)

        Dim hashTable As IDictionary = New Hashtable
        Dim dataTable As DataTable = dataAccess.ControlRead(targetTable, param)

        If dataTable.Rows.Count > 0 Then
            Select Case targetTable
                Case IControlReader.テーブル一覧型.コントロールテーブル
                    For I As Integer = 0 To dataTable.Rows.Count - 1
                        hashTable.Add(dataTable.Rows(I).Item("CUSCE01001").ToString.Trim, dataTable.Rows(I).Item("CUSCE01002"))
                    Next
                Case IControlReader.テーブル一覧型.日付管理テーブル
                    For Each row As DataRow In dataTable.Rows
                        For Each column As DataColumn In dataTable.Columns
                            hashTable.Add(column.ColumnName, row(column.ColumnName))
                        Next
                    Next
            End Select

        End If

        Return hashTable

    End Function

    'A-CUST20251104↓
    ''' <summary>
    ''' FieldBuilderXMLの存在チェックを行い、initInfoに結果を設定する
    ''' </summary>
    ''' <param name="initInfo"></param>
    Private Sub SetExtensionItemInfo(ByRef initInfo As System.Collections.IDictionary)

        'D-CUST20251104↓ '2026/04/08
        '' App.config からアプリケーション設定データパスを取得
        'Dim basePath As String = System.Configuration.ConfigurationManager.AppSettings("アプリケーション設定データパス")

        '' 明細・ヘッダーのFieldBuilderXMLファイル名（固定名と仮定）
        'Dim detailXmlFile As String = "EO汎用_FieldBuilder_売上明細.xml"
        'Dim headerXmlFile As String = "EO汎用_FieldBuilder_売上伝票.xml"

        '' フルパスを構築
        'Dim detailXmlPath As String = System.IO.Path.Combine(basePath, detailXmlFile)
        'Dim headerXmlPath As String = System.IO.Path.Combine(basePath, headerXmlFile)

        '' ファイルの存在チェック
        'Dim isDetailEnabled As Boolean = System.IO.File.Exists(detailXmlPath)
        'Dim isHeaderEnabled As Boolean = System.IO.File.Exists(headerXmlPath)
        '' initInfo に結果を格納
        'initInfo("プログラム専用.FieldBuilder.明細.有効") = isDetailEnabled
        'initInfo("プログラム専用.FieldBuilder.ヘッダー.有効") = isHeaderEnabled
        'D-CUST20251104↑ '2026/04/08

        'A-CUST20251104↓ '2026/04/08
        Dim xmlFileExist As IXmlFileExist = New XmlFileExist

        ' initInfo に結果を格納
        initInfo("プログラム専用.FieldBuilder.明細.有効") = xmlFileExist.XmlDetailFileExist
        initInfo("プログラム専用.FieldBuilder.ヘッダー.有効") = xmlFileExist.XmlHeaderFileExist
        'A-CUST20251104↑ '2026/04/08

    End Sub

    'A-CUST20251104↑

End Class
