﻿'A-CUST20251104↓ '2026/04/08
Public Class XmlFileExist
    Inherits DataHandlerBase
    Implements IXmlFileExist

    Public Function XmlHeaderFileExist() As Boolean Implements IXmlFileExist.XmlHeaderFileExist
        ' App.config からアプリケーション設定データパスを取得
        Dim basePath As String = System.Configuration.ConfigurationManager.AppSettings("アプリケーション設定データパス")
        'ヘッダーのFieldBuilderXMLファイル名（固定名と仮定）
        Dim headerXmlFile As String = "EO汎用_FieldBuilder_売上伝票.xml"
        ' フルパスを構築
        Dim headerXmlPath As String = System.IO.Path.Combine(basePath, headerXmlFile)
        ' ファイルの存在チェック
        Dim isHeaderEnabled As Boolean = System.IO.File.Exists(headerXmlPath)

        Return isHeaderEnabled
    End Function

    Public Function XmlDetailFileExist() As Boolean Implements IXmlFileExist.XmlDetailFileExist
        ' App.config からアプリケーション設定データパスを取得
        Dim basePath As String = System.Configuration.ConfigurationManager.AppSettings("アプリケーション設定データパス")
        ' 明細のFieldBuilderXMLファイル名
        Dim detailXmlFile As String = "EO汎用_FieldBuilder_売上明細.xml"
        ' フルパスを構築
        Dim detailXmlPath As String = System.IO.Path.Combine(basePath, detailXmlFile)
        ' ファイルの存在チェック
        Dim isDetailEnabled As Boolean = System.IO.File.Exists(detailXmlPath)
        Return isDetailEnabled
    End Function
End Class

'A-CUST20251104↑ '2026/04/08