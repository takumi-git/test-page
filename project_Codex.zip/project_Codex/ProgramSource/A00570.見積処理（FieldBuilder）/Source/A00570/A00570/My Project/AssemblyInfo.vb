﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' アセンブリに関する一般情報は以下の属性セットをとおして制御されます。 
' アセンブリに関連付けられている情報を変更するには、
' これらの属性値を変更してください。

' アセンブリ属性の値を確認します。

<Assembly: AssemblyTitle("見積処理（FieldBuilder対応）")>
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyCompany("株式会社OSK")>
<Assembly: AssemblyProduct("")>
<Assembly: AssemblyCopyright("")>
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)> 

'このプロジェクトが COM に公開される場合、次の GUID がタイプ ライブラリの ID になります。
<Assembly: Guid("ea6e5f8e-441a-4934-a519-c0cb8d8e5676")> 

' アセンブリのバージョン情報は、以下の 4 つの値で構成されています:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' すべての値を指定するか、下のように '*' を使ってビルドおよびリビジョン番号を 
' 既定値にすることができます:

<Assembly: AssemblyVersion("2.0.0.0")>
<Assembly: AssemblyInformationalVersion("2.0.0.0")>
<Assembly: AssemblyFileVersion("92.0.9658.32535")>
