﻿'A-CUST20251104↓ '2026/04/08
Public Interface IXmlFileExist
    Inherits IBase
    Function XmlHeaderFileExist() As Boolean
    Function XmlDetailFileExist() As Boolean
End Interface
'A-CUST20251104↑
