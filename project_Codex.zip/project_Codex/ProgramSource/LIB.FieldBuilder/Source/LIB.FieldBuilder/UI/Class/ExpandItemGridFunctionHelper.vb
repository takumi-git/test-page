'A-CUST20260407↓
''' <summary>
''' FieldBuilder定義に基づき、グリッド列に登録すべきファンクション種別を返すヘルパー。
''' SubForm.InitializeFunction() と同じ属性型判定ロジックを共通化し、
''' A00570 等の画面側が最小限の記述でファンクション登録できるようにする。
''' </summary>
Public Class ExpandItemGridFunctionHelper

    Private _systdate As Integer = 0
    Private _userId As String = ""

    ''' <summary>
    ''' 予約語変換用の環境情報を設定する。
    ''' 計算式やマスター取得SQLで @SYSDATE/@USERID を使用する場合に必要。
    ''' </summary>
    Public Sub SetEnvironment(ByVal systdate As Integer, ByVal userId As String)
        _systdate = systdate
        _userId = If(userId, "")
    End Sub

    ''' <summary>グリッド列に登録可能なファンクション種別</summary>
    Public Enum GridFunctionKind
        ''' <summary>入力値クリア（明細=入力行クリア、ヘッダー=クリアに対応）</summary>
        クリア
        ''' <summary>参照定義コードで マスター検索=1 の場合に登録</summary>
        マスター検索
        ''' <summary>F9以下省略相当（行終了）</summary>
        行終了
        ''' <summary>計算式=1 かつ 入力可否=1 の場合に登録（F12再計算）</summary>
        再計算
        ''' <summary>画像/ファイル/フォルダ系でボタン使用=1 の場合に登録（F3参照）</summary>
        参照
        ''' <summary>画像/ファイル/フォルダ/URL/メール系でボタン使用=1 の場合に登録（F7開く）</summary>
        開く
    End Enum

    'A-CUST20260501↓
    ''' <summary>
    ''' DB列名（"K001" 等）から番号部分を整数で取得する。（内部用）
    ''' </summary>
    Private Function GetKNumber(ByVal dbColumnName As String) As Integer
        Return CInt(dbColumnName.TrimStart("K"c))
    End Function

    ''' <summary>
    ''' DB列名 + K付きプレフィックスで DB実列名を生成する。（内部用）
    ''' 例: dbColumnName="K001", prefix="CUSRE12K" → "CUSRE12K001"
    ''' </summary>
    Private Function ToCusreColumnName(
            ByVal dbColumnName As String,
            ByVal prefix As String) As String
        Return prefix & GetKNumber(dbColumnName).ToString("D3")
    End Function
    'A-CUST20260501↑

    ''' <summary>
    ''' ファイル選択ダイアログを表示し、選択パスを返す。キャンセルは String.Empty。
    ''' SubForm.OpenDialog のコアロジックを共通化。
    ''' </summary>
    Public Function ShowFileDialog(
            ByVal attr As ExpandItemParam.属性型,
            ByVal currentText As String,
            ByVal parentForm As System.Windows.Forms.IWin32Window
        ) As String

        Dim selectedPath As String = String.Empty
        Select Case attr
            Case ExpandItemParam.属性型.画像
                Using dlg As New System.Windows.Forms.OpenFileDialog()
                    dlg.InitialDirectory = currentText
                    dlg.Title = "画像ファイルを選択してください"
                    dlg.Filter = "画像(*.bmp,*.jpg,*.jpeg)|*.bmp;*.jpg;*.jpeg"
                    If dlg.ShowDialog(parentForm) = System.Windows.Forms.DialogResult.OK Then
                        selectedPath = dlg.FileName
                    End If
                End Using

            Case ExpandItemParam.属性型.実行ファイル
                Using dlg As New System.Windows.Forms.OpenFileDialog()
                    dlg.InitialDirectory = currentText
                    dlg.Title = "実行ファイルを選択してください"
                    dlg.Filter = "実行ファイル|*.exe;*.com;*.bat|すべてのファイル|*.*"
                    If dlg.ShowDialog(parentForm) = System.Windows.Forms.DialogResult.OK Then
                        selectedPath = dlg.FileName
                    End If
                End Using

            Case ExpandItemParam.属性型.ファイル
                Using dlg As New System.Windows.Forms.OpenFileDialog()
                    dlg.InitialDirectory = currentText
                    dlg.Title = "ファイルを選択してください"
                    dlg.Filter = "すべてのファイル|*.*"
                    If dlg.ShowDialog(parentForm) = System.Windows.Forms.DialogResult.OK Then
                        selectedPath = dlg.FileName
                    End If
                End Using

            Case ExpandItemParam.属性型.フォルダ
                Using dlg As New System.Windows.Forms.FolderBrowserDialog()
                    dlg.SelectedPath = currentText
                    dlg.Description = "フォルダを選択してください"
                    If dlg.ShowDialog(parentForm) = System.Windows.Forms.DialogResult.OK Then
                        selectedPath = dlg.SelectedPath
                    End If
                End Using
        End Select
        Return selectedPath

    End Function

    ''' <summary>
    ''' アプリ・URL・メールを起動する。成功時 True、エラー時 False を返す。
    ''' SubForm.OpenApp のコアロジックを共通化。
    ''' </summary>
    Public Function LaunchApp(
            ByVal attr As ExpandItemParam.属性型,
            ByVal value As String,
            ByVal parentForm As System.Windows.Forms.IWin32Window
        ) As Boolean

        Dim success As Boolean = True
        Try
            Select Case attr
                Case ExpandItemParam.属性型.画像
                    If value = "" Then
                        OSK.X1.Foundation.UserInterface.OSKMessageBox.Show(parentForm, "画像ファイルが指定されていません。", "FieldBuilder", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation)
                        Return False
                    End If
                    If Not CheckImageFileExtension(value) Then
                        OSK.X1.Foundation.UserInterface.OSKMessageBox.Show(parentForm, "対象の画像ファイルではありません。", "FieldBuilder", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation)
                        Return False
                    End If
                    System.Diagnostics.Process.Start(value)

                Case ExpandItemParam.属性型.実行ファイル
                    If value = "" Then
                        OSK.X1.Foundation.UserInterface.OSKMessageBox.Show(parentForm, "実行ファイルが指定されていません。", "FieldBuilder", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation)
                        Return False
                    End If
                    Try
                        Microsoft.VisualBasic.Shell(value, Microsoft.VisualBasic.AppWinStyle.NormalFocus)
                    Catch ex As Exception
                        OSK.X1.Foundation.UserInterface.OSKMessageBox.Show(parentForm, "指定されたファイルを実行できません。", "FieldBuilder", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation)
                        Return False
                    End Try

                Case ExpandItemParam.属性型.ファイル
                    If value = "" Then
                        OSK.X1.Foundation.UserInterface.OSKMessageBox.Show(parentForm, "ファイルが指定されていません。", "FieldBuilder", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation)
                        Return False
                    End If
                    System.Diagnostics.Process.Start(value)

                Case ExpandItemParam.属性型.フォルダ
                    If value = "" Then
                        OSK.X1.Foundation.UserInterface.OSKMessageBox.Show(parentForm, "フォルダが指定されていません。", "FieldBuilder", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation)
                        Return False
                    ElseIf Not System.IO.Directory.Exists(value) Then
                        OSK.X1.Foundation.UserInterface.OSKMessageBox.Show(parentForm, "指定されたフォルダは存在しません。", "FieldBuilder", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation)
                        Return False
                    End If
                    System.Diagnostics.Process.Start(value)

                Case ExpandItemParam.属性型.URL
                    If value = "" Then
                        OSK.X1.Foundation.UserInterface.OSKMessageBox.Show(parentForm, "URLが指定されていません。", "FieldBuilder", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation)
                        Return False
                    End If
                    Dim url As String = value
                    If Not url.ToLowerInvariant().StartsWith("http") Then
                        url = "http://" & url
                    End If
                    System.Diagnostics.Process.Start(url)

                Case ExpandItemParam.属性型.メールアドレス
                    If value = "" Then
                        OSK.X1.Foundation.UserInterface.OSKMessageBox.Show(parentForm, "メールアドレスが指定されていません。", "FieldBuilder", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation)
                        Return False
                    End If
                    System.Diagnostics.Process.Start("mailto:" & value)

            End Select
        Catch ex As Exception
            OSK.X1.Foundation.UserInterface.OSKMessageBox.Show(parentForm, ex.Message, "FieldBuilder", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Exclamation)
            success = False
        End Try
        Return success

    End Function

    Private Function CheckImageFileExtension(ByVal fileName As String) As Boolean
        Dim ext As String = System.IO.Path.GetExtension(fileName).ToUpperInvariant()
        Return (ext = ".BMP" OrElse ext = ".JPG" OrElse ext = ".JPEG")
    End Function

#Region "再計算（計算式実行）"

    Private ReadOnly _calc As New CalculateAnalysis()

    ''' <summary>
    ''' グリッドセルの計算式を実行し、計算結果を反映先項目へ反映する。
    ''' CurrentCol が計算式定義を持つ場合はその式を実行する。
    ''' 計算式定義を持たない場合は、補助的に CurrentCol の項目変数を反映先に持つ式を探して実行する。
    ''' </summary>
    ''' <param name="parentForm">呼び出し元ウィンドウ。計算エラー時のメッセージ表示に使用する。</param>
    ''' <param name="currentColName">現在処理中のDB実列名。例: "CUSRE11K001" または "CUSRE12K001"。</param>
    ''' <param name="allItems">同一グリッド上の FieldBuilder定義一覧。項目変数・計算式・反映先の解決に使用する。</param>
    ''' <param name="colNamePrefix">DB実列名のプレフィックス。"CUSRE11K" または "CUSRE12K" を指定する。</param>
    ''' <param name="getValueByCol">DB実列名を受け取り、現在のグリッド値を文字列で返すコールバック。</param>
    ''' <param name="setResultByCol">DB実列名と計算結果を受け取り、退避情報およびグリッドへ値を反映するコールバック。</param>
    Public Sub ExecuteGridCalc(
            ByVal parentForm As System.Windows.Forms.IWin32Window,
            ByVal currentColName As String,
            ByVal allItems As System.Collections.Generic.List(Of ExpandItemParam.FieldBuilder定義型),
            ByVal colNamePrefix As String,
            ByVal getValueByCol As System.Func(Of String, String),
            ByVal setResultByCol As System.Action(Of String, Object))

        If allItems Is Nothing OrElse allItems.Count = 0 Then Return

        ' 現在列に対応する FB 定義を検索
        Dim currentItem As ExpandItemParam.FieldBuilder定義型 = Nothing
        Dim currentFound As Boolean = False
        For Each item As ExpandItemParam.FieldBuilder定義型 In allItems
            If String.Equals(ToCusreColumnName(item.DB列名, colNamePrefix), currentColName, StringComparison.Ordinal) Then
                currentItem = item
                currentFound = True
                Exit For
            End If
        Next
        If Not currentFound Then Return

        ' ケース1: 現在列自体が計算式定義を持つ（式の起点）
        If HasCalcDef(currentItem) Then
            EvalAndApplyFormula(parentForm, currentItem, allItems, colNamePrefix, getValueByCol, setResultByCol)
            Return
        End If

        ' ケース2: 現在列の項目変数を反映先に持つ計算式列を探して実行
        Dim destVar As String = currentItem.項目変数.Trim()
        If String.IsNullOrEmpty(destVar) Then Return

        For Each srcItem As ExpandItemParam.FieldBuilder定義型 In allItems
            If srcItem.計算式 <> 1 Then Continue For
            If Not HasCalcDef(srcItem) Then Continue For
            If RefContainsVar(srcItem.計算式項目.反映先.Trim(), destVar) Then
                EvalAndApplyFormula(parentForm, srcItem, allItems, colNamePrefix, getValueByCol, setResultByCol)
            End If
        Next

    End Sub

    Private Function HasCalcDef(ByVal item As ExpandItemParam.FieldBuilder定義型) As Boolean
        If item.計算式 <> 1 Then Return False
        Try
            Dim formula As String = item.計算式項目.取得データ.Trim()
            Dim reflect As String = item.計算式項目.反映先.Trim()
            Return (formula.Length > 0 AndAlso reflect.Length > 0)
        Catch
            Return False
        End Try
    End Function

    Private Sub EvalAndApplyFormula(
            ByVal parentForm As System.Windows.Forms.IWin32Window,
            ByVal srcItem As ExpandItemParam.FieldBuilder定義型,
            ByVal allItems As System.Collections.Generic.List(Of ExpandItemParam.FieldBuilder定義型),
            ByVal colNamePrefix As String,
            ByVal getValueByCol As System.Func(Of String, String),
            ByVal setResultByCol As System.Action(Of String, Object))

        Dim formula As String = srcItem.計算式項目.取得データ.Trim()

        ' @変数を抽出（長いトークンを先行して誤置換防止）
        Dim varList As New System.Collections.Generic.List(Of String)()
        For Each m As System.Text.RegularExpressions.Match In
                System.Text.RegularExpressions.Regex.Matches(formula, "@[A-Za-z0-9_]+")
            If Not varList.Contains(m.Value) Then varList.Add(m.Value)
        Next
        varList.Sort(Function(a As String, b As String) As Integer
                         Return b.Length.CompareTo(a.Length)
                     End Function)

        ' 変数を現在値で置換
        For Each varName As String In varList
            ' 予約語（@SYSDATE/@USERID）
            If String.Equals(varName, "@SYSDATE", StringComparison.OrdinalIgnoreCase) Then
                formula = formula.Replace(varName, _systdate.ToString())
                Continue For
            ElseIf String.Equals(varName, "@USERID", StringComparison.OrdinalIgnoreCase) Then
                formula = formula.Replace(varName, """" & _userId.Replace("""", """""") & """")
                Continue For
            End If

            For Each refItem As ExpandItemParam.FieldBuilder定義型 In allItems
                If Not String.Equals(refItem.項目変数.Trim(), varName, StringComparison.Ordinal) Then Continue For
                Dim rawVal As String = getValueByCol(ToCusreColumnName(refItem.DB列名, colNamePrefix))
                If rawVal Is Nothing Then rawVal = ""
                Dim replaced As String
                Select Case refItem.属性
                    Case ExpandItemParam.属性型.数値,
                         ExpandItemParam.属性型.日付,
                         ExpandItemParam.属性型.日付_年度,
                         ExpandItemParam.属性型.日付_年月
                        replaced = If(String.IsNullOrEmpty(rawVal.Trim()), "0", rawVal)
                    Case Else
                        replaced = """" & rawVal.Replace("""", """""") & """"
                End Select
                formula = formula.Replace(varName, replaced)
                Exit For
            Next
        Next

        ' 計算実行
        Dim errMsg As String = ""
        Dim resultType As ICalculateAnalysis.ResultType
        Dim resultNumeric As Decimal = 0D
        Dim resultStr As String = ""
        Dim calcResult As ICalculateAnalysis.ErrorType =
            _calc.GetKeisan(formula, srcItem.小数, errMsg, resultType, resultNumeric, resultStr)

        If calcResult = ICalculateAnalysis.ErrorType.計算成功 Then
            ' 反映先変数に対応する列へ結果を書き込む
            For Each reflVar As String In GetReflectVars(srcItem.計算式項目.反映先.Trim())
                For Each destItem As ExpandItemParam.FieldBuilder定義型 In allItems
                    If Not String.Equals(destItem.項目変数.Trim(), reflVar, StringComparison.Ordinal) Then Continue For
                    Dim writeVal As Object
                    If destItem.属性 = ExpandItemParam.属性型.数値 Then
                        Dim numVal As Decimal = 0D
                        If resultType = ICalculateAnalysis.ResultType.数値 Then
                            numVal = resultNumeric
                        Else
                            Decimal.TryParse(resultStr, numVal)
                        End If
                        writeVal = numVal
                    Else
                        writeVal = If(resultType = ICalculateAnalysis.ResultType.数値,
                                      resultNumeric.ToString(), resultStr)
                    End If
                    setResultByCol(ToCusreColumnName(destItem.DB列名, colNamePrefix), writeVal)
                    Exit For
                Next
            Next

        ElseIf calcResult = ICalculateAnalysis.ErrorType.除数0エラー Then
            ' エラーメッセージ表示
            If parentForm IsNot Nothing Then
                OSK.X1.Foundation.UserInterface.OSKMessageBox.Show(
                    parentForm, errMsg, "FieldBuilder",
                    System.Windows.Forms.MessageBoxButtons.OK,
                    System.Windows.Forms.MessageBoxIcon.Exclamation)
            End If
            ' 反映先を0に設定して継続
            For Each reflVar As String In GetReflectVars(srcItem.計算式項目.反映先.Trim())
                For Each destItem As ExpandItemParam.FieldBuilder定義型 In allItems
                    If Not String.Equals(destItem.項目変数.Trim(), reflVar, StringComparison.Ordinal) Then Continue For
                    Dim zeroVal As Object = If(destItem.属性 = ExpandItemParam.属性型.数値, CObj(0D), CObj("0"))
                    setResultByCol(ToCusreColumnName(destItem.DB列名, colNamePrefix), zeroVal)
                    Exit For
                Next
            Next

        Else
            ' その他のエラー: メッセージ表示のみ
            If parentForm IsNot Nothing Then
                OSK.X1.Foundation.UserInterface.OSKMessageBox.Show(
                    parentForm, errMsg, "FieldBuilder",
                    System.Windows.Forms.MessageBoxButtons.OK,
                    System.Windows.Forms.MessageBoxIcon.Exclamation)
            End If
        End If

    End Sub

    ''' <summary>反映先文字列（例: "@K3,@K4"）から変数名リストを返す</summary>
    Private Function GetReflectVars(ByVal reflectStr As String) As System.Collections.Generic.List(Of String)
        Dim result As New System.Collections.Generic.List(Of String)()
        For Each m As System.Text.RegularExpressions.Match In
                System.Text.RegularExpressions.Regex.Matches(reflectStr, "@[A-Za-z0-9_]+")
            If Not result.Contains(m.Value) Then result.Add(m.Value)
        Next
        Return result
    End Function

    ''' <summary>reflectStr 内に varName が含まれるか判定</summary>
    Private Function RefContainsVar(ByVal reflectStr As String, ByVal varName As String) As Boolean
        For Each v As String In GetReflectVars(reflectStr)
            If v = varName Then Return True
        Next
        Return False
    End Function

#End Region

    ''' <summary>
    ''' FieldBuilder定義に応じて登録すべきファンクション種別リストを返す。
    ''' SubForm.InitializeFunction() と同じ属性型判定ロジックを共通化。
    ''' </summary>
    Public Function GetApplicableFunctions(
            ByVal item As ExpandItemParam.FieldBuilder定義型
        ) As List(Of GridFunctionKind)

        Dim result As New List(Of GridFunctionKind)()

        Select Case item.検索種別
            Case ExpandItemParam.検索種別型._1件指定
                Select Case item.属性
                    Case ExpandItemParam.属性型.全角文字,
                         ExpandItemParam.属性型.半角文字
                        result.Add(GridFunctionKind.クリア)
                        result.Add(GridFunctionKind.行終了)
                        If item.計算式 = 1 AndAlso item.入力可否 = 1 Then
                            result.Add(GridFunctionKind.再計算)
                        End If

                    Case ExpandItemParam.属性型.数値
                        result.Add(GridFunctionKind.クリア)
                        result.Add(GridFunctionKind.行終了)
                        If item.計算式 = 1 AndAlso item.入力可否 = 1 Then
                            result.Add(GridFunctionKind.再計算)
                        End If

                    Case ExpandItemParam.属性型.日付,
                         ExpandItemParam.属性型.日付_年月,
                         ExpandItemParam.属性型.日付_年度
                        result.Add(GridFunctionKind.クリア)
                        result.Add(GridFunctionKind.行終了)

                    Case ExpandItemParam.属性型.画像,
                         ExpandItemParam.属性型.実行ファイル,
                         ExpandItemParam.属性型.ファイル,
                         ExpandItemParam.属性型.フォルダ
                        If item.ボタン使用 = 1 Then
                            result.Add(GridFunctionKind.参照)
                            result.Add(GridFunctionKind.クリア)
                            result.Add(GridFunctionKind.開く)
                            result.Add(GridFunctionKind.行終了)
                        End If

                    Case ExpandItemParam.属性型.URL,
                         ExpandItemParam.属性型.メールアドレス
                        If item.ボタン使用 = 1 Then
                            result.Add(GridFunctionKind.クリア)
                            result.Add(GridFunctionKind.開く)
                            result.Add(GridFunctionKind.行終了)
                        End If

                    Case ExpandItemParam.属性型.参照定義コード
                        If item.マスター検索 = 1 Then
                            result.Add(GridFunctionKind.マスター検索)
                        End If
                        result.Add(GridFunctionKind.クリア)
                        result.Add(GridFunctionKind.行終了)

                End Select
        End Select

        Return result

    End Function

#Region "マスター取得（コード検索後のSQL実行）"

    ''' <summary>
    ''' コード検索で選択されたコード、または直接入力されたコードを元にマスター取得SQLを実行し、結果をグリッドへ反映する。
    ''' SubForm の DisplayItem 相当をグリッド向けに実装。
    ''' </summary>
    ''' <param name="parentForm">呼び出し元フォーム。DataAccessFactory のインスタンス生成に使用する。</param>
    ''' <param name="settingInfo">FieldBuilder の設定情報。マスター取得SQL実行時に DataReader へ渡す。</param>
    ''' <param name="item">マスター取得を行う FieldBuilder定義。取得SQL・反映先・項目変数などを参照する。</param>
    ''' <param name="allItems">同一グリッド上の FieldBuilder定義一覧。項目変数から実列名を解決するために使用する。</param>
    ''' <param name="colNamePrefix">DB実列名のプレフィックス。"CUSRE11K" または "CUSRE12K" を指定する。</param>
    ''' <param name="selectedCode">コード検索で選択されたコード、またはグリッドへ直接入力されたコード。</param>
    ''' <param name="getValueByCol">DB実列名を受け取り、現在のグリッド値を文字列で返すコールバック。</param>
    ''' <param name="setResultByCol">DB実列名と反映値を受け取り、退避情報およびグリッドへ値を反映するコールバック。</param>
    ''' <returns>True=取得成功または取得不要／False=コード不存在（0件）またはSQL実行失敗</returns>
    Public Function ExecuteGridMasterGet(
            ByVal parentForm As DesignFormBase,
            ByVal settingInfo As System.Collections.IDictionary,
            ByVal item As ExpandItemParam.FieldBuilder定義型,
            ByVal allItems As System.Collections.Generic.List(Of ExpandItemParam.FieldBuilder定義型),
            ByVal colNamePrefix As String,
            ByVal selectedCode As String,
            ByVal getValueByCol As System.Func(Of String, String),
            ByVal setResultByCol As System.Action(Of String, Object)) As Boolean

        If item.マスター取得 <> 1 Then Return True
        If allItems Is Nothing OrElse allItems.Count = 0 Then Return True

        Dim sqlTemplate As String = If(item.マスター取得項目.取得データ Is Nothing, "", item.マスター取得項目.取得データ.Trim())
        If String.IsNullOrEmpty(sqlTemplate) Then Return True

        ' @変数 を @n に置換しながら ExpandItemParam を構築
        Dim param As New ExpandItemParam()
        Dim workSql As String = sqlTemplate
        Dim execSql As String = String.Empty
        Dim n As Integer = 1
        Do
            Dim pos As Integer = workSql.IndexOf("@"c)
            If pos = -1 Then
                execSql &= workSql
                Exit Do
            End If
            ' 変数名を取得（空白まで）
            Dim varName As String = ""
            For i As Integer = pos To workSql.Length - 1
                If Char.IsWhiteSpace(workSql(i)) Then Exit For
                varName &= workSql(i)
            Next
            execSql &= workSql.Substring(0, pos) & "@" & n.ToString()

            ' 値を決定（自身の項目変数は選択コード、予約語は環境値、その他はグリッド現在値）
            Dim rawVal As Object = ""
            If String.Equals(varName, item.項目変数.Trim(), StringComparison.OrdinalIgnoreCase) Then
                rawVal = selectedCode
            ElseIf String.Equals(varName, "@SYSDATE", StringComparison.OrdinalIgnoreCase) Then
                rawVal = _systdate.ToString()
            ElseIf String.Equals(varName, "@USERID", StringComparison.OrdinalIgnoreCase) Then
                rawVal = _userId
            Else
                For Each fi As ExpandItemParam.FieldBuilder定義型 In allItems
                    If String.Equals(fi.項目変数.Trim(), varName, StringComparison.OrdinalIgnoreCase) Then
                        Dim v As String = getValueByCol(ToCusreColumnName(fi.DB列名, colNamePrefix))
                        rawVal = If(v Is Nothing, "", v)
                        Exit For
                    End If
                Next
            End If

            Dim cond As New ExpandItemParam.検索条件()
            cond.initialize()
            cond.FieldBuilder = rawVal
            cond.属性 = ExpandItemParam.属性型.半角文字
            cond.桁数 = CStr(rawVal).Length
            cond.置換文字列 = New System.Collections.Generic.List(Of String)() From {String.Empty}
            param.FieldBuilder.Add(cond)

            workSql = workSql.Substring(pos + varName.Length)
            n += 1
        Loop
        param.取得用SQL = execSql

        ' FieldBuilder DA で SQL 実行（同期）
        Dim dt As DataTable = Nothing
        Try
            Dim da As IDataReader = DataAccessFactory(Of IDataReader).CreateInstance(parentForm, "OSK.X1.OTS.LIB.FieldBuilder.DA", "DataReader")
            dt = da.ReadData_ExpandItem(settingInfo, param)
        Catch
            Return False
        End Try
        If dt Is Nothing OrElse dt.Rows.Count = 0 Then Return False

        ' 反映先変数 → 対応列に書き込み（DataTable列順 = 反映先順）
        Dim reflectVars As System.Collections.Generic.List(Of String) = GetReflectVars(item.マスター取得項目.反映先.Trim())
        For i As Integer = 0 To reflectVars.Count - 1
            If i >= dt.Columns.Count Then Exit For
            Dim rv As String = reflectVars(i)
            For Each fi As ExpandItemParam.FieldBuilder定義型 In allItems
                If String.Equals(fi.項目変数.Trim(), rv, StringComparison.OrdinalIgnoreCase) Then
                    Dim writeVal As Object = If(dt.Rows(0).IsNull(i), "", CStr(dt.Rows(0)(i)).Trim())
                    setResultByCol(ToCusreColumnName(fi.DB列名, colNamePrefix), writeVal)
                    Exit For
                End If
            Next
        Next
        Return True

    End Function

    ''' <summary>
    ''' マスター取得の反映先項目を空でクリアする。
    ''' </summary>
    ''' <param name="colNamePrefix">列名プレフィックス（"CUSRE11K" or "CUSRE12K"）</param>
    Public Sub ClearGridMasterReflectTargets(
            ByVal item As ExpandItemParam.FieldBuilder定義型,
            ByVal allItems As System.Collections.Generic.List(Of ExpandItemParam.FieldBuilder定義型),
            ByVal colNamePrefix As String,
            ByVal setResultByCol As System.Action(Of String, Object))

        If item.マスター取得 <> 1 Then Exit Sub
        If allItems Is Nothing OrElse allItems.Count = 0 Then Exit Sub

        Dim reflectText As String = ""
        reflectText = item.マスター取得項目.反映先

        If reflectText Is Nothing Then
            reflectText = ""
        Else
            reflectText = reflectText.Trim()
        End If

        If String.IsNullOrEmpty(reflectText) Then Exit Sub

        ' 反映先変数 → 対応列を空で書き戻す
        Dim reflectVars As System.Collections.Generic.List(Of String) = GetReflectVars(reflectText)

        For i As Integer = 0 To reflectVars.Count - 1
            Dim rv As String = reflectVars(i)

            For Each fi As ExpandItemParam.FieldBuilder定義型 In allItems
                If String.Equals(fi.項目変数.Trim(), rv, StringComparison.OrdinalIgnoreCase) Then
                    setResultByCol(ToCusreColumnName(fi.DB列名, colNamePrefix), "")
                    Exit For
                End If
            Next
        Next

    End Sub

#End Region

End Class
'A-CUST20260407↑
