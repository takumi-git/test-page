﻿Imports System
Imports System.Collections.Generic

' ▼属性ごとの振る舞いを戦略クラスに分離
Public Interface IUIHelper
    Function CreateControl(ByVal FieldBuilder As ExpandItemParam.FieldBuilder定義型) As Control
    Sub SetDefault(ByVal ctrl As Control, ByVal defaults As List(Of String))
    Sub SetReadOnly(ByVal ctrl As Control, ByVal isReadOnly As Boolean)
    Function GetValue(ByVal ctrl As Control) As Object
End Interface

' 文字入力（全角/半角/URL/メール/ファイル/フォルダ/画像/実行ファイル）共通
Public Class TextStrategy
    Implements IUIHelper
    Private Const MAXDISPLENGTH As Integer = 64
    Public Function CreateControl(ByVal FieldBuilder As ExpandItemParam.FieldBuilder定義型) As Control _
        Implements IUIHelper.CreateControl

        Dim control As InputTextWithItemName = New InputTextWithItemName()
        Dim dispLength As Integer = 0　'A-CUST20251104 '2026/03/16
        Try ' A-CUST20251104 '2026/03/16 追加 XMLの設定に不備がある場合の例外をキャッチしてエラーメッセージを表示する
            'A-CUST20251104↓ '2026/03/25 XML設定値の事前バリデーション
            If FieldBuilder.桁数 <= 0 OrElse FieldBuilder.桁数 > 256 Then
                Throw New ApplicationException(SimpleErrorMessageBuilder.BuildRangeError("桁数", FieldBuilder.桁数, 1, 256))
            End If
            'A-CUST20251104↑ '2026/03/25
            dispLength = CInt(FieldBuilder.桁数)
            control.ItemName = FieldBuilder.タイトル

            ' ラベル幅を ItemName に合わせて動的設定（最小16文字）
            Dim util As New OSK.X1.Foundation.Utility.UserInterface.WidthCalculator
            'D-CUST20251104↓ '2026/03/24
            'Dim minChars As Integer = 16
            'Dim nameLen As Integer = If(String.IsNullOrEmpty(control.ItemName), minChars, Math.Max(minChars, control.ItemName.Length))
            'control.ItemNameAreaWidth = util.GetSize(control, nameLen).Width
            'D-CUST20251104↑ '2026/03/24
            control.ItemNameAreaWidth = util.GetSize(control, 13).Width 'A-CUST20251104 '2026/03/25
            If dispLength > MAXDISPLENGTH Then
                control.MaxLength = MAXDISPLENGTH
                control.AutoResizeInputControl = False
                control.InputTextControl.DispTextToolTip = True
                control.InputTextControl.DispTextToolTipMode = OSK.X1.Foundation.Controls.Common.DispToolTipModeType.OverflowOnly
            Else
                control.AutoResizeInputControl = True
            End If
            control.MaxLength = dispLength
            control.MaxLengthMode = Foundation.Controls.InputText.MaxLengthModeType.CustomLength


            Select Case FieldBuilder.属性
                Case ExpandItemParam.属性型.全角文字
                    ' IME：ひらがな ＋ 全角のみ許可
                    control.InputType = InputTextWithItemName.InputTypeList.全文字入力可
                    control.InputTextControl.ImeMode = control.InputTextImeMode.Hiragana
                Case ExpandItemParam.属性型.半角文字
                    ' IME：無効（オフ） ＋ 半角のみ許可
                    control.InputType = InputTextWithItemName.InputTypeList.半角文字のみ
                    control.InputTextControl.ImeMode = control.InputTextImeMode.NoControl
                Case ExpandItemParam.属性型.URL,
             ExpandItemParam.属性型.メールアドレス,
             ExpandItemParam.属性型.ファイル,
             ExpandItemParam.属性型.フォルダ,
             ExpandItemParam.属性型.画像,
             ExpandItemParam.属性型.実行ファイル
                    ' IME：無効（オフ）／フィルタなし（全文字可）
                    control.InputTextControl.ImeMode = control.InputTextImeMode.NoControl
                    control.InputType = InputTextWithItemName.InputTypeList.全文字入力可
            End Select


            Return control
            'A-CUST20251104↓ '2026/03/16
        Catch ex As Exception
            Throw New ApplicationException(SimpleErrorMessageBuilder.GetMessage(ex), ex)
        End Try
        'A-CUST20251104↑ '2026/03/16
    End Function

    Public Sub SetDefault(ByVal ctrl As Control, ByVal defaults As List(Of String)) _
        Implements IUIHelper.SetDefault
        Dim control As InputTextWithItemName = CType(ctrl, InputTextWithItemName)
        control.TextValue = defaults(0)
    End Sub

    Public Sub SetReadOnly(ByVal ctrl As Control, ByVal isReadOnly As Boolean) _
        Implements IUIHelper.SetReadOnly
        If CType(ctrl, InputTextWithItemName).AutoResizeInputControl = False Then
            CType(ctrl, InputTextWithItemName).InputControlReadOnly = isReadOnly
            CType(ctrl, InputTextWithItemName).InputTextControl.CanFocusByUser = Not isReadOnly
            CType(ctrl, InputTextWithItemName).InputTextControl.DisplayOnly = isReadOnly
        Else
            CType(ctrl, InputTextWithItemName).InputControlReadOnly = isReadOnly
        End If
    End Sub

    Public Function GetValue(ByVal ctrl As Control) As Object _
        Implements IUIHelper.GetValue
        Return CType(ctrl, InputTextWithItemName).TextValue
    End Function
End Class
' 数値戦略
Public Class NumericStrategy
    Implements IUIHelper

    Public Function CreateControl(ByVal FieldBuilder As ExpandItemParam.FieldBuilder定義型) As Control _
        Implements IUIHelper.CreateControl

        Dim control As InputNumericalWithItemName = New InputNumericalWithItemName()
        Try  'A-CUST20251104 '2026/03/16 追加 XMLの設定に不備がある場合の例外をキャッチしてエラーメッセージを表示する
            'A-CUST20251104↓ '2026/03/25 XML設定値の事前バリデーション
            Dim digits As Integer = CInt(FieldBuilder.桁数)
            Dim decimals As Integer = CInt(FieldBuilder.小数)
            If digits <= 0 OrElse digits > 13 Then
                Throw New ApplicationException(SimpleErrorMessageBuilder.BuildRangeError("整数桁", digits, 1, 13))
            End If
            If decimals < 0 OrElse decimals > 6 Then
                Throw New ApplicationException(SimpleErrorMessageBuilder.BuildRangeError("小数桁", decimals, 0, 6))
            End If

            If FieldBuilder.デフォルト値 IsNot Nothing AndAlso FieldBuilder.デフォルト値.Count > 0 Then
                Try
                    Dim defaultValue As Decimal = CDec(FieldBuilder.デフォルト値(0))
                Catch ex As Exception
                    Throw New ApplicationException(SimpleErrorMessageBuilder.BuildValueError("デフォルト値", "数値形式である必要があります（有効値は数値です）"))
                End Try
            End If
            'A-CUST20251104↑ '2026/03/25
            control.ItemName = FieldBuilder.タイトル

            ' ラベル幅を ItemName に合わせて動的設定（最小16文字）
            Dim util As New OSK.X1.Foundation.Utility.UserInterface.WidthCalculator
            'D-CUST20251104↓ '2026/03/24
            'Dim minChars As Integer = 16
            'Dim nameLen As Integer = If(String.IsNullOrEmpty(control.ItemName), minChars, Math.Max(minChars, control.ItemName.Length))
            'control.ItemNameAreaWidth = util.GetSize(control, nameLen).Width
            'D-CUST20251104↑ '2026/03/24
            control.ItemNameAreaWidth = util.GetSize(control, 13).Width 'A-CUST20251104 '2026/03/24    

            control.整数桁数 = CInt(FieldBuilder.桁数)
            control.小数桁数 = CInt(FieldBuilder.小数)
            control.カンマ表示 = (FieldBuilder.カンマ = 1)
            Return control
            'A-CUST20251104↓ '2026/03/16
        Catch ex As Exception
            Throw New ApplicationException(SimpleErrorMessageBuilder.GetMessage(ex), ex)
        End Try
        'A-CUST20251104↑ '2026/03/16
    End Function

    Public Sub SetDefault(ByVal ctrl As Control, ByVal defaults As List(Of String)) _
        Implements IUIHelper.SetDefault
        CType(ctrl, InputNumericalWithItemName).Value = CDec(defaults(0))
    End Sub

    Public Sub SetReadOnly(ByVal ctrl As Control, ByVal isReadOnly As Boolean) _
        Implements IUIHelper.SetReadOnly
        CType(ctrl, InputNumericalWithItemName).InputControlReadOnly = isReadOnly
    End Sub

    Public Function GetValue(ByVal ctrl As Control) As Object _
        Implements IUIHelper.GetValue
        Return CType(ctrl, InputNumericalWithItemName).Value
    End Function
End Class

' 日付戦略（通常／年月／年度をコンストラクタ引数で切り替え）
Public Class DateStrategy
    Implements IUIHelper

    Private ReadOnly _format As InputDate.DisplayFormatType
    Private ReadOnly _ym As Boolean
    Private ReadOnly _yearOnly As Boolean

    Public Sub New(ByVal format As InputDate.DisplayFormatType,
                   ByVal ym As Boolean,
                   ByVal yearOnly As Boolean)
        _format = format
        _ym = ym
        _yearOnly = yearOnly
    End Sub

    Public Function CreateControl(ByVal FieldBuilder As ExpandItemParam.FieldBuilder定義型) As Control _
        Implements IUIHelper.CreateControl

        Dim control As InputDateWithItemName = New InputDateWithItemName()

        Try 'A-CUST20251104 '2026/03/16  追加 XMLの設定に不備がある場合の例外をキャッチしてエラーメッセージを表示する
            'A-CUST20251104↓ '2026/03/25 XML設定値の事前バリデーション
            Try
                Dim separatorValue As Integer = CInt(FieldBuilder.区切り文字)
                If separatorValue < 0 OrElse separatorValue > 4 Then
                    Throw New ApplicationException(SimpleErrorMessageBuilder.BuildRangeError("区切り文字", separatorValue, 0, 4))
                End If

                ' 日付形式に応じた桁数チェック
                Dim expectedDigits As Integer = 0
                If _ym Then
                    ' 年月：YYYYMM（6桁）
                    expectedDigits = 6
                ElseIf _yearOnly Then
                    ' 年度：YYYY（4桁）
                    expectedDigits = 4
                Else
                    ' 年月日：YYYYMMDD（8桁）
                    expectedDigits = 8
                End If

                If FieldBuilder.桁数 <> expectedDigits Then
                    Throw New ApplicationException(SimpleErrorMessageBuilder.BuildRangeError(FieldBuilder.タイトル, "桁数", FieldBuilder.桁数, expectedDigits))
                End If
            Catch ex As Exception
                Throw New ApplicationException(SimpleErrorMessageBuilder.BuildValueError("日付設定", ex.Message), ex)
            End Try

            If FieldBuilder.デフォルト値 IsNot Nothing AndAlso FieldBuilder.デフォルト値.Count > 0 Then
                Dim dateString As String = FieldBuilder.デフォルト値(0)
                Dim dateValue As Integer = 0
                If Not Integer.TryParse(dateString, dateValue) Then
                    Throw New ApplicationException(SimpleErrorMessageBuilder.BuildValueError( "デフォルト値", "整数値である必要があります"))
                End If

                ' 日付形式に応じた桁数チェック
                Dim expectedDigits As Integer = If(_ym, 6, If(_yearOnly, 4, 8))
                If dateValue <> 0 AndAlso dateString.Length <> expectedDigits Then
                    Throw New ApplicationException(SimpleErrorMessageBuilder.BuildRangeError("デフォルト値", dateString.Length, expectedDigits))
                End If

                ' 0以外の場合、日付の妥当性をチェック
                If dateValue <> 0 Then
                    If _ym Then
                        ' 年月：YYYYMM
                        Dim month As Integer = dateValue Mod 100
                        If month < 1 OrElse month > 12 Then
                            Throw New ApplicationException(SimpleErrorMessageBuilder.BuildValueError("デフォルト値", "月が範囲外です（1-12）"))
                        End If
                    ElseIf Not _yearOnly Then
                        ' 年月日：YYYYMMDD
                        Dim year As Integer = dateValue \ 10000
                        Dim month As Integer = (dateValue Mod 10000) \ 100
                        Dim day As Integer = dateValue Mod 100
                        If month < 1 OrElse month > 12 Then
                            Throw New ApplicationException(SimpleErrorMessageBuilder.BuildValueError("デフォルト値", "月が範囲外です（1-12）"))
                        End If
                        ' 月の最大日数を取得してチェック
                        Dim daysInMonth As Integer = DateTime.DaysInMonth(year, month)
                        If day < 1 OrElse day > daysInMonth Then
                            Throw New ApplicationException(SimpleErrorMessageBuilder.BuildValueError("デフォルト値", String.Format("日が範囲外です（1-{0}）", daysInMonth)))
                        End If
                    End If
                    ' 年度（年のみ）は数値チェック済みなので追加チェック不要
                End If
            End If
            'A-CUST20251104↑ '2026/03/25
            control.ItemName = FieldBuilder.タイトル
            ' ラベル幅を ItemName に合わせて動的設定（最小16文字）
            Dim util As New OSK.X1.Foundation.Utility.UserInterface.WidthCalculator
            'D-CUST20251104↓ '2026/03/24
            'Dim minChars As Integer = 16
            'Dim nameLen As Integer = If(String.IsNullOrEmpty(control.ItemName), minChars, Math.Max(minChars, control.ItemName.Length))
            'control.ItemNameAreaWidth = util.GetSize(control, nameLen).Width
            'D-CUST20251104↑ '2026/03/24
            control.ItemNameAreaWidth = util.GetSize(control, 13).Width 'A-CUST20251104 '2026/03/24   

            control.区切り文字 = CType(FieldBuilder.区切り文字, InputDateWithItemName.SeparatorType)
            control.DispSpinButton = True
            control.InputDateControl.DisplayFormat = _format
            If _ym Then
                control.日付形式 = InputDateWithItemName.DateFormatType.年月
                control.InputDateControl.HiddenDay = 1
            End If
            If _yearOnly Then
                control.日付形式 = InputDateWithItemName.DateFormatType.年
                control.InputDateControl.HiddenDay = 1
                control.InputDateControl.HiddenMonth = 1
            End If
            Return control
            'A-CUST20251104↓ '2026/03/16
        Catch ex As Exception
            Throw New ApplicationException(SimpleErrorMessageBuilder.GetMessage(ex), ex)
        End Try
        'A-CUST20251104↑ '2026/03/16
    End Function

    Public Sub SetDefault(ByVal ctrl As Control, ByVal defaults As List(Of String)) _
        Implements IUIHelper.SetDefault
        'Dim datevlue As Integer = CInt(defaults(0))    'D-CUST20260501
        Dim datevalue As Integer = 0 'A-CUST20260501
        Dim inputDate As InputDateWithItemName = CType(ctrl, InputDateWithItemName)

        'A-CUST20260501↓
        If defaults Is Nothing OrElse defaults.Count = 0 Then
            inputDate.DateValue = 0
            Return
        End If


        If Not Integer.TryParse(defaults(0), dateValue) Then
            inputDate.DateValue = 0
            Return
        End If

        If dateValue = 0 Then
            inputDate.DateValue = 0
            Return
        End If
        'A-CUST20260501↑

        If _ym Then
            Dim year As Integer = datevalue \ 100
            Dim month As Integer = datevalue Mod 100
            inputDate.InputDateControl.Year = year
            inputDate.InputDateControl.Month = month
            inputDate.DateValue = (year * 10000) + (month * 100) + 1
        ElseIf _yearOnly Then
            Dim year As Integer = datevalue
            inputDate.InputDateControl.Year = year
            inputDate.DateValue = (year * 10000) + 101
        Else
            inputDate.DateValue = datevalue
        End If
    End Sub

    Public Sub SetReadOnly(ByVal ctrl As Control, ByVal isReadOnly As Boolean) _
        Implements IUIHelper.SetReadOnly
        CType(ctrl, InputDateWithItemName).InputControlReadOnly = isReadOnly
    End Sub

    Public Function GetValue(ByVal ctrl As Control) As Object _
        Implements IUIHelper.GetValue
        Return CType(ctrl, InputDateWithItemName).DateValue
    End Function
End Class

' 参照定義コード（名称表示付き）戦略
Public Class RefCodeStrategy
    Implements IUIHelper

    Public Function CreateControl(ByVal FieldBuilder As ExpandItemParam.FieldBuilder定義型) As Control _
        Implements IUIHelper.CreateControl
        Dim Utility As New OSK.X1.Foundation.Utility.UserInterface.WidthCalculator
        Dim maxDispLength As Integer = 32
        Dim dispLength As Integer = CInt(FieldBuilder.桁数)
        Dim control As InputTextWithItemNameAndInputName = New InputTextWithItemNameAndInputName()

        Try 'A-CUST20251104 '2026/03/16 追加 XMLの設定に不備がある場合の例外をキャッチしてエラーメッセージを表示する
            'A-CUST20251104↓ '2026/03/25 XML設定値の事前バリデーション
            If dispLength <= 0 OrElse dispLength > 256 Then
                Throw New ApplicationException(SimpleErrorMessageBuilder.BuildRangeError("参照コード桁数", dispLength, 1, 256))
            End If
            'A-CUST20251104↑ '2026/03/25
            control.ItemName = FieldBuilder.タイトル
            If dispLength > maxDispLength Then
                control.MaxLength = maxDispLength
                control.AutoResizeInputControl = False
                control.InputTextControl.DispTextToolTip = True
                control.InputTextControl.DispTextToolTipMode = OSK.X1.Foundation.Controls.Common.DispToolTipModeType.OverflowOnly
            Else
                control.AutoResizeInputControl = True
            End If
            control.MaxLength = dispLength
            control.MaxLengthMode = Foundation.Controls.InputText.MaxLengthModeType.CustomLength
            If FieldBuilder.タイプ = 1 Then
                control.InputType = InputTextWithItemNameAndInputName.InputModeType.全文字入力可
                If FieldBuilder.大文字変換 = 1 Then
                    control.InputType = InputTextWithItemNameAndInputName.InputModeType.ログインID入力モード
                End If
                control.ZeroFill = False
            Else
                control.InputType = InputTextWithItemNameAndInputName.InputModeType.数値のみ
                control.ZeroFill = True
            End If

            ' ラベル幅を ItemName に合わせて動的設定（最小16文字）
            'DispNameは48文字想定で固定（参照定義コードの名称は長くなる可能性があるため）
            Dim util As New OSK.X1.Foundation.Utility.UserInterface.WidthCalculator
            'D-CUST20251104↓ '2026/03/24
            'Dim minChars As Integer = 16
            'Dim nameLen As Integer = If(String.IsNullOrEmpty(control.ItemName), minChars, Math.Max(minChars, control.ItemName.Length))
            'control.ItemNameAreaWidth = util.GetSize(control, nameLen).Width
            'D-CUST20251104↑ '2026/03/24
            control.ItemNameAreaWidth = util.GetSize(control, 13).Width 'A-CUST20251104 '2026/03/24    
            'control.DispNameAreaWidth = Utility.GetSize(control.DispNameControl, 48).Width 'D-CUST20260501 '2026/05/22
            'A-CUST20260501↓ '2026/05/22
            If FieldBuilder.マスター取得 = 1 Then
                control.DispNameAreaWidth = Utility.GetSize(control.DispNameControl, 48).Width
            Else
                control.DispNameControl.Visible = False
                control.DispNameAreaWidth = 0
            End If
            'A-CUST20260501↑ '2026/05/22

            Return control
            'A-CUST20251104↓ '2026/03/16            
        Catch ex As Exception
            Throw New ApplicationException(SimpleErrorMessageBuilder.GetMessage(ex), ex)
        End Try
        'A-CUST20251104↑ '2026/03/16
    End Function

    Public Sub SetDefault(ByVal ctrl As Control, ByVal defaults As List(Of String)) _
        Implements IUIHelper.SetDefault
        Dim control As InputTextWithItemNameAndInputName = CType(ctrl, InputTextWithItemNameAndInputName)
        control.InputTextControl.Text = defaults(0)
        control.DispNameControl.Text = String.Empty
    End Sub

    Public Sub SetReadOnly(ByVal ctrl As Control, ByVal isReadOnly As Boolean) _
        Implements IUIHelper.SetReadOnly
        CType(ctrl, InputTextWithItemNameAndInputName).InputControlReadOnly = isReadOnly


        CType(ctrl, InputTextWithItemNameAndInputName).Enabled = True

        CType(ctrl, InputTextWithItemNameAndInputName).TabStop = Not isReadOnly
        Try
            CType(ctrl, InputTextWithItemNameAndInputName).InputTextControl.TabStop = Not isReadOnly
        Catch
        End Try

    End Sub

    Public Function GetValue(ByVal ctrl As Control) As Object _
        Implements IUIHelper.GetValue
        Return CType(ctrl, InputTextWithItemNameAndInputName).InputTextControl.Text
    End Function
End Class

' ▼戦略ファクトリ（SubForm から呼び出す）
Public NotInheritable Class AttrStrategyFactory
    Private Sub New()
    End Sub

    Public Shared Function BuildStrategyMap(ByVal displayFormat As OSK.X1.Foundation.Controls.InputDate.DisplayFormatType) _
        As Dictionary(Of ExpandItemParam.属性型, IUIHelper)

        Dim map As Dictionary(Of ExpandItemParam.属性型, IUIHelper) =
            New Dictionary(Of ExpandItemParam.属性型, IUIHelper)()

        ' 文字系（同一戦略へ集約）
        map(ExpandItemParam.属性型.全角文字) = New TextStrategy()
        map(ExpandItemParam.属性型.半角文字) = New TextStrategy()
        map(ExpandItemParam.属性型.URL) = New TextStrategy()
        map(ExpandItemParam.属性型.メールアドレス) = New TextStrategy()
        map(ExpandItemParam.属性型.ファイル) = New TextStrategy()
        map(ExpandItemParam.属性型.フォルダ) = New TextStrategy()
        map(ExpandItemParam.属性型.画像) = New TextStrategy()
        map(ExpandItemParam.属性型.実行ファイル) = New TextStrategy()

        ' 数値
        map(ExpandItemParam.属性型.数値) = New NumericStrategy()

        ' 日付
        map(ExpandItemParam.属性型.日付) = New DateStrategy(displayFormat, ym:=False, yearOnly:=False)
        map(ExpandItemParam.属性型.日付_年月) = New DateStrategy(displayFormat, ym:=True, yearOnly:=False)
        map(ExpandItemParam.属性型.日付_年度) = New DateStrategy(displayFormat, ym:=False, yearOnly:=True)

        ' 参照定義コード
        map(ExpandItemParam.属性型.参照定義コード) = New RefCodeStrategy()

        Return map
    End Function

End Class

'A-CUST20251104↓ '2026/03/16
' XMLの設定に不備がある場合のエラーメッセージを取得するクラス
Public NotInheritable Class SimpleErrorMessageBuilder
    Private Sub New()
    End Sub

    ''' <summary>
    ''' 例外メッセージから最初の行のみを抽出した簡潔なエラーメッセージを取得する
    ''' </summary>
    Public Shared Function GetMessage(ByVal ex As Exception) As String
        Dim message As String = String.Empty
        Dim lines() As String = Nothing
        Dim separators() As String = Nothing

        If ex Is Nothing Then
            Return "不正な設定値です。"
        End If

        message = ex.Message

        If String.IsNullOrWhiteSpace(message) Then
            Return "不正な設定値です。"
        End If

        separators = New String() {vbCrLf, vbLf, vbCr}
        lines = message.Split(separators, StringSplitOptions.None)

        If lines Is Nothing OrElse lines.Length = 0 Then
            Return message.Trim()
        End If

        If String.IsNullOrWhiteSpace(lines(0)) Then
            Return message.Trim()
        End If

        Return lines(0).Trim()
    End Function

    'A-CUST20251104↓ '2026/03/25 バリデーション用メソッド追加
    ''' <summary>
    ''' 範囲チェックのエラーメッセージを生成（最小値～最大値、または最小値のみ）
    ''' maxValueが指定されない場合は「有効値=○です」、指定された場合は「有効値=○～△です」
    ''' </summary>
    Public Shared Function BuildRangeError(ByVal fieldName As String,
                                          ByVal currentValue As Object, ByVal minValue As Object,
                                          Optional ByVal maxValue As Object = Nothing) As String
        If maxValue Is Nothing Then
            Return String.Format(" {0}が範囲外です。有効値={1} (現在値={2})",
                                fieldName, minValue, currentValue)
        Else
            Return String.Format("{0}が範囲外です。有効値={1}～{2} (現在値={3})",
                                fieldName, minValue, maxValue, currentValue)
        End If
    End Function

    ''' <summary>
    ''' 個別チェックのエラーメッセージを生成
    ''' </summary>
    Public Shared Function BuildValueError(ByVal fieldName As String,
                                          ByVal errorMessage As String) As String
        Return String.Format(" {0} - {1}", fieldName, errorMessage)
    End Function
    'A-CUST20251104↑ '2026/03/25

End Class
'A-CUST20251104↑ '2026/03/16
