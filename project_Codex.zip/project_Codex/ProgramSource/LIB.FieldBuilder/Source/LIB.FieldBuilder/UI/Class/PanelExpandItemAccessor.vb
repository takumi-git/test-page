﻿
Public Class PanelExpandItemAccessor
    Implements IExpandItemAccessor

    Public Enum OmitDecisionType As Integer
        省略可 = 0
        警告 = 1
        必須 = 2
    End Enum

    Public Structure ValidationResult
        Public IsValid As Boolean
        Public HasMissingRequired As Boolean
        Public FirstErrorControl As Control
        Public FirstErrorItemName As String
        Public IsWarning As Boolean
        Public WarningItemName As String
        Public WarningControl As Control
    End Structure

    Private ReadOnly _panel As SimpleControl.Panel

    Public Sub New(ByVal panel As SimpleControl.Panel)
        Me._panel = panel
    End Sub

    Public Function Validate(ByVal expandItem As ExpandItemParam.FieldBuilder定義型) _
        As ValidationResult Implements IExpandItemAccessor.Validate

        Dim result As New ValidationResult
        result.IsValid = True
        result.HasMissingRequired = False
        result.FirstErrorControl = Nothing
        result.FirstErrorItemName = String.Empty
        result.IsWarning = False
        result.WarningItemName = String.Empty

        Dim ctrl As Control = Me._panel.Controls(CType(expandItem.control, Control).Name)
        If ctrl Is Nothing Then Return result

        Dim isEmpty As Boolean = False
        Dim itemName As String = String.Empty

        Select Case expandItem.属性
            Case ExpandItemParam.属性型.全角文字, ExpandItemParam.属性型.半角文字
                Dim c As InputTextWithItemName = CType(ctrl, InputTextWithItemName)
                itemName = CType(c.ItemName, String)
                'isEmpty = (CType(c.TextValue, String) = String.Empty)  'D-CUST20251104 '2026/03/12
                isEmpty = (CType(c.TextValue, String).Trim() = String.Empty)    'A-CUST20251104 '2026/03/12

            Case ExpandItemParam.属性型.数値
                Dim c As InputNumericalWithItemName = CType(ctrl, InputNumericalWithItemName)
                itemName = CType(c.ItemName, String)
                isEmpty = (c.Value = 0D)

            Case ExpandItemParam.属性型.日付
                Dim c As InputDateWithItemName = CType(ctrl, InputDateWithItemName)
                itemName = CType(c.ItemName, String)
                isEmpty = (c.DateValue = 0)

            Case ExpandItemParam.属性型.日付_年月
                Dim c As InputDateWithItemName = CType(ctrl, InputDateWithItemName)
                itemName = CType(c.ItemName, String)
                Dim ym As String = CStr(c.InputDateControl.Year) & CStr(c.InputDateControl.Month).PadLeft(2, "0"c)
                Dim ymInt As Integer = 0
                Integer.TryParse(ym, ymInt)
                isEmpty = (ymInt = 0)

            Case ExpandItemParam.属性型.日付_年度
                Dim c As InputDateWithItemName = CType(ctrl, InputDateWithItemName)
                itemName = CType(c.ItemName, String)
                isEmpty = (c.InputDateControl.Year = 0)

            Case ExpandItemParam.属性型.参照定義コード
                Dim c As InputTextWithItemNameAndInputName = CType(ctrl, InputTextWithItemNameAndInputName)
                itemName = CType(c.ItemName, String)
                'isEmpty = (c.InputTextControl.Text = String.Empty)  'D-CUST20251104 '2026/03/12
                isEmpty = (c.InputTextControl.Text.Trim() = String.Empty)   'A-CUST20251104 '2026/03/12

            Case ExpandItemParam.属性型.画像, ExpandItemParam.属性型.実行ファイル, ExpandItemParam.属性型.ファイル,
                     ExpandItemParam.属性型.フォルダ, ExpandItemParam.属性型.URL, ExpandItemParam.属性型.メールアドレス
                If Not TypeOf ctrl Is SimpleControl.CommandButton Then
                    Dim c As InputTextWithItemName = CType(ctrl, InputTextWithItemName)
                    itemName = CType(c.ItemName, String)
                    'isEmpty = (CType(c.TextValue, String) = String.Empty)   'D-CUST20251104 '2026/03/12
                    isEmpty = (CType(c.TextValue, String).Trim() = String.Empty)    'A-CUST20251104 '2026/03/12
                End If
        End Select

        If isEmpty Then

            Dim decision As OmitDecisionType
            Select Case expandItem.入力チェック
                Case 0
                    decision = OmitDecisionType.省略可
                Case 1
                    decision = OmitDecisionType.警告
                Case 2
                    decision = OmitDecisionType.必須
                Case Else
                    decision = OmitDecisionType.省略可
            End Select

            If decision = OmitDecisionType.必須 Then
                result.IsValid = False
                result.HasMissingRequired = True
                result.FirstErrorControl = ctrl
                result.FirstErrorItemName = itemName
            ElseIf decision = OmitDecisionType.警告 AndAlso Not result.IsWarning Then
                result.IsWarning = True
                result.WarningItemName = itemName
                result.WarningControl = ctrl
            End If

        End If
        Return result
    End Function

End Class
