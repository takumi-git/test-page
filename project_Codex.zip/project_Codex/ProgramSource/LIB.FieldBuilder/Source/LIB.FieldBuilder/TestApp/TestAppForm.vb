﻿Public Class TestCaller
    Inherits InsideJobBase
    Public _loader As ProgramLoad.UserInterface.LocalLoader
    Public Sub New()

    End Sub
    Public Sub load(ByVal paraminfo As IDictionary)
        If _loader Is Nothing Then
            _loader = New ProgramLoad.UserInterface.LocalLoader
            _loader.Startup(Me, "OSK.X1.OTS.A02800", 0)
        End If
        _loader.Run(paraminfo)

    End Sub
End Class

Public Class TestAppForm

    Private _target As ILocalLoader
    Private _startupLpader As OSK.X1.Foundation.ProgramLoad.UserInterface.Loader



    Private Sub CommandButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CommandButton1.Click
        Dim settingInfo As IDictionary = New Hashtable
        Dim initInfo As IDictionary = New Hashtable
        Dim saveInfo As IDictionary = New Hashtable
        Dim paramInfo As IDictionary = New Hashtable
        SetSettingInfo(settingInfo, 構成形態型.スタンドアロン)
        Dim ExpandItemEntry As OSK.X1.OTS.LIB.FieldBuilder.UI.ISubForm = New OSK.X1.OTS.LIB.FieldBuilder.UI.SubForm
        Dim dtサブ画面データ As New DataTable
        For i As Integer = 1 To 30
            dtサブ画面データ.Columns.Add(New DataColumn("CUSRE11K" & i.ToString("D3"), GetType(String))) 'FieldBuilder001~030
        Next
        Dim dr As DataRow = dtサブ画面データ.NewRow
        'For i As Integer = 0 To dtサブ画面データ.Columns.Count - 1
        '    If dtサブ画面データ.Columns(i).ColumnName = "CUSRE11K010" Then
        '        dr.Item(i) = "\\20dvlfs-03\share\カスタマイズ\17-8792EOサンプル(拡張項目機能)\テーブル定義・結合表定義情報\(EO)_CMN10P001_プログラム表示制御_結合表.txt"
        '    ElseIf dtサブ画面データ.Columns(i).ColumnName = "CUSRE11K005" Then
        '        dr.Item(i) = "202511"
        '    ElseIf dtサブ画面データ.Columns(i).ColumnName = "CUSRE11K006" Then
        '        dr.Item(i) = "2025"
        '    Else
        '        dr.Item(i) = "20251020"
        '    End If
        'Next
        dtサブ画面データ.Rows.Add(dr)

        ' 列名マッピングの生成
        Dim dic列名マップ As New Dictionary(Of String, String)
        For i As Integer = 1 To 30
            dic列名マップ.Add("K" & i.ToString("D3"), "CUSRE11K" & i.ToString("D3"))
        Next


        With paramInfo
            .Add("XMLファイル名", "EO汎用_FieldBuilder_売上伝票.xml")
            .Add("処理モード", 1) '入力モード
            .Add("サブ画面データ", dtサブ画面データ)
            .Add("列名マップ", dic列名マップ)
            .Add("処理名", "見積処理")
        End With
        ExpandItemEntry.Initialize(settingInfo, initInfo, saveInfo)
        ExpandItemEntry.SetUpForm(paramInfo)
        'If _startupLpader Is Nothing Then
        '    _startupLpader = New OSK.X1.Foundation.ProgramLoad.UserInterface.Loader    'X1変換Tool-20160525

        'End If
        'paramInfo.Item("再表示区分") = 再表示区分.CheckState = Windows.Forms.CheckState.Checked

        '_startupLpader.Run(settingInfo, paramInfo)
        ''_load.load(paramInfo)
        'If paramInfo.Contains("@RET1") Then
        '    戻り値１.Text = CStr(paramInfo.Item("@RET1"))
        'End If
        'If paramInfo.Contains("@RET2") Then
        '    戻り値２.Text = CStr(paramInfo.Item("@RET2"))
        'End If
        'If paramInfo.Contains("@RET3") Then
        '    戻り値３.Text = CStr(paramInfo.Item("@RET3"))
        'End If

        'If paramInfo.Contains("再表示区分") Then
        '    If CType(paramInfo.Item("再表示区分"), Boolean) = True Then
        '        再表示区分.CheckState = Windows.Forms.CheckState.Checked
        '    Else
        '        再表示区分.CheckState = Windows.Forms.CheckState.Unchecked
        '    End If
        'End If
    End Sub

    Private Sub CommandButton2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CommandButton2.Click
        Dim settingInfo As IDictionary = New Hashtable
        'Dim initInfo As IDictionary = New Hashtable
        'Dim saveInfo As IDictionary = New Hashtable

        SetSettingInfo(settingInfo, 構成形態型.分散)

        Dim brokerInfo As OSK.X1.Foundation.UserInterface.BrokerInfo = New OSK.X1.Foundation.UserInterface.BrokerInfo(settingInfo)    'X1変換Tool-20160525
        brokerInfo.サーバー接続URI = "http://localhost:8181/RemotingBrokerService"
        brokerInfo.プロキシアセンブリ名 = "OSK.X1.Broker.UserInterface"    'X1変換Tool-20160525
        brokerInfo.プロキシクラス名 = "OSK.X1.Broker.UserInterface.RemotingProxyHandler"    'X1変換Tool-20160525

        Dim stateInfo As OSK.X1.Foundation.StateServerInfo = New OSK.X1.Foundation.StateServerInfo(settingInfo)    'X1変換Tool-20160525
        stateInfo.URI = "tcp://localhost:8180/RemotingStateManagerService"

        Dim paramInfo As IDictionary = New Hashtable()

        Dim startupLoader As New OSK.X1.Foundation.ProgramLoad.UserInterface.Loader    'X1変換Tool-20160525
        startupLoader.Run(settingInfo, paramInfo)

    End Sub

    Private Sub CommandButton3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CommandButton3.Click
        Dim settingInfo As IDictionary = New Hashtable
        Dim paramInfo As IDictionary = New Hashtable

        SetSettingInfo(settingInfo, 構成形態型.スタンドアロン)

        If _target Is Nothing Then
            _target = New LocalLoader
            Dim testCaller As New TestCaller
            testCaller.Initialize(settingInfo)
            _target.Startup(testCaller, "OSK.X1.OTS.A01800", 0)    'X1変換Tool-20160525
        End If

        paramInfo.Item("再表示区分") = 再表示区分.CheckState = Windows.Forms.CheckState.Checked
        _target.Run(paramInfo)



    End Sub

    Private Sub SetSettingInfo(ByRef settingInfoValue As IDictionary, ByVal 構成形態 As OSK.X1.Foundation.構成形態型)    'X1変換Tool-20160525
        Dim info As New SettingInfo(settingInfoValue)

        info.データベース情報.接続ID = "CNNSQL"
        'info.データベース情報.接続ID = "cnnORA"
        info.データベース情報.ログ接続ID = info.データベース情報.接続ID
        info.プログラム情報.ID = "OSK.X1.OTS.A02800"    'X1変換Tool-20160525
        info.プログラム情報.ID = "OSK.X1.OTS.LIB.TestDummyEntry"
        info.プログラム情報.枝番 = 99001
        'info.プログラム情報.枝番 = 39001
        info.プログラム情報.オリジナルID = info.プログラム情報.ID
        info.プログラム情報.実行ID = System.Guid.NewGuid.ToString()
        info.プログラム情報.名称 = "支払処理"
        info.業務情報.ID = "CUS"
        info.会社情報.名称 = "株式会社　テスト"
        info.ログオンユーザー情報.業務管理者権限 = True
        info.ログオンユーザー情報.ID = "ADMINISTRATOR"
        'info.ログオンユーザー情報.ID = "SMILE"
        info.コンピュータ情報.名前 = System.Environment.MachineName

        info.システム構成情報.構成形態 = 構成形態
        info.システム構成情報.動作モード = 動作モード型.デバッグ

        info.プログラム制御情報.Escキー終了機能 = True
        info.プログラム制御情報.処理状況更新間隔 = 1
        info.プログラム制御情報.ウィンドウサイズ保存機能 = True
        info.プログラム制御情報.起動ログ出力 = True
        info.プログラム制御情報.データ出力ログ出力 = True
        info.プログラム制御情報.出力イメージ保存 = True
        info.プログラム制御情報.会社名表示 = True

        'info.プログラム制御情報.フォント変更 = True
        'info.プログラム制御情報.入力用フォント名 = "HG明朝E"
        info.プログラム制御情報.表示用フォント名 = "HG創英角ﾎﾟｯﾌﾟ体"
        info.プログラム制御情報.ファンクションバーサイズ拡大 = True

        info.色情報.プログラムID = info.プログラム情報.ID
        info.色情報.プログラム枝番 = info.プログラム情報.枝番
        info.色情報.業務区分 = info.業務情報.ID
        info.色情報.色パターン設定区分 = True

    End Sub


End Class


