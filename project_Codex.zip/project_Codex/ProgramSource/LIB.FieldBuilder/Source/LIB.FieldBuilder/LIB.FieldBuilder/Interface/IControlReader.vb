﻿Public Interface IControlReader
    Inherits IBase

    Sub Startup(ByRef infoXML As System.Collections.IDictionary, ByVal NmXML As String,
                ByRef conditionList As List(Of ExpandItemParam.FieldBuilder定義型), ByVal 処理名 As String)

End Interface
