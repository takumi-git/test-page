'A-CUST20260407↓
''' <summary>
''' FieldBuilder のデータ操作に関する共通ヘルパー（UIに依存しない純粋ロジック）。
''' ・IsFieldEmpty             : DataRow の値が属性型に応じて「空」かどうか判定
''' ・GetKNumber               : DB列名("K001"等)から番号部を取得
''' ・ToCusreColumnName        : DB列名 + プレフィックスでDB実列名を生成
''' ・AddFBColumns             : DataTable に FieldBuilder用の列を追加
''' ・ExpandFBValues           : FieldBuilder DataTable から対象行へ値を展開
''' ・ExpandFBValues_Grid      : FieldBuilder DataTable から対象行へ値を展開
''' ・ExpandDateValueForGrid   : DB値(6/4桁)をGridEdit用8桁日付に変換
''' ・ConvertGridDataValue     : GridEdit値を属性に応じた桁数に変換
''' ・ApplyDefaultValues       : デフォルト値を DataRow に設定（予約語変換込み）
''' </summary>
Public Class FieldBuilderDataHelper
    ''' <summary>
    ''' DataRow の指定列の値が、属性型に応じて「空」かどうかを判定する。
    ''' 文字列系: IsNullOrEmpty で判定
    ''' 数値: Decimal=0 で空と判定
    ''' 日付系: Integer=0 で空と判定
    ''' </summary>
    ''' <param name="row">判定対象のデータ行</param>
    ''' <param name="colName">判定対象のDB実列名</param>
    ''' <param name="zokusei">属性型の値（Integer）</param>
    Public Function IsFieldEmpty(
        ByVal row As System.Data.DataRow,
        ByVal colName As String,
        ByVal zokusei As Integer) As Boolean

        If row Is Nothing Then Return True
        If row.Table Is Nothing Then Return True
        If String.IsNullOrEmpty(colName) Then Return True
        If row.Table.Columns.Contains(colName) = False Then Return True

        Dim rawVal As String = ""
        If row.IsNull(colName) = False Then
            rawVal = CStr(row(colName)).TrimEnd()
        End If

        Select Case CType(zokusei, ExpandItemParam.属性型)
            Case ExpandItemParam.属性型.全角文字,
                ExpandItemParam.属性型.半角文字,
                ExpandItemParam.属性型.参照定義コード,
                ExpandItemParam.属性型.画像,
                ExpandItemParam.属性型.実行ファイル,
                ExpandItemParam.属性型.ファイル,
                ExpandItemParam.属性型.フォルダ,
                ExpandItemParam.属性型.URL,
                ExpandItemParam.属性型.メールアドレス
                Return String.IsNullOrEmpty(rawVal)

            Case ExpandItemParam.属性型.数値
                Dim d As Decimal = 0D
                If String.IsNullOrEmpty(rawVal) = False Then
                    Decimal.TryParse(rawVal, d)
                End If
                Return d = 0D

            Case ExpandItemParam.属性型.日付,
                ExpandItemParam.属性型.日付_年度,
                ExpandItemParam.属性型.日付_年月
                Dim n As Integer = 0
                If String.IsNullOrEmpty(rawVal) = False Then
                    Integer.TryParse(rawVal, n)
                End If
                Return n = 0

            Case Else
                Return String.IsNullOrEmpty(rawVal)
        End Select

    End Function


    ''' <summary>
    ''' DB列名（"K001" 等）から番号部分を整数で取得する。（内部用）
    ''' </summary>
    Private Function GetKNumber(ByVal dbColumnName As String) As Integer
        Return CInt(dbColumnName.TrimStart("K"c))
    End Function

    ''' <summary>
    ''' DB列名 + プレフィックスで DB実列名を生成する。（内部用）
    ''' 例: dbColumnName="K001", prefix="CUSRE11K" → "CUSRE11K001"
    ''' </summary>
    Private Function ToCusreColumnName(
            ByVal dbColumnName As String,
            ByVal prefix As String) As String
        Return prefix & GetKNumber(dbColumnName).ToString("D3")
    End Function

    ''' <summary>
    ''' DataTable に FieldBuilder 用のデータ列（CUSRE列）を追加する。
    ''' 既に存在する列はスキップする。
    ''' </summary>
    ''' <param name="dt">対象の DataTable</param>
    ''' <param name="items">FieldBuilder定義型リスト（配置対象の項目群）</param>
    ''' <param name="prefix">DB実列名のプレフィックス（"CUSRE11K" or "CUSRE12K"）</param>
    Public Sub AddFBColumns(
            ByVal dt As System.Data.DataTable,
            ByVal items As List(Of ExpandItemParam.FieldBuilder定義型),
            ByVal prefix As String)

        If dt Is Nothing Then Return
        If items Is Nothing OrElse items.Count = 0 Then Return

        For Each item As ExpandItemParam.FieldBuilder定義型 In items
            Dim colCus As String = ToCusreColumnName(item.DB列名, prefix)
            If Not dt.Columns.Contains(colCus) Then
                dt.Columns.Add(colCus, GetType(String))
            End If
        Next
    End Sub

    ''' <summary>
    ''' FieldBuilder DataTable の値を対象行に展開（コピー）する。
    ''' fbDt が Nothing/空行の場合は何もしない。
    ''' </summary>
    ''' <param name="targetRow">コピー先の DataRow</param>
    ''' <param name="fbDt">FieldBuilder 値を保持する DataTable（行0を使用）</param>
    ''' <param name="items">FieldBuilder定義型リスト</param>
    ''' <param name="prefix">DB実列名のプレフィックス（"CUSRE11K" or "CUSRE12K"）</param>
    Public Sub ExpandFBValues(
            ByVal targetRow As System.Data.DataRow,
            ByVal fbDt As System.Data.DataTable,
            ByVal items As List(Of ExpandItemParam.FieldBuilder定義型),
            ByVal prefix As String)

        If targetRow Is Nothing OrElse targetRow.Table Is Nothing Then Return
        If fbDt Is Nothing OrElse fbDt.Rows.Count = 0 Then Return
        If items Is Nothing OrElse items.Count = 0 Then Return

        For Each item As ExpandItemParam.FieldBuilder定義型 In items
            Dim colCus As String = ToCusreColumnName(item.DB列名, prefix)
            If targetRow.Table.Columns.Contains(colCus) AndAlso fbDt.Columns.Contains(colCus) Then
                targetRow(colCus) = fbDt.Rows(0)(colCus)
            End If
        Next
    End Sub

    ''' <summary>
    ''' DB値（6桁yyyymm / 4桁yyyy）をGridEdit用の8桁日付値に変換する。
    ''' 日付_年月(属性5): 6桁yyyymm → 8桁yyyymm01（日を01で補完）
    ''' 日付_年度(属性6): 4桁yyyy   → 8桁yyyy0101（月・日を0101で補完）
    ''' 上記以外はそのまま返す。
    ''' </summary>
    ''' <param name="rawVal">DBから取得した元の値</param>
    ''' <param name="colName">対象のDB実列名（例: "CUSRE11K001"）</param>
    ''' <param name="items">FieldBuilder定義型のリスト</param>
    ''' <param name="colPrefix">列名プレフィックス（例: "CUSRE11K"）</param>
    Public Function ExpandDateValueForGrid(
            ByVal rawVal As Object,
            ByVal colName As String,
            ByVal items As List(Of ExpandItemParam.FieldBuilder定義型),
            ByVal colPrefix As String) As Object

        If rawVal Is Nothing OrElse rawVal Is DBNull.Value Then Return ""
        Dim strVal As String = CStr(rawVal)
        If strVal = "" Then Return ""
        If items Is Nothing OrElse items.Count = 0 Then Return strVal
        If String.IsNullOrEmpty(colName) Then Return strVal

        ' 対応する FieldBuilder定義型 を検索
        Dim item As ExpandItemParam.FieldBuilder定義型 = Nothing
        Dim itemFound As Boolean = False
        For Each fi As ExpandItemParam.FieldBuilder定義型 In items
            If String.Equals(ToCusreColumnName(fi.DB列名, colPrefix), colName, StringComparison.Ordinal) Then
                item = fi
                itemFound = True
                Exit For
            End If
        Next
        If Not itemFound Then Return strVal

        Select Case item.属性
            Case ExpandItemParam.属性型.日付_年月
                ' 6桁yyyymm → 8桁yyyymm01（日を01で補完）
                Dim n As Integer = 0
                If Integer.TryParse(strVal, n) AndAlso n > 0 Then
                    Return (n * 100 + 1).ToString()
                End If
                Return strVal
            Case ExpandItemParam.属性型.日付_年度
                ' 4桁yyyy → 8桁yyyy0101（月・日を0101で補完）
                Dim n As Integer = 0
                If Integer.TryParse(strVal, n) AndAlso n > 0 Then
                    Return (n * 10000 + 101).ToString()
                End If
                Return strVal
            Case Else
                Return strVal
        End Select
    End Function

    ''' <summary>
    ''' FieldBuilder DataTable の値を対象行に展開する。
    ''' fbDt が Nothing/空行の場合は何もしない。
    ''' </summary>
    ''' <param name="targetRow">コピー先の DataRow</param>
    ''' <param name="fbDt">FieldBuilder 値を保持する DataTable（行0を使用）</param>
    ''' <param name="items">FieldBuilder定義型リスト</param>
    ''' <param name="colPrefix">列名プレフィックス（"CUSRE11K" or "CUSRE12K"）</param>
    Public Sub ExpandFBValues_Grid(
            ByVal targetRow As System.Data.DataRow,
            ByVal fbDt As System.Data.DataTable,
            ByVal items As List(Of ExpandItemParam.FieldBuilder定義型),
            ByVal colPrefix As String)

        If targetRow Is Nothing OrElse targetRow.Table Is Nothing Then Return
        If fbDt Is Nothing OrElse fbDt.Rows.Count = 0 Then Return
        If items Is Nothing OrElse items.Count = 0 Then Return

        Dim fbRow As System.Data.DataRow = fbDt.Rows(0)
        For Each item As ExpandItemParam.FieldBuilder定義型 In items
            Dim colCus As String = ToCusreColumnName(item.DB列名, colPrefix)
            If Not targetRow.Table.Columns.Contains(colCus) Then Continue For
            If Not fbDt.Columns.Contains(colCus) Then Continue For

            Dim rawVal As Object = fbRow(colCus)
            If rawVal Is Nothing OrElse rawVal Is DBNull.Value Then
                targetRow(colCus) = ""
                Continue For
            End If
            Dim strVal As String = CStr(rawVal)
            If strVal = "" Then
                targetRow(colCus) = ""
                Continue For
            End If
            Select Case item.属性
                Case ExpandItemParam.属性型.日付_年月
                    Dim n As Integer = 0
                    targetRow(colCus) = If(Integer.TryParse(strVal, n) AndAlso n > 0, (n * 100 + 1).ToString(), strVal)
                Case ExpandItemParam.属性型.日付_年度
                    Dim n As Integer = 0
                    targetRow(colCus) = If(Integer.TryParse(strVal, n) AndAlso n > 0, (n * 10000 + 101).ToString(), strVal)
                    'A-CUST20260501↓
                Case ExpandItemParam.属性型.参照定義コード
                    ' ConvertGridDataValue で正規化済みの値をそのまま表示
                    targetRow(colCus) = strVal
                    'A-CUST20260501↑
                Case Else
                    targetRow(colCus) = strVal

            End Select
        Next
    End Sub

    ''' <summary>
    ''' GridEditのGetDataが返す値を属性に応じた桁数に変換する。
    ''' 日付_年月(属性5): 8桁yyyymmdd → 6桁yyyymm
    ''' 日付_年度(属性6): 8桁yyyymmdd → 4桁yyyy
    ''' 参照定義コード(属性7): 数字のみの場合、定義桁数まで左0埋め（例: 桁数11、1001 → 00000001001）
    ''' 上記以外はそのまま返す。
    ''' </summary>
    ''' <param name="rawVal">GridEditから取得した値</param>
    ''' <param name="colName">対象のDB実列名（例: "CUSRE11K001"）</param>
    ''' <param name="items">FieldBuilder定義型のリスト</param>
    ''' <param name="colPrefix">列名プレフィックス（例: "CUSRE11K"）</param>
    Public Function ConvertGridDataValue(
            ByVal rawVal As Object,
            ByVal colName As String,
            ByVal items As List(Of ExpandItemParam.FieldBuilder定義型),
            ByVal colPrefix As String) As Object

        If rawVal Is Nothing OrElse rawVal Is DBNull.Value Then Return ""
        Dim strVal As String = CStr(rawVal)
        If strVal = "" Then Return ""
        If items Is Nothing OrElse items.Count = 0 Then Return strVal
        If String.IsNullOrEmpty(colName) Then Return strVal

        ' 対応する FieldBuilder定義型 を検索
        Dim item As ExpandItemParam.FieldBuilder定義型 = Nothing
        Dim itemFound As Boolean = False
        For Each fi As ExpandItemParam.FieldBuilder定義型 In items
            If String.Equals(ToCusreColumnName(fi.DB列名, colPrefix), colName, StringComparison.Ordinal) Then
                item = fi
                itemFound = True
                Exit For
            End If
        Next
        If Not itemFound Then Return strVal

        Select Case item.属性
            Case ExpandItemParam.属性型.日付_年月
                ' 8桁 → 上6桁(yyyymm)
                Dim n As Integer = 0
                If Integer.TryParse(strVal, n) AndAlso n > 0 Then
                    Return (n \ 100).ToString()
                End If
                Return strVal
            Case ExpandItemParam.属性型.日付_年度
                ' 8桁 → 上4桁(yyyy)
                Dim n As Integer = 0
                If Integer.TryParse(strVal, n) AndAlso n > 0 Then
                    Return (n \ 10000).ToString()
                End If
                Return strVal

            'A-CUST20260501↓
            Case ExpandItemParam.属性型.参照定義コード

                Dim hasNonDigit As Boolean = False
                For Each ch As Char In strVal
                    If Char.IsDigit(ch) = False Then
                        hasNonDigit = True
                        Exit For
                    End If
                Next


                'コードタイプで考える
                '文字コードの場合→そのまま
                If item.タイプ = 1 Then
                    Return strVal
                    '数値コードの場合→定義桁数で左ゼロ埋め
                Else
                    If item.桁数 > 0 AndAlso strVal.Length < item.桁数 Then
                        Return strVal.PadLeft(item.桁数, "0"c)
                    End If
                End If

                Return strVal
                'A-CUST20260501↑
            Case Else
                Return strVal
        End Select
    End Function

    ''' <summary>
    ''' FieldBuilder定義に基づき、DataRow にデフォルト値を設定する。
    ''' SubForm.RememberDefaults + ReservedWordConv 相当をグリッド向けに実装。
    ''' 予約語（@SYSDATE/@USERID）は環境値に変換する。
    ''' デフォルト値が未設定の項目はスキップする。
    ''' </summary>
    ''' <param name="row">デフォルト値を設定する DataRow</param>
    ''' <param name="items">FieldBuilder定義型リスト（配置対象の項目群）</param>
    ''' <param name="prefix">DB実列名のプレフィックス（"CUSRE11K" or "CUSRE12K"）</param>
    ''' <param name="systdate">システム日付（yyyyMMdd 形式の整数）</param>
    ''' <param name="userId">ログインユーザーID</param>
    Public Sub ApplyDefaultValues(
            ByVal row As System.Data.DataRow,
            ByVal items As List(Of ExpandItemParam.FieldBuilder定義型),
            ByVal prefix As String,
            ByVal systdate As Integer,
            ByVal userId As String)

        If row Is Nothing OrElse row.Table Is Nothing Then Return
        If items Is Nothing OrElse items.Count = 0 Then Return

        For Each item As ExpandItemParam.FieldBuilder定義型 In items
            If item.デフォルト値 Is Nothing OrElse item.デフォルト値.Count = 0 Then Continue For

            Dim defaultVal As String = item.デフォルト値(0)
            If String.IsNullOrEmpty(defaultVal) Then Continue For

            If String.Equals(defaultVal, "@SYSDATE", StringComparison.OrdinalIgnoreCase) Then
                Select Case item.属性
                    Case ExpandItemParam.属性型.日付_年月
                        defaultVal = (systdate \ 100).ToString()

                    Case ExpandItemParam.属性型.日付_年度
                        defaultVal = (systdate \ 10000).ToString()

                    Case Else
                        defaultVal = systdate.ToString()
                End Select

            ElseIf String.Equals(defaultVal, "@USERID", StringComparison.OrdinalIgnoreCase) Then
                If userId Is Nothing Then
                    defaultVal = ""
                Else
                    defaultVal = userId
                End If
            Else
                Select Case item.属性
                    Case ExpandItemParam.属性型.日付_年月
                        If defaultVal.Length >= 8 Then
                            defaultVal = defaultVal.Substring(0, 6)
                        End If

                    Case ExpandItemParam.属性型.日付_年度
                        If defaultVal.Length >= 8 Then
                            defaultVal = defaultVal.Substring(0, 4)
                        End If
                End Select
            End If

            Dim colCus As String = ToCusreColumnName(item.DB列名, prefix)

            If row.Table.Columns.Contains(colCus) Then
                row(colCus) = defaultVal
            End If
        Next

    End Sub

End Class
'A-CUST20260407↑
