'A-CUST20260407↓
''' <summary>
''' FieldBuilder 明細グリッドのレイアウト計算を担う共通ヘルパー。
''' ・SortItems         : 行位置 → 表示順 → 入力順 の優先度でソート
''' ・DistributeIntoRows: ソート済みリストを行位置に従って行に振り分ける
''' </summary>
Public Class FieldBuilderLayoutHelper

    ''' <summary>
    ''' 項目リストを「行位置 → 表示順 → 入力順」の優先度で昇順ソートした新リストを返す。
    ''' 元のリストは変更しない。
    ''' items が Nothing または空の場合は、空のリストを返す。
    ''' </summary>
    ''' <param name="items">元の FieldBuilder定義型 リスト</param>
    Public Function SortItems(
            ByVal items As List(Of ExpandItemParam.FieldBuilder定義型)) _
            As List(Of ExpandItemParam.FieldBuilder定義型)

        Dim result As New List(Of ExpandItemParam.FieldBuilder定義型)

        If items Is Nothing OrElse items.Count = 0 Then
            Return result
        End If

        ' インデックス付きペアを作り、元の順序キーとして使う
        Dim indexed As New List(Of IndexedItem)
        For i As Integer = 0 To items.Count - 1
            indexed.Add(New IndexedItem With {.Item = items(i), .OriginalIndex = i})
        Next

        ' 安定ソート: 行位置 → 表示順あり優先/昇順 → 表示順なし → 元の順序
        indexed.Sort(AddressOf CompareIndexedItems)

        For Each x As IndexedItem In indexed
            result.Add(x.Item)
        Next
        Return result
    End Function

    ''' <summary>
    ''' ソート済み項目リストを、FieldBuilder定義の行位置に従って行に振り分ける。
    ''' getWidth は行幅集計用に使用するが、配置行の決定には使用しない。
    ''' </summary>
    ''' <param name="sortedItems">SortItems() の戻り値</param>
    ''' <param name="getWidth">項目→ピクセル幅を返すコールバック。行幅集計用。</param>
    ''' <returns>行ごとの項目リスト。rows(0) が1行目、rows(1) が2行目 …</returns>
    Public Function DistributeIntoRows(
            ByVal sortedItems As List(Of ExpandItemParam.FieldBuilder定義型),
            ByVal getWidth As Func(Of ExpandItemParam.FieldBuilder定義型, Integer)) _
            As List(Of List(Of ExpandItemParam.FieldBuilder定義型)) 'A-CUST20260501
        'D-CUST20260501↓
        ' Public Function DistributeIntoRows(
        '         ByVal sortedItems As List(Of ExpandItemParam.FieldBuilder定義型),
        '         ByVal dataWidthLimit As Integer,
        '         ByVal getWidth As Func(Of ExpandItemParam.FieldBuilder定義型, Integer)) _
        '         As List(Of List(Of ExpandItemParam.FieldBuilder定義型))
        'D-CUST20260501↑
        Dim rows As New List(Of List(Of ExpandItemParam.FieldBuilder定義型))
        Dim rowWidths As New List(Of Integer)
        rows.Add(New List(Of ExpandItemParam.FieldBuilder定義型))
        rowWidths.Add(0)

        If sortedItems Is Nothing OrElse sortedItems.Count = 0 Then
            Return rows
        End If

        For Each item As ExpandItemParam.FieldBuilder定義型 In sortedItems
            'Dim colWidth As Integer = getWidth(item)
            Dim reqRowIdx As Integer = Math.Max(1, item.行位置) - 1  ' 0-indexed

            ' 要求行まで行コンテナを拡張
            EnsureRowCount(rows, rowWidths, reqRowIdx + 1)

            '' 要求行から始めて収まる行を探す（空行なら幅に関わらず必ず配置）
            'Dim j As Integer = reqRowIdx
            'Do
            '    ' If CanFit(rowWidths(j), colWidth, dataWidthLimit) Then
            '    rows(j).Add(item)
            '        rowWidths(j) += colWidth
            '    '    Exit Do
            '    'End If
            '    j += 1
            '    EnsureRowCount(rows, rowWidths, j + 1)
            'Loop
            rows(reqRowIdx).Add(item)

            Dim colWidth As Integer = 0
            If getWidth IsNot Nothing Then
                colWidth = getWidth(item)
            End If
            rowWidths(reqRowIdx) += colWidth

        Next

        Return rows
    End Function

    ' -----------------------------------------------------------------------
    ' Private helpers
    ' -----------------------------------------------------------------------

    ''' <summary>指定した数の行が存在するよう行コンテナを拡張する</summary>
    Private Sub EnsureRowCount(
            ByVal rows As List(Of List(Of ExpandItemParam.FieldBuilder定義型)),
            ByVal widths As List(Of Integer),
            ByVal requiredCount As Integer)
        While rows.Count < requiredCount
            rows.Add(New List(Of ExpandItemParam.FieldBuilder定義型))
            widths.Add(0)
        End While
    End Sub

    'D-CUST20260501↓
    '''' <summary>空行（usedWidth=0）または幅が収まる場合 True を返す</summary>
    ' Private Function CanFit(
    '         ByVal usedWidth As Integer,
    '         ByVal colWidth As Integer,
    '         ByVal limit As Integer) As Boolean
    '     Return usedWidth = 0 OrElse usedWidth + colWidth <= limit
    ' End Function
    'D-CUST20260501↑

    ''' <summary>SortItems 内部で使うインデックス付き作業用型</summary>
    Private Class IndexedItem
        Public Property Item As ExpandItemParam.FieldBuilder定義型
        Public Property OriginalIndex As Integer
    End Class

    ''' <summary>
    ''' IndexedItem の比較ロジック。
    ''' 優先度: ①行位置昇順 → ②表示順あり(>0)を昇順 → ③表示順なし(0)は後ろ → ④元の順序
    ''' </summary>
    Private Function CompareIndexedItems(
            ByVal a As IndexedItem,
            ByVal b As IndexedItem) As Integer

        ' ① 行位置
        Dim rowComp As Integer = CompareSettingRow(a.Item, b.Item)
        If rowComp <> 0 Then Return rowComp

        ' ② 表示順（指定あり同士）
        Dim orderComp As Integer = CompareHaichiJun(a.Item, b.Item)
        If orderComp <> 0 Then Return orderComp

        ' ③ 元の入力順（キーが同じ場合の安定化）
        Return a.OriginalIndex.CompareTo(b.OriginalIndex)
    End Function

    ''' <summary>行位置で比較（昇順）</summary>
    Private Function CompareSettingRow(
            ByVal a As ExpandItemParam.FieldBuilder定義型,
            ByVal b As ExpandItemParam.FieldBuilder定義型) As Integer
        Return a.行位置.CompareTo(b.行位置)
    End Function

    ''' <summary>
    ''' 表示順で比較。
    ''' ・両方 0（未指定）→ 0（差なし：元の順序に委ねる）
    ''' ・片方だけ指定あり → 指定あり側を先にする
    ''' ・両方指定あり → 昇順
    ''' </summary>
    Private Function CompareHaichiJun(
            ByVal a As ExpandItemParam.FieldBuilder定義型,
            ByVal b As ExpandItemParam.FieldBuilder定義型) As Integer
        Dim aHas As Boolean = (a.表示順 > 0)
        Dim bHas As Boolean = (b.表示順 > 0)

        If aHas AndAlso bHas Then Return a.表示順.CompareTo(b.表示順)  ' 両方あり: 昇順
        If aHas Then Return -1                                           ' a だけあり: a が先
        If bHas Then Return 1                                            ' b だけあり: b が先
        Return 0                                                         ' 両方なし: 差なし
    End Function

End Class
'A-CUST20260407↑
