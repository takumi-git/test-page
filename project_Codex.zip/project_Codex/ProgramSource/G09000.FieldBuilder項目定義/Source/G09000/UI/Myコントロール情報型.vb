﻿'Public Class Myコントロール情報型
'    Inherits OSK.X1.Foundation.Base    'X1変換Tool-20160427

'    Private _ＲＥＶ型 As ＲＥＶ型                                                                           'A-20080709_2 & A-20080709_3 & A-20080709_4 
'    Private _オプション区分型 As オプション区分型
'    Private _機能区分型 As 機能区分型
'    Private _売上処理型 As 売上処理型
'    Private _伝票承認型 As OSK.X1.HAN.LIB.ControlInfoC001.伝票承認型               'A-20101213_2    'X1変換Tool-20160427
'    Private _その他型 As OSK.X1.HAN.LIB.ControlInfoC001.その他型                   'A-20121120_1    'X1変換Tool-20160427
'    Private _桁数拡張型 As OSK.X1.HAN.LIB.ControlInfoC001.桁数拡張型               'A-20160817-X1-桁数拡張
'    Private _拡張項目型 As OSK.X1.HAN.LIB.ControlInfoC001.拡張項目型               'A-20180314-X1-新元号
'    Private _マスター申請承認X1型 As OSK.X1.HAN.LIB.ControlInfoC001.マスター申請承認X1型      'A-20180919-X1-マスター申請承認機能
'    Private _スマートサーチ型 As OSK.X1.HAN.LIB.ControlInfoC001.スマートサーチ型 'A-20191213-X1-スマートサーチ機能
'    Private _外部データ自動入力 As OSK.X1.HAN.LIB.ControlInfoC001.外部データ自動入力型        'A-20220408-X1.A-入力データ取込機能

'#Region "コンストラクタ"

'    Sub New()
'        _ＲＥＶ型 = New ＲＥＶ型                                                                            'A-20080709_2 & A-20080709_3 & A-20080709_4 
'        _オプション区分型 = New オプション区分型
'        _機能区分型 = New 機能区分型
'        _売上処理型 = New 売上処理型
'        _伝票承認型 = New OSK.X1.HAN.LIB.ControlInfoC001.伝票承認型                'A-20101213_2    'X1変換Tool-20160427
'        _その他型 = New OSK.X1.HAN.LIB.ControlInfoC001.その他型                    'A-20121120_1    'X1変換Tool-20160427
'        _桁数拡張型 = New OSK.X1.HAN.LIB.ControlInfoC001.桁数拡張型                'A-20160817-X1-桁数拡張
'        _拡張項目型 = New OSK.X1.HAN.LIB.ControlInfoC001.拡張項目型　　　　　　　　'A-20180314-X1-新元号
'        _マスター申請承認X1型 = New OSK.X1.HAN.LIB.ControlInfoC001.マスター申請承認X1型       'A-20180919-X1-マスター申請承認機能
'        _スマートサーチ型 = New OSK.X1.HAN.LIB.ControlInfoC001.スマートサーチ型 'A-20191213-X1-スマートサーチ機能
'        _外部データ自動入力 = New OSK.X1.HAN.LIB.ControlInfoC001.外部データ自動入力型         'A-20220408-X1.A-入力データ取込機能
'    End Sub

'#End Region

'#Region "メソッド"

'    Public Sub InitializeMyControlInfo(ByVal initInfo As IDictionary)

'        Dim controlGetter As IHANControlInfoGetter
'        controlGetter = CommonFactory.CreateInstance(Of IHANControlInfoGetter)(Me, GetType(HANControlInfoGetter))
'        Dim controlInfoC001 As IDictionary
'        controlInfoC001 = controlGetter.GetControlInfo(initInfo, IHANControlInfoGetter.コントロール型.HANコントロールテーブル)

'        _ＲＥＶ型.Initialize(controlInfoC001)                                                               'A-20080709_2 & A-20080709_3 & A-20080709_4 
'        _オプション区分型.Initialize(controlInfoC001)
'        _機能区分型.Initialize(controlInfoC001)
'        _売上処理型.Initialize(controlInfoC001)
'        _伝票承認型.Initialize(controlInfoC001)                 'A-20101213_2
'        _その他型.Initialize(controlInfoC001)                   'A-20121120_1
'        _桁数拡張型.Initialize(controlInfoC001)                 'A-20160817-X1-桁数拡張
'        _拡張項目型.Initialize(controlInfoC001)                 'A-20180314-X1-新元号
'        _マスター申請承認X1型.Initialize(controlInfoC001)       'A-20180919-X1-マスター申請承認機能
'        _スマートサーチ型.Initialize(controlInfoC001)           'A-20191213-X1-スマートサーチ機能
'        _外部データ自動入力.Initialize(controlInfoC001)         'A-20220408-X1.A-入力データ取込機能
'    End Sub

'#End Region

'#Region "プロパティ"

'    Public ReadOnly Property 強化区分() As Decimal                                                          'A-20080709_2 & A-20080709_3 & A-20080709_4 
'        Get
'            Return _ＲＥＶ型.強化区分
'        End Get
'    End Property

'    Public ReadOnly Property 受発注管理() As オプション区分定義型.区分型
'        Get
'            Return _オプション区分型.受発注管理
'        End Get
'    End Property

'    Public ReadOnly Property 見積管理() As オプション区分定義型.区分型
'        Get
'            Return _オプション区分型.見積管理
'        End Get
'    End Property

'    Public ReadOnly Property 部門管理() As オプション区分定義型.区分型
'        Get
'            Return _オプション区分型.部門管理
'        End Get
'    End Property

'    Public ReadOnly Property 原価管理() As オプション区分定義型.区分型                                      'A-20080709_2
'        Get
'            Return _オプション区分型.原価管理
'        End Get
'    End Property

'    Public ReadOnly Property ロット管理() As オプション区分定義型.区分型                                    'A-20091125_1
'        Get
'            Return _オプション区分型.ロット管理
'        End Get
'    End Property

'    Public ReadOnly Property 倉庫管理() As 機能区分定義型.倉庫別在庫管理型
'        Get
'            Return _機能区分型.倉庫別在庫管理
'        End Get
'    End Property

'    Public ReadOnly Property 営業所管理() As 機能区分定義型.営業所管理区分型
'        Get
'            Return _機能区分型.営業所管理
'        End Get
'    End Property

'    Public ReadOnly Property 拡張項目データリンク機能() As 機能区分定義型.拡張項目データリンク機能型        'A-20080709_3
'        Get
'            Return _機能区分型.拡張項目データリンク機能
'        End Get
'    End Property

'    Public ReadOnly Property 定期取引作成機能() As 機能区分定義型.定期取引作成機能型                        'A-20080709_4
'        Get
'            Return _機能区分型.定期取引作成機能
'        End Get
'    End Property

'    'A-20151116_1{
'    Public ReadOnly Property 受発注_入出荷_消費税入力() As 機能区分定義型.受発注_入出荷_消費税入力型
'        Get
'            Return _機能区分型.受発注_入出荷_消費税入力
'        End Get
'    End Property
'    'A-20151116_1}
'    '↓A-20220408-X1.A-入力データ取込機能
'    Public ReadOnly Property 外部データ取込機能() As 機能区分定義型.外部データ取込機能型
'        Get
'            Return _機能区分型.外部データ取込機能
'        End Get
'    End Property
'    '↑A-20220408-X1.A-入力データ取込機能


'    Public ReadOnly Property 売上処理_お届け先() As 売上処理定義型.お届け先使用区分型
'        Get
'            Return _売上処理型.お届け先
'        End Get
'    End Property

'    '↓A-20170428-X1-付箋ＵＩ改善
'    Public ReadOnly Property Is付箋アイコン表示 As Boolean
'        Get
'            If _機能区分型.付箋アイコン表示 = 機能区分定義型.付箋アイコン表示型.行う Then
'                Return True
'            End If
'            Return False
'        End Get
'    End Property
'    '↑A-20170428-X1-付箋ＵＩ改善

'    'A-20101213_1{
'#Region "伝票申請承認機能対応"
'    Public ReadOnly Property 伝票承認機能使用区分() As OSK.X1.HAN.LIB.ControlInfoC001.伝票承認定義型.区分型    'X1変換Tool-20160427
'        Get
'            Return _伝票承認型.伝票承認機能使用区分
'        End Get
'    End Property
'    Public ReadOnly Property 見積伝票承認使用区分() As OSK.X1.HAN.LIB.ControlInfoC001.伝票承認定義型.区分型    'X1変換Tool-20160427
'        Get
'            Return _伝票承認型.見積伝票承認使用区分
'        End Get
'    End Property
'    Public ReadOnly Property 受注伝票承認使用区分() As OSK.X1.HAN.LIB.ControlInfoC001.伝票承認定義型.区分型    'X1変換Tool-20160427
'        Get
'            Return _伝票承認型.受注伝票承認使用区分
'        End Get
'    End Property
'    Public ReadOnly Property 発注伝票承認使用区分() As OSK.X1.HAN.LIB.ControlInfoC001.伝票承認定義型.区分型    'X1変換Tool-20160427
'        Get
'            Return _伝票承認型.発注伝票承認使用区分
'        End Get
'    End Property
'#End Region
'    'A-20101213_1}

'    'A-20101213_2{
'#Region "検収基準対応"
'    Public ReadOnly Property 検収基準() As OSK.X1.HAN.LIB.ControlInfoC001.機能区分定義型.検収基準型    'X1変換Tool-20160427
'        Get
'            Return _機能区分型.検収基準
'        End Get
'    End Property
'    Public ReadOnly Property 着荷基準() As OSK.X1.HAN.LIB.ControlInfoC001.機能区分定義型.着荷基準型    'X1変換Tool-20160427
'        Get
'            Return _機能区分型.着荷基準
'        End Get
'    End Property
'#End Region
'    'A-20101213_2}

'    'A-20121120_1{
'#Region "その他"
'    Public ReadOnly Property 予定在庫区分_入出庫() As OSK.X1.HAN.LIB.ControlInfoC001.その他定義型.予定在庫区分_入出庫型    'X1変換Tool-20160427
'        Get
'            Return _その他型.予定在庫区分_入出庫
'        End Get
'    End Property
'#End Region
'    'A-20121120_1}
'    '↓A-20160817-X1-桁数拡張
'#Region "桁数拡張"
'    Public ReadOnly Property 拡張項目データリンク桁数拡張() As Boolean
'        Get
'            If _桁数拡張型.拡張項目データリンク桁数拡張 = 桁数拡張定義型.拡張項目データリンク桁数拡張型.使用する Then
'                Return True
'            End If
'            Return False
'        End Get
'    End Property

'    Public ReadOnly Property 拡張項目数値型桁数拡張 As Boolean
'        Get
'            If _桁数拡張型.拡張項目数値型桁数拡張 = 桁数拡張定義型.拡張項目数値型桁数拡張型.使用する Then
'                Return True
'            End If
'            Return False
'        End Get
'    End Property
'#End Region
'    '↑A-20160817-X1-桁数拡張
'    '↓A-20180314-X1-新元号
'#Region "年度"
'    Public ReadOnly Property 年属性_年月属性表現方法 As 拡張項目設計型.年属性_年月属性表現方法型
'        Get
'            Return _拡張項目型.年属性_年月属性表現方法
'        End Get
'    End Property
'#End Region

'    '↑A-20180314-X1-新元号

'    '↓A-20180919-X1-マスター申請承認機能
'#Region "マスター申請承認機能対応"
'    Public ReadOnly Property マスター申請承認機能_ワークフロー販売連携() As マスター申請承認X1定義型.区分型
'        Get
'            Return _マスター申請承認X1型.マスター申請承認機能_ワークフロー販売連携
'        End Get
'    End Property
'    Public ReadOnly Property 得意先マスター承認() As マスター申請承認X1定義型.区分型
'        Get
'            Return _マスター申請承認X1型.得意先マスター承認
'        End Get
'    End Property
'    Public ReadOnly Property 仕入先マスター承認() As マスター申請承認X1定義型.区分型
'        Get
'            Return _マスター申請承認X1型.仕入先マスター承認
'        End Get
'    End Property
'    Public ReadOnly Property 商品マスター承認() As マスター申請承認X1定義型.区分型
'        Get
'            Return _マスター申請承認X1型.商品マスター承認
'        End Get
'    End Property
'    Public ReadOnly Property 原価集計マスター承認() As マスター申請承認X1定義型.区分型
'        Get
'            Return _マスター申請承認X1型.原価集計マスター承認
'        End Get
'    End Property
'#End Region
'    '↑A-20180919-X1-マスター申請承認機能

'    '↓A-20191213-X1-スマートサーチ機能
'#Region "スマートサーチ機能対応"
'    Public ReadOnly Property スマートサーチ機能() As スマートサーチ定義型.スマートサーチ機能使用区分型
'        Get
'            Return _スマートサーチ型.スマートサーチ機能使用区分
'        End Get
'    End Property
'#End Region
'    '↑A-20191213-X1-スマートサーチ機能

'    '↓A-20220408-X1.A-入力データ取込機能
'#Region "外部データ自動入力"
'    Public ReadOnly Property 入金データ自動入力() As 外部データ自動入力定義型.入金データ自動入力型
'        Get
'            Return _外部データ自動入力.入金データ自動入力
'        End Get
'    End Property
'    '↓A-20220926-X1-仕入データ自動入力
'    Public ReadOnly Property 仕入データ自動入力() As 外部データ自動入力定義型.仕入データ自動入力型
'        Get
'            Return _外部データ自動入力.仕入データ自動入力
'        End Get
'    End Property
'    '↑A-20220926-X1-仕入データ自動入力
'#End Region
'    '↑A-20220408-X1.A-入力データ取込機能
'#End Region

'End Class
