﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CommandView
    Inherits OSK.X1.Foundation.Batch.UserInterface.CommandViewBase

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Item1 As OSK.X1.Foundation.Controls.GroupOptionImpl.Item = New OSK.X1.Foundation.Controls.GroupOptionImpl.Item()
        Dim Item2 As OSK.X1.Foundation.Controls.GroupOptionImpl.Item = New OSK.X1.Foundation.Controls.GroupOptionImpl.Item()
        Dim Item3 As OSK.X1.Foundation.Controls.GroupOptionImpl.Item = New OSK.X1.Foundation.Controls.GroupOptionImpl.Item()
        Dim ColumnAttributeInfo1 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo2 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo3 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo4 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo5 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo6 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo7 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim ColumnAttributeInfo8 As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo = New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(CommandView))
        Dim SortRange1 As OSK.X1.Foundation.Controls.Grid.Common.SortRange = New OSK.X1.Foundation.Controls.Grid.Common.SortRange()
        Dim FunctionControlList1 As OSK.X1.Foundation.SmartControl.FunctionBar.FunctionControlList = New OSK.X1.Foundation.SmartControl.FunctionBar.FunctionControlList()
        Me.execute = New OSK.X1.Foundation.SimpleControl.CommandButton()
        Me.mainPanel = New OSK.X1.Foundation.SimpleControl.Panel(Me.components)
        Me.shoriModeLabel = New OSK.X1.Foundation.SimpleControl.Label()
        Me.conditionPanel = New OSK.X1.Foundation.SimpleControl.Panel(Me.components)
        Me.meisaiKubun = New OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemNameAndInputName()
        Me.dataShurui = New OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemNameAndInputName()
        Me.complete = New OSK.X1.Foundation.SimpleControl.CommandButton()
        Me.shori = New OSK.X1.Foundation.SimpleControl.GroupOption()
        Me.subPanel = New OSK.X1.Foundation.SimpleControl.Panel(Me.components)
        Me.gridEntry = New OSK.X1.Foundation.SimpleControl.GridEdit(Me.components)
        Me.FunctionBar1 = New OSK.X1.Foundation.SmartControl.FunctionBar.FunctionBar()
        Me.ColorDialogForm = New OSK.X1.Foundation.SmartControl.ColorDialogForm.ColorDialogForm()
        Me.basePanel.ContentPanel.SuspendLayout()
        Me.basePanel.SuspendLayout()
        Me.mainPanel.SuspendLayout()
        Me.conditionPanel.SuspendLayout()
        Me.subPanel.SuspendLayout()
        Me.SuspendLayout()
        '
        'basePanel
        '
        Me.basePanel.BottomToolStripPanelVisible = True
        '
        'basePanel.ContentPanel
        '
        Me.basePanel.ContentPanel.Controls.Add(Me.FunctionBar1)
        Me.basePanel.ContentPanel.Controls.Add(Me.mainPanel)
        Me.basePanel.ContentPanel.Controls.Add(Me.execute)
        Me.basePanel.ContentPanel.Size = New System.Drawing.Size(877, 522)
        Me.basePanel.LeftToolStripPanelVisible = True
        Me.basePanel.RightToolStripPanelVisible = True
        Me.basePanel.Size = New System.Drawing.Size(877, 593)
        Me.basePanel.TopToolStripPanelVisible = True
        '
        'execute
        '
        Me.execute.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.execute.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.execute.FocusBackColor = System.Drawing.Color.Empty
        Me.execute.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.execute.GroupNo = 2
        Me.execute.Image = Nothing
        Me.execute.Location = New System.Drawing.Point(782, 470)
        Me.execute.Name = "execute"
        Me.execute.NextByDownKey = False
        Me.execute.NextByEnterKey = False
        Me.execute.NextByTabKey = False
        Me.execute.RemarkString = Nothing
        Me.execute.Size = New System.Drawing.Size(80, 24)
        Me.execute.SubGroupNo = 2
        Me.execute.TabIndex = 14
        Me.execute.Text = "実行"
        Me.execute.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'mainPanel
        '
        Me.mainPanel.AutoScroll = True
        Me.mainPanel.BackColor = System.Drawing.SystemColors.Control
        Me.mainPanel.BorderStyle = OSK.X1.Foundation.Controls.Panel.BorderStyleType.None
        Me.mainPanel.Controls.Add(Me.shoriModeLabel)
        Me.mainPanel.Controls.Add(Me.conditionPanel)
        Me.mainPanel.Controls.Add(Me.subPanel)
        Me.mainPanel.Location = New System.Drawing.Point(3, 3)
        Me.mainPanel.Name = "mainPanel"
        Me.mainPanel.Size = New System.Drawing.Size(859, 461)
        Me.mainPanel.TabIndex = 0
        Me.mainPanel.Text = "Panel2"
        '
        'shoriModeLabel
        '
        Me.shoriModeLabel.BackColor = System.Drawing.Color.Transparent
        Me.shoriModeLabel.BorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.SingleBold
        Me.shoriModeLabel.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.shoriModeLabel.Location = New System.Drawing.Point(439, 91)
        Me.shoriModeLabel.Name = "shoriModeLabel"
        Me.shoriModeLabel.Size = New System.Drawing.Size(81, 19)
        Me.shoriModeLabel.TabIndex = 6
        Me.shoriModeLabel.Tag = "@EXCEPTION@"
        Me.shoriModeLabel.Text = "新規データ"
        Me.shoriModeLabel.TextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Equal
        Me.shoriModeLabel.Visible = False
        '
        'conditionPanel
        '
        Me.conditionPanel.BackColor = System.Drawing.SystemColors.Info
        Me.conditionPanel.BorderColor = System.Drawing.SystemColors.Window
        Me.conditionPanel.BorderStyle = OSK.X1.Foundation.Controls.Panel.BorderStyleType.Narrow
        Me.conditionPanel.Controls.Add(Me.meisaiKubun)
        Me.conditionPanel.Controls.Add(Me.dataShurui)
        Me.conditionPanel.Controls.Add(Me.complete)
        Me.conditionPanel.Controls.Add(Me.shori)
        Me.conditionPanel.Location = New System.Drawing.Point(9, 9)
        Me.conditionPanel.Name = "conditionPanel"
        Me.conditionPanel.Size = New System.Drawing.Size(424, 108)
        Me.conditionPanel.TabIndex = 0
        Me.conditionPanel.Tag = "@KeyArea@"
        Me.conditionPanel.Text = "Panel1"
        '
        'meisaiKubun
        '
        Me.meisaiKubun.AllowBottomPosition = True
        Me.meisaiKubun.AutoResizeDispName = True
        Me.meisaiKubun.AutoResizeInputControl = True
        Me.meisaiKubun.BackColor = System.Drawing.Color.Transparent
        Me.meisaiKubun.DispNameAreaHeight = 19
        Me.meisaiKubun.DispNameAreaWidth = 210
        Me.meisaiKubun.DispNameBorderColor = System.Drawing.SystemColors.Window
        Me.meisaiKubun.DispNameBorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.meisaiKubun.DispNameSpace = 3
        Me.meisaiKubun.DispNameText = ""
        Me.meisaiKubun.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.meisaiKubun.GroupNo = 0
        Me.meisaiKubun.Indent = 0
        Me.meisaiKubun.InnerSpace = 3
        Me.meisaiKubun.InputAreaFont = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.meisaiKubun.InputControlReadOnly = False
        Me.meisaiKubun.InputControlSize = New System.Drawing.Size(23, 19)
        Me.meisaiKubun.InputTextImeMode = OSK.X1.Foundation.Controls.InputText.ImeModeType.NoControl
        Me.meisaiKubun.InputType = OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemNameAndInputName.InputModeType.数値のみ
        Me.meisaiKubun.ItemName = "明細区分"
        Me.meisaiKubun.ItemNameAreaHeight = 19
        Me.meisaiKubun.ItemNameAreaWidth = 100
        Me.meisaiKubun.ItemNameBorderColor = System.Drawing.SystemColors.Window
        Me.meisaiKubun.ItemNameBorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.meisaiKubun.ItemNameFont = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.meisaiKubun.ItemNameTextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Equal
        Me.meisaiKubun.Location = New System.Drawing.Point(9, 80)
        Me.meisaiKubun.Margin = New System.Windows.Forms.Padding(0)
        Me.meisaiKubun.MaxLength = 2
        Me.meisaiKubun.MaxLengthMode = OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CharCount
        Me.meisaiKubun.Name = "meisaiKubun"
        Me.meisaiKubun.RemarkString = Nothing
        Me.meisaiKubun.Size = New System.Drawing.Size(339, 19)
        Me.meisaiKubun.SubGroupNo = 0
        Me.meisaiKubun.TabIndex = 4
        Me.meisaiKubun.Tag = "@KeyArea@"
        Me.meisaiKubun.TextValue = ""
        Me.meisaiKubun.ZeroFill = True
        Me.meisaiKubun.ZeroFillAlways = False
        '
        'dataShurui
        '
        Me.dataShurui.AllowBottomPosition = True
        Me.dataShurui.AutoResizeDispName = True
        Me.dataShurui.AutoResizeInputControl = True
        Me.dataShurui.BackColor = System.Drawing.Color.Transparent
        Me.dataShurui.DispNameAreaHeight = 19
        Me.dataShurui.DispNameAreaWidth = 210
        Me.dataShurui.DispNameBorderColor = System.Drawing.SystemColors.Window
        Me.dataShurui.DispNameBorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.dataShurui.DispNameSpace = 3
        Me.dataShurui.DispNameText = ""
        Me.dataShurui.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.dataShurui.GroupNo = 0
        Me.dataShurui.Indent = 0
        Me.dataShurui.InnerSpace = 3
        Me.dataShurui.InputAreaFont = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.dataShurui.InputControlReadOnly = False
        Me.dataShurui.InputControlSize = New System.Drawing.Size(23, 19)
        Me.dataShurui.InputTextImeMode = OSK.X1.Foundation.Controls.InputText.ImeModeType.NoControl
        Me.dataShurui.InputType = OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemNameAndInputName.InputModeType.数値のみ
        Me.dataShurui.ItemName = "データ種類"
        Me.dataShurui.ItemNameAreaHeight = 19
        Me.dataShurui.ItemNameAreaWidth = 100
        Me.dataShurui.ItemNameBorderColor = System.Drawing.SystemColors.Window
        Me.dataShurui.ItemNameBorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.dataShurui.ItemNameFont = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.dataShurui.ItemNameTextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Equal
        Me.dataShurui.Location = New System.Drawing.Point(9, 55)
        Me.dataShurui.Margin = New System.Windows.Forms.Padding(0)
        Me.dataShurui.MaxLength = 2
        Me.dataShurui.MaxLengthMode = OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CharCount
        Me.dataShurui.Name = "dataShurui"
        Me.dataShurui.RemarkString = Nothing
        Me.dataShurui.Size = New System.Drawing.Size(339, 19)
        Me.dataShurui.SubGroupNo = 0
        Me.dataShurui.TabIndex = 3
        Me.dataShurui.Tag = "@KeyArea@"
        Me.dataShurui.TextValue = ""
        Me.dataShurui.ZeroFill = True
        Me.dataShurui.ZeroFillAlways = False
        '
        'complete
        '
        Me.complete.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.complete.FocusBackColor = System.Drawing.Color.Empty
        Me.complete.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.complete.Image = Nothing
        Me.complete.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.complete.Location = New System.Drawing.Point(355, 80)
        Me.complete.Name = "complete"
        Me.complete.NextByEnterKey = False
        Me.complete.RemarkString = Nothing
        Me.complete.Size = New System.Drawing.Size(60, 21)
        Me.complete.TabIndex = 5
        Me.complete.TabStop = False
        Me.complete.Tag = "アイコン＝最新取得"
        Me.complete.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'shori
        '
        Me.shori.BackColor = System.Drawing.SystemColors.Info
        Me.shori.BorderStyle = OSK.X1.Foundation.Controls.GroupOption.BorderStyleType.Normal
        Me.shori.FocusBackColor = System.Drawing.Color.Empty
        Me.shori.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.shori.ItemCount = 3
        Item1.Enabled = True
        Item1.Text = "登録"
        Item1.Visible = True
        Item2.Enabled = True
        Item2.Text = "修正"
        Item2.Visible = True
        Item3.Enabled = True
        Item3.Text = "削除"
        Item3.Visible = True
        Me.shori.Items = New OSK.X1.Foundation.Controls.GroupOptionImpl.Item() {Item1, Item2, Item3}
        Me.shori.Location = New System.Drawing.Point(9, 9)
        Me.shori.Name = "shori"
        Me.shori.PrevByShiftTabKey = False
        Me.shori.PrevByUpKey = False
        Me.shori.RemarkString = Nothing
        Me.shori.Size = New System.Drawing.Size(192, 40)
        Me.shori.TabIndex = 0
        Me.shori.Tag = "@KeyArea@"
        Me.shori.Title = "処理モード"
        Me.shori.Value = 1
        '
        'subPanel
        '
        Me.subPanel.BackColor = System.Drawing.SystemColors.Control
        Me.subPanel.Controls.Add(Me.gridEntry)
        Me.subPanel.Location = New System.Drawing.Point(9, 123)
        Me.subPanel.Name = "subPanel"
        Me.subPanel.Size = New System.Drawing.Size(847, 338)
        Me.subPanel.TabIndex = 3
        Me.subPanel.Text = "Panel4"
        '
        'gridEntry
        '
        Me.gridEntry.BackColorSpace = System.Drawing.SystemColors.Control
        Me.gridEntry.ButtonBackColor = System.Drawing.Color.Empty
        Me.gridEntry.ButtonForeColor = System.Drawing.Color.Empty
        Me.gridEntry.ColumnCount = 8
        ColumnAttributeInfo1.AlignmentHeader = OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center
        ColumnAttributeInfo1.DataType = OSK.X1.Foundation.Controls.Grid.Common.GridDataType.Num
        ColumnAttributeInfo1.DispToolTipMode = Nothing
        ColumnAttributeInfo1.DspName = "属性"
        ColumnAttributeInfo1.ImageAlignment = Nothing
        ColumnAttributeInfo1.ImageDisplayMode = Nothing
        ColumnAttributeInfo1.Name = "CUSCE81004"
        ColumnAttributeInfo1.SortMode = OSK.X1.Foundation.Controls.Grid.Common.GridSortMode.Number
        ColumnAttributeInfo1.Width = 120.0!
        ColumnAttributeInfo2.AlignmentHeader = OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center
        ColumnAttributeInfo2.DataType = OSK.X1.Foundation.Controls.Grid.Common.GridDataType.Num
        ColumnAttributeInfo2.DispToolTipMode = Nothing
        ColumnAttributeInfo2.DspName = "桁数"
        ColumnAttributeInfo2.EditType = OSK.X1.Foundation.Controls.Grid.Common.GridEditType.InputNumeric
        ColumnAttributeInfo2.ImageAlignment = Nothing
        ColumnAttributeInfo2.ImageDisplayMode = Nothing
        ColumnAttributeInfo2.Name = "CUSCE81005"
        ColumnAttributeInfo2.SortMode = OSK.X1.Foundation.Controls.Grid.Common.GridSortMode.Number
        ColumnAttributeInfo2.TabIndex = 2
        ColumnAttributeInfo3.AlignmentHeader = OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center
        ColumnAttributeInfo3.DataType = OSK.X1.Foundation.Controls.Grid.Common.GridDataType.Num
        ColumnAttributeInfo3.DispToolTipMode = Nothing
        ColumnAttributeInfo3.DspName = "小数"
        ColumnAttributeInfo3.ImageAlignment = Nothing
        ColumnAttributeInfo3.ImageDisplayMode = Nothing
        ColumnAttributeInfo3.Name = "CUSCE81006"
        ColumnAttributeInfo3.SortMode = OSK.X1.Foundation.Controls.Grid.Common.GridSortMode.Number
        ColumnAttributeInfo3.TabIndex = 3
        ColumnAttributeInfo4.AlignmentHeader = OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center
        ColumnAttributeInfo4.DispToolTipMode = Nothing
        ColumnAttributeInfo4.DspName = "項目名称"
        ColumnAttributeInfo4.ImageAlignment = Nothing
        ColumnAttributeInfo4.ImageDisplayMode = Nothing
        ColumnAttributeInfo4.Name = "CUSCE81007"
        ColumnAttributeInfo4.SortMode = OSK.X1.Foundation.Controls.Grid.Common.GridSortMode.Character
        ColumnAttributeInfo4.TabIndex = 5
        ColumnAttributeInfo5.AlignmentHeader = OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center
        ColumnAttributeInfo5.DispToolTipMode = Nothing
        ColumnAttributeInfo5.DspName = "画面表示"
        ColumnAttributeInfo5.ImageAlignment = Nothing
        ColumnAttributeInfo5.ImageDisplayMode = Nothing
        ColumnAttributeInfo5.Name = "CUSCE81008"
        ColumnAttributeInfo5.TabIndex = 6
        ColumnAttributeInfo6.AlignmentHeader = OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center
        ColumnAttributeInfo6.DispToolTipMode = Nothing
        ColumnAttributeInfo6.DspName = "行位置"
        ColumnAttributeInfo6.ImageAlignment = Nothing
        ColumnAttributeInfo6.ImageDisplayMode = Nothing
        ColumnAttributeInfo6.Name = "CUSCE81009"
        ColumnAttributeInfo6.TabIndex = 7
        ColumnAttributeInfo7.AlignmentHeader = OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center
        ColumnAttributeInfo7.DispToolTipMode = Nothing
        ColumnAttributeInfo7.DspName = "表示順"
        ColumnAttributeInfo7.ImageAlignment = Nothing
        ColumnAttributeInfo7.ImageDisplayMode = Nothing
        ColumnAttributeInfo7.Name = "CUSCE81010"
        ColumnAttributeInfo7.TabIndex = 8
        ColumnAttributeInfo8.AlignmentHeader = OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center
        ColumnAttributeInfo8.DispToolTipMode = Nothing
        ColumnAttributeInfo8.DspName = "表示桁数"
        ColumnAttributeInfo8.ImageAlignment = Nothing
        ColumnAttributeInfo8.ImageDisplayMode = Nothing
        ColumnAttributeInfo8.Name = "CUSCE81011"
        ColumnAttributeInfo8.TabIndex = 9
        Me.gridEntry.Columns.AddRange(New OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo() {ColumnAttributeInfo1, ColumnAttributeInfo2, ColumnAttributeInfo3, ColumnAttributeInfo4, ColumnAttributeInfo5, ColumnAttributeInfo6, ColumnAttributeInfo7, ColumnAttributeInfo8})
        Me.gridEntry.Dock = System.Windows.Forms.DockStyle.Fill
        Me.gridEntry.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.gridEntry.GroupNo = 1
        Me.gridEntry.KeyDownButtonBackColor = System.Drawing.Color.Empty
        Me.gridEntry.Location = New System.Drawing.Point(0, 0)
        Me.gridEntry.Name = "gridEntry"
        Me.gridEntry.Padding = New System.Windows.Forms.Padding(9)
        Me.gridEntry.PrevByUpKey = False
        Me.gridEntry.RowStateAdded = "新規"
        Me.gridEntry.Size = New System.Drawing.Size(847, 338)
        Me.gridEntry.SortRange = SortRange1
        Me.gridEntry.SubGroupNo = 1
        Me.gridEntry.TabIndex = 0
        Me.gridEntry.UseLineNumber = True
        '
        'FunctionBar1
        '
        Me.FunctionBar1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.FunctionBar1.F1でヘルプ = OSK.X1.Foundation.SmartControl.FunctionBar.FunctionBar.ヘルプタイプ.実行する
        Me.FunctionBar1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.FunctionBar1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.FunctionBar1.GroupNo = 0
        FunctionControlList1.個別指定ファンクションキー = OSK.X1.Foundation.SmartControl.FunctionBar.FunctionControl.KeyType.F7
        FunctionControlList1.個別指定表示状態 = False
        Me.FunctionBar1.Items = FunctionControlList1
        Me.FunctionBar1.Location = New System.Drawing.Point(0, 497)
        Me.FunctionBar1.Name = "FunctionBar1"
        Me.FunctionBar1.ShowItemToolTips = False
        Me.FunctionBar1.Size = New System.Drawing.Size(877, 25)
        Me.FunctionBar1.Stretch = True
        Me.FunctionBar1.SubGroupNo = 0
        Me.FunctionBar1.TabIndex = 15
        Me.FunctionBar1.Text = "FunctionBar1"
        Me.FunctionBar1.個別指定ファンクションキー = OSK.X1.Foundation.SmartControl.FunctionBar.FunctionControl.KeyType.F7
        '
        'ColorDialogForm
        '
        Me.ColorDialogForm.AllowFullOpen = True
        Me.ColorDialogForm.AnyColor = False
        Me.ColorDialogForm.Color = System.Drawing.Color.Black
        Me.ColorDialogForm.CustomColors = New Integer() {16777215, 16777215, 16777215, 16777215, 16777215, 16777215, 16777215, 16777215, 16777215, 16777215, 16777215, 16777215, 16777215, 16777215, 16777215, 16777215}
        Me.ColorDialogForm.FullOpen = False
        Me.ColorDialogForm.ShowHelp = False
        Me.ColorDialogForm.SolidColorOnly = False
        Me.ColorDialogForm.Tag = Nothing
        '
        'CommandView
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.AutoSize = True
        Me.ClientSize = New System.Drawing.Size(877, 593)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "CommandView"
        Me.Text = "CommandView"
        Me.basePanel.ContentPanel.ResumeLayout(False)
        Me.basePanel.ContentPanel.PerformLayout()
        Me.basePanel.ResumeLayout(False)
        Me.basePanel.PerformLayout()
        Me.mainPanel.ResumeLayout(False)
        Me.conditionPanel.ResumeLayout(False)
        Me.subPanel.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents execute As OSK.X1.Foundation.SimpleControl.CommandButton
    Friend WithEvents mainPanel As OSK.X1.Foundation.SimpleControl.Panel
    Friend WithEvents subPanel As OSK.X1.Foundation.SimpleControl.Panel
    Friend WithEvents conditionPanel As OSK.X1.Foundation.SimpleControl.Panel
    Protected WithEvents complete As OSK.X1.Foundation.SimpleControl.CommandButton
    Friend WithEvents shori As OSK.X1.Foundation.SimpleControl.GroupOption
    Friend WithEvents dataShurui As OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemNameAndInputName
    Friend WithEvents shoriModeLabel As OSK.X1.Foundation.SimpleControl.Label
    Protected WithEvents Adjustment As OSK.X1.Foundation.SimpleControl.CommandButton
    Friend WithEvents FunctionBar1 As OSK.X1.Foundation.SmartControl.FunctionBar.FunctionBar
    Friend WithEvents ColorDialogForm As OSK.X1.Foundation.SmartControl.ColorDialogForm.ColorDialogForm
    Friend WithEvents gridEntry As SimpleControl.GridEdit
    Friend WithEvents meisaiKubun As SmartControl.InputTextWithItemName.InputTextWithItemNameAndInputName
End Class
