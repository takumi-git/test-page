﻿''' <summary>
''' グリッドのカラム定義情報(グリッドヘルパーで使用)
''' </summary>
''' <remarks></remarks>
Public Class ColumnInfoList
    Inherits ColumnInfoListBase

    Private _MyForm As OSK.X1.Foundation.UIDesign.UserInterface.DesignFormBase
    Private _gridEntry As OSK.X1.Foundation.SimpleControl.GridEdit

    Sub New(ByVal initInfo As IDictionary, ByVal settingInfo As IDictionary, ByVal myForm As OSK.X1.Foundation.UIDesign.UserInterface.DesignFormBase)
        MyBase.New(initInfo, settingInfo)
        _MyForm = myForm
    End Sub

    Sub SetGridEntry(ByVal gridEntry As OSK.X1.Foundation.SimpleControl.GridEdit)
        _gridEntry = gridEntry
        SetUpItemInfo()
    End Sub

    Private Sub SetUpItemInfo()

        Dim ComboListCount As Integer = 8
        Dim ComboCellWidth As Integer = 16
        ComboCellWidth = 19
        Dim zokuseiList() As String = {"0:未使用", "1:全角文字", "2:半角文字", "3:数値", "4:日付(年月日)", "5:日付(年月)", "6:日付(年)", "9:参照定義ｺｰﾄﾞ"}

        Dim zokuseilist_wk() As String = {"0:未使用", "1:全角文字", "2:半角文字", "3:数値", "4:日付(年月日)", "5:日付(年月)", "6:日付(年)", "7:参照定義ｺｰﾄﾞ" _
                                            , "8:画像", "9:実行ファイル", "10:ファイル", "11:フォルダ", "12:URL", "13:メールアドレス"}
        zokuseilist_wk = New String() {"0:未使用", "1:全角文字", "2:半角文字", "3:数値", "4:日付(年月日)", "5:日付(年月)", "6:日付(年)", "7:参照定義コード" _
                                     , "8:画像", "9:実行ファイル", "10:ファイル", "11:フォルダ", "12:URL", "13:メールアドレス"}
        zokuseiList = zokuseilist_wk
        ComboListCount = 14
        ComboCellWidth = 19
        'End If                                                                                                                                       


        For i As Integer = 0 To zokuseiList.Length - 1
            If zokuseiList(i).Contains("5:日付(年月)") = True Then
                zokuseiList(i) = zokuseiList(i).Replace("5:日付(年月)", "5:日付(年月度)")
            End If
            If zokuseiList(i).Contains("6:日付(年)") = True Then
                zokuseiList(i) = zokuseiList(i).Replace("6:日付(年)", "6:日付(年度)")
            End If
        Next

        AddItemInfo(New ColumnInfo("CUSCE81004", GetColSize(ComboCellWidth), "属性", 0, False, "0", False,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Left,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    OSK.X1.Foundation.Controls.Grid.Common.GridSortMode.NotSort,
                    New SettingComboBox(ComboListCount, Combo.Common.Control.StyleType.DropDown, zokuseiList)))

        Dim maxLength_Size As Integer = 3

        AddItemInfo(New ColumnInfo("CUSCE81005", GetColSize(5), "桁数", 0, False, "0", False,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Right,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    OSK.X1.Foundation.Controls.Grid.Common.GridSortMode.Number,
                    New SettingInputNumerical(True, maxLength_Size, 0)))
        '↑A-20160817-X1-桁数拡張
        AddItemInfo(New ColumnInfo("CUSCE81006", GetColSize(5), "小数", 0, False, "0", False,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Right,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    OSK.X1.Foundation.Controls.Grid.Common.GridSortMode.Number,
                    New SettingInputNumerical(True, 1, 0)))    'X1変換Tool-20160427



        AddItemInfo(New ColumnInfo("CUSCE81007", GetColSize(30), "項目名称", 0, False, "", False,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Left,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    OSK.X1.Foundation.Controls.Grid.Common.GridSortMode.Character,
                    New SettingInputText(20, OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CustomLength,
                                         OSK.X1.Foundation.Controls.InputText.ImeModeType.Hiragana, False, False, True, True, True, True, True, True, True, True, True)))
        'A-CUST20260501↓
        AddItemInfo(New ColumnInfo("CUSCE81008", GetColSize(10), "画面表示", 0, False, "0", False,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    OSK.X1.Foundation.Controls.Grid.Common.GridSortMode.Number,
                    New SettingCheckBox()))

        AddItemInfo(New ColumnInfo("CUSCE81009", GetColSize(10), "行位置", 0, False, "0", False,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Right,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    OSK.X1.Foundation.Controls.Grid.Common.GridSortMode.Number,
                    New SettingInputNumerical(True, 2, 0)))

        AddItemInfo(New ColumnInfo("CUSCE81010", GetColSize(10), "表示順", 0, False, "0", False,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Right,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    OSK.X1.Foundation.Controls.Grid.Common.GridSortMode.Number,
                    New SettingInputNumerical(True, 2, 0)))

        AddItemInfo(New ColumnInfo("CUSCE81011", GetColSize(13), "表示桁数", 0, False, "0", False,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Right,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    OSK.X1.Foundation.Controls.Grid.Common.GridSortMode.Number,
                    New SettingInputNumerical(True, 2, 0)))
        'A-CUST20260501↑

    End Sub

    Private Function GetColSize(ByVal maxlength As Integer) As Integer
        Dim utilitty As OSK.X1.Foundation.Utility.UserInterface.WidthCalculator    'X1変換Tool-20160427
        utilitty = New OSK.X1.Foundation.Utility.UserInterface.WidthCalculator    'X1変換Tool-20160427
        Return utilitty.GetSize(_MyForm.ScaleFactor, _gridEntry, maxlength, 5, 0).Width
    End Function

    Private Function GetshohinCodeCollength(ByVal maxlength As Integer) As Boolean
        If maxlength < 20 Then
            Return False
        End If
        Return True
    End Function

End Class


