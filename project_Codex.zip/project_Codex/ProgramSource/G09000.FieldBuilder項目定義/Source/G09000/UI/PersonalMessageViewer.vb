﻿Public Class PersonalMessageViewer

    Enum MessageType
        MessageBox = 0
        StatusBar
    End Enum

#Region "コンストラクタ"

    Public Sub New(ByVal settingInfo As IDictionary)
        _settingInfo = settingInfo

        _messages = New Hashtable
        SetMessage()
    End Sub

    Public Sub New(ByVal settingInfo As IDictionary, ByVal StatusBar As OSK.X1.Foundation.SmartControl.StatusBar.StatusBar)    'X1変換Tool-20160427
        _settingInfo = settingInfo
        _statusLabelControl = StatusBar.StatusLabelControl

        _messages = New Hashtable
        SetMessage()
    End Sub

#End Region

    Private _messages As IDictionary
    Private _statusLabelControl As System.Windows.Forms.ToolStripStatusLabel    'X1変換Tool-20160427
    Private _settingInfo As IDictionary

    'メッセージの登録
    Private Sub SetMessage()
        'ここに必要な分だけメッセージを登録する。
        _messages.Add(0, "更新しますか？")
        _messages.Add(1, "有効値.. 1～64")
        _messages.Add(2, "有効値.. 1～11")
        _messages.Add(3, "有効値.. 0～6")
        _messages.Add(4, "すべての項目が使用しない設定です。")
        _messages.Add(5, "指定したデータ種類は既に存在します。")
        _messages.Add(6, "指定したデータ種類は存在しません。")
        _messages.Add(7, "登録します。よろしいですか。")
        _messages.Add(8, "修正します。よろしいですか。")
        _messages.Add(9, "削除します。よろしいですか。")
        _messages.Add(10, "直前に他で変更されました。")
        _messages.Add(11, "入力に誤りがあります。再度入力して下さい。")
        _messages.Add(12, "すべての項目が使用しない設定です。削除しますか？")
        _messages.Add(13, "FieldBuilder画面設定で配置されている定義データです。" & vbCrLf & "削除すると画面設定を修正する必要があります。" & vbCrLf & "処理を続行しますか？")
        _messages.Add(14, "で使用しない設定になっています。" & vbCrLf)
        _messages.Add(15, "有効値.. 1～256")                'A-20160817-X1-桁数拡張
        _messages.Add(16, "有効値.. 1～13")                 'A-20160817-X1-桁数拡張
        _messages.Add(17, "有効値.. 年月日:8 年月度:6 年度:4")
        '_messages.Add(18, "属性変更があります。変更により項目設定が初期化されます。実行しますか？") 'TODO 属性変更時確認メッセージ出したほうがいいか。
        'A-CUST20260501↓
        _messages.Add(20, "有効値.. 1～30")
        _messages.Add(21, "有効値.. 0～64")
        'A-CUST20260501↑
    End Sub

    'メッセージの編集
    Private Function MakeMessage(ByVal messageNo As Integer, ByVal beforeText As String, ByVal afterText As String) As String

        Dim Str As String = CStr(_messages.Item(messageNo))

        '前テキスト・後テキストの挿入
        Str = beforeText & Str & afterText

        Return Str
    End Function

    Public Function Show(ByVal messageNo As Integer, ByVal type As MessageType, _
                         Optional ByVal defaultButton As OSK.X1.Foundation.UserInterface.IMessageViewer.DefaultButtonType = IMessageViewer.DefaultButtonType.OK, _
                         Optional ByVal beforeText As String = Nothing, _
                         Optional ByVal afterText As String = Nothing, _
                         Optional ByVal defaultIcon As IMessageViewer.IconType = IMessageViewer.IconType.Exclamation, _
                         Optional ByVal title As String = Nothing) As OSK.X1.Foundation.UserInterface.IMessageViewer.ShowResultType    'X1変換Tool-20160427

        Dim result As IMessageViewer.ShowResultType

        If title = Nothing Then
            title = CStr(_settingInfo.Item("プログラム情報.名称"))
        End If

        If _messages.Contains(messageNo) = False Then
            OSK.X1.Foundation.UserInterface.OSKMessageBox.Show(Me, "メッセージがありません。", title)    'X1変換Tool-20160427
            Exit Function
        End If

        Dim text As String = MakeMessage(messageNo, beforeText, afterText)

        If type = MessageType.MessageBox Then
            Dim mbIcon As System.Windows.Forms.MessageBoxIcon    'X1変換Tool-20160427
            Dim mbButtons As System.Windows.Forms.MessageBoxButtons    'X1変換Tool-20160427
            Dim mbDefaultButton As System.Windows.Forms.MessageBoxDefaultButton    'X1変換Tool-20160427

            Select Case defaultIcon
                Case IMessageViewer.IconType.Question
                    mbIcon = MessageBoxIcon.Question

                Case IMessageViewer.IconType.Information
                    mbIcon = MessageBoxIcon.Information

                Case IMessageViewer.IconType.Exclamation
                    mbIcon = MessageBoxIcon.Exclamation

                Case IMessageViewer.IconType.Critical
                    mbIcon = MessageBoxIcon.Error

            End Select

            Select Case defaultButton
                Case IMessageViewer.DefaultButtonType.OK
                    mbButtons = MessageBoxButtons.OK
                    mbDefaultButton = MessageBoxDefaultButton.Button1

                Case IMessageViewer.DefaultButtonType.Yes
                    mbButtons = MessageBoxButtons.YesNo
                    mbDefaultButton = MessageBoxDefaultButton.Button1

                Case IMessageViewer.DefaultButtonType.No
                    mbButtons = MessageBoxButtons.YesNo
                    mbDefaultButton = MessageBoxDefaultButton.Button2

            End Select


            Dim dlgResult As DialogResult
            dlgResult = OSK.X1.Foundation.UserInterface.OSKMessageBox.Show(Me, text, title, mbButtons, mbIcon, mbDefaultButton)    'X1変換Tool-20160427
            Select Case dlgResult
                Case DialogResult.OK
                    result = IMessageViewer.ShowResultType.OK

                Case DialogResult.Yes
                    result = IMessageViewer.ShowResultType.Yes

                Case Else
                    result = IMessageViewer.ShowResultType.No

            End Select
        Else
            _statusLabelControl.Text = text
        End If

        Return result

    End Function


End Class
