﻿<CLSCompliant(True)> _
Public Interface IMasterSelector
    Inherits IBase

#Region "列挙型"
    Enum マスター区分型 As Integer
        参照定義 = 0
        画面設定
        データ種類
    End Enum
#End Region

#Region "メソッド"
    'Function GetName(ByVal settingInfo As IDictionary, ByRef getDataValue() As String, ByVal targetMaster As マスター区分型, _
    '                 ByVal ParamArray コード As String()) As Boolean

    'Function GetSetteiList(ByVal settingInfo As IDictionary, ByRef getDataValue As DataTable, ByVal targetMaster As マスター区分型, _
    '                       ByVal ParamArray コード As String()) As Boolean

    Function GetDatatype(ByVal settingInfo As IDictionary, ByVal syubetsuCode As String, ByRef detDataType As DataTable, ByVal targetMaster As マスター区分型) As Boolean

    Function GetTypeInfo(ByVal settingInfo As IDictionary, ByVal syubetsuCode As String, ByRef typeName As String, ByVal targetMaster As マスター区分型) As Boolean    'A-CUST20251104 '2026/03/09
#End Region

End Interface
