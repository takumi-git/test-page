﻿Imports System.Xml
Imports System.Text
Imports System.IO
Imports System.Collections.Generic
Imports System.Text.RegularExpressions

Public Class XmlFileWriter

    'FieldBuilder属性情報：XMLに出す5項目＋ファイル名用（データ種類／明細区分）
    Public Structure ExtItemInfo
        Public タイトル As String
        Public 属性 As String
        Public 列名 As String
        Public 桁数 As String
        Public 小数 As String
        Public データ種類 As Integer
        'Public データ種類略称 As String  'D-CUST20251104 '2026/03/12
        Public データ種類名 As String  'A-CUST20251104 '2026/03/12
        Public 明細区分 As Integer ' 1:ヘッダー, 2:明細
        Public 明細区分名称 As String
        'A-CUST20260501↓
        Public 画面表示 As String
        Public 行位置 As String
        Public 表示順 As String
        Public 表示桁数 As String
        'A-CUST20260501↑
    End Structure

    '属性=7 のときに追加するサンプル定義（現状は固定値）
    Private Const SAMPLE_CODE_SEARCH_ID As String = "OSK.X1.OTS.R00100"
    Private Const SAMPLE_CODE_SEARCH_EDA As String = "0"
    Private Const SAMPLE_CODE_SEARCH_UKETORI_KEY As String = "コード"
    Private Const SAMPLE_CODE_SEARCH_HIKISU_KEY As String = "0702"

    '起動元処理のサンプル定義
    Private Const SAMPLE_STARTUP_PROCESS_COMMENT As String = "サンプル提供：処理別項目設定"


    Private Const SAMPLE_MASTER_SQL As String =
        "SELECT" & vbCrLf &
        "ISNULL(CUSME34003,N' ') CUSME34003 " & vbCrLf &
        "FROM CUS98ME34GENERICNAME WITH(NOLOCK)" & vbCrLf &
        "WHERE CUSME34001 = '0702' " & vbCrLf &
        "AND CUSME34002 = @K1 " & vbCrLf

    Private Const SAMPLE_MASTER_HANEI As String = "@K1"

    '<取得データ> / <反映先> のテキスト整形用（開閉タグのインデント：10スペース）
    Private Const SAMPLE_BLOCK_TAG_INDENT As String = "          "

    '計算式サンプル（先頭2枠が計算式、3枠目が出力）
    Private Const SAMPLE_CALC_EXPR As String = "RTRIM(@K3) + RTRIM(@K4)"
    Private Const SAMPLE_CALC_TARGET As String = "@K5"

    ''' <summary>
    ''' FieldBuilder属性情報を「データ種類×明細区分」ごとに1ファイルへ出力／更新
    ''' ・既存ファイルがあれば該当要素だけ部分更新（ユーザー手入力属性は保持）
    ''' ・XML宣言：UTF-8（BOMあり）／CRLF
    ''' ・拡張設定の「項目数」は既定：実在件数
    ''' ・属性3～6の項目は PARM1 デフォルト='0' を必ず更新（存在しなければ追加）
    ''' ・それ以外の属性の項目は PARM1 を更新しない（存在しなければ '' で追加）
    ''' ・属性の並びは「タイトル→属性→列名→桁数→小数→その他」に統一
    ''' ・属性=7 のとき、親要素サンプル属性＋サンプル子要素（コード検索/マスター取得）を新規作成時のみ追加
    ''' ・新規作成時のみ、属性=0（未使用）の先頭3枠に「計算式サンプル（2枠＋出力1枠）」を投入
    ''' </summary>
    Public Sub WriteOrUpdateGrouped(ByVal folderPath As String,
                                   ByVal items() As ExtItemInfo,
                                   Optional ByVal patternWidth As String = "740",
                                   Optional ByVal autoApplyAugment As Boolean = True) 'A-CUST20251104 '2026/03/17 実装リファクタリング

        'D-CUST20251104↓ '2026/03/17
        'Public Sub WriteOrUpdateGrouped(ByVal folderPath As String,
        '                           ByVal items() As ExtItemInfo,
        '                           Optional ByVal patternWidth As String = "740")
        'D-CUST20251104↑ '2026/03/17

        ' 入力チェック
        If String.IsNullOrEmpty(folderPath) Then Throw New ArgumentException("folderPath が空です。")
        If Not Directory.Exists(folderPath) Then Throw New DirectoryNotFoundException("指定フォルダが存在しません: " & folderPath)
        If items Is Nothing OrElse items.Length = 0 Then Throw New ArgumentException("items が空です。")

        ' XML Writer 設定（宣言は手書きで UTF-8 を大文字にする）
        Dim settings As XmlWriterSettings = New XmlWriterSettings()
        settings.Encoding = New UTF8Encoding(True) ' BOMあり
        settings.Indent = True
        settings.IndentChars = "  " ' 2スペース
        settings.NewLineChars = vbCrLf ' CRLF
        settings.OmitXmlDeclaration = True ' 宣言は自前で書く

        ' 1) 空項目を除外（5項目がすべて空ならスキップ）
        Dim valid As New List(Of ExtItemInfo)()
        Dim i As Integer
        For i = 0 To items.Length - 1
            Dim d As ExtItemInfo = items(i)
            If Not IsEmptyExtItem(d) Then valid.Add(d)
        Next
        If valid.Count = 0 Then Exit Sub

        ' 2) データ種類×明細区分でグループ化
        Dim groups As New Dictionary(Of String, List(Of ExtItemInfo))()
        For i = 0 To valid.Count - 1
            Dim d As ExtItemInfo = valid(i)
            Dim key As String = d.データ種類.ToString() & "_" & d.明細区分.ToString()
            If Not groups.ContainsKey(key) Then groups(key) = New List(Of ExtItemInfo)()
            groups(key).Add(d)
        Next

        ' 3) 各グループを1ファイルへ（既存があれば部分更新）
        For Each kv As KeyValuePair(Of String, List(Of ExtItemInfo)) In groups
            Dim list As List(Of ExtItemInfo) = kv.Value
            If list.Count = 0 Then Continue For

            Dim filename As String = BuildFileName(list(0))
            Dim path As String = System.IO.Path.Combine(folderPath, filename)

            Dim isNewFile As Boolean = Not File.Exists(path)

            ' ドキュメント準備：既存があれば読み込み、なければ骨組み作成
            Dim doc As XmlDocument = New XmlDocument()
            doc.PreserveWhitespace = False ' 整形出力（CRLF＋インデント）

            If Not isNewFile Then
                Using fs As New FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read)
                    doc.Load(fs)
                End Using
            Else
                Dim decl As XmlDeclaration = doc.CreateXmlDeclaration("1.0", "UTF-8", Nothing)
                doc.AppendChild(decl)

                Dim root As XmlElement = doc.CreateElement("汎用サブ画面")
                doc.AppendChild(root)

                'D-CUST20251104↓ '2026/03/19
                ''Dim prog As XmlElement = doc.CreateElement("プログラム情報")
                ''Dim pname As XmlElement = doc.CreateElement("プログラム名")
                ''pname.InnerText = BuildProgramName(list(0))
                ''prog.AppendChild(pname)
                ''root.AppendChild(prog)
                'D-CUST20251104↑ '2026/03/19

                Dim pat As XmlElement = doc.CreateElement("パターン情報")
                pat.SetAttribute("横幅", patternWidth)
                root.AppendChild(pat)

                Dim ext As XmlElement = doc.CreateElement("設定")
                ext.SetAttribute("項目数", "0")
                pat.AppendChild(ext)
            End If

            ' 必須ノードの補完（既存を壊さず追加のみ）
            Dim rootNode As XmlElement = TryCast(doc.SelectSingleNode("/汎用サブ画面"), XmlElement)
            If rootNode Is Nothing Then
                rootNode = doc.CreateElement("汎用サブ画面")
                doc.AppendChild(rootNode)
            End If

            Dim patNode As XmlElement = TryCast(doc.SelectSingleNode("/汎用サブ画面/パターン情報"), XmlElement)
            If patNode Is Nothing Then
                patNode = doc.CreateElement("パターン情報")
                patNode.SetAttribute("横幅", patternWidth)
                rootNode.AppendChild(patNode)
            Else
                If String.IsNullOrEmpty(patNode.GetAttribute("横幅")) Then
                    patNode.SetAttribute("横幅", patternWidth)
                End If
            End If

            Dim extNode As XmlElement = TryCast(doc.SelectSingleNode("/汎用サブ画面/パターン情報/設定"), XmlElement)
            If extNode Is Nothing Then
                extNode = doc.CreateElement("設定")
                extNode.SetAttribute("項目数", "0")
                patNode.AppendChild(extNode)
            End If

            ' グループ内の全項目をアップサート（既存は部分更新、未存在は追加）
            Dim j As Integer
            For j = 0 To list.Count - 1
                'UpsertExtItem(doc, extNode, list(j))   'D-CUST20251104 '2026/03/17
                UpsertExtItem(doc, extNode, list(j), autoApplyAugment)  'A-CUST20251104 '2026/03/17
            Next

            '新規作成時のみ：最初の項目に「起動元処理」サンプルを追加
            If isNewFile AndAlso list.Count > 0 Then
                EnsureSampleStartupProcessing(doc, extNode, list(0))
            End If

            '新規作成時のみ：属性=0 の先頭3枠へ計算式サンプル（2枠＋出力1枠）を投入
            EnsureSampleCalcFormulaSet(doc, extNode, isNewFile)

            '' 項目数の設定
            Dim countNodes As XmlNodeList = extNode.SelectNodes("項目")
            extNode.SetAttribute("項目数", countNodes.Count.ToString())

            ' 保存
            Using sw As New StreamWriter(path, False, New UTF8Encoding(True))
                sw.WriteLine("<?xml version=""1.0"" encoding=""UTF-8""?>")
                Using xw As XmlWriter = XmlWriter.Create(sw, settings)
                    Dim node As XmlNode = doc.SelectSingleNode("/汎用サブ画面")
                    If node IsNot Nothing Then
                        node.WriteTo(xw)
                    End If
                End Using
            End Using

            ' 仕上げ：PARM1 の属性をダブルクォート→シングルクォートへ、"/>" 前スペース除去
            FixParm1Quotes(path)
        Next

    End Sub

    'D-CUST20251104↓ '2026/03/17
    'Private Sub UpsertExtItem(ByVal doc As XmlDocument,
    '                         ByVal extNode As XmlElement,
    '                         ByVal d As ExtItemInfo)
    'D-CUST20251104↑ '2026/03/17
    'A-CUST20251104↓ '2026/03/17　XML作成の実装リファクタリング
    Private Sub UpsertExtItem(ByVal doc As XmlDocument,
                             ByVal extNode As XmlElement,
                             ByVal d As ExtItemInfo,
                             Optional ByVal autoApplyAugment As Boolean = False)
        'A-CUST20251104↑ '2026/03/17
        ' キーは「列名」で判定（例：K001）
        Dim target As XmlElement = TryCast(extNode.SelectSingleNode("項目[@列名='" & d.列名 & "']"), XmlElement)

        ' 属性の数値判定
        Dim attrNum As Integer = 0
        Dim ok As Boolean = Integer.TryParse(d.属性, attrNum)
        Dim isNumericOrDate As Boolean = ok AndAlso attrNum >= 3 AndAlso attrNum <= 6

        If target Is Nothing Then
            ' --- 新規追加（既知の5属性だけ付与） ---
            target = doc.CreateElement("項目")
            If Not String.IsNullOrEmpty(d.タイトル) Then target.SetAttribute("タイトル", d.タイトル)
            If Not String.IsNullOrEmpty(d.属性) Then target.SetAttribute("属性", d.属性)
            If Not String.IsNullOrEmpty(d.列名) Then target.SetAttribute("列名", d.列名)
            If Not String.IsNullOrEmpty(d.桁数) Then target.SetAttribute("桁数", d.桁数)
            If Not String.IsNullOrEmpty(d.小数) Then target.SetAttribute("小数", d.小数)


            '属性3にはカンマ編集用の属性を追加(デフォルト0）
            If ok AndAlso attrNum = 3 Then
                target.SetAttribute("カンマ編集", "0")
            End If

            '属性4～6(年月日～年度）までには、区切り文字の属性を追加
            'デフォルトは1：スラッシュにしておく
            If ok AndAlso (attrNum >= 4 AndAlso attrNum <= 6) Then
                target.SetAttribute("区切り文字", "1")
            End If

            ' 属性7の際は親要素側のサンプル属性を付与（新規作成時のみ）
            If ok AndAlso attrNum = 7 Then
                target.SetAttribute("入力チェック", "1")
                target.SetAttribute("マスター検索", "1")
                target.SetAttribute("タイプ", "0")
                target.SetAttribute("大文字変換", "0")
                target.SetAttribute("マスター取得", "1")
                target.SetAttribute("項目変数", "@K1")
            End If

            '属性8～13(画像～メールアドレス)の際はボタン使用は有効化
            If ok AndAlso (attrNum >= 8 AndAlso attrNum <= 13) Then
                target.SetAttribute("ボタン使用", "1")
            End If

            'A-CUST20260501↓
            If Not String.IsNullOrEmpty(d.画面表示) Then target.SetAttribute("画面表示", d.画面表示)
            If Not String.IsNullOrEmpty(d.行位置) Then target.SetAttribute("行位置", d.行位置)
            If Not String.IsNullOrEmpty(d.表示順) Then target.SetAttribute("表示順", d.表示順)
            If Not String.IsNullOrEmpty(d.表示桁数) Then target.SetAttribute("表示桁数", d.表示桁数)
            'A-CUST20260501↑

            ' PARM1（新規時のみ追加）
            Dim parm As XmlElement = doc.CreateElement("PARM1")
            parm.SetAttribute("デフォルト", If(isNumericOrDate, "0", ""))
            target.AppendChild(parm)


            ' サンプル子要素は新規作成時のみ追加（既存項目は触らない）
            If ok AndAlso attrNum = 7 Then
                EnsureSampleNodesForAttr7(doc, target)
            End If

            extNode.AppendChild(target)

        Else
            ' --- 既存あり：渡された5項目のみ部分更新（空文字は未変更） ---
            'D-CUST20251104↓ '2026/03/17
            'If Not String.IsNullOrEmpty(d.タイトル) Then target.SetAttribute("タイトル", d.タイトル)
            'If Not String.IsNullOrEmpty(d.属性) Then target.SetAttribute("属性", d.属性)
            'If Not String.IsNullOrEmpty(d.列名) Then target.SetAttribute("列名", d.列名)
            'If Not String.IsNullOrEmpty(d.桁数) Then target.SetAttribute("桁数", d.桁数)
            'If Not String.IsNullOrEmpty(d.小数) Then target.SetAttribute("小数", d.小数)
            'D-CUST20251104↑ '2026/03/17

            'A-CUST20251104↓ '2026/03/17　実装リファクタリング
            ' ただし属性が変更された場合は、ユーザーが設定した付帯属性／子要素をすべて削除し
            ' 当該属性のデフォルトだけを再構築する（ユーザー要求）

            ' 変更前の属性・コア値を保持
            Dim existingAttrValue As String = target.GetAttribute("属性")
            Dim prevTitle As String = target.GetAttribute("タイトル")
            Dim prevColName As String = target.GetAttribute("列名")
            Dim prevKetasu As String = target.GetAttribute("桁数")
            Dim prevShousuu As String = target.GetAttribute("小数")

            'A-CUST20260501↓
            Dim prevDispFlg As String = target.GetAttribute("画面表示")
            Dim prevDispRow As String = target.GetAttribute("行位置")
            Dim prevDispCol As String = target.GetAttribute("表示順")
            Dim prevKetaGrid As String = target.GetAttribute("表示桁数")
            'A-CUST20260501↑

            ' コア5項目の更新（空文字は未変更）
            If Not String.IsNullOrEmpty(d.タイトル) Then
                target.SetAttribute("タイトル", d.タイトル)
            ElseIf Not String.IsNullOrEmpty(prevTitle) Then
                target.SetAttribute("タイトル", prevTitle)
            End If

            If Not String.IsNullOrEmpty(d.属性) Then
                target.SetAttribute("属性", d.属性)
            ElseIf Not String.IsNullOrEmpty(existingAttrValue) Then
                target.SetAttribute("属性", existingAttrValue)
            End If

            If Not String.IsNullOrEmpty(d.列名) Then
                target.SetAttribute("列名", d.列名)
            ElseIf Not String.IsNullOrEmpty(prevColName) Then
                target.SetAttribute("列名", prevColName)
            End If

            If Not String.IsNullOrEmpty(d.桁数) Then
                target.SetAttribute("桁数", d.桁数)
            ElseIf Not String.IsNullOrEmpty(prevKetasu) Then
                target.SetAttribute("桁数", prevKetasu)
            End If

            If Not String.IsNullOrEmpty(d.小数) Then
                target.SetAttribute("小数", d.小数)
            ElseIf Not String.IsNullOrEmpty(prevShousuu) Then
                target.SetAttribute("小数", prevShousuu)
            End If

            ' 属性が変更された場合は付帯属性／子要素をすべてリセットしてから新属性のデフォルトだけを付与
            If Not String.IsNullOrEmpty(d.属性) AndAlso d.属性 <> existingAttrValue Then
                ' 削除対象属性名（コア5項目は保持）
                Dim keepAttrs As New HashSet(Of String)(StringComparer.OrdinalIgnoreCase)
                keepAttrs.Add("タイトル") : keepAttrs.Add("属性") : keepAttrs.Add("列名") : keepAttrs.Add("桁数") : keepAttrs.Add("小数")

                ' 属性の削除（列挙してから削除する）
                Dim toRemove As New List(Of String)()
                Dim aIdx As Integer
                For aIdx = 0 To target.Attributes.Count - 1
                    Dim at As XmlAttribute = CType(target.Attributes.Item(aIdx), XmlAttribute)
                    If Not keepAttrs.Contains(at.Name) Then
                        toRemove.Add(at.Name)
                    End If
                Next
                For Each aname As String In toRemove
                    target.RemoveAttribute(aname)
                Next

                ' 子ノードはすべて削除（PARM1 等も含む）。後で必要なものを追加する
                While target.HasChildNodes
                    target.RemoveChild(target.FirstChild)
                End While

                ' PARM1 を新規作成（属性種別に応じたデフォルト）
                Dim parmNew As XmlElement = doc.CreateElement("PARM1")
                parmNew.SetAttribute("デフォルト", If(isNumericOrDate, "0", ""))
                target.AppendChild(parmNew)

                ' 新属性に応じたデフォルト付与（属性=3/4-6/7/8-13）
                If ok AndAlso attrNum = 3 Then
                    target.SetAttribute("カンマ編集", "0")
                End If

                If ok AndAlso (attrNum >= 4 AndAlso attrNum <= 6) Then
                    target.SetAttribute("区切り文字", "1")
                    ' target.SetAttribute("小数", "0") '属性変更で数値→日付になるケースを想定して小数はクリア
                End If

                If ok AndAlso attrNum = 7 Then
                    target.SetAttribute("入力チェック", "1")
                    target.SetAttribute("マスター検索", "1")
                    target.SetAttribute("タイプ", "0")
                    target.SetAttribute("大文字変換", "0")
                    target.SetAttribute("マスター取得", "1")
                    target.SetAttribute("項目変数", "@K1")
                    ' サンプル子要素の追加（EnsureSampleNodesForAttr7 が既存チェックを行うが、
                    ' ここでは子ノードを消しているため必ず追加される）
                    EnsureSampleNodesForAttr7(doc, target)
                End If

                If ok AndAlso (attrNum >= 8 AndAlso attrNum <= 13) Then
                    target.SetAttribute("ボタン使用", "1")
                End If

                ' 属性変更時は、ユーザーが設定していたコメントも削除したいと判断したため、
                ' コメントノードが残っている場合は削除する（節度を保つため例外は握り潰す）
                Try
                    Dim childNode As XmlNode = target.FirstChild
                    While childNode IsNot Nothing
                        Dim nextNode As XmlNode = childNode.NextSibling
                        If childNode.NodeType = XmlNodeType.Comment Then
                            target.RemoveChild(childNode)
                        End If
                        childNode = nextNode
                    End While
                Catch ex As Exception
                End Try
            End If
            'A-CUST20251104↑ '2026/03/17

            ' PARM1：
            Dim parmExisting As XmlElement = TryCast(target.SelectSingleNode("PARM1"), XmlElement)
            If isNumericOrDate Then
                If parmExisting Is Nothing Then
                    Dim parmNew As XmlElement = doc.CreateElement("PARM1")
                    parmNew.SetAttribute("デフォルト", "0")
                    target.AppendChild(parmNew)
                Else
                    parmExisting.SetAttribute("デフォルト", "0")
                End If
            Else
                If parmExisting Is Nothing Then
                    Dim parmNew As XmlElement = doc.CreateElement("PARM1")
                    parmNew.SetAttribute("デフォルト", "")
                    target.AppendChild(parmNew)
                End If
            End If

            'A-CUST20251104↓ '2026/03/17　実装リファクタリング
            ' --- オプション: 既存項目にも補助属性を自動付与する ---
            If autoApplyAugment Then
                If ok AndAlso attrNum = 3 Then
                    If Not target.HasAttribute("カンマ編集") Then
                        target.SetAttribute("カンマ編集", "0")
                    End If
                End If

                If ok AndAlso (attrNum >= 4 AndAlso attrNum <= 6) Then
                    If Not target.HasAttribute("区切り文字") Then
                        target.SetAttribute("区切り文字", "1")
                    End If
                End If

                If ok AndAlso attrNum = 7 Then
                    If Not target.HasAttribute("入力チェック") Then target.SetAttribute("入力チェック", "1")
                    If Not target.HasAttribute("マスター検索") Then target.SetAttribute("マスター検索", "1")
                    If Not target.HasAttribute("タイプ") Then target.SetAttribute("タイプ", "0")
                    If Not target.HasAttribute("大文字変換") Then target.SetAttribute("大文字変換", "0")
                    If Not target.HasAttribute("マスター取得") Then target.SetAttribute("マスター取得", "1")
                    If Not target.HasAttribute("項目変数") Then target.SetAttribute("項目変数", "@K1")
                    ' サンプル子要素の追加（存在チェックは内部で行う）
                    EnsureSampleNodesForAttr7(doc, target)
                End If

                If ok AndAlso (attrNum >= 8 AndAlso attrNum <= 13) Then
                    If Not target.HasAttribute("ボタン使用") Then
                        target.SetAttribute("ボタン使用", "1")
                    End If
                End If
            End If
            'A-CUST20251104↑ '2026/03/17

            'A-CUST20260501↓

            If String.IsNullOrEmpty(d.画面表示) Then
                target.RemoveAttribute("画面表示")
                target.RemoveAttribute("行位置")
                target.RemoveAttribute("表示順")
                target.RemoveAttribute("表示桁数")
            Else
                target.SetAttribute("画面表示", d.画面表示)

                If Not String.IsNullOrEmpty(d.行位置) Then
                    target.SetAttribute("行位置", d.行位置)
                Else
                    target.RemoveAttribute("行位置")
                End If

                If Not String.IsNullOrEmpty(d.表示順) Then
                    target.SetAttribute("表示順", d.表示順)
                Else
                    target.RemoveAttribute("表示順")
                End If

                If Not String.IsNullOrEmpty(d.表示桁数) Then
                    target.SetAttribute("表示桁数", d.表示桁数)
                Else
                    target.RemoveAttribute("表示桁数")
                End If

            End If

            'A-CUST20260501↑

        End If

        ' 属性並び順を統一
        NormalizeExtItemAttributeOrder(doc, extNode, target)

    End Sub

    ' ---- 属性=7 用：コード検索／コード保守／マスター取得を追加（サンプル用途） ----
    ' ※新規作成時にのみ呼ばれる前提
    Private Sub EnsureSampleNodesForAttr7(ByVal doc As XmlDocument, ByVal target As XmlElement)

        Dim codeSearch As XmlElement = TryCast(target.SelectSingleNode("コード検索"), XmlElement)
        If codeSearch Is Nothing Then
            codeSearch = doc.CreateElement("コード検索")
            codeSearch.SetAttribute("ID", SAMPLE_CODE_SEARCH_ID)
            codeSearch.SetAttribute("枝番", SAMPLE_CODE_SEARCH_EDA)

            Dim uketori As XmlElement = doc.CreateElement("受取")
            uketori.SetAttribute("KeyName", SAMPLE_CODE_SEARCH_UKETORI_KEY)
            codeSearch.AppendChild(uketori)

            Dim hikisu As XmlElement = doc.CreateElement("引数")
            hikisu.SetAttribute("マスター種別", SAMPLE_CODE_SEARCH_HIKISU_KEY)
            codeSearch.AppendChild(hikisu)

            InsertAfterParm1OrAppend(target, codeSearch)
        End If

        'Dim codeMaint As XmlElement = TryCast(target.SelectSingleNode("コード保守"), XmlElement)
        'If codeMaint Is Nothing Then
        '    codeMaint = doc.CreateElement("コード保守")
        '    codeMaint.SetAttribute("ID", SAMPLE_CODE_MAINT_ID)
        '    codeMaint.SetAttribute("枝番", SAMPLE_CODE_MAINT_EDA)

        '    Dim uketori2 As XmlElement = doc.CreateElement("受取")
        '    uketori2.SetAttribute("KeyName", SAMPLE_CODE_MAINT_UKETORI_KEY)
        '    codeMaint.AppendChild(uketori2)

        '    Dim hikisu As XmlElement = doc.CreateElement("引数")
        '    hikisu.SetAttribute("KeyName", SAMPLE_CODE_MAINT_HIKISU_KEY)
        '    codeMaint.AppendChild(hikisu)

        '    InsertAfterParm1OrAppend(target, codeMaint)
        'End If

        Dim masterGet As XmlElement = TryCast(target.SelectSingleNode("マスター取得"), XmlElement)
        If masterGet Is Nothing Then
            masterGet = doc.CreateElement("マスター取得")

            Dim getData As XmlElement = doc.CreateElement("取得データ")
            getData.InnerText = BuildIndentedBlockText(SAMPLE_MASTER_SQL, SAMPLE_BLOCK_TAG_INDENT)
            masterGet.AppendChild(getData)

            Dim hanei As XmlElement = doc.CreateElement("反映先")
            hanei.InnerText = BuildIndentedBlockText(SAMPLE_MASTER_HANEI, SAMPLE_BLOCK_TAG_INDENT)
            masterGet.AppendChild(hanei)

            InsertAfterParm1OrAppend(target, masterGet)
        End If

        'サンプルXMLであるためのコメントの追加
        Try
            Dim node As XmlNode = target.SelectSingleNode("comment()[normalize-space(.)='サンプル提供：参照定義コード']")
            Dim sampleComment As XmlComment = TryCast(node, XmlComment)
            If sampleComment Is Nothing Then
                sampleComment = doc.CreateComment("サンプル提供：参照定義コード")
                InsertAfterParm1OrAppendComment(target, sampleComment)
            End If
        Catch ex As Exception
        End Try

    End Sub

    ' ----新規作成時のみ：属性=0 の先頭3枠を計算式サンプルにする ----
    Private Sub EnsureSampleCalcFormulaSet(ByVal doc As XmlDocument, ByVal extNode As XmlElement, ByVal isNewFile As Boolean)

        If Not isNewFile Then Exit Sub
        If extNode Is Nothing Then Exit Sub

        ' 属性=0 の候補を列名番号順に並べる
        Dim nodes As XmlNodeList = extNode.SelectNodes("項目[@属性='0']")
        If nodes Is Nothing OrElse nodes.Count < 3 Then Exit Sub

        Dim candidates As New List(Of XmlElement)()
        Dim n As XmlNode
        For Each n In nodes
            Dim el As XmlElement = TryCast(n, XmlElement)
            If el IsNot Nothing Then candidates.Add(el)
        Next

        candidates.Sort(AddressOf CompareByColNameNumber)


        ' 先頭候補の直前に固定文言コメント
        EnsureSiblingCommentBeforeElement(extNode, candidates(0), "サンプル提供：計算式サンプル")


        ' 先頭3つを対象（最初の2つ：計算式、3つ目：出力）
        ApplyCalcSampleToSlot(doc, extNode, candidates(0), 1)
        ApplyCalcSampleToSlot(doc, extNode, candidates(1), 2)
        ApplyCalcSampleToSlot(doc, extNode, candidates(2), 3)

    End Sub

    Private Function CompareByColNameNumber(ByVal a As XmlElement, ByVal b As XmlElement) As Integer
        Dim na As Integer = ParseColNumber(a.GetAttribute("列名"))
        Dim nb As Integer = ParseColNumber(b.GetAttribute("列名"))
        Return na.CompareTo(nb)
    End Function

    Private Function ParseColNumber(ByVal col As String) As Integer
        If String.IsNullOrEmpty(col) Then Return Integer.MaxValue
        If col.Length < 2 Then Return Integer.MaxValue

        Dim digits As String = col.Trim()
        If digits.StartsWith("K", StringComparison.OrdinalIgnoreCase) Then
            digits = digits.Substring(1)
        End If

        Dim n As Integer = 0
        If Integer.TryParse(digits, n) Then
            Return n
        End If

        Return Integer.MaxValue
    End Function

    ' 計算式項目の設定 1、2=計算式枠、3=出力枠
    Private Sub ApplyCalcSampleToSlot(ByVal doc As XmlDocument, ByVal parent As XmlElement, ByVal target As XmlElement, ByVal slotNo As Integer)

        If doc Is Nothing OrElse parent Is Nothing OrElse target Is Nothing Then Exit Sub

        ' 既存の列名は維持。未使用枠（属性=0）をサンプルとして実装。
        target.SetAttribute("属性", "1")

        Dim colNo As Integer = ParseColNumber(target.GetAttribute("列名"))
        If colNo <> Integer.MaxValue Then
            target.SetAttribute("タイトル", "計算項目" & colNo.ToString("00"))
        End If

        target.SetAttribute("桁数", "10")
        target.SetAttribute("入力チェック", "0")
        target.SetAttribute("計算式", "1")

        Select Case slotNo
            Case 1
                target.SetAttribute("項目変数", "@K3")
            Case 2
                target.SetAttribute("項目変数", "@K4")
            Case Else
                target.SetAttribute("入力可否", "0")
                target.SetAttribute("項目変数", "@K5")
        End Select

        ' PARM1 が無ければ追加（既にあるならそのまま）
        Dim parmExisting As XmlElement = TryCast(target.SelectSingleNode("PARM1"), XmlElement)
        If parmExisting Is Nothing Then
            Dim parmNew As XmlElement = doc.CreateElement("PARM1")
            parmNew.SetAttribute("デフォルト", "")
            target.AppendChild(parmNew)
        End If

        ' 計算式子要素：1、2 のみ付与。 3（出力）は付与しない。
        Dim calcExisting As XmlElement = TryCast(target.SelectSingleNode("計算式"), XmlElement)
        If calcExisting IsNot Nothing Then
            target.RemoveChild(calcExisting)
        End If

        If slotNo = 1 OrElse slotNo = 2 Then

            Dim calc As XmlElement = doc.CreateElement("計算式")

            Dim getData As XmlElement = doc.CreateElement("取得データ")
            getData.InnerText = BuildIndentedBlockText(SAMPLE_CALC_EXPR, SAMPLE_BLOCK_TAG_INDENT)
            calc.AppendChild(getData)

            Dim hanei As XmlElement = doc.CreateElement("反映先")
            hanei.InnerText = BuildIndentedBlockText(SAMPLE_CALC_TARGET, SAMPLE_BLOCK_TAG_INDENT)
            calc.AppendChild(hanei)

            ' PARM1 の直後に配置
            InsertAfterParm1OrAppend(target, calc)
        End If

        ' 属性並び順を統一
        NormalizeExtItemAttributeOrder(doc, parent, target)

    End Sub

    '<取得データ> 等のテキストを「改行＋インデント」で整形する
    Private Function BuildIndentedBlockText(ByVal src As String, ByVal tagIndent As String) As String

        Dim normalized As String = src
        normalized = normalized.Replace(vbCrLf, vbLf)
        normalized = normalized.Replace(vbCr, vbLf)

        Dim lines() As String = normalized.Split(New String() {vbLf}, StringSplitOptions.None)

        ' 中身は開始タグより 1スペース深くする（見た目調整）
        Dim innerIndent As String = tagIndent & " "

        Dim sb As New StringBuilder()
        sb.Append(vbCrLf)

        Dim i As Integer
        For i = 0 To lines.Length - 1
            If lines(i) IsNot Nothing AndAlso lines(i).Length > 0 Then
                sb.Append(innerIndent)
                sb.Append(lines(i))
            End If
            sb.Append(vbCrLf)
        Next

        ' 終了タグの前に、開始タグと同じインデントを入れて揃える
        sb.Append(tagIndent)

        Return sb.ToString()

    End Function

    ' PARM1 の直後に挿入できれば挿入、なければ末尾に追加
    Private Sub InsertAfterParm1OrAppend(ByVal target As XmlElement, ByVal nodeToInsert As XmlElement)
        Dim parm As XmlNode = target.SelectSingleNode("PARM1")
        If parm Is Nothing Then
            target.AppendChild(nodeToInsert)
        Else
            Dim inserted As XmlNode = target.InsertAfter(nodeToInsert, parm)
        End If
    End Sub

    ' PARM1 の直後に挿入できれば挿入、なければ末尾に追加（コメント版）
    Private Sub InsertAfterParm1OrAppendComment(ByVal target As XmlElement, ByVal nodeToInsert As XmlComment)
        Dim parm As XmlNode = target.SelectSingleNode("PARM1")
        If parm Is Nothing Then
            target.AppendChild(nodeToInsert)
        Else
            Dim inserted As XmlNode = target.InsertAfter(nodeToInsert, parm)
        End If
    End Sub

    ' 対象項目の直前にコメントを1回だけ追加
    Private Sub EnsureSiblingCommentBeforeElement(ByVal parent As XmlElement, ByVal target As XmlElement, ByVal commentText As String)
        If parent Is Nothing OrElse target Is Nothing Then Exit Sub
        ' 直前に既に同等のコメントがあるかチェック
        Dim prev As XmlNode = target.PreviousSibling
        Do While prev IsNot Nothing AndAlso prev.NodeType = XmlNodeType.Whitespace
            prev = prev.PreviousSibling
        Loop
        Dim exists As Boolean = False
        If prev IsNot Nothing Then
            Dim c As XmlComment = TryCast(prev, XmlComment)
            If c IsNot Nothing Then
                Dim data As String = If(c.Data, String.Empty)
                If data.Contains(commentText) Then exists = True
            End If
        End If
        If Not exists Then
            Dim c As XmlComment = parent.OwnerDocument.CreateComment(commentText)
            parent.InsertBefore(c, target)
        End If
    End Sub
    ' ---- 属性並び順の統一：新要素を作って置換する（既存の子ノードは保持） ----
    Private Sub NormalizeExtItemAttributeOrder(ByVal doc As XmlDocument,
                                              ByVal parent As XmlElement,
                                              ByVal target As XmlElement)

        Dim desired() As String = {"タイトル", "属性", "列名", "桁数", "小数"}

        Dim existing As New List(Of XmlAttribute)()
        Dim idx As Integer
        For idx = 0 To target.Attributes.Count - 1
            existing.Add(CType(target.Attributes.Item(idx), XmlAttribute))
        Next

        Dim newEl As XmlElement = doc.CreateElement("項目")
        Dim added As New HashSet(Of String)()

        Dim name As String
        For Each name In desired
            If target.HasAttribute(name) Then
                newEl.SetAttribute(name, target.GetAttribute(name))
                added.Add(name)
            End If
        Next

        Dim attr As XmlAttribute
        For Each attr In existing
            If Not added.Contains(attr.Name) Then
                newEl.SetAttribute(attr.Name, attr.Value)
            End If
        Next

        Dim child As XmlNode
        For Each child In target.ChildNodes
            newEl.AppendChild(child.CloneNode(True))
        Next

        parent.ReplaceChild(newEl, target)

    End Sub

    Private Function IsEmptyExtItem(ByRef d As ExtItemInfo) As Boolean
        Return String.IsNullOrEmpty(d.タイトル) AndAlso
               String.IsNullOrEmpty(d.属性) AndAlso
               String.IsNullOrEmpty(d.列名) AndAlso
               String.IsNullOrEmpty(d.桁数) AndAlso
               String.IsNullOrEmpty(d.小数)
    End Function

    Private Function BuildFileName(ByRef d As ExtItemInfo) As String
        Dim sb As New StringBuilder("EO汎用_FieldBuilder_")
        'Select Case d.データ種類
        '    Case 1 : sb.Append("売上")
        '    Case 2 : sb.Append("入金")
        '    Case 3 : sb.Append("仕入")
        '    Case 4 : sb.Append("支払")
        '    Case 5 : sb.Append("入出庫")
        '    Case Else : sb.Append("未定義")
        'End Select
        'sb.Append(d.データ種類略称)  'D-CUST20251104 '2026/03/12
        sb.Append(d.データ種類名)  'A-CUST20251104 '2026/03/12
        sb.Append(d.明細区分名称)
        'Select Case d.明細区分
        '    Case 1 : sb.Append("ヘッダー")
        '    Case 2 : sb.Append("明細")
        '    Case Else : sb.Append("未定義区分")
        'End Select
        sb.Append(".xml")
        Return sb.ToString()
    End Function

    Private Function BuildProgramName(ByRef d As ExtItemInfo) As String
        Dim sb As New StringBuilder()
        'Select Case d.データ種類
        '    Case 1 : sb.Append("売上")
        '    Case 2 : sb.Append("入金")
        '    Case 3 : sb.Append("仕入")
        '    Case 4 : sb.Append("支払")
        '    Case 5 : sb.Append("入出庫")
        '    Case Else : sb.Append("未定義")
        'End Select
        'sb.Append(d.データ種類略称)  'D-CUST20251104 '2026/03/12
        sb.Append(d.データ種類名)  'A-CUST20251104 '2026/03/12
        sb.Append(d.明細区分名称)
        'Select Case d.明細区分
        '    Case 1 : sb.Append("ヘッダー")
        '    Case 2 : sb.Append("明細")
        '    Case Else : sb.Append("未定義区分")
        'End Select
        sb.Append("FieldBuilder")
        Return sb.ToString()
    End Function

    Private Sub EnsureSampleStartupProcessing(ByVal doc As XmlDocument,
                                             ByVal extNode As XmlElement,
                                             ByVal firstItem As ExtItemInfo)
        ' firstItem の列名でターゲット項目を検索
        Dim target As XmlElement = TryCast(extNode.SelectSingleNode("項目[@列名='" & firstItem.列名 & "']"), XmlElement)
        If target Is Nothing Then
            Return
        End If

        ' <起動元処理> が既に存在しないかチェック
        Dim startupProcessing As XmlElement = TryCast(target.SelectSingleNode("起動元処理"), XmlElement)
        If startupProcessing IsNot Nothing Then
            Return  ' 既に存在するため追加しない
        End If

        ' <起動元処理> 要素を作成
        startupProcessing = doc.CreateElement("起動元処理")

        ' 3つの <処理> 子要素を追加
        ' 1. 見積処理   入力可否="0"
        Dim shori1 As XmlElement = doc.CreateElement("処理")
        shori1.SetAttribute("名称", "見積処理")
        shori1.SetAttribute("入力可否", "0")
        startupProcessing.AppendChild(shori1)

        ' 2. 受注処理   入力チェック="1"
        Dim shori2 As XmlElement = doc.CreateElement("処理")
        shori2.SetAttribute("名称", "受注処理")
        shori2.SetAttribute("入力チェック", "1")
        startupProcessing.AppendChild(shori2)

        ' 3. 売上処理   入力チェック="2"
        Dim shori3 As XmlElement = doc.CreateElement("処理")
        shori3.SetAttribute("名称", "売上処理")
        shori3.SetAttribute("入力チェック", "2")
        startupProcessing.AppendChild(shori3)

        ' PARM1 の後に挿入するか、またはターゲットの最初に追加
        InsertAfterParm1OrAppend(target, startupProcessing)

        ' コメント付きでサンプルとして識別
        Try
            Dim node As XmlNode = target.SelectSingleNode("comment()[normalize-space(.)='" & SAMPLE_STARTUP_PROCESS_COMMENT & "']")
            Dim sampleComment As XmlComment = TryCast(node, XmlComment)
            If sampleComment Is Nothing Then
                sampleComment = doc.CreateComment(SAMPLE_STARTUP_PROCESS_COMMENT)
                InsertAfterParm1OrAppendComment(target, sampleComment)
            End If
        Catch ex As Exception
            ' コメント挿入エラーは無視
        End Try
    End Sub

    Private Sub FixParm1Quotes(ByVal path As String)
        Dim xml As String = File.ReadAllText(path, Encoding.UTF8)
        xml = Regex.Replace(xml, "(<PARM1\s+デフォルト=)""([^""]*)""", "$1'$2'")
        xml = Regex.Replace(xml, "<PARM1([^>]*)\s+/>", "<PARM1$1/>")
        File.WriteAllText(path, xml, New UTF8Encoding(True))
    End Sub

End Class
