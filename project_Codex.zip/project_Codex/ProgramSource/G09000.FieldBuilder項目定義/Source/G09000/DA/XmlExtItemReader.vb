﻿
Option Strict On
Option Infer Off

Imports System
Imports System.Configuration
Imports System.Data
Imports System.Globalization
Imports System.IO
Imports System.Xml

'==============================================
' XML優先で「属性情報表示用(DataTable)」を作るヘルパ
'  - XMLが無い/読めない場合は False を返す（呼び出し側でDBフォールバック）
'  - ファイル名規則は XmlFileWriter.BuildFileName と同一
'==============================================
Public NotInheritable Class XmlExtItemReader

    Private Sub New()
    End Sub

    Public Shared Function TryLoadZokuseiTable(ByVal dataKind As String,
                                               ByVal meisaiKubun As String,
                                               ByRef table As DataTable,
                                               ByRef err As Exception) As Boolean
        table = Nothing
        err = Nothing

        Try
            Dim folderPath As String = GetSettingFolderPath()
            If String.IsNullOrEmpty(folderPath) Then
                Return False
            End If

            Dim fileName As String = BuildFileName(dataKind, meisaiKubun)
            Dim fullPath As String = Path.Combine(folderPath, fileName)

            If File.Exists(fullPath) = False Then
                Return False
            End If

            Dim doc As New XmlDocument()
            Using fs As New FileStream(fullPath, FileMode.Open, FileAccess.Read, FileShare.Read)
                doc.Load(fs)
            End Using

            Dim nodes As XmlNodeList = doc.SelectNodes("/汎用サブ画面/パターン情報/設定/項目")
            If nodes Is Nothing OrElse nodes.Count = 0 Then
                ' XMLは存在するが項目が0件 → DBへフォールバック
                Return False
            End If

            Dim dt As DataTable = CreateZokuseiSchema()

            Dim i As Integer
            Dim maxRow As Integer = Math.Min(nodes.Count, 30)
            For i = 0 To maxRow - 1
                Dim el As XmlElement = TryCast(nodes(i), XmlElement)
                If el Is Nothing Then
                    Continue For
                End If

                Dim title As String = SafeGetAttr(el, "タイトル")
                Dim attrText As String = SafeGetAttr(el, "属性")
                Dim precText As String = SafeGetAttr(el, "桁数")
                Dim scaleText As String = SafeGetAttr(el, "小数")
                Dim dispFlg As String = SafeGetAttr(el, "画面表示")
                Dim dispRow As String = SafeGetAttr(el, "行位置")
                Dim dispCol As String = SafeGetAttr(el, "表示順")
                Dim gridPrec As String = SafeGetAttr(el, "表示桁数")

                Dim row As DataRow = dt.NewRow()

                ' CUSCE81003: 1始まりの行番号
                row("CUSCE81003") = CDec(i + 1)

                ' CUSCE81004: 属性
                Dim attrVal As Decimal = 0D
                If Decimal.TryParse(attrText, NumberStyles.Any, CultureInfo.InvariantCulture, attrVal) Then
                    row("CUSCE81004") = attrVal
                Else
                    row("CUSCE81004") = 0D
                End If

                ' CUSCE81005: 桁数
                Dim precVal As Decimal = 0D
                If Decimal.TryParse(precText, NumberStyles.Any, CultureInfo.InvariantCulture, precVal) Then
                    row("CUSCE81005") = precVal
                Else
                    ' XMLで未指定/不正の場合も 0 を返す（SetRowDataUpd の型変換エラー回避）
                    row("CUSCE81005") = 0D
                End If

                ' CUSCE81005: 桁数
                precVal = 0D
                If Decimal.TryParse(precText, NumberStyles.Any, CultureInfo.InvariantCulture, precVal) Then
                    row("CUSCE81005") = precVal
                Else
                    ' XMLで未指定/不正の場合も 0 を返す（SetRowDataUpd の型変換エラー回避）
                    row("CUSCE81005") = DBNull.Value
                End If

                ' CUSCE81006: 小数
                Dim scaleVal As Decimal = 0D
                If Decimal.TryParse(scaleText, NumberStyles.Any, CultureInfo.InvariantCulture, scaleVal) Then
                    row("CUSCE81006") = scaleVal
                Else
                    row("CUSCE81006") = DBNull.Value
                End If

                ' CUSCE81007: タイトル
                row("CUSCE81007") = title


                'A-CUST20260501↓
                ' CUSCE81008: 画面表示
                Dim dispFlgVal As Decimal = 0D
                If Decimal.TryParse(dispFlg, NumberStyles.Any, CultureInfo.InvariantCulture, dispFlgVal) Then
                    '1以外はNULLを返す
                    If dispFlgVal = 1 Then
                        row("CUSCE81008") = dispFlgVal
                    Else
                        row("CUSCE81008") = DBNull.Value
                    End If
                Else
                    row("CUSCE81008") = DBNull.Value
                End If

                ' CUSCE81009: 行位置
                Dim dispRowVal As Decimal = 0D
                If Decimal.TryParse(dispRow, NumberStyles.Any, CultureInfo.InvariantCulture, dispRowVal) Then
                    row("CUSCE81009") = dispRowVal
                Else
                    row("CUSCE81009") = DBNull.Value
                End If

                ' CUSCE81010: 表示順
                Dim dispColVal As Decimal = 0D
                If Decimal.TryParse(dispCol, NumberStyles.Any, CultureInfo.InvariantCulture, dispColVal) Then
                    row("CUSCE81010") = dispColVal
                Else
                    row("CUSCE81010") = DBNull.Value
                End If

                ' CUSCE81011: 表示桁数 
                Dim gridPrecVal As Decimal = 0D
                If Decimal.TryParse(gridPrec, NumberStyles.Any, CultureInfo.InvariantCulture, gridPrecVal) Then
                    row("CUSCE81011") = gridPrecVal
                Else
                    row("CUSCE81011") = DBNull.Value
                End If

                'A-CUST20260501↑

                dt.Rows.Add(row)
            Next

            table = dt
            Return True

        Catch ex As Exception
            err = ex
            table = Nothing
            Return False
        End Try

    End Function

    '----------------------------------------------
    ' 設定値（更新時と同じ）
    '----------------------------------------------
    Private Shared Function GetSettingFolderPath() As String
        Dim folders As String = CStr(ConfigurationManager.AppSettings("アプリケーション設定データパス"))
        Return folders
    End Function

    '----------------------------------------------
    ' ファイル名生成（XmlFileWriter.BuildFileName と同一）
    '----------------------------------------------
    Public Shared Function BuildFileName(ByVal dataKind As String, ByVal meisaiKubun As String) As String
        Dim sb As New System.Text.StringBuilder("EO汎用_FieldBuilder_")

        'Select Case dataKind
        '    Case 1 : sb.Append("売上")
        '    Case 2 : sb.Append("入金")
        '    Case 3 : sb.Append("仕入")
        '    Case 4 : sb.Append("支払")
        '    Case 5 : sb.Append("入出庫")
        '    Case Else : sb.Append("未定義")
        'End Select
        sb.Append(dataKind)
        sb.Append(meisaiKubun)
        'Select Case meisaiKubun
        '    Case 1 : sb.Append("ヘッダー")
        '    Case 2 : sb.Append("明細")
        '    Case Else : sb.Append("未定義区分")
        'End Select

        sb.Append(".xml")
        Return sb.ToString()
    End Function

    '----------------------------------------------
    ' DataTableスキーマ（CommandView / DataReader の既存列に合わせる）
    '  - CUSCE81003: 行番号(1..30)
    '  - CUSCE81004: 属性
    '  - CUSCE81005: 桁数
    '  - CUSCE81006: 小数
    '  - CUSCE81007: タイトル
    'A-CUST20260501↓
    '  - CUSCE81008: 画面表示
    '  - CUSCE81009: 行位置
    '  - CUSCE81010: 表示順
    '  - CUSCE81011: 表示桁数
    'A-CUST20260501↑
    '----------------------------------------------
    Private Shared Function CreateZokuseiSchema() As DataTable
        Dim dt As New DataTable()

        Dim c03 As New DataColumn("CUSCE81003", GetType(Decimal))
        Dim c04 As New DataColumn("CUSCE81004", GetType(Decimal))
        Dim c05 As New DataColumn("CUSCE81005", GetType(Decimal))
        Dim c06 As New DataColumn("CUSCE81006", GetType(Decimal))
        Dim c07 As New DataColumn("CUSCE81007", GetType(String))
        'A-CUST20260501↓
        Dim c08 As New DataColumn("CUSCE81008", GetType(Decimal))
        Dim c09 As New DataColumn("CUSCE81009", GetType(Decimal))
        Dim c10 As New DataColumn("CUSCE81010", GetType(Decimal))
        Dim c11 As New DataColumn("CUSCE81011", GetType(Decimal))
        'A-CUST20260501↑

        dt.Columns.Add(c03)
        dt.Columns.Add(c04)
        dt.Columns.Add(c05)
        dt.Columns.Add(c06)
        dt.Columns.Add(c07)
        'A-CUST20260501↓
        dt.Columns.Add(c08)
        dt.Columns.Add(c09)
        dt.Columns.Add(c10)
        dt.Columns.Add(c11)
        'A-CUST20260501↑

        Return dt
    End Function

    Private Shared Function SafeGetAttr(ByVal el As XmlElement, ByVal name As String) As String
        If el Is Nothing Then
            Return ""
        End If
        If el.HasAttribute(name) Then
            Return el.GetAttribute(name)
        End If
        Return ""
    End Function


    Public Shared Sub DeleteExtItemXml(ByVal dataKind As String, ByVal meisaiKubun As String)
        Dim folderPath As String = CStr(ConfigurationManager.AppSettings("アプリケーション設定データパス"))
        If String.IsNullOrEmpty(folderPath) Then
            Exit Sub
        End If

        Dim fileName As String = BuildFileName(dataKind, meisaiKubun)
        Dim fullPath As String = Path.Combine(folderPath, fileName)

        If File.Exists(fullPath) Then
            File.Delete(fullPath)
        End If
    End Sub

End Class
