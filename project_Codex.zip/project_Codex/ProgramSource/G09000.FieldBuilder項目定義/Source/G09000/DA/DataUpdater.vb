﻿Imports System.Text.RegularExpressions

Public Class DataUpdater
    Inherits DataUpdaterBase

    Private _CommandParam As New CommandParam
    Private _データ種類名称 As IDictionary = New Hashtable

#Region "変数"
    Private _shoriMode As IShoriMode
    Private _selectMasterId As String
#End Region

#Region "列挙型"
    Enum 実行ステータス型 As Integer
        更新中 = 0
        明細拡張ファイル削除中
        拡張マスター削除中
        チェック中
        更新終了
        仮明細拡張ファイル削除中
    End Enum

    Enum 拡張データ種別 As Integer
        マスター = 0
        取引データ = 1
        受発注データ = 2
        入出荷データ = 3
        見積データ = 4
        取引パターンデータ = 5
        経費データ = 6
    End Enum

    Enum 拡張データIndex
        仕入売上 = 0
        受発注
        見積
        経費
        入出荷
        MaxIndex
    End Enum

    '更新ﾀｲﾌﾟ
    Private Enum enumExecType
        ExecNone = 0 '更新無し
        ExecINS      'INSERT
        ExecUPD      'UPDATE
        ExecDEL      'DELETE
    End Enum

    Private Enum g_enmAttr           'FieldBuilderの属性
        None = 0                          ' - 未使用
        Wide = 1                          ' - 全角文字
        Narrow = 2                        ' - 半角文字
        Numeric = 3                       ' - 数値
        YMD = 4                           ' - 年月日
        YM = 5                            ' - 年月
        Y = 6                             ' - 年
        参照定義コード = 9                  '参照定義コード
        Bmp = 11                             '画像                     
        Exe = 12                             '実行ファイル             
        File = 13                            'ファイル                 
        Folder = 14                          'フォルダ              
        URL = 15                             'URL                   
        Mail = 16                            'メールアドレス        
    End Enum

    'A-20101014_1{
    Enum 整合性チェック型 As Integer
        行わない = 0
        行う
    End Enum
    'A-20101014_1}

    '↓A-20180919-X1-マスター申請承認機能
    Enum 申請テーブル型 As Integer
        申請 = 0
        申請変更履歴
        申請一時保管
    End Enum
    '↑A-20180919-X1-マスター申請承認機能

    '↓A-20191213-X1-スマートサーチ機能
    Enum 入力履歴テーブル型 As Integer
        取引 = 1
        受発注 = 4
        見積 = 6
        入出荷 = 11
        経費 = 13
        定期取引 = 71
    End Enum
    '↑A-20191213-X1-スマートサーチ機能

    '↓A-20220408-X1.A-入力データ取込機能
    Enum 入力データテーブル型
        項目別ルールテーブル = 0
        自動入力辞書テーブル
    End Enum

    Enum 実行状態型
        修正_未使用 = 0
        修正_属性
        削除
    End Enum

    Enum 更新対象業務型
        販売
        会計
    End Enum
    '↑A-20220408-X1.A-入力データ取込機能

#End Region

#Region "内部変数定義"
    Private _logID As String = ""
    Private _logInfo As ILogInfo
    Private _subLogID As String = ""
    Private _state As Integer = 0
    Private _message As String = ""
    Private _appLogUpdater As IAppLogUpdater
    Private _更新件数用ワーク As Integer                      '更新件数用ワーク

    Private _読込件数 As Integer                      '読込件数
    Private _更新件数 As Integer                      '更新件数
    Private _ErrNumber As Long = 0

    Private _処理モード As Integer = -1     '処理モード
    Private _データ種類 As Integer          'ﾃﾞｰﾀ種類
    'Private _データ種類略称 As String       'データ種類略称  'D-CUST20251104 '2026/03/12
    Private _明細区分 As Integer            '明細区分
    Private _明細区分名 As String           '明細区分名
    Private _強化区分 As Decimal            '強化区分                                               'A-20080709_2 & A-20080709_3 & A-20080709_4 
    Private _定期取引作成 As Integer        '定期取引作成機能                                       'A-20080709_4
    Private _売上受発注区分 As Integer      '売上受発注区分
    Private _売上見積区分 As Integer        '売上見積区分
    Private _仕入経費区分 As Integer        '仕入経費区分                                           'A-20080709_2
    Private _入出荷区分 As Integer          '入出荷区分                 'A-20101213_2
    Private _データ種別名 As String         'データ種別名
    Private _データ種類名 As String         'データ種類名
    Private _実行状態フラグ As Integer      '実行状態フラグ(0:通常　1:強制)
    Private _不整合チェック As Boolean      '整合性ﾁｪｯｸで不一致ﾃﾞｰﾀが存在する場合Trueに設定する。
    Private _付箋機能変更ﾌﾗｸﾞ As Integer    '付箋機能変更ﾌﾗｸﾞ
    Private _属性変更フラグ As Integer      '属性変更ﾌﾗｸﾞ
    Private _整合処理チェック区分_売上_仕入 As Integer  '売上/仕入(整合処理より更新時、使用)
    Private _整合処理チェック区分_受注_発注 As Integer  '受注/発注(整合処理より更新時、使用)
    Private _整合処理チェック区分_見積 As Integer       '見積     (整合処理より更新時、使用)    
    Private _整合処理チェック区分_経費 As Integer       '経費     (整合処理より更新時、使用)        'A-20080709_2
    Private _整合処理チェック区分_出荷_入荷 As Integer     '出荷/入荷(整合処理より更新時、使用)        'A-20101213_2
    Private _更新再実行フラグ As Boolean = False
    Private _伝票申請承認機能_整合性チェック As Integer    '伝票申請承認機能                   'A-20101014_1
    Private _販売伝票申請承認機能_見積整合性チェック As Integer       '販売 伝票申請承認機能      'A-20101213_1
    Private _販売伝票申請承認機能_受発注整合性チェック As Integer     '販売 伝票申請承認機能      'A-20101213_1
    Private _メニューバー整合処理より実行 As Boolean        '整合処理の呼出元の判断               'A-20110408_1
    Private _Is受発注消費税あり As Boolean                  '受発注消費税ありの判断               'A-20151116_1
    '↓A-20180919-X1-マスター申請承認機能
    Private _Is得意先マスター申請承認機能あり As Boolean    '得意先マスター申請承認機能ありの判断 
    Private _Is仕入先マスター申請承認機能あり As Boolean    '仕入先マスター申請承認機能ありの判断 
    Private _Is商品マスター申請承認機能あり As Boolean      '商品マスター申請承認機能ありの判断 
    Private _Is原価集計マスター申請承認機能あり As Boolean  '原価集計マスター申請承認機能ありの判断 
    '↑A-20180919-X1-マスター申請承認機能
    '↓A-20191213-X1-スマートサーチ機能
    Private _Isスマートサーチ機能あり As Boolean 'スマートサーチ機能ありの判断
    Private _Is検収＿着荷基準仕入あり As Boolean '検収・着荷基準仕入ありの判断
    Private _Is検収＿着荷基準売上あり As Boolean '検収・着荷基準売上ありの判断
    Private _Is予定在庫区分_入出庫 As Boolean    '予定在庫区分-入出庫ありの判断
    '↑A-20191213-X1-スマートサーチ機能
    '↓A-20220408-X1.A-入力データ取込機能
    Private _Is入力データ取込機能 As Boolean
    Private _Is入力データ取込機能_会計 As Boolean
    '↑A-20220408-X1.A-入力データ取込機能
    '↓A-20220926-X1-仕入データ自動入力
    Private _Is仕入データ自動入力機能あり As Boolean
    '↑A-20220926-X1-仕入データ自動入力
#End Region

#Region "プロパティ"

    Private _stateStore As StateStore
    ''' <summary>
    ''' 状態管理クラス
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overloads Property StateStore() As StateStore
        Get
            Return _stateStore
        End Get
        Set(ByVal value As StateStore)
            _stateStore = value
        End Set
    End Property

    Private _実行ID枝番 As Long
    ''' <summary>
    ''' 実行ID枝番
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks>操作実行ログ書込み部品にてログの更新時に使用する枝番</remarks>
    Public Overloads Property 実行ID枝番() As Long
        Get
            Return _実行ID枝番
        End Get
        Set(ByVal value As Long)
            _実行ID枝番 = value
        End Set
    End Property

#End Region

#Region "メソッド"

    ''' <summary>
    ''' 更新する
    ''' </summary>
    ''' <param name="settingInfo">システム共通設定情報</param>
    ''' <param name="stateKey">状態管理用Key</param>
    ''' <param name="commandParam">更新パラメータ</param>
    ''' <param name="logInfo">ログ情報</param>
    ''' <param name="executeCheckInfo">排他情報</param>
    ''' <returns>更新結果パラメータ</returns>
    ''' <remarks></remarks>
    Public Overrides Function Update(ByVal settingInfo As System.Collections.IDictionary, ByVal stateKey As String,
                                     ByVal commandParam As ICommandParam, ByVal logInfo As CMN.LIB.AppLog.ILogInfo, ByRef executeCheckInfo As IExecuteCheckInfo) As IResultParam

        Dim result As IResultParam = Nothing
        Dim gen As New XmlFileWriter()
        Dim folders As String = CStr(System.Configuration.ConfigurationManager.AppSettings("アプリケーション設定データパス"))
        Initialize(settingInfo)
        SetUpDAC()

        Using connection As DbConnection = OpenConnection()

            StateStore = New StateMachine.DataAccess.StateStore
            StateStore.Initialize(settingInfo) 'A-20201221-X1-Air対応_ステート管理へのSettingInfo引き渡し
            StateStore.Startup(stateKey)

            _logInfo = logInfo

            Dim endContentsOfProcess As String = ""
            result = UpdateImpl(0, connection, commandParam, executeCheckInfo)

            EndAppLog(result)

            StateStore.Shutdown()

            If result.UpdateResult <> ResultType.成功 Then
                Return result
            End If

            '削除時はXMLを削除する
            If _処理モード = IShoriMode.処理モード区分.削除 Then
                'Dim dataKind As Integer = CInt(Val(_データ種類.ToString()))
                'Dim dataKind As String = CStr(_データ種類略称)  'D-CUST20251104 '2026/03/12
                Dim dataKind As String = CStr(_データ種類名)  'A-CUST20251104 '2026/03/12
                'Dim meisaiKubun As Integer = CInt(Val(_明細区分.ToString()))
                Dim meisaiKubun As String = CStr(_明細区分名)
                If dataKind <> "" AndAlso meisaiKubun <> "" Then
                    XmlExtItemReader.DeleteExtItemXml(dataKind, meisaiKubun)
                End If
                CloseConnection(connection)
                Return result
            End If

            'XMLへ書き出し
            ' 1) 詰め替え
            Dim infos(_updateCUSCE81Back.Length - 1) As XmlFileWriter.ExtItemInfo
            Dim i As Integer
            For i = 0 To _updateCUSCE81Back.Length - 1
                infos(i) = ToExtItemInfo(_updateCUSCE81Back(i))
            Next

            gen.WriteOrUpdateGrouped(folders, infos)
            CloseConnection(connection)
        End Using

        Return result
    End Function

    Protected Overrides Function UpdateImpl(ByVal mode As 更新モード型, ByVal connection As DbConnection, ByVal commandParam As ICommandParam,
                                            ByRef executeCheckInfo As IExecuteCheckInfo) As Foundation.Batch.IResultParam
        _不整合チェック = False

        Return DoBatch(connection, commandParam, executeCheckInfo)
    End Function

    ''' <summary>
    ''' 更新する
    ''' </summary>
    ''' <returns>データ種類名</returns>
    ''' <remarks></remarks>
    Private Function GetMasterKubunMeisho(ByVal _データ種類 As Integer) As String
        Dim result As String = ""

        Select Case _データ種類
            Case 1
                result = _データ種類名称("得意先").ToString
            Case 2
                result = _データ種類名称("仕入先").ToString
            Case 3
                result = _データ種類名称("商品").ToString
            Case 4
                result = _データ種類名称("担当者").ToString
            Case 5
                result = _データ種類名称("仕入担当者").ToString
            Case 6
                result = _データ種類名称("部門").ToString
            Case 7
                result = _データ種類名称("納品先").ToString
            Case 8
                result = _データ種類名称("倉庫").ToString
            Case 9
                result = _データ種類名称("営業所").ToString
            Case 10
                result = _データ種類名称("得意先別商品サブ").ToString
            Case 11
                result = _データ種類名称("仕入先別商品サブ").ToString
            Case 12                                                                     'A-20080709_2
                result = _データ種類名称("原価集計").ToString                           'A-20080709_2
            Case 13                                                                     'A-20091125_1
                result = _データ種類名称("ロット").ToString                             'A-20091125_1
        End Select

        Return result
    End Function

    ''' <summary>
    ''' UI側から渡ってきた値へ退避させる
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetArgFromParamData(ByVal commandParam As ICommandParam)

        _処理モード = CType(commandParam, CommandParam).処理モード                              '0:登録 1:修正 2:削除
        '_データ種別 = CType(commandParam, CommandParam).データ種別                              '0:ﾏｽﾀｰ 1:取引ﾃﾞｰﾀ
        '_データ種別名 = CType(commandParam, CommandParam).データ種別名
        _データ種類 = CType(commandParam, CommandParam).データ種類
        _データ種類名 = CType(commandParam, CommandParam).データ種類名
        '_データ種類略称 = CType(commandParam, CommandParam).データ種類略称  'D-CUST20251104 '2026/03/12
        'If _データ種別 = 0 Then
        '    _明細区分 = 0                                                                       '0:マスター
        'Else
        _明細区分 = CType(commandParam, CommandParam).明細区分                              '1:伝票(ヘッダー)　2:明細
        _明細区分名 = CType(commandParam, CommandParam).明細区分名
        'If _明細区分 = 1 Then
        '    _明細区分名 = "伝票"
        'Else
        '    _明細区分名 = "明細"
        'End If


        For i As Integer = 0 To 29
            _updateCUSCE81Back(i).zokusei = CType(commandParam, CommandParam).項目属性LIST(i).属性
            _updateCUSCE81Back(i).keta_Seisuu = CType(commandParam, CommandParam).項目属性LIST(i).整数部桁数
            _updateCUSCE81Back(i).keta_Shousuu = CType(commandParam, CommandParam).項目属性LIST(i).小数部桁数
            _updateCUSCE81Back(i).koumokuMei = CType(commandParam, CommandParam).項目属性LIST(i).項目名
            _updateCUSCE81Back(i).koumokuNumber = i
            _updateCUSCE81Back(i).kousinNumber = CType(commandParam, CommandParam).項目属性LIST(i).項目更新番号
            'A-CUST20260501↓
            _updateCUSCE81Back(i).dispFlg = CType(commandParam, CommandParam).項目属性LIST(i).画面表示
            _updateCUSCE81Back(i).dispRow = CType(commandParam, CommandParam).項目属性LIST(i).行位置
            _updateCUSCE81Back(i).dispCol = CType(commandParam, CommandParam).項目属性LIST(i).表示順
            _updateCUSCE81Back(i).keta_Grid = CType(commandParam, CommandParam).項目属性LIST(i).表示桁数
            'A-CUST20260501↑
        Next
    End Sub

    'A-20101213_2{
    Private Function Check入出荷区分() As Long
        If _入出荷区分 = 5 Then     '5:出荷 6:入荷
            Return 1        'DB更新値に変換
        Else
            Return 2        'DB更新値に変換
        End If
    End Function
    'A-20101213_2}

#End Region

    ''' <summary>
    ''' バッチ処理の実行
    ''' </summary>
    ''' <remarks></remarks>
    Private Function DoBatch(ByVal connection As DbConnection, ByVal commandParam As ICommandParam, ByRef executeCheckInfo As IExecuteCheckInfo) As IResultParam

        Dim strLogData As String = ""    'ﾃｷｽﾄﾛｸﾞ編集用
        Dim lngExItemNo As Long = 0      'FieldBuilder1～30
        Dim lngKosJikkoNo As Long = 0    '更新中ｲﾝﾃﾞｯｸｽ
        Dim lngKosErrNo As Long = 0
        Dim strEndMessage As String = ""
        Dim blnUnKnownError As Boolean = False

        'UI層からのデータを退避する。
        Call SetArgFromParamData(commandParam)


        Dim updateCount As Integer

        Dim checkResult As IResultParam
        checkResult = CommonFactory.CreateInstance(Of IResultParam)(Me, GetType(ResultParam))

        Dim checkControl As IExecuteControlerForUpdate
        checkControl = CommonFactory.CreateInstance(Of IExecuteControlerForUpdate)(Me, GetType(ExecuteControlerForUpdate))
        checkControl.Initialize(Me)

        Try
            Using newConnection As DbConnection = Me.OpenConnection()
                Using transaction As DbTransaction = DataAccess.BeginTransaction(connection)

                    Try
                        'If checkControl.StartExecution(executeCheckInfo, CheckCondition.異常終了チェック無し) = ExecuteCheckResult.排他エラー Then 'D-20080416_1
                        If checkControl.StartExecution(executeCheckInfo, CheckCondition.通常チェック) = ExecuteCheckResult.排他エラー Then          'A-20080416_1
                            checkResult.UpdateResult = ResultType.同時実行不可
                            Return checkResult
                        End If

                        '開始ログ書込み(DB)
                        RequestStartAppLog(commandParam)

                        'A-CUST20251104↓ '2026/03/16
                        If _処理モード <> -1 Then
                            Call LockCE81(transaction, checkResult)
                        End If
                        'A-CUST20251104↑ '2026/03/16

                        If checkResult.UpdateResult = ResultType.ロック中 Then
                            Return checkResult
                        End If

                        'A-CUST20251104↓ '2026/03/16
                        '結果に応じたエラーハンドリング
                        If _ErrNumber <> 0 AndAlso _ErrNumber <> 1 Then
                            If _ErrNumber = 3 Then
                                '他で更新されている（バージョン不一致）
                                checkResult.UpdateResult = ResultType.他で更新済
                                checkResult.ResultInfo.Add("更新番号エラー", "メイン更新番号エラー")
                                Return checkResult
                            ElseIf _ErrNumber = 2 Then
                                '登録時にキー重複
                                checkResult.UpdateResult = ResultType.一意制約違反
                                Return checkResult
                            Else
                                checkResult.Set結果情報("FieldBuilder属性情報テーブルロック時にエラーが発生しました")
                                GetErrorEnd処理内容(checkResult)
                                Return checkResult
                            End If
                        End If
                        'A-CUST20251104↑ '2026/03/16

                        If DoBatchMain(transaction, commandParam, updateCount, checkResult) = False Then
                            DataAccess.RollbackTransaction(transaction)
                            'checkResult.UpdateResult = Foundation.ResultType.想定された失敗                 'D-20090107_1
                            GetErrorEnd処理内容(checkResult)
                            Return checkResult
                        End If

                        strEndMessage = ""
                        If _不整合チェック = True Then
                            DataAccess.RollbackTransaction(transaction)
                            Exit Try
                        End If

                        DataAccess.CommitTransaction(transaction)

                        checkResult.UpdateResult = Foundation.ResultType.成功
                        checkResult.Set結果情報(WriteExecuteStatus(実行ステータス型.更新終了, _更新件数))
                        checkResult.ResultInfo.Add("処理件数", _更新件数)

                        checkControl.EndExecution()
                    Catch ex As Exception
                        Throw
                    Finally
                        CloseConnection(newConnection)
                    End Try
                End Using
            End Using
        Finally
            checkControl.Release()
        End Try

        Return checkResult
    End Function

    ''' <summary>
    ''' バッチ処理のメイン処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Function DoBatchMain(ByVal transaction As DbTransaction, ByVal commandParam As ICommandParam,
                                 ByRef updateCount As Integer, ByRef checkResult As IResultParam) As Boolean

        'Dim lngExItemNo As Long
        Dim intMax As Integer
        'Dim lngRet As Long
        Dim paramInfo As ParamInfoList = New ParamInfoList

        Select Case _売上受発注区分 + _売上見積区分 + _仕入経費区分 + _入出荷区分                                           'A-20101213_2
            Case 0
                intMax = 0
            Case Else
                'intMax = 2                                                                                                 'D-20080709_2
                intMax = 拡張データIndex.MaxIndex - 1                                                                       'A-20080709_2
        End Select

        '売上の場合(処理モードに合わせて更新処理を選択する。)
        Select Case _処理モード
            Case IShoriMode.処理モード区分.登録
                'Call InsertZ030(transaction, commandParam, _売上受発注区分, lngExItemNo, checkResult)
                Call InsertCE81(transaction, commandParam, _売上受発注区分, checkResult)

            Case IShoriMode.処理モード区分.修正
                'LockCE81で既にバージョン確認済み：_ErrNumber=3なら他で更新されている
                If _ErrNumber = 0 Then  'バージョンOK    'A-CUST20251104 '2026/03/16
                    Call DeleteCE81(transaction, commandParam, checkResult)
                    Call InsertCE81(transaction, commandParam, _売上受発注区分, checkResult)
                End If  'A-CUST20251104 '2026/03/12

            Case IShoriMode.処理モード区分.削除
                If _ErrNumber <> 1 Then
                    'Call DeleteZ030(transaction, commandParam, lngExItemNo, checkResult)
                    Call DeleteCE81(transaction, commandParam, checkResult)
                End If
        End Select


        Dim blnCheck As Boolean
        Select Case _属性変更フラグ
            Case 0
                blnCheck = False
            Case 1
                blnCheck = True
        End Select

        If Not blnCheck Then
            If _処理モード = IShoriMode.処理モード区分.削除 Then
                blnCheck = True
            End If
        End If

        Return True
    End Function

#Region "更新処理"

#Region "登録処理"
    ''' <summary>
    ''' CE81:FieldBuilder属性情報更新処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Function InsertCE81(ByVal transaction As DbTransaction, ByVal commandParam As ICommandParam,
                                 ByVal lngSwitch As Integer, ByRef checkResult As IResultParam) As Long

        Dim SQL As String = ""

        SQL = GetSQLInsertCE81()


        _updateCUSCE81.detaShurui = _データ種類
        _updateCUSCE81.meisaiKubun = _明細区分


        For i As Integer = 0 To 29

            Dim insertCheck As Boolean = False


            If _明細区分 = 0 Then insertCheck = True
            Try
                DataAccess.SetLockTimeOut(transaction, 0)
                ' 属性が「0:未使用」ではなく、属性用グリッドの使用区分にチェックが入っていたら登録する。
                If _updateCUSCE81Back(i).zokusei.ToString <> "0" Then 'AndAlso insertCheck = True Then
                    Dim ParamInfo As ParamInfoList = New ParamInfoList

                    _updateCUSCE81.koumokuNumber = i + 1
                    _updateCUSCE81.zokusei = _updateCUSCE81Back(i).zokusei

                    _updateCUSCE81.keta_Seisuu = _updateCUSCE81Back(i).keta_Seisuu
                    _updateCUSCE81.koumokuMei = _updateCUSCE81Back(i).koumokuMei
                    'End If
                    _updateCUSCE81.keta_Shousuu = _updateCUSCE81Back(i).keta_Shousuu
                    'A-CUST20260501↓
                    _updateCUSCE81.dispFlg = _updateCUSCE81Back(i).dispFlg
                    _updateCUSCE81.dispRow = _updateCUSCE81Back(i).dispRow
                    _updateCUSCE81.dispCol = _updateCUSCE81Back(i).dispCol
                    _updateCUSCE81.keta_Grid = _updateCUSCE81Back(i).keta_Grid
                    'A-CUST20260501↑
                    _updateCUSCE81.kousinNumber = _updateCUSCE81Back(i).kousinNumber

                    ParamInfo = SetParameterInsertCE81(ParamInfo)
                    DataAccess.ExecuteNonQuery(transaction, SQL, ParamInfo)
                End If

            Catch ex As Exception
                checkResult.Set結果情報("FieldBuilder属性情報テーブルの更新に失敗しました。")
                Throw
            End Try
        Next
    End Function

#End Region

#Region "修正処理"

#End Region

#Region "削除処理"

    ''' <summary>
    ''' CE81:FieldBuilder属性情報(削除)
    ''' </summary>
    ''' <remarks></remarks>
    Private Function DeleteCE81(ByVal transaction As DbTransaction, ByVal commandParam As ICommandParam,
                                  ByRef checkResult As IResultParam) As Long

        Dim SQL As String = ""
        Dim paramInfo As ParamInfoList = New ParamInfoList

        SQL = GetSQLDeleteCE81()

        Try
            'A-20080709_2
            _updateCUSCE81.detaShurui = _データ種類
            _updateCUSCE81.meisaiKubun = _明細区分

            paramInfo = SetParameterDeleteCE81(paramInfo)

            DataAccess.ExecuteNonQuery(transaction, SQL, paramInfo)
        Catch ex As Exception
            checkResult.Set結果情報("FieldBuilder属性情報テーブルの更新に失敗しました。")
            Throw
        End Try

    End Function

    'A-CUST20251104↓ '2026/03/16
    ''' <summary>
    ''' CE81:FieldBuilder属性情報の排他ロックを行う
    ''' </summary>
    ''' <remarks>修正・削除前にバージョン確認を実施する</remarks>
    Private Function LockCE81(ByVal transaction As DbTransaction, ByRef checkResult As IResultParam) As Long
        Dim hasRows As Boolean
        Dim SQL As String = ""
        Dim dataReader As DbDataReader = Nothing
        Dim command As DbCommand = Nothing
        Dim ParamInfo As ParamInfoList = New ParamInfoList

        SQL = GetSQLLockCE81()

        Try
            DataAccess.SetLockTimeOut(transaction, 0)

            _updateCUSCE81.detaShurui = _データ種類
            _updateCUSCE81.meisaiKubun = _明細区分

            SetParam(ParamInfo, "CE001001", DbType.Decimal, 0, 2, 0, _updateCUSCE81.detaShurui)      'データ種類
            SetParam(ParamInfo, "CE001002", DbType.Decimal, 0, 2, 0, _updateCUSCE81.meisaiKubun)     '明細区分

            dataReader = DataAccess.GetDataReader(transaction, SQL, ParamInfo, hasRows, command)

            If _処理モード = IShoriMode.処理モード区分.登録 Then
                '登録時：既存レコードがあったらキー重複エラー
                If hasRows = True Then
                    checkResult.UpdateResult = ResultType.一意制約違反
                    _ErrNumber = 2
                End If
            Else
                '修正・削除時：レコード存在確認とバージョン比較
                If hasRows = False Then
                    checkResult.UpdateResult = ResultType.成功
                    _ErrNumber = 1
                Else
                    'バージョン番号チェック：メモリ内値 vs DB内値
                    Dim memoryVersion As Integer = _updateCUSCE81Back(0).kousinNumber
                    Dim dbCurrentVersion As Integer = CType(dataReader.GetValue(0), Integer)

                    '修正・削除時は+1されているので-1して比較
                    If _処理モード = IShoriMode.処理モード区分.修正 OrElse _処理モード = IShoriMode.処理モード区分.削除 Then
                        memoryVersion = memoryVersion - 1
                    End If

                    If memoryVersion <> dbCurrentVersion Then
                        checkResult.UpdateResult = ResultType.他で更新済
                        _ErrNumber = 3
                    End If
                End If
            End If

        Catch ex As DBLockException
            checkResult.UpdateResult = ResultType.ロック中
        Catch ex As Exception
            Throw
        Finally
            DataAccess.CancelCommand(command)
            DataAccess.CloseReader(dataReader)
        End Try
    End Function

    'A-CUST20251104↑ '2026/03/16

#End Region

#End Region

#Region "操作ログ・状態管理"

    Private Overloads Sub RequestStartAppLog(ByVal commandParam As ICommandParam)

        _appLogUpdater = CommonFactory.CreateInstance(Of IAppLogUpdater)(Me, GetType(AppLogUpdater))
        _appLogUpdater.Initialize(Me.SettingInfo)

        If _更新再実行フラグ = False Then
            _logInfo.処理状態 = 処理状態型.処理開始
            _appLogUpdater.InsertLogData(_logInfo, Nothing)
            _実行ID枝番 = ProgressAppLog()
        Else
            _実行ID枝番 = CType(commandParam, CommandParam).実行ID枝番
        End If


    End Sub

    Private Function ProgressAppLog() As Long
        StateStore.UpdateProgress("処理開始しました")
        Dim progressLog As ILogInfo = New LogInfo()
        progressLog.処理状態 = 処理状態型.処理中
        progressLog.処理内容 = "処理開始しました"
        progressLog.詳細情報 = _logInfo.詳細情報
        Return _appLogUpdater.InsertLogData(progressLog, Nothing)
    End Function

    ''' <summary>
    ''' 処理状態=処理中で操作ログを更新する
    ''' </summary>
    ''' <param name="count">処理件数</param>
    ''' <remarks></remarks>
    Private Overloads Sub UpdateProgressAppLog(ByVal count As Integer)
        UpdateProgressAppLog(処理状態型.処理中, String.Format("処理件数{0}件", count))
    End Sub

    ''' <summary>
    ''' 処理状態=処理中の操作ログを更新する
    ''' </summary>
    ''' <param name="処理内容">処理内容</param>
    ''' <remarks></remarks>
    Private Overloads Sub UpdateProgressAppLog(ByVal 処理内容 As String)
        UpdateProgressAppLog(処理状態型.処理中, 処理内容)
    End Sub

    ''' <summary>
    ''' 操作ログ出力　終了
    ''' </summary>
    ''' <param name="result">戻りパラメータ</param>
    ''' <remarks></remarks>
    Private Sub EndAppLog(ByVal result As IResultParam)
        If _appLogUpdater Is Nothing Then Exit Sub

        Dim 処理内容 As String = GetResultInfo(result.ResultInfo(), "")
        Select Case result.UpdateResult
            Case ResultType.成功
                UpdateProgressAppLog(処理状態型.正常終了, 処理内容)
            Case Else
                If result.ResultInfo.Contains("想定された失敗") = False Then
                    UpdateProgressAppLog(処理状態型.異常終了, GetErrorEnd処理内容(result))
                Else
                    UpdateProgressAppLog(処理状態型.正常終了, GetErrorEnd処理内容(result))
                End If

        End Select
    End Sub

    Friend Function GetResultInfo(ByVal resultInfo As IDictionary, ByVal defaultValue As String) As String
        If resultInfo.Contains("結果情報") Then
            Return resultInfo.Item("結果情報").ToString
        Else
            Return defaultValue
        End If
    End Function

    ''' <summary>
    ''' 操作ログを更新する
    ''' </summary>
    ''' <param name="state">処理状態</param>
    ''' <param name="処理内容">処理内容</param>
    ''' <remarks></remarks>
    Private Overloads Sub UpdateProgressAppLog(ByVal state As 処理状態型, ByVal 処理内容 As String)

        _appLogUpdater.UpdateLogData(state, 処理内容, _実行ID枝番)
    End Sub

    Private Function ProgressEndAppLog() As Long
        Return _appLogUpdater.InsertLogData(_logInfo, Nothing)
    End Function

    ''' <summary>
    ''' 異常終了時の操作ログの書込みを行なう
    ''' </summary>
    ''' <param name="result">処理結果</param>
    ''' <remarks>処理内容</remarks>
    Protected Overrides Function GetErrorEnd処理内容(ByVal result As IResultParam) As String
        Dim 処理内容 As String = GetResultInfo(result.ResultInfo(), "")
        Return 処理内容
    End Function

    Private Function WriteExecuteStatus(ByVal status As 実行ステータス型, ByVal updateCount As Integer) As String
        Dim returnMessage As String = ""

        Select Case status
            Case 実行ステータス型.更新中
                returnMessage = "更新中... "
            Case 実行ステータス型.更新終了
                returnMessage = "処理を終了しました "
        End Select

        'D-CUST20251104↓ '2026/03/12
        'If _処理モード = IShoriMode.処理モード区分.修正 Then
        '    returnMessage &= "(処理件数：" & CType(updateCount, String) & "件)"
        'End If
        'D-CUST20251104↑ '2026/03/12
        Return returnMessage
    End Function

    Private Function WriteExecuteStatus(ByVal status As 実行ステータス型, ByVal updateCount As Integer, ByVal readCount As Integer) As String
        Dim returnMessage As String = ""

        Select Case status
            Case 実行ステータス型.更新中
                returnMessage = "更新中... "
            Case 実行ステータス型.更新終了
                returnMessage = "処理を終了しました "
        End Select
        returnMessage &= "(処理件数：" & CType(updateCount, String) & "件/ " & CType(readCount, String) & "件)"

        Return returnMessage
    End Function

    Private Function WriteExecuteStatus(ByVal status As 実行ステータス型) As String
        Dim returnMessage As String = ""

        Select Case status
            Case 実行ステータス型.更新中
                returnMessage = "更新中..."
            Case 実行ステータス型.明細拡張ファイル削除中
                returnMessage = "明細拡張ファイル削除中..."
            Case 実行ステータス型.拡張マスター削除中
                returnMessage = "拡張マスター削除中..."
            Case 実行ステータス型.チェック中
                returnMessage = "整合性チェック中..."
            Case 実行ステータス型.更新終了
                returnMessage = "処理を終了しました"
        End Select

        Return returnMessage
    End Function

#End Region

#Region "標準モジュール"

    ''' <summary>
    ''' ﾃﾞｰﾀ種類に該当する伝票区分を返す。
    ''' </summary>
    ''' <remarks></remarks>
    Friend Function GetDenpKBN(ByRef dataShurui As Integer, Optional ByVal optionKubun As Integer = 0) As Integer

        Select Case optionKubun
            Case 0
                Select Case dataShurui 'ﾃﾞｰﾀ種類
                    Case 1 '売上
                        GetDenpKBN = 3
                    Case 2 '入金
                        GetDenpKBN = 4
                    Case 3 '仕入
                        GetDenpKBN = 1
                    Case 4 '支払
                        GetDenpKBN = 2
                    Case 5 '入出庫
                        GetDenpKBN = 5
                    Case Else
                        GetDenpKBN = dataShurui
                End Select
            Case 1
                Select Case dataShurui 'ﾃﾞｰﾀ種類
                    Case 1
                        GetDenpKBN = 2
                    Case 3
                        GetDenpKBN = 1
                        'A-20121120_1{
                    Case 5  '入出庫予定
                        GetDenpKBN = 5
                        'A-20121120_1}
                End Select
            Case 2
                GetDenpKBN = 1
        End Select

    End Function


#End Region

    ''' <summary>
    ''' 整合性ﾁｪｯｸ処理-実ﾃﾞｰﾀと属性との比較
    ''' </summary>
    ''' <remarks></remarks>
    Private Function CheckData(ByVal lngExItemNo As Long, ByVal strItemValue As String, Optional ByVal lngJuhatu As Long = 0) As Boolean
        Dim intX As Integer
        Dim lngKETA As Integer
        Dim strZ As String
        Dim blnTEN_SW As Boolean

        CheckData = False

        If strItemValue = "" Then
            CheckData = True
            Exit Function
        End If
        Select Case Val(_updateCUSCE81Back(CInt(lngExItemNo)).zokusei)
            Case g_enmAttr.None             '未使用
                If strItemValue <> "" Then
                    strItemValue = ""
                    Exit Function
                End If

            Case g_enmAttr.Wide  '全角
                'FieldBuilder項目のバイト数が定義ﾌｧｲﾙの桁数より多い場合はエラー
                If OSK.X1.Foundation.TextUtility.GetTextLength(strItemValue) > Val(_updateCUSCE81Back(CInt(lngExItemNo)).keta_Seisuu) Then    'X1変換Tool-20160427
                    strItemValue = ""
                    Exit Function
                End If

            Case g_enmAttr.Narrow  '半角
                '※半角でも全角文字が入るのでこのチェック↓はしない
                ''バイト数と文字数が一致しない場合はエラー
                'If OSK.X1.Foundation.TextUtility.GetTextLength(strItemValue) <> strItemValue.Length Then    'X1変換Tool-20160427
                '    strItemValue = ""
                '    Exit Function
                'End If
                'If Val(_updateCUSZE01Back(CInt(lngExItemNo)).zokusei2) = g_enmAttr2.None Then                                                       'A-20080709_3
                'FieldBuilder項目のバイト数が定義ﾌｧｲﾙの桁数より多い場合はエラー
                If OSK.X1.Foundation.TextUtility.GetTextLength(strItemValue) > Val(_updateCUSCE81Back(CInt(lngExItemNo)).keta_Seisuu) Then    'X1変換Tool-20160427
                    strItemValue = ""
                    Exit Function
                End If
                'Else                                                                                                                                'A-20080709_3
                '    '属性２が設定されている場合は、属性２との整合性チェックを行う                                                                   'A-20080709_3
                '    If CheckData2(lngExItemNo, strItemValue, lngJuhatu) = False Then                                                                'A-20080709_3
                '        Exit Function                                                                                                               'A-20080709_3
                '    End If                                                                                                                          'A-20080709_3
                'End If                                                                                                                              'A-20080709_3

            Case g_enmAttr.Numeric   '数値
                If Trim$(strItemValue) = "" Then
                    CheckData = True
                    Exit Function
                End If
                '数値の場合、数値以外の文字が1文字でもあったらエラー
                lngKETA = Len(Trim$(strItemValue))
                If lngKETA = 0 Then Exit Function

                For intX = 1 To lngKETA
                    strZ = Mid(strItemValue, intX, 1)
                    Select Case strZ
                        Case "0" To "9"
                        Case "-"
                            If intX <> 1 Then
                                strItemValue = ""
                                Exit Function
                            End If
                        Case "."
                            If blnTEN_SW = True Then
                                strItemValue = ""
                                Exit Function
                            Else
                                blnTEN_SW = True
                            End If
                        Case Else
                            strItemValue = ""
                            Exit Function
                    End Select
                Next

                If NUM_CHK(strItemValue, CInt(Val(_updateCUSCE81Back(CInt(lngExItemNo)).keta_Seisuu) + Val(_updateCUSCE81Back(CInt(lngExItemNo)).keta_Shousuu)),
                                         CInt(Val(_updateCUSCE81Back(CInt(lngExItemNo)).keta_Shousuu))) = False Then          'NUM_CHKで桁数,小数点等のﾁｪｯｸ
                    strItemValue = ""
                    Exit Function
                End If

                If Val(strItemValue) = 0 Then
                    strItemValue = ""
                    Exit Function
                End If

            Case g_enmAttr.YMD '年月日
                If IsDateEx(strItemValue, 8) = False Then
                    strItemValue = ""
                    Exit Function
                End If

            Case g_enmAttr.YM '年月
                If IsDateEx(strItemValue, 6) = False Then
                    strItemValue = ""
                    Exit Function
                End If

            Case g_enmAttr.Y '年
                If IsDateEx(strItemValue, 4) = False Then
                    strItemValue = ""
                    Exit Function
                End If

            Case g_enmAttr.参照定義コード

                '桁ｵｰﾊﾞｰ
                If Len(strItemValue) <> Val(_updateCUSCE81Back(CInt(lngExItemNo)).keta_Seisuu) Then
                    strItemValue = ""
                    Exit Function
                End If

            Case g_enmAttr.Bmp             '画像
                'FieldBuilder項目のバイト数が定義ﾌｧｲﾙの桁数より多い場合はエラー
                If OSK.X1.Foundation.TextUtility.GetTextLength(strItemValue) > Val(_updateCUSCE81Back(CInt(lngExItemNo)).keta_Seisuu) Then    'X1変換Tool-20160427
                    strItemValue = ""
                    Exit Function
                End If

            Case g_enmAttr.Exe             '実行ファイル
                'FieldBuilder項目のバイト数が定義ﾌｧｲﾙの桁数より多い場合はエラー
                If OSK.X1.Foundation.TextUtility.GetTextLength(strItemValue) > Val(_updateCUSCE81Back(CInt(lngExItemNo)).keta_Seisuu) Then    'X1変換Tool-20160427
                    strItemValue = ""
                    Exit Function
                End If

            Case g_enmAttr.File            'ファイル
                'FieldBuilder項目のバイト数が定義ﾌｧｲﾙの桁数より多い場合はエラー
                If OSK.X1.Foundation.TextUtility.GetTextLength(strItemValue) > Val(_updateCUSCE81Back(CInt(lngExItemNo)).keta_Seisuu) Then    'X1変換Tool-20160427
                    strItemValue = ""
                    Exit Function
                End If

            Case g_enmAttr.Folder          'フォルダ
                'FieldBuilder項目のバイト数が定義ﾌｧｲﾙの桁数より多い場合はエラー
                If OSK.X1.Foundation.TextUtility.GetTextLength(strItemValue) > Val(_updateCUSCE81Back(CInt(lngExItemNo)).keta_Seisuu) Then    'X1変換Tool-20160427
                    strItemValue = ""
                    Exit Function
                End If

            Case g_enmAttr.URL             'URL
                'FieldBuilder項目のバイト数が定義ﾌｧｲﾙの桁数より多い場合はエラー
                If OSK.X1.Foundation.TextUtility.GetTextLength(strItemValue) > Val(_updateCUSCE81Back(CInt(lngExItemNo)).keta_Seisuu) Then    'X1変換Tool-20160427
                    strItemValue = ""
                    Exit Function
                End If

            Case g_enmAttr.Mail            'メールアドレス
                'FieldBuilder項目のバイト数が定義ﾌｧｲﾙの桁数より多い場合はエラー
                If OSK.X1.Foundation.TextUtility.GetTextLength(strItemValue) > Val(_updateCUSCE81Back(CInt(lngExItemNo)).keta_Seisuu) Then    'X1変換Tool-20160427
                    strItemValue = ""
                    Exit Function
                End If
        End Select

        CheckData = True
    End Function


    Public Function NUM_CHK(ByVal CHK_TK As String, ByVal MAX_KT As Integer, ByVal DEC_KT As Integer) As Boolean

        Dim j As Integer
        Dim K As Integer
        Dim itext As String

        NUM_CHK = True
        '*** 整数部ﾁｪｯｸ ************************************************
        'ﾁｪｯｸ項目より整数部分抜き出し
        j = InStr(1, CHK_TK, ".")
        If j <> 0 Then
            j = j - 1
            itext = Mid(CHK_TK, 1, j)
        Else
            itext = CHK_TK
        End If

        '整数部桁数ｵｰﾊﾞｰﾁｪｯｸ
        If Val(CHK_TK) > 0 Then
            If Val(Trim$(itext)) > Val(Format(9, New String(CChar("9"), MAX_KT - DEC_KT))) OrElse Val(Trim$(itext)) < 0 Then
                NUM_CHK = False
                Exit Function
            End If
        ElseIf Val(CHK_TK) < 0 Then
            If Val(Trim$(itext)) < Val(Format(9, New String(CChar("9"), MAX_KT - DEC_KT))) * -1 OrElse Val(Trim$(itext)) > 0 Then
                NUM_CHK = False
                Exit Function
            End If
        End If
        '*** 小数部ﾁｪｯｸ ************************************************
        j = Len(Trim$(CHK_TK))
        K = 0
        '内容値=Null or 桁数=0 はﾁｪｯｸ対象外
        If CHK_TK = "" And j = 0 Then
            Exit Function
        End If
        'ﾁｪｯｸ項目より小数部の桁数算出
        Do Until Mid(CHK_TK, j - K, 1) = Chr(46) OrElse j - K = 0
            K = K + 1
            If K = j Then
                If Mid(CHK_TK, j - (K - 1), 1) <> Chr(46) Then
                    K = 0
                    Exit Do
                End If
            End If
        Loop
        '小数部桁数ｵｰﾊﾞｰﾁｪｯｸ
        If K > DEC_KT Then
            NUM_CHK = False
            Exit Function
        End If
    End Function

    ''' <summary>
    ''' 日付ﾁｪｯｸを行う
    ''' </summary>
    ''' <remarks></remarks>
    Private Function IsDateEx(ByRef strValue As String, ByRef lngLength As Long) As Boolean

        IsDateEx = False
        '数値ﾁｪｯｸ
        If Not IsNumeric(strValue) Then
            Exit Function
        End If
        '桁ﾁｪｯｸ
        If Len(strValue) <> lngLength Then
            Exit Function
        End If
        '日付論理ﾁｪｯｸ - 日付ﾁｪｯｸが可能な形式(yyyy/mm/dd)に変換してﾁｪｯｸ
        Dim strCheckDate As String = ""

        Select Case lngLength
            Case 8 '年月日
                strCheckDate = Mid$(strValue, 1, 4) & "/" & Mid$(strValue, 5, 2) & "/" & Mid$(strValue, 7, 2)
            Case 6 '年月 - 日は"01"固定
                strCheckDate = Mid$(strValue, 1, 4) & "/" & Mid$(strValue, 5, 2) & "/01"
            Case 4 '年 - 月日は"0101"固定
                strCheckDate = strValue & "/01/01"
        End Select

        If IsDate(strCheckDate) = False Then
            Exit Function
        End If

        IsDateEx = True
    End Function


#Region "MakeSQL"

#Region "MakeSQL(読込み)"
#End Region

#Region "MakeSQL(登録)"
    '**************************************************************
    ' @プロシージャ名: GetSQLInsertCE81
    ' @機能　　　　　: Insert文を返す。
    '**************************************************************
    Private Function GetSQLInsertCE81() As String
        'FieldBuilder属性情報テーブル
        Dim SQL As String = ""
        Dim updateItem As String = ""
        Dim updateParam As String = ""

        'For i As Integer = 1 To 7  'D-CUST20260501
        For i As Integer = 1 To 11   'A-CUST20260501
            updateItem &= "CUSCE81" & Format(i, "000") & ", "
            updateParam &= "?, "
        Next
        updateItem &= "CUSCE81999 "
        updateParam &= " ? "


        SQL &= ""
        SQL &= "INSERT INTO " & Me.ExchangeTableName("CUS98CE81ZOKUSEI") & " ( "    'X1変換Tool-20160427
        SQL &= updateItem
        SQL &= ") VALUES ("
        SQL &= updateParam
        SQL &= ")"

        Return SQL
    End Function

#End Region

#Region "MakeSQL(更新)"


#End Region

#Region "MakeSQL(削除)"

    '**************************************************************
    ' @プロシージャ名: GetSQLDeleteCE81
    ' @機能　　　　　: 削除を行うSQL文を返す
    '**************************************************************
    Private Function GetSQLDeleteCE81() As String

        Dim SQL As String

        SQL = ""
        SQL &= "DELETE FROM " & Me.ExchangeTableName("CUS98CE81ZOKUSEI") & " "    'X1変換Tool-20160427
        SQL &= "WHERE CUSCE81001 = ? "       'ﾃﾞｰﾀ種類
        SQL &= "  AND CUSCE81002 = ? "       '明細区分

        Return SQL
    End Function

#End Region

    'A-CUST20251104↓ '2026/03/16
#Region "MakeSQL(ロック)"
    '**************************************************************
    ' @プロシージャ名: GetSQLLockCE81
    ' @機能　　　　　: CE81ロックチェックを行うSQL文を返す
    '**************************************************************
    Private Function GetSQLLockCE81() As String
        Dim SQL As String
        SQL = ""
        SQL &= "SELECT CUSCE81999 "
        SQL &= "FROM " & Me.ExchangeTableName("CUS98CE81ZOKUSEI") & " " & QueryWrapper.AddUpdLock(True) & " "
        SQL &= "WHERE CUSCE81001 = ? "       'データ種類
        SQL &= "  AND CUSCE81002 = ? "       '明細区分
        SQL &= " " & QueryWrapper.AddForUpdate(True)
        Return SQL
    End Function
#End Region
    'A-CUST20251104↑ '2026/03/16

#End Region

#Region "パラメータ"

    Private Const PARAMETER_MARKER As String = "?"

#Region "構造体"

#Region "FieldBuilder項目データ"


    'CE81 FieldBuilder属性情報テーブル  ----------------------------------------------------------------------
    Private Structure update_CUSCE81             'FieldBuilder属性情報テーブル
        Dim detaShurui As Integer                'データ種類
        Dim meisaiKubun As Integer               '明細区分
        Dim koumokuNumber As Integer             '項目№
        Dim zokusei As Integer                   '属性
        Dim keta_Seisuu As Integer               '桁(整数部桁)
        Dim keta_Shousuu As Integer              '桁(小数以下桁)
        Dim koumokuMei As String                 '項目名
        Dim kousinNumber As Integer              '更新番号
        'A-CUST20260501↓
        Dim dispFlg As Integer                   '画面表示
        Dim dispRow As Integer　　　             '行位置
        Dim dispCol As Integer　　　             '表示順
        Dim keta_Grid As Integer                 '表示桁数
        'A-CUST20260501↑
    End Structure
    Private _updateCUSCE81 As update_CUSCE81
    Private _updateCUSCE81Back(29) As update_CUSCE81

#End Region

#End Region

#Region "パラメータセット"

    'Private Function SetParameterMaster(ByRef paramInfo As ParamInfoList, ByVal checkMaster() As String, ByVal checkColorNumber As Integer, ByVal keyNamber() As String) As ParamInfoList

    '    Dim koumokuName(29) As String
    '    Dim husenName As String = ""
    '    Dim lastValue(19) As Object

    '    For i As Integer = 0 To 29
    '        koumokuName(i) = "M" & Format(CInt(_selectMasterId), "000") & "K" & Format(i + 1, "000")
    '        If checkMaster(i) = "" Then
    '            lastValue(i) = DBNull.Value
    '        Else
    '            lastValue(i) = checkMaster(i)
    '        End If
    '        SetParam(paramInfo, koumokuName(i), DbType.String, 256, 0, 0, lastValue(i)) 'A-20160817-X1-桁数拡張
    '    Next

    '    husenName = "M" & Format(CInt(_selectMasterId), "000") & "K999"
    '    SetParam(paramInfo, husenName, DbType.Decimal, 0, 2, 0, checkColorNumber)

    '    Return paramInfo
    'End Function
    Private Function SetParameterInsertCE81(ByRef paramInfo As ParamInfoList) As ParamInfoList

        SetParam(paramInfo, "CE81001", DbType.Decimal, 0, 2, 0, _updateCUSCE81.detaShurui)                                'データ種類
        SetParam(paramInfo, "CE81002", DbType.Decimal, 0, 2, 0, _updateCUSCE81.meisaiKubun)                               '明細区分
        SetParam(paramInfo, "CE81003", DbType.Decimal, 0, 2, 0, _updateCUSCE81.koumokuNumber)                             '項目№
        SetParam(paramInfo, "CE81004", DbType.Decimal, 0, 2, 0, _updateCUSCE81.zokusei)                                   '属性
        SetParam(paramInfo, "CE81005", DbType.Decimal, 0, 3, 0, _updateCUSCE81.keta_Seisuu)                               '桁(整数部桁)          'A-20160817-X1-桁数拡張
        SetParam(paramInfo, "CE81006", DbType.Decimal, 0, 1, 0, _updateCUSCE81.keta_Shousuu)                              '桁(小数以下桁)
        SetParam(paramInfo, "CE81007", DbType.String, 20, 0, 0, _updateCUSCE81.koumokuMei)                                '項目名
        'A-CUST20260501↓
        SetParam(paramInfo, "CE81008", DbType.Decimal, 0, 2, 0, _updateCUSCE81.dispFlg)                                   '画面表示
        SetParam(paramInfo, "CE81009", DbType.Decimal, 0, 2, 0, _updateCUSCE81.dispRow)                                   '行位置
        SetParam(paramInfo, "CE81010", DbType.Decimal, 0, 2, 0, _updateCUSCE81.dispCol)                                   '表示順
        SetParam(paramInfo, "CE81011", DbType.Decimal, 0, 2, 0, _updateCUSCE81.keta_Grid)                                 '表示桁数
        'A-CUST20260501↑
        SetParam(paramInfo, "CE81999", DbType.Decimal, 0, 9, 0, _updateCUSCE81.kousinNumber)                              '更新番号

        Return paramInfo
    End Function

    Private Function SetParameterDeleteCE81(ByRef paramInfo As ParamInfoList) As ParamInfoList

        SetParam(paramInfo, "ZE001001", DbType.Decimal, 0, 2, 0, _updateCUSCE81.detaShurui)              'データ種類
        SetParam(paramInfo, "ZE001002", DbType.Decimal, 0, 2, 0, _updateCUSCE81.meisaiKubun)             '明細区分         

        Return paramInfo
    End Function


    'A-20090107_1}
    Private Sub SetParam(ByRef paramList As ParamInfoList, ByVal name As String, ByVal type As DbType, ByVal size As Integer,
                         ByVal precision As Integer, ByVal scale As Integer, ByVal value As Object)

        Dim param As New ParamInfo
        With param
            .Name = name
            .Type = type
            .Size = size                                                           '文字型
            .Precision = CType(precision, Global.System.Nullable(Of Byte))         '数字型　小数点以上
            .Scale = CType(scale, Global.System.Nullable(Of Byte))                 '数字型　小数点以下
            .Value = value
            .Direction = ParameterDirection.Input
        End With

        paramList.Add(param)
    End Sub
#End Region

#End Region


    ''' <summary>
    ''' XMLへ書き出し用データを詰める
    ''' </summary>
    ''' <param name="s">構造体</param>
    ''' <returns></returns>
    Private Function ToExtItemInfo(ByVal s As update_CUSCE81) As XmlFileWriter.ExtItemInfo
        Dim d As XmlFileWriter.ExtItemInfo

        d.タイトル = ""
        If s.koumokuMei = "" Then
            d.タイトル = "FieldBuilder" & (s.koumokuNumber + 1).ToString("00")
        Else
            d.タイトル = s.koumokuMei
        End If

        d.属性 = If(s.zokusei = 0, "0", s.zokusei.ToString())
        d.列名 = If(s.koumokuNumber + 1 <= 0, "", "K" & (s.koumokuNumber + 1).ToString("000"))
        d.桁数 = If(s.keta_Seisuu <= 0, "0", s.keta_Seisuu.ToString())
        d.小数 = If(s.keta_Shousuu <= 0, "", s.keta_Shousuu.ToString())
        'A-CUST20260501↓
        d.画面表示 = If(s.dispFlg <= 0, "", s.dispFlg.ToString())
        d.行位置 = If(s.dispRow <= 0, "", s.dispRow.ToString())
        d.表示順 = If(s.dispCol <= 0, "", s.dispCol.ToString())
        d.表示桁数 = If(s.keta_Grid <= 0, "", s.keta_Grid.ToString())
        'A-CUST20260501↑
        d.データ種類 = _データ種類
        'd.データ種類略称 = _データ種類略称  'D-CUST20251104 '2026/03/12
        d.データ種類名 = _データ種類名  'A-CUST20251104 '2026/03/12
        d.明細区分 = _明細区分
        d.明細区分名称 = _明細区分名
        Return d
    End Function


End Class

