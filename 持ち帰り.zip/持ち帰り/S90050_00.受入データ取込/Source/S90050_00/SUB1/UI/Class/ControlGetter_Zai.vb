﻿Public Class ControlGetter_Zai
    Inherits InsideJobBase
    Implements IControlGetter_Zai

    Public Sub Startup(ByVal initInfo As IDictionary, ByRef controlC001 As IDictionary) Implements IControlGetter_Zai.Startup

        Dim ZAIControlInfoGetter As IZAIControlInfoGetter = New ZAIControlInfoGetter
        controlC001 = ZAIControlInfoGetter.GetControlInfo(initInfo, IZAIControlInfoGetter.コントロール型.ZAIコントロールテーブル)

    End Sub

    Public Sub ControlGet(ByVal controlC001 As IDictionary, ByRef コントロール情報 As Myコントロール情報型) Implements IControlGetter_Zai.ControlGet

        Dim My財務コントロール情報 As New My財務コントロール情報型
        My財務コントロール情報.InitializeZAIC001(controlC001, コントロール情報)

    End Sub

End Class
