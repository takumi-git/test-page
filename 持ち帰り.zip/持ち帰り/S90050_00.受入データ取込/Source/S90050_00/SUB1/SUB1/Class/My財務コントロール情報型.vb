﻿Public Class My財務コントロール情報型

#Region "■変数■"

    Private _Myコントロール情報 As Myコントロール情報型

    Private _財務オプション区分 As ZAI.LIB.ControlInfoC001.オプション区分型
    Private _財務支払機能 As ZAI.LIB.ControlInfoC001.支払機能管理型
    Private _財務プロジェクト機能 As ZAI.LIB.ControlInfoC001.プロジェクト機能型     'A-2009/12/18_Ver7.40_PRO
    Private _財務伝票承認 As ZAI.LIB.ControlInfoC001.伝票承認型                     'A-2010/09/13_Ver7.4X_ZAISHONIN

#End Region

#Region "■コンストラクタ■"

    Public Sub New()

        _Myコントロール情報 = New Myコントロール情報型

        _財務オプション区分 = New ZAI.LIB.ControlInfoC001.オプション区分型
        _財務支払機能 = New ZAI.LIB.ControlInfoC001.支払機能管理型
        _財務プロジェクト機能 = New ZAI.LIB.ControlInfoC001.プロジェクト機能型      'A-2009/12/18_Ver7.40_PRO
        _財務伝票承認 = New ZAI.LIB.ControlInfoC001.伝票承認型                      'A-2010/09/13_Ver7.4X_ZAISHONIN

    End Sub

#End Region

#Region "■メソッド■"

    ''' <summary>
    ''' 財務コントロールテーブルの初期化
    ''' </summary>
    ''' <param name="controlInfo">財務コントロールテーブル情報</param>
    ''' <param name="コントロール情報">コントロール情報</param>
    ''' <remarks></remarks>
    Public Sub InitializeZAIC001(ByRef controlInfo As IDictionary, ByRef コントロール情報 As Myコントロール情報型)

        _Myコントロール情報 = コントロール情報

        _財務オプション区分.Initialize(controlInfo)
        _財務支払機能.Initialize(controlInfo)
        _財務プロジェクト機能.Initialize(controlInfo)           'A-2009/12/18_Ver7.40_PRO
        _財務伝票承認.Initialize(controlInfo)                   'A-2010/09/13_Ver7.4X_ZAISHONIN

        '各種設定を退避
        _Myコントロール情報.会計債務管理 = 会計債務管理
        _Myコントロール情報.会計債務残消込管理 = 会計債務残消込管理
        _Myコントロール情報.会計原価振替処理 = 会計原価振替処理 'A-2009/12/18_Ver7.40_PRO
        _Myコントロール情報.会計伝票承認機能 = 会計伝票承認機能 'A-2010/09/13_Ver7.4X_ZAISHONIN

        コントロール情報 = _Myコントロール情報

    End Sub

#End Region

#Region "プロパティ"

    Public ReadOnly Property 会計債務管理() As Boolean
        Get
            If _財務オプション区分.債務管理オプション = ZAI.LIB.ControlInfoC001.オプション区分定義型.オプション区分型00.行う Then
                Return True
            Else
                Return False
            End If
        End Get
    End Property

    Public ReadOnly Property 会計債務残消込管理() As Boolean
        Get
            If _財務支払機能.債務残消込管理 = ZAI.LIB.ControlInfoC001.債務機能管理定義型.管理区分型.行う Then
                Return True
            Else
                Return False
            End If
        End Get
    End Property

    Public ReadOnly Property 会計原価管理システム連携() As Boolean  'A-2009/12/18_Ver7.40_PRO
        Get
            If _財務オプション区分.原価管理システム連携 = ZAI.LIB.ControlInfoC001.オプション区分定義型.オプション区分型00.行う Then
                Return True
            Else
                Return False
            End If
        End Get
    End Property

    Public ReadOnly Property 会計原価振替処理() As Boolean  'A-2009/12/18_Ver7.40_PRO
        Get
            If 会計原価管理システム連携 = False Then
                Return False
            End If

            If _財務プロジェクト機能.原価振替処理 = ZAI.LIB.ControlInfoC001.プロジェクト機能定義型.管理区分型.行う Then
                Return True
            Else
                Return False
            End If
        End Get
    End Property

    Public ReadOnly Property 会計伝票承認機能() As Boolean  'A-2010/09/13_Ver7.4X_ZAISHONIN
        Get
            If _財務伝票承認.伝票承認機能使用区分 = ZAI.LIB.ControlInfoC001.伝票承認定義型.使用区分型.使用する AndAlso _
               _財務伝票承認.販売データ仕訳作成承認機能使用区分 = ZAI.LIB.ControlInfoC001.伝票承認定義型.使用区分型.使用する Then
                Return True
            Else
                Return False
            End If
        End Get
    End Property
#End Region

End Class
