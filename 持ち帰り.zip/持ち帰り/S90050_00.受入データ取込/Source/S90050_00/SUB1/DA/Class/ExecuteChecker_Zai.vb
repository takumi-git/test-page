﻿Public Class ExecuteChecker_Zai
    Inherits InsideDataHandlerBase
    Implements IExecuteChecker_Zai

#Region "プロパティ"

    Private _myImportParam As S90050_00.ImportParam
    Public Property MyImportParam() As S90050_00.ImportParam Implements IExecuteChecker_Zai.MyImportParam
        Get
            Return _myImportParam
        End Get
        Set(ByVal value As ImportParam)
            _myImportParam = value
        End Set
    End Property

    Private _result_Han As TextFileImport.IResult
    Public Property result_Han() As TextFileImport.IResult Implements IExecuteChecker_Zai.result_Han
        Get
            Return _result_Han
        End Get
        Set(ByVal value As Foundation.TextFileImport.IResult)
            _result_Han = value
        End Set
    End Property

#End Region

#Region "変数"

#End Region

#Region "コンストラクタ"

    Public Sub New()

        _result_Han = New TextFileImport.ResultBase

    End Sub

#End Region

#Region "継承メソッド"

    Public Function DoExecuteCheck(ByRef chkctrl As IExecuteControlerForUpdate, _
                                   ByRef executeCheckInfo As IExecuteCheckInfo) As ExecuteCheckResult Implements IExecuteChecker_Zai.DoExecuteCheck

        Dim executeResult As ExecuteCheck.DataAccess.ExecuteCheckResult

        '---------------------------------------------
        '   排他制御／プログラム独自チェック
        '---------------------------------------------
        Dim checkExecution_Han As CheckExecution = New CheckExecution
        checkExecution_Han.MyImportParam = _myImportParam

        Dim checkExecution_Zai As CheckExecution_Zai = New CheckExecution_Zai

        Select Case chkctrl.StartExecution(executeCheckInfo, CheckCondition.通常チェック, checkExecution_Han, checkExecution_Zai)
            Case ExecuteCheckResult.成功
                executeResult = ExecuteCheckResult.成功

            Case ExecuteCheckResult.排他エラー
                executeResult = ExecuteCheckResult.排他エラー

            Case ExecuteCheckResult.アプリケーションエラー
                executeResult = ExecuteCheckResult.アプリケーションエラー
                _result_Han = checkExecution_Han.Result

        End Select

        Return executeResult
    End Function

#End Region

End Class
