﻿Public Class ControlGetter_Zai
    Inherits InsideDataHandlerBase
    Implements IControlGetter_Zai

    Public Sub Startup(ByVal connection As DbConnection, ByVal initInfo As IDictionary, ByRef コントロール情報 As Myコントロール情報型) Implements IControlGetter_Zai.Startup

        Dim ZAIcontrolInfoReader As ZAI.LIB.ControlInfo.DataAccess.IZAIControlReader = New ZAI.LIB.ControlInfo.DataAccess.ZAIControlReader
        ZAIcontrolInfoReader.Initialize(Me)
        ZAIcontrolInfoReader.GetControlInfo(connection, initInfo, ZAI.LIB.ControlInfo.DataAccess.IZAIControlReader.コントロール型.ZAIコントロールテーブル)
        Dim ZAIcontrolInfoGetter As ZAI.LIB.ControlInfo.DataAccess.IZAIControlInfoGetter = New ZAI.LIB.ControlInfo.DataAccess.ZAIControlInfoGetter
        Dim controlInfoZAIC001 As IDictionary = ZAIcontrolInfoGetter.GetControlInfo(initInfo, ZAI.LIB.ControlInfo.DataAccess.IZAIControlInfoGetter.コントロール型.ZAIコントロールテーブル)
        ControlGet(controlInfoZAIC001, コントロール情報)

    End Sub

    Public Sub ControlGet(ByVal controlC001 As IDictionary, ByRef コントロール情報 As Myコントロール情報型) Implements IControlGetter_Zai.ControlGet

        Dim My財務コントロール情報 As New My財務コントロール情報型
        My財務コントロール情報.InitializeZAIC001(controlC001, コントロール情報)

    End Sub

End Class
