﻿Public Class LibChecker_Zai
    Inherits InsideDataHandlerBase
    Implements ILibChecker_Zai

#Region "プロパティ"

    Private _myImportParam As S90050_00.ImportParam
    Public Property MyImportParam() As S90050_00.ImportParam Implements ILibChecker_Zai.MyImportParam
        Get
            Return _myImportParam
        End Get
        Set(ByVal value As S90050_00.ImportParam)
            _myImportParam = value
        End Set
    End Property

#End Region

#Region "変数"

    Private _会計日付情報 As ZAI.LIB.DateInfoC011.IDateInfoGetter

#End Region

#Region "コンストラクタ"

    Public Sub New()

        _会計日付情報 = New ZAI.LIB.DateInfoC011.DateInfoGetter

    End Sub

#End Region

#Region "継承メソッド"

    Public Function DoDateCheck(ByRef transaction As DbTransaction, _
                                ByVal 対象日付 As String) As ILibChecker_Zai.会計チェック結果型 Implements ILibChecker_Zai.DoDateCheck

        Dim result As ILibChecker_Zai.会計チェック結果型

        '----------------------------------------
        '   対象年月度チェック
        '----------------------------------------
        InitializeZAIDateInfo(transaction)
        result = Check対象日付(対象日付)

        Return result
    End Function

#End Region

#Region "内部メソッド"

    ''' <summary>
    ''' 会計日付情報取得部品の初期処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub InitializeZAIDateInfo(ByVal transaction As DbTransaction)

        '会計日付情報取得
        Dim dateReader As ZAI.LIB.DateInfo.DataAccess.IZAIDateReader
        dateReader = CommonFactory.CreateInstance(Of ZAI.LIB.DateInfo.DataAccess.IZAIDateReader)(Me, GetType(ZAI.LIB.DateInfo.DataAccess.ZAIDateReader))
        dateReader.Initialize(Me)

        Dim dateInfo As ZAI.LIB.DateInfoC011.DateInfoData = New ZAI.LIB.DateInfoC011.DateInfoData
        dateInfo = dateReader.CreateDateInfo(transaction)

        _会計日付情報 = CommonFactory.CreateInstance(Of ZAI.LIB.DateInfoC011.IDateInfoGetter)(Me, GetType(ZAI.LIB.DateInfoC011.DateInfoGetter))
        _会計日付情報.SetData(dateInfo)

    End Sub

#End Region

#Region "各種チェック処理"

    ''' <summary>
    ''' 対象日付チェック
    ''' </summary>
    ''' <param name="denpyoYMD"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function Check対象日付(ByVal denpyoYMD As String) As ILibChecker_Zai.会計チェック結果型

        Dim ymd As String = denpyoYMD       '年月日
        Dim gaitoki As Integer              '該当期
        Dim kssanki As Integer              '決算期
        Dim kaikeiNend As String = ""       '会計年度
        Dim mm As Integer                   '該当月数
        Dim hygn As String = ""             '年月表現
        Dim karjm As Integer                '仮締区分
        Dim hniF As String = ""             '対象年月のFrom年月日
        Dim hniT As String = ""             '対象年月のTo年月日
        Dim kssanSiwake As Integer          '決算仕訳入力区分
        Dim sakjoMM As Integer              '明細削除月数

        If _会計日付情報.GetByYMD(ymd, gaitoki, kssanki, kaikeiNend, mm, hygn, karjm, hniF, hniT, kssanSiwake, sakjoMM) = False Then
            Return ILibChecker_Zai.会計チェック結果型.日付範囲エラー
        End If

        Select Case gaitoki
            Case 0, 1
                '当期／翌期
            Case Else
                '以外
                Return ILibChecker_Zai.会計チェック結果型.日付範囲エラー
        End Select

        Return ILibChecker_Zai.会計チェック結果型.成功

    End Function

#End Region

End Class
