﻿Public Class CheckExecution_Zai
    Inherits ZAI.LIB.ExecuteCheck.DetailCheckZAI

End Class
