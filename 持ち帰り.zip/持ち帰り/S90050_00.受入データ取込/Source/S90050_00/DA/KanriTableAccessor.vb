﻿Public Class KanriTableAccessor
    Inherits KanriTableAccessorBase

    Protected Overrides Function Edit取込条件(ByVal importParam As Foundation.TextFileImport.IImportParam _
                                              ) As String
        Dim 取込条件 As String = ""
        Dim param As S90050_00.ImportParam = CType(importParam, S90050_00.ImportParam)
        Call TextFileImportLib.SetKeywordValue(取込条件, "処理連番の採番方法", param.処理連番採番.ToString)
        取込条件 &= Space(1)
        Call TextFileImportLib.SetKeywordValue(取込条件, "伝票№の採番方法", param.伝票番号採番.ToString)

        'A-2009/12/18_Ver7.40_LOT
        If Is画面条件有効判定_ロットNo採番(param) = True Then
            取込条件 &= Space(1)
            Call TextFileImportLib.SetKeywordValue(取込条件, "ロット№の採番方法", param.ロットNo採番.ToString)
        End If
        'A-2009/12/18_Ver7.40_LOT

        'A-20120315_3↓
        取込条件 &= Space(1)
        Call TextFileImportLib.SetKeywordValue(取込条件, "発注残以上のデータ取込チェック", CType(param.発注残以上のデータ取込チェック, String))
        取込条件 &= Space(1)
        Call TextFileImportLib.SetKeywordValue(取込条件, "完納済みデータ取込チェック", CType(param.完納済みデータ取込チェック, String))
        'A-20120315_3↑

        Return 取込条件

    End Function

    Protected Overrides Function Edit更新方法(ByVal importParam As OSK.X1.Foundation.TextFileImport.IImportParam
                                 ) As String    'X1変換Tool-20170508
        Dim 更新方法 As String = ""
        Dim param As S90050_00.ImportParam = CType(importParam, S90050_00.ImportParam)
        Call TextFileImportLib.SetKeywordValue(更新方法, "同一処理連番存在時は上書き", CType(param.同一処理連番存在時は上書き, String))
        Return 更新方法
    End Function

    Private Function Is画面条件有効判定_ロットNo採番(ByVal param As S90050_00.ImportParam) As Boolean  'A-2009/12/18_Ver7.40_LOT

        If param.Myコントロール情報.Myオプション区分.ロット管理 = False Then
            Return False
        End If

        'If param.Myコントロール情報.Myロット管理.ロットNo採番方法 <> ロット管理定義型.ロットNo採番方法型.連番 Then
        '    Return False
        'End If

        Return True
    End Function

End Class
