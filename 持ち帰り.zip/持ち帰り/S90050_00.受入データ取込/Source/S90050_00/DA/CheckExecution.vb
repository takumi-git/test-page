﻿''' <summary>
''' 実行可否チェック
''' </summary>
''' <remarks></remarks>
Public Class CheckExecution
    Inherits OSK.X1.HAN.LIB.ExecuteCheck.DetailCheckHAN    'X1変換Tool-20170508

#Region "■プロパティ■"

    Private _result As TextFileImport.ResultBase = New TextFileImport.ResultBase
    Public Property Result() As TextFileImport.ResultBase
        Get
            Return _result
        End Get
        Set(ByVal value As TextFileImport.ResultBase)
            _result = value
        End Set
    End Property

    Private _myImportParam As S90050_00.ImportParam
    Public Property MyImportParam() As S90050_00.ImportParam
        Get
            Return _myImportParam
        End Get
        Set(ByVal value As S90050_00.ImportParam)
            _myImportParam = value
        End Set
    End Property
#End Region

#Region "■継承メソッド■"

    Public Overrides Function CheckApplicationError(ByVal session As Foundation.ExecuteCheck.DataAccess.SessionManager, ByRef checkInfo As Foundation.ExecuteCheck.IExecuteCheckInfo) As Boolean

        Me.Result.code = ResultType.成功    'A-2008/07/18_Ver7.30_SAIMU

        '拡張項目定義.更新番号チェック
        If CheckHANZ030更新番号(session) = False Then Return False

        Return True
    End Function

#End Region

#Region "■内部メソッド■"

    Private Function CheckHANZ030更新番号(ByVal session As Foundation.ExecuteCheck.DataAccess.SessionManager) As Boolean

        '仕入伝票
        'If MyImportParam.Myコントロール情報.Myオプション区分.拡張項目_仕入伝票 = True Then 'D-20161117_1
        If MyImportParam.拡張項目情報_仕入伝票_使用 = True Then                             'A-20161117_1
            Dim expandItemReader As SEI.LIB.ExpandItemControl.DataAccess.ISEIExpandItemReader
            expandItemReader = CMN.LIB.PartReplacement.CommonFactory.CreateInstance(Of SEI.LIB.ExpandItemControl.DataAccess.ISEIExpandItemReader)(Me, GetType(SEI.LIB.ExpandItemControl.DataAccess.SEIExpandItemReader))
            With expandItemReader
                .Initialize(Me)
                Dim 更新番号 As Long = .GetExpandItemUpdateNumber(session.Transaction, SEI.LIB.ExpandItemControl.I拡張項目定義型.SEI拡張項目型.仕入伝票)
                If MyImportParam.拡張項目情報_仕入伝票_更新番号 <> 更新番号 Then
                    Me.Result.code = ResultType.他で更新済
                    Me.Result.TableID = "HANZ030"
                    Return False
                End If
            End With
        End If

        '仕入明細
        'If MyImportParam.Myコントロール情報.Myオプション区分.拡張項目_仕入明細 = True Then 'D-20161117_1
        If MyImportParam.拡張項目情報_仕入明細_使用 = True Then                             'A-20161117_1
            Dim expandItemReader As SEI.LIB.ExpandItemControl.DataAccess.ISEIExpandItemReader
            expandItemReader = CMN.LIB.PartReplacement.CommonFactory.CreateInstance(Of SEI.LIB.ExpandItemControl.DataAccess.ISEIExpandItemReader)(Me, GetType(SEI.LIB.ExpandItemControl.DataAccess.SEIExpandItemReader))
            With expandItemReader
                .Initialize(Me)
                Dim 更新番号 As Long = .GetExpandItemUpdateNumber(session.Transaction, SEI.LIB.ExpandItemControl.I拡張項目定義型.SEI拡張項目型.仕入明細)
                If MyImportParam.拡張項目情報_仕入明細_更新番号 <> 更新番号 Then
                    Me.Result.code = ResultType.他で更新済
                    Me.Result.TableID = "HANZ030"
                    Return False
                End If
            End With
        End If

        'A-20161117_1↓
        '入荷伝票
        If MyImportParam.拡張項目情報_入荷伝票_使用 = True Then
            Dim expandItemReader As SEI.LIB.ExpandItemControl.DataAccess.ISEIExpandItemReader
            expandItemReader = CMN.LIB.PartReplacement.CommonFactory.CreateInstance(Of SEI.LIB.ExpandItemControl.DataAccess.ISEIExpandItemReader)(Me, GetType(SEI.LIB.ExpandItemControl.DataAccess.SEIExpandItemReader))
            With expandItemReader
                .Initialize(Me)
                Dim 更新番号 As Long = .GetExpandItemUpdateNumber(session.Transaction, SEI.LIB.ExpandItemControl.I拡張項目定義型.SEI拡張項目型.入荷伝票)
                If MyImportParam.拡張項目情報_入荷伝票_更新番号 <> 更新番号 Then
                    Me.Result.code = ResultType.他で更新済
                    Me.Result.TableID = "HANZ030"
                    Return False
                End If
            End With
        End If

        '入荷明細
        If MyImportParam.拡張項目情報_入荷明細_使用 = True Then
            Dim expandItemReader As SEI.LIB.ExpandItemControl.DataAccess.ISEIExpandItemReader
            expandItemReader = CMN.LIB.PartReplacement.CommonFactory.CreateInstance(Of SEI.LIB.ExpandItemControl.DataAccess.ISEIExpandItemReader)(Me, GetType(SEI.LIB.ExpandItemControl.DataAccess.SEIExpandItemReader))
            With expandItemReader
                .Initialize(Me)
                Dim 更新番号 As Long = .GetExpandItemUpdateNumber(session.Transaction, SEI.LIB.ExpandItemControl.I拡張項目定義型.SEI拡張項目型.入荷明細)
                If MyImportParam.拡張項目情報_入荷明細_更新番号 <> 更新番号 Then
                    Me.Result.code = ResultType.他で更新済
                    Me.Result.TableID = "HANZ030"
                    Return False
                End If
            End With
        End If
        'A-20161117_1↑

        Return True
    End Function

#End Region

End Class
