﻿''' <summary>
''' データ更新用インターフェース
''' </summary>
''' <remarks></remarks>
Public Class MyDataUpdater
    Inherits OSK.X1.Foundation.DataAccess.InsideDataHandlerBase    'X1変換Tool-20170508

    Private _queryMaker As IMyQueryMaker

#Region "■初期処理関連■"

    Public Overloads Sub Initialize(ByRef base As OSK.X1.Foundation.IBase,
                                    ByVal myImportParam As S90050_00.ImportParam
                         )    'X1変換Tool-20170508

        MyBase.Initialize(CType(base, OSK.X1.Foundation.DataAccess.IDataHandler))    'X1変換Tool-20170508
        _queryMaker = CType(TextFileImportDALib.CreateQueryMaker(base), IMyQueryMaker)
        _queryMaker.MyImportParam = myImportParam

    End Sub

#End Region

#Region "■公開メソッド■"

    ''' <summary>
    ''' 販売データ仕訳作成日付管理テーブル更新
    ''' </summary>
    ''' <param name="transaction"></param>
    ''' <param name="伝票日付"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function UpdateHANC015(ByRef transaction As DbTransaction,
                                  ByVal 伝票日付 As Integer
                    ) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        result = UpdateHANC015Impl(transaction, 伝票日付)

        Return result

    End Function

    ''' <summary>
    ''' 連番管理テーブル更新
    ''' </summary>
    ''' <param name="transaction"></param>
    ''' <param name="処理連番"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function UpdateHANC021(ByRef transaction As DbTransaction,
                                  ByVal 処理連番 As Long
                    ) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        result = UpdateHANC021Impl(transaction, 処理連番)

        Return result

    End Function

    ''' <summary>
    ''' 伝票番号管理テーブル更新
    ''' </summary>
    ''' <param name="transaction"></param>
    ''' <param name="更新データ"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function UpdateHANC022(ByRef transaction As DbTransaction,
                                  ByVal 更新データ As WorkTableUnitData
                    ) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        result = UpdateHANC022Impl(transaction, 更新データ)

        Return result

    End Function

    ''' <summary>
    ''' ロット№管理テーブル更新
    ''' </summary>
    ''' <param name="transaction"></param>
    ''' <param name="ロットNo"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function UpdateHANC023(ByRef transaction As DbTransaction,
                                  ByVal ロットNo As Decimal
                    ) As TextFileImport.IResult 'A-2009/12/18_Ver7.40_LOT

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        result = UpdateHANC023Impl(transaction, ロットNo)

        Return result

    End Function

    ''' <summary>
    ''' 仕訳ヘッダー更新
    ''' </summary>
    ''' <param name="transaction"></param>
    ''' <param name="処理連番"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function UpdateZAIR001(ByRef transaction As DbTransaction,
                                  ByVal 処理連番 As Long
                    ) As TextFileImport.IResult     'A-2008/07/18_Ver7.30_SAIMU

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        result = UpdateZAIR001Impl(transaction, 処理連番)

        Return result

    End Function

    ''' <summary>
    ''' 仮仕訳ヘッダー更新
    ''' </summary>
    ''' <param name="transaction"></param>
    ''' <param name="処理連番"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function UpdateZAIR101(ByRef transaction As DbTransaction,
                                  ByVal 処理連番 As Long
                    ) As TextFileImport.IResult     'A-2010/09/13_Ver7.4X_ZAISHONIN

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        result = UpdateZAIR101Impl(transaction, 処理連番)

        Return result

    End Function

    ''' <summary>
    ''' 取引ヘッダー登録
    ''' </summary>
    ''' <param name="transaction"></param>
    ''' <param name="更新データ"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function InsertHANR001(ByRef transaction As DbTransaction,
                                  ByVal 更新データ As S90050_00.WorkTableUnitData
                    ) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        result = InsertHANR001Impl(transaction, 更新データ)

        Return result

    End Function

    ''' <summary>
    ''' 取引明細登録
    ''' </summary>
    ''' <param name="transaction"></param>
    ''' <param name="更新データ"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function InsertHANR002(ByRef transaction As DbTransaction,
                                  ByVal 更新データ As S90050_00.WorkTableUnitData,
                                  ByVal line As Integer
                    ) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        result = InsertHANR002Impl(transaction, 更新データ, line)

        Return result

    End Function

    ''' <summary>
    ''' 受発注ヘッダー更新
    ''' </summary>
    ''' <param name="transaction"></param>
    ''' <param name="更新データ"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function UpdateHANR004(ByRef transaction As DbTransaction,
                                  ByVal 更新データ As S90050_00.WorkTableUnitData
                    ) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        result = UpdateHANR004Impl(transaction, 更新データ)

        Return result

    End Function

    ''' <summary>
    ''' 受発注明細更新
    ''' </summary>
    ''' <param name="transaction"></param>
    ''' <param name="更新データ"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function UpdateHANR005(ByRef transaction As DbTransaction,
                                  ByVal 更新データ As S90050_00.WorkTableUnitData,
                                  ByVal line As Integer
                    ) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        result = UpdateHANR005Impl(transaction, 更新データ, line)

        Return result

    End Function

    ''' <summary>
    ''' 入出荷ヘッダー登録
    ''' </summary>
    ''' <param name="transaction"></param>
    ''' <param name="更新データ"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function InsertSEIR010(ByRef transaction As DbTransaction,
                                  ByVal 更新データ As S90050_00.WorkTableUnitData
                    ) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        result = InsertSEIR010Impl(transaction, 更新データ)

        Return result

    End Function

    ''' <summary>
    ''' 入出荷明細登録
    ''' </summary>
    ''' <param name="transaction"></param>
    ''' <param name="更新データ"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function InsertSEIR011(ByRef transaction As DbTransaction,
                                  ByVal 更新データ As S90050_00.WorkTableUnitData,
                                  ByVal line As Integer
                    ) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        result = InsertSEIR011Impl(transaction, 更新データ, line)

        Return result

    End Function

    ''' <summary>
    ''' ロット明細登録
    ''' </summary>
    ''' <param name="transaction"></param>
    ''' <param name="更新データ"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function InsertSEIR008(ByRef transaction As DbTransaction,
                                  ByVal 更新データ As S90050_00.WorkTableUnitData,
                                  ByVal line As Integer
                    ) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        result = InsertSEIR008Impl(transaction, 更新データ, line)

        Return result

    End Function

    ''' <summary>
    ''' 受入索引テーブル登録
    ''' </summary>
    ''' <param name="transaction"></param>
    ''' <param name="更新データ"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function InsertSEIR114(ByRef transaction As DbTransaction,
                                  ByVal 更新データ As S90050_00.WorkTableUnitData
                    ) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        result = InsertSEIR114Impl(transaction, 更新データ)

        Return result

    End Function

    ''' <summary>
    ''' 受入索引テーブル削除
    ''' </summary>
    ''' <param name="transaction"></param>
    ''' <param name="更新データ"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function DeleteSEIR114(ByRef transaction As DbTransaction,
                                  ByVal 更新データ As S90050_00.WorkTableUnitData
                    ) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        result = DeleteSEIR114Impl(transaction, 更新データ)

        Return result

    End Function

    ''' <summary>
    ''' ロット連番管理テーブル登録
    ''' </summary>
    ''' <param name="transaction"></param>
    ''' <param name="更新データ"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function InsertSEIC056(ByRef transaction As DbTransaction,
                                  ByVal 更新データ As S90050_00.WorkTableUnitData
                    ) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        result = InsertSEIC056Impl(transaction, 更新データ)

        Return result

    End Function

    ''' <summary>
    ''' ロット連番管理テーブル更新
    ''' </summary>
    ''' <param name="transaction"></param>
    ''' <param name="更新データ"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function UpdateSEIC056(ByRef transaction As DbTransaction,
                                  ByVal 更新データ As S90050_00.WorkTableUnitData
                    ) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        result = UpdateSEIC056Impl(transaction, 更新データ)

        Return result

    End Function

    ''' <summary>
    ''' 製番マスタ更新
    ''' </summary>
    ''' <param name="transaction"></param>
    ''' <param name="更新データ"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function UpdateSEIM050(ByRef transaction As DbTransaction,
                                  ByVal 更新データ As S90050_00.WorkTableUnitData,
                                  ByVal line As Integer
                    ) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        result = UpdateSEIM050Impl(transaction, 更新データ, line)

        Return result

    End Function

    'A-20111025_3↓
    ''' <summary>
    ''' 製番マスタ更新(手入力製番用)
    ''' </summary>
    ''' <param name="transaction"></param>
    ''' <param name="更新データ"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function UpdateSEIM050_手入力製番(ByRef transaction As DbTransaction,
                                             ByVal 更新データ As S90050_00.WorkTableUnitData
                    ) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        result = UpdateSEIM050_手入力製番Impl(transaction, 更新データ)

        Return result

    End Function
    'A-20111025_3↑

    ''' <summary>
    ''' 支払予定テーブル
    ''' </summary>
    ''' <param name="transaction"></param>
    ''' <param name="更新データ"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function InsertHANR031(ByRef transaction As DbTransaction,
                                  ByVal 更新データ As S90050_00.WorkTableUnitData,
                                  ByVal line As Integer
                    ) As TextFileImport.IResult     'A-2008/07/18_Ver7.30_SHIHARAI

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        result = InsertHANR031Impl(transaction, 更新データ, line)

        Return result

    End Function

    ''' <summary>
    ''' 支払予定テーブル削除
    ''' </summary>
    ''' <param name="transaction"></param>
    ''' <param name="伝票処理連番"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function DeleteHANR031(ByRef transaction As DbTransaction,
                                  ByVal 伝票処理連番 As Long
                    ) As TextFileImport.IResult     'A-2008/07/18_Ver7.30_SHIHARAI

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        result = DeleteHANR031Impl(transaction, 伝票処理連番)

        Return result

    End Function

    'A-CUST20190830↓
#Region "発注内訳更新用"
    Public Function UpdateSEIRA01(ByRef transaction As DbTransaction,
                                  ByVal 更新データ As S90050_00.WorkTableUnitData,
                                  ByVal 発注内訳残区分 As Integer
                    ) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        result = UpdateSEIRA01Impl(transaction, 更新データ, 発注内訳残区分)

        Return result

    End Function
#End Region

#Region "入出庫予定更新用"
    Public Function UpdateSEIRA02RA03(ByRef transaction As DbTransaction,
                                  ByVal 更新データ As S90050_00.WorkTableUnitData,
                                  ByVal 残区分 As Integer,
                                       ByVal 更新対象 As Integer,
                                       ByVal 番号 As Long,
                                       ByVal 行番号 As Integer,
                                       Optional ByVal line As Integer = -1
                    ) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        result = UpdateSEIRA02RA03Impl(transaction, 更新データ, 残区分, 更新対象, 番号, 行番号, line)

        Return result

    End Function
#End Region
    'A-CUST20190830↑
#End Region

#Region "■内部メソッド■"

    Private Function UpdateHANC015Impl(ByRef transaction As DbTransaction, ByVal 伝票日付 As Integer) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.UpdateHANC015(paramInfo, 伝票日付)
        Call MyBase.DataAccess.ExecuteNonQuery(transaction, query, paramInfo)
        result.Code = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508

        Return result

    End Function

    Private Function UpdateHANC021Impl(ByRef transaction As DbTransaction, ByVal 処理連番 As Long) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.UpdateHANC021(paramInfo, 処理連番)
        Call MyBase.DataAccess.ExecuteNonQuery(transaction, query, paramInfo)
        result.Code = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508

        Return result

    End Function

    Private Function UpdateHANC022Impl(ByRef transaction As DbTransaction, ByVal 更新データ As WorkTableUnitData) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.UpdateHANC022(paramInfo, 更新データ)
        Call MyBase.DataAccess.ExecuteNonQuery(transaction, query, paramInfo)
        result.Code = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508

        Return result

    End Function

    Private Function UpdateHANC023Impl(ByRef transaction As DbTransaction, ByVal ロットNo As Decimal) As TextFileImport.IResult 'A-2009/12/18_Ver7.40_LOT

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.UpdateHANC023(paramInfo, ロットNo)
        Call MyBase.DataAccess.ExecuteNonQuery(transaction, query, paramInfo)
        result.Code = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508

        Return result

    End Function

    Private Function UpdateZAIR001Impl(ByRef transaction As DbTransaction, ByVal 処理連番 As Long) As TextFileImport.IResult    'A-2008/07/18_Ver7.30_SAIMU

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.UpdateZAIR001(paramInfo, 処理連番)
        Call MyBase.DataAccess.ExecuteNonQuery(transaction, query, paramInfo)
        result.Code = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508

        Return result

    End Function

    Private Function UpdateZAIR101Impl(ByRef transaction As DbTransaction, ByVal 処理連番 As Long) As TextFileImport.IResult    'A-2010/09/13_Ver7.4X_ZAISHONIN

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.UpdateZAIR101(paramInfo, 処理連番)
        Call MyBase.DataAccess.ExecuteNonQuery(transaction, query, paramInfo)
        result.Code = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508

        Return result

    End Function

    Private Function InsertHANR001Impl(ByRef transaction As DbTransaction,
                                       ByVal 更新データ As S90050_00.WorkTableUnitData) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.InsertHANR001(paramInfo, 更新データ)
        Call MyBase.DataAccess.ExecuteNonQuery(transaction, query, paramInfo)
        result.Code = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508

        Return result

    End Function

    Private Function InsertHANR002Impl(ByRef transaction As DbTransaction,
                                       ByVal 更新データ As S90050_00.WorkTableUnitData,
                                       ByVal line As Integer) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.InsertHANR002(paramInfo, 更新データ, line)
        Call MyBase.DataAccess.ExecuteNonQuery(transaction, query, paramInfo)
        result.Code = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508

        Return result

    End Function

    Private Function UpdateHANR004Impl(ByRef transaction As DbTransaction,
                                       ByVal 更新データ As S90050_00.WorkTableUnitData) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.UpdateHANR004(paramInfo, 更新データ)
        Call MyBase.DataAccess.ExecuteNonQuery(transaction, query, paramInfo)
        result.Code = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508

        Return result

    End Function

    Private Function UpdateHANR005Impl(ByRef transaction As DbTransaction,
                                       ByVal 更新データ As S90050_00.WorkTableUnitData,
                                       ByVal line As Integer) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.UpdateHANR005(paramInfo, 更新データ, line)
        Call MyBase.DataAccess.ExecuteNonQuery(transaction, query, paramInfo)
        result.Code = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508

        Return result

    End Function

    Private Function InsertSEIR010Impl(ByRef transaction As DbTransaction,
                                       ByVal 更新データ As S90050_00.WorkTableUnitData) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.InsertSEIR010(paramInfo, 更新データ)
        Call MyBase.DataAccess.ExecuteNonQuery(transaction, query, paramInfo)
        result.Code = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508

        Return result

    End Function

    Private Function InsertSEIR011Impl(ByRef transaction As DbTransaction,
                                       ByVal 更新データ As S90050_00.WorkTableUnitData,
                                       ByVal line As Integer) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.InsertSEIR011(paramInfo, 更新データ, line)
        Call MyBase.DataAccess.ExecuteNonQuery(transaction, query, paramInfo)
        result.Code = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508

        Return result

    End Function

    Private Function InsertSEIR008Impl(ByRef transaction As DbTransaction,
                                       ByVal 更新データ As S90050_00.WorkTableUnitData,
                                       ByVal line As Integer) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.InsertSEIR008(paramInfo, 更新データ, line)
        Call MyBase.DataAccess.ExecuteNonQuery(transaction, query, paramInfo)
        result.Code = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508

        Return result

    End Function

    Private Function InsertSEIR114Impl(ByRef transaction As DbTransaction,
                                       ByVal 更新データ As S90050_00.WorkTableUnitData) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.InsertSEIR114(paramInfo, 更新データ)
        Call MyBase.DataAccess.ExecuteNonQuery(transaction, query, paramInfo)
        result.Code = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508

        Return result

    End Function

    Private Function DeleteSEIR114Impl(ByRef transaction As DbTransaction,
                                       ByVal 更新データ As S90050_00.WorkTableUnitData) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.DeleteSEIR114(paramInfo, 更新データ)
        Call MyBase.DataAccess.ExecuteNonQuery(transaction, query, paramInfo)
        result.Code = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508

        Return result

    End Function

    Private Function InsertSEIC056Impl(ByRef transaction As DbTransaction,
                                       ByVal 更新データ As S90050_00.WorkTableUnitData) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.InsertSEIC056(paramInfo, 更新データ)
        Call MyBase.DataAccess.ExecuteNonQuery(transaction, query, paramInfo)
        result.Code = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508

        Return result

    End Function

    Private Function UpdateSEIC056Impl(ByRef transaction As DbTransaction,
                                       ByVal 更新データ As S90050_00.WorkTableUnitData) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.UpdateSEIC056(paramInfo, 更新データ)
        Call MyBase.DataAccess.ExecuteNonQuery(transaction, query, paramInfo)
        result.Code = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508

        Return result

    End Function

    Private Function UpdateSEIM050Impl(ByRef transaction As DbTransaction,
                                       ByVal 更新データ As S90050_00.WorkTableUnitData,
                                       ByVal line As Integer) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.UpdateSEIM050(paramInfo, 更新データ, line)
        Call MyBase.DataAccess.ExecuteNonQuery(transaction, query, paramInfo)
        result.Code = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508

        Return result

    End Function

    'A-20111025_3↓
    Private Function UpdateSEIM050_手入力製番Impl(ByRef transaction As DbTransaction,
                                                  ByVal 更新データ As S90050_00.WorkTableUnitData) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.UpdateSEIM050_手入力製番(paramInfo, 更新データ)
        Call MyBase.DataAccess.ExecuteNonQuery(transaction, query, paramInfo)
        result.Code = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508

        Return result

    End Function
    'A-20111025_3↑

    Private Function InsertHANR031Impl(ByRef transaction As DbTransaction,
                                       ByVal 更新データ As S90050_00.WorkTableUnitData,
                                       ByVal line As Integer) As TextFileImport.IResult     'A-2008/07/18_Ver7.30_SHIHARAI

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.InsertHANR031(paramInfo, 更新データ, line)
        Call MyBase.DataAccess.ExecuteNonQuery(transaction, query, paramInfo)
        result.Code = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508

        Return result

    End Function

    Private Function DeleteHANR031Impl(ByRef transaction As DbTransaction, ByVal 伝票処理連番 As Long) As TextFileImport.IResult    'A-2008/07/18_Ver7.30_SHIHARAI

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.DeleteHANR031(paramInfo, 伝票処理連番)
        Call MyBase.DataAccess.ExecuteNonQuery(transaction, query, paramInfo)
        result.Code = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508

        Return result

    End Function

    'A-CUST20190830↓
    Public Function UpdateHANW091(ByRef transaction As DbTransaction,
                          ByVal 更新データ As String,
                          ByVal 行番号 As Integer,
                          ByVal 分割コード As String
            ) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        result = UpdateHANW091Impl(transaction, 更新データ, 行番号, 分割コード)

        Return result

    End Function

    Public Function UpdateHANC020(ByRef transaction As DbTransaction,
                              ByVal ImportParam As S90050_00.ImportParam
                ) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        result = UpdateHANC020Impl(transaction, ImportParam)

        Return result

    End Function

    Private Function UpdateHANW091Impl(ByRef transaction As DbTransaction,
                                      ByVal 更新データ As String,
                                      ByVal 行番号 As Integer,
                                      ByVal 分割キー As String
                                      ) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20191106
        Dim query As String = _queryMaker.UpdateHANW091(paramInfo, 更新データ, 行番号, 分割キー)
        Call MyBase.DataAccess.ExecuteNonQuery(transaction, query, paramInfo)
        result.Code = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20191106

        Return result

    End Function

    Private Function UpdateHANC020Impl(ByRef transaction As DbTransaction, ByVal ImportParam As S90050_00.ImportParam) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20191106
        Dim query As String = _queryMaker.UpdateHANC020(paramInfo, ImportParam)

        Try
            MyBase.DataAccess.SetLockTimeOut(transaction, 0)
            Call MyBase.DataAccess.ExecuteNonQuery(transaction, query, paramInfo)

        Catch ex As OSK.X1.DataAccess.DBLockException    'X1変換Tool-20191106

        Catch ex As Exception

        End Try
        result.Code = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20191106

        Return result

    End Function

#Region "発注内訳更新用"
    Private Function UpdateSEIRA01Impl(ByRef transaction As DbTransaction,
                                       ByVal 更新データ As S90050_00.WorkTableUnitData,
                                       ByVal 発注内訳残区分 As Integer) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20191106
        Dim query As String = _queryMaker.UpdateSEIRA01(paramInfo, 更新データ, 発注内訳残区分)
        Call MyBase.DataAccess.ExecuteNonQuery(transaction, query, paramInfo)
        result.Code = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20191106

        Return result

    End Function
#End Region

#Region "入出庫予定更新用"
    Private Function UpdateSEIRA02RA03Impl(ByRef transaction As DbTransaction,
                                       ByVal 更新データ As S90050_00.WorkTableUnitData,
                                       ByVal 残区分 As Integer,
                                       ByVal 更新対象 As Integer,
                                       ByVal 番号 As Long,
                                       ByVal 行番号 As Integer,
                                       ByVal line As Integer) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20191106
        Dim query As String
        If 更新対象 = 0 Then
            query = _queryMaker.UpdateSEIRA02(paramInfo, 更新データ, 残区分, 番号)
        Else
            query = _queryMaker.UpdateSEIRA03(paramInfo, 更新データ, 残区分, 番号, 行番号, line)
        End If

        Call MyBase.DataAccess.ExecuteNonQuery(transaction, query, paramInfo)
        result.Code = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20191106

        Return result

    End Function
#End Region
    'A-CUST20190830↑

#End Region

End Class
