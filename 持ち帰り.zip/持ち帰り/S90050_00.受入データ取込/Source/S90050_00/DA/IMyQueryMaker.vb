﻿Public Interface IMyQueryMaker
    Inherits IQueryMaker

    Property MyImportParam() As S90050_00.ImportParam

    Function SelectHANC015UpdateLock(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                     ByVal 伝票日付 As Integer
             ) As String    'X1変換Tool-20170508

    Function SelectSEIC056PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                     ByVal 管理区分 As Integer,
                                     ByVal 連番コード As String
             ) As String    'X1変換Tool-20170508

    Function SelectHANC021PrimaryKey() As String

    Function SelectHANC022PrimaryKey() As String

    Function SelectHANC023PrimaryKey() As String    'A-2009/12/18_Ver7.40_LOT

    Function SelectHANM002PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                     ByVal 仕入先コード As String
             ) As String    'X1変換Tool-20170508

    Function SelectHANM003PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                     ByVal 商品コード As String
             ) As String    'X1変換Tool-20170508

    Function SelectHANM005PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                     ByVal 担当者コード As String
             ) As String    'X1変換Tool-20170508

    Function SelectHANM006PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                     ByVal 倉庫コード As String
             ) As String    'X1変換Tool-20170508

    Function SelectHANM008PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                     ByVal 備考コード As String
             ) As String    'X1変換Tool-20170508

    Function SelectHANM009PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                     ByVal 摘要コード As String
             ) As String    'X1変換Tool-20170508

    Function SelectHANM010PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                 ByVal マスター区分 As Integer,
                                 ByVal 分類種別番号 As Integer,
                                 ByVal 分類コード As String
            ) As String     'A-2008/07/18_Ver7.30_GENKA    'X1変換Tool-20170508

    Function SelectHANM015PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                     ByVal 部門コード As String
             ) As String    'X1変換Tool-20170508

    Function SelectHANM021PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                     ByVal 内訳種別 As Integer,
                                     ByVal 内訳コード As String
             ) As String    'A-2009/12/18_Ver7.40_UCHIWAKE    'X1変換Tool-20170508

    Function SelectHANM023PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                     ByVal 読込キー As ProgramLib.商品内訳マスター型
             ) As String    'A-2009/12/18_Ver7.40_UCHIWAKE    'X1変換Tool-20170508

    Function SelectHANM031PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                     ByVal 参照定義コード As String,
                                     ByVal コード As String
             ) As String    'X1変換Tool-20170508

    Function SelectHANM036PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                     ByVal 営業所コード As String
             ) As String    'X1変換Tool-20170508

    Function SelectHANM040PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                     ByVal 原価集計メインコード As String,
                                     ByVal 原価集計サブコード As String
             ) As String    'A-2008/07/18_Ver7.30_GENKA    'X1変換Tool-20170508

    Function SelectHANM045PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                     ByVal 読込キー As ProgramLib.ロットマスター型
             ) As String    'A-2009/12/18_Ver7.40_LOT    'X1変換Tool-20170508

    Function SelectSEIR009PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                     ByVal 商品コード As String,
                                     ByVal ロットNO As String
             ) As String    'X1変換Tool-20170508

    Function SelectSEIR010PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                     ByVal 処理連番 As Long
             ) As String    'X1変換Tool-20170508

    Function SelectSEIR010返品伝票存在(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                       ByVal 処理連番 As Long
             ) As String    'X1変換Tool-20170508

    Function SelectSEIR055PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                     ByVal 手配番号 As Long
             ) As String    'X1変換Tool-20170508

    Function SelectSEIR055前後工程取得(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                       ByVal 手配管理番号 As Long,
                                       ByVal 手順番号 As Integer,
                                       ByVal 前後工程 As Integer
             ) As String    'X1変換Tool-20170508

    'A-20160324_2↓
    Function SelectSEIR055_SEIM050同時取得(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                           ByVal 手配番号 As Long
             ) As String    'X1変換Tool-20170508
    'A-20160324_2↑

    Function SelectSEIR056PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                     ByVal 手配番号 As Long,
                                     ByVal 展開順序番号 As Integer,
                                     ByVal 支給管理 As Integer
             ) As String    'X1変換Tool-20170508

    Function SelectSEIR057PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                     ByVal 手配番号 As Long) As String    'X1変換Tool-20170508

    'A-20121217_Ver7.50_2↓
    Function SelectSEIR057工程明細取得(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                       ByVal 処理連番 As Long) As String    'X1変換Tool-20170508
    'A-20121217_Ver7.50_2↑

    Function SelectSEIR057実績数量合計(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                       ByVal 手配番号 As Long) As String    'X1変換Tool-20170508

    Function SelectSEIM012PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                     ByVal 費目コード As String
             ) As String    'X1変換Tool-20170508

    Function SelectSEIM050PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                     ByVal 製番 As String
             ) As String    'X1変換Tool-20170508

    Function SelectSEIM053PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                     ByVal 工程コード As String
             ) As String    'X1変換Tool-20170508

    Function SelectHANR001PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                     ByVal 処理連番 As Long,
                                     Optional ByVal 明細区分 As Integer = -1,
                                     Optional ByVal 行番号 As Integer = -1,
                                     Optional ByVal 相手存在チェック As Boolean = False
             ) As String    'X1変換Tool-20170508

    Function SelectHANR001PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                     ByVal 取引区分 As Integer,
                                     ByVal 処理連番 As Long
             ) As String    'X1変換Tool-20170508

    Function SelectHANR001出庫伝票存在(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                       ByVal 処理連番 As Long,
                                       ByVal 取引区分 As Integer
             ) As String    'X1変換Tool-20170508

    'A-20121217_Ver7.50_1↓
    Function SelectHANR001按分済受入伝票(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                         ByVal 諸掛管理番号 As String
             ) As String    'X1変換Tool-20170508
    'A-20121217_Ver7.50_1↑

    Function SelectHANR001入庫伝票取得(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                       ByVal 処理連番 As Long
             ) As String    'X1変換Tool-20170508

    Function SelectHANR004PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                     ByVal 発注番号 As Long
             ) As String    'X1変換Tool-20170508

    Function SelectHANR005PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                     ByVal 発注番号 As Long,
                                     ByVal 発注行番号 As Integer
             ) As String    'X1変換Tool-20170508

    Function SelectHANR005関連受注(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                   ByVal 受注番号 As Long,
                                   ByVal 受注行番号 As Integer
             ) As String    'X1変換Tool-20170508

    Function SelectHANR005見込受注(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                   ByVal 発注番号 As Long
             ) As String    'X1変換Tool-20170508

    Function SelectHANR005原価集計制御情報(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                           ByVal 発注番号 As Long,
                                           ByVal 発注行番号 As Integer
             ) As String    'A-2008/07/18_Ver7.30_GENKA    'X1変換Tool-20170508

    'A-20121217_Ver7.50_2↓
    Function SelectHANR005元需要受注伝票(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                         ByVal 製番 As String,
                                         ByVal 品目 As String
             ) As String    'X1変換Tool-20170508
    'A-20121217_Ver7.50_2↑

    Function SelectSEIR008PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                     ByVal 処理連番 As Long,
                                     ByVal 行番号 As Integer
             ) As String    'X1変換Tool-20170508

    Function SelectSEIR008_自動ロット(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                      ByVal 倉庫コード As String,
                                      ByVal 商品コード As String,
                                      ByVal 期首年月 As Integer
             ) As String    'X1変換Tool-20170508

    'D-20111124_3↓
    'Function SelectSEIR008ロット明細合計(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList, _    'X1変換Tool-20170508
    '                                     ByVal 処理連番 As Long, _
    '                                     Optional ByVal 処理連番CH As Long = -1 _
    '         ) As String
    'D-20111124_3↑
    'A-20111124_3↓
    Function SelectSEIR008ロット明細合計(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                         ByVal 処理連番 As Long,
                                         Optional ByVal 処理連番CH As Long = -1,
                                         Optional ByVal 倉庫移動出庫処理連番 As Long = -1,
                                         Optional ByVal 入出庫区分 As 入出庫区分型 = 入出庫区分型.入庫
             ) As String    'X1変換Tool-20170508
    'A-20111124_3↑
    'A-20130402_2↓
    Function SelectSEIR008ロット明細_構成品(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal 処理連番 As Long,
                                            Optional ByVal 処理連番CH As Long = -1,
                                            Optional ByVal 倉庫移動出庫処理連番 As Long = -1,
                                            Optional ByVal 入出庫区分 As 入出庫区分型 = 入出庫区分型.入庫
         ) As String    'X1変換Tool-20170508

    'A-20130402_2↑

    Function SelectSEIR008出庫伝票合計(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                       ByVal 手配番号 As Long,
                                       ByVal 処理連番 As Long
             ) As String    'X1変換Tool-20170508

    Function SelectSEIR008関連ロット明細(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                         ByVal 手配番号 As Long,
                                         ByVal 展開順序番号 As Integer
             ) As String    'X1変換Tool-20170508

    Function SelectHANR031PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                     ByVal 伝票処理連番 As Long
             ) As String    'A-2008/07/18_Ver7.30_SHIHARAI    'X1変換Tool-20170508

    Function SelectHANR032PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                     ByVal 支払予定データ As ProgramLib.支払予定テーブル型
             ) As String    'A-2008/07/18_Ver7.30_SHIHARAI    'X1変換Tool-20170508

    Function SelectHANS002PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                     ByVal 仕入先コード As String,
                                     ByVal 対象年月 As Integer
             ) As String    'X1変換Tool-20170508

    'A-20121217_Ver7.50_1↓
    Function SelectSEIS005PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                     ByVal 仕入先コード As String,
                                     ByVal 対象年月 As Integer
             ) As String    'X1変換Tool-20170508
    'A-20121217_Ver7.50_1↑

    Function SelectHANZ034PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                     ByVal 明細区分 As Integer,
                                     ByVal 入力パターン番号 As String
             ) As String    'X1変換Tool-20170508

    Function SelectZAIR001UpdateLock(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                     ByVal 処理連番 As Long
            ) As String     'A-2008/07/18_Ver7.30_SAIMU    'X1変換Tool-20170508

    Function SelectZAIR101UpdateLock(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                     ByVal 処理連番 As Long
             ) As String    'A-2010/09/13_Ver7.4X_ZAISHONIN    'X1変換Tool-20170508

    Function SelectZAIR204会計債務消込チェック(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                               ByVal 処理連番 As Long
             ) As String    'A-2008/07/18_Ver7.30_SAIMU    'X1変換Tool-20170508

    Function SelectZAIR205会計支払状態チェック(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                               ByVal 処理連番 As Long
             ) As String    'A-2008/07/18_Ver7.30_SAIMU    'X1変換Tool-20170508

    Function SelectZAIR502完成原価自動振替チェック(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                                   ByVal 処理連番 As Long
             ) As String    'A-2009/12/18_Ver7.40_PRO    'X1変換Tool-20170508

    Function UpdateHANC015(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                           ByVal 伝票日付 As Integer
             ) As String    'X1変換Tool-20170508

    Function UpdateHANC021(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                           ByVal 処理連番 As Long
             ) As String    'X1変換Tool-20170508

    Function UpdateHANC022(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                           ByVal 更新データ As WorkTableUnitData
             ) As String    'X1変換Tool-20170508

    Function UpdateHANC023(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                           ByVal ロットNo As Decimal
             ) As String    'A-2009/12/18_Ver7.40_LOT    'X1変換Tool-20170508

    Function UpdateZAIR001(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                           ByVal 処理連番 As Long
            ) As String     'A-2008/07/18_Ver7.30_SAIMU    'X1変換Tool-20170508

    Function UpdateZAIR101(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                           ByVal 処理連番 As Long
             ) As String    'A-2010/09/13_Ver7.4X_ZAISHONIN    'X1変換Tool-20170508

    Function InsertHANR001(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                           ByVal 更新データ As S90050_00.WorkTableUnitData
             ) As String    'X1変換Tool-20170508

    Function InsertHANR002(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                           ByVal 更新データ As S90050_00.WorkTableUnitData,
                           ByVal line As Integer
             ) As String    'X1変換Tool-20170508

    Function InsertSEIR010(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                           ByVal 更新データ As S90050_00.WorkTableUnitData
             ) As String    'X1変換Tool-20170508

    Function InsertSEIR011(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                           ByVal 更新データ As S90050_00.WorkTableUnitData,
                           ByVal line As Integer
             ) As String    'X1変換Tool-20170508

    Function InsertSEIR008(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                           ByVal 更新データ As S90050_00.WorkTableUnitData,
                           ByVal line As Integer
             ) As String    'X1変換Tool-20170508

    Function InsertSEIR114(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                           ByVal 更新データ As S90050_00.WorkTableUnitData
             ) As String    'X1変換Tool-20170508

    Function DeleteSEIR114(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                           ByVal 更新データ As S90050_00.WorkTableUnitData
             ) As String    'X1変換Tool-20170508

    Function InsertSEIC056(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                           ByVal 更新データ As S90050_00.WorkTableUnitData
             ) As String    'X1変換Tool-20170508

    Function UpdateSEIC056(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                           ByVal 更新データ As S90050_00.WorkTableUnitData
             ) As String    'X1変換Tool-20170508

    Function UpdateSEIM050(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                           ByVal 更新データ As S90050_00.WorkTableUnitData,
                           ByVal line As Integer
             ) As String    'X1変換Tool-20170508

    'A-20111025_3↓
    Function UpdateSEIM050_手入力製番(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                      ByVal 更新データ As S90050_00.WorkTableUnitData
             ) As String    'X1変換Tool-20170508
    'A-20111025_3↑

    Function InsertHANR031(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                           ByVal 更新データ As S90050_00.WorkTableUnitData,
                           ByVal line As Integer
             ) As String    'A-2008/07/18_Ver7.30_SHIHARAI    'X1変換Tool-20170508

    Function DeleteHANR031(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                           ByVal 処理連番 As Long
             ) As String    'A-2008/07/18_Ver7.30_SHIHARAI    'X1変換Tool-20170508

    Function SelectHANW091任意項目(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                   ByVal 分割コード As String,
                                   ByVal 任意項目１ As String
             ) As String    'X1変換Tool-20170508

    'D-20150520_1↓
    'Function Select製造出庫(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList, _    'X1変換Tool-20170508
    '                        ByVal 処理連番 As Long, _
    '                        ByVal 手配番号 As Long, _
    '                        ByVal 構成品出庫区分 As Integer, _
    '                        ByVal 支給管理 As Integer _
    '         ) As String
    'D-20150520_1↑
    'A-20150520_1↓
    Function Select製造出庫(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                            ByVal 処理連番 As Long,
                            ByVal 手配番号 As Long,
                            ByVal 構成品出庫区分 As Integer,
                            ByVal 支給管理 As Integer,
                            ByVal 対象年月度 As Integer
             ) As String    'X1変換Tool-20170508
    'A-20150520_1↑

    Function Select個別出庫(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                            ByVal 処理連番 As Long
             ) As String    'X1変換Tool-20170508

    Function Selectロット明細(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                              ByVal 明細区分 As Integer,
                              ByVal 取引区分 As Integer,
                              ByVal 処理連番 As Long,
                              ByVal 行番号 As Integer
             ) As String    'X1変換Tool-20170508

    Function UpdateHANR004(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                           ByVal 更新データ As S90050_00.WorkTableUnitData
             ) As String    'X1変換Tool-20170508

    Function UpdateHANR005(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                           ByVal 更新データ As S90050_00.WorkTableUnitData,
                           ByVal line As Integer
             ) As String    'X1変換Tool-20170508
    'A-20110912_1↓
    Function SelectHANR001SK(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                     ByVal 処理連番 As Long) As String    'X1変換Tool-20170508

    Function SelectSEIW053前後工程仕掛取得(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                       ByVal 手配管理番号 As Long,
                                       ByVal 手順番号F As Integer,
                                       ByVal 手順番号T As Integer
             ) As String    'X1変換Tool-20170508
    'A-20110912_1↑

    'A-20120125_1↓
    Function SelectSEIS003仕掛在庫数量取得(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                           ByVal 内外区分 As Integer,
                                           ByVal 手配先コード As String,
                                           ByVal 品目コード As String,
                                           ByVal 手順No As Integer,
                                           ByVal 当期期首年月度 As Integer
             ) As String    'X1変換Tool-20170508
    'A-20120125_1↑

    'A-20130304_1↓
    Function SelectSEIR010分納実績取得(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                       ByVal 発注番号 As Long,
                                       ByVal 処理連番 As Long
             ) As String    'X1変換Tool-20170508
    'A-20130304_1↑

    'A-20130304_2↓
    Function Select元需要_個別受注(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                   ByVal 発注番号 As Long
             ) As String    'X1変換Tool-20170508

    Function Select元需要_従属需要(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                   ByVal 発注区分 As Integer,
                                   ByVal 発注番号 As Long,
                                   ByVal 手配管理番号 As Long
             ) As String    'X1変換Tool-20170508

    Function Select元需要_従属需要予定(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                       ByVal 発注区分 As Integer,
                                       ByVal 発注番号 As Long,
                                       ByVal 手配管理番号 As Long
             ) As String    'X1変換Tool-20170508
    'A-20130304_2↑

    'A-CUST20190830↓
    Function Select発注伝票CUST(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                 ByVal 発注番号 As Long,
                                 ByVal 発注行番号 As Integer
         ) As String

    Function Select発注内訳伝票CUST(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                 ByVal 発注番号 As Long,
                                 ByVal 発注行番号 As Integer,
                                 ByVal 内訳番号 As Integer
         ) As String

    Function Select入出荷予定伝票CUST(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                 ByVal 入出荷予定番号 As Long,
                                 ByVal 入出荷予定行番号 As Integer
         ) As String

    Function Select入出荷予定伝票CUST(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                 ByVal 入出荷予定番号 As Long
         ) As String

    Function Select入出荷予定ヘッダーCUST(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                 ByVal 入出荷予定番号 As Long
         ) As String

    Function Select入出荷予定明細CUST(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                 ByVal 入出荷予定番号 As Long,
                                 ByVal 入出荷予定行番号 As Integer
         ) As String

    Function SelectSEIMA02PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                     ByVal コード As String
             ) As String

    Function UpdateHANW091(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                   ByVal 更新データ As String,
                   ByVal 行番号 As Integer,
                   ByVal 分割キー As String
            ) As String

    Function UpdateHANC020(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                           ByVal ImportParam As S90050_00.ImportParam
            ) As String

    Function UpdateSEIRA01(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                           ByVal 更新データ As S90050_00.WorkTableUnitData,
                           ByVal 発注内訳残区分 As Integer
             ) As String

    Function UpdateSEIRA02(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                           ByVal 更新データ As S90050_00.WorkTableUnitData,
                           ByVal 残区分 As Integer,
                           ByVal 番号 As Long
             ) As String

    Function UpdateSEIRA03(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                           ByVal 更新データ As S90050_00.WorkTableUnitData,
                           ByVal 残区分 As Integer,
                           ByVal 番号 As Long,
                           ByVal 行番号 As Integer,
                           ByVal line As Integer
             ) As String
    'A-CUST20190830↑

End Interface
