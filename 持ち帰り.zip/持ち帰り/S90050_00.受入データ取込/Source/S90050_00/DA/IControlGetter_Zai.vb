﻿'A-2008/07/18_Ver7.30_SAIMU ※クラス追加
Public Interface IControlGetter_Zai
    Inherits IInsideDataHandler

    Sub Startup(ByVal connection As DbConnection, ByVal initInfo As IDictionary, ByRef コントロール情報 As Myコントロール情報型)

    Sub ControlGet(ByVal controlC001 As IDictionary, ByRef コントロール情報 As Myコントロール情報型)

End Interface
