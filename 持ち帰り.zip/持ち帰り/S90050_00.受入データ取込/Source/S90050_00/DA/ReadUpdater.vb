﻿''' <summary>
''' 業務テーブル更新処理
''' </summary>
''' <remarks></remarks>
Public Class ReadUpdater
    Inherits ReadUpdaterBase

#Region "for debug ..."

    <Conditional("Debug")>
    Protected Overrides Function 処理件数表示単位() As Integer
        If Me.システム環境情報.システム構成情報.動作モード = Foundation.動作モード型.通常 Then
            Return MyBase.処理件数表示単位
        End If
        Return 10
    End Function

#End Region

#Region "■定義■"

    Private Structure 伝票履歴作成型        'A-2009/08/21_RIREKI
        Dim 伝票種類 As ISlipHistory.伝票種類型
        Dim 伝票区分 As Integer
        Dim 処理連番 As Long
        Dim 更新区分 As ISlipHistory.更新区分型
        Sub Initialize()
            伝票種類 = ISlipHistory.伝票種類型.取引
            伝票区分 = 0
            処理連番 = 0
            更新区分 = ISlipHistory.更新区分型.修正
        End Sub
    End Structure

    Private Structure 伝票履歴番号取得型    'A-2009/08/21_RIREKI
        Dim 伝票種類 As ISlipHistory.伝票種類型
        Dim 伝票区分 As Integer
        Dim 処理連番 As Long
        Sub Initialize()
            伝票種類 = ISlipHistory.伝票種類型.取引
            伝票区分 = 0
            処理連番 = 0
        End Sub
    End Structure

    Private Structure 内訳登録型    'A-2009/12/18_Ver7.40_UCHIWAKE
        Dim 商品コード As String
        Dim 内訳コード１ As String
        Dim 内訳コード２ As String
        Dim 内訳コード３ As String
        Dim 単位換算数量 As Decimal
        Dim 内訳使用区分１ As Integer
        Dim 内訳使用区分２ As Integer
        Dim 内訳使用区分３ As Integer
        Dim ロット管理区分 As Integer
        Dim 当期期首月 As Integer
        Sub Initialize()
            商品コード = ""
            内訳コード１ = ""
            内訳コード２ = ""
            内訳コード３ = ""
            単位換算数量 = 0
            内訳使用区分１ = 0
            内訳使用区分２ = 0
            内訳使用区分３ = 0
            ロット管理区分 = 0
            当期期首月 = 0
        End Sub
    End Structure

    Private Structure ロット登録型  'A-2009/12/18_Ver7.40_LOT
        Dim 商品コード As String
        Dim 内訳コード１ As String
        Dim 内訳コード２ As String
        Dim 内訳コード３ As String
        Dim ロット番号 As String
        Dim サブロット番号 As String
        Dim 有効期限 As Integer
        Dim 単価 As Decimal
        Dim 内訳使用区分１ As Integer
        Dim 内訳使用区分２ As Integer
        Dim 内訳使用区分３ As Integer
        Dim 当期期首月 As Integer
        Sub Initialize()
            商品コード = ""
            内訳コード１ = ""
            内訳コード２ = ""
            内訳コード３ = ""
            ロット番号 = ""
            サブロット番号 = ""
            有効期限 = 0
            単価 = 0
            内訳使用区分１ = 0
            内訳使用区分２ = 0
            内訳使用区分３ = 0
            当期期首月 = 0
        End Sub
    End Structure

    Private Const INSERT_ストアド_仕入伝票 As String = "OSKHAN10A00030INS"    'X1変換Tool-20170509
    Private Const DELETE_ストアド_仕入伝票 As String = "OSKHAN10A00030DEL"    'X1変換Tool-20170509
    Private Const INSERT_ストアド_仕入伝票_内訳ロット As String = "OSKHAN10A00033INS"   'A-2009/12/18_Ver7.40_UCHIWAKE    'X1変換Tool-20170509
    Private Const DELETE_ストアド_仕入伝票_内訳ロット As String = "OSKHAN10A00033DEL"   'A-2009/12/18_Ver7.40_UCHIWAKE    'X1変換Tool-20170509
    Private Const INSERT_ストアド_受発注原価集計更新 As String = "OSKHAN10A00012INS"    'A-2008/07/18_Ver7.30_GENKA    'X1変換Tool-20170509

    '受入処理-ストアド
    Private Const INSERT_ストアド_受入伝票 As String = "OSKSEI10A06100INS"    'X1変換Tool-20170509
    Private Const DELETE_ストアド_受入伝票 As String = "OSKSEI10A06100DEL"    'X1変換Tool-20170509
    Private Const INSERT_ストアド_入荷伝票 As String = "OSKSEI10A06101INS"    'X1変換Tool-20170509
    Private Const DELETE_ストアド_入荷伝票 As String = "OSKSEI10A06101DEL"    'X1変換Tool-20170509
    'Private Const INSERT_ストアド_入庫伝票 As String = "OSKHAN10A00050INS"    'X1変換Tool-20170509
    'Private Const DELETE_ストアド_入庫伝票 As String = "OSKHAN10A00050DEL"    'X1変換Tool-20170509
    Private Const INSERT_ストアド_ロット明細 As String = "OSKSEI10E10011INS"    'X1変換Tool-20170509
    Private Const DELETE_ストアド_ロット明細 As String = "OSKSEI10E10011DEL"    'X1変換Tool-20170509
    Private Const INSERT_ストアド As String = "OSKSEI10A07140INS"    'X1変換Tool-20170509
    Private Const DELETE_ストアド As String = "OSKSEI10A07140DEL"    'X1変換Tool-20170509
    Private Const INSERT_ストアド_原価 As String = "OSKSEI10A15110INS"    'X1変換Tool-20170509
    Private Const DELETE_ストアド_原価 As String = "OSKSEI10A15110DEL"    'X1変換Tool-20170509

    Private Const INSERT_ストアド_入庫伝票_入荷 As String = "OSKSEI10E10010INS"    'X1変換Tool-20170509
    Private Const DELETE_ストアド_入庫伝票_入荷 As String = "OSKSEI10E10010DEL"    'X1変換Tool-20170509
    Private Const INSERT_ストアド_入庫伝票_検収 As String = "OSKSEI10A06102INS"    'X1変換Tool-20170509
    Private Const DELETE_ストアド_入庫伝票_検収 As String = "OSKSEI10A06102DEL"    'X1変換Tool-20170509

    Private Const INSERT_ストアド_出庫_みなし As String = "OSKHAN10A00050INS" 'A-20111105_1    'X1変換Tool-20170509
    Private Const INSERT_ストアド_入庫_みなし As String = "OSKSEI10A07140INSS1" 'A-20111105_1    'X1変換Tool-20170509

    Private Const INSERT_ストアド_入荷伝票_４次強化 As String = "OSKSEI10A06104INS"      'A-20121217_Ver7.50    'X1変換Tool-20170509
    Private Const DELETE_ストアド_入荷伝票_４次強化 As String = "OSKSEI10A06104DEL"      'A-20121217_Ver7.50    'X1変換Tool-20170509

    Private Const DELETE_ストアド_入荷伝票_仕掛 As String = "OSKSEI10A06103DEL"          'A-20121217_Ver7.50    'X1変換Tool-20170509
    Private Const DELETE_ストアド_入荷伝票_仕掛_４次強化 As String = "OSKSEI10A06105DEL" 'A-20121217_Ver7.50    'X1変換Tool-20170509

    Private Const INSERT_ストアド_ロット明細_４次強化 As String = "OSKSEI10E10012INS"    'A-20121217_Ver7.50    'X1変換Tool-20170509
    Private Const DELETE_ストアド_ロット明細_４次強化 As String = "OSKSEI10E10012DEL"    'A-20121217_Ver7.50    'X1変換Tool-20170509

    Private Const INSERT_ストアド_製造実績更新_４次強化 As String = "OSKSEI10A07142INS"  'A-20121217_Ver7.50    'X1変換Tool-20170509
    Private Const DELETE_ストアド_製造実績更新_４次強化 As String = "OSKSEI10A07142DEL"  'A-20121217_Ver7.50    'X1変換Tool-20170509

    'A-CUST20190830↓
    Private Const INSERT_ストアド_入出庫伝票 As String = "OSKSEI10E10010INS"
    Private Const INSERT_ストアド_ロット伝票 As String = "OSKSEI10E10011INS"
    'A-CUST20190830↑

    Private _myImportParam As S90050_00.ImportParam
    Private _エラー＿警告情報() As String    'X1変換Tool-20170508

    Private _データ件数 As Integer

    Private _システム日付 As Integer                        'A-2009/08/21_RIREKI
    Private _システム時刻 As Integer                        'A-2009/08/21_RIREKI
    Private _仕入伝票履歴番号 As Integer                    'A-2009/08/21_RIREKI
    Private _関連履歴作成_受発注 As ICreateKanrenHistory    'A-2009/08/21_RIREKI
    Private _内訳登録 As IComprisingItemIns                 'A-2009/12/18_Ver7.40_UCHIWAKE
    Private _ロット登録 As ILotInsert                       'A-2009/12/18_Ver7.40_LOT

    Private _在庫引当更新 As IHikiateKoushinGetter          'A-20121217_Ver7.50_2

    Private Enum 計上区分型
        入荷基準 = 0
        検収基準
    End Enum
    'A-20110912_1↓
    Private Enum 処理区分型 As Integer
        登録 = 1
        修正
        削除
    End Enum
    'A-20110912_1↑
#End Region

#Region "■初期処理関連■"

    Protected Overrides Sub MyInitialize()

        _myImportParam = CType(MyBase.ImportParam, S90050_00.ImportParam)
        MyBase._textDataChecker = MyBase.CreateTextDataChecker()
        MyBase._workTableUnitData = New S90050_00.WorkTableUnitData

    End Sub

    Protected Overrides Function GetErrorWorningCountヘッダー() As Integer

        Return S90050_00.エラー＿警告一覧_ヘッダー._項目数    'X1変換Tool-20170508

    End Function

    Protected Overrides Function GetErrorWorningCount明細() As Integer

        Return S90050_00.エラー＿警告一覧_明細._項目数    'X1変換Tool-20170508

    End Function

#End Region

#Region "■ワークデータ取得関連■"

    Protected Overrides Sub SetNewKeys(ByRef newKeys() As String, ByRef W091TFTORIKOMIData As TextFileImport.IWorkTableUnitData.W091TFTORIKOMI定義)
        'D-CUST20190830↓
        'ReDim newKeys(0)
        'newKeys(0) = W091TFTORIKOMIData.W091002_テキスト内容配列(仕入データ型.処理連番)
        'D-CUST20190830↑
        'A-CUST20190830↓
        ReDim newKeys(1)
        newKeys(0) = W091TFTORIKOMIData.W091002_テキスト内容配列(仕入データ型.処理連番)
        newKeys(1) = W091TFTORIKOMIData.W091002_テキスト内容配列(仕入データ型.データ区分)
        'A-CUST20190830↑
    End Sub

#End Region

#Region "■業務テーブル更新■"

    'A-CUST20190830↓
    ''' <summary>
    ''' テキストデータのチェックとテーブルの更新
    ''' </summary>
    ''' <param name="appConnection"></param>
    ''' <returns></returns>
    ''' <remarks>データ一単位毎に処理を行う</remarks>
    Protected Overrides Function CheckAndUpdateUnit(ByRef appConnection As DbConnection
                                   ) As TextFileImport.IResult
        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Using transaction As DbTransaction = MyBase.DataAccess.BeginTransaction(appConnection)
            Try
                '■取込データチェック
                result = _textDataChecker.DoDataCheck(transaction)
                If result.Code <> ResultType.成功 Then
                    transaction.Rollback()
                    Return result
                End If

                '■業務テーブル更新 - エラーチェック時は更新しない
                '                     エラーデータが存在する場合は更新しない
                If Me.ImportParam.実行中の処理 <> TextFileImportLib.実行中の処理型.エラーチェック AndAlso
                   _workTableUnitData.エラー件数 = 0 Then
                    result = UpdateApplicationTable(transaction)
                    If result.Code <> ResultType.成功 Then
                        transaction.Rollback()
                        Return result
                    End If
                End If

                '■ワークテーブル更新 - 警告・エラーリスト出力の為、エラーチェック時でもコミット
                result = UpdateWorkTable(transaction)

                Dim ワーク行番号 As Integer = MyBase._workTableUnitData.W091TFTORIKOMIDatas.W091001_行番号
                Dim ファイル行番号 As Integer = MyBase._workTableUnitData.W091TFTORIKOMIDatas.W091001_行番号 - 1
                Dim 元テキスト内容 As String
                For 行 As Integer = 1 To MyBase._workTableUnitData.データ件数
                    元テキスト内容 = CType(Me.ImportParam, S90050_00.ImportParam).元ファイル内容(ファイル行番号)
                    元テキスト内容 = 元テキスト内容.Replace(vbTab, TextFileImportLib.TAB_STRING)

                    Dim parameters As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20191106
                    result = UpdateHANW091(transaction, 元テキスト内容, ワーク行番号, ImportParam.KanriTableData.分割コード)

                    If result.Code <> ResultType.成功 Then
                        transaction.Rollback()
                        Return result
                    End If
                    ワーク行番号 += 1
                    ファイル行番号 += 1
                Next

                If result.Code = ResultType.成功 Then
                    transaction.Commit()
                Else
                    transaction.Rollback()
                End If

            Catch ex As Exception
                Debug.Print(CStr(MyBase._workTableUnitData.W091TFTORIKOMIDatas.W091001_行番号))
                transaction.Rollback()
                Throw ex

            End Try
        End Using

        Return result
    End Function
    'A-CUST20190830↑

    ''' <summary>
    ''' 業務テーブル更新
    ''' </summary>
    ''' <param name="transaction"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Protected Overrides Function UpdateApplicationTable(ByRef transaction As DbTransaction
                                 ) As TextFileImport.IResult
        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim 更新データ As S90050_00.WorkTableUnitData

        Dim syoriRenban As Decimal = 0                  'A-20110912_1
        Dim HANC021 As ProgramLib.連番管理テーブル型    'A-20110912_1

        更新データ = CType(_workTableUnitData, S90050_00.WorkTableUnitData)
        'A-20121217_Ver7.50↓
        '2回目以降の処理で前回処理の内容値をそのまま保持している可能性があるため上書きする
        更新データ.ストアドパラメータ_INSERT_出庫_移動有 = 更新データ.ストアドパラメータ_INSERT
        更新データ.ストアドパラメータ_INSERT_入庫_移動有 = 更新データ.ストアドパラメータ_INSERT
        'A-20121217_Ver7.50↑

        HANC021 = 更新データ.連番管理テーブル           'A-20110912_1

        _データ件数 = 更新データ.データ件数 + 更新データ.生成消費税行数

        If _データ件数 > ProgramLib.MAX_DETAIL_COUNT Then
            _データ件数 = ProgramLib.MAX_DETAIL_COUNT
        End If

        syoriRenban = 更新データ.連番管理テーブル.C021002       'A-20110912_1

        Get日時情報()   'A-2009/08/21_RIREKI

        'A-CUST20190830↓
        '予定入庫の場合は、「UpdateApplicationTable_CUST」へ。
        If 更新データ.取込種別 = 伝票種別型._予定入庫_預入庫 OrElse 更新データ.取込種別 = 伝票種別型._予定入庫_移動 Then
            GoTo UpdateApplicationTable_CUST
        End If
        'A-CUST20190830↑

        'A-20110912_1↓
        '修正時は新旧データの判断を行う。
        Dim _仕掛生成区分 As Integer = 0
        Dim 仕掛入出庫存在 As Boolean = False    'A-20121217_Ver7.50
        If _myImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 3D And
            _myImportParam.Myコントロール情報.MyMOA機能追加.仕掛管理区分 = MOA機能追加定義型.その他管理区分型.行う Then
            If MyBase._textDataChecker.DB更新Mode = ITextDataChecker.DB更新Mode型.UPDATE Then
                Dim _仕掛入出庫データ As New DataTable

                '仕掛入出庫データ参照
                If ReadHANR001SK(transaction, _仕掛入出庫データ, 更新データ.入荷ヘッダー.R010005) = ResultType.成功 Then
                    _仕掛生成区分 = CType(_仕掛入出庫データ.Rows(0).Item("HANR001S002"), Integer)
                    'A-20121217_Ver7.50↓
                    If CInt(_仕掛入出庫データ.Rows(0).Item("HANR001004")) = 9 Then
                        仕掛入出庫存在 = True
                        'A-20150108_1↓
                        '単独工程返品伝票の場合、自前で仕掛入庫データを作成するので、呼び出すストアドは
                        '通常の入荷用となる。
                        If Is単独工程返品伝票(CLng(_仕掛入出庫データ.Rows(0).Item("SEIR010046")),
                                              CLng(_仕掛入出庫データ.Rows(0).Item("SEIR010016")),
                                              CInt(_仕掛入出庫データ.Rows(0).Item("SEIR010040")),
                                              CInt(_仕掛入出庫データ.Rows(0).Item("SEIR010045"))) = True Then
                            仕掛入出庫存在 = False
                        End If
                        'A-20150108_1↑
                    End If
                    'A-20121217_Ver7.50↑
                End If
            End If
        End If
        'A-20110912_1↑

        If MyBase._textDataChecker.DB更新Mode = ITextDataChecker.DB更新Mode型.UPDATE Then
            '↓A-2009/08/21_RIREKI
            '■仕入履歴作成
            If _myImportParam.Myコントロール情報.My変更履歴.変更履歴_仕入 = True Then
                Dim パラメータ As 伝票履歴作成型
                With パラメータ
                    .Initialize()
                    .伝票種類 = ISlipHistory.伝票種類型.取引
                    .伝票区分 = 伝票区分型.仕入
                    .処理連番 = 更新データ.仕入ヘッダー.R001006
                    .更新区分 = Get更新区分_仕入(MyBase._textDataChecker.DB更新Mode)
                End With
                Create伝票履歴(transaction, パラメータ)
            End If
            '↑A-2009/08/21_RIREKI

            ''削除処理(ストアド)
            ''↓A-2009/12/18_Ver7.40_UCHIWAKE
            'Dim 削除ストアド名称 As String = DELETE_ストアド_仕入伝票

            'If _myImportParam.Myコントロール情報.MyＲＥＶ.強化区分 >= 4.0 Then
            '    '４次強化以上の時、内訳ロット対応版のストアドを実行
            '    削除ストアド名称 = DELETE_ストアド_仕入伝票_内訳ロット
            'End If
            ''↑A-2009/12/18_Ver7.40_UCHIWAKE
            ''result = Updateストアド_仕入(transaction, DELETE_ストアド_仕入伝票, 更新データ.ストアドパラメータ_仕入_DELETE) 'D-2009/12/18_Ver7.40_UCHIWAKE
            'result = Updateストアド_仕入(transaction, 削除ストアド名称, 更新データ.ストアドパラメータ_仕入_DELETE)          'A-2009/12/18_Ver7.40_UCHIWAKE
            'If result.Code <> ResultType.成功 Then
            '    Return result
            'End If

            'A-20121217_Ver7.50_3↓
            '在庫引当更新(引当解除)
            If _myImportParam.Myコントロール情報.My機能区分.受注在庫引当 = 機能区分定義型.受注在庫引当型.行う Then
                '在庫引当更新(製造出庫品目の引当解除)
                Is在庫引当更新(transaction, 更新データ)
                If result.Code <> ResultType.成功 Then Return result

                '在庫引当更新(引当解除)
                result = Is在庫引当更新(transaction, 更新データ, 処理区分型.削除)
                If result.Code <> ResultType.成功 Then Return result
            End If
            'A-20121217_Ver7.50_3↑

            'A-20110912_1↓
            If _myImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 3D And
               _myImportParam.Myコントロール情報.MyMOA機能追加.仕掛管理区分 = MOA機能追加定義型.その他管理区分型.行う Then
                '修正かつ新データの場合のみ部品を使用する。
                If _仕掛生成区分 = 1 Then
                    '<--- 仕掛入庫伝票減算処理実行 --->
                    ' 仕掛在庫更新部品
                    '  登録時：- (実行しない)
                    '  修正時：減算処理
                    result = Update仕掛在庫更新部品(transaction, 更新データ, 処理区分型.削除, syoriRenban)
                    If result.Code <> ResultType.成功 Then
                        Return result
                    End If
                End If
            End If
            'A-20110912_1↑

            '削除処理(ストアド) - 原価
            If 更新データ.ストアドパラメータ_原価_入庫_DELETE.更新判断 = True Then
                result = Updateストアド_仕入(transaction, DELETE_ストアド_原価, 更新データ, 入出庫区分型.入庫)
            End If
            If 更新データ.ストアドパラメータ_原価_出庫_DELETE.更新判断 = True Then
                result = Updateストアド_仕入(transaction, DELETE_ストアド_原価, 更新データ, 入出庫区分型.出庫)
            End If

            '削除処理(ストアド) - 受入(入荷)
            If 更新データ.自動生成区分 = 0 Then
                'result = Updateストアド_仕入(transaction, DELETE_ストアド_入荷伝票, 更新データ)         'D-20121217_Ver7.50
                'A-20121217_Ver7.50↓
                If 仕掛入出庫存在 = False Then
                    result = Updateストアド_仕入(transaction, DELETE_ストアド_入荷伝票, 更新データ)
                Else
                    result = Updateストアド_仕入(transaction, DELETE_ストアド_入荷伝票_仕掛, 更新データ)
                End If
                'A-20121217_Ver7.50↑
            Else
                result = Updateストアド_仕入(transaction, DELETE_ストアド_受入伝票, 更新データ)
            End If

            '削除処理(ストアド) - 入庫
            If 更新データ.ストアドパラメータ_入庫_DELETE.更新判断 = True Then
                If 更新データ.計上区分 = 計上区分型.入荷基準 Then
                    result = Updateストアド_仕入(transaction, DELETE_ストアド_入庫伝票_入荷, 更新データ)
                Else
                    result = Updateストアド_仕入(transaction, DELETE_ストアド_入庫伝票_検収, 更新データ)
                End If
            End If

            '削除処理(ストアド) - ロット明細
            If 更新データ.ストアドパラメータ_ロット明細_DELETE.更新判断 = True Then
                result = Updateストアド_仕入(transaction, DELETE_ストアド_ロット明細, 更新データ)
            End If

            '受入索引テーブル削除
            If 更新データ.修正前受入索引連番 <> 0 Then
                result = DeleteSEIR114(transaction, 更新データ)
                If result.Code <> ResultType.成功 Then
                    Return result
                End If
            End If

            '出庫ストアド
            If 更新データ.ストアドパラメータ_DELETE.更新判断 = True Then
                result = Updateストアド_仕入(transaction, DELETE_ストアド, 更新データ)

                'A-20111124_8↓
                '倉庫移動入庫を削除する。
                If _myImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 3D And
                   _myImportParam.Myコントロール情報.MyMOA機能追加.仕掛管理区分 = MOA機能追加定義型.その他管理区分型.行う Then

                    result = Updateストアド_仕入(transaction, DELETE_ストアド, 更新データ, 入出庫区分型.入庫)

                End If
                'A-20111124_8↑
            End If

            '既存拡張項目の削除
            result = 拡張項目削除(transaction, 更新データ)
            If result.Code <> ResultType.成功 Then
                Return result
            End If

            If _myImportParam.Myコントロール情報.My販売財務連動.販売財務連動区分 = 販売財務連動定義型.販売財務連動区分型.行う AndAlso
               _myImportParam.Myコントロール情報.My販売財務連動.仕入データ連動区分 <> 販売財務連動定義型.仕入データ連動区分型.連動しない AndAlso
               更新データ.仕訳対象外区分_元伝票 = 0 Then
                '販売データ仕訳作成日付管理テーブル更新
                If ReadHANC015UpdateLock(transaction, 更新データ.仕訳作成日付_元伝票) = ResultType.成功 Then
                    result = UpdateHANC015(transaction, 更新データ.仕訳作成日付_元伝票)
                    If result.Code <> ResultType.成功 Then
                        Return result
                    End If
                End If
            End If

        End If

        '↓A-2008/07/18_Ver7.30_SHIHARAI
        If _myImportParam.Myコントロール情報.Myオプション区分.支払管理 = オプション区分定義型.区分型.行う Then
            '支払予定テーブル削除
            If 更新データ.既存支払予定データあり = True Then
                result = DeleteHANR031(transaction, 更新データ.仕入ヘッダー.R001006)
                If result.Code <> ResultType.成功 Then
                    Return result
                End If
            End If

            '支払予定テーブル登録
            If 更新データ.支払予定更新区分 <> WorkTableUnitData.DB更新区分型.None Then
                result = InsertHANR031(transaction, 更新データ)
                If result.Code <> ResultType.成功 Then
                    Return result
                End If
            End If
        End If
        '↑A-2008/07/18_Ver7.30_SHIHARAI

        '↓A-2009/08/21_RIREKI
        '■履歴番号取得
        _仕入伝票履歴番号 = 0
        If _myImportParam.Myコントロール情報.My変更履歴.変更履歴_仕入 = True Then
            Dim パラメータ As 伝票履歴番号取得型
            With パラメータ
                .伝票種類 = ISlipHistory.伝票種類型.取引
                .伝票区分 = 伝票区分型.仕入
                .処理連番 = 更新データ.仕入ヘッダー.R001006
            End With
            _仕入伝票履歴番号 = Get履歴番号(transaction, パラメータ)
        End If

        '■関連履歴作成
        If Is関連履歴作成判定_発注() = True Then
            '初期処理
            Initialize関連履歴()
            仮想処理_発注(transaction, 更新データ)
            '履歴作成
            Create関連履歴(transaction)
        End If
        '↑A-2009/08/21_RIREKI

        '*** 受入伝票登録
        If 更新データ.仕入伝票更新 = True Then

            '更新取引ヘッダー再編集             'A-2009/08/21_RIREKI
            SetData取引ヘッダー(更新データ)     'A-2009/08/21_RIREKI

            '取引ヘッダー登録
            result = InsertHANR001(transaction, 更新データ, 伝票区分型.仕入)
            If result.Code <> ResultType.成功 Then
                Return result
            End If

            '取引明細登録
            result = InsertHANR002(transaction, 更新データ, 伝票区分型.仕入)
            If result.Code <> ResultType.成功 Then
                Return result
            End If

        End If

        '*** 入荷伝票登録
        If 更新データ.入荷伝票更新 = True Then

            '入出荷ヘッダー登録
            result = InsertSEIR010(transaction, 更新データ)
            If result.Code <> ResultType.成功 Then
                Return result
            End If

            '入出荷明細登録
            result = InsertSEIR011(transaction, 更新データ)
            If result.Code <> ResultType.成功 Then
                Return result
            End If

        End If

        '*** 入庫伝票登録
        If 更新データ.入庫伝票更新 = True Then

            '取引ヘッダー登録
            result = InsertHANR001(transaction, 更新データ, 伝票区分型.入出庫)
            If result.Code <> ResultType.成功 Then
                Return result
            End If

            '取引明細登録
            result = InsertHANR002(transaction, 更新データ, 伝票区分型.入出庫)
            If result.Code <> ResultType.成功 Then
                Return result
            End If

            'ロット明細登録
            result = InsertSEIR008(transaction, 更新データ)
            If result.Code <> ResultType.成功 Then
                Return result
            End If

        End If

        '*** 仕掛入庫伝票登録
        'A-20110912_1↓
        'D-20150108_1↓
        'If _myImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 3D And _
        '   _myImportParam.Myコントロール情報.MyMOA機能追加.仕掛管理区分 = MOA機能追加定義型.その他管理区分型.行う And _
        '    (MyBase._textDataChecker.DB更新Mode = ITextDataChecker.DB更新Mode型.INSERT OrElse _仕掛生成区分 = 1) Then
        'D-20150108_1↑
        'A-20150108_1↓
        '単独の工程返品は本プログラムで仕掛入庫データを生成するよう修正。
        If _myImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 3D And
           _myImportParam.Myコントロール情報.MyMOA機能追加.仕掛管理区分 = MOA機能追加定義型.その他管理区分型.行う And
            (MyBase._textDataChecker.DB更新Mode = ITextDataChecker.DB更新Mode型.INSERT OrElse _仕掛生成区分 = 1) AndAlso
           Is単独工程返品伝票(更新データ) = False Then
            'A-20150108_1↑
            '仕掛管理ありの場合は仕掛更新部品で仕掛入庫データを作成する。
        Else
            'A-20110912_1↑
            If 更新データ.仕掛入庫伝票更新 = True Then

                '取引ヘッダー登録
                result = InsertHANR001(transaction, 更新データ, 伝票区分型.仕掛入庫)
                If result.Code <> ResultType.成功 Then
                    Return result
                End If

                '取引明細登録
                result = InsertHANR002(transaction, 更新データ, 伝票区分型.仕掛入庫)
                If result.Code <> ResultType.成功 Then
                    Return result
                End If

            End If
        End If        'A-20110912_1

        '*** 製造実績更新
        If 更新データ.製造実績更新 = True Then
            result = Update製造実績更新部品(transaction, 更新データ)
            If result.Code <> ResultType.成功 Then
                Return result
            End If

            syoriRenban = 更新データ.連番管理テーブル.C021002 'A-20111105_1
        End If
        'A-20110912_1↓
        'D-20150108_1↓
        'If _myImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 3D And _
        '   _myImportParam.Myコントロール情報.MyMOA機能追加.仕掛管理区分 = MOA機能追加定義型.その他管理区分型.行う Then
        'D-20150108_1↑
        'A-20150108_1↓
        '単独の工程返品は本プログラムで仕掛入庫データを生成するため、仕掛在庫更新部品の呼び出しを抑止する。
        'なお、購買の場合も仕掛在庫更新部品を呼び出してしまっているのは不具合と考えられるが、現状、これで
        '上手くいっているようなので、このままとする。
        If _myImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 3D And
           _myImportParam.Myコントロール情報.MyMOA機能追加.仕掛管理区分 = MOA機能追加定義型.その他管理区分型.行う AndAlso
           Is単独工程返品伝票(更新データ) = False Then
            'A-20150108_1↑
            '登録または、修正かつ新データの場合のみ部品を使用する。
            If MyBase._textDataChecker.DB更新Mode = ITextDataChecker.DB更新Mode型.INSERT OrElse _仕掛生成区分 = 1 Then
                '<--- 仕掛入庫伝票更新 --->
                ' 仕掛在庫更新部品
                '  登録時：加算処理
                '  修正時：加算処理
                result = Update仕掛在庫更新部品(transaction, 更新データ, 処理区分型.登録, syoriRenban)
                If result.Code <> ResultType.成功 Then
                    Return result
                End If

                '仕掛在庫更新部品でカウントアップした値で連番管理テーブルの更新内容をセットする。
                HANC021.C021002 = CType(syoriRenban, Long)
                更新データ.連番管理テーブル = HANC021
            End If
        End If
        'A-20110912_1↑

        '出庫ストアド
        If 更新データ.ストアドパラメータ_INSERT.更新判断 = True Then
            result = Updateストアド_仕入(transaction, INSERT_ストアド, 更新データ)
        End If

        'A-20111105_1↓

        If 更新データ.ストアドパラメータ_INSERT_入庫_移動有.更新判断 = True Then
            'result = Updateストアド_仕入(transaction, INSERT_ストアド_入庫_みなし, 更新データ)         'D-20111124_9
            result = Updateストアド_仕入(transaction, INSERT_ストアド, 更新データ, 入出庫区分型.入庫)   'A-20111124_9
        End If

        'A-20111105_1↑

        'D-20130604_1↓
        ''A-20121217_Ver7.50_3↓
        ''在庫引当更新(在庫引当)
        'If _myImportParam.Myコントロール情報.My機能区分.受注在庫引当 = 機能区分定義型.受注在庫引当型.行う Then
        '    '在庫引当更新(在庫引当)
        '    result = Is在庫引当更新(transaction, 更新データ, 処理区分型.登録)
        '    If result.Code <> ResultType.成功 Then Return result
        'End If
        ''A-20121217_Ver7.50_3↑
        'D-20130604_1↑

        '*** 受入索引テーブル更新
        If 更新データ.受入索引更新 = True Then

            '受入索引テーブル登録
            result = InsertSEIR114(transaction, 更新データ)
            If result.Code <> ResultType.成功 Then
                Return result
            End If

        End If

        ''ストアド実行
        ''↓A-2009/12/18_Ver7.40_UCHIWAKE
        'Dim 登録ストアド名称 As String = INSERT_ストアド_仕入伝票

        'If _myImportParam.Myコントロール情報.MyＲＥＶ.強化区分 >= 4.0 Then
        '    '４次強化以上の時、内訳ロット対応版のストアドを実行
        '    登録ストアド名称 = INSERT_ストアド_仕入伝票_内訳ロット
        'End If
        ''↑A-2009/12/18_Ver7.40_UCHIWAKE
        ''result = Updateストアド_仕入(transaction, INSERT_ストアド_仕入伝票, 更新データ.ストアドパラメータ_仕入_INSERT) 'D-2009/12/18_Ver7.40_UCHIWAKE
        'result = Updateストアド_仕入(transaction, 登録ストアド名称, 更新データ.ストアドパラメータ_仕入_INSERT)          'A-2009/12/18_Ver7.40_UCHIWAKE
        'If result.Code <> ResultType.成功 Then
        '    Return result
        'End If

        '登録処理(ストアド) - 受入(入荷)
        If 更新データ.自動生成区分 = 0 Then
            result = Updateストアド_仕入(transaction, INSERT_ストアド_入荷伝票, 更新データ)
        Else
            result = Updateストアド_仕入(transaction, INSERT_ストアド_受入伝票, 更新データ)
        End If

        '登録処理(ストアド) - 原価
        If 更新データ.ストアドパラメータ_原価_入庫_INSERT.更新判断 = True Then
            'result = Updateストアド_仕入(transaction, INSERT_ストアド_原価, 更新データ)                    'D-20111025_6
            result = Updateストアド_仕入(transaction, INSERT_ストアド_原価, 更新データ, 入出庫区分型.入庫)  'A-20111025_6
        End If
        If 更新データ.ストアドパラメータ_原価_出庫_INSERT.更新判断 = True Then
            result = Updateストアド_仕入(transaction, INSERT_ストアド_原価, 更新データ)
        End If

        '登録処理(ストアド) - 入庫
        If 更新データ.ストアドパラメータ_入庫_INSERT.更新判断 = True Then
            If 更新データ.計上区分 = 計上区分型.入荷基準 Then
                result = Updateストアド_仕入(transaction, INSERT_ストアド_入庫伝票_入荷, 更新データ)
            Else
                result = Updateストアド_仕入(transaction, INSERT_ストアド_入庫伝票_検収, 更新データ)
            End If
        End If

        '登録処理(ストアド) - ロット明細
        If 更新データ.ストアドパラメータ_ロット明細_INSERT.更新判断 = True Then
            result = Updateストアド_仕入(transaction, INSERT_ストアド_ロット明細, 更新データ)
        End If

        'A-20130604_1↓
        '在庫引当更新(在庫引当)
        If _myImportParam.Myコントロール情報.My機能区分.受注在庫引当 = 機能区分定義型.受注在庫引当型.行う Then
            '在庫引当更新(在庫引当)
            result = Is在庫引当更新(transaction, 更新データ, 処理区分型.登録)
            If result.Code <> ResultType.成功 Then Return result
        End If
        'A-20130604_1↑

        '製番マスタ更新
        If 更新データ.製番マスタ更新 = True Then
            result = UpdateSEIM050(transaction, 更新データ)
            If result.Code <> ResultType.成功 Then
                Return result
            End If
        End If

        'A-CUST20190830↓
        '発注内訳更新
        result = UpdateSEIRA01(transaction, 更新データ)
        If result.Code <> ResultType.成功 Then
            Return result
        End If
        'A-CUST20190830↑

        'A-20111025_3↓
        '手入力製番マスタ更新(修正元)
        If 更新データ.既存手入力製番マスタ更新 = True Then
            result = UpdateSEIM050_手入力製番(transaction, 更新データ, False)
            If result.Code <> ResultType.成功 Then
                Return result
            End If
        End If

        '手入力製番マスタ更新
        If 更新データ.手入力製番マスタ更新 = True Then
            result = UpdateSEIM050_手入力製番(transaction, 更新データ)
            If result.Code <> ResultType.成功 Then
                Return result
            End If
        End If
        'A-20111025_3↑

        '*** 見込受注伝票更新
        If 更新データ.受注伝票更新 = True Then

            '受注ヘッダー更新
            result = UpdateHANR004(transaction, 更新データ)
            If result.Code <> ResultType.成功 Then
                Return result
            End If

            '受注明細更新
            result = UpdateHANR005(transaction, 更新データ)
            If result.Code <> ResultType.成功 Then
                Return result
            End If

        End If

        '拡張項目登録
        result = 拡張項目更新(transaction, 更新データ)
        If result.Code <> ResultType.成功 Then
            Return result
        End If

        If _myImportParam.Myコントロール情報.My販売財務連動.販売財務連動区分 = 販売財務連動定義型.販売財務連動区分型.行う AndAlso
           _myImportParam.Myコントロール情報.My販売財務連動.仕入データ連動区分 <> 販売財務連動定義型.仕入データ連動区分型.連動しない AndAlso
           更新データ.仕入ヘッダー.R001065 = 0 Then
            '販売データ仕訳作成日付管理テーブル更新
            If ReadHANC015UpdateLock(transaction, 更新データ.仕入ヘッダー.R001003) = ResultType.成功 Then
                result = UpdateHANC015(transaction, 更新データ.仕入ヘッダー.R001003)
                If result.Code <> ResultType.成功 Then
                    Return result
                End If
            End If
        End If

        '↓A-2008/07/18_Ver7.30_GENKA
        If _myImportParam.Myコントロール情報.Myオプション区分.原価管理 = オプション区分定義型.区分型.行う Then
            '受発注原価集計更新(ストアド)
            If _myImportParam.Myコントロール情報.Myオプション区分.受発注管理 = オプション区分定義型.区分型.行う Then
                Dim 原価集計ストアド名称 As String = INSERT_ストアド_受発注原価集計更新
                result = Updateストアド_原価集計(transaction, 原価集計ストアド名称, 更新データ)
                If result.Code <> ResultType.成功 Then
                    Return result
                End If
            End If
        End If
        '↑A-2008/07/18_Ver7.30_GENKA

        '↓A-2008/07/18_Ver7.30_SAIMU
        If 仕訳更新前チェック_会計債務(transaction, 更新データ) = True Then
            result = UpdateZAIR001(transaction, 更新データ.既存仕入ヘッダー.R001060)
            If result.Code <> ResultType.成功 Then
                Return result
            End If
        End If
        '↑A-2008/07/18_Ver7.30_SAIMU

        '↓A-2010/09/13_Ver7.4X_ZAISHONIN
        If 仮仕訳更新前チェック_会計債務(transaction, 更新データ) = True Then
            result = UpdateZAIR101(transaction, 更新データ.既存仕入ヘッダー.R001060)
            If result.Code <> ResultType.成功 Then
                Return result
            End If
        End If
        '↑A-2010/09/13_Ver7.4X_ZAISHONIN

        If _myImportParam.実行中の処理 = TextFileImportLib.実行中の処理型.取込実行 Then
            '* 連番管理/伝票番号管理テーブルは、修正時でも採番される可能性があるため毎時修正を行う
            '連番管理テーブル更新
            result = UpdateHANC021(transaction, 更新データ.連番管理テーブル.C021002)
            If result.Code <> ResultType.成功 Then
                Return result
            End If

            '伝票番号管理テーブル更新
            result = UpdateHANC022(transaction, 更新データ)
            If result.Code <> ResultType.成功 Then
                Return result
            End If

            'ロット連番管理テーブル
            If 更新データ.ロット連番管理.更新区分 = 更新区分型.INSERT Then
                result = InsertSEIC056(transaction, 更新データ)
                If result.Code <> ResultType.成功 Then
                    Return result
                End If
            ElseIf 更新データ.ロット連番管理.更新区分 = 更新区分型.UPDATE Then
                result = UpdateSEIC056(transaction, 更新データ)
                If result.Code <> ResultType.成功 Then
                    Return result
                End If
            End If

            '↓A-2009/12/18_Ver7.40_LOT
            'ロット№連番管理テーブル更新
            If _myImportParam.Myコントロール情報.Myオプション区分.ロット管理 = True Then
                If IsロットNo自動採番判定() = True AndAlso
                   更新データ.ロットNo連番管理テーブル.更新対象 = True Then
                    result = UpdateHANC023(transaction, 更新データ.ロットNo連番管理テーブル.C023002)
                    If result.Code <> ResultType.成功 Then
                        Return result
                    End If
                End If
            End If
            '↑A-2009/12/18_Ver7.40_LOT
        End If

        'A-CUST20190830↓
        GoTo UpdateApplicationTable_END

UpdateApplicationTable_CUST:

        '*** 入庫伝票登録
        If 更新データ.入庫伝票更新_自分 = True Then

            '取引ヘッダー登録
            result = InsertHANR001(transaction, 更新データ, 伝票区分型.入出庫_自分)
            If result.Code <> ResultType.成功 Then
                Return result
            End If

            '取引明細登録
            result = InsertHANR002(transaction, 更新データ, 伝票区分型.入出庫_自分)
            If result.Code <> ResultType.成功 Then
                Return result
            End If

            'ロット明細登録
            result = InsertSEIR008_CUST_自分(transaction, 更新データ)
            If result.Code <> ResultType.成功 Then
                Return result
            End If

            '入出庫予定
            result = Update入出庫予定(transaction, 更新データ)
            If result.Code <> ResultType.成功 Then
                Return result
            End If

            '登録処理(ストアド) - 入庫
            result = Updateストアド_入出庫(transaction, INSERT_ストアド_入出庫伝票, 更新データ.ストアドパラメータ_入出庫_INSERT_自分)
            '登録処理(ストアド) - ロット明細
            result = Updateストアド_ロット(transaction, INSERT_ストアド_ロット伝票, 更新データ.ストアドパラメータ_入出庫_INSERT_自分)

            '拡張項目登録
            result = 拡張項目更新_CUST_自分(transaction, 更新データ)
            If result.Code <> ResultType.成功 Then
                Return result
            End If

            '----------倉庫移動時!----------
            If 更新データ.取込種別 = 伝票種別型._予定入庫_移動 Then

                '取引ヘッダー登録
                result = InsertHANR001(transaction, 更新データ, 伝票区分型.入出庫_相手)
                If result.Code <> ResultType.成功 Then
                    Return result
                End If

                '取引明細登録
                result = InsertHANR002(transaction, 更新データ, 伝票区分型.入出庫_相手)
                If result.Code <> ResultType.成功 Then
                    Return result
                End If

                'ロット明細登録
                result = InsertSEIR008_CUST_相手(transaction, 更新データ)
                If result.Code <> ResultType.成功 Then
                    Return result
                End If

                '登録処理(ストアド) - 入庫
                result = Updateストアド_入出庫(transaction, INSERT_ストアド_入出庫伝票, 更新データ.ストアドパラメータ_入出庫_INSERT_相手)
                '登録処理(ストアド) - ロット明細
                result = Updateストアド_ロット(transaction, INSERT_ストアド_ロット伝票, 更新データ.ストアドパラメータ_入出庫_INSERT_相手)

                '拡張項目登録
                result = 拡張項目更新_CUST_相手(transaction, 更新データ)
                If result.Code <> ResultType.成功 Then
                    Return result
                End If
            End If

            If _myImportParam.実行中の処理 = TextFileImportLib.実行中の処理型.取込実行 Then
                '* 連番管理/伝票番号管理テーブルは、修正時でも採番される可能性があるため毎時修正を行う
                '連番管理テーブル更新
                result = UpdateHANC021(transaction, 更新データ.連番管理テーブル.C021002)
                If result.Code <> ResultType.成功 Then
                    Return result
                End If

                '伝票番号管理テーブル更新
                result = UpdateHANC022(transaction, 更新データ)
                If result.Code <> ResultType.成功 Then
                    Return result
                End If
            End If

        End If

UpdateApplicationTable_END:
        'A-CUST20190830↑

        Return result
    End Function

    'A-20150108_1↓
    Private Function Is単独工程返品伝票(ByVal 更新データ As S90050_00.WorkTableUnitData) As Boolean

        '単票前提のコードになっていることに注意。

        If 更新データ.入荷伝票更新 = False Then
            Return False
        End If

        Return Is単独工程返品伝票(更新データ.入荷ヘッダー.R010046, 更新データ.入荷ヘッダー.R010016, 更新データ.入荷ヘッダー.R010040, 更新データ.入荷ヘッダー.R010045)

    End Function

    Private Function Is単独工程返品伝票(ByVal 元入荷連番 As Long, ByVal 発注番号 As Long, ByVal 発注区分 As Integer, ByVal 返品区分 As Integer) As Boolean

        '元入荷連番＝０、発注番号＝０、発注区分＝工程、返品区分＝返品
        If 元入荷連番 = 0 AndAlso
           発注番号 = 0 AndAlso
           発注区分 = 2 AndAlso
           返品区分 = 1 Then
            Return True
        End If

        Return False

    End Function
    'A-20150108_1↑

    Private Sub SetData取引ヘッダー(ByRef 更新データ As S90050_00.WorkTableUnitData)   'A-2009/08/21_RIREKI

        Dim 仕入ヘッダー As ProgramLib.仕入ヘッダー型 = 更新データ.仕入ヘッダー
        With 仕入ヘッダー
            .R001911 = _仕入伝票履歴番号
            .R001914 = _システム日付
            .R001915 = _システム時刻
        End With

        更新データ.仕入ヘッダー = 仕入ヘッダー

    End Sub

    Private Function 拡張項目更新(ByRef transaction As DbTransaction,
                                  ByVal 更新データ As S90050_00.WorkTableUnitData
            ) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase
        Dim 拡張項目情報 As I拡張項目入力情報型 = CommonFactory.CreateInstance(Of I拡張項目入力情報型)(Me, GetType(拡張項目入力情報型))
        Dim 拡張項目入力情報 As I拡張項目入力情報型

        '伝票拡張項目登録
        'If _myImportParam.拡張項目情報_仕入伝票_使用 = True Then   'D-20111124_16
        'D-20111124_16↓
        If _myImportParam.拡張項目情報_仕入伝票_使用 = True AndAlso
           _myImportParam.Myコントロール情報.Myオプション区分.拡張項目_仕入伝票 = True Then
            'D-20111124_16↑
            If 更新データ.仕入伝票更新 = True Then
                拡張項目入力情報 = 更新データ.仕入ヘッダー.拡張項目入力情報

                With 拡張項目情報
                    .伝票種類 = I拡張項目入力情報型.伝票種類型.仕入
                    .明細区分 = I拡張項目入力情報型.明細区分型.通常
                    .連番 = 更新データ.仕入ヘッダー.R001006
                    .行番号 = 0
                    .付箋色番号 = 拡張項目入力情報.付箋色番号
                    For i As Integer = 1 To ProgramLib.MAX_EXPANDITEM_COUNT
                        .拡張項目(i) = 拡張項目入力情報.拡張項目(i)
                    Next
                    .更新番号 = _myImportParam.拡張項目情報_仕入伝票.更新番号

                    result = InsertExpandItem(transaction, 拡張項目情報)
                    If result.Code <> ResultType.成功 Then
                        Return result
                    End If
                End With
            End If
        End If

        'If _myImportParam.拡張項目情報_仕入明細_使用 = True Then   'D-20111124_16
        'A-20111124_16↓
        If _myImportParam.拡張項目情報_仕入明細_使用 = True AndAlso
           _myImportParam.Myコントロール情報.Myオプション区分.拡張項目_仕入明細 Then
            'A-20111124_16↑
            If 更新データ.仕入伝票更新 = True Then
                For line As Integer = 0 To 更新データ.仕入伝票更新件数 - 1

                    拡張項目入力情報 = 更新データ.仕入明細(line).拡張項目入力情報

                    With 拡張項目情報
                        .伝票種類 = I拡張項目入力情報型.伝票種類型.仕入
                        .明細区分 = CType(更新データ.仕入明細(line).R002005, I拡張項目入力情報型.明細区分型)
                        .連番 = 更新データ.仕入明細(line).R002004
                        .行番号 = 更新データ.仕入明細(line).R002006
                        .付箋色番号 = 拡張項目入力情報.付箋色番号
                        For i As Integer = 1 To ProgramLib.MAX_EXPANDITEM_COUNT
                            .拡張項目(i) = 拡張項目入力情報.拡張項目(i)
                        Next
                        .更新番号 = _myImportParam.拡張項目情報_仕入明細.更新番号

                        result = InsertExpandItem(transaction, 拡張項目情報)
                        If result.Code <> ResultType.成功 Then
                            Return result
                        End If
                    End With
                Next
            End If
        End If

        If _myImportParam.Myコントロール情報.MyMOA機能追加.仕入検収基準 = MOA機能追加定義型.その他管理区分型.行わない OrElse
           (_myImportParam.拡張項目情報_入荷伝票_使用 = False AndAlso _myImportParam.拡張項目情報_入荷明細_使用 = False) Then
            Return result
        End If

        If _myImportParam.拡張項目情報_入荷伝票_使用 = True Then
            With 拡張項目情報
                .伝票種類 = I拡張項目入力情報型.伝票種類型.入荷
                .明細区分 = I拡張項目入力情報型.明細区分型.通常
                If 更新データ.入荷伝票更新 = True Then
                    .連番 = 更新データ.入荷ヘッダー.R010005
                    拡張項目入力情報 = 更新データ.入荷ヘッダー.拡張項目入力情報
                Else
                    '入荷伝票が更新されない場合(消費税自動生成 または 取引区分が値引)
                    .連番 = 更新データ.仕入ヘッダー.R001006
                    拡張項目入力情報 = 更新データ.仕入ヘッダー.拡張項目入力情報
                End If
                .行番号 = 0
                .付箋色番号 = 拡張項目入力情報.付箋色番号
                For i As Integer = 1 To ProgramLib.MAX_EXPANDITEM_COUNT
                    .拡張項目(i) = 拡張項目入力情報.拡張項目(i)
                Next
                .更新番号 = _myImportParam.拡張項目情報_入荷伝票.更新番号

                result = InsertExpandItem(transaction, 拡張項目情報)
                If result.Code <> ResultType.成功 Then
                    Return result
                End If
            End With
        End If

        '明細拡張項目登録
        If _myImportParam.拡張項目情報_入荷明細_使用 = True Then
            If 更新データ.入荷伝票更新 = True Then
                For line As Integer = 0 To 更新データ.入荷伝票更新件数 - 1

                    拡張項目入力情報 = 更新データ.入荷明細(line).拡張項目入力情報

                    With 拡張項目情報
                        .伝票種類 = I拡張項目入力情報型.伝票種類型.入荷
                        .明細区分 = CType(更新データ.入荷明細(line).R011004, I拡張項目入力情報型.明細区分型)
                        .連番 = 更新データ.入荷明細(line).R011003
                        .行番号 = 更新データ.入荷明細(line).R011005
                        .付箋色番号 = 拡張項目入力情報.付箋色番号
                        For i As Integer = 1 To ProgramLib.MAX_EXPANDITEM_COUNT
                            .拡張項目(i) = 拡張項目入力情報.拡張項目(i)
                        Next
                        .更新番号 = _myImportParam.拡張項目情報_入荷明細.更新番号

                        result = InsertExpandItem(transaction, 拡張項目情報)
                        If result.Code <> ResultType.成功 Then
                            Return result
                        End If
                    End With
                Next
            Else
                For line As Integer = 0 To 更新データ.仕入伝票更新件数 - 1

                    拡張項目入力情報 = 更新データ.仕入明細(line).拡張項目入力情報

                    With 拡張項目情報
                        .伝票種類 = I拡張項目入力情報型.伝票種類型.入荷
                        .明細区分 = CType(更新データ.仕入明細(line).R002005, I拡張項目入力情報型.明細区分型)
                        .連番 = 更新データ.仕入明細(line).R002004
                        .行番号 = 更新データ.仕入明細(line).R002006
                        .付箋色番号 = 拡張項目入力情報.付箋色番号
                        For i As Integer = 1 To ProgramLib.MAX_EXPANDITEM_COUNT
                            .拡張項目(i) = 拡張項目入力情報.拡張項目(i)
                        Next
                        .更新番号 = _myImportParam.拡張項目情報_入荷明細.更新番号

                        result = InsertExpandItem(transaction, 拡張項目情報)
                        If result.Code <> ResultType.成功 Then
                            Return result
                        End If
                    End With
                Next
            End If
        End If

        Return result
    End Function

    Private Function 拡張項目削除(ByRef transaction As DbTransaction,
                                  ByVal 更新データ As S90050_00.WorkTableUnitData
            ) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase
        Dim 拡張項目情報 As I拡張項目入力情報型 = CommonFactory.CreateInstance(Of I拡張項目入力情報型)(Me, GetType(拡張項目入力情報型))

        If _myImportParam.Myコントロール情報.Myオプション区分.拡張項目_仕入伝票 = True OrElse
           _myImportParam.Myコントロール情報.Myオプション区分.拡張項目_仕入明細 = True Then

            If 更新データ.更新前処理連番_仕入伝票 <> 0 Then
                '
                With 拡張項目情報
                    .伝票種類 = I拡張項目入力情報型.伝票種類型.仕入
                    .連番 = 更新データ.更新前処理連番_仕入伝票
                End With

                result = DeleteExpandItem(transaction, 拡張項目情報)
                If result.Code <> ResultType.成功 Then
                    Return result
                End If

                '値引行 消費税伝票の場合は仕入伝票の処理連場で入荷拡張が生成されているため
                With 拡張項目情報
                    .伝票種類 = I拡張項目入力情報型.伝票種類型.入荷
                    .連番 = 更新データ.更新前処理連番_仕入伝票
                End With

                result = DeleteExpandItem(transaction, 拡張項目情報)
                If result.Code <> ResultType.成功 Then
                    Return result
                End If
            End If

            If 更新データ.更新前処理連番_入荷伝票 <> 0 Then
                With 拡張項目情報
                    .伝票種類 = I拡張項目入力情報型.伝票種類型.入荷
                    .連番 = 更新データ.更新前処理連番_入荷伝票
                End With

                result = DeleteExpandItem(transaction, 拡張項目情報)
                If result.Code <> ResultType.成功 Then
                    Return result
                End If
            End If

        End If

        Return result
    End Function

    Private Function InsertHANR001(ByRef transaction As DbTransaction,
                                   ByVal 更新データ As S90050_00.WorkTableUnitData,
                                   ByVal 伝票区分 As 伝票区分型
                ) As TextFileImport.IResult
        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Select Case 伝票区分
            Case 伝票区分型.仕入
                更新データ.取引ヘッダー = 更新データ.仕入ヘッダー
            Case 伝票区分型.入出庫
                更新データ.取引ヘッダー = 更新データ.入庫ヘッダー
            Case 伝票区分型.仕掛入庫
                更新データ.取引ヘッダー = 更新データ.仕掛入庫ヘッダー
                'A-CUST20190830↓
            Case 伝票区分型.入出庫_自分
                更新データ.取引ヘッダー = 更新データ.入庫ヘッダー_自分
            Case 伝票区分型.入出庫_相手
                更新データ.取引ヘッダー = 更新データ.出庫ヘッダー_相手
                'A-CUST20190830↑
            Case Else
                result.Code = ResultType.成功
                Return result
        End Select

        Dim myDataUpdater As New MyDataUpdater
        myDataUpdater.Initialize(Me, _myImportParam)
        result = myDataUpdater.InsertHANR001(transaction, 更新データ)

        Return result
    End Function

    Private Function InsertHANR002(ByRef transaction As DbTransaction,
                                   ByVal 更新データ As S90050_00.WorkTableUnitData,
                                   ByVal 伝票区分 As 伝票区分型
                ) As TextFileImport.IResult
        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim myDataUpdater As New MyDataUpdater
        myDataUpdater.Initialize(Me, _myImportParam)

        Dim データ件数 As Integer = 0
        Select Case 伝票区分
            Case 伝票区分型.仕入
                データ件数 = 更新データ.仕入伝票更新件数
            Case 伝票区分型.入出庫
                データ件数 = 更新データ.入庫伝票更新件数
            Case 伝票区分型.仕掛入庫
                データ件数 = 更新データ.仕掛入庫伝票更新件数
                'A-CUST20190830↓
            Case 伝票区分型.入出庫_自分
                データ件数 = 更新データ.入庫伝票更新件数_自分
            Case 伝票区分型.入出庫_相手
                データ件数 = 更新データ.出庫伝票更新件数_相手
                'A-CUST20190830↑
            Case Else
                result.Code = ResultType.成功
                Return result
        End Select

        For i As Integer = 0 To データ件数 - 1

            Select Case 伝票区分
                Case 伝票区分型.仕入
                    更新データ.取引明細(i) = 更新データ.仕入明細(i)
                Case 伝票区分型.入出庫
                    更新データ.取引明細(i) = 更新データ.入庫明細(i)
                Case 伝票区分型.仕掛入庫
                    更新データ.取引明細(i) = 更新データ.仕掛入庫明細(i)
                    'A-CUST20190830↓
                Case 伝票区分型.入出庫_自分
                    更新データ.取引明細(i) = 更新データ.入庫明細_自分(i)
                Case 伝票区分型.入出庫_相手
                    更新データ.取引明細(i) = 更新データ.出庫明細_相手(i)
                    'A-CUST20190830↑
                Case Else
                    result.Code = ResultType.成功
                    Return result
            End Select

            result = myDataUpdater.InsertHANR002(transaction, 更新データ, i)
            If result.Code <> ResultType.成功 Then
                Return result
            End If
        Next

        Return result
    End Function

    Private Function InsertSEIR010(ByRef transaction As DbTransaction,
                                   ByVal 更新データ As S90050_00.WorkTableUnitData
                ) As TextFileImport.IResult
        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim myDataUpdater As New MyDataUpdater
        myDataUpdater.Initialize(Me, _myImportParam)
        result = myDataUpdater.InsertSEIR010(transaction, 更新データ)

        Return result
    End Function

    Private Function InsertSEIR011(ByRef transaction As DbTransaction,
                                   ByVal 更新データ As S90050_00.WorkTableUnitData
                ) As TextFileImport.IResult
        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim myDataUpdater As New MyDataUpdater
        myDataUpdater.Initialize(Me, _myImportParam)

        For i As Integer = 0 To 更新データ.入荷伝票更新件数 - 1

            If 更新データ.入荷明細(i).R011003 = 0 Then Continue For

            result = myDataUpdater.InsertSEIR011(transaction, 更新データ, i)
            If result.Code <> ResultType.成功 Then
                Return result
            End If
        Next

        Return result
    End Function

    Private Function InsertSEIR008(ByRef transaction As DbTransaction,
                                   ByVal 更新データ As S90050_00.WorkTableUnitData
                ) As TextFileImport.IResult
        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim myDataUpdater As New MyDataUpdater
        myDataUpdater.Initialize(Me, _myImportParam)

        For i As Integer = 0 To 更新データ.入庫伝票更新件数 - 1
            result = myDataUpdater.InsertSEIR008(transaction, 更新データ, i)
            If result.Code <> ResultType.成功 Then
                Return result
            End If
        Next

        Return result
    End Function

    Private Function InsertSEIR114(ByRef transaction As DbTransaction,
                                   ByVal 更新データ As S90050_00.WorkTableUnitData
                ) As TextFileImport.IResult
        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim myDataUpdater As New MyDataUpdater
        myDataUpdater.Initialize(Me, _myImportParam)
        result = myDataUpdater.InsertSEIR114(transaction, 更新データ)

        Return result
    End Function

    Private Function DeleteSEIR114(ByRef transaction As DbTransaction,
                                   ByVal 更新データ As S90050_00.WorkTableUnitData
                ) As TextFileImport.IResult
        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim myDataUpdater As New MyDataUpdater
        myDataUpdater.Initialize(Me, _myImportParam)
        result = myDataUpdater.DeleteSEIR114(transaction, 更新データ)

        Return result
    End Function

    Private Function InsertSEIC056(ByRef transaction As DbTransaction,
                                   ByVal 更新データ As S90050_00.WorkTableUnitData
                ) As TextFileImport.IResult
        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim myDataUpdater As New MyDataUpdater
        myDataUpdater.Initialize(Me, _myImportParam)
        result = myDataUpdater.InsertSEIC056(transaction, 更新データ)

        Return result
    End Function

    Private Function UpdateSEIC056(ByRef transaction As DbTransaction,
                                   ByVal 更新データ As S90050_00.WorkTableUnitData
                ) As TextFileImport.IResult
        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim myDataUpdater As New MyDataUpdater
        myDataUpdater.Initialize(Me, _myImportParam)
        result = myDataUpdater.UpdateSEIC056(transaction, 更新データ)

        Return result
    End Function

    Private Function UpdateSEIM050(ByRef transaction As DbTransaction,
                                   ByVal 更新データ As S90050_00.WorkTableUnitData
                    ) As TextFileImport.IResult
        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim myDataUpdater As New MyDataUpdater
        myDataUpdater.Initialize(Me, _myImportParam)

        For i As Integer = 0 To 更新データ.製番マスタ更新件数 - 1

            Dim 発注残区分 As Integer = 0

            '発注伝票(更新後)の取得
            Dim dt As New DataTable
            If ReadHANR005PrimaryKey(transaction, dt, 更新データ.製番マスタ(i).M050011, 1) = ResultType.成功 Then
                発注残区分 = CInt(dt.Rows(0).Item("HANR005050"))
            Else
                Continue For
            End If

            Dim 製番マスタ As New ProgramLib.製番マスター型
            製番マスタ = 更新データ.製番マスタ(i)

            With 製番マスタ
                If 発注残区分 = 残区分型.残あり Then
                    .M050003 = 2    '2:手配
                    .M050038 = -1   '-1:SQLで更新対象外とする
                Else    '発注残なし
                    .M050003 = 3    '3:完了
                End If
            End With

            更新データ.製番マスタ(i) = 製番マスタ

            result = myDataUpdater.UpdateSEIM050(transaction, 更新データ, i)
            If result.Code <> ResultType.成功 Then
                Return result
            End If
        Next

        Return result
    End Function

    'A-20111025_3↓
    Private Function UpdateSEIM050_手入力製番(ByRef transaction As DbTransaction,
                                              ByVal 更新データ As S90050_00.WorkTableUnitData,
                                     Optional ByVal is修正後製番 As Boolean = True
                    ) As TextFileImport.IResult
        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim myDataUpdater As New MyDataUpdater
        myDataUpdater.Initialize(Me, _myImportParam)

        Dim 対象件数 As Integer = 0

        If is修正後製番 = True Then
            対象件数 = 更新データ.手入力製番マスタ更新件数
        Else
            対象件数 = 更新データ.既存手入力製番マスタ更新件数
        End If

        For i As Integer = 0 To 対象件数 - 1
            If is修正後製番 = True Then
                更新データ.製番マスタ_更新用 = 更新データ.手入力製番マスタ(i)
            Else
                更新データ.製番マスタ_更新用 = 更新データ.既存手入力製番マスタ(i)
            End If

            result = myDataUpdater.UpdateSEIM050_手入力製番(transaction, 更新データ)
            If result.Code <> ResultType.成功 Then
                Return result
            End If
        Next

        Return result
    End Function
    'A-20111025_3↑

    Private Function UpdateHANR004(ByRef transaction As DbTransaction,
                                   ByVal 更新データ As S90050_00.WorkTableUnitData
                ) As TextFileImport.IResult
        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim myDataUpdater As New MyDataUpdater
        myDataUpdater.Initialize(Me, _myImportParam)
        result = myDataUpdater.UpdateHANR004(transaction, 更新データ)

        Return result
    End Function

    Private Function UpdateHANR005(ByRef transaction As DbTransaction,
                                   ByVal 更新データ As S90050_00.WorkTableUnitData
                ) As TextFileImport.IResult
        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim myDataUpdater As New MyDataUpdater
        myDataUpdater.Initialize(Me, _myImportParam)

        For i As Integer = 0 To 更新データ.受注伝票更新件数 - 1
            result = myDataUpdater.UpdateHANR005(transaction, 更新データ, i)
            If result.Code <> ResultType.成功 Then
                Return result
            End If
        Next

        Return result
    End Function

    Private Function UpdateHANC015(ByRef transaction As DbTransaction,
                                   ByVal 伝票日付 As Integer
                ) As TextFileImport.IResult
        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim myDataUpdater As New MyDataUpdater
        myDataUpdater.Initialize(Me, _myImportParam)
        result = myDataUpdater.UpdateHANC015(transaction, 伝票日付)

        Return result
    End Function

    Private Function UpdateHANC021(ByRef transaction As DbTransaction,
                                   ByVal 処理連番 As Long
                ) As TextFileImport.IResult
        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim myDataUpdater As New MyDataUpdater
        myDataUpdater.Initialize(Me, _myImportParam)
        result = myDataUpdater.UpdateHANC021(transaction, 処理連番)

        Return result
    End Function

    Private Function UpdateHANC022(ByRef transaction As DbTransaction,
                                   ByVal 更新データ As WorkTableUnitData
                ) As TextFileImport.IResult
        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim myDataUpdater As New MyDataUpdater
        myDataUpdater.Initialize(Me, _myImportParam)
        result = myDataUpdater.UpdateHANC022(transaction, 更新データ)

        Return result
    End Function

    Private Function UpdateHANC023(ByRef transaction As DbTransaction,
                                   ByVal ロットNo As Decimal
                ) As TextFileImport.IResult 'A-2009/12/18_Ver7.40_LOT
        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim myDataUpdater As New MyDataUpdater
        myDataUpdater.Initialize(Me, _myImportParam)
        result = myDataUpdater.UpdateHANC023(transaction, ロットNo)

        Return result
    End Function

    Private Function UpdateZAIR001(ByRef transaction As DbTransaction,
                                   ByVal 処理連番 As Long
                ) As TextFileImport.IResult     'A-2008/07/18_Ver7.30_SAIMU
        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim myDataUpdater As New MyDataUpdater
        myDataUpdater.Initialize(Me, _myImportParam)
        result = myDataUpdater.UpdateZAIR001(transaction, 処理連番)

        Return result
    End Function

    Private Function UpdateZAIR101(ByRef transaction As DbTransaction,
                                   ByVal 処理連番 As Long
                 ) As TextFileImport.IResult    'A-2010/09/13_Ver7.4X_ZAISHONIN
        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim myDataUpdater As New MyDataUpdater
        myDataUpdater.Initialize(Me, _myImportParam)
        result = myDataUpdater.UpdateZAIR101(transaction, 処理連番)

        Return result
    End Function

    Private Function InsertHANR031(ByRef transaction As DbTransaction,
                                   ByVal 更新データ As S90050_00.WorkTableUnitData
                ) As TextFileImport.IResult     'A-2008/07/18_Ver7.30_SHIHARAI
        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim myDataUpdater As New MyDataUpdater
        myDataUpdater.Initialize(Me, _myImportParam)

        For i As Integer = 0 To 更新データ.支払予定行数 - 1
            'D-20121217_Ver7.50_1↓
            ''仕入(支払)金額＝０のデータは更新しない
            'If 更新データ.支払予定(i).R031012 = 0 Then
            '    GoTo InsertHANR031_次明細
            'End If
            'D-20121217_Ver7.50_1↑
            'A-20121217_Ver7.50_1↓
            If 更新データ.外貨取引先 = False Then
                '仕入(支払)金額＝０のデータは更新しない
                If 更新データ.支払予定(i).R031012 = 0 Then
                    GoTo InsertHANR031_次明細
                End If
            Else
                '仕入(支払)金額(外貨)＝０のデータは更新しない
                If 更新データ.支払予定(i).R031S002 = 0 Then
                    GoTo InsertHANR031_次明細
                End If
            End If
            'A-20121217_Ver7.50_1↑

            If 更新データ.支払単位 = SEI.LIB.ControlInfoC001.支払管理定義型.支払管理単位型.伝票単位 Then
                GoTo InsertHANR031_更新実行
            End If

            '明細消費税ありの場合は消費税行は更新対象外
            If 更新データ.仕入ヘッダー.R001022 = 3 AndAlso 更新データ.仕入明細(i).R002005 = 1 Then
                GoTo InsertHANR031_次明細
            End If
            '仕入明細の金額＋外税＝０の場合は更新対象外
            If 更新データ.仕入明細(i).R002027 + 更新データ.仕入明細(i).R002050 = 0 Then
                GoTo InsertHANR031_次明細
            End If

InsertHANR031_更新実行:
            result = myDataUpdater.InsertHANR031(transaction, 更新データ, i)
            If result.Code <> ResultType.成功 Then
                Return result
            End If

InsertHANR031_次明細:
        Next

        Return result
    End Function

    Private Function DeleteHANR031(ByRef transaction As DbTransaction,
                                   ByVal 伝票処理連番 As Long
                ) As TextFileImport.IResult     'A-2008/07/18_Ver7.30_SHIHARAI
        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim myDataUpdater As New MyDataUpdater
        myDataUpdater.Initialize(Me, _myImportParam)
        result = myDataUpdater.DeleteHANR031(transaction, 伝票処理連番)

        Return result
    End Function

    ''' <summary>
    ''' 拡張登録処理
    ''' </summary>
    ''' <param name="transaction"></param>
    ''' <param name="拡張項目情報"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function InsertExpandItem(ByVal transaction As DbTransaction,
                                      ByVal 拡張項目情報 As I拡張項目入力情報型) As IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase
        Dim expandResult As ISEIExpandItemEntryUpdater.結果型

        Dim 拡張更新 As ISEIExpandItemEntryUpdater
        拡張更新 = CommonFactory.CreateInstance(Of ISEIExpandItemEntryUpdater)(Me, GetType(SEIExpandItemEntryUpdater))
        拡張更新.Initialize(Me)

        expandResult = 拡張更新.InsertExpandItem(transaction, 拡張項目情報)

        Select Case expandResult
            Case ISEIExpandItemEntryUpdater.結果型.成功
                result.Code = ResultType.成功

            Case ISEIExpandItemEntryUpdater.結果型.定義情報変更あり
                result.Code = ResultType.他で更新済
                result.TableID = "HANZ030"

            Case ISEIExpandItemEntryUpdater.結果型.一意制約違反
                result.Code = ResultType.一意制約違反

            Case ISEIExpandItemEntryUpdater.結果型.ロック中
                result.Code = ResultType.ロック中

        End Select

        Return result

    End Function

    ''' <summary>
    ''' 拡張削除処理
    ''' </summary>
    ''' <param name="transaction"></param>
    ''' <param name="拡張項目情報"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function DeleteExpandItem(ByVal transaction As DbTransaction,
                                      ByVal 拡張項目情報 As I拡張項目入力情報型) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase
        Dim expandResult As ISEIExpandItemEntryUpdater.結果型

        Dim 拡張更新 As ISEIExpandItemEntryUpdater
        拡張更新 = CommonFactory.CreateInstance(Of ISEIExpandItemEntryUpdater)(Me, GetType(SEIExpandItemEntryUpdater))
        拡張更新.Initialize(Me)

        expandResult = 拡張更新.DeleteExpandItem(transaction, 拡張項目情報)

        Select Case expandResult
            Case ISEIExpandItemEntryUpdater.結果型.成功
                result.Code = ResultType.成功

            Case ISEIExpandItemEntryUpdater.結果型.定義情報変更あり
                result.Code = ResultType.他で更新済
                result.TableID = "HANZ030"

            Case ISEIExpandItemEntryUpdater.結果型.一意制約違反
                result.Code = ResultType.一意制約違反

            Case ISEIExpandItemEntryUpdater.結果型.ロック中
                result.Code = ResultType.ロック中

        End Select

        Return result

    End Function

    ''' <summary>
    ''' 製造実績更新処理
    ''' </summary>
    ''' <param name="transaction">トランザクション情報</param>
    ''' <returns>エラー情報</returns>
    ''' <remarks></remarks>
    Private Function Update製造実績更新部品(ByVal transaction As DbTransaction,
                                            ByRef 更新データ As S90050_00.WorkTableUnitData) As IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim _settingInfo As IDictionary = New Hashtable()
        Dim handler As New DataHandlerBase
        handler.Initialize(Me.SettingInfo)
        Dim seizoJissekiGetter As OSK.X1.SEI.LIB.SeizoJisseki.DataAccess.SeizoJissekiGetter = New OSK.X1.SEI.LIB.SeizoJisseki.DataAccess.SeizoJissekiGetter    'X1変換Tool-20170508
        seizoJissekiGetter.Initialize(handler)

        Dim conditionParam As New OSK.X1.SEI.LIB.SeizoJisseki.ConditionParam    'X1変換Tool-20170508

        With conditionParam
            .transaction = transaction
            If MyBase._textDataChecker.DB更新Mode = ITextDataChecker.DB更新Mode型.INSERT Then
                .処理区分 = [LIB].SeizoJisseki.処理区分型.登録
            Else
                .処理区分 = [LIB].SeizoJisseki.処理区分型.修正
            End If
            .処理連番 = 更新データ.製造実績部品関連.処理連番
            .手配番号 = 更新データ.製造実績部品関連.手配番号
            .使用可能処理連番 = 更新データ.製造実績部品関連.使用可能処理連番
            .構成品区分 = CType(更新データ.製造実績部品関連.構成品出庫区分, [LIB].SeizoJisseki.構成品出庫区分型)
            '.構成品区分 = 構成品出庫区分型.自動
            .製造出庫情報 = 更新データ.製造実績更新_製造出庫
            .個別出庫情報 = 更新データ.製造実績更新_個別出庫
            .完成入庫情報 = 更新データ.製造実績更新_完成入庫
        End With

        Dim ret As New SeizoJissekiInfo
        Dim resultBuhin As Long = 0
        resultBuhin = seizoJissekiGetter.SeizoJisseki_Ukeire(conditionParam, ret)

        Select Case resultBuhin
            Case ResultType.成功
                result.Code = ResultType.成功

                Dim HANC021 As ProgramLib.連番管理テーブル型 = 更新データ.連番管理テーブル

                '↓A-20111105_1
                If CLng(ret.更新件数) <> 0 Then
                    HANC021.C021002 = 更新データ.製造実績部品関連.使用可能処理連番 + CLng(ret.更新件数) - 1 'A-20111105_1 '発行元番号＋処理件数を連番取得結果として戻しておく。
                    If HANC021.C021002 > 9999999999 Then
                        Dim ｵｰﾊﾞｰﾌﾛｰ件数 As Long = 9999999999 - HANC021.C021002
                        HANC021.C021002 = -1 * ｵｰﾊﾞｰﾌﾛｰ件数
                    End If
                    更新データ.連番管理テーブル = HANC021

                    Dim HANC022 As ProgramLib.伝票番号管理テーブル型 = 更新データ.伝票番号管理テーブル
                    HANC022.C022A002 += CInt(ret.更新件数) - 1
                    If HANC022.C022A002 > 99999999 Then
                        Dim ｵｰﾊﾞｰﾌﾛｰ件数 As Integer = 99999999 - HANC022.C022A002
                        HANC022.C022A002 = -1 * ｵｰﾊﾞｰﾌﾛｰ件数
                    End If
                    更新データ.伝票番号管理テーブル = HANC022
                    '3件以上の更新が発生している場合は、みなし移動ありと判断して入出庫用のストアドを起動する。
                    If CLng(ret.更新件数) >= 3 Then

                        Dim W_INSERT_出庫_移動有 As ProgramLib.ストアドパラメータ_出庫 = 更新データ.ストアドパラメータ_INSERT
                        Dim W_INSERT_入庫_移動有 As ProgramLib.ストアドパラメータ_出庫 = 更新データ.ストアドパラメータ_INSERT
                        W_INSERT_出庫_移動有.処理連番 = 更新データ.製造実績部品関連.使用可能処理連番
                        W_INSERT_入庫_移動有.処理連番 = W_INSERT_出庫_移動有.処理連番 + 1

                        更新データ.ストアドパラメータ_INSERT_出庫_移動有 = W_INSERT_出庫_移動有
                        更新データ.ストアドパラメータ_INSERT_入庫_移動有 = W_INSERT_入庫_移動有
                    End If

                End If

                '↑A-20111105_1

                ''↓D-20111105_1
                'HANC021.C021002 += CLng(ret.更新件数)
                'If HANC021.C021002 > 9999999999 Then
                '    Dim ｵｰﾊﾞｰﾌﾛｰ件数 As Long = 9999999999 - HANC021.C021002
                '    HANC021.C021002 = -1 * ｵｰﾊﾞｰﾌﾛｰ件数
                'End If
                '更新データ.連番管理テーブル = HANC021
                ''↑D-20111105_1


            Case ResultType.ロック中
                result.Code = ResultType.ロック中

            Case Else
                result.Code = ResultType.想定された失敗

        End Select

Update拡張項目_End:

        Return result

    End Function

    'A-CUST20190830↓
    Private Function UpdateHANW091(ByRef transaction As DbTransaction,
                       ByVal 更新データ As String,
                       ByVal 行番号 As Integer,
                       ByVal 分割コード As String
                        ) As TextFileImport.IResult
        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim myDataUpdater As New MyDataUpdater
        myDataUpdater.Initialize(Me, _myImportParam)

        result = myDataUpdater.UpdateHANW091(transaction, 更新データ, 行番号, 分割コード)
        If result.Code <> ResultType.成功 Then
            Return result
        End If

        Return result
    End Function

    Private Function UpdateSEIRA01(ByRef transaction As DbTransaction,
                                       ByVal 更新データ As S90050_00.WorkTableUnitData
                        ) As TextFileImport.IResult
        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim myDataUpdater As New MyDataUpdater
        myDataUpdater.Initialize(Me, _myImportParam)

        Dim resultDB As New Foundation.ResultType
        Dim resultTable As New DataTable

        'D-CUST20190830↓ '2020/08/06
        'resultDB = ReadHANR005PrimaryKey(transaction, resultTable,
        '                                 CLng(更新データ.仕入明細(0).R002011), 1)
        'D-CUST20190830↑ '2020/08/06
        'A-CUST20190830↓ '2020/08/06
        resultDB = ReadHAN発注内訳伝票チェック(transaction,
                                     resultTable,
                                     CLng(更新データ.仕入明細(0).R002011),
                                     1,
                                     CInt(Val(更新データ.仕入明細(0).拡張項目入力情報.拡張項目(16))))
        'A-CUST20190830↑ '2020/08/06

        Select Case resultDB
            Case ResultType.成功
                Dim 内訳発注残区分 As Integer
                If CDec(resultTable.Rows(0).Item("SEIRA01009")) -
                   CDec(resultTable.Rows(0).Item("SEIRA01011")) -
                   CDec(更新データ.仕入明細(0).R002025) <= 0 Then
                    内訳発注残区分 = 1  '1:残無し
                Else
                    内訳発注残区分 = 0  '0:残有り
                End If

                result = myDataUpdater.UpdateSEIRA01(transaction, 更新データ, 内訳発注残区分)
                If result.Code <> ResultType.成功 Then
                    Return result
                End If

            Case Else
                Return result
        End Select

        Return result
    End Function

    '入出庫予定消し込み
    Private Function Update入出庫予定(ByRef transaction As DbTransaction,
                                       ByVal 更新データ As S90050_00.WorkTableUnitData
                        ) As TextFileImport.IResult
        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim myDataUpdater As New MyDataUpdater
        myDataUpdater.Initialize(Me, _myImportParam)

        Dim ヘッダー更新用残区分 As Integer = 1

        Dim resultDB As New Foundation.ResultType
        Dim resultTable As New DataTable
        Dim 番号 As Long = 0
        Dim 明細件数 As Integer
        If 更新データ.取込種別 = 伝票種別型._予定入庫_預入庫 Then
            明細件数 = 更新データ.入庫伝票更新件数_自分
        Else
            明細件数 = 更新データ.出庫伝票更新件数_相手
        End If



        '明細更新
        For i As Integer = 0 To 明細件数 - 1

            Dim 拡張項目入力情報M As I拡張項目入力情報型

            更新データ.取引明細(i) = 更新データ.入庫明細_自分(i)
            拡張項目入力情報M = 更新データ.入庫明細_自分(i).拡張項目入力情報

            Dim 行番号 As Integer = 0
            番号 = CLng(拡張項目入力情報M.拡張項目(19))
            行番号 = CInt(拡張項目入力情報M.拡張項目(20))

            resultDB = ReadSEIRA03PrimaryKey(transaction, resultTable,
                                             番号, 行番号)

            Select Case resultDB
                Case ResultType.成功
                    Dim 残区分 As Integer
                    If CDec(resultTable.Rows(0).Item("SEIRA03018")) -
                       CDec(resultTable.Rows(0).Item("SEIRA03024")) -
                       CDec(更新データ.取引明細(i).R002025) <= 0 Then
                        残区分 = 1  '1:残無し
                    Else
                        残区分 = 0  '0:残有り
                        ヘッダー更新用残区分 = 0
                    End If

                    result = myDataUpdater.UpdateSEIRA02RA03(transaction, 更新データ, 残区分, 1, 番号, 行番号, i)
                    If result.Code <> ResultType.成功 Then
                        Return result
                    End If

                Case Else
                    Return result
            End Select

        Next

        '全明細を読込、残区分の判定を行う。
        resultDB = ReadSEIRA03PrimaryKey(transaction, resultTable, 番号)

        For i As Integer = 0 To resultTable.Rows.Count - 1
            Select Case resultDB
                Case ResultType.成功
                    If CInt(resultTable.Rows(i).Item("SEIRA03028")) = 0 Then
                        ヘッダー更新用残区分 = 0  '0:残有り
                    End If

                Case Else
                    Return result
            End Select
        Next

        'ヘッダー更新
        Dim 拡張項目入力情報H As I拡張項目入力情報型
        resultDB = New Foundation.ResultType
        resultTable = New DataTable

        更新データ.取引ヘッダー = 更新データ.入庫ヘッダー_自分
        拡張項目入力情報H = 更新データ.入庫ヘッダー_自分.拡張項目入力情報

        番号 = CLng(拡張項目入力情報H.拡張項目(20))

        resultDB = ReadSEIRA02PrimaryKey(transaction, resultTable, 番号)

        Select Case resultDB
            Case ResultType.成功
                result = myDataUpdater.UpdateSEIRA02RA03(transaction, 更新データ, ヘッダー更新用残区分, 0, 番号, 0, )
                If result.Code <> ResultType.成功 Then
                    Return result
                End If

            Case Else
                Return result
        End Select

        Return result
    End Function
    'A-CUST20190830↑

    'A-20121217_Ver7.50_2↓
    ''' <summary>
    ''' 在庫引当更新
    ''' </summary>
    ''' <param name="transaction"></param>
    ''' <param name="更新データ"></param>
    ''' <param name="処理区分"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function Is在庫引当更新(ByVal transaction As DbTransaction,
                                    ByRef 更新データ As S90050_00.WorkTableUnitData,
                                    ByVal 処理区分 As 処理区分型) As IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        '*** 更新対象データ
        If 処理区分 = 処理区分型.登録 Then
            If 更新データ.在庫引当更新対象 = False Then
                Return result
            End If
        Else
            If 更新データ.在庫引当解除対象 = False Then
                Return result
            End If
        End If

        '------------------------------
        '   在庫引当更新
        '------------------------------
        If _在庫引当更新 Is Nothing Then
            _在庫引当更新 = CommonFactory.CreateInstance(Of IHikiateKoushinGetter)(Me, GetType(HikiateKoushinGetter))
            _在庫引当更新.Initialize(Me)
        End If

        Dim HikiateKoushinInfo As New [LIB].HikiateKoushin.HikiateKoushinInfo
        Dim condition As New [LIB].HikiateKoushin.ConditionParam
        With condition
            .InitInfo = New Hashtable
            .transaction = transaction
            .呼出元種別 = [LIB].HikiateKoushin.呼出元種別型.受入処理＿親品目受入    'X1変換Tool-20170508
            If 処理区分 = 処理区分型.登録 Then
                .処理区分 = [LIB].HikiateKoushin.処理区分型.引当
            Else
                .処理区分 = [LIB].HikiateKoushin.処理区分型.引当解除
            End If
            If 更新データ.需要元受注伝票存在 = True Then
                .引当区分 = [LIB].HikiateKoushin.引当区分型.受注
            Else
                .引当区分 = [LIB].HikiateKoushin.引当区分型.従属需要
            End If
            If 更新データ.発注区分 = 1 Then
                .手配区分 = [LIB].HikiateKoushin.手配区分型.購買
            Else
                .手配区分 = [LIB].HikiateKoushin.手配区分型.手配確定
            End If
            .自動引当 = [LIB].HikiateKoushin.自動引当型.行わない

            If 更新データ.発注区分 = 1 Then
                .連番 = 更新データ.在庫引当更新_連番
                .行＿展開順序番号 = 更新データ.在庫引当更新_行    'X1変換Tool-20170508
            Else
                Dim 処理連番 As Long = 0
                If 更新データ.入荷伝票更新 = True Then
                    処理連番 = 更新データ.入荷ヘッダー.R010005
                Else
                    処理連番 = 更新データ.仕入ヘッダー.R001006
                End If
                Dim 工程明細 As New DataTable
                If ReadSEIR057工程明細取得(transaction, 工程明細, 処理連番) <> ResultType.成功 Then
                    result.Code = ResultType.レコード無し
                    Return result
                Else
                    '受注伝票が存在しない場合
                    If 工程明細.Rows.Count = 0 Then
                        result.Code = ResultType.レコード無し
                        Return result
                    Else
                        .連番 = CLng(工程明細.Rows(0).Item("SEIR057004"))
                    End If
                End If
                .行＿展開順序番号 = 0    'X1変換Tool-20170508
            End If
            If 処理区分 = 処理区分型.登録 Then
                .在庫引当情報 = 更新データ.在庫引当情報
            End If
        End With

        Dim 更新Result As ResultType = ResultType.成功
        更新Result = CType(_在庫引当更新.Hikiate_Koushin(condition, HikiateKoushinInfo), ResultType)
        Select Case 更新Result
            Case ResultType.成功
                result.Code = ResultType.成功
            Case ResultType.レコード無し
                result.Code = ResultType.レコード無し
            Case ResultType.ファイル無し
                result.Code = ResultType.ファイル無し
            Case ResultType.ロック中
                result.Code = ResultType.ロック中
            Case ResultType.一意制約違反
                result.Code = ResultType.一意制約違反
            Case ResultType.想定された失敗
                result.Code = ResultType.想定された失敗
            Case ResultType.他で更新済
                result.Code = ResultType.他で更新済
            Case ResultType.同時実行不可
                result.Code = ResultType.同時実行不可
        End Select

        Return result
    End Function
    'A-20121217_Ver7.50_2↑

    'A-20121217_Ver7.50_3↓
    ''' <summary>
    ''' 在庫引当更新(製造出庫品目の引当解除)
    ''' </summary>
    ''' <param name="transaction"></param>
    ''' <param name="更新データ"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function Is在庫引当更新(ByVal transaction As DbTransaction,
                                    ByRef 更新データ As S90050_00.WorkTableUnitData) As IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        '構成品出庫=しない 場合は対象外とする
        If 更新データ.製造実績更新 = False Then
            Return result
        End If

        Dim ResultData As New DataTable
        Dim 連番 As Long = -1
        If 更新データ.入荷伝票更新 = True Then
            連番 = 更新データ.入荷ヘッダー.R010005
        Else
            連番 = 更新データ.仕入ヘッダー.R001006
        End If

        result.Code = ReadHANR001出庫伝票取得(transaction, ResultData, 連番)
        Select Case result.Code
            Case ResultType.成功
                'データが存在する場合、以下処理を行う
            Case ResultType.レコード無し
                result.Code = ResultType.成功
                Return result
            Case Else
                Return result
        End Select

        '------------------------------
        '   在庫引当更新
        '------------------------------
        If _在庫引当更新 Is Nothing Then
            _在庫引当更新 = CommonFactory.CreateInstance(Of IHikiateKoushinGetter)(Me, GetType(HikiateKoushinGetter))
            _在庫引当更新.Initialize(Me)
        End If

        For i As Integer = 0 To ResultData.Rows.Count - 1
            '
            For row As Integer = 0 To 更新データ.製造実績更新_製造出庫.Rows.Count - 1
                '展開順序番号の比較により、行位置を把握する
                If CType(ResultData.Rows(i).Item("HANR002A029"), Integer) <> CType(更新データ.製造実績更新_製造出庫.Rows(row).Item("行"), Integer) Then
                    Continue For
                End If

                '引当状態=0:対象外 は更新対象外
                If CType(更新データ.製造実績更新_製造出庫.Rows(row).Item("引当状態"), Integer) = 0 Then
                    Continue For
                End If

                Exit For
            Next

            Dim HikiateKoushinInfo As New [LIB].HikiateKoushin.HikiateKoushinInfo
            Dim condition As New [LIB].HikiateKoushin.ConditionParam
            With condition
                .InitInfo = New Hashtable
                .transaction = transaction
                .呼出元種別 = [LIB].HikiateKoushin.呼出元種別型.受入処理＿子品目出庫    'X1変換Tool-20170508
                .処理区分 = [LIB].HikiateKoushin.処理区分型.引当解除
                .引当区分 = [LIB].HikiateKoushin.引当区分型.従属需要
                .手配区分 = [LIB].HikiateKoushin.手配区分型.手配確定
                .自動引当 = [LIB].HikiateKoushin.自動引当型.行わない
                .連番 = 更新データ.製造実績部品関連.製造出庫連番
                .行＿展開順序番号 = CType(ResultData.Rows(i).Item("HANR002006"), Integer)    'X1変換Tool-20170508
            End With

            Dim 更新Result As ResultType = ResultType.成功
            更新Result = CType(_在庫引当更新.Hikiate_Koushin(condition, HikiateKoushinInfo), ResultType)
            Select Case 更新Result
                Case ResultType.成功
                    result.Code = ResultType.成功
                Case ResultType.レコード無し
                    result.Code = ResultType.レコード無し
                Case ResultType.ファイル無し
                    result.Code = ResultType.ファイル無し
                Case ResultType.ロック中
                    result.Code = ResultType.ロック中
                Case ResultType.一意制約違反
                    result.Code = ResultType.一意制約違反
                Case ResultType.想定された失敗
                    result.Code = ResultType.想定された失敗
                Case ResultType.他で更新済
                    result.Code = ResultType.他で更新済
                Case ResultType.同時実行不可
                    result.Code = ResultType.同時実行不可
            End Select

            If result.Code <> ResultType.成功 Then Exit For
        Next

        Return result
    End Function
    'A-20121217_Ver7.50_3↑

    'A-20121217_Ver7.50_2↓
    Private Function ReadSEIR057工程明細取得(ByRef transaction As DbTransaction,
                                             ByRef 取得したデータ As DataTable,
                                             ByVal 処理連番 As Long) As Foundation.ResultType

        Dim myDataReader As New MyDataReader
        myDataReader.Initialize(Me, _myImportParam)
        Return myDataReader.ReadSEIR057工程明細取得(transaction, 取得したデータ, 処理連番)

    End Function
    'A-20121217_Ver7.50_2↑

#End Region
    'A-20110912_1↓
#Region "仕掛在庫更新部品"

    Private Function Update仕掛在庫更新部品(ByVal transaction As DbTransaction,
                                            ByVal 更新データ As S90050_00.WorkTableUnitData,
                                            ByVal mode As 処理区分型,
                                            ByRef 使用可能連番 As Decimal) As IResult


        Dim renBan As Long = 0
        Dim denBan As Long = 0
        Dim tehaiNo As Long = 0
        Dim SiyouKanouRenban As Decimal = 0
        Dim resultBuhin As Long = 0
        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        renBan = 更新データ.入荷ヘッダー.R010005
        tehaiNo = 更新データ.入荷明細(0).R011075
        denBan = 更新データ.入荷ヘッダー.R010006

        If mode <> 処理区分型.削除 Then
            SiyouKanouRenban = 使用可能連番
        End If

        Dim _settingInfo As IDictionary = New Hashtable()
        Dim handler As New DataHandlerBase
        handler.Initialize(Me.SettingInfo)
        Dim ShikakariKoshinGetter As OSK.X1.SEI.LIB.ShikakariKoshin.DataAccess.ShikakariKoshinGetter = New OSK.X1.SEI.LIB.ShikakariKoshin.DataAccess.ShikakariKoshinGetter    'X1変換Tool-20170508
        ShikakariKoshinGetter.Initialize(handler)

        Dim conditionParam As New OSK.X1.SEI.LIB.ShikakariKoshin.ConditionParam    'X1変換Tool-20170508

        With conditionParam

            '--ＩＮパラメータ--
            'transaction
            .transaction = transaction
            '呼出区分	1:受入処理
            .呼出区分 = [LIB].ShikakariKoshin.呼出区分型.受入処理
            '処理区分	1:登録 2:修正 3:削除
            .処理区分 = CType(mode, [LIB].ShikakariKoshin.処理区分型)
            '処理連番	仕入データの処理連番
            .処理連番 = renBan
            '手配番号	入荷データの手配番号
            .手配番号 = tehaiNo
            '伝票番号	入荷データの伝票№
            .伝票番号 = denBan
            '使用可能処理連番	連番管理テーブル.処理連番
            .使用可能処理連番 = CLng(SiyouKanouRenban)

            '--ＯＵＴパラメータ--
            '更新件数	更新件数を返す。（ ※処理連番更新用 ）

            'エラー情報	エラー情報を返す。
            '　・エラーパラメータ
            '　・更新失敗テーブルなど

        End With

        Dim ret As New ShikakariKoshinInfo
        resultBuhin = ShikakariKoshinGetter.Shikakari_Koshin(conditionParam, ret)

        Select Case resultBuhin
            Case ResultType.成功
                result.Code = ResultType.成功
                '仕掛更新部品からの更新件数を処理連番に加算する。
                If mode <> 処理区分型.削除 Then
                    使用可能連番 = 使用可能連番 + CDec(ret.更新件数)
                End If
            Case ResultType.ロック中
                result.Code = ResultType.ロック中
            Case ResultType.レコード無し
                '仕掛在庫更新部品レコード無しが返ってきた場合、「他で削除済みです。」を表示する。
                'result.Code = ResultType.レコード無し
                result.Code = ResultType.成功
            Case ResultType.一意制約違反
                result.Code = ResultType.一意制約違反
            Case Else
                result.Code = ResultType.想定された失敗
        End Select

Update仕掛在庫更新部品_End:

        Return result


    End Function
#End Region
    'A-20110912_1↑
#Region "内部メソッド"  'A-2008/07/18_Ver7.30_SAIMU

    ''' <summary>
    ''' 仕訳伝票更新前チェック(会計債務管理)
    ''' </summary>
    ''' <returns>False：仕訳更新対象外／True：仕訳更新対象</returns>
    ''' <remarks></remarks>
    Private Function 仕訳更新前チェック_会計債務(ByRef transaction As DbTransaction,
                                                 ByVal 更新データ As S90050_00.WorkTableUnitData) As Boolean   'A-2008/07/18_Ver7.30_SAIMU

        If _myImportParam.Myコントロール情報.My会計オプション.会計債務管理 = False Then
            Return False
        End If

        If Is仕訳更新判定_会計債務(更新データ) = False Then
            Return False
        End If

        Dim 仕訳ヘッダー情報 As New DataTable
        If ReadZAIR001UpdateLock(transaction, 仕訳ヘッダー情報, 更新データ.既存仕入ヘッダー.R001060) <> ResultType.成功 Then
            Return False
        End If

        If Check仕訳伝票日付_会計債務(transaction, CInt(仕訳ヘッダー情報.Rows(0).Item("ZAIR001001"))) = False Then
            Return False
        End If

        Return True
    End Function

    ''' <summary>
    ''' 仮仕訳伝票更新前チェック(会計債務管理)
    ''' </summary>
    ''' <returns>False：仮仕訳更新対象外／True：仮仕訳更新対象</returns>
    ''' <remarks></remarks>
    Private Function 仮仕訳更新前チェック_会計債務(ByRef transaction As DbTransaction,
                                                   ByVal 更新データ As S90050_00.WorkTableUnitData) As Boolean 'A-2010/09/13_Ver7.4X_ZAISHONIN

        If _myImportParam.Myコントロール情報.My会計オプション.会計債務管理 = False Then
            Return False
        End If

        If _myImportParam.Myコントロール情報.My会計伝票承認.会計伝票承認機能 = False Then
            Return False
        End If

        If Is仕訳更新判定_会計債務(更新データ) = False Then
            Return False
        End If

        Dim 仮仕訳ヘッダー情報 As New DataTable
        If ReadZAIR101UpdateLock(transaction, 仮仕訳ヘッダー情報, 更新データ.既存仕入ヘッダー.R001060) <> ResultType.成功 Then
            Return False
        End If

        If Check仕訳伝票日付_会計債務(transaction, CInt(仮仕訳ヘッダー情報.Rows(0).Item("ZAIR101001"))) = False Then
            Return False
        End If

        Return True
    End Function

    ''' <summary>
    ''' 仕訳の更新を行うか判定(会計債務管理)
    ''' </summary>
    ''' <returns>False：更新しない／True：更新する</returns>
    ''' <remarks></remarks>
    Private Function Is仕訳更新判定_会計債務(ByVal 更新データ As S90050_00.WorkTableUnitData) As Boolean   'A-2008/07/18_Ver7.30_SAIMU

        If _myImportParam.Myコントロール情報.My会計オプション.会計債務管理 = False Then
            Return False
        End If

        Select Case MyBase._textDataChecker.DB更新Mode
            Case ITextDataChecker.DB更新Mode型.UPDATE

            Case Else
                Return False
        End Select

        If 更新データ.既存仕入ヘッダー.R001059 <> 2 Then
            Return False
        End If

        If 更新データ.既存仕入ヘッダー.R001060 = 0 Then
            Return False
        End If

        If 更新データ.既存仕入ヘッダー.R001018 = 1 AndAlso
           更新データ.仕入ヘッダー.R001018 = 1 Then
            Return False
        End If

        Return True

    End Function

    ''' <summary>
    ''' 仕訳伝票日付のチェック(会計債務管理)
    ''' </summary>
    ''' <returns>False：有効期間外／True：有効期間内</returns>
    ''' <remarks></remarks>
    Private Function Check仕訳伝票日付_会計債務(ByRef transaction As DbTransaction,
                                                ByVal 仕訳伝票日付 As Integer) As Boolean   'A-2008/07/18_Ver7.30_SAIMU

        If _myImportParam.Myコントロール情報.My会計オプション.会計債務管理 = False Then
            Return False
        End If

        Dim libChecker_Zai As ILibChecker_Zai
        'libChecker_Zai = OSK.X1.Foundation.GeneralFactory(Of ILibChecker_Zai).CreateInstance(Me, "OSK.X1.HAN.S90050_00.SUB1.DA", "LibChecker_Zai")    'X1変換Tool-20170508
        libChecker_Zai = OSK.X1.Foundation.GeneralFactory(Of ILibChecker_Zai).CreateInstance(Me, "OSK.X1.SEI.S90050_00.SUB1.DA", "LibChecker_Zai")    'X1変換Tool-20170508
        libChecker_Zai.Initialize(Me)
        libChecker_Zai.MyImportParam = CType(_myImportParam, S90050_00.ImportParam)

        Select Case libChecker_Zai.DoDateCheck(transaction, 仕訳伝票日付.ToString)
            Case ILibChecker_Zai.会計チェック結果型.成功

            Case ILibChecker_Zai.会計チェック結果型.日付範囲エラー
                Return False
        End Select

        Return True

    End Function

    ''' <summary>
    ''' 新規ロットの自動採番を行うか判定
    ''' </summary>
    ''' <returns>True：自動採番を行う／False：自動採番を行わない</returns>
    ''' <remarks></remarks>
    Private Function IsロットNo自動採番判定() As Boolean    'A-2009/12/18_Ver7.40_LOT

        'ロットNo採番方法が連番の時以外は対象外
        If _myImportParam.Myコントロール情報.Myロット管理.ロットNo採番方法 <> ロット管理定義型.ロットNo採番方法型.連番 Then
            Return False
        End If

        '条件指定が「新規に採番する」以外は対象外
        If _myImportParam.ロットNo採番 <> S90050_00.ImportParam.ロットNo採番型.新規に採番する Then
            Return False
        End If

        Return True
    End Function

    ''' <summary>
    ''' ロットマスターの登録を行うか判定
    ''' </summary>
    ''' <returns>False：更新しない／True：更新する</returns>
    ''' <remarks></remarks>
    Private Function Isロットマスター登録判定(ByRef transaction As DbTransaction,
                                              ByVal 更新データ As S90050_00.WorkTableUnitData,
                                              ByVal line As Integer) As Boolean     'A-2009/12/18_Ver7.40_LOT

        If _myImportParam.Myコントロール情報.Myオプション区分.ロット管理 = False Then
            Return False
        End If

        '新規ロット以外は対象外
        If 更新データ.仕入明細(line).ロット更新情報.新規ロット = False Then
            Return False
        End If

        'ロット№の自動採番を行わない場合は登録対象
        If IsロットNo自動採番判定() = False Then
            Return True
        End If

        '新規採番時
        If 更新データ.仕入明細(line).ロット更新情報.強制諸口ロット = True Then
            '新規採番時は新規ロット重複チェックを行わないが、返品／値引時は強制的に諸口ロット固定にする関係上
            '同一の新規ロットが重複する可能性があるため、マスター存在チェックを行う
            Dim resultRead As Foundation.ResultType = New Foundation.ResultType
            Dim resultDT As New DataTable
            Dim 読込キー As New ProgramLib.ロットマスター型
            With 読込キー
                .初期化()
                .M045001 = 更新データ.仕入明細(line).R002019
                .M045002 = 更新データ.仕入明細(line).R002066
                .M045003 = 更新データ.仕入明細(line).R002067
                .M045004 = 更新データ.仕入明細(line).R002068
                .M045005 = 更新データ.仕入明細(line).R002086
            End With
            resultRead = ReadHANM045PrimaryKey(transaction, resultDT, 読込キー)
            Select Case resultRead
                Case ResultType.レコード無し
                    Return True
                Case Else
                    Return False
            End Select
        End If

        Return True

    End Function

#End Region

#Region "読込"

    Private Function ReadHANC015UpdateLock(ByRef transaction As DbTransaction,
                                           ByRef 伝票日付 As Integer
                ) As Foundation.ResultType
        Dim myDataReader As New MyDataReader
        myDataReader.Initialize(Me, _myImportParam)
        Return myDataReader.ReadHANC015UpdateLock(transaction, 伝票日付)

    End Function

    Private Function ReadHANM045PrimaryKey(ByRef transaction As DbTransaction,
                                           ByRef 取得したデータ As DataTable,
                                           ByVal 読込キー As ProgramLib.ロットマスター型
        ) As Foundation.ResultType  'A-2009/12/18_Ver7.40_LOT

        Dim myDataReader As New MyDataReader
        myDataReader.Initialize(Me, _myImportParam)
        Return myDataReader.ReadHANM045PrimaryKey(transaction, 取得したデータ, 読込キー)

    End Function

    Private Function ReadZAIR001UpdateLock(ByRef transaction As DbTransaction,
                                           ByRef resultTable As DataTable,
                                           ByRef 処理連番 As Long
                ) As Foundation.ResultType  'A-2008/07/18_Ver7.30_SAIMU
        Dim myDataReader As New MyDataReader
        myDataReader.Initialize(Me, _myImportParam)
        Return myDataReader.ReadZAIR001UpdateLock(transaction, resultTable, 処理連番)

    End Function

    Private Function ReadZAIR101UpdateLock(ByRef transaction As DbTransaction,
                                           ByRef resultTable As DataTable,
                                           ByRef 処理連番 As Long
                ) As Foundation.ResultType 'A-2010/09/13_Ver7.4X_ZAISHONIN
        Dim myDataReader As New MyDataReader
        myDataReader.Initialize(Me, _myImportParam)
        Return myDataReader.ReadZAIR101UpdateLock(transaction, resultTable, 処理連番)

    End Function

    Private Function ReadHANR005PrimaryKey(ByRef transaction As DbTransaction,
                                           ByRef 取得したデータ As DataTable,
                                           ByVal 発注番号 As Long,
                                           ByVal 発注行番号 As Integer
                ) As Foundation.ResultType

        Dim myDataReader As New MyDataReader
        myDataReader.Initialize(Me, _myImportParam)
        Return myDataReader.ReadHANR005PrimaryKey(transaction, 取得したデータ, 発注番号, 発注行番号)

    End Function

    'A-CUST20190830↓ '2020/08/06
    Private Function ReadHAN発注内訳伝票チェック(ByRef transaction As DbTransaction,
                                       ByRef 取得したデータ As DataTable,
                                       ByVal 発注番号 As Long,
                                       ByVal 発注行番号 As Integer,
                                       ByVal 内訳番号 As Integer
            ) As Foundation.ResultType

        Dim myDataReader As New MyDataReader
        myDataReader.Initialize(Me, _myImportParam)
        Return myDataReader.Read発注内訳伝票CUST(transaction, 取得したデータ, 発注番号, 発注行番号, 内訳番号)

    End Function
    'A-CUST20190830↑ '2020/08/06

    'A-20110912_1↓
    Private Function ReadHANR001SK(ByRef transaction As DbTransaction,
                                    ByRef 取得したデータ As DataTable,
                                    ByVal 処理連番 As Long
         ) As Foundation.ResultType

        Dim myDataReader As New MyDataReader
        myDataReader.Initialize(Me, _myImportParam)
        Return myDataReader.ReadHANR001SK(transaction, 取得したデータ, 処理連番)

    End Function
    'A-20110912_1↑

    'A-20121217_Ver7.50_3↓
    Private Function ReadHANR001出庫伝票取得(ByRef transaction As DbTransaction,
                                             ByRef 取得したデータ As DataTable,
                                             ByVal 処理連番 As Long
         ) As Foundation.ResultType

        Dim myDataReader As New MyDataReader
        myDataReader.Initialize(Me, _myImportParam)
        Return myDataReader.ReadHANR001出庫伝票取得(transaction, 取得したデータ, 処理連番)

    End Function
    'A-20121217_Ver7.50_3↑

#End Region

#Region "ストアド"

    ''' <summary>
    ''' ストアド更新処理
    ''' </summary>
    ''' <param name="transaction">トランザクション情報</param>
    ''' <param name="storedName">ストアド名</param>
    ''' <returns>エラー情報</returns>
    ''' <remarks></remarks>
    Private Function Updateストアド_仕入(ByVal transaction As DbTransaction,
                                         ByVal storedName As String,
                                         ByVal 更新データ As S90050_00.WorkTableUnitData,
                                         Optional ByVal 区分 As Integer = -1) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase
        Dim paramInfo As ParamInfoList = New ParamInfoList

        Dim 受発注管理 As String = IIf(_myImportParam.Myコントロール情報.Myオプション区分.受発注管理 = オプション区分定義型.区分型.行う, "1", "0").ToString
        Dim 部門管理 As String = IIf(_myImportParam.Myコントロール情報.Myオプション区分.部門管理 = オプション区分定義型.区分型.行う, "1", "0").ToString
        Dim 倉庫別在庫管理 As String = IIf(_myImportParam.Myコントロール情報.My機能区分.倉庫別在庫管理 = 機能区分定義型.倉庫別在庫管理型.行う, "1", "0").ToString
        Dim 営業所管理 As String = IIf(_myImportParam.Myコントロール情報.My機能区分.営業所管理 = 機能区分定義型.営業所管理区分型.行う, "1", "0").ToString
        Dim 税抜消費税算出方法_仕入 As String = CStr(_myImportParam.Myコントロール情報.My消費税.税抜消費税算出方法_仕入)
        Dim 有効期限更新方法 As String = CStr(_myImportParam.Myコントロール情報.MyMOAロット管理.有効期限更新方法設定)

        Dim 単価端数処理_仕入処理区分 As String = CStr(_myImportParam.Myコントロール情報.My端数処理.単価端数処理_仕入_処理区分)
        Dim 単価端数処理_仕入単位 As String = CStr(_myImportParam.Myコントロール情報.My端数処理.単価端数処理_仕入_単位)

        Dim 取引先コード_タイプ As String = CStr(_myImportParam.Myコントロール情報.My機能区分.得意先_仕入先_コード_タイプ)
        Dim 取引先コード_桁数 As String = CStr(_myImportParam.Myコントロール情報.My機能区分.得意先_仕入先_コード_桁数)

        '受注の残更新を行わない場合は受発注管理なしとする
        If _myImportParam.Myコントロール情報.My機能区分.注残更新区分 = 機能区分定義型.注残更新区分型.行わない Then
            受発注管理 = "0"
        End If

        'A-20121217_Ver7.50_1↓
        Dim 外貨管理 As String = "0"
        Dim 未検収在庫機能 As String = "0"
        If _myImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 4.0 Then
            外貨管理 = IIf(_myImportParam.Myコントロール情報.MyMOAオプション.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う, "1", "0").ToString
            未検収在庫機能 = IIf(_myImportParam.Myコントロール情報.MyMOA機能追加.未検収在庫機能 = MOA機能追加定義型.未検収在庫機能使用区分型.使用する, "0", "1").ToString
        End If
        'A-20121217_Ver7.50_1↑
        '↓A-20170601-X1-RevUp
        Dim 金額桁数拡張 As String = IIf(_myImportParam.Myコントロール情報.My桁数拡張.金額桁数 = 12, "1", "0").ToString
        '↑A-20170601-X1-RevUp

        'GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.受発注管理, 受発注管理, paramInfo)
        'GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.部門管理, 部門管理, paramInfo)
        'GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.倉庫別在庫管理, 倉庫別在庫管理, paramInfo)
        'GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.営業所管理, 営業所管理, paramInfo)

        Select Case storedName
            Case DELETE_ストアド
                Dim storedParam As New ProgramLib.ストアドパラメータ_出庫
                storedParam = 更新データ.ストアドパラメータ_DELETE

                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.H処理連番, storedParam.処理連番, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.対象年月度, storedParam.対象年月度, paramInfo)
                'GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.H入出庫区分, storedParam.入出庫区分, paramInfo)   'D-20111124_9
                'A-20111124_9↓
                If 区分 = 入出庫区分型.入庫 Then
                    '倉庫移動入庫の場合は、入庫として呼び出す。
                    GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.H入出庫区分, 1, paramInfo)
                Else
                    GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.H入出庫区分, storedParam.入出庫区分, paramInfo)
                End If
                'A-20111124_9↑

                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.倉庫別在庫管理, 倉庫別在庫管理, paramInfo)

                'A-20121217_Ver7.50_1↓
                '生産強化区分≧4.0 の場合、ストアドを4次強化対応版に差換える
                If _myImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 4.0 Then
                    storedName = DELETE_ストアド_製造実績更新_４次強化
                    '
                    GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.未検収在庫機能, 未検収在庫機能, paramInfo)
                End If
                'A-20121217_Ver7.50_1↑

            Case INSERT_ストアド
                Dim storedParam As New ProgramLib.ストアドパラメータ_出庫
                storedParam = 更新データ.ストアドパラメータ_INSERT

                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.H処理連番, storedParam.処理連番, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.対象年月度, storedParam.対象年月度, paramInfo)
                'GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.H入出庫区分, storedParam.入出庫区分, paramInfo)   'D-20111124_9
                'A-20111124_9↓
                If 区分 = 入出庫区分型.入庫 Then
                    '倉庫移動入庫の場合は、入庫として呼び出す。
                    GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.H入出庫区分, 1, paramInfo)
                Else
                    GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.H入出庫区分, storedParam.入出庫区分, paramInfo)
                End If
                'A-20111124_9↑

                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.有効期限更新方法, 有効期限更新方法, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.倉庫別在庫管理, 倉庫別在庫管理, paramInfo)

                'A-20121217_Ver7.50_1↓
                '生産強化区分≧4.0 の場合、ストアドを4次強化対応版に差換える
                If _myImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 4.0 Then
                    storedName = INSERT_ストアド_製造実績更新_４次強化
                    '
                    GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.未検収在庫機能, 未検収在庫機能, paramInfo)
                End If
                'A-20121217_Ver7.50_1↑

            Case DELETE_ストアド_受入伝票
                Dim storedParam As New ProgramLib.ストアドパラメータ_仕入
                storedParam = 更新データ.ストアドパラメータ_仕入_DELETE

                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.処理連番, storedParam.処理連番, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.対象年月度, storedParam.年月, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.税抜消費税算出方法_仕入, 税抜消費税算出方法_仕入, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.端数処理区分_金額, storedParam.端数処理区分_金額, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.端数処理区分_消費税分解, storedParam.端数処理区分_消費税分解, paramInfo)

                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.受発注管理, 受発注管理, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.部門管理, 部門管理, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.倉庫別在庫管理, 倉庫別在庫管理, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.営業所管理, 営業所管理, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.金額桁数拡張, 金額桁数拡張, paramInfo) 'A-20170601-X1-RevUp

            Case INSERT_ストアド_受入伝票
                Dim storedParam As New ProgramLib.ストアドパラメータ_仕入
                storedParam = 更新データ.ストアドパラメータ_仕入_INSERT

                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.処理連番, storedParam.処理連番, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.対象年月度, storedParam.年月, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.税抜消費税算出方法_仕入, 税抜消費税算出方法_仕入, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.端数処理区分_金額, storedParam.端数処理区分_金額, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.端数処理区分_消費税分解, storedParam.端数処理区分_消費税分解, paramInfo)

                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.受発注管理, 受発注管理, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.部門管理, 部門管理, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.倉庫別在庫管理, 倉庫別在庫管理, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.営業所管理, 営業所管理, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.金額桁数拡張, 金額桁数拡張, paramInfo) 'A-20170601-X1-RevUp

            Case DELETE_ストアド_入荷伝票
                Dim storedParam As New ProgramLib.ストアドパラメータ_仕入
                storedParam = 更新データ.ストアドパラメータ_仕入_DELETE

                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.処理連番, storedParam.処理連番, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.対象年月度, storedParam.年月, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.税抜消費税算出方法_仕入, 税抜消費税算出方法_仕入, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.端数処理区分_金額, storedParam.端数処理区分_金額, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.端数処理区分_消費税分解, storedParam.端数処理区分_消費税分解, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.計上区分, storedParam.計上区分, paramInfo)

                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.受発注管理, 受発注管理, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.部門管理, 部門管理, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.倉庫別在庫管理, 倉庫別在庫管理, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.営業所管理, 営業所管理, paramInfo)

                'A-20121217_Ver7.50_1↓
                '生産強化区分≧4.0 の場合、ストアドを4次強化対応版に差換える
                If _myImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 4.0 Then
                    storedName = DELETE_ストアド_入荷伝票_４次強化
                    '
                    GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.外貨入力, 外貨管理, paramInfo)
                    GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.未検収在庫機能, 未検収在庫機能, paramInfo)
                    GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.通貨区分, storedParam.通貨区分, paramInfo)
                    GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.端数処理区分_金額_外貨, storedParam.端数処理区分_金額_外貨, paramInfo)
                    GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.小数以下桁数_金額_外貨, storedParam.小数以下桁数_金額_外貨, paramInfo)
                    GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.通貨単位, storedParam.通貨単位, paramInfo)
                    GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.金額桁数拡張, 金額桁数拡張, paramInfo) 'A-20170601-X1-RevUp
                End If
                'A-20121217_Ver7.50_1↑

            Case INSERT_ストアド_入荷伝票
                Dim storedParam As New ProgramLib.ストアドパラメータ_仕入
                storedParam = 更新データ.ストアドパラメータ_仕入_INSERT

                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.処理連番, storedParam.処理連番, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.対象年月度, storedParam.年月, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.税抜消費税算出方法_仕入, 税抜消費税算出方法_仕入, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.端数処理区分_金額, storedParam.端数処理区分_金額, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.端数処理区分_消費税分解, storedParam.端数処理区分_消費税分解, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.計上区分, storedParam.計上区分, paramInfo)

                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.受発注管理, 受発注管理, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.部門管理, 部門管理, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.倉庫別在庫管理, 倉庫別在庫管理, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.営業所管理, 営業所管理, paramInfo)

                'A-20121217_Ver7.50_1↓
                '生産強化区分≧4.0 の場合、ストアドを4次強化対応版に差換える
                If _myImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 4.0 Then
                    storedName = INSERT_ストアド_入荷伝票_４次強化
                    '
                    GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.外貨入力, 外貨管理, paramInfo)
                    GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.未検収在庫機能, 未検収在庫機能, paramInfo)
                    GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.通貨区分, storedParam.通貨区分, paramInfo)
                    GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.端数処理区分_金額_外貨, storedParam.端数処理区分_金額_外貨, paramInfo)
                    GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.小数以下桁数_金額_外貨, storedParam.小数以下桁数_金額_外貨, paramInfo)
                    GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.通貨単位, storedParam.通貨単位, paramInfo)
                    GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.金額桁数拡張, 金額桁数拡張, paramInfo) 'A-20170601-X1-RevUp
                End If
                'A-20121217_Ver7.50_1↑

                'A-20121217_Ver7.50↓
            Case DELETE_ストアド_入荷伝票_仕掛
                Dim storedParam As New ProgramLib.ストアドパラメータ_仕入
                storedParam = 更新データ.ストアドパラメータ_仕入_DELETE

                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.処理連番, storedParam.処理連番, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.対象年月度, storedParam.年月, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.税抜消費税算出方法_仕入, 税抜消費税算出方法_仕入, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.端数処理区分_金額, storedParam.端数処理区分_金額, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.端数処理区分_消費税分解, storedParam.端数処理区分_消費税分解, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.計上区分, storedParam.計上区分, paramInfo)

                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.受発注管理, 受発注管理, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.部門管理, 部門管理, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.倉庫別在庫管理, 倉庫別在庫管理, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.営業所管理, 営業所管理, paramInfo)

                'A-20121217_Ver7.50_1↓
                '生産強化区分≧4.0 の場合、ストアドを4次強化対応版に差換える
                If _myImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 4.0 Then
                    storedName = DELETE_ストアド_入荷伝票_仕掛_４次強化
                    '
                    GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.外貨入力, 外貨管理, paramInfo)
                    GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.未検収在庫機能, 未検収在庫機能, paramInfo)
                    GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.通貨区分, storedParam.通貨区分, paramInfo)
                    GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.端数処理区分_金額_外貨, storedParam.端数処理区分_金額_外貨, paramInfo)
                    GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.小数以下桁数_金額_外貨, storedParam.小数以下桁数_金額_外貨, paramInfo)
                    GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.通貨単位, storedParam.通貨単位, paramInfo)
                    GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.金額桁数拡張, 金額桁数拡張, paramInfo) 'A-20170601-X1-RevUp
                End If
                'A-20121217_Ver7.50_1↑
                'A-20121217_Ver7.50↑

            Case DELETE_ストアド_入庫伝票_入荷, DELETE_ストアド_入庫伝票_検収
                Dim storedParam As New ProgramLib.ストアドパラメータ_入庫
                storedParam = 更新データ.ストアドパラメータ_入庫_DELETE

                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.処理連番, storedParam.処理連番, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.対象年月度, storedParam.対象年月度, paramInfo)

                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.倉庫別在庫管理, 倉庫別在庫管理, paramInfo)

            Case INSERT_ストアド_入庫伝票_入荷, INSERT_ストアド_入庫伝票_検収
                Dim storedParam As New ProgramLib.ストアドパラメータ_入庫
                storedParam = 更新データ.ストアドパラメータ_入庫_INSERT

                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.処理連番, storedParam.処理連番, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.対象年月度, storedParam.対象年月度, paramInfo)

                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.倉庫別在庫管理, 倉庫別在庫管理, paramInfo)

            Case DELETE_ストアド_ロット明細
                Dim storedParam As New ProgramLib.ストアドパラメータ_ロット明細
                storedParam = 更新データ.ストアドパラメータ_ロット明細_DELETE

                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.処理連番, storedParam.処理連番, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.対象年月度, storedParam.対象年月度, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.伝票区分, 伝票区分型.入出庫, paramInfo)

                'A-20121217_Ver7.50_1↓
                '生産強化区分≧4.0 の場合、ストアドを4次強化対応版に差換える
                If _myImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 4.0 Then
                    storedName = DELETE_ストアド_ロット明細_４次強化
                    '
                    GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.当期期首年月, storedParam.当期期首年月, paramInfo)
                    GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.処理区分, 1, paramInfo)
                    GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.未検収在庫機能, 未検収在庫機能, paramInfo)
                End If
                'A-20121217_Ver7.50_1↑

            Case INSERT_ストアド_ロット明細
                Dim storedParam As New ProgramLib.ストアドパラメータ_ロット明細
                storedParam = 更新データ.ストアドパラメータ_ロット明細_INSERT

                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.処理連番, storedParam.処理連番, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.対象年月度, storedParam.対象年月度, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.伝票区分, 伝票区分型.入出庫, paramInfo)

                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.有効期限更新方法, 有効期限更新方法, paramInfo)

                'A-20121217_Ver7.50_1↓
                '生産強化区分≧4.0 の場合、ストアドを4次強化対応版に差換える
                If _myImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 4.0 Then
                    storedName = INSERT_ストアド_ロット明細_４次強化
                    '
                    GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.当期期首年月, storedParam.当期期首年月, paramInfo)
                    GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.処理区分, 1, paramInfo)
                    GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.未検収在庫機能, 未検収在庫機能, paramInfo)
                End If
                'A-20121217_Ver7.50_1↑

            Case DELETE_ストアド_原価
                Dim storedParam As New ProgramLib.ストアドパラメータ_原価
                If 区分 = 入出庫区分型.入庫 Then
                    storedParam = 更新データ.ストアドパラメータ_原価_入庫_DELETE
                Else
                    storedParam = 更新データ.ストアドパラメータ_原価_出庫_DELETE
                End If

                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.発生区分, 1, paramInfo)
                'GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.入出庫区分, 1, paramInfo) 'D-20111124_10
                'A-20111124_10↓
                If 区分 = 入出庫区分型.入庫 Then
                    GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.入出庫区分, 1, paramInfo)
                Else
                    GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.入出庫区分, 2, paramInfo)
                End If
                'A-20111124_10↑
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.処理連番, storedParam.処理連番, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.対象年月度, storedParam.対象年月度, paramInfo)

            Case INSERT_ストアド_原価
                Dim storedParam As New ProgramLib.ストアドパラメータ_原価
                If 区分 = 入出庫区分型.入庫 Then
                    storedParam = 更新データ.ストアドパラメータ_原価_入庫_INSERT
                Else
                    storedParam = 更新データ.ストアドパラメータ_原価_出庫_INSERT
                End If

                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.発生区分, 1, paramInfo)
                'GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.入出庫区分, 1, paramInfo) 'D-20111124_10
                'A-20111124_10↓
                If 区分 = 入出庫区分型.入庫 Then
                    GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.入出庫区分, 1, paramInfo)
                Else
                    GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.入出庫区分, 2, paramInfo)
                End If
                'A-20111124_10↑
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.処理連番, storedParam.処理連番, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.対象年月度, storedParam.対象年月度, paramInfo)

                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.単価端数処理_仕入処理区分, 単価端数処理_仕入処理区分, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.単価端数処理_仕入単位, 単価端数処理_仕入単位, paramInfo)

                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.仕入先コード_タイプ, 取引先コード_タイプ, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.仕入先コード_桁数, 取引先コード_桁数, paramInfo)



                'A-20111105_1↓
            Case INSERT_ストアド_出庫_みなし
                Dim storedParam As New ProgramLib.ストアドパラメータ_出庫
                storedParam = 更新データ.ストアドパラメータ_INSERT_出庫_移動有

                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.処理連番, storedParam.処理連番, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.対象年月度, storedParam.対象年月度, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.倉庫別在庫管理, 倉庫別在庫管理, paramInfo)

            Case INSERT_ストアド_入庫_みなし
                Dim storedParam As New ProgramLib.ストアドパラメータ_出庫
                storedParam = 更新データ.ストアドパラメータ_INSERT_入庫_移動有

                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.処理連番, storedParam.処理連番, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.対象年月度, storedParam.対象年月度, paramInfo)
                GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.倉庫別在庫管理, 倉庫別在庫管理, paramInfo)

                'A-20111105_1↑


        End Select

        GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.リターンコード, 0, paramInfo)
        GetUpdateParameterストアド_仕入(ストアドパラメータ仕入型.エラー発生場所, "", paramInfo)

        DataAccess.ExecuteStoredProcedure(transaction, storedName, paramInfo)
        Select Case CInt(Getパラメータ(paramInfo, "RETCD1", 属性.数値))
            Case 0
                result.Code = ResultType.成功
            Case Else
                Dim errorMessage As String = ""
                errorMessage &= storedName & Space(5)
                errorMessage &= CStr(Getパラメータ(paramInfo, "RETCD2", 属性.文字))
                HandleStoredProcedureError(errorMessage)
        End Select

        Return result

    End Function

    Private Enum ストアドパラメータ仕入型 As Integer
        処理連番
        対象年月度
        受発注管理
        部門管理
        商品内訳管理            'A-2009/12/18_Ver7.40_UCHIWAKE
        ロット管理              'A-2009/12/18_Ver7.40_UCHIWAKE
        倉庫別在庫管理
        営業所管理
        小数以下桁数_換算数量   'A-2009/12/18_Ver7.40_UCHIWAKE
        税抜消費税算出方法_仕入
        端数処理区分_金額
        端数処理区分_消費税分解
        外貨入力                'A-20121217_Ver7.50
        未検収在庫機能          'A-20121217_Ver7.50
        当期期首年月            'A-20121217_Ver7.50
        処理区分                'A-20121217_Ver7.50
        通貨区分                'A-20121217_Ver7.50_1
        端数処理区分_金額_外貨  'A-20121217_Ver7.50_1
        小数以下桁数_金額_外貨  'A-20121217_Ver7.50_1
        通貨単位                'A-20121217_Ver7.50_1
        金額桁数拡張            'A-20170601-X1-RevUp
        '受入
        H処理連番
        H入出庫区分
        有効期限更新方法
        発生区分
        入出庫区分
        計上区分
        伝票区分
        単価端数処理_仕入処理区分
        単価端数処理_仕入単位
        仕入先コード_タイプ
        仕入先コード_桁数
        リターンコード
        エラー発生場所
    End Enum

    Private Sub GetUpdateParameterストアド_仕入(Of T)(
                                        ByVal targetType As ストアドパラメータ仕入型,
                                        ByVal value As T,
                                        ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList)    'X1変換Tool-20170508

        Dim newParameter As New OSK.X1.DataAccess.ParamInfo    'X1変換Tool-20170508

        Select Case targetType
            Case ストアドパラメータ仕入型.処理連番
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 10
                    .Scale = 0
                    .Value = value
                    .Name = "RENBAN"
                End With
            Case ストアドパラメータ仕入型.対象年月度
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 8
                    .Scale = 0
                    .Value = value
                    .Name = "YYYYMM"
                End With
            Case ストアドパラメータ仕入型.受発注管理
                With newParameter
                    .Type = DbType.AnsiStringFixedLength
                    .Size = 1
                    .Value = value
                    .Name = "OPT_001"
                End With
            Case ストアドパラメータ仕入型.部門管理
                With newParameter
                    .Type = DbType.AnsiStringFixedLength
                    .Size = 1
                    .Value = value
                    .Name = "OPT_004"
                End With
            Case ストアドパラメータ仕入型.倉庫別在庫管理
                With newParameter
                    .Type = DbType.AnsiStringFixedLength
                    .Size = 1
                    .Value = value
                    .Name = "KINO_001"
                End With
            Case ストアドパラメータ仕入型.営業所管理
                With newParameter
                    .Type = DbType.AnsiStringFixedLength
                    .Size = 1
                    .Value = value
                    .Name = "KINO_082"
                End With
            Case ストアドパラメータ仕入型.税抜消費税算出方法_仕入
                With newParameter
                    .Type = DbType.AnsiStringFixedLength
                    .Size = 1
                    .Value = value
                    .Name = "SZEI_002"
                End With
            Case ストアドパラメータ仕入型.端数処理区分_金額
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 1
                    .Scale = 0
                    .Value = value
                    .Name = "HASUUKBN_KIN"
                End With
            Case ストアドパラメータ仕入型.端数処理区分_消費税分解
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 1
                    .Scale = 0
                    .Value = value
                    .Name = "HASUUKBN_ZEI"
                End With
                'A-20121217_Ver7.50↓
            Case ストアドパラメータ仕入型.外貨入力
                With newParameter
                    .Type = DbType.AnsiStringFixedLength
                    .Size = 1
                    .Value = value
                    .Name = "SEI_OPT_007"
                End With
            Case ストアドパラメータ仕入型.未検収在庫機能
                With newParameter
                    .Type = DbType.AnsiStringFixedLength
                    .Size = 1
                    .Value = value
                    .Name = "SEI_KINO_045"
                End With
            Case ストアドパラメータ仕入型.当期期首年月
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 6
                    .Scale = 0
                    .Value = value
                    .Name = "TOKIKISHUYM"
                End With
            Case ストアドパラメータ仕入型.処理区分
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 1
                    .Scale = 0
                    .Value = value
                    .Name = "SHORIKBN"
                End With
                'A-20121217_Ver7.50↑
                'A-20121217_Ver7.50_1↓
            Case ストアドパラメータ仕入型.通貨区分
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 1
                    .Scale = 0
                    .Value = value
                    .Name = "TUUKA_KBN"
                End With
            Case ストアドパラメータ仕入型.端数処理区分_金額_外貨
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 1
                    .Scale = 0
                    .Value = value
                    .Name = "HASUUKBN_KIN_GAI"
                End With
            Case ストアドパラメータ仕入型.小数以下桁数_金額_外貨
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 1
                    .Scale = 0
                    .Value = value
                    .Name = "SHOSUKETA_KBN"
                End With
            Case ストアドパラメータ仕入型.通貨単位
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 5
                    .Scale = 0
                    .Value = value
                    .Name = "TSUUKA_TANI"
                End With
                'A-20121217_Ver7.50_1↑
                '↓A-20170601-X1-RevUp
            Case ストアドパラメータ仕入型.金額桁数拡張
                With newParameter
                    .Type = DbType.AnsiStringFixedLength
                    .Size = 1
                    .Value = value
                    .Name = "KETA_005"
                End With
                '↑A-20170601-X1-RevUp
                '↓A-2009/12/18_Ver7.40_UCHIWAKE
            Case ストアドパラメータ仕入型.商品内訳管理
                With newParameter
                    .Type = DbType.AnsiStringFixedLength
                    .Size = 1
                    .Value = value
                    .Name = "OPT_013"
                End With
            Case ストアドパラメータ仕入型.ロット管理
                With newParameter
                    .Type = DbType.AnsiStringFixedLength
                    .Size = 1
                    .Value = value
                    .Name = "OPT_019"
                End With
            Case ストアドパラメータ仕入型.小数以下桁数_換算数量
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 1
                    .Scale = 0
                    .Value = value
                    .Name = "KINO_122"
                End With
                '↑A-2009/12/18_Ver7.40_UCHIWAKE
            Case ストアドパラメータ仕入型.H処理連番
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 10
                    .Scale = 0
                    .Value = value
                    .Name = "HRENBAN"
                End With
            Case ストアドパラメータ仕入型.H入出庫区分
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 1
                    .Scale = 0
                    .Value = value
                    .Name = "NSKKBN"
                End With
            Case ストアドパラメータ仕入型.有効期限更新方法
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 1
                    .Scale = 0
                    .Value = value
                    .Name = "UPDKBN"
                End With
            Case ストアドパラメータ仕入型.発生区分
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 1
                    .Scale = 0
                    .Value = value
                    .Name = "HASSEIKBN"
                End With
            Case ストアドパラメータ仕入型.入出庫区分
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 1
                    .Scale = 0
                    .Value = value
                    .Name = "NYUSHUKBN"
                End With
            Case ストアドパラメータ仕入型.計上区分
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 1
                    .Scale = 0
                    .Value = value
                    .Name = "KENSHU_KIJUN"
                End With
            Case ストアドパラメータ仕入型.伝票区分
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 1
                    .Scale = 0
                    .Value = value
                    .Name = "DENKBN"
                End With
            Case ストアドパラメータ仕入型.単価端数処理_仕入処理区分
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 1
                    .Scale = 0
                    .Value = value
                    .Name = "HASUU_003"
                End With
            Case ストアドパラメータ仕入型.単価端数処理_仕入単位
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 9
                    .Scale = 0
                    .Value = value
                    .Name = "HASUU_004"
                End With
            Case ストアドパラメータ仕入型.仕入先コード_タイプ
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 1
                    .Scale = 0
                    .Value = value
                    .Name = "KINO_007"
                End With
            Case ストアドパラメータ仕入型.仕入先コード_桁数
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 2
                    .Scale = 0
                    .Value = value
                    .Name = "KINO_008"
                End With
            Case ストアドパラメータ仕入型.リターンコード
                With newParameter
                    .Direction = ParameterDirection.Output
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 1
                    .Scale = 0
                    .Value = 0
                    .Name = "RETCD1"
                End With
            Case ストアドパラメータ仕入型.エラー発生場所
                With newParameter
                    .Direction = ParameterDirection.Output
                    .Type = DbType.String
                    .Size = 30
                    .Value = ""
                    .Name = "RETCD2"
                End With
            Case Else
                Throw New System.Exception("paramTypeパラメータ不正")
        End Select

        paramInfo.Add(newParameter)

    End Sub

    Private Enum 属性 As Integer
        文字
        数値
    End Enum

    ''' <summary>
    ''' パラメータ内容を取得する
    ''' </summary>
    ''' <param name="paramInfo">パラメータ配列</param>
    ''' <param name="取得項目名">取得したい項目名</param>
    ''' <param name="取得項目属性">取得したい項目の属性</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function Getパラメータ(ByVal paramInfo As ParamInfoList,
                                   ByVal 取得項目名 As String,
                                   ByVal 取得項目属性 As 属性) As Object

        Dim パラメータ名 As String = ""

        Dim 取得パラメータ As Object = Nothing
        Select Case 取得項目属性
            Case 属性.文字
                取得パラメータ = ""
            Case 属性.数値
                取得パラメータ = 0
        End Select

        For index As Integer = 0 To paramInfo.Count - 1
            パラメータ名 = paramInfo(index).Name.Trim
            If Left(パラメータ名, 1) = "@" Then
                パラメータ名 = Mid(パラメータ名, 2, パラメータ名.Length - 1)
            End If
            If パラメータ名.Trim = 取得項目名.Trim Then
                取得パラメータ = paramInfo(index).Value
                Exit For
            End If
        Next

        Return 取得パラメータ

    End Function

    'A-CUST20190830↓
    ''' <summary>
    ''' ストアド更新処理
    ''' </summary>
    ''' <param name="transaction">トランザクション情報</param>
    ''' <param name="storedName">ストアド名</param>
    ''' <returns>エラー情報</returns>
    ''' <remarks></remarks>
    Private Function Updateストアド_入出庫(ByVal transaction As DbTransaction,
                                           ByVal storedName As String,
                                           ByVal storedParam As ProgramLib.ストアドパラメータ_入出庫) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase
        Dim paramInfo As ParamInfoList = New ParamInfoList

        Dim 倉庫別在庫管理 As String = IIf(_myImportParam.Myコントロール情報.My機能区分.倉庫別在庫管理 = 機能区分定義型.倉庫別在庫管理型.行う, "1", "0").ToString

        GetUpdateParameterストアド_入出庫(ストアドパラメータ入出庫型.処理連番, storedParam.処理連番, paramInfo)
        GetUpdateParameterストアド_入出庫(ストアドパラメータ入出庫型.対象年月度, storedParam.年月, paramInfo)
        GetUpdateParameterストアド_入出庫(ストアドパラメータ入出庫型.倉庫別在庫管理, 倉庫別在庫管理, paramInfo)
        GetUpdateParameterストアド_入出庫(ストアドパラメータ入出庫型.リターンコード, 0, paramInfo)
        GetUpdateParameterストアド_入出庫(ストアドパラメータ入出庫型.エラー発生場所, "", paramInfo)

        DataAccess.ExecuteStoredProcedure(transaction, storedName, paramInfo)
        Select Case CInt(Getパラメータ(paramInfo, "RETCD1", 属性.数値))
            Case 0
                result.Code = ResultType.成功
            Case Else
                Dim errorMessage As String = ""
                errorMessage &= storedName & Space(5)
                errorMessage &= CStr(Getパラメータ(paramInfo, "RETCD2", 属性.文字))
                HandleStoredProcedureError(errorMessage)
        End Select

        Return result

    End Function

    Private Enum ストアドパラメータ入出庫型 As Integer
        処理連番
        対象年月度
        倉庫別在庫管理
        リターンコード
        エラー発生場所
    End Enum

    Private Sub GetUpdateParameterストアド_入出庫(Of T)(
                                        ByVal targetType As ストアドパラメータ入出庫型,
                                        ByVal value As T,
                                        ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList)    'X1変換Tool-20191106

        Dim newParameter As New OSK.X1.DataAccess.ParamInfo    'X1変換Tool-20191106

        Select Case targetType
            Case ストアドパラメータ入出庫型.処理連番
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 10
                    .Scale = 0
                    .Value = value
                    .Name = "RENBAN"
                End With
            Case ストアドパラメータ入出庫型.対象年月度
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 8
                    .Scale = 0
                    .Value = value
                    .Name = "YYYYMM"
                End With
            Case ストアドパラメータ入出庫型.倉庫別在庫管理
                With newParameter
                    .Type = DbType.AnsiStringFixedLength
                    .Size = 1
                    .Value = value
                    .Name = "KINO_001"
                End With
            Case ストアドパラメータ入出庫型.リターンコード
                With newParameter
                    .Direction = ParameterDirection.Output
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 1
                    .Scale = 0
                    .Value = 0
                    .Name = "RETCD1"
                End With
            Case ストアドパラメータ入出庫型.エラー発生場所
                With newParameter
                    .Direction = ParameterDirection.Output
                    .Type = DbType.String
                    .Size = 30
                    .Value = ""
                    .Name = "RETCD2"
                End With
            Case Else
                Throw New System.Exception("paramTypeパラメータ不正")
        End Select

        paramInfo.Add(newParameter)

    End Sub
    'A-2008/12/29↓

    ''' <summary>
    ''' ストアド更新処理
    ''' </summary>
    ''' <param name="transaction">トランザクション情報</param>
    ''' <param name="storedName">ストアド名</param>
    ''' <returns>エラー情報</returns>
    ''' <remarks></remarks>
    Private Function Updateストアド_ロット(ByVal transaction As DbTransaction,
                                           ByVal storedName As String,
                                           ByVal storedParam As ProgramLib.ストアドパラメータ_入出庫, Optional ByVal 削除区分 As Boolean = False) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase
        Dim paramInfo As ParamInfoList = New ParamInfoList

        Dim 伝票区分 As Integer = 5

        Dim 更新方法 As Integer = _myImportParam.Myコントロール情報.MyMOAロット管理.有効期限更新方法設定

        GetUpdateParameterストアド_ロット(ストアドパラメータロット型.処理連番, storedParam.処理連番, paramInfo)
        GetUpdateParameterストアド_ロット(ストアドパラメータロット型.対象年月度, storedParam.年月, paramInfo)
        GetUpdateParameterストアド_ロット(ストアドパラメータロット型.伝票区分, 伝票区分, paramInfo)
        If 削除区分 = False Then
            GetUpdateParameterストアド_ロット(ストアドパラメータロット型.更新方法, 更新方法, paramInfo)
        End If
        GetUpdateParameterストアド_ロット(ストアドパラメータロット型.リターンコード, 0, paramInfo)
        GetUpdateParameterストアド_ロット(ストアドパラメータロット型.エラー発生場所, "", paramInfo)

        DataAccess.ExecuteStoredProcedure(transaction, storedName, paramInfo)
        Select Case CInt(Getパラメータ(paramInfo, "RETCD1", 属性.数値))
            Case 0
                result.Code = ResultType.成功
            Case Else
                Dim errorMessage As String = ""
                errorMessage &= storedName & Space(5)
                errorMessage &= CStr(Getパラメータ(paramInfo, "RETCD2", 属性.文字))
                HandleStoredProcedureError(errorMessage)
        End Select

        Return result

    End Function

    Private Enum ストアドパラメータロット型 As Integer
        処理連番
        対象年月度
        伝票区分
        更新方法
        リターンコード
        エラー発生場所
    End Enum

    Private Sub GetUpdateParameterストアド_ロット(Of T)(
                                        ByVal targetType As ストアドパラメータロット型,
                                        ByVal value As T,
                                        ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList)    'X1変換Tool-20191106

        Dim newParameter As New OSK.X1.DataAccess.ParamInfo    'X1変換Tool-20191106

        Select Case targetType
            Case ストアドパラメータロット型.処理連番
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 10
                    .Scale = 0
                    .Value = value
                    .Name = "RENBAN"
                End With
            Case ストアドパラメータロット型.対象年月度
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 8
                    .Scale = 0
                    .Value = value
                    .Name = "YYYYMM"
                End With
            Case ストアドパラメータロット型.伝票区分
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 1
                    .Value = value
                    .Name = "DENKBN "
                End With
            Case ストアドパラメータロット型.更新方法
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 1
                    .Value = value
                    .Name = "UPDKBN "
                End With
            Case ストアドパラメータロット型.リターンコード
                With newParameter
                    .Direction = ParameterDirection.Output
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 1
                    .Scale = 0
                    .Value = 0
                    .Name = "RETCD1"
                End With
            Case ストアドパラメータロット型.エラー発生場所
                With newParameter
                    .Direction = ParameterDirection.Output
                    .Type = DbType.String
                    .Size = 30
                    .Value = ""
                    .Name = "RETCD2"
                End With
            Case Else
                Throw New System.Exception("paramTypeパラメータ不正")
        End Select

        paramInfo.Add(newParameter)

    End Sub
    'A-CUST20190830↑
#End Region

#Region "ストアド(原価集計)"    'A-2008/07/18_Ver7.30_GENKA

    ''' <summary>
    ''' ストアド更新処理(原価集計)
    ''' </summary>
    ''' <param name="transaction">トランザクション情報</param>
    ''' <param name="storedName">ストアド名</param>
    ''' <returns>エラー情報</returns>
    ''' <remarks></remarks>
    Private Function Updateストアド_原価集計(ByVal transaction As DbTransaction,
                                             ByVal storedName As String,
                                             ByVal storedParam As S90050_00.WorkTableUnitData) As TextFileImport.IResult 'A-2008/07/18_Ver7.30_GENKA

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase
        Dim paramInfo As ParamInfoList = New ParamInfoList

        Dim 伝票区分 As Decimal = storedParam.仕入ヘッダー.R001004
        Dim 処理連番 As Decimal = storedParam.仕入ヘッダー.R001006
        Dim 原価集計コードタイプ As Decimal = _myImportParam.Myコントロール情報.My機能区分.原価集計コード_タイプ
        Dim 原価集計コード桁数 As Decimal = _myImportParam.Myコントロール情報.My機能区分.原価集計コード_桁数
        Dim 要素使用分類種別 As Decimal = _myImportParam.Myコントロール情報.My原価管理.要素使用分類種別
        Dim 明細単位原価集計入力_売上 As Decimal = CDec(IIf(_myImportParam.Myコントロール情報.My原価管理.明細単位原価集計入力_売上 = 原価管理定義型.明細単位原価集計入力型.行う, 1, 0))
        Dim 明細単位原価集計入力_仕入 As Decimal = CDec(IIf(_myImportParam.Myコントロール情報.My原価管理.明細単位原価集計入力_仕入 = 原価管理定義型.明細単位原価集計入力型.行う, 1, 0))

        GetUpdateParameterストアド_原価集計(ストアドパラメータ原価集計型.伝票区分, 伝票区分, paramInfo)
        GetUpdateParameterストアド_原価集計(ストアドパラメータ原価集計型.処理連番, 処理連番, paramInfo)
        GetUpdateParameterストアド_原価集計(ストアドパラメータ原価集計型.原価集計コードタイプ, 原価集計コードタイプ, paramInfo)
        GetUpdateParameterストアド_原価集計(ストアドパラメータ原価集計型.原価集計コード桁数, 原価集計コード桁数, paramInfo)
        GetUpdateParameterストアド_原価集計(ストアドパラメータ原価集計型.要素使用分類種別, 要素使用分類種別, paramInfo)
        GetUpdateParameterストアド_原価集計(ストアドパラメータ原価集計型.明細単位原価集計入力_売上, 明細単位原価集計入力_売上, paramInfo)
        GetUpdateParameterストアド_原価集計(ストアドパラメータ原価集計型.明細単位原価集計入力_仕入, 明細単位原価集計入力_仕入, paramInfo)
        GetUpdateParameterストアド_原価集計(ストアドパラメータ原価集計型.リターンコード, 0, paramInfo)
        GetUpdateParameterストアド_原価集計(ストアドパラメータ原価集計型.エラー発生場所, "", paramInfo)

        DataAccess.ExecuteStoredProcedure(transaction, storedName, paramInfo)
        Select Case CInt(Getパラメータ(paramInfo, "RETCD1", 属性.数値))
            Case 0
                result.Code = ResultType.成功
            Case Else
                Dim errorMessage As String = ""
                errorMessage &= storedName & Space(5)
                errorMessage &= CStr(Getパラメータ(paramInfo, "RETCD2", 属性.文字))
                HandleStoredProcedureError(errorMessage)
        End Select

        Return result

    End Function

    Private Enum ストアドパラメータ原価集計型 As Integer    'A-2008/07/18_Ver7.30_GENKA
        伝票区分
        処理連番
        原価集計コードタイプ
        原価集計コード桁数
        要素使用分類種別
        明細単位原価集計入力_売上
        明細単位原価集計入力_仕入
        リターンコード
        エラー発生場所
    End Enum

    Private Sub GetUpdateParameterストアド_原価集計(Of T)(
                                    ByVal targetType As ストアドパラメータ原価集計型,
                                    ByVal value As T,
                                    ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList) 'A-2008/07/18_Ver7.30_GENKA    'X1変換Tool-20170508

        Dim newParameter As New OSK.X1.DataAccess.ParamInfo    'X1変換Tool-20170508

        Select Case targetType
            Case ストアドパラメータ原価集計型.伝票区分
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 1
                    .Scale = 0
                    .Value = value
                    .Name = "DENKBN"
                End With
            Case ストアドパラメータ原価集計型.処理連番
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 10
                    .Scale = 0
                    .Value = value
                    .Name = "RENBAN"
                End With
            Case ストアドパラメータ原価集計型.原価集計コードタイプ
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 1
                    .Scale = 0
                    .Value = value
                    .Name = "KINO_112"
                End With
            Case ストアドパラメータ原価集計型.原価集計コード桁数
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 2
                    .Scale = 0
                    .Value = value
                    .Name = "KINO_113"
                End With
            Case ストアドパラメータ原価集計型.要素使用分類種別
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 1
                    .Scale = 0
                    .Value = value
                    .Name = "GENKA_002"
                End With
            Case ストアドパラメータ原価集計型.明細単位原価集計入力_売上
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 1
                    .Scale = 0
                    .Value = value
                    .Name = "GENKA_003"
                End With
            Case ストアドパラメータ原価集計型.明細単位原価集計入力_仕入
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 1
                    .Scale = 0
                    .Value = value
                    .Name = "GENKA_004"
                End With
            Case ストアドパラメータ原価集計型.リターンコード
                With newParameter
                    .Direction = ParameterDirection.Output
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 1
                    .Scale = 0
                    .Value = 0
                    .Name = "RETCD1"
                End With
            Case ストアドパラメータ原価集計型.エラー発生場所
                With newParameter
                    .Direction = ParameterDirection.Output
                    .Type = DbType.String
                    .Size = 30
                    .Value = ""
                    .Name = "RETCD2"
                End With
            Case Else
                Throw New System.Exception("paramTypeパラメータ不正")
        End Select

        paramInfo.Add(newParameter)

    End Sub

#End Region

#Region "データ変更履歴"    'A-2009/08/21_RIREKI

    Private Sub Get日時情報()   'A-2009/08/21_RIREKI

        Dim システム日付時刻 As DateTime = DateTime.Now
        _システム日付 = CInt(システム日付時刻.ToString("yyyyMMdd"))
        _システム時刻 = CInt(システム日付時刻.ToString("HHmmssfff"))

    End Sub

#Region "伝票履歴"  'A-2009/08/21_RIREKI

    ''' <summary>
    ''' 伝票履歴作成
    ''' </summary>
    ''' <param name="transaction"></param>
    ''' <param name="パラメータ"></param>
    ''' <remarks></remarks>
    Private Sub Create伝票履歴(ByVal transaction As DbTransaction,
                               ByVal パラメータ As 伝票履歴作成型)  'A-2009/08/21_RIREKI

        Dim 引渡項目 As IDictionary = New Hashtable
        With 引渡項目
            .Add(ISlipHistory.引渡項目_伝票履歴作成型.伝票種類.ToString, パラメータ.伝票種類)
            .Add(ISlipHistory.引渡項目_伝票履歴作成型.伝票区分.ToString, パラメータ.伝票区分)
            .Add(ISlipHistory.引渡項目_伝票履歴作成型.処理連番.ToString, パラメータ.処理連番)
            .Add(ISlipHistory.引渡項目_伝票履歴作成型.更新区分.ToString, パラメータ.更新区分)
            .Add(ISlipHistory.引渡項目_伝票履歴作成型.呼出モード.ToString, ISlipHistory.呼出モード型.通常)
        End With

        Dim 伝票履歴作成 As ISlipHistory = CommonFactory.CreateInstance(Of ISlipHistory)(Me, GetType(SlipHistory))
        伝票履歴作成.Initialize(Me)
        伝票履歴作成.CreateSlipHistory(transaction, 引渡項目)

    End Sub

    ''' <summary>
    ''' 履歴№取得
    ''' </summary>
    ''' <param name="transaction"></param>
    ''' <param name="パラメータ"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function Get履歴番号(ByVal transaction As DbTransaction,
                                 ByVal パラメータ As 伝票履歴番号取得型) As Integer     'A-2009/08/21_RIREKI

        Dim 引渡項目 As IDictionary = New Hashtable
        With 引渡項目
            .Add(ISlipHistory.引渡項目_履歴番号取得型.伝票種類.ToString, パラメータ.伝票種類)
            .Add(ISlipHistory.引渡項目_履歴番号取得型.伝票区分.ToString, パラメータ.伝票区分)
            .Add(ISlipHistory.引渡項目_履歴番号取得型.処理連番.ToString, パラメータ.処理連番)
        End With

        Dim 伝票履歴作成 As ISlipHistory = CommonFactory.CreateInstance(Of ISlipHistory)(Me, GetType(SlipHistory))
        伝票履歴作成.Initialize(Me)
        Return 伝票履歴作成.GetRirekiNo(transaction, 引渡項目)

    End Function

    ''' <summary>
    ''' 仕入伝票の更新区分取得
    ''' </summary>
    ''' <param name="mode"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function Get更新区分_仕入(ByVal mode As ITextDataChecker.DB更新Mode型) As ISlipHistory.更新区分型   'A-2009/08/21_RIREKI

        Select Case mode
            Case ITextDataChecker.DB更新Mode型.UPDATE
                Return ISlipHistory.更新区分型.修正

        End Select

    End Function

#End Region

#Region "関連履歴"  'A-2009/08/21_RIREKI

    ''' <summary>
    ''' 関連履歴(受注)の作成判定
    ''' </summary>
    ''' <remarks></remarks>
    Private Function Is関連履歴作成判定_発注() As Boolean   'A-2009/08/21_RIREKI

        If _myImportParam.Myコントロール情報.My変更履歴.変更履歴_発注 = False Then
            Return False
        End If

        If _myImportParam.Myコントロール情報.My機能区分.注残更新区分 = 機能区分定義型.注残更新区分型.行わない Then
            Return False
        End If

        If _myImportParam.Myコントロール情報.My受発注管理.売上_仕入_完納区分表示 = 受発注管理定義型.完納区分表示型.受注_発注_より表示 Then
            Return False
        End If

        Return True
    End Function

    ''' <summary>
    ''' 関連履歴情報の初期化
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Initialize関連履歴()    'A-2009/08/21_RIREKI

        Dim 引渡項目 As IDictionary = New Hashtable
        With 引渡項目
            .Add(ICreateKanrenHistory.引渡項目_履歴情報クリア型.伝票種類.ToString, ICreateKanrenHistory.伝票種類型.受発注)
        End With

        Dim 比較項目名 As IList(Of String) = New List(Of String)
        With 比較項目名
            .Add(ICreateKanrenHistory.比較対象_受発注型.完納区分.ToString)
        End With

        If _関連履歴作成_受発注 Is Nothing Then
            _関連履歴作成_受発注 = CommonFactory.CreateInstance(Of ICreateKanrenHistory)(Me, GetType(CreateKanrenHistory))
            _関連履歴作成_受発注.Initialize(Me)
        End If
        _関連履歴作成_受発注.Clear関連履歴情報(引渡項目, 比較項目名)

    End Sub

    ''' <summary>
    ''' 仮想処理（発注）
    ''' </summary>
    ''' <param name="transaction"></param>
    ''' <param name="更新データ"></param>
    ''' <remarks></remarks>
    Private Sub 仮想処理_発注(ByVal transaction As DbTransaction,
                              ByVal 更新データ As S90050_00.WorkTableUnitData) 'A-2009/08/21_RIREKI

        '仮想加算処理
        For row As Integer = 0 To 更新データ.データ件数 - 1
            Dim 仕入明細 As ProgramLib.仕入明細型 = 更新データ.仕入明細(row)

            '消費税行は対象外
            If 仕入明細.R002005 = 1 Then
                Continue For
            End If

            '受発注№が設定されていない場合は対象外
            If 仕入明細.R002011 = 0 Then
                Continue For
            End If

            Dim 引渡項目 As IDictionary = New Hashtable
            With 引渡項目
                .Add(ICreateKanrenHistory.引渡項目_仮想処理型.伝票種類.ToString, ICreateKanrenHistory.伝票種類型.受発注)
                .Add(ICreateKanrenHistory.引渡項目_仮想処理型.伝票区分.ToString, 受発注区分型.発注)
                .Add(ICreateKanrenHistory.引渡項目_仮想処理型.処理連番.ToString, 仕入明細.R002011)
                .Add(ICreateKanrenHistory.引渡項目_仮想処理型.行番号.ToString, 仕入明細.R002012)
            End With

            Dim 比較項目内容 As IDictionary = New Hashtable
            With 比較項目内容
                .Add(ICreateKanrenHistory.比較対象_受発注型.完納区分.ToString, 仕入明細.R002052)
            End With

            _関連履歴作成_受発注.仮想処理_加算(transaction, 引渡項目, 比較項目内容)
        Next

    End Sub

    ''' <summary>
    ''' 関連履歴作成
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Create関連履歴(ByVal transaction As DbTransaction)  'A-2009/08/21_RIREKI

        Dim 引渡項目 As IDictionary = New Hashtable
        With 引渡項目
            .Add(ICreateKanrenHistory.引渡項目_履歴作成型.伝票種類.ToString, ICreateKanrenHistory.伝票種類型.受発注)
            .Add(ICreateKanrenHistory.引渡項目_履歴作成型.最終更新操作日付.ToString, _システム日付)
            .Add(ICreateKanrenHistory.引渡項目_履歴作成型.最終更新操作時刻.ToString, _システム時刻)
        End With

        _関連履歴作成_受発注.Create関連履歴(transaction, 引渡項目)

    End Sub

#End Region

#End Region

#Region "商品内訳管理"  'A-2009/12/18_Ver7.40_UCHIWAKE

    Private Function Create内訳(ByVal transaction As DbTransaction,
                                ByVal パラメータ As 内訳登録型) As TextFileImport.IResult   'A-2009/12/18_Ver7.40_UCHIWAKE

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase
        result.Code = ResultType.成功

        Dim 内訳マスター自動登録 As String = IIf(_myImportParam.Myコントロール情報.My商品内訳管理.内訳マスター自動登録 = True, "1", "0").ToString
        Dim 内訳タイプ As String = CStr(_myImportParam.Myコントロール情報.My商品内訳管理.内訳タイプ)
        Dim データ変更履歴取得可能区分 As String = IIf(_myImportParam.Myコントロール情報.My変更履歴.変更履歴使用区分 = True, "1", "0").ToString
        Dim 変更履歴_内訳 As String = IIf(_myImportParam.Myコントロール情報.My変更履歴.変更履歴_内訳 = True, "1", "0").ToString
        Dim 変更履歴_商品内訳 As String = IIf(_myImportParam.Myコントロール情報.My変更履歴.変更履歴_商品内訳 = True, "1", "0").ToString
        Dim ロット管理 As String = IIf(_myImportParam.Myコントロール情報.Myオプション区分.ロット管理 = True, "1", "0").ToString

        Dim param As IDictionary = New Hashtable
        With param
            .Add(IComprisingItemIns.パラメータ型.商品コード.ToString, パラメータ.商品コード)
            .Add(IComprisingItemIns.パラメータ型.内訳コード１.ToString, パラメータ.内訳コード１)
            .Add(IComprisingItemIns.パラメータ型.内訳コード２.ToString, パラメータ.内訳コード２)
            .Add(IComprisingItemIns.パラメータ型.内訳コード３.ToString, パラメータ.内訳コード３)
            .Add(IComprisingItemIns.パラメータ型.単位換算数量.ToString, パラメータ.単位換算数量)
            .Add(IComprisingItemIns.パラメータ型.内訳使用区分１.ToString, パラメータ.内訳使用区分１)
            .Add(IComprisingItemIns.パラメータ型.内訳使用区分２.ToString, パラメータ.内訳使用区分２)
            .Add(IComprisingItemIns.パラメータ型.内訳使用区分３.ToString, パラメータ.内訳使用区分３)
            .Add(IComprisingItemIns.パラメータ型.ロット管理区分.ToString, パラメータ.ロット管理区分)
            .Add(IComprisingItemIns.パラメータ型.当期期首月.ToString, パラメータ.当期期首月)
            .Add(IComprisingItemIns.パラメータ型.内訳マスター自動登録.ToString, 内訳マスター自動登録)
            .Add(IComprisingItemIns.パラメータ型.内訳タイプ.ToString, _myImportParam.Myコントロール情報.My商品内訳管理.内訳タイプ)
            .Add(IComprisingItemIns.パラメータ型.データ変更履歴取得可能区分.ToString, データ変更履歴取得可能区分)
            .Add(IComprisingItemIns.パラメータ型.変更履歴_内訳.ToString, 変更履歴_内訳)
            .Add(IComprisingItemIns.パラメータ型.変更履歴_商品内訳.ToString, 変更履歴_商品内訳)
            .Add(IComprisingItemIns.パラメータ型.ロット管理.ToString, ロット管理)
        End With

        If _内訳登録 Is Nothing Then
            _内訳登録 = CommonFactory.CreateInstance(Of IComprisingItemIns)(Me, GetType(ComprisingItemIns))
            _内訳登録.Initialize(Me)
        End If
        _内訳登録.UchiwakeMstIns(transaction, param)

        Return result
    End Function

#End Region

#Region "ロット管理"    'A-2009/12/18_Ver7.40_LOT

    Private Function Createロット(ByVal transaction As DbTransaction,
                                  ByVal パラメータ As ロット登録型) As TextFileImport.IResult   'A-2009/12/18_Ver7.40_LOT

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase
        result.Code = ResultType.成功

        Dim 内訳マスター自動登録 As String = IIf(_myImportParam.Myコントロール情報.My商品内訳管理.内訳マスター自動登録 = True, "1", "0").ToString
        Dim データ変更履歴取得可能区分 As String = IIf(_myImportParam.Myコントロール情報.My変更履歴.変更履歴使用区分 = True, "1", "0").ToString
        Dim 変更履歴_ロット As String = IIf(_myImportParam.Myコントロール情報.My変更履歴.変更履歴_ロット = True, "1", "0").ToString
        Dim ロット管理 As String = IIf(_myImportParam.Myコントロール情報.Myオプション区分.ロット管理 = True, "1", "0").ToString

        Dim param As IDictionary = New Hashtable
        With param
            .Add(ILotInsert.パラメータ型.商品コード.ToString, パラメータ.商品コード)
            .Add(ILotInsert.パラメータ型.内訳コード１.ToString, パラメータ.内訳コード１)
            .Add(ILotInsert.パラメータ型.内訳コード２.ToString, パラメータ.内訳コード２)
            .Add(ILotInsert.パラメータ型.内訳コード３.ToString, パラメータ.内訳コード３)
            .Add(ILotInsert.パラメータ型.ロット番号.ToString, パラメータ.ロット番号)
            .Add(ILotInsert.パラメータ型.サブロット番号.ToString, パラメータ.サブロット番号)
            .Add(ILotInsert.パラメータ型.有効期限.ToString, パラメータ.有効期限)
            .Add(ILotInsert.パラメータ型.単価.ToString, パラメータ.単価)
            .Add(ILotInsert.パラメータ型.内訳使用区分１.ToString, パラメータ.内訳使用区分１)
            .Add(ILotInsert.パラメータ型.内訳使用区分２.ToString, パラメータ.内訳使用区分２)
            .Add(ILotInsert.パラメータ型.内訳使用区分３.ToString, パラメータ.内訳使用区分３)
            .Add(ILotInsert.パラメータ型.当期期首月.ToString, パラメータ.当期期首月)
            .Add(ILotInsert.パラメータ型.内訳タイプ.ToString, _myImportParam.Myコントロール情報.My商品内訳管理.内訳タイプ)
            .Add(ILotInsert.パラメータ型.データ変更履歴取得可能区分.ToString, データ変更履歴取得可能区分)
            .Add(ILotInsert.パラメータ型.変更履歴_ロット.ToString, 変更履歴_ロット)
        End With

        If _ロット登録 Is Nothing Then
            _ロット登録 = CommonFactory.CreateInstance(Of ILotInsert)(Me, GetType(LotInsert))
            _ロット登録.Initialize(Me)
        End If
        _ロット登録.LotMstIns(transaction, param)

        Return result
    End Function

#End Region

    'A-CUST20190830↓
#Region "カスタマイズ"
    Private Function InsertSEIR008_CUST_自分(ByRef transaction As DbTransaction,
                                   ByVal 更新データ As S90050_00.WorkTableUnitData
                ) As TextFileImport.IResult
        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim myDataUpdater As New MyDataUpdater
        myDataUpdater.Initialize(Me, _myImportParam)

        For i As Integer = 0 To 更新データ.入庫伝票更新件数_自分 - 1
            更新データ.ロット明細(i) = 更新データ.ロット明細_自分(i)

            result = myDataUpdater.InsertSEIR008(transaction, 更新データ, i)
            If result.Code <> ResultType.成功 Then
                Return result
            End If
        Next

        Return result
    End Function

    Private Function InsertSEIR008_CUST_相手(ByRef transaction As DbTransaction,
                                   ByVal 更新データ As S90050_00.WorkTableUnitData
                ) As TextFileImport.IResult
        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        Dim myDataUpdater As New MyDataUpdater
        myDataUpdater.Initialize(Me, _myImportParam)

        For i As Integer = 0 To 更新データ.出庫伝票更新件数_相手 - 1
            更新データ.ロット明細(i) = 更新データ.ロット明細_相手(i)

            result = myDataUpdater.InsertSEIR008(transaction, 更新データ, i)
            If result.Code <> ResultType.成功 Then
                Return result
            End If
        Next

        Return result
    End Function

    Private Function 拡張項目更新_CUST_自分(ByRef transaction As DbTransaction,
                                       ByVal 更新データ As S90050_00.WorkTableUnitData
            ) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase
        Dim 拡張項目情報 As I拡張項目入力情報型 = CommonFactory.CreateInstance(Of I拡張項目入力情報型)(Me, GetType(拡張項目入力情報型))
        Dim 拡張項目入力情報 As I拡張項目入力情報型

        '伝票拡張項目登録
        If _myImportParam.Myコントロール情報.Myオプション区分.拡張項目_入出庫伝票 = True Then
            拡張項目入力情報 = 更新データ.入庫ヘッダー_自分.拡張項目入力情報

            With 拡張項目情報
                .伝票種類 = I拡張項目入力情報型.伝票種類型.入出庫
                .明細区分 = I拡張項目入力情報型.明細区分型.通常
                .連番 = 更新データ.入庫ヘッダー_自分.R001006
                .行番号 = 0
                .付箋色番号 = 拡張項目入力情報.付箋色番号
                For i As Integer = 1 To ProgramLib.MAX_EXPANDITEM_COUNT
                    .拡張項目(i) = 拡張項目入力情報.拡張項目(i)
                Next
                .更新番号 = _myImportParam.拡張項目情報_入出庫伝票.更新番号

                result = InsertExpandItem(transaction, 拡張項目情報)
                If result.Code <> ResultType.成功 Then
                    Return result
                End If
            End With
        End If

        '明細拡張項目登録
        If _myImportParam.Myコントロール情報.Myオプション区分.拡張項目_入出庫明細 = True Then
            For line As Integer = 0 To 更新データ.入庫伝票更新件数_自分 - 1
                拡張項目入力情報 = 更新データ.入庫明細_自分(line).拡張項目入力情報

                With 拡張項目情報
                    .伝票種類 = I拡張項目入力情報型.伝票種類型.入出庫
                    .明細区分 = I拡張項目入力情報型.明細区分型.通常
                    .連番 = 更新データ.入庫明細_自分(line).R002004
                    .行番号 = 更新データ.入庫明細_自分(line).R002006
                    .付箋色番号 = 拡張項目入力情報.付箋色番号
                    For i As Integer = 1 To ProgramLib.MAX_EXPANDITEM_COUNT
                        .拡張項目(i) = 拡張項目入力情報.拡張項目(i)
                    Next
                    .更新番号 = _myImportParam.拡張項目情報_入出庫明細.更新番号

                    result = InsertExpandItem(transaction, 拡張項目情報)
                    If result.Code <> ResultType.成功 Then
                        Return result
                    End If
                End With
            Next
        End If

        Return result

    End Function

    Private Function 拡張項目更新_CUST_相手(ByRef transaction As DbTransaction,
                                       ByVal 更新データ As S90050_00.WorkTableUnitData
            ) As TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase
        Dim 拡張項目情報 As I拡張項目入力情報型 = CommonFactory.CreateInstance(Of I拡張項目入力情報型)(Me, GetType(拡張項目入力情報型))
        Dim 拡張項目入力情報 As I拡張項目入力情報型

        '伝票拡張項目登録
        If _myImportParam.Myコントロール情報.Myオプション区分.拡張項目_入出庫伝票 = True Then
            拡張項目入力情報 = 更新データ.入庫ヘッダー_自分.拡張項目入力情報

            With 拡張項目情報
                .伝票種類 = I拡張項目入力情報型.伝票種類型.入出庫
                .明細区分 = I拡張項目入力情報型.明細区分型.通常
                .連番 = 更新データ.出庫ヘッダー_相手.R001006
                .行番号 = 0
                .付箋色番号 = 拡張項目入力情報.付箋色番号
                For i As Integer = 1 To ProgramLib.MAX_EXPANDITEM_COUNT
                    .拡張項目(i) = 拡張項目入力情報.拡張項目(i)
                Next
                .更新番号 = _myImportParam.拡張項目情報_入出庫伝票.更新番号

                result = InsertExpandItem(transaction, 拡張項目情報)
                If result.Code <> ResultType.成功 Then
                    Return result
                End If
            End With
        End If

        '明細拡張項目登録
        If _myImportParam.Myコントロール情報.Myオプション区分.拡張項目_入出庫明細 = True Then
            For line As Integer = 0 To 更新データ.出庫伝票更新件数_相手 - 1

                拡張項目入力情報 = 更新データ.出庫明細_相手(line).拡張項目入力情報

                With 拡張項目情報
                    .伝票種類 = I拡張項目入力情報型.伝票種類型.入出庫
                    .明細区分 = I拡張項目入力情報型.明細区分型.通常
                    .連番 = 更新データ.出庫明細_相手(line).R002004
                    .行番号 = 更新データ.出庫明細_相手(line).R002006
                    .付箋色番号 = 拡張項目入力情報.付箋色番号
                    For i As Integer = 1 To ProgramLib.MAX_EXPANDITEM_COUNT
                        .拡張項目(i) = 拡張項目入力情報.拡張項目(i)
                    Next
                    .更新番号 = _myImportParam.拡張項目情報_入出庫明細.更新番号

                    result = InsertExpandItem(transaction, 拡張項目情報)
                    If result.Code <> ResultType.成功 Then
                        Return result
                    End If
                End With
            Next
        End If

        Return result

    End Function

    Private Function ReadSEIRA02PrimaryKey(ByRef transaction As DbTransaction,
                                       ByRef 取得したデータ As DataTable,
                                       ByVal 番号 As Long
            ) As Foundation.ResultType

        Dim myDataReader As New MyDataReader
        myDataReader.Initialize(Me, _myImportParam)
        Return myDataReader.Read入出荷予定ヘッダーCUST(transaction, 取得したデータ, 番号)

    End Function

    Private Function ReadSEIRA03PrimaryKey(ByRef transaction As DbTransaction,
                                       ByRef 取得したデータ As DataTable,
                                       ByVal 番号 As Long,
                                       ByVal 行番号 As Integer
            ) As Foundation.ResultType

        Dim myDataReader As New MyDataReader
        myDataReader.Initialize(Me, _myImportParam)
        Return myDataReader.Read入出荷予定伝票CUST(transaction, 取得したデータ, 番号, 行番号)

    End Function

    Private Function ReadSEIRA03PrimaryKey(ByRef transaction As DbTransaction,
                                       ByRef 取得したデータ As DataTable,
                                       ByVal 番号 As Long
            ) As Foundation.ResultType

        Dim myDataReader As New MyDataReader
        myDataReader.Initialize(Me, _myImportParam)
        Return myDataReader.Read入出荷予定伝票CUST(transaction, 取得したデータ, 番号)

    End Function

#End Region
    'A-CUST20190830↑

End Class
