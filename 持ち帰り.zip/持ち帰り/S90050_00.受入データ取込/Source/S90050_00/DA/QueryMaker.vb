﻿Public Class QueryMaker
    Inherits QueryMakerBase
    Implements IMyQueryMaker

#Region "■定義■"

    Private _myImportParam As ImportParam
    ''' <summary>
    ''' 取込実行パラメータ
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property MyImportParam() As ImportParam Implements IMyQueryMaker.MyImportParam
        Get
            Return _myImportParam
        End Get
        Set(ByVal value As ImportParam)
            _myImportParam = value
        End Set
    End Property

#End Region

#Region "■列挙型■"

    Private Enum 製造出庫項目型 As Integer
        発生元相手連番 = 1
        手配管理番号
        手配番号
        処理連番
        行番号
        テーブルID
        品目コード
        品目名
        倉庫コード
        ロケーション
        ロットNo
        支給出庫予定数量
        引落数量
        強制完納区分
        数量単位
        部番
        行摘要コード
        行摘要１
        行摘要２
        支給出庫済数量
        費目コード
        費目区分
        有償支給数量
        無償支給数量
        標準支給単価
        在庫管理区分
        在庫引当対象区分
        基準倉庫コード
        正式名称１
        正式名称２
        正式名称３
        ロット管理区分
        基準ロケーション
        倉庫略称
        数量
        原単位区分
        取数分子
        取数分母
        支給区分
        需要数計算単位
        対象倉庫区分
        伝票番号
        伝票日付
        変更前伝票日付
        出庫予定日
        材料費
        労務費
        外注費
        みなし出庫区分                      'A-20111124_3
        倉庫コード_みなし出庫移動有用       'A-20111124_3
        ロケーション_みなし出庫移動有用     'A-20111124_3
        倉庫移動出庫処理連番                'A-20111124_3
        展開順序番号                        'A-20121217_Ver7.50_4
        出庫引当済数                        'A-20121217_Ver7.50_4
        引落引当済数                        'A-20121217_Ver7.50_4
        引当状態                            'A-20121217_Ver7.50_4
        出庫行番号                          'A-20130603_1
        経費                                'A-20141105_1
    End Enum

#End Region


#Region "■販売データ仕訳作成日付管理テーブル■"

    Public Function SelectHANC015UpdateLock(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal 伝票日付 As Integer
                    ) As String Implements IMyQueryMaker.SelectHANC015UpdateLock    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append(" SELECT")
        query.Append(" HANC015003 ")

        query.Append(" FROM ")
        query.Append(Me.ExchangeTableName("HAN10C015SDATE") & Space$(1))    'X1変換Tool-20170509
        query.Append(QueryWrapper.AddUpdLock(True))

        query.Append(" WHERE HANC015001 = " & AddParamInfo(paramInfo, "HANC015001", DbType.Decimal, 0, 8, 0, 伝票日付))
        query.Append("   AND HANC015002 = 1 ")
        query.Append("   AND HANC015003 = 0 ")

        query.Append(Space$(1))
        query.Append(QueryWrapper.AddForUpdate(True))

        Return query.ToString

    End Function

    Public Function UpdateHANC015(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                  ByVal 伝票日付 As Integer
                    ) As String Implements IMyQueryMaker.UpdateHANC015    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append(" UPDATE ")
        query.Append(Me.ExchangeTableName("HAN10C015SDATE"))    'X1変換Tool-20170509

        query.Append(" SET ")
        query.Append(" HANC015003 = 1 ")
        query.Append(" WHERE HANC015001 = " & AddParamInfo(paramInfo, "HANC015001", DbType.Decimal, 0, 8, 0, 伝票日付))
        query.Append("   AND HANC015002 = 1 ")
        query.Append("   AND HANC015003 = 0 ")

        Return query.ToString

    End Function

#End Region

#Region "■連番管理テーブル■"

    Public Function SelectHANC021PrimaryKey() As String Implements IMyQueryMaker.SelectHANC021PrimaryKey

        Dim query As New System.Text.StringBuilder

        query.Append(" SELECT")
        query.Append(" HANC021002 ")

        query.Append(" FROM ")
        query.Append(Me.ExchangeTableName("HAN10C021RENBAN") & Space$(1) & Me.QueryWrapper.AddNoLock)    'X1変換Tool-20170509

        query.Append(" WHERE HANC021001 = '021' ")

        query.Append(Space$(1))
        query.Append(QueryWrapper.AddUR())

        Return query.ToString

    End Function

    Public Function UpdateHANC021(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                  ByVal 処理連番 As Long
                    ) As String Implements IMyQueryMaker.UpdateHANC021    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append(" UPDATE ")
        query.Append(Me.ExchangeTableName("HAN10C021RENBAN"))    'X1変換Tool-20170509

        query.Append(" SET ")
        query.Append(" HANC021002 = " & AddParamInfo(paramInfo, "HANC021002", DbType.Decimal, 0, 10, 0, 処理連番))
        query.Append(" WHERE HANC021001 = '021' ")

        Return query.ToString

    End Function

#End Region

#Region "■伝票番号管理テーブル■"

    Public Function SelectHANC022PrimaryKey() As String Implements IMyQueryMaker.SelectHANC022PrimaryKey

        Dim query As New System.Text.StringBuilder

        query.Append(" SELECT")
        query.Append(" HANC022004 ")
        query.Append(",HANC022006 ")
        query.Append(",HANC022009 ")
        query.Append(",HANC022A002 ")
        query.Append(",HANC022A005 ")

        query.Append(" FROM ")
        query.Append(Me.ExchangeTableName("HAN10C022DENNO") & Space$(1) & Me.QueryWrapper.AddNoLock)    'X1変換Tool-20170509

        query.Append(" WHERE HANC022001 = '022' ")

        query.Append(Space$(1))
        query.Append(QueryWrapper.AddUR())

        Return query.ToString

    End Function

    Public Function UpdateHANC022(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                  ByVal 更新データ As WorkTableUnitData
                    ) As String Implements IMyQueryMaker.UpdateHANC022    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append(" UPDATE ")
        query.Append(Me.ExchangeTableName("HAN10C022DENNO"))    'X1変換Tool-20170509

        query.Append(" SET ")
        query.Append(" HANC022004 = " & AddParamInfo(paramInfo, "HANC022004", DbType.Decimal, 0, 8, 0, 更新データ.伝票番号管理テーブル.C022004))
        query.Append(",HANC022006 = " & AddParamInfo(paramInfo, "HANC022006", DbType.Decimal, 0, 8, 0, 更新データ.伝票番号管理テーブル.C022006))
        query.Append(",HANC022009 = " & AddParamInfo(paramInfo, "HANC022009", DbType.Decimal, 0, 8, 0, 更新データ.伝票番号管理テーブル.C022009))
        query.Append(",HANC022A002 = " & AddParamInfo(paramInfo, "HANC022A002", DbType.Decimal, 0, 8, 0, 更新データ.伝票番号管理テーブル.C022A002))
        query.Append(",HANC022A005 = " & AddParamInfo(paramInfo, "HANC022A005", DbType.Decimal, 0, 8, 0, 更新データ.伝票番号管理テーブル.C022A005))
        query.Append(" WHERE HANC022001 = '022' ")

        Return query.ToString

    End Function

#End Region

#Region "■ロット連番管理テーブル■"

    ''' <summary>
    ''' ロット連番管理テーブルの更新（Insert）
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function InsertSEIC056(ByRef paramInfo As ParamInfoList,
                                  ByVal 更新データ As WorkTableUnitData) As String Implements IMyQueryMaker.InsertSEIC056

        Dim query As New System.Text.StringBuilder
        query.Append(" INSERT INTO ")
        query.Append(Me.ExchangeTableName("SEI10C056LOT"))    'X1変換Tool-20170509

        query.Append(" (")
        query.Append(" SEIC056001")
        query.Append(",SEIC056002")
        query.Append(",SEIC056003")
        query.Append(" )")

        query.Append(" VALUES (")
        query.Append(" " & AddParamInfo(paramInfo, "SEIC056001", DbType.Decimal, 0, 1, 0, 更新データ.ロット連番管理.C056001))
        query.Append("," & AddParamInfo(paramInfo, "SEIC056002", DbType.AnsiStringFixedLength, 25, 0, 0, 更新データ.ロット連番管理.C056002))
        query.Append("," & AddParamInfo(paramInfo, "SEIC056003", DbType.AnsiStringFixedLength, 20, 0, 0, 更新データ.ロット連番管理.C056003))
        query.Append(" )")

        Return query.ToString
    End Function

    ''' <summary>
    ''' ロット連番管理テーブルの更新（Update）
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function UpdateSEIC056(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                  ByVal 更新データ As WorkTableUnitData) As String Implements IMyQueryMaker.UpdateSEIC056    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append(" UPDATE ")
        query.Append(Me.ExchangeTableName("SEI10C056LOT"))    'X1変換Tool-20170509

        query.Append(" SET ")
        query.Append(" SEIC056003 = " & AddParamInfo(paramInfo, "SEIC056003", DbType.AnsiStringFixedLength, 20, 0, 0, 更新データ.ロット連番管理.C056003))

        query.Append(" WHERE ")
        query.Append(" SEIC056001 = " & AddParamInfo(paramInfo, "SEIC056001", DbType.Decimal, 0, 1, 0, 更新データ.ロット連番管理.C056001))
        query.Append(" AND ")
        query.Append(" SEIC056002 = " & AddParamInfo(paramInfo, "SEIC056002", DbType.AnsiStringFixedLength, 25, 0, 0, 更新データ.ロット連番管理.C056002))

        Return query.ToString

    End Function

#End Region

#Region "■ロット№管理テーブル■"

    Public Function SelectHANC023PrimaryKey() As String Implements IMyQueryMaker.SelectHANC023PrimaryKey    'A-2009/12/18_Ver7.40_LOT

        Dim query As New System.Text.StringBuilder

        query.Append(" SELECT")
        query.Append(" HANC023002 ")

        query.Append(" FROM ")
        query.Append(Me.ExchangeTableName("HAN10C023LOTRENBAN") & Space$(1) & Me.QueryWrapper.AddNoLock)    'X1変換Tool-20170509

        query.Append(" WHERE HANC023001 = '023' ")

        query.Append(Space$(1))
        query.Append(QueryWrapper.AddUR())

        Return query.ToString

    End Function

    Public Function UpdateHANC023(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                  ByVal ロットNo As Decimal
                    ) As String Implements IMyQueryMaker.UpdateHANC023  'A-2009/12/18_Ver7.40_LOT    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append(" UPDATE ")
        query.Append(Me.ExchangeTableName("HAN10C023LOTRENBAN"))    'X1変換Tool-20170509

        query.Append(" SET ")
        query.Append(" HANC023002 = " & AddParamInfo(paramInfo, "HANC023002", DbType.Decimal, 0, 20, 0, ロットNo))
        query.Append(" WHERE HANC023001 = '023' ")

        Return query.ToString

    End Function

#End Region

#Region "■仕入先マスター■"

    '存在チェック
    Public Function SelectHANM002PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal 仕入先コード As String
                    ) As String Implements IMyQueryMaker.SelectHANM002PrimaryKey    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(" SHIIRE.HANM002001 HANM002001 ")                                                          '請求先コード
        query.Append(",SHIIRE.HANM002041 HANM002041 ")                                                          '端数処理区分 単価
        query.Append(",SHIIRE.HANM002042 HANM002042 ")                                                          '端数処理単位 単価
        query.Append(",SHIIRE.HANM002043 HANM002043 ")                                                          '端数処理区分 金額
        'A-CUST20190830↓
        query.Append(",SHIIRE.HANM002044 HANM002044 ")                                                          '消費税計算  処理区分
        query.Append(",SHIIRE.HANM002045 HANM002045 ")                                                          '消費税計算  処理単位
        'A-CUST20190830↑
        query.Append(",SHIIRE.HANM002046 HANM002046 ")                                                          '端数処理区分 消費税分解
        query.Append(",SHIIRE.HANM002047 HANM002047 ")                                                          'A-CUST20190830
        query.Append(",SHIIRE.HANM002050 HANM002050 ")                                                          '消費税通知区分
        query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SHIHARAI.HANM002989, 0) HANM002989SHIHARAI ")   '締日付
        query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANM035011, 0) HANM035011 ")                    '請求処理連番
        '↓A-2008/07/18_Ver7.30_SHIHARAI
        If MyImportParam.Myコントロール情報.Myオプション区分.支払管理 = オプション区分定義型.区分型.行う Then
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SHIHARAI.HANM002027, 0) HANM002027SHIHARAI ")       '締日１
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SHIHARAI.HANM002028, 0) HANM002028SHIHARAI ")       '締日２
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SHIHARAI.HANM002029, 0) HANM002029SHIHARAI ")       '締日３
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SHIHARAI.HANM002030, 0) HANM002030SHIHARAI ")       '支払日１
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SHIHARAI.HANM002031, 0) HANM002031SHIHARAI ")       '支払日２
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SHIHARAI.HANM002032, 0) HANM002032SHIHARAI ")       '支払日３
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SHIHARAI.HANM002033, 0) HANM002033SHIHARAI ")       '支払サイクル１
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SHIHARAI.HANM002034, 0) HANM002034SHIHARAI ")       '支払サイクル２
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SHIHARAI.HANM002035, 0) HANM002035SHIHARAI ")       '支払サイクル３
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SHIHARAI.HANM002090, 0) HANM002090SHIHARAI ")       '支払管理区分
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SHIHARAI.HANM002091, 0) HANM002091SHIHARAI ")       '支払管理単位
        End If
        '↑A-2008/07/18_Ver7.30_SHIHARAI
        'A-20121217_Ver7.50_1↓
        If MyImportParam.Myコントロール情報.MyMOAオプション.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う Then
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SHIIRE.HANM002S004, 0) HANM002S004 ")               '海外取引先区分
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SHIIRE.HANM002S005, ' ') HANM002S005 ")             '通貨コード
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SHIIRE.HANM002S008, 0) HANM002S008 ")               '単価区分(外貨)
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SHIIRE.HANM002S009, 0) HANM002S009 ")               '金額区分(外貨)
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SHIIRE.HANM002S010, 0) HANM002S010 ")               '支払予定日
            '
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SEIM013001, ' ') SEIM013001 ")                      '通貨コード
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SEIM013006, 0) SEIM013006 ")                        'レート桁数
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SEIM013007, 0) SEIM013007 ")                        '通貨単位
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SEIM013S002, 0) SEIM013S002 ")                      '入力桁数(金額)(仕入)
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SEIM013S003, 0) SEIM013S003 ")                      '入力桁数(単価)(仕入)
        End If
        'A-20121217_Ver7.50_1↑

        query.Append("FROM " & MyBase.ExchangeTableName("HAN10M002SHIIRE") & " SHIIRE ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())

        query.Append("INNER JOIN " & MyBase.ExchangeTableName("HAN10M002SHIIRE") & " SHIHARAI ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())
        query.Append("   ON SHIHARAI.HANM002003 = SHIIRE.HANM002001 ")

        query.Append("LEFT OUTER JOIN " & MyBase.ExchangeTableName("HAN10M035SHIMEG") & " ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())
        query.Append("   ON HANM035001 = 1 ")
        query.Append("  AND HANM035002 = SHIHARAI.HANM002991 ")

        'A-20121217_Ver7.50_1↓
        If MyImportParam.Myコントロール情報.MyMOAオプション.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う Then
            '通貨マスター
            query.Append(" LEFT OUTER JOIN ")
            query.Append(Me.ExchangeTableName("SEI10M013TUUKA ") & QueryWrapper.AddNoLock)    'X1変換Tool-20170509
            query.Append("  ON " & "SEIM013001 = SHIIRE.HANM002S005 ")
        End If
        'A-20121217_Ver7.50_1↑

        query.Append("WHERE ")
        query.Append("SHIIRE.HANM002003 = " & AddParamInfo(paramInfo, "HANM002003", DbType.AnsiStringFixedLength, 11, 0, 0, 仕入先コード))
        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString

    End Function

#End Region

#Region "■商品マスター■"

    '存在チェック
    Public Function SelectHANM003PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal 商品コード As String
                    ) As String Implements IMyQueryMaker.SelectHANM003PrimaryKey    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(" " & MyBase.QueryWrapper.AddIsNull() & " (HANM003002, ' ') HANM003002 ")
        query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANM003004, ' ') HANM003004 ")
        query.Append(",HANM003007 ")
        query.Append(",HANM003008 ")
        query.Append(",HANM003009 ")
        query.Append(",HANM003015 ")
        query.Append(",HANM003029 ")
        query.Append(",HANM003035 ")
        query.Append(",HANM003039 ")
        query.Append(",HANM003040 ")
        query.Append(",HANM003041 ")
        query.Append(",HANM003042 ")
        query.Append(",HANM003045 ")
        '↓A-2009/12/18_Ver7.40_UCHIWAKE
        query.Append(",HANM003051 ")
        query.Append(",HANM003052 ")
        query.Append(",HANM003053 ")
        query.Append(",HANM003054 ")            'A-20121217_Ver7.50_2
        If _myImportParam.Myコントロール情報.Myオプション区分.商品内訳管理 = True Then
            query.Append(",HANM003086 ")
        End If
        If _myImportParam.Myコントロール情報.Myオプション区分.ロット管理 = True Then
            query.Append(",HANM003092 ")
            query.Append(",HANM003093 ")        'A-2009/12/18_Ver7.40_LOT
            query.Append(",HANM003094 ")        'A-2009/12/18_Ver7.40_LOT
        End If
        '↑A-2009/12/18_Ver7.40_UCHIWAKE

        query.Append(",HANM003A005 ")
        query.Append(",HANM003A010 ")           '基準倉庫コード         'A-20141105_2
        query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANM003A014, ' ') HANM003A014 ")
        query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANM003A015, ' ') HANM003A015 ")
        query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANM003A016, ' ') HANM003A016 ")
        query.Append(",HANM003A017 ")
        query.Append(",HANM003A019 ")
        query.Append(",HANM003A024 ")
        query.Append(",HANM003A026 ")
        query.Append(",HANM003A027 ")           '基準ロケーション       'A-20141105_2
        query.Append(",HANM003A028 ")
        query.Append(",HANM003A029 ")
        query.Append(",HANM003A030 ")
        query.Append(",HANM003A031 ")
        query.Append(",HANM003A032 ")

        'A-20121217_Ver7.50_1↓
        If MyImportParam.Myコントロール情報.MyMOAオプション.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う Then
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANM003S007, ' ') HANM003S007 ")                    '外国語品目名１
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANM003S008, ' ') HANM003S008 ")                    '外国語品目名２
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANM003S009, ' ') HANM003S009 ")                    '外国語品目名３
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANM003S010, ' ') HANM003S010 ")                    '外国語単位
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANM003S011, ' ') HANM003S011 ")                    '外国語個数単位
        End If
        'A-20121217_Ver7.50_1↑

        'A-20130304_1↓
        If MyImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 4.0 Then
            query.Append(",HANM003S015 ")
        End If
        'A-20130304_1↑
        'A-20141105_1↓
        If MyImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 6D Then
            query.Append(",HANM003S030 ")
        End If
        'A-20141105_1↑
        'A-CUST20190830↓
        query.Append(",HANM003001 ")
        query.Append(",HANM003016 ")
        query.Append(",HANM003036 ")
        query.Append(",HANM003A033 ")
        'A-CUST20190830↑

        query.Append("FROM " & MyBase.ExchangeTableName("HAN10M003SHOHIN") & " ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())
        query.Append("WHERE ")
        query.Append("HANM003001 = " & AddParamInfo(paramInfo, "HANM003001", DbType.AnsiStringFixedLength, 25, 0, 0, 商品コード))
        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString

    End Function

#End Region

#Region "■仕入担当者マスター■"

    '存在チェック
    Public Function SelectHANM005PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal 担当者コード As String
                    ) As String Implements IMyQueryMaker.SelectHANM005PrimaryKey    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append("HANM005001 ")
        query.Append("FROM " & MyBase.ExchangeTableName("HAN10M005STANTO") & " ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())
        query.Append("WHERE ")
        query.Append("HANM005001 = " & AddParamInfo(paramInfo, "HANM005001", DbType.AnsiStringFixedLength, 8, 0, 0, 担当者コード))
        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString

    End Function

#End Region

#Region "■倉庫マスター■"

    '存在チェック
    Public Function SelectHANM006PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal 倉庫コード As String
                    ) As String Implements IMyQueryMaker.SelectHANM006PrimaryKey    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(" " & MyBase.QueryWrapper.AddIsNull() & " (HANM006002, ' ') HANM006002 ")
        query.Append(",HANM006A001 ")
        query.Append(",HANM006A002 ")
        query.Append("FROM " & MyBase.ExchangeTableName("HAN10M006SOKO") & " ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())
        query.Append("WHERE ")
        query.Append("HANM006001 = " & AddParamInfo(paramInfo, "HANM006001", DbType.AnsiStringFixedLength, 11, 0, 0, 倉庫コード))
        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString

    End Function

#End Region

#Region "■備考マスター■"

    '存在チェック
    Public Function SelectHANM008PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal 備考コード As String
                    ) As String Implements IMyQueryMaker.SelectHANM008PrimaryKey    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(" HANM008001 ")
        query.Append("FROM " & MyBase.ExchangeTableName("HAN10M008BIKO") & " ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())
        query.Append("WHERE ")
        query.Append("HANM008001 = " & AddParamInfo(paramInfo, "HANM008001", DbType.AnsiStringFixedLength, 5, 0, 0, 備考コード))
        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString

    End Function

#End Region

#Region "■摘要マスター■"

    '存在チェック
    Public Function SelectHANM009PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal 摘要コード As String
                    ) As String Implements IMyQueryMaker.SelectHANM009PrimaryKey    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(" HANM009001 ")
        query.Append("FROM " & MyBase.ExchangeTableName("HAN10M009TEKIYOU") & " ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())
        query.Append("WHERE ")
        query.Append("HANM009001 = " & AddParamInfo(paramInfo, "HANM009001", DbType.AnsiStringFixedLength, 5, 0, 0, 摘要コード))
        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString

    End Function

#End Region

#Region "■分類名マスター■"    'A-2008/07/18_Ver7.30_GENKA

    '存在チェック
    Public Function SelectHANM010PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal マスター区分 As Integer,
                                            ByVal 分類種別番号 As Integer,
                                            ByVal 分類コード As String
                    ) As String Implements IMyQueryMaker.SelectHANM010PrimaryKey            'A-2008/07/18_Ver7.30_GENKA    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(" HANM010003 ")
        query.Append("FROM " & MyBase.ExchangeTableName("HAN10M010BUNRUI") & " ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())
        query.Append("WHERE ")
        query.Append("     HANM010001 = " & AddParamInfo(paramInfo, "HANM010001", DbType.Decimal, 0, 2, 0, マスター区分))
        query.Append(" AND HANM010002 = " & AddParamInfo(paramInfo, "HANM010002", DbType.Decimal, 0, 1, 0, 分類種別番号))
        query.Append(" AND HANM010003 = " & AddParamInfo(paramInfo, "HANM010003", DbType.AnsiStringFixedLength, 8, 0, 0, 分類コード))
        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString

    End Function

#End Region

#Region "■部門マスター■"

    '存在チェック
    Public Function SelectHANM015PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal 部門コード As String
                    ) As String Implements IMyQueryMaker.SelectHANM015PrimaryKey    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(" HANM015001 ")
        query.Append("FROM " & MyBase.ExchangeTableName("HAN10M015BUMON") & " ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())
        query.Append("WHERE ")
        query.Append("HANM015001 = " & AddParamInfo(paramInfo, "HANM015001", DbType.AnsiStringFixedLength, 8, 0, 0, 部門コード))
        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString

    End Function

#End Region

#Region "■内訳マスター■"  'A-2009/12/18_Ver7.40_UCHIWAKE

    '存在チェック
    Public Function SelectHANM021PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal 内訳種別 As Integer,
                                            ByVal 内訳コード As String
                    ) As String Implements IMyQueryMaker.SelectHANM021PrimaryKey    'A-2009/12/18_Ver7.40_UCHIWAKE    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(" HANM021001 ")
        query.Append("FROM " & MyBase.ExchangeTableName("HAN10M021UCHIWAKE") & " ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())
        query.Append(" WHERE HANM021001 = " & AddParamInfo(paramInfo, "HANM021001", DbType.Decimal, 0, 1, 0, 内訳種別) & " ")
        query.Append("   AND HANM021002 = " & AddParamInfo(paramInfo, "HANM021002", DbType.AnsiStringFixedLength, 20, 0, 0, 内訳コード) & " ")
        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString

    End Function

#End Region

#Region "■商品内訳マスター■"  'A-2009/12/18_Ver7.40_UCHIWAKE

    '存在チェック
    Public Function SelectHANM023PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal 読込キー As ProgramLib.商品内訳マスター型
                    ) As String Implements IMyQueryMaker.SelectHANM023PrimaryKey    'A-2009/12/18_Ver7.40_UCHIWAKE    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(" HANM023006 ")
        query.Append("FROM " & MyBase.ExchangeTableName("HAN10M023SHOHINUCHIM") & " ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())
        query.Append(" WHERE HANM023001 = " & AddParamInfo(paramInfo, "HANM023001", DbType.AnsiStringFixedLength, 25, 0, 0, 読込キー.M023001) & " ")
        query.Append("   AND HANM023002 = " & AddParamInfo(paramInfo, "HANM023002", DbType.AnsiStringFixedLength, 20, 0, 0, 読込キー.M023002) & " ")
        query.Append("   AND HANM023003 = " & AddParamInfo(paramInfo, "HANM023003", DbType.AnsiStringFixedLength, 20, 0, 0, 読込キー.M023003) & " ")
        query.Append("   AND HANM023004 = " & AddParamInfo(paramInfo, "HANM023004", DbType.AnsiStringFixedLength, 20, 0, 0, 読込キー.M023004) & " ")
        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString

    End Function

#End Region

#Region "■拡張項目参照マスター■"

    '存在チェック
    Public Function SelectHANM031PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal 参照定義コード As String,
                                            ByVal コード As String
                    ) As String Implements IMyQueryMaker.SelectHANM031PrimaryKey    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(" HANM031002 ")
        query.Append("FROM " & MyBase.ExchangeTableName("HAN10M031SANSHO") & " ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())
        query.Append("WHERE ")
        query.Append("HANM031001 = " & AddParamInfo(paramInfo, "HANM031001", DbType.AnsiStringFixedLength, 4, 0, 0, 参照定義コード))
        query.Append("AND HANM031002 = " & AddParamInfo(paramInfo, "HANM031002", DbType.String, 20, 0, 0, コード))
        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString

    End Function

#End Region

#Region "■営業所マスター■"

    '存在チェック
    Public Function SelectHANM036PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal 営業所コード As String
                    ) As String Implements IMyQueryMaker.SelectHANM036PrimaryKey    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(" HANM036001 ")
        query.Append("FROM " & MyBase.ExchangeTableName("HAN10M036EIGYOU") & " ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())
        query.Append("WHERE ")
        query.Append("HANM036001 = " & AddParamInfo(paramInfo, "HANM036001", DbType.AnsiStringFixedLength, 8, 0, 0, 営業所コード))
        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString

    End Function

#End Region

#Region "■原価集計マスター■"    'A-2008/07/18_Ver7.30_GENKA

    '存在チェック
    Public Function SelectHANM040PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal 原価集計メインコード As String,
                                            ByVal 原価集計サブコード As String
                    ) As String Implements IMyQueryMaker.SelectHANM040PrimaryKey    'A-2008/07/18_Ver7.30_GENKA    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(" HANM040009 ")
        query.Append(",HANM040037 ")
        query.Append("FROM " & MyBase.ExchangeTableName("HAN10M040GENKA") & " ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())
        query.Append("WHERE ")
        query.Append("     HANM040001 = " & AddParamInfo(paramInfo, "HANM040001", DbType.AnsiStringFixedLength, 20, 0, 0, 原価集計メインコード))
        query.Append(" AND HANM040002 = " & AddParamInfo(paramInfo, "HANM040002", DbType.AnsiStringFixedLength, 2, 0, 0, 原価集計サブコード))
        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString

    End Function

#End Region

#Region "■ロットマスター■"    'A-2009/12/18_Ver7.40_LOT

    '存在チェック
    Public Function SelectHANM045PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal 読込キー As ProgramLib.ロットマスター型
                    ) As String Implements IMyQueryMaker.SelectHANM045PrimaryKey    'A-2009/12/18_Ver7.40_LOT    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(" HANM045010 ")
        query.Append("FROM " & MyBase.ExchangeTableName("HAN10M045LOT") & " ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())
        query.Append(" WHERE HANM045001 = " & AddParamInfo(paramInfo, "HANM045001", DbType.AnsiStringFixedLength, 25, 0, 0, 読込キー.M045001) & " ")
        query.Append("   AND HANM045002 = " & AddParamInfo(paramInfo, "HANM045002", DbType.AnsiStringFixedLength, 20, 0, 0, 読込キー.M045002) & " ")
        query.Append("   AND HANM045003 = " & AddParamInfo(paramInfo, "HANM045003", DbType.AnsiStringFixedLength, 20, 0, 0, 読込キー.M045003) & " ")
        query.Append("   AND HANM045004 = " & AddParamInfo(paramInfo, "HANM045004", DbType.AnsiStringFixedLength, 20, 0, 0, 読込キー.M045004) & " ")
        query.Append("   AND HANM045005 = " & AddParamInfo(paramInfo, "HANM045005", DbType.AnsiStringFixedLength, 20, 0, 0, 読込キー.M045005) & " ")
        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString

    End Function

#End Region

#Region "■取引ヘッダー■"

    Public Function SelectHANR001PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal 処理連番 As Long,
                                            Optional ByVal 明細区分 As Integer = -1,
                                            Optional ByVal 行番号 As Integer = -1,
                                            Optional ByVal 相手存在チェック As Boolean = False
                    ) As String Implements IMyQueryMaker.SelectHANR001PrimaryKey    'X1変換Tool-20170508
        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(QueryWrapper.AddIndexHintOracle(GetIndexHint("SEL_A_1")))
        query.Append(" HANR001002 ")                                                    '取引先コード
        query.Append(",HANR001003 ")                                                    '伝票日付
        query.Append(",HANR001005 ")                                                    '
        query.Append(",HANR001006 ")                                                    '処理連番
        query.Append(",HANR001015 ")                                                    '発注№             'A-20111025_1
        query.Append(",HANR001018 ")                                                    '買掛区分
        query.Append(",HANR001019 ")                                                    '支払区分
        query.Append(",HANR001020 ")                                                    '台帳用支払区分
        query.Append(",HANR001021 ")                                                    '支払処理連番
        query.Append(",HANR001022 ")                                                    '消費税計算区分     'A-2008/07/18_Ver7.30_SHIHARAI
        query.Append(",HANR001024 ")                                                    '自動生成データ区分
        query.Append(",HANR001025 ")                                                    '伝票行数
        query.Append(",HANR001028 ")                                                    '税込仕入 仕入額
        query.Append(",HANR001029 ")                                                    '         返品額
        query.Append(",HANR001030 ")                                                    '         値引額
        query.Append(",HANR001031 ")                                                    '内消費税 仕入額
        query.Append(",HANR001032 ")                                                    '         返品額
        query.Append(",HANR001033 ")                                                    '         値引額
        query.Append(",HANR001034 ")                                                    '税抜仕入 仕入額
        query.Append(",HANR001035 ")                                                    '         返品額
        query.Append(",HANR001036 ")                                                    '         値引額
        query.Append(",HANR001037 ")                                                    '外税     仕入額
        query.Append(",HANR001038 ")                                                    '         返品額
        query.Append(",HANR001039 ")                                                    '         値引額
        query.Append(",HANR001040 ")                                                    '非課税   仕入額
        query.Append(",HANR001041 ")                                                    '         返品額
        query.Append(",HANR001042 ")                                                    '         値引額
        query.Append(",HANR001046 ")                                                    '支払 現金
        query.Append(",HANR001056 ")                                                    '通貨コード
        query.Append(",HANR001059 ")                                                    '財務連結区分
        query.Append(",HANR001060 ")                                                    '財務処理連番
        query.Append(",HANR001065 ")                                                    '仕訳対象外区分
        query.Append(",HANR001066 ")                                                    '支払締日付         'A-2008/07/18_Ver7.30_SAIMU
        query.Append(",HANR001067 ")                                                    '支払予定日         'A-2008/07/18_Ver7.30_SAIMU
        query.Append(",HANR001068 ")                                                    '入出荷処理連番
        query.Append(",HANR001069 ")                                                    '計上区分           'A-20111025_1
        query.Append(",HANR001075 ")                                                    '請求書番号
        query.Append(",HANR001076 ")                                                    '締処理グループ
        query.Append(",HANR001999 ")                                                    '更新番号
        query.Append(",HANR001A008 ")

        'A-20111124_11↓
        If MyImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 3D Then
            query.Append("," & QueryWrapper.AddIsNull() & "(HANR001S002, 0) HANR001S002 ")  '仕掛生成区分
        End If
        'A-20111124_11↑

        'A-20121217_Ver7.50_1↓
        If MyImportParam.Myコントロール情報.MyMOAオプション.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う Then
            query.Append(",HANR001087 ")                                                '入力通貨区分
            query.Append(",HANR001088 ")                                                'レート種別
            query.Append(",HANR001089 ")                                                'レート
            'A-20160324_1↓
            If _myImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 8D Then
                query.Append(",HANR001095 ")                                            '外貨管理 レート固定区分
                query.Append(",HANR001096 ")                                            '外貨管理 外貨　売上額
                query.Append(",HANR001097 ")                                            '外貨管理 外貨　返品額
                query.Append(",HANR001098 ")                                            '外貨管理 外貨　値引額
                query.Append(",HANR001099 ")                                            '外貨管理 外貨入金　現金
                query.Append(",HANR001100 ")                                            '外貨管理 外貨入金　振込
                query.Append(",HANR001101 ")                                            '外貨管理 外貨入金　相殺
                query.Append(",HANR001102 ")                                            '外貨管理 外貨入金　手形
                query.Append(",HANR001103 ")                                            '外貨管理 外貨入金　値引
                query.Append(",HANR001104 ")                                            '外貨管理 外貨入金　調整
                query.Append(",HANR001105 ")                                            '外貨管理 外貨　粗利額
            End If
            'A-20160324_1↑
            query.Append(",HANR001S003 ")                                               'レート換算基準区分
            query.Append(",HANR001S004 ")                                               '非課税売上 売上額(外貨)
            query.Append(",HANR001S005 ")                                               '           返品額(外貨)
            query.Append(",HANR001S006 ")                                               '           値引額(外貨)
            query.Append(",HANR001S007 ")                                               '入金 現金
            query.Append(",HANR001S008 ")                                               '     振込
            query.Append(",HANR001S009 ")                                               '     相殺
            query.Append(",HANR001S010 ")                                               '     手形
            query.Append(",HANR001S011 ")                                               '     値引
            query.Append(",HANR001S012 ")                                               '     調整
            query.Append(",HANR001S013 ")                                               '粗利額(外貨)
            query.Append(",HANR001S014 ")                                               'INVOICE№
            'A-20160324_1↓
            If MyImportParam.Myコントロール情報.使用条件(Myコントロール情報Param.条件型.外貨複数伝票消込機能, 8D) Then
                query.Append(",HANR001S015 ")                                           '邦貨手入力区分
            End If
            'A-20160324_1↑
        End If
        'A-20121217_Ver7.50_1↑

        query.Append(",HANR002001 ")                                                    '
        query.Append(",HANR002004 ")                                                    '
        query.Append(",HANR002005 ")                                                    '明細区分
        query.Append(",HANR002006 ")                                                    '行番号
        query.Append(",HANR002010 ")                                                    '取引区分           'A-20130402_2
        query.Append(",HANR002011 ")                                                    '
        query.Append(",HANR002018 ")                                                    '倉庫コード         'A-20130402_2
        query.Append(",HANR002019 ")                                                    '
        'query.Append(",HANR002021 ")                                                           'D-20111124_5
        query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANR002021, ' ') HANR002021 ")  'A-20111124_5
        query.Append(",HANR002025 ")                                                    '
        query.Append(",HANR002027 ")                                                    '金額               'A-2008/07/18_Ver7.30_SHIHARAI
        query.Append(",HANR002029 ")                                                    '単価計算方法
        query.Append(",HANR002048 ")                                                    '消費税率
        query.Append(",HANR002050 ")                                                    '外税額             'A-2008/07/18_Ver7.30_SHIHARAI
        query.Append(",HANR002052 ")                                                    '完納区分
        query.Append(",HANR002057 ")                                                    '取引区分属性
        query.Append(",HANR002059 ")                                                    '通貨コード
        query.Append(",HANR002999 ")                                                    '更新番号
        query.Append(",HANR002A006 ")                                                   '製番               'A-20111027_3
        query.Append(",HANR002A010 ")                                                   '
        query.Append(",HANR002A012 ")                                                   'ロケーション       'A-20130402_2
        query.Append(",HANR002A014 ")                                                   '
        'query.Append(",HANR002A015 ")                                                            'D-20111124_5
        query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANR002A015, ' ') HANR002A015 ")  'A-20111124_5
        query.Append(",HANR002A016 ")                                                   '
        query.Append(",HANR002A033 ")                                                   '

        'A-20121217_Ver7.50_1↓
        If MyImportParam.Myコントロール情報.MyMOAオプション.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う Then
            query.Append(",HANR002101 ")                                                '入力通貨区分
            query.Append(",HANR002102 ")                                                'レート種別
            query.Append(",HANR002103 ")                                                'レート
            query.Append(",HANR002104 ")                                                '外貨金額
            query.Append(",HANR002105 ")                                                '決算時評価替え区分
            query.Append(",HANR002106 ")                                                '売上(仕入)円貨金額
            query.Append(",HANR002107 ")                                                '売上(仕入)レート
            'A-20160324_1↓
            If MyImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 8D Then
                query.Append(",HANR002108 ")                                            '外貨管理 単価
                query.Append(",HANR002109 ")                                            '外貨管理 原単価
                query.Append(",HANR002110 ")                                            '外貨管理 原価金額
                query.Append(",HANR002112 ")                                            '外貨管理 粗利額
                query.Append(",HANR002113 ")                                            '外貨金額内訳 売上(仕入)金額
                query.Append(",HANR002114 ")                                            '外貨金額内訳 返品金額
                query.Append(",HANR002115 ")                                            '外貨金額内訳 値引金額
            End If
            'A-20160324_1↑
            query.Append(",HANR002S001 ")                                               '単価(外貨)
            query.Append(",HANR002S002 ")                                               '税抜売上 売上額(外貨)
            query.Append(",HANR002S003 ")                                               '         返品額(外貨)
            query.Append(",HANR002S004 ")                                               '         値引額(外貨)
            query.Append(",HANR002S005 ")                                               '原単価(外貨)
            query.Append(",HANR002S006 ")                                               '原価金額(外貨)
            query.Append(",HANR002S007 ")                                               '粗利額(外貨)
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANR002S008, ' ') HANR002S008 ")  '外国語品目名１
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANR002S009, ' ') HANR002S009 ")  '外国語品目名２
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANR002S010, ' ') HANR002S010 ")  '外国語品目名３
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANR002S011, ' ') HANR002S011 ")  '外国語単位
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANR002S012, ' ') HANR002S012 ")  '外国語個数単位
            query.Append(",HANR002S013 ")                                               '諸掛管理№
            query.Append(",HANR002S014 ")                                               '按分対象区分
            query.Append(",HANR002S015 ")                                               '按分基準
            query.Append(",HANR002S016 ")                                               '按分済区分
        End If
        'A-20121217_Ver7.50_1↑
        'A-20141105_1↓
        If MyImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 6D Then
            query.Append(",HANR002S017 ")                                               '費目コード・経費
            query.Append(",HANR002S018 ")                                               '出庫金額・経費
        End If
        'A-20141105_1↑
        'A-20160324_2↓
        If MyImportParam.Myコントロール情報.使用条件(Myコントロール情報Param.条件型.品目別原価計算機能, 8D) = True Then
            query.Append(",HANR002S020 ")                                               '原価計上手配番号
        End If
        'A-20160324_2↑

        query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SHIIRE.HANM002001, ' ') HANM002001 ")           '支払先コード
        query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SHIIRE.HANM002043, 0) HANM002043 ")             '端数処理区分 金額
        query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SHIIRE.HANM002046, 0) HANM002046 ")             '端数処理区分 消費税分解
        query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SHIHARAI.HANM002989, 0) HANM002989SHIHARAI ")   '締日付
        '↓A-2008/07/18_Ver7.30_SHIHARAI
        If MyImportParam.Myコントロール情報.Myオプション区分.支払管理 = オプション区分定義型.区分型.行う Then
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SHIHARAI.HANM002027, 0) HANM002027SHIHARAI ")   '締日１         
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SHIHARAI.HANM002090, 0) HANM002090SHIHARAI ")   '支払管理区分    
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SHIHARAI.HANM002091, 0) HANM002091SHIHARAI ")   '支払管理単位   
        End If
        '↑A-2008/07/18_Ver7.30_SHIHARAI
        query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANM035011, 0) HANM035011 ")                    '支払処理連番

        '↓A-2009/12/18_Ver7.40_LOT
        If MyImportParam.Myコントロール情報.Myオプション区分.ロット管理 = True Then
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANM045010, 0) HANM045010 ")        '完了区分
        End If
        '↑A-2009/12/18_Ver7.40_LOT

        If MyImportParam.Myコントロール情報.Myオプション区分.拡張項目_仕入伝票 = True Then
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_H.HANR030006, 0) HANR030006_H ")       '付箋色番号
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_H.HANR030007, ' ') HANR030007_H ")     '拡張項目０１
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_H.HANR030008, ' ') HANR030008_H ")     '拡張項目０２
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_H.HANR030009, ' ') HANR030009_H ")     '拡張項目０３
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_H.HANR030010, ' ') HANR030010_H ")     '拡張項目０４
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_H.HANR030011, ' ') HANR030011_H ")     '拡張項目０５
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_H.HANR030012, ' ') HANR030012_H ")     '拡張項目０６
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_H.HANR030013, ' ') HANR030013_H ")     '拡張項目０７
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_H.HANR030014, ' ') HANR030014_H ")     '拡張項目０８
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_H.HANR030015, ' ') HANR030015_H ")     '拡張項目０９
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_H.HANR030016, ' ') HANR030016_H ")     '拡張項目１０
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_H.HANR030017, ' ') HANR030017_H ")     '拡張項目１１
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_H.HANR030018, ' ') HANR030018_H ")     '拡張項目１２
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_H.HANR030019, ' ') HANR030019_H ")     '拡張項目１３
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_H.HANR030020, ' ') HANR030020_H ")     '拡張項目１４
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_H.HANR030021, ' ') HANR030021_H ")     '拡張項目１５
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_H.HANR030022, ' ') HANR030022_H ")     '拡張項目１６
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_H.HANR030023, ' ') HANR030023_H ")     '拡張項目１７
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_H.HANR030024, ' ') HANR030024_H ")     '拡張項目１８
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_H.HANR030025, ' ') HANR030025_H ")     '拡張項目１９
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_H.HANR030026, ' ') HANR030026_H ")     '拡張項目２０
        End If

        If MyImportParam.Myコントロール情報.Myオプション区分.拡張項目_仕入明細 = True Then
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_M.HANR030006, 0) HANR030006_M ")       '付箋色番号
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_M.HANR030007, ' ') HANR030007_M ")     '拡張項目０１
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_M.HANR030008, ' ') HANR030008_M ")     '拡張項目０２
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_M.HANR030009, ' ') HANR030009_M ")     '拡張項目０３
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_M.HANR030010, ' ') HANR030010_M ")     '拡張項目０４
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_M.HANR030011, ' ') HANR030011_M ")     '拡張項目０５
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_M.HANR030012, ' ') HANR030012_M ")     '拡張項目０６
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_M.HANR030013, ' ') HANR030013_M ")     '拡張項目０７
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_M.HANR030014, ' ') HANR030014_M ")     '拡張項目０８
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_M.HANR030015, ' ') HANR030015_M ")     '拡張項目０９
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_M.HANR030016, ' ') HANR030016_M ")     '拡張項目１０
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_M.HANR030017, ' ') HANR030017_M ")     '拡張項目１１
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_M.HANR030018, ' ') HANR030018_M ")     '拡張項目１２
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_M.HANR030019, ' ') HANR030019_M ")     '拡張項目１３
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_M.HANR030020, ' ') HANR030020_M ")     '拡張項目１４
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_M.HANR030021, ' ') HANR030021_M ")     '拡張項目１５
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_M.HANR030022, ' ') HANR030022_M ")     '拡張項目１６
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_M.HANR030023, ' ') HANR030023_M ")     '拡張項目１７
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_M.HANR030024, ' ') HANR030024_M ")     '拡張項目１８
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_M.HANR030025, ' ') HANR030025_M ")     '拡張項目１９
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_M.HANR030026, ' ') HANR030026_M ")     '拡張項目２０
        End If

        'D-20140402_1↓
        ''/ 入出荷ヘッダー
        'query.Append(",SEIR010001 ")                                                    '// (001)  取引先区分
        'query.Append(",SEIR010002 ")                                                    '// (002)  取引先コード
        'query.Append(",SEIR010003 ")                                                    '// (003)  入出荷日(年月日)
        'query.Append(",SEIR010004 ")                                                    '// (004)  伝票区分
        'query.Append(",SEIR010005 ")                                                    '// (005)  処理連番
        'query.Append(",SEIR010006 ")                                                    '// (006)  入出荷伝票番号
        'query.Append(",SEIR010007 ")                                                    '// (007)  売上(仕入)伝票番号
        'query.Append(",SEIR010008 ")                                                    '// (008)  操作日付(年月日)
        'query.Append("," & QueryWrapper.AddIsNull() & "(SEIR010009, ' ') SEIR010009 ")  '// (009)  ログインＩＤ
        'query.Append(",SEIR010010 ")                                                    '// (010)  チェックマーク区分
        'query.Append(",SEIR010011 ")                                                    '// (011)  担当者コード
        'query.Append(",SEIR010012 ")                                                    '// (012)  納品先コード
        'query.Append(",SEIR010013 ")                                                    '// (013)  部門コード
        'query.Append(",SEIR010014 ")                                                    '// (014)  倉庫コード
        'query.Append(",SEIR010015 ")                                                    '// (015)  オーダーコード
        'query.Append(",SEIR010016 ")                                                    '// (016)  受(発)注番号
        'query.Append(",SEIR010017 ")                                                    '// (017)  売掛区分
        'query.Append(",SEIR010018 ")                                                    '// (018)  請求(支払)区分
        'query.Append(",SEIR010019 ")                                                    '// (019)  消費税計算区分
        'query.Append(",SEIR010020 ")                                                    '// (020)  消費税率
        'query.Append(",SEIR010021 ")                                                    '// (021)  伝票行数
        'query.Append(",SEIR010022 ")                                                    '// (022)  備考コード
        'query.Append("," & QueryWrapper.AddIsNull() & "(SEIR010023, ' ') SEIR010023 ")  '// (023)  備考
        'query.Append("," & QueryWrapper.AddIsNull() & "(SEIR010024, ' ') SEIR010024 ")  '// (024)  手入力得意先名１
        'query.Append("," & QueryWrapper.AddIsNull() & "(SEIR010025, ' ') SEIR010025 ")  '// (025)  手入力得意先名２
        'query.Append("," & QueryWrapper.AddIsNull() & "(SEIR010026, ' ') SEIR010026 ")  '// (026)  手入力納品先名
        'query.Append(",SEIR010027 ")                                                    '// (027)  通貨コード
        'query.Append(",SEIR010028 ")                                                    '// (028)  データ発生区分
        'query.Append(",SEIR010029 ")                                                    '// (029)  検収残区分
        'query.Append(",SEIR010030 ")                                                    '// (030)  関連検収伝票枚数
        'query.Append(",SEIR010031 ")                                                    '// (031)  計上区分
        'query.Append(",SEIR010032 ")                                                    '// (032)  営業所コード
        'query.Append(",SEIR010033 ")                                                    '// (033)  受注区分
        'query.Append(",SEIR010034 ")                                                    '// (034)  受注形態
        'query.Append(",SEIR010035 ")                                                    '// (035)  プロジェクトメインコード
        'query.Append(",SEIR010036 ")                                                    '// (036)  プロジェクトサブコード
        'query.Append(",SEIR010037 ")                                                    '// (037)  製番
        'query.Append(",SEIR010038 ")                                                    '// (038)  製番(メイン)
        'query.Append(",SEIR010039 ")                                                    '// (039)  製番(枝番)
        'query.Append(",SEIR010040 ")                                                    '// (040)  発注区分
        'query.Append(",SEIR010041 ")                                                    '// (041)  完成品区分
        'query.Append(",SEIR010042 ")                                                    '// (042)  計上区分
        'query.Append(",SEIR010043 ")                                                    '// (043)  計算区分
        'query.Append(",SEIR010044 ")                                                    '// (044)  構成品出庫生成区分
        'query.Append(",SEIR010045 ")                                                    '// (045)  返品区分
        'query.Append(",SEIR010046 ")                                                    '// (046)  元出荷処理連番
        'query.Append(",SEIR010047 ")                                                    '// (047)  税込売上_売上額
        'query.Append(",SEIR010048 ")                                                    '// (048)  税込売上_返品額
        'query.Append(",SEIR010049 ")                                                    '// (049)  税込売上_値引額
        'query.Append(",SEIR010050 ")                                                    '// (050)  内消費税_売上額
        'query.Append(",SEIR010051 ")                                                    '// (051)  内消費税_返品額
        'query.Append(",SEIR010052 ")                                                    '// (052)  内消費税_値引額
        'query.Append(",SEIR010053 ")                                                    '// (053)  税抜売上_売上額
        'query.Append(",SEIR010054 ")                                                    '// (054)  税抜売上_返品額
        'query.Append(",SEIR010055 ")                                                    '// (055)  税抜売上_値引額
        'query.Append(",SEIR010056 ")                                                    '// (056)  外税_売上額
        'query.Append(",SEIR010057 ")                                                    '// (057)  外税_返品額
        'query.Append(",SEIR010058 ")                                                    '// (058)  外税_値引額
        'query.Append(",SEIR010059 ")                                                    '// (059)  非課税_売上額
        'query.Append(",SEIR010060 ")                                                    '// (060)  非課税_返品額
        'query.Append(",SEIR010061 ")                                                    '// (061)  非課税_値引額
        'query.Append(",SEIR010062 ")                                                    '// (062)  粗利額
        'query.Append(",SEIR010999 ")                                                    '// (999)  更新番号

        ''A-20121217_Ver7.50_1↓
        'If MyImportParam.Myコントロール情報.MyMOAオプション.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う Then
        '    query.Append(",SEIR010063 ")                                                'レート
        '    query.Append(",SEIR010064 ")                                                'レート種類
        '    query.Append(",SEIR010065 ")                                                'レート換算基準区分
        '    query.Append(",SEIR010066 ")                                                '非課税売上 売上額(外貨)
        '    query.Append(",SEIR010067 ")                                                '           返品額(外貨)
        '    query.Append(",SEIR010068 ")                                                '           値引額(外貨)
        '    query.Append(",SEIR010069 ")                                                '粗利額(外貨)
        '    query.Append(",SEIR010070 ")                                                'INVOICE№
        'End If
        ''A-20121217_Ver7.50_1↑

        ''/ 入出荷明細
        'query.Append(",SEIR011001 ")                                                    '// (001)  入出荷日（年月日）
        'query.Append(",SEIR011002 ")                                                    '// (002)  伝票区分
        'query.Append(",SEIR011003 ")                                                    '// (003)  処理連番
        'query.Append(",SEIR011004 ")                                                    '// (004)  明細区分
        'query.Append(",SEIR011005 ")                                                    '// (005)  行番号
        'query.Append(",SEIR011006 ")                                                    '// (006)  入出荷伝票番号
        'query.Append(",SEIR011007 ")                                                    '// (007)  売上(仕入)伝票番号
        'query.Append(",SEIR011008 ")                                                    '// (008)  取引先区分
        'query.Append(",SEIR011009 ")                                                    '// (009)  取引先コード
        'query.Append(",SEIR011010 ")                                                    '// (010)  担当者コード
        'query.Append(",SEIR011011 ")                                                    '// (011)  取引区分
        'query.Append(",SEIR011012 ")                                                    '// (012)  受(発)注番号
        'query.Append(",SEIR011013 ")                                                    '// (013)  受(発)注行番号
        'query.Append(",SEIR011014 ")                                                    '// (014)  部門コード
        'query.Append(",SEIR011015 ")                                                    '// (015)  倉庫コード
        'query.Append(",SEIR011016 ")                                                    '// (016)  商品(品目)コード
        'query.Append("," & QueryWrapper.AddIsNull() & "(SEIR011017, ' ') SEIR011017 ")  '// (017)  商品(品目)名
        'query.Append("," & QueryWrapper.AddIsNull() & "(SEIR011018, ' ') SEIR011018 ")  '// (018)  数量単位
        'query.Append(",SEIR011019 ")                                                    '// (019)  入数
        'query.Append(",SEIR011020 ")                                                    '// (020)  個数
        'query.Append("," & QueryWrapper.AddIsNull() & "(SEIR011021, ' ') SEIR011021 ")  '// (021)  個数単位
        'query.Append(",SEIR011022 ")                                                    '// (022)  入出荷数量
        'query.Append(",SEIR011023 ")                                                    '// (023)  入出荷単価
        'query.Append(",SEIR011024 ")                                                    '// (024)  入出荷金額
        'query.Append(",SEIR011025 ")                                                    '// (025)  原単価
        'query.Append(",SEIR011026 ")                                                    '// (026)  単価計算方法
        'query.Append(",SEIR011027 ")                                                    '// (027)  単価掛率
        'query.Append(",SEIR011028 ")                                                    '// (028)  標準売上単価
        'query.Append(",SEIR011029 ")                                                    '// (029)  標準仕入単価
        'query.Append(",SEIR011030 ")                                                    '// (030)  上代単価
        'query.Append(",SEIR011031 ")                                                    '// (031)  粗利額
        'query.Append(",SEIR011032 ")                                                    '// (032)  入出荷金額
        'query.Append(",SEIR011033 ")                                                    '// (033)  値引金額
        'query.Append(",SEIR011034 ")                                                    '// (034)  課税区分
        'query.Append(",SEIR011035 ")                                                    '// (035)  消費税率
        'query.Append(",SEIR011036 ")                                                    '// (036)  内消費税額
        'query.Append(",SEIR011037 ")                                                    '// (037)  強制検収完納区分
        'query.Append(",SEIR011038 ")                                                    '// (038)  行摘要コード
        'query.Append("," & QueryWrapper.AddIsNull() & "(SEIR011039, ' ') SEIR011039 ")  '// (039)  行摘要１
        'query.Append("," & QueryWrapper.AddIsNull() & "(SEIR011040, ' ') SEIR011040 ")  '// (040)  行摘要２
        'query.Append(",SEIR011041 ")                                                    '// (041)  検収済数量
        'query.Append(",SEIR011042 ")                                                    '// (042)  検収済金額
        'query.Append(",SEIR011043 ")                                                    '// (043)  検収済金額内消費税
        'query.Append(",SEIR011044 ")                                                    '// (044)  検収済金額内訳売上
        'query.Append(",SEIR011045 ")                                                    '// (045)  検収済金額内訳値引
        'query.Append(",SEIR011046 ")                                                    '// (046)  検収回数
        'query.Append(",SEIR011047 ")                                                    '// (047)  最終検収日
        'query.Append(",SEIR011048 ")                                                    '// (048)  関連売上/仕入伝票行数
        'query.Append(",SEIR011049 ")                                                    '// (049)  検収残区分
        'query.Append(",SEIR011050 ")                                                    '// (050)  通貨コード
        'query.Append(",SEIR011051 ")                                                    '// (051)  取引区分属性
        'query.Append(",SEIR011052 ")                                                    '// (052)  入出庫区分
        'query.Append(",SEIR011053 ")                                                    '// (053)  データ発生区分
        'query.Append(",SEIR011054 ")                                                    '// (054)  上代課税区分
        'query.Append(",SEIR011055 ")                                                    '// (055)  計上区分
        'query.Append(",SEIR011056 ")                                                    '// (056)  売掛区分
        'query.Append(",SEIR011057 ")                                                    '// (057)  原価金額
        'query.Append(",SEIR011058 ")                                                    '// (058)  営業所コード
        'query.Append(",SEIR011059 ")                                                    '// (059)  拡張項目入力パターン№
        'query.Append("," & QueryWrapper.AddIsNull() & "(SEIR011060, ' ') SEIR011060 ")  '// (060)  品目名１
        'query.Append("," & QueryWrapper.AddIsNull() & "(SEIR011061, ' ') SEIR011061 ")  '// (061)  品目名２
        'query.Append("," & QueryWrapper.AddIsNull() & "(SEIR011062, ' ') SEIR011062 ")  '// (062)  品目名３
        'query.Append(",SEIR011063 ")                                                    '// (063)  製　番
        'query.Append(",SEIR011064 ")                                                    '// (064)  製番（メイン）
        'query.Append(",SEIR011065 ")                                                    '// (065)  製番（枝番）
        'query.Append(",SEIR011066 ")                                                    '// (066)  客先注番
        'query.Append(",SEIR011067 ")                                                    '// (067)  検査方法
        'query.Append(",SEIR011068 ")                                                    '// (068)  発注区分
        'query.Append(",SEIR011069 ")                                                    '// (069)  子部品引当区分
        'query.Append(",SEIR011070 ")                                                    '// (070)  工程コード
        'query.Append(",SEIR011071 ")                                                    '// (071)  入出荷数量(発注単位)
        'query.Append("," & QueryWrapper.AddIsNull() & "(SEIR011072, ' ') SEIR011072 ")  '// (072)  入出荷単位(発注単位)
        'query.Append(",SEIR011073 ")                                                    '// (073)  発注単位変換係数
        'query.Append(",SEIR011074 ")                                                    '// (074)  発注確定区分
        'query.Append(",SEIR011075 ")                                                    '// (075)  手配番号
        'query.Append(",SEIR011076 ")                                                    '// (076)  手配管理番号
        'query.Append(",SEIR011077 ")                                                    '// (077)  仮単価区分
        'query.Append(",SEIR011078 ")                                                    '// (078)  受注形態
        'query.Append(",SEIR011079 ")                                                    '// (079)  個別発注連番
        'query.Append(",SEIR011080 ")                                                    '// (080)  検収済数量(発注単位)
        'query.Append(",SEIR011081 ")                                                    '// (081)  費目コード
        'query.Append(",SEIR011082 ")                                                    '// (082)  費目区分
        'query.Append(",SEIR011083 ")                                                    '// (083)  ロケーション
        'query.Append(",SEIR011084 ")                                                    '// (084)  ロット№
        'query.Append(",SEIR011085 ")                                                    '// (085)  不良数量(在庫単位)
        'query.Append(",SEIR011086 ")                                                    '// (086)  不良数量(発注単位)
        'query.Append(",SEIR011087 ")                                                    '// (087)  ロット管理区分
        'query.Append(",SEIR011088 ")                                                    '// (088)  有効期限
        'query.Append(",SEIR011089 ")                                                    '// (089)  最新検収単価
        'query.Append(",SEIR011090 ")                                                    '// (090)  相手売上(仕入)処理連番
        'query.Append(",SEIR011091 ")                                                    '// (091)  相手売上(仕入)行番号
        'query.Append(",SEIR011092 ")                                                    '// (092)  相手入出庫処理連番
        'query.Append(",SEIR011093 ")                                                    '// (093)  相手入出庫行番号
        'query.Append(",SEIR011094 ")                                                    '// (094)  外税額(明細消費税用)
        'query.Append(",SEIR011095 ")                                                    '// (095)  検収残金額
        'query.Append(",SEIR011096 ")                                                    '// (096)  元入出荷処理連番
        'query.Append(",SEIR011097 ")                                                    '// (097)  元入出荷行番号
        'query.Append(",SEIR011098 ")                                                    '// (098)  受発注強制完納区分
        'query.Append(",SEIR011099 ")                                                    '// (099)  消費税計算区分
        'query.Append(",SEIR011999 ")                                                    '// (999)  更新番号

        ''A-20121217_Ver7.50_1↓
        'If MyImportParam.Myコントロール情報.MyMOAオプション.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う Then
        '    query.Append(",SEIR011100 ")                                                '単価(外貨)
        '    query.Append(",SEIR011101 ")                                                '金額(外貨)
        '    query.Append(",SEIR011102 ")                                                '税抜売上 売上額(外貨)
        '    query.Append(",SEIR011103 ")                                                '         値引額(外貨)
        '    query.Append(",SEIR011104 ")                                                '検収済金額(外貨)
        '    query.Append(",SEIR011105 ")                                                '検収済金額内訳売上(外貨)
        '    query.Append(",SEIR011106 ")                                                '検収済金額内訳値引(外貨)
        '    query.Append(",SEIR011107 ")                                                '最新検収単価(外貨)
        '    query.Append(",SEIR011108 ")                                                '検収残金額
        '    query.Append(",SEIR011109 ")                                                '原単価(外貨)
        '    query.Append(",SEIR011110 ")                                                '原価金額(外貨)
        '    query.Append(",SEIR011111 ")                                                '粗利額(外貨)
        '    query.Append(",SEIR011112 ")                                                '諸掛管理№
        '    query.Append(",SEIR011113 ")                                                '按分対象区分
        '    query.Append(",SEIR011114 ")                                                '按分基準
        '    query.Append(",SEIR011115 ")                                                '按分済区分
        '    query.Append(",SEIR011116 ")                                                '外国語品目名１
        '    query.Append(",SEIR011117 ")                                                '外国語品目名２
        '    query.Append(",SEIR011118 ")                                                '外国語品目名３
        '    query.Append(",SEIR011119 ")                                                '外国語単位
        '    query.Append(",SEIR011120 ")                                                '外国語個数単位
        'End If
        ''A-20121217_Ver7.50_1↑
        'D-20140402_1↑

        query.Append("FROM " & MyBase.ExchangeTableName("HAN10R001TORIHIKIH"))    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock(GetIndexHint("R001_A_1")))

        query.Append("INNER JOIN " & MyBase.ExchangeTableName("HAN10R002TORIHIKIM") & " ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock(GetIndexHint("R002_A_1")))
        query.Append("   ON HANR002002 = HANR001004 ")
        query.Append("  AND HANR002004 = HANR001006 ")

        'D-20140402_1↓
        'query.Append("LEFT OUTER JOIN " & MyBase.ExchangeTableName("SEI10R010NYUSHUKKAH"))    'X1変換Tool-20170509
        'query.Append(MyBase.QueryWrapper.AddNoLock(GetIndexHint("R010_A_1")))
        'query.Append("   ON SEIR010004 = 2 ")
        'query.Append("  AND SEIR010005 = HANR001A004 ")
        'query.Append("  AND SEIR010005 = HANR001A005 ")

        'query.Append("LEFT OUTER JOIN " & MyBase.ExchangeTableName("SEI10R011NYUSHUKKAM") & " ")    'X1変換Tool-20170509
        'query.Append(MyBase.QueryWrapper.AddNoLock(GetIndexHint("R011_A_1")))
        'query.Append("   ON SEIR011002 = SEIR010004 ")
        'query.Append("  AND SEIR011003 = SEIR010005 ")
        'query.Append("  AND SEIR011004 = HANR002005 ")
        'query.Append("  AND SEIR011091 = HANR002006 ")
        'D-20140402_1↑

        query.Append("LEFT OUTER JOIN " & MyBase.ExchangeTableName("HAN10M002SHIIRE") & " SHIIRE ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())
        query.Append("   ON SHIIRE.HANM002003 = HANR001002 ")

        query.Append("LEFT OUTER JOIN " & MyBase.ExchangeTableName("HAN10M002SHIIRE") & " SHIHARAI ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())
        query.Append("   ON SHIHARAI.HANM002003 = SHIIRE.HANM002001 ")

        query.Append("LEFT OUTER JOIN " & MyBase.ExchangeTableName("HAN10M035SHIMEG") & " ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())
        query.Append("   ON HANM035001 = 1 ")
        query.Append("  AND HANM035002 = SHIHARAI.HANM002991 ")

        '↓A-2009/12/18_Ver7.40_LOT
        If MyImportParam.Myコントロール情報.Myオプション区分.ロット管理 = True Then
            query.Append("LEFT OUTER JOIN " & MyBase.ExchangeTableName("HAN10M045LOT") & " ")    'X1変換Tool-20170509
            query.Append(MyBase.QueryWrapper.AddNoLock())
            query.Append("   ON HANM045001 = HANR002019 ")
            query.Append("  AND HANM045002 = HANR002066 ")
            query.Append("  AND HANM045003 = HANR002067 ")
            query.Append("  AND HANM045004 = HANR002068 ")
            query.Append("  AND HANM045005 = HANR002086 ")
        End If
        '↑A-2009/12/18_Ver7.40_LOT

        If MyImportParam.Myコントロール情報.Myオプション区分.拡張項目_仕入伝票 = True Then
            query.Append("LEFT OUTER JOIN " & MyBase.ExchangeTableName("HAN10R030KAKUCHO") & " R030_H ")    'X1変換Tool-20170509
            query.Append(MyBase.QueryWrapper.AddNoLock())
            query.Append("   ON R030_H.HANR030001 = 1 ")
            query.Append("  AND R030_H.HANR030002 = HANR001004 ")
            query.Append("  AND R030_H.HANR030003 = 0 ")
            query.Append("  AND R030_H.HANR030004 = HANR001006 ")
            query.Append("  AND R030_H.HANR030005 = 0 ")
        End If

        If MyImportParam.Myコントロール情報.Myオプション区分.拡張項目_仕入明細 = True Then
            query.Append("LEFT OUTER JOIN " & MyBase.ExchangeTableName("HAN10R030KAKUCHO") & " R030_M ")    'X1変換Tool-20170509
            query.Append(MyBase.QueryWrapper.AddNoLock())
            query.Append("   ON R030_M.HANR030001 = 1 ")
            query.Append("  AND R030_M.HANR030002 = HANR002002 ")
            query.Append("  AND R030_M.HANR030003 = HANR002005 ")
            query.Append("  AND R030_M.HANR030004 = HANR002004 ")
            query.Append("  AND R030_M.HANR030005 = HANR002006 ")
        End If

        query.Append("WHERE HANR001004 = 1")
        query.Append("  AND HANR001006 = " & AddParamInfo(paramInfo, "HANR001006", DbType.Decimal, 0, 10, 0, 処理連番) & " ")
        If 明細区分 <> -1 Then
            query.Append("  AND HANR002005 = " & AddParamInfo(paramInfo, "HANR002005", DbType.Decimal, 0, 1, 0, 明細区分) & " ")
        End If
        If 行番号 <> -1 Then
            query.Append("  AND HANR002006 = " & AddParamInfo(paramInfo, "HANR002006", DbType.Decimal, 0, 3, 0, 行番号) & " ")
        End If
        If 相手存在チェック = True Then
            query.Append("  AND HANR001068 = 0 ")
        End If

        query.Append("ORDER BY HANR001004,HANR001006,HANR002005,HANR002006")
        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString
    End Function

    Public Function SelectHANR001PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal 取引区分 As Integer,
                                            ByVal 処理連番 As Long
                    ) As String Implements IMyQueryMaker.SelectHANR001PrimaryKey    'X1変換Tool-20170508
        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(" HANR001006 ")                                                    '処理連番

        query.Append("FROM " & MyBase.ExchangeTableName("HAN10R001TORIHIKIH"))    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())

        If 取引区分 <> -1 Then
            query.Append("WHERE HANR001004 = " & AddParamInfo(paramInfo, "HANR001004", DbType.Decimal, 0, 1, 0, 取引区分) & " ")
            query.Append("  AND HANR001006 = " & AddParamInfo(paramInfo, "HANR001006", DbType.Decimal, 0, 10, 0, 処理連番) & " ")
        Else
            '連番使用済チェック
            query.Append("WHERE HANR001006 = " & AddParamInfo(paramInfo, "HANR001006", DbType.Decimal, 0, 10, 0, 処理連番) & " ")
        End If

        query.Append("ORDER BY HANR001004,HANR001006")
        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString
    End Function

    Public Function SelectHANR001出庫伝票存在(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                              ByVal 処理連番 As Long,
                                              ByVal 取引区分 As Integer
                ) As String Implements IMyQueryMaker.SelectHANR001出庫伝票存在    'X1変換Tool-20170508
        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(QueryWrapper.AddIndexHintOracle(GetIndexHint("SEL_N_1")))
        query.Append(" HANR001006 ")                                                    '処理連番
        query.Append(",HANR002001 ")                                                    '伝票日付   'A-20120125_2
        query.Append(",HANR002006 ")                                                    '行番号             'A-20121217_Ver7.50_3
        query.Append(",HANR002A029 ")                                                   '展開順序行番号     'A-20121217_Ver7.50_3

        query.Append("FROM " & MyBase.ExchangeTableName("HAN10R001TORIHIKIH"))    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock(GetIndexHint("R001_N_1")))

        query.Append("INNER JOIN " & MyBase.ExchangeTableName("HAN10R002TORIHIKIM") & " ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock(GetIndexHint("R002_N_1")))
        query.Append("   ON HANR002002 = HANR001004 ")
        query.Append("  AND HANR002004 = HANR001006 ")

        query.Append(" WHERE ")
        ' 伝票区分
        query.Append("HANR001004 = 5")
        query.Append(" AND ")

        If 取引区分 <> -1 Then
            query.Append("HANR001010 = " & AddParamInfo(paramInfo, "HANR001010", DbType.Decimal, 0, 2, 0, 取引区分) & " ")
            query.Append(" AND ")
        End If

        '入出庫区分
        query.Append("HANR001074 = 2 ")
        query.Append(" AND ")

        ' 発生区分
        query.Append("HANR001A004 = 1")
        query.Append(" AND ")

        ' 発生元相手連番
        query.Append("HANR001A005 = " & AddParamInfo(paramInfo, "HANR001A005", DbType.Decimal, 0, 10, 0, 処理連番) & " ")

        query.Append("ORDER BY HANR001004,HANR001006,HANR002005,HANR002006")
        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString
    End Function

    Public Function SelectHANR001入庫伝票取得(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                              ByVal 処理連番 As Long
                ) As String Implements IMyQueryMaker.SelectHANR001入庫伝票取得    'X1変換Tool-20170508
        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(QueryWrapper.AddIndexHintOracle(GetIndexHint("SEL_M_1")))
        query.Append(" HANR001002 ")                                                    '取引先コード
        query.Append(",HANR001003 ")                                                    '伝票日付
        query.Append(",HANR001004 ")                                                    '明細区分
        query.Append(",HANR001005 ")                                                    '伝票番号
        query.Append(",HANR001006 ")                                                    '処理連番
        query.Append(",HANR001015 ")                                                    '発注№             'A-20111025_1
        query.Append(",HANR001018 ")                                                    '買掛区分
        query.Append(",HANR001019 ")                                                    '支払区分
        query.Append(",HANR001020 ")                                                    '台帳用支払区分
        query.Append(",HANR001021 ")                                                    '支払処理連番
        query.Append(",HANR001022 ")                                                    '消費税計算区分     'A-2008/07/18_Ver7.30_SHIHARAI
        query.Append(",HANR001024 ")                                                    '自動生成データ区分
        query.Append(",HANR001025 ")                                                    '
        query.Append(",HANR001028 ")                                                    '税込仕入 仕入額
        query.Append(",HANR001029 ")                                                    '         返品額
        query.Append(",HANR001030 ")                                                    '         値引額
        query.Append(",HANR001031 ")                                                    '内消費税 仕入額
        query.Append(",HANR001032 ")                                                    '         返品額
        query.Append(",HANR001033 ")                                                    '         値引額
        query.Append(",HANR001034 ")                                                    '税抜仕入 仕入額
        query.Append(",HANR001035 ")                                                    '         返品額
        query.Append(",HANR001036 ")                                                    '         値引額
        query.Append(",HANR001037 ")                                                    '外税     仕入額
        query.Append(",HANR001038 ")                                                    '         返品額
        query.Append(",HANR001039 ")                                                    '         値引額
        query.Append(",HANR001040 ")                                                    '非課税   仕入額
        query.Append(",HANR001041 ")                                                    '         返品額
        query.Append(",HANR001042 ")                                                    '         値引額
        query.Append(",HANR001046 ")                                                    '支払 現金
        query.Append(",HANR001056 ")                                                    '通貨コード
        query.Append(",HANR001059 ")                                                    '財務連結区分
        query.Append(",HANR001060 ")                                                    '財務処理連番
        query.Append(",HANR001065 ")                                                    '仕訳対象外区分
        query.Append(",HANR001066 ")                                                    '支払締日付         'A-2008/07/18_Ver7.30_SAIMU
        query.Append(",HANR001067 ")                                                    '支払予定日         'A-2008/07/18_Ver7.30_SAIMU
        query.Append(",HANR001068 ")                                                    '入出荷処理連番
        query.Append(",HANR001069 ")                                                    '計上区分           'A-20111025_1
        query.Append(",HANR001075 ")                                                    '請求書番号
        query.Append(",HANR001076 ")                                                    '締処理グループ
        query.Append(",HANR001999 ")                                                    '更新番号
        query.Append(",HANR001A008 ")

        'A-20111124_11↓
        If MyImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 3D Then
            query.Append("," & QueryWrapper.AddIsNull() & "(HANR001S002, 0) HANR001S002 ")  '仕掛生成区分
        End If
        'A-20111124_11↑

        'A-20121217_Ver7.50_1↓
        If MyImportParam.Myコントロール情報.MyMOAオプション.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う Then
            query.Append(",HANR001087 ")                                                '入力通貨区分
            query.Append(",HANR001088 ")                                                'レート種別
            query.Append(",HANR001089 ")                                                'レート
            'A-20160324_1↓
            If _myImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 8D Then
                query.Append(",HANR001095 ")                                            '外貨管理 レート固定区分
                query.Append(",HANR001096 ")                                            '外貨管理 外貨　売上額
                query.Append(",HANR001097 ")                                            '外貨管理 外貨　返品額
                query.Append(",HANR001098 ")                                            '外貨管理 外貨　値引額
                query.Append(",HANR001099 ")                                            '外貨管理 外貨入金　現金
                query.Append(",HANR001100 ")                                            '外貨管理 外貨入金　振込
                query.Append(",HANR001101 ")                                            '外貨管理 外貨入金　相殺
                query.Append(",HANR001102 ")                                            '外貨管理 外貨入金　手形
                query.Append(",HANR001103 ")                                            '外貨管理 外貨入金　値引
                query.Append(",HANR001104 ")                                            '外貨管理 外貨入金　調整
                query.Append(",HANR001105 ")                                            '外貨管理 外貨　粗利額
            End If
            'A-20160324_1↑
            query.Append(",HANR001S003 ")                                               'レート換算基準区分
            query.Append(",HANR001S004 ")                                               '非課税売上 売上額(外貨)
            query.Append(",HANR001S005 ")                                               '           返品額(外貨)
            query.Append(",HANR001S006 ")                                               '           値引額(外貨)
            query.Append(",HANR001S007 ")                                               '入金 現金
            query.Append(",HANR001S008 ")                                               '     振込
            query.Append(",HANR001S009 ")                                               '     相殺
            query.Append(",HANR001S010 ")                                               '     手形
            query.Append(",HANR001S011 ")                                               '     値引
            query.Append(",HANR001S012 ")                                               '     調整
            query.Append(",HANR001S013 ")                                               '粗利額(外貨)
            query.Append(",HANR001S014 ")                                               'INVOICE№
            'A-20160324_1↓
            If MyImportParam.Myコントロール情報.使用条件(Myコントロール情報Param.条件型.外貨複数伝票消込機能, 8D) Then
                query.Append(",HANR001S015 ")                                           '邦貨手入力区分
            End If
            'A-20160324_1↑
        End If
        'A-20121217_Ver7.50_1↑

        query.Append(",HANR002001 ")                                                    '
        query.Append(",HANR002004 ")                                                    '
        query.Append(",HANR002005 ")                                                    '明細区分
        query.Append(",HANR002006 ")                                                    '行番号
        query.Append(",HANR002010 ")                                                    '取引区分           'A-20130402_2
        query.Append(",HANR002011 ")                                                    '
        query.Append(",HANR002018 ")                                                    '倉庫コード         'A-20130402_2
        query.Append(",HANR002019 ")                                                    '
        query.Append(",HANR002021 ")                                                    '
        query.Append(",HANR002025 ")                                                    '
        query.Append(",HANR002027 ")                                                    '金額               'A-2008/07/18_Ver7.30_SHIHARAI
        query.Append(",HANR002029 ")                                                    '単価計算方法
        query.Append(",HANR002048 ")                                                    '消費税率
        query.Append(",HANR002050 ")                                                    '外税額             'A-2008/07/18_Ver7.30_SHIHARAI
        query.Append(",HANR002052 ")                                                    '完納区分
        query.Append(",HANR002057 ")                                                    '取引区分属性
        query.Append(",HANR002059 ")                                                    '通貨コード
        query.Append(",HANR002999 ")                                                    '更新番号
        query.Append(",HANR002A006 ")                                                   '製番               'A-20111027_3
        query.Append(",HANR002A010 ")                                                   '
        query.Append(",HANR002A012 ")                                                   'ロケーション       'A-20130402_2
        query.Append(",HANR002A014 ")                                                   '
        query.Append(",HANR002A015 ")                                                   '
        query.Append(",HANR002A016 ")                                                   '
        query.Append(",HANR002A033 ")                                                   '

        'A-20121217_Ver7.50_1↓
        If MyImportParam.Myコントロール情報.MyMOAオプション.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う Then
            query.Append(",HANR002101 ")                                                '入力通貨区分
            query.Append(",HANR002102 ")                                                'レート種別
            query.Append(",HANR002103 ")                                                'レート
            query.Append(",HANR002104 ")                                                '外貨金額
            query.Append(",HANR002105 ")                                                '決算時評価替え区分
            query.Append(",HANR002106 ")                                                '売上(仕入)円貨金額
            query.Append(",HANR002107 ")                                                '売上(仕入)レート
            'A-20160324_1↓
            If MyImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 8D Then
                query.Append(",HANR002108 ")                                            '外貨管理 単価
                query.Append(",HANR002109 ")                                            '外貨管理 原単価
                query.Append(",HANR002110 ")                                            '外貨管理 原価金額
                query.Append(",HANR002112 ")                                            '外貨管理 粗利額
                query.Append(",HANR002113 ")                                            '外貨金額内訳 売上(仕入)金額
                query.Append(",HANR002114 ")                                            '外貨金額内訳 返品金額
                query.Append(",HANR002115 ")                                            '外貨金額内訳 値引金額
            End If
            'A-20160324_1↑
            query.Append(",HANR002S001 ")                                               '単価(外貨)
            query.Append(",HANR002S002 ")                                               '税抜売上 売上額(外貨)
            query.Append(",HANR002S003 ")                                               '         返品額(外貨)
            query.Append(",HANR002S004 ")                                               '         値引額(外貨)
            query.Append(",HANR002S005 ")                                               '原単価(外貨)
            query.Append(",HANR002S006 ")                                               '原価金額(外貨)
            query.Append(",HANR002S007 ")                                               '粗利額(外貨)
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANR002S008, ' ') HANR002S008 ")  '外国語品目名１
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANR002S009, ' ') HANR002S009 ")  '外国語品目名２
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANR002S010, ' ') HANR002S010 ")  '外国語品目名３
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANR002S011, ' ') HANR002S011 ")  '外国語単位
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANR002S012, ' ') HANR002S012 ")  '外国語個数単位
            query.Append(",HANR002S013 ")                                               '諸掛管理№
            query.Append(",HANR002S014 ")                                               '按分対象区分
            query.Append(",HANR002S015 ")                                               '按分基準
            query.Append(",HANR002S016 ")                                               '按分済区分
        End If
        'A-20121217_Ver7.50_1↑

        'A-20141105_1↓
        If MyImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 6D Then
            query.Append(",HANR002S017 ")                                               '費目コード・経費
            query.Append(",HANR002S018 ")                                               '出庫金額・経費
        End If
        'A-20141105_1↑
        'A-20160324_2↓
        If MyImportParam.Myコントロール情報.使用条件(Myコントロール情報Param.条件型.品目別原価計算機能, 8D) = True Then
            query.Append(",HANR002S020 ")                                               '原価計上手配番号
        End If
        'A-20160324_2↑

        query.Append("FROM " & MyBase.ExchangeTableName("HAN10R001TORIHIKIH"))    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock(GetIndexHint("R001_M_1")))

        query.Append("INNER JOIN " & MyBase.ExchangeTableName("HAN10R002TORIHIKIM") & " ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock(GetIndexHint("R002_M_1")))
        query.Append("   ON HANR002002 = HANR001004 ")
        query.Append("  AND HANR002004 = HANR001006 ")

        query.Append(" WHERE ")
        ' 伝票区分
        query.Append("(HANR001004 = 5 OR HANR001004 = 9) ")
        query.Append(" AND ")

        ' 処理連番
        query.Append("HANR001006 = " & AddParamInfo(paramInfo, "HANR001006", DbType.Decimal, 0, 10, 0, 処理連番) & " ")
        query.Append(" AND ")

        '入出庫区分
        query.Append("HANR001074 = 1 ")

        query.Append("ORDER BY HANR001004,HANR001006,HANR002005,HANR002006")
        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString
    End Function

    Public Function InsertHANR001(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                  ByVal 更新データ As WorkTableUnitData) As String Implements IMyQueryMaker.InsertHANR001    'X1変換Tool-20170508
        Dim query As New System.Text.StringBuilder

        query.Append(" INSERT INTO ")
        query.Append(Me.ExchangeTableName("HAN10R001TORIHIKIH"))    'X1変換Tool-20170509

        query.Append(" (")
        query.Append(" HANR001001")
        query.Append(",HANR001002")
        query.Append(",HANR001003")
        query.Append(",HANR001004")
        query.Append(",HANR001005")
        query.Append(",HANR001006")
        query.Append(",HANR001007")
        query.Append(",HANR001008")
        query.Append(",HANR001009")
        query.Append(",HANR001010")
        query.Append(",HANR001011")
        query.Append(",HANR001012")
        query.Append(",HANR001013")
        query.Append(",HANR001014")
        query.Append(",HANR001015")
        query.Append(",HANR001016")
        query.Append(",HANR001017")
        query.Append(",HANR001018")
        query.Append(",HANR001019")
        query.Append(",HANR001020")
        query.Append(",HANR001021")
        query.Append(",HANR001022")
        query.Append(",HANR001023")
        query.Append(",HANR001024")
        query.Append(",HANR001025")
        query.Append(",HANR001026")
        query.Append(",HANR001027")
        query.Append(",HANR001028")
        query.Append(",HANR001029")
        query.Append(",HANR001030")
        query.Append(",HANR001031")
        query.Append(",HANR001032")
        query.Append(",HANR001033")
        query.Append(",HANR001034")
        query.Append(",HANR001035")
        query.Append(",HANR001036")
        query.Append(",HANR001037")
        query.Append(",HANR001038")
        query.Append(",HANR001039")
        query.Append(",HANR001040")
        query.Append(",HANR001041")
        query.Append(",HANR001042")
        query.Append(",HANR001043")
        query.Append(",HANR001044")
        query.Append(",HANR001045")
        query.Append(",HANR001046")
        query.Append(",HANR001047")
        query.Append(",HANR001048")
        query.Append(",HANR001049")
        query.Append(",HANR001050")
        query.Append(",HANR001051")
        query.Append(",HANR001052")
        query.Append(",HANR001053")
        query.Append(",HANR001054")
        query.Append(",HANR001055")
        query.Append(",HANR001056")
        query.Append(",HANR001057")
        query.Append(",HANR001058")
        query.Append(",HANR001059")
        query.Append(",HANR001060")
        query.Append(",HANR001061")
        query.Append(",HANR001062")
        query.Append(",HANR001063")
        query.Append(",HANR001064")
        query.Append(",HANR001065")
        query.Append(",HANR001066")
        query.Append(",HANR001067")
        query.Append(",HANR001068")
        query.Append(",HANR001069")
        query.Append(",HANR001070")
        query.Append(",HANR001071")
        query.Append(",HANR001072")
        query.Append(",HANR001073")
        query.Append(",HANR001074")
        query.Append(",HANR001075")
        query.Append(",HANR001076")
        query.Append(",HANR001999")

        query.Append(",HANR001A001")
        query.Append(",HANR001A002")
        query.Append(",HANR001A003")
        query.Append(",HANR001A004")
        query.Append(",HANR001A005")
        query.Append(",HANR001A006")
        query.Append(",HANR001A007")
        query.Append(",HANR001A008")
        query.Append(",HANR001A009")
        query.Append(",HANR001A010")
        query.Append(",HANR001A011")
        query.Append(",HANR001A012")
        query.Append(",HANR001A013")
        query.Append(",HANR001A014")
        query.Append(",HANR001A015")
        query.Append(",HANR001A016")

        'A-20111124_11↓
        If MyImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 3D AndAlso
           MyImportParam.Myコントロール情報.MyMOA機能追加.仕掛管理区分 = MOA機能追加定義型.その他管理区分型.行う Then
            query.Append(",HANR001S002")
        End If
        'A-20111124_11↑

        'A-20121217_Ver7.50_1↓
        If MyImportParam.Myコントロール情報.MyMOAオプション.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う Then
            query.Append(",HANR001087 ")
            query.Append(",HANR001088 ")
            query.Append(",HANR001089 ")
            'A-20160324_1↓
            If _myImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 8D Then
                query.Append(",HANR001095 ")
                query.Append(",HANR001096 ")
                query.Append(",HANR001097 ")
                query.Append(",HANR001098 ")
                query.Append(",HANR001099 ")
                query.Append(",HANR001100 ")
                query.Append(",HANR001101 ")
                query.Append(",HANR001102 ")
                query.Append(",HANR001103 ")
                query.Append(",HANR001104 ")
                query.Append(",HANR001105 ")
            End If
            'A-20160324_1↑
            query.Append(",HANR001S003 ")
            query.Append(",HANR001S004 ")
            query.Append(",HANR001S005 ")
            query.Append(",HANR001S006 ")
            query.Append(",HANR001S007 ")
            query.Append(",HANR001S008 ")
            query.Append(",HANR001S009 ")
            query.Append(",HANR001S010 ")
            query.Append(",HANR001S011 ")
            query.Append(",HANR001S012 ")
            query.Append(",HANR001S013 ")
            query.Append(",HANR001S014 ")
            'A-20160324_1↓
            If _myImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 8D Then
                query.Append(",HANR001S015 ")
            End If
            'A-20160324_1↑
        End If
        'A-20121217_Ver7.50_1↑

        ''↓A-2008/07/18_Ver7.30_GENKA
        'If MyImportParam.Myコントロール情報.Myオプション区分.原価管理 = オプション区分定義型.区分型.行う Then
        '    query.Append(",HANR001077")
        '    query.Append(",HANR001078")
        'End If
        ''↑A-2008/07/18_Ver7.30_GENKA
        ''↓A-2009/08/21_RIREKI
        'If MyImportParam.Myコントロール情報.My変更履歴.変更履歴使用区分 = True Then
        '    query.Append(",HANR001911")
        '    query.Append(",HANR001914")
        '    query.Append(",HANR001915")
        '    query.Append(",HANR001916")
        '    query.Append(",HANR001917")
        '    query.Append(",HANR001918")
        '    query.Append(",HANR001919")
        'End If
        ''↑A-2009/08/21_RIREKI
        query.Append(" )")

        query.Append(" VALUES (")
        query.Append(" " & AddParamInfo(paramInfo, "HANR001001", DbType.Decimal, 0, 1, 0, 更新データ.取引ヘッダー.R001001))
        query.Append("," & AddParamInfo(paramInfo, "HANR001002", DbType.AnsiStringFixedLength, 11, 0, 0, 更新データ.取引ヘッダー.R001002))
        query.Append("," & AddParamInfo(paramInfo, "HANR001003", DbType.Decimal, 0, 8, 0, 更新データ.取引ヘッダー.R001003))
        query.Append("," & AddParamInfo(paramInfo, "HANR001004", DbType.Decimal, 0, 1, 0, 更新データ.取引ヘッダー.R001004))
        query.Append("," & AddParamInfo(paramInfo, "HANR001005", DbType.Decimal, 0, 8, 0, 更新データ.取引ヘッダー.R001005))
        query.Append("," & AddParamInfo(paramInfo, "HANR001006", DbType.Decimal, 0, 10, 0, 更新データ.取引ヘッダー.R001006))
        query.Append("," & AddParamInfo(paramInfo, "HANR001007", DbType.Decimal, 0, 8, 0, 更新データ.取引ヘッダー.R001007))
        query.Append("," & AddParamInfo(paramInfo, "HANR001008", DbType.String, 64, 0, 0, 更新データ.取引ヘッダー.R001008))
        query.Append("," & AddParamInfo(paramInfo, "HANR001009", DbType.Decimal, 0, 1, 0, 更新データ.取引ヘッダー.R001009))
        query.Append("," & AddParamInfo(paramInfo, "HANR001010", DbType.Decimal, 0, 2, 0, 更新データ.取引ヘッダー.R001010))
        query.Append("," & AddParamInfo(paramInfo, "HANR001011", DbType.AnsiStringFixedLength, 8, 0, 0, 更新データ.取引ヘッダー.R001011))
        query.Append("," & AddParamInfo(paramInfo, "HANR001012", DbType.AnsiStringFixedLength, 6, 0, 0, 更新データ.取引ヘッダー.R001012))
        query.Append("," & AddParamInfo(paramInfo, "HANR001013", DbType.AnsiStringFixedLength, 11, 0, 0, 更新データ.取引ヘッダー.R001013))
        query.Append("," & AddParamInfo(paramInfo, "HANR001014", DbType.AnsiStringFixedLength, 8, 0, 0, 更新データ.取引ヘッダー.R001014))
        query.Append("," & AddParamInfo(paramInfo, "HANR001015", DbType.Decimal, 0, 10, 0, 更新データ.取引ヘッダー.R001015))
        query.Append("," & AddParamInfo(paramInfo, "HANR001016", DbType.Decimal, 0, 10, 0, 更新データ.取引ヘッダー.R001016))
        query.Append("," & AddParamInfo(paramInfo, "HANR001017", DbType.Decimal, 0, 10, 0, 更新データ.取引ヘッダー.R001017))
        query.Append("," & AddParamInfo(paramInfo, "HANR001018", DbType.Decimal, 0, 1, 0, 更新データ.取引ヘッダー.R001018))
        query.Append("," & AddParamInfo(paramInfo, "HANR001019", DbType.Decimal, 0, 1, 0, 更新データ.取引ヘッダー.R001019))
        query.Append("," & AddParamInfo(paramInfo, "HANR001020", DbType.Decimal, 0, 1, 0, 更新データ.取引ヘッダー.R001020))
        query.Append("," & AddParamInfo(paramInfo, "HANR001021", DbType.Decimal, 0, 8, 0, 更新データ.取引ヘッダー.R001021))
        query.Append("," & AddParamInfo(paramInfo, "HANR001022", DbType.Decimal, 0, 1, 0, 更新データ.取引ヘッダー.R001022))
        query.Append("," & AddParamInfo(paramInfo, "HANR001023", DbType.Decimal, 0, 4, 2, 更新データ.取引ヘッダー.R001023))
        query.Append("," & AddParamInfo(paramInfo, "HANR001024", DbType.Decimal, 0, 1, 0, 更新データ.取引ヘッダー.R001024))
        query.Append("," & AddParamInfo(paramInfo, "HANR001025", DbType.Decimal, 0, 3, 0, 更新データ.取引ヘッダー.R001025))
        query.Append("," & AddParamInfo(paramInfo, "HANR001026", DbType.AnsiStringFixedLength, 5, 0, 0, 更新データ.取引ヘッダー.R001026))
        query.Append("," & AddParamInfo(paramInfo, "HANR001027", DbType.String, 36, 0, 0, 更新データ.取引ヘッダー.R001027))
        query.Append("," & AddParamInfo(paramInfo, "HANR001028", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001028))
        query.Append("," & AddParamInfo(paramInfo, "HANR001029", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001029))
        query.Append("," & AddParamInfo(paramInfo, "HANR001030", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001030))
        query.Append("," & AddParamInfo(paramInfo, "HANR001031", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001031))
        query.Append("," & AddParamInfo(paramInfo, "HANR001032", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001032))
        query.Append("," & AddParamInfo(paramInfo, "HANR001033", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001033))
        query.Append("," & AddParamInfo(paramInfo, "HANR001034", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001034))
        query.Append("," & AddParamInfo(paramInfo, "HANR001035", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001035))
        query.Append("," & AddParamInfo(paramInfo, "HANR001036", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001036))
        query.Append("," & AddParamInfo(paramInfo, "HANR001037", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001037))
        query.Append("," & AddParamInfo(paramInfo, "HANR001038", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001038))
        query.Append("," & AddParamInfo(paramInfo, "HANR001039", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001039))
        query.Append("," & AddParamInfo(paramInfo, "HANR001040", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001040))
        query.Append("," & AddParamInfo(paramInfo, "HANR001041", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001041))
        query.Append("," & AddParamInfo(paramInfo, "HANR001042", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001042))
        query.Append("," & AddParamInfo(paramInfo, "HANR001043", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001043))
        query.Append("," & AddParamInfo(paramInfo, "HANR001044", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001044))
        query.Append("," & AddParamInfo(paramInfo, "HANR001045", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001045))
        query.Append("," & AddParamInfo(paramInfo, "HANR001046", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001046))
        query.Append("," & AddParamInfo(paramInfo, "HANR001047", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001047))
        query.Append("," & AddParamInfo(paramInfo, "HANR001048", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001048))
        query.Append("," & AddParamInfo(paramInfo, "HANR001049", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001049))
        query.Append("," & AddParamInfo(paramInfo, "HANR001050", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001050))
        query.Append("," & AddParamInfo(paramInfo, "HANR001051", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001051))
        query.Append("," & AddParamInfo(paramInfo, "HANR001052", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001052))
        '↓D-20170601-X1-桁数拡張
        'query.Append("," & AddParamInfo(paramInfo, "HANR001053", DbType.String, 32, 0, 0, 更新データ.取引ヘッダー.R001053))
        'query.Append("," & AddParamInfo(paramInfo, "HANR001054", DbType.String, 32, 0, 0, 更新データ.取引ヘッダー.R001054))
        'query.Append("," & AddParamInfo(paramInfo, "HANR001055", DbType.String, 32, 0, 0, 更新データ.取引ヘッダー.R001055))
        '↑D-20170601-X1-桁数拡張
        '↓A-20170601-X1-桁数拡張
        query.Append("," & AddParamInfo(paramInfo, "HANR001053", DbType.String, 48, 0, 0, 更新データ.取引ヘッダー.R001053))
        query.Append("," & AddParamInfo(paramInfo, "HANR001054", DbType.String, 48, 0, 0, 更新データ.取引ヘッダー.R001054))
        query.Append("," & AddParamInfo(paramInfo, "HANR001055", DbType.String, 48, 0, 0, 更新データ.取引ヘッダー.R001055))
        '↑A-20170601-X1-桁数拡張
        query.Append("," & AddParamInfo(paramInfo, "HANR001056", DbType.AnsiStringFixedLength, 3, 0, 0, 更新データ.取引ヘッダー.R001056))
        query.Append("," & AddParamInfo(paramInfo, "HANR001057", DbType.Decimal, 0, 1, 0, 更新データ.取引ヘッダー.R001057))
        query.Append("," & AddParamInfo(paramInfo, "HANR001058", DbType.Decimal, 0, 10, 0, 更新データ.取引ヘッダー.R001058))
        query.Append("," & AddParamInfo(paramInfo, "HANR001059", DbType.Decimal, 0, 1, 0, 更新データ.取引ヘッダー.R001059))
        query.Append("," & AddParamInfo(paramInfo, "HANR001060", DbType.Decimal, 0, 10, 0, 更新データ.取引ヘッダー.R001060))
        query.Append("," & AddParamInfo(paramInfo, "HANR001061", DbType.Decimal, 0, 2, 0, 更新データ.取引ヘッダー.R001061))
        query.Append("," & AddParamInfo(paramInfo, "HANR001062", DbType.Decimal, 0, 1, 0, 更新データ.取引ヘッダー.R001062))
        query.Append("," & AddParamInfo(paramInfo, "HANR001063", DbType.Decimal, 0, 1, 0, 更新データ.取引ヘッダー.R001063))
        query.Append("," & AddParamInfo(paramInfo, "HANR001064", DbType.Decimal, 0, 1, 0, 更新データ.取引ヘッダー.R001064))
        query.Append("," & AddParamInfo(paramInfo, "HANR001065", DbType.Decimal, 0, 1, 0, 更新データ.取引ヘッダー.R001065))
        query.Append("," & AddParamInfo(paramInfo, "HANR001066", DbType.Decimal, 0, 8, 0, 更新データ.取引ヘッダー.R001066))
        query.Append("," & AddParamInfo(paramInfo, "HANR001067", DbType.Decimal, 0, 8, 0, 更新データ.取引ヘッダー.R001067))
        query.Append("," & AddParamInfo(paramInfo, "HANR001068", DbType.Decimal, 0, 10, 0, 更新データ.取引ヘッダー.R001068))
        query.Append("," & AddParamInfo(paramInfo, "HANR001069", DbType.Decimal, 0, 1, 0, 更新データ.取引ヘッダー.R001069))
        query.Append("," & AddParamInfo(paramInfo, "HANR001070", DbType.Decimal, 0, 1, 0, 更新データ.取引ヘッダー.R001070))
        query.Append("," & AddParamInfo(paramInfo, "HANR001071", DbType.AnsiStringFixedLength, 20, 0, 0, 更新データ.取引ヘッダー.R001071))
        query.Append("," & AddParamInfo(paramInfo, "HANR001072", DbType.Decimal, 0, 3, 0, 更新データ.取引ヘッダー.R001072))
        query.Append("," & AddParamInfo(paramInfo, "HANR001073", DbType.AnsiStringFixedLength, 8, 0, 0, 更新データ.取引ヘッダー.R001073))
        query.Append("," & AddParamInfo(paramInfo, "HANR001074", DbType.Decimal, 0, 1, 0, 更新データ.取引ヘッダー.R001074))
        query.Append("," & AddParamInfo(paramInfo, "HANR001075", DbType.Decimal, 0, 4, 0, 更新データ.取引ヘッダー.R001075))
        query.Append("," & AddParamInfo(paramInfo, "HANR001076", DbType.AnsiStringFixedLength, 6, 0, 0, 更新データ.取引ヘッダー.R001076))
        query.Append("," & AddParamInfo(paramInfo, "HANR001999", DbType.Decimal, 0, 9, 0, 更新データ.取引ヘッダー.R001999))

        query.Append("," & AddParamInfo(paramInfo, "HANR001A001", DbType.AnsiStringFixedLength, 12, 0, 0, 更新データ.取引ヘッダー.R001A001))
        query.Append("," & AddParamInfo(paramInfo, "HANR001A002", DbType.AnsiStringFixedLength, 10, 0, 0, 更新データ.取引ヘッダー.R001A002))
        query.Append("," & AddParamInfo(paramInfo, "HANR001A003", DbType.AnsiStringFixedLength, 2, 0, 0, 更新データ.取引ヘッダー.R001A003))
        query.Append("," & AddParamInfo(paramInfo, "HANR001A004", DbType.Decimal, 0, 1, 0, 更新データ.取引ヘッダー.R001A004))
        query.Append("," & AddParamInfo(paramInfo, "HANR001A005", DbType.Decimal, 0, 10, 0, 更新データ.取引ヘッダー.R001A005))
        query.Append("," & AddParamInfo(paramInfo, "HANR001A006", DbType.Decimal, 0, 1, 0, 更新データ.取引ヘッダー.R001A006))
        query.Append("," & AddParamInfo(paramInfo, "HANR001A007", DbType.Decimal, 0, 1, 0, 更新データ.取引ヘッダー.R001A007))
        query.Append("," & AddParamInfo(paramInfo, "HANR001A008", DbType.Decimal, 0, 10, 0, 更新データ.取引ヘッダー.R001A008))
        query.Append("," & AddParamInfo(paramInfo, "HANR001A009", DbType.Decimal, 0, 1, 0, 更新データ.取引ヘッダー.R001A009))
        query.Append("," & AddParamInfo(paramInfo, "HANR001A010", DbType.Decimal, 0, 1, 0, 更新データ.取引ヘッダー.R001A010))
        query.Append("," & AddParamInfo(paramInfo, "HANR001A011", DbType.Decimal, 0, 10, 0, 更新データ.取引ヘッダー.R001A011))
        query.Append("," & AddParamInfo(paramInfo, "HANR001A012", DbType.AnsiStringFixedLength, 8, 0, 0, 更新データ.取引ヘッダー.R001A012))
        query.Append("," & AddParamInfo(paramInfo, "HANR001A013", DbType.AnsiStringFixedLength, 2, 0, 0, 更新データ.取引ヘッダー.R001A013))
        query.Append("," & AddParamInfo(paramInfo, "HANR001A014", DbType.Decimal, 0, 1, 0, 更新データ.取引ヘッダー.R001A014))
        query.Append("," & AddParamInfo(paramInfo, "HANR001A015", DbType.Decimal, 0, 1, 0, 更新データ.取引ヘッダー.R001A015))
        query.Append("," & AddParamInfo(paramInfo, "HANR001A016", DbType.Decimal, 0, 8, 0, 更新データ.取引ヘッダー.R001A016))

        'A-20111124_11↓
        If MyImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 3D AndAlso
           MyImportParam.Myコントロール情報.MyMOA機能追加.仕掛管理区分 = MOA機能追加定義型.その他管理区分型.行う Then
            query.Append("," & AddParamInfo(paramInfo, "HANR001S002", DbType.Decimal, 0, 1, 0, 更新データ.取引ヘッダー.R001S002))
        End If
        'A-20111124_11↑

        'A-20121217_Ver7.50_1↓
        If MyImportParam.Myコントロール情報.MyMOAオプション.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う Then
            query.Append("," & AddParamInfo(paramInfo, "HANR001087", DbType.Decimal, 0, 1, 0, 更新データ.取引ヘッダー.R001087))
            query.Append("," & AddParamInfo(paramInfo, "HANR001088", DbType.Decimal, 0, 1, 0, 更新データ.取引ヘッダー.R001088))
            query.Append("," & AddParamInfo(paramInfo, "HANR001089", DbType.Decimal, 0, 9, 4, 更新データ.取引ヘッダー.R001089))
            'A-20160324_1↓
            If _myImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 8D Then
                query.Append("," & AddParamInfo(paramInfo, "HANR001095", DbType.Decimal, 0, 1, 0, 更新データ.取引ヘッダー.R001095))
                query.Append("," & AddParamInfo(paramInfo, "HANR001096", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001096))
                query.Append("," & AddParamInfo(paramInfo, "HANR001097", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001097))
                query.Append("," & AddParamInfo(paramInfo, "HANR001098", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001098))
                query.Append("," & AddParamInfo(paramInfo, "HANR001099", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001099))
                query.Append("," & AddParamInfo(paramInfo, "HANR001100", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001100))
                query.Append("," & AddParamInfo(paramInfo, "HANR001101", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001101))
                query.Append("," & AddParamInfo(paramInfo, "HANR001102", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001102))
                query.Append("," & AddParamInfo(paramInfo, "HANR001103", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001103))
                query.Append("," & AddParamInfo(paramInfo, "HANR001104", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001104))
                query.Append("," & AddParamInfo(paramInfo, "HANR001105", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001105))
            End If
            'A-20160324_1↑
            query.Append("," & AddParamInfo(paramInfo, "HANR001S003", DbType.Decimal, 0, 1, 0, 更新データ.取引ヘッダー.R001S003))
            query.Append("," & AddParamInfo(paramInfo, "HANR001S004", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001S004))
            query.Append("," & AddParamInfo(paramInfo, "HANR001S005", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001S005))
            query.Append("," & AddParamInfo(paramInfo, "HANR001S006", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001S006))
            query.Append("," & AddParamInfo(paramInfo, "HANR001S007", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001S007))
            query.Append("," & AddParamInfo(paramInfo, "HANR001S008", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001S008))
            query.Append("," & AddParamInfo(paramInfo, "HANR001S009", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001S009))
            query.Append("," & AddParamInfo(paramInfo, "HANR001S010", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001S010))
            query.Append("," & AddParamInfo(paramInfo, "HANR001S011", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001S011))
            query.Append("," & AddParamInfo(paramInfo, "HANR001S012", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001S012))
            query.Append("," & AddParamInfo(paramInfo, "HANR001S013", DbType.Decimal, 0, 19, 4, 更新データ.取引ヘッダー.R001S013))
            query.Append("," & AddParamInfo(paramInfo, "HANR001S014", DbType.AnsiStringFixedLength, 20, 0, 0, 更新データ.取引ヘッダー.R001S014))
            'A-20160324_1↓
            If _myImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 8D Then
                query.Append("," & AddParamInfo(paramInfo, "HANR001S015", DbType.Decimal, 0, 1, 0, 更新データ.取引ヘッダー.R001S015))
            End If
            'A-20160324_1↑
        End If
        'A-20121217_Ver7.50_1↑

        ''↓A-2008/07/18_Ver7.30_GENKA
        'If MyImportParam.Myコントロール情報.Myオプション区分.原価管理 = オプション区分定義型.区分型.行う Then
        '    query.Append("," & AddParamInfo(paramInfo, "HANR001077", DbType.AnsiStringFixedLength, 20, 0, 0, 更新データ.仕入ヘッダー.R001077))
        '    query.Append("," & AddParamInfo(paramInfo, "HANR001078", DbType.AnsiStringFixedLength, 2, 0, 0, 更新データ.仕入ヘッダー.R001078))
        'End If
        ''↑A-2008/07/18_Ver7.30_GENKA
        ''↓A-2009/08/21_RIREKI
        'If MyImportParam.Myコントロール情報.My変更履歴.変更履歴使用区分 = True Then
        '    query.Append("," & AddParamInfo(paramInfo, "HANR001911", DbType.Decimal, 0, 5, 0, 更新データ.仕入ヘッダー.R001911))
        '    query.Append("," & AddParamInfo(paramInfo, "HANR001914", DbType.Decimal, 0, 8, 0, 更新データ.仕入ヘッダー.R001914))
        '    query.Append("," & AddParamInfo(paramInfo, "HANR001915", DbType.Decimal, 0, 9, 0, 更新データ.仕入ヘッダー.R001915))
        '    query.Append("," & AddParamInfo(paramInfo, "HANR001916", DbType.String, 64, 0, 0, 更新データ.仕入ヘッダー.R001916))
        '    query.Append("," & AddParamInfo(paramInfo, "HANR001917", DbType.AnsiStringFixedLength, 32, 0, 0, 更新データ.仕入ヘッダー.R001917))
        '    query.Append("," & AddParamInfo(paramInfo, "HANR001918", DbType.Decimal, 0, 4, 0, 更新データ.仕入ヘッダー.R001918))
        '    query.Append("," & AddParamInfo(paramInfo, "HANR001919", DbType.String, 64, 0, 0, 更新データ.仕入ヘッダー.R001919))
        'End If
        ''↑A-2009/08/21_RIREKI
        query.Append(" )")

        Return query.ToString
    End Function
    'A-20110912_1↓
    Public Function SelectHANR001SK(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                             ByVal 処理連番 As Long) As String Implements IMyQueryMaker.SelectHANR001SK    'X1変換Tool-20170508
        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(" HANR001004 ")                                                     '伝票区分
        query.Append(",HANR001S002 ")                                                    '仕掛生成区分
        'A-20150108_1↓
        query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SEIR010016, 0) SEIR010016 ")   '発注番号
        query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SEIR010040, 0) SEIR010040 ")   '発注区分
        query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SEIR010045, 0) SEIR010045 ")   '返品区分
        query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SEIR010046, 0) SEIR010046 ")   '元入荷連番
        'A-20150108_1↑

        query.Append("FROM " & MyBase.ExchangeTableName("HAN10R001TORIHIKIH"))    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())

        'A-20150108_1↓
        query.Append(" LEFT OUTER JOIN " & MyBase.ExchangeTableName("SEI10R010NYUSHUKKAH"))    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())
        query.Append(" ON SEIR010004 = 1 AND SEIR010005 = HANR001068 ")
        'A-20150108_1↑

        '--------------------
        '   検索条件
        '--------------------

        query.Append(" WHERE ")
        ' 伝票区分
        'query.Append("HANR001004 = 9 ")                    'D-20111124_11
        query.Append("(HANR001004 = 5 OR HANR001004 = 9)")  'A-20111124_11
        query.Append(" AND ")

        ' 入出庫区分
        query.Append("HANR001074 = 1 ")
        query.Append(" AND ")

        ' 入出荷処理連番
        query.Append("HANR001068 = " & AddParamInfo(paramInfo, "HANR001068", DbType.Decimal, 0, 10, 0, 処理連番) & " ")

        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString
    End Function
    'A-20110912_1↑
#End Region

#Region "■取引明細■"

    'A-20121217_Ver7.50_1↓
    Public Function SelectHANR001按分済受入伝票(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                                ByVal 諸掛管理番号 As String
                ) As String Implements IMyQueryMaker.SelectHANR001按分済受入伝票    'X1変換Tool-20170508
        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(QueryWrapper.AddIndexHintOracle(GetIndexHint("SEL_P_1")))
        query.Append(" HANR002004 ")                                                    '処理連番

        query.Append("FROM " & MyBase.ExchangeTableName("HAN10R002TORIHIKIM"))    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock(GetIndexHint("R002_P_1")))

        query.Append(" WHERE ")
        query.Append("     " & "HANR002002 = 1 ")
        query.Append(" AND " & "HANR002005 = 0 ")
        query.Append(" AND " & "HANR002010 = 8 ")
        query.Append(" AND " & "HANR002S016 = 1 ")
        query.Append(" AND " & "HANR002S013 = " & AddParamInfo(paramInfo, "HANR002S013", DbType.String, 20, 0, 0, 諸掛管理番号) & " ")

        query.Append("ORDER BY HANR002002,HANR002004,HANR002005,HANR002006")
        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString
    End Function
    'A-20121217_Ver7.50_1↑

    Public Function InsertHANR002(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                  ByVal 更新データ As WorkTableUnitData,
                                  ByVal line As Integer) As String Implements IMyQueryMaker.InsertHANR002    'X1変換Tool-20170508
        Dim query As New System.Text.StringBuilder

        query.Append(" INSERT INTO ")
        query.Append(Me.ExchangeTableName("HAN10R002TORIHIKIM"))    'X1変換Tool-20170509

        query.Append(" (")
        query.Append(" HANR002001")
        query.Append(",HANR002002")
        query.Append(",HANR002003")
        query.Append(",HANR002004")
        query.Append(",HANR002005")
        query.Append(",HANR002006")
        query.Append(",HANR002007")
        query.Append(",HANR002008")
        query.Append(",HANR002009")
        query.Append(",HANR002010")
        query.Append(",HANR002011")
        query.Append(",HANR002012")
        query.Append(",HANR002013")
        query.Append(",HANR002014")
        query.Append(",HANR002015")
        query.Append(",HANR002016")
        query.Append(",HANR002017")
        query.Append(",HANR002018")
        query.Append(",HANR002019")
        query.Append(",HANR002020")
        query.Append(",HANR002021")
        query.Append(",HANR002022")
        query.Append(",HANR002023")
        query.Append(",HANR002024")
        query.Append(",HANR002025")
        query.Append(",HANR002026")
        query.Append(",HANR002027")
        query.Append(",HANR002028")
        query.Append(",HANR002029")
        query.Append(",HANR002030")
        query.Append(",HANR002031")
        query.Append(",HANR002032")
        query.Append(",HANR002033")
        query.Append(",HANR002034")
        query.Append(",HANR002035")
        query.Append(",HANR002036")
        query.Append(",HANR002037")
        query.Append(",HANR002038")
        query.Append(",HANR002039")
        query.Append(",HANR002040")
        query.Append(",HANR002041")
        query.Append(",HANR002042")
        query.Append(",HANR002043")
        query.Append(",HANR002044")
        query.Append(",HANR002045")
        query.Append(",HANR002046")
        query.Append(",HANR002047")
        query.Append(",HANR002048")
        query.Append(",HANR002049")
        query.Append(",HANR002050")
        query.Append(",HANR002051")
        query.Append(",HANR002052")
        query.Append(",HANR002053")
        query.Append(",HANR002054")
        query.Append(",HANR002055")
        query.Append(",HANR002056")
        query.Append(",HANR002057")
        query.Append(",HANR002058")
        query.Append(",HANR002059")
        query.Append(",HANR002060")
        query.Append(",HANR002061")
        query.Append(",HANR002062")
        query.Append(",HANR002063")
        query.Append(",HANR002064")
        query.Append(",HANR002065")
        query.Append(",HANR002066")
        query.Append(",HANR002067")
        query.Append(",HANR002068")
        query.Append(",HANR002069")
        query.Append(",HANR002070")
        query.Append(",HANR002071")
        query.Append(",HANR002072")
        query.Append(",HANR002073")
        query.Append(",HANR002074")
        query.Append(",HANR002075")
        query.Append(",HANR002076")
        query.Append(",HANR002077")
        query.Append(",HANR002999")

        query.Append(",HANR002A001")
        query.Append(",HANR002A002")
        query.Append(",HANR002A003")
        query.Append(",HANR002A004")
        query.Append(",HANR002A005")
        query.Append(",HANR002A006")
        query.Append(",HANR002A007")
        query.Append(",HANR002A008")
        query.Append(",HANR002A009")
        query.Append(",HANR002A010")
        query.Append(",HANR002A011")
        query.Append(",HANR002A012")
        query.Append(",HANR002A013")
        query.Append(",HANR002A014")
        query.Append(",HANR002A015")
        query.Append(",HANR002A016")
        query.Append(",HANR002A017")
        query.Append(",HANR002A018")
        query.Append(",HANR002A019")
        query.Append(",HANR002A020")
        query.Append(",HANR002A021")
        query.Append(",HANR002A022")
        query.Append(",HANR002A023")
        query.Append(",HANR002A024")
        query.Append(",HANR002A025")
        query.Append(",HANR002A026")
        query.Append(",HANR002A027")
        query.Append(",HANR002A028")
        query.Append(",HANR002A029")
        query.Append(",HANR002A030")
        query.Append(",HANR002A031")
        query.Append(",HANR002A032")
        query.Append(",HANR002A033")
        query.Append(",HANR002A034")
        query.Append(",HANR002A035")
        query.Append(",HANR002A036")
        query.Append(",HANR002A037")
        query.Append(",HANR002A038")
        query.Append(",HANR002A039")
        query.Append(",HANR002A040")
        query.Append(",HANR002A041")
        query.Append(",HANR002A042")

        'A-20121217_Ver7.50_1↓
        If MyImportParam.Myコントロール情報.MyMOAオプション.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う Then
            query.Append(",HANR002101 ")
            query.Append(",HANR002102 ")
            query.Append(",HANR002103 ")
            query.Append(",HANR002104 ")
            query.Append(",HANR002105 ")
            query.Append(",HANR002106 ")
            query.Append(",HANR002107 ")
            'A-20160324_1↓
            If MyImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 8D Then
                query.Append(",HANR002108 ")
                query.Append(",HANR002109 ")
                query.Append(",HANR002110 ")
                query.Append(",HANR002112 ")
                query.Append(",HANR002113 ")
                query.Append(",HANR002114 ")
                query.Append(",HANR002115 ")
            End If
            'A-20160324_1↑
            query.Append(",HANR002S001 ")
            query.Append(",HANR002S002 ")
            query.Append(",HANR002S003 ")
            query.Append(",HANR002S004 ")
            query.Append(",HANR002S005 ")
            query.Append(",HANR002S006 ")
            query.Append(",HANR002S007 ")
            query.Append(",HANR002S008 ")
            query.Append(",HANR002S009 ")
            query.Append(",HANR002S010 ")
            query.Append(",HANR002S011 ")
            query.Append(",HANR002S012 ")
            query.Append(",HANR002S013 ")
            query.Append(",HANR002S014 ")
            query.Append(",HANR002S015 ")
            query.Append(",HANR002S016 ")
        End If
        'A-20121217_Ver7.50_1↑

        'A-20141105_1↓
        If MyImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 6D Then
            query.Append(",HANR002S017 ")
            query.Append(",HANR002S018 ")
        End If
        'A-20141105_1↑
        'A-20160324_2↓
        If MyImportParam.Myコントロール情報.使用条件(Myコントロール情報Param.条件型.品目別原価計算機能, 8D) = True Then
            query.Append(",HANR002S020 ")
        End If
        'A-20160324_2↑

        ''↓A-2008/07/18_Ver7.30_GENKA
        'If MyImportParam.Myコントロール情報.Myオプション区分.原価管理 = オプション区分定義型.区分型.行う Then
        '    query.Append(",HANR002078")
        '    query.Append(",HANR002079")
        '    query.Append(",HANR002080")
        'End If
        ''↑A-2008/07/18_Ver7.30_GENKA
        ''↓A-2009/12/18_Ver7.40_UCHIWAKE
        'If MyImportParam.Myコントロール情報.Myオプション区分.商品内訳管理 = True Then
        '    query.Append(",HANR002083")
        '    query.Append(",HANR002084")
        'End If
        ''↑A-2009/12/18_Ver7.40_UCHIWAKE
        ''↓A-2009/12/18_Ver7.40_LOT
        'If MyImportParam.Myコントロール情報.Myオプション区分.ロット管理 = True Then
        '    query.Append(",HANR002086")
        'End If
        ''↑A-2009/12/18_Ver7.40_LOT
        query.Append(" )")

        query.Append(" VALUES (")
        query.Append(" " & AddParamInfo(paramInfo, "HANR002001", DbType.Decimal, 0, 8, 0, 更新データ.取引明細(line).R002001))
        query.Append("," & AddParamInfo(paramInfo, "HANR002002", DbType.Decimal, 0, 1, 0, 更新データ.取引明細(line).R002002))
        query.Append("," & AddParamInfo(paramInfo, "HANR002003", DbType.Decimal, 0, 8, 0, 更新データ.取引明細(line).R002003))
        query.Append("," & AddParamInfo(paramInfo, "HANR002004", DbType.Decimal, 0, 10, 0, 更新データ.取引明細(line).R002004))
        query.Append("," & AddParamInfo(paramInfo, "HANR002005", DbType.Decimal, 0, 1, 0, 更新データ.取引明細(line).R002005))
        query.Append("," & AddParamInfo(paramInfo, "HANR002006", DbType.Decimal, 0, 3, 0, 更新データ.取引明細(line).R002006))
        query.Append("," & AddParamInfo(paramInfo, "HANR002007", DbType.Decimal, 0, 1, 0, 更新データ.取引明細(line).R002007))
        query.Append("," & AddParamInfo(paramInfo, "HANR002008", DbType.AnsiStringFixedLength, 11, 0, 0, 更新データ.取引明細(line).R002008))
        query.Append("," & AddParamInfo(paramInfo, "HANR002009", DbType.AnsiStringFixedLength, 8, 0, 0, 更新データ.取引明細(line).R002009))
        query.Append("," & AddParamInfo(paramInfo, "HANR002010", DbType.Decimal, 0, 2, 0, 更新データ.取引明細(line).R002010))
        query.Append("," & AddParamInfo(paramInfo, "HANR002011", DbType.Decimal, 0, 10, 0, 更新データ.取引明細(line).R002011))
        query.Append("," & AddParamInfo(paramInfo, "HANR002012", DbType.Decimal, 0, 3, 0, 更新データ.取引明細(line).R002012))
        query.Append("," & AddParamInfo(paramInfo, "HANR002013", DbType.Decimal, 0, 10, 0, 更新データ.取引明細(line).R002013))
        query.Append("," & AddParamInfo(paramInfo, "HANR002014", DbType.Decimal, 0, 3, 0, 更新データ.取引明細(line).R002014))
        query.Append("," & AddParamInfo(paramInfo, "HANR002015", DbType.Decimal, 0, 10, 0, 更新データ.取引明細(line).R002015))
        query.Append("," & AddParamInfo(paramInfo, "HANR002016", DbType.Decimal, 0, 3, 0, 更新データ.取引明細(line).R002016))
        query.Append("," & AddParamInfo(paramInfo, "HANR002017", DbType.AnsiStringFixedLength, 8, 0, 0, 更新データ.取引明細(line).R002017))
        query.Append("," & AddParamInfo(paramInfo, "HANR002018", DbType.AnsiStringFixedLength, 11, 0, 0, 更新データ.取引明細(line).R002018))
        query.Append("," & AddParamInfo(paramInfo, "HANR002019", DbType.AnsiStringFixedLength, 25, 0, 0, 更新データ.取引明細(line).R002019))
        query.Append("," & AddParamInfo(paramInfo, "HANR002020", DbType.String, 36, 0, 0, 更新データ.取引明細(line).R002020))
        query.Append("," & AddParamInfo(paramInfo, "HANR002021", DbType.String, 4, 0, 0, 更新データ.取引明細(line).R002021))
        query.Append("," & AddParamInfo(paramInfo, "HANR002022", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002022))
        query.Append("," & AddParamInfo(paramInfo, "HANR002023", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002023))
        query.Append("," & AddParamInfo(paramInfo, "HANR002024", DbType.String, 4, 0, 0, 更新データ.取引明細(line).R002024))
        query.Append("," & AddParamInfo(paramInfo, "HANR002025", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002025))
        query.Append("," & AddParamInfo(paramInfo, "HANR002026", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002026))
        query.Append("," & AddParamInfo(paramInfo, "HANR002027", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002027))
        query.Append("," & AddParamInfo(paramInfo, "HANR002028", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002028))
        query.Append("," & AddParamInfo(paramInfo, "HANR002029", DbType.Decimal, 0, 2, 0, 更新データ.取引明細(line).R002029))
        query.Append("," & AddParamInfo(paramInfo, "HANR002030", DbType.Decimal, 0, 4, 1, 更新データ.取引明細(line).R002030))
        query.Append("," & AddParamInfo(paramInfo, "HANR002031", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002031))
        query.Append("," & AddParamInfo(paramInfo, "HANR002032", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002032))
        query.Append("," & AddParamInfo(paramInfo, "HANR002033", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002033))
        query.Append("," & AddParamInfo(paramInfo, "HANR002034", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002034))
        query.Append("," & AddParamInfo(paramInfo, "HANR002035", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002035))
        query.Append("," & AddParamInfo(paramInfo, "HANR002036", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002036))
        query.Append("," & AddParamInfo(paramInfo, "HANR002037", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002037))
        query.Append("," & AddParamInfo(paramInfo, "HANR002038", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002038))
        query.Append("," & AddParamInfo(paramInfo, "HANR002039", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002039))
        query.Append("," & AddParamInfo(paramInfo, "HANR002040", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002040))
        query.Append("," & AddParamInfo(paramInfo, "HANR002041", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002041))
        query.Append("," & AddParamInfo(paramInfo, "HANR002042", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002042))
        query.Append("," & AddParamInfo(paramInfo, "HANR002043", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002043))
        query.Append("," & AddParamInfo(paramInfo, "HANR002044", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002044))
        query.Append("," & AddParamInfo(paramInfo, "HANR002045", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002045))
        query.Append("," & AddParamInfo(paramInfo, "HANR002046", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002046))
        query.Append("," & AddParamInfo(paramInfo, "HANR002047", DbType.Decimal, 0, 1, 0, 更新データ.取引明細(line).R002047))
        query.Append("," & AddParamInfo(paramInfo, "HANR002048", DbType.Decimal, 0, 4, 2, 更新データ.取引明細(line).R002048))
        query.Append("," & AddParamInfo(paramInfo, "HANR002049", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002049))
        query.Append("," & AddParamInfo(paramInfo, "HANR002050", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002050))
        query.Append("," & AddParamInfo(paramInfo, "HANR002051", DbType.Decimal, 0, 1, 0, 更新データ.取引明細(line).R002051))
        query.Append("," & AddParamInfo(paramInfo, "HANR002052", DbType.Decimal, 0, 1, 0, 更新データ.取引明細(line).R002052))
        query.Append("," & AddParamInfo(paramInfo, "HANR002053", DbType.AnsiStringFixedLength, 5, 0, 0, 更新データ.取引明細(line).R002053))
        query.Append("," & AddParamInfo(paramInfo, "HANR002054", DbType.String, 12, 0, 0, 更新データ.取引明細(line).R002054))
        query.Append("," & AddParamInfo(paramInfo, "HANR002055", DbType.String, 12, 0, 0, 更新データ.取引明細(line).R002055))
        query.Append("," & AddParamInfo(paramInfo, "HANR002056", DbType.Decimal, 0, 8, 0, 更新データ.取引明細(line).R002056))
        query.Append("," & AddParamInfo(paramInfo, "HANR002057", DbType.Decimal, 0, 1, 0, 更新データ.取引明細(line).R002057))
        query.Append("," & AddParamInfo(paramInfo, "HANR002058", DbType.Decimal, 0, 1, 0, 更新データ.取引明細(line).R002058))
        query.Append("," & AddParamInfo(paramInfo, "HANR002059", DbType.AnsiStringFixedLength, 3, 0, 0, 更新データ.取引明細(line).R002059))
        query.Append("," & AddParamInfo(paramInfo, "HANR002060", DbType.Decimal, 0, 10, 0, 更新データ.取引明細(line).R002060))
        query.Append("," & AddParamInfo(paramInfo, "HANR002061", DbType.Decimal, 0, 1, 0, 更新データ.取引明細(line).R002061))
        query.Append("," & AddParamInfo(paramInfo, "HANR002062", DbType.Decimal, 0, 10, 0, 更新データ.取引明細(line).R002062))
        query.Append("," & AddParamInfo(paramInfo, "HANR002063", DbType.Decimal, 0, 3, 0, 更新データ.取引明細(line).R002063))
        query.Append("," & AddParamInfo(paramInfo, "HANR002064", DbType.Decimal, 0, 1, 0, 更新データ.取引明細(line).R002064))
        query.Append("," & AddParamInfo(paramInfo, "HANR002065", DbType.Decimal, 0, 2, 0, 更新データ.取引明細(line).R002065))
        query.Append("," & AddParamInfo(paramInfo, "HANR002066", DbType.AnsiStringFixedLength, 20, 0, 0, 更新データ.取引明細(line).R002066))
        query.Append("," & AddParamInfo(paramInfo, "HANR002067", DbType.AnsiStringFixedLength, 20, 0, 0, 更新データ.取引明細(line).R002067))
        query.Append("," & AddParamInfo(paramInfo, "HANR002068", DbType.AnsiStringFixedLength, 20, 0, 0, 更新データ.取引明細(line).R002068))
        query.Append("," & AddParamInfo(paramInfo, "HANR002069", DbType.Decimal, 0, 1, 0, 更新データ.取引明細(line).R002069))
        query.Append("," & AddParamInfo(paramInfo, "HANR002070", DbType.Decimal, 0, 10, 0, 更新データ.取引明細(line).R002070))
        query.Append("," & AddParamInfo(paramInfo, "HANR002071", DbType.Decimal, 0, 3, 0, 更新データ.取引明細(line).R002071))
        query.Append("," & AddParamInfo(paramInfo, "HANR002072", DbType.Decimal, 0, 1, 0, 更新データ.取引明細(line).R002072))
        query.Append("," & AddParamInfo(paramInfo, "HANR002073", DbType.AnsiStringFixedLength, 20, 0, 0, 更新データ.取引明細(line).R002073))
        query.Append("," & AddParamInfo(paramInfo, "HANR002074", DbType.Decimal, 0, 1, 0, 更新データ.取引明細(line).R002074))
        query.Append("," & AddParamInfo(paramInfo, "HANR002075", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002075))
        query.Append("," & AddParamInfo(paramInfo, "HANR002076", DbType.AnsiStringFixedLength, 8, 0, 0, 更新データ.取引明細(line).R002076))
        query.Append("," & AddParamInfo(paramInfo, "HANR002077", DbType.AnsiStringFixedLength, 4, 0, 0, 更新データ.取引明細(line).R002077))
        query.Append("," & AddParamInfo(paramInfo, "HANR002999", DbType.Decimal, 0, 9, 0, 更新データ.取引明細(line).R002999))

        query.Append("," & AddParamInfo(paramInfo, "HANR002A001", DbType.String, 36, 0, 0, 更新データ.取引明細(line).R002A001))
        query.Append("," & AddParamInfo(paramInfo, "HANR002A002", DbType.String, 36, 0, 0, 更新データ.取引明細(line).R002A002))
        query.Append("," & AddParamInfo(paramInfo, "HANR002A003", DbType.String, 20, 0, 0, 更新データ.取引明細(line).R002A003))
        query.Append("," & AddParamInfo(paramInfo, "HANR002A004", DbType.Decimal, 0, 1, 0, 更新データ.取引明細(line).R002A004))
        query.Append("," & AddParamInfo(paramInfo, "HANR002A005", DbType.Decimal, 0, 10, 0, 更新データ.取引明細(line).R002A005))
        query.Append("," & AddParamInfo(paramInfo, "HANR002A006", DbType.AnsiStringFixedLength, 12, 0, 0, 更新データ.取引明細(line).R002A006))
        query.Append("," & AddParamInfo(paramInfo, "HANR002A007", DbType.AnsiStringFixedLength, 10, 0, 0, 更新データ.取引明細(line).R002A007))
        query.Append("," & AddParamInfo(paramInfo, "HANR002A008", DbType.AnsiStringFixedLength, 2, 0, 0, 更新データ.取引明細(line).R002A008))
        query.Append("," & AddParamInfo(paramInfo, "HANR002A009", DbType.Decimal, 0, 1, 0, 更新データ.取引明細(line).R002A009))
        query.Append("," & AddParamInfo(paramInfo, "HANR002A010", DbType.AnsiStringFixedLength, 20, 0, 0, 更新データ.取引明細(line).R002A010))
        query.Append("," & AddParamInfo(paramInfo, "HANR002A011", DbType.Decimal, 0, 8, 0, 更新データ.取引明細(line).R002A011))
        query.Append("," & AddParamInfo(paramInfo, "HANR002A012", DbType.AnsiStringFixedLength, 10, 0, 0, 更新データ.取引明細(line).R002A012))
        query.Append("," & AddParamInfo(paramInfo, "HANR002A013", DbType.Decimal, 0, 1, 0, 更新データ.取引明細(line).R002A013))
        query.Append("," & AddParamInfo(paramInfo, "HANR002A014", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002A014))
        query.Append("," & AddParamInfo(paramInfo, "HANR002A015", DbType.String, 4, 0, 0, 更新データ.取引明細(line).R002A015))
        query.Append("," & AddParamInfo(paramInfo, "HANR002A016", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002A016))
        query.Append("," & AddParamInfo(paramInfo, "HANR002A017", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002A017))
        query.Append("," & AddParamInfo(paramInfo, "HANR002A018", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002A018))
        query.Append("," & AddParamInfo(paramInfo, "HANR002A019", DbType.Decimal, 0, 1, 0, 更新データ.取引明細(line).R002A019))
        query.Append("," & AddParamInfo(paramInfo, "HANR002A020", DbType.Decimal, 0, 1, 0, 更新データ.取引明細(line).R002A020))
        query.Append("," & AddParamInfo(paramInfo, "HANR002A021", DbType.Decimal, 0, 1, 0, 更新データ.取引明細(line).R002A021))
        query.Append("," & AddParamInfo(paramInfo, "HANR002A022", DbType.AnsiStringFixedLength, 11, 0, 0, 更新データ.取引明細(line).R002A022))
        query.Append("," & AddParamInfo(paramInfo, "HANR002A023", DbType.Decimal, 0, 10, 0, 更新データ.取引明細(line).R002A023))
        query.Append("," & AddParamInfo(paramInfo, "HANR002A024", DbType.Decimal, 0, 1, 0, 更新データ.取引明細(line).R002A024))
        query.Append("," & AddParamInfo(paramInfo, "HANR002A025", DbType.Decimal, 0, 1, 0, 更新データ.取引明細(line).R002A025))
        query.Append("," & AddParamInfo(paramInfo, "HANR002A026", DbType.Decimal, 0, 10, 0, 更新データ.取引明細(line).R002A026))
        query.Append("," & AddParamInfo(paramInfo, "HANR002A027", DbType.Decimal, 0, 10, 0, 更新データ.取引明細(line).R002A027))
        query.Append("," & AddParamInfo(paramInfo, "HANR002A028", DbType.Decimal, 0, 10, 0, 更新データ.取引明細(line).R002A028))
        query.Append("," & AddParamInfo(paramInfo, "HANR002A029", DbType.Decimal, 0, 5, 0, 更新データ.取引明細(line).R002A029))
        query.Append("," & AddParamInfo(paramInfo, "HANR002A030", DbType.AnsiStringFixedLength, 6, 0, 0, 更新データ.取引明細(line).R002A030))
        query.Append("," & AddParamInfo(paramInfo, "HANR002A031", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002A031))
        query.Append("," & AddParamInfo(paramInfo, "HANR002A032", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002A032))
        query.Append("," & AddParamInfo(paramInfo, "HANR002A033", DbType.Decimal, 0, 1, 0, 更新データ.取引明細(line).R002A033))
        query.Append("," & AddParamInfo(paramInfo, "HANR002A034", DbType.Decimal, 0, 10, 0, 更新データ.取引明細(line).R002A034))
        query.Append("," & AddParamInfo(paramInfo, "HANR002A035", DbType.Decimal, 0, 3, 0, 更新データ.取引明細(line).R002A035))
        query.Append("," & AddParamInfo(paramInfo, "HANR002A036", DbType.Decimal, 0, 8, 0, 更新データ.取引明細(line).R002A036))
        query.Append("," & AddParamInfo(paramInfo, "HANR002A037", DbType.AnsiStringFixedLength, 6, 0, 0, 更新データ.取引明細(line).R002A037))
        query.Append("," & AddParamInfo(paramInfo, "HANR002A038", DbType.AnsiStringFixedLength, 6, 0, 0, 更新データ.取引明細(line).R002A038))
        query.Append("," & AddParamInfo(paramInfo, "HANR002A039", DbType.AnsiStringFixedLength, 6, 0, 0, 更新データ.取引明細(line).R002A039))
        query.Append("," & AddParamInfo(paramInfo, "HANR002A040", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002A040))
        query.Append("," & AddParamInfo(paramInfo, "HANR002A041", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002A041))
        query.Append("," & AddParamInfo(paramInfo, "HANR002A042", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002A042))

        'A-20121217_Ver7.50_1↓
        If MyImportParam.Myコントロール情報.MyMOAオプション.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う Then
            query.Append("," & AddParamInfo(paramInfo, "HANR002101", DbType.Decimal, 0, 1, 0, 更新データ.取引明細(line).R002101))
            query.Append("," & AddParamInfo(paramInfo, "HANR002102", DbType.Decimal, 0, 1, 0, 更新データ.取引明細(line).R002102))
            query.Append("," & AddParamInfo(paramInfo, "HANR002103", DbType.Decimal, 0, 9, 4, 更新データ.取引明細(line).R002103))
            query.Append("," & AddParamInfo(paramInfo, "HANR002104", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002104))
            query.Append("," & AddParamInfo(paramInfo, "HANR002105", DbType.Decimal, 0, 1, 0, 更新データ.取引明細(line).R002105))
            query.Append("," & AddParamInfo(paramInfo, "HANR002106", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002106))
            query.Append("," & AddParamInfo(paramInfo, "HANR002107", DbType.Decimal, 0, 9, 4, 更新データ.取引明細(line).R002107))
            'A-20160324_1↓
            If MyImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 8D Then
                query.Append("," & AddParamInfo(paramInfo, "HANR002108", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002108))
                query.Append("," & AddParamInfo(paramInfo, "HANR002109", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002109))
                query.Append("," & AddParamInfo(paramInfo, "HANR002110", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002110))
                query.Append("," & AddParamInfo(paramInfo, "HANR002112", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002112))
                query.Append("," & AddParamInfo(paramInfo, "HANR002113", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002113))
                query.Append("," & AddParamInfo(paramInfo, "HANR002114", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002114))
                query.Append("," & AddParamInfo(paramInfo, "HANR002115", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002115))
            End If
            'A-20160324_1↑

            query.Append("," & AddParamInfo(paramInfo, "HANR002S001", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002S001))
            query.Append("," & AddParamInfo(paramInfo, "HANR002S002", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002S002))
            query.Append("," & AddParamInfo(paramInfo, "HANR002S003", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002S003))
            query.Append("," & AddParamInfo(paramInfo, "HANR002S004", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002S004))
            query.Append("," & AddParamInfo(paramInfo, "HANR002S005", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002S005))
            query.Append("," & AddParamInfo(paramInfo, "HANR002S006", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002S006))
            query.Append("," & AddParamInfo(paramInfo, "HANR002S007", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002S007))
            query.Append("," & AddParamInfo(paramInfo, "HANR002S008", DbType.String, 36, 0, 0, 更新データ.取引明細(line).R002S008))
            query.Append("," & AddParamInfo(paramInfo, "HANR002S009", DbType.String, 36, 0, 0, 更新データ.取引明細(line).R002S009))
            query.Append("," & AddParamInfo(paramInfo, "HANR002S010", DbType.String, 36, 0, 0, 更新データ.取引明細(line).R002S010))
            query.Append("," & AddParamInfo(paramInfo, "HANR002S011", DbType.String, 10, 0, 0, 更新データ.取引明細(line).R002S011))
            query.Append("," & AddParamInfo(paramInfo, "HANR002S012", DbType.String, 10, 0, 0, 更新データ.取引明細(line).R002S012))
            query.Append("," & AddParamInfo(paramInfo, "HANR002S013", DbType.AnsiStringFixedLength, 20, 0, 0, 更新データ.取引明細(line).R002S013))
            query.Append("," & AddParamInfo(paramInfo, "HANR002S014", DbType.Decimal, 0, 1, 0, 更新データ.取引明細(line).R002S014))
            query.Append("," & AddParamInfo(paramInfo, "HANR002S015", DbType.Decimal, 0, 1, 0, 更新データ.取引明細(line).R002S015))
            query.Append("," & AddParamInfo(paramInfo, "HANR002S016", DbType.Decimal, 0, 1, 0, 更新データ.取引明細(line).R002S016))
        End If
        'A-20121217_Ver7.50_1↑
        'A-20141105_1↓
        If MyImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 6D Then
            query.Append("," & AddParamInfo(paramInfo, "HANR002S017", DbType.AnsiStringFixedLength, 6, 0, 0, 更新データ.取引明細(line).R002S017))
            query.Append("," & AddParamInfo(paramInfo, "HANR002S018", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002S018))
        End If
        'A-20141105_1↑
        'A-20160324_2↓
        If MyImportParam.Myコントロール情報.使用条件(Myコントロール情報Param.条件型.品目別原価計算機能, 8D) = True Then
            query.Append("," & AddParamInfo(paramInfo, "HANR002S020", DbType.Decimal, 0, 10, 0, 更新データ.取引明細(line).R002S020))
        End If
        'A-20160324_2↑

        ''↓A-2008/07/18_Ver7.30_GENKA
        'If MyImportParam.Myコントロール情報.Myオプション区分.原価管理 = オプション区分定義型.区分型.行う Then
        '    query.Append("," & AddParamInfo(paramInfo, "HANR002078", DbType.AnsiStringFixedLength, 20, 0, 0, 更新データ.仕入明細(line).R002078))
        '    query.Append("," & AddParamInfo(paramInfo, "HANR002079", DbType.AnsiStringFixedLength, 2, 0, 0, 更新データ.仕入明細(line).R002079))
        '    query.Append("," & AddParamInfo(paramInfo, "HANR002080", DbType.AnsiStringFixedLength, 8, 0, 0, 更新データ.仕入明細(line).R002080))
        'End If
        ''↑A-2008/07/18_Ver7.30_GENKA
        ''↓A-2009/12/18_Ver7.40_UCHIWAKE
        'If MyImportParam.Myコントロール情報.Myオプション区分.商品内訳管理 = True Then
        '    query.Append("," & AddParamInfo(paramInfo, "HANR002083", DbType.Decimal, 0, 19, 4, 更新データ.仕入明細(line).R002083))
        '    query.Append("," & AddParamInfo(paramInfo, "HANR002084", DbType.Decimal, 0, 1, 0, 更新データ.仕入明細(line).R002084))
        'End If
        ''↑A-2009/12/18_Ver7.40_UCHIWAKE
        ''↓A-2009/12/18_Ver7.40_LOT
        'If MyImportParam.Myコントロール情報.Myオプション区分.ロット管理 = True Then
        '    query.Append("," & AddParamInfo(paramInfo, "HANR002086", DbType.AnsiStringFixedLength, 20, 0, 0, 更新データ.仕入明細(line).R002086))
        'End If
        ''↑A-2009/12/18_Ver7.40_LOT
        query.Append(" )")

        Return query.ToString
    End Function

#End Region

#Region "■発注ヘッダー■"

    '存在チェック
    Public Function SelectHANR004PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal 発注番号 As Long
                    ) As String Implements IMyQueryMaker.SelectHANR004PrimaryKey    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(QueryWrapper.AddIndexHintOracle(GetIndexHint("SEL_B_1")))
        query.Append(" HANR004002 ")
        query.Append("FROM " & MyBase.ExchangeTableName("HAN10R004JUHACHUH") & " ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock(GetIndexHint("R004_B_1")))
        query.Append("WHERE HANR004004 = 1 ")
        query.Append("  AND HANR004005 = " & AddParamInfo(paramInfo, "HANR004005", DbType.Decimal, 0, 10, 0, 発注番号))

        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString

    End Function

    Public Function UpdateHANR004(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                  ByVal 更新データ As WorkTableUnitData) As String Implements IMyQueryMaker.UpdateHANR004    'X1変換Tool-20170508
        Dim query As New System.Text.StringBuilder

        query.Append(" UPDATE ")
        query.Append(Me.ExchangeTableName("HAN10R004JUHACHUH"))    'X1変換Tool-20170509

        query.Append(" SET ")
        query.Append(" HANR004038 = " & AddParamInfo(paramInfo, "HANR004038", DbType.Decimal, 0, 1, 0, 更新データ.受注ヘッダー.R004038))

        query.Append(" WHERE HANR004004 = " & AddParamInfo(paramInfo, "HANR004004", DbType.Decimal, 0, 1, 0, 更新データ.受注ヘッダー.R004004))
        query.Append("   AND HANR004005 = " & AddParamInfo(paramInfo, "HANR004005", DbType.Decimal, 0, 10, 0, 更新データ.受注ヘッダー.R004005))

        Return query.ToString
    End Function

#End Region

#Region "■発注明細■"

    '存在チェック
    Public Function SelectHANR005PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal 発注番号 As Long,
                                            ByVal 発注行番号 As Integer
                    ) As String Implements IMyQueryMaker.SelectHANR005PrimaryKey    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(QueryWrapper.AddIndexHintOracle(GetIndexHint("SEL_C_1")))
        '↓D-2008/07/18_Ver7.30_GENKA
        'query.Append(" HANR005017 ")
        'query.Append(",HANR005038 ")
        'query.Append(",HANR005052 ")
        '↑D-2008/07/18_Ver7.30_GENKA
        '↓A-2008/07/18_Ver7.30_GENKA
        query.Append(" MHCH.HANR005003 HANR005003 ")        '発注番号
        query.Append(",MHCH.HANR005004 HANR005004 ")        '発注行番号
        query.Append(",MHCH.HANR005008 HANR005008 ")        '納期
        query.Append(",MHCH.HANR005017 HANR005017 ")        '商品コード
        query.Append(",MHCH.HANR005019 HANR005019 ")        '数量単位
        query.Append(",MHCH.HANR005038 HANR005038 ")        '強制完納区分
        query.Append(",MHCH.HANR005050 HANR005050 ")        '
        query.Append(",MHCH.HANR005052 HANR005052 ")        '取引区分属性
        query.Append(",MHCH.HANR005058 HANR005058 ")        '内訳コード１   'A-2009/12/18_Ver7.40_UCHIWAKE
        query.Append(",MHCH.HANR005059 HANR005059 ")        '内訳コード２   'A-2009/12/18_Ver7.40_UCHIWAKE
        query.Append(",MHCH.HANR005060 HANR005060 ")        '内訳コード３   'A-2009/12/18_Ver7.40_UCHIWAKE
        query.Append(",MHCH.HANR005073 HANR005073 ")        '
        If MyImportParam.Myコントロール情報.Myオプション区分.原価管理 = オプション区分定義型.区分型.行う Then
            query.Append(",MHCH.HANR005086 HANR005086 ")    '原価集計コード
            query.Append(",MHCH.HANR005087 HANR005087 ")    '原価集計サブコード
            query.Append("," & QueryWrapper.AddIsNull & "(MJCH.HANR005003,0) HANR005003JCH ")   '受注番号
            query.Append("," & QueryWrapper.AddIsNull & "(MJCH.HANR005006,' ') HANR005006JCH ") '得意先コード
        End If
        '↑A-2008/07/18_Ver7.30_GENKA
        query.Append(",MHCH.HANR005A004 HANR005A004 ")       '製番
        query.Append(",MHCH.HANR005A019 HANR005A019 ")       '検査方法
        query.Append(",MHCH.HANR005A020 HANR005A020 ")       '発注区分
        query.Append(",MHCH.HANR005A021 HANR005A021 ")       '子部品引当部品
        query.Append(",MHCH.HANR005A022 HANR005A022 ")       '工程コード
        query.Append(",MHCH.HANR005A023 HANR005A023 ")       '発注数量(発注単位)    'A-20120315_3
        query.Append(",MHCH.HANR005A025 HANR005A025 ")       '発注単位変換係数
        query.Append(",MHCH.HANR005A026 HANR005A026 ")       '発注確定区分
        query.Append(",MHCH.HANR005A027 HANR005A027 ")       '手配番号
        query.Append(",MHCH.HANR005A028 HANR005A028 ")       '手配管理番号
        query.Append(",MHCH.HANR005A031 HANR005A031 ")       '受注形態              'A-20130304_3
        query.Append(",MHCH.HANR005A033 HANR005A033 ")       '個別発注連番
        query.Append(",MHCH.HANR005A034 HANR005A034 ")       '受入数量
        query.Append(",MHCH.HANR005A037 HANR005A037 ")       '費目区分
        'A-20160324_2↓
        If MyImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 8D Then
            query.Append(",MHCH.HANR005S027 HANR005S027 ")   '原価計上手配番号
        End If
        'A-20160324_2↑

        query.Append(",HHCH.HANR004002 HANR004002 ")         '取引先コード
        query.Append(",HHCH.HANR004003 HANR004003 ")         '受発注日付
        query.Append(",HHCH.HANR004013 HANR004013 ")         '倉庫コード            'A-20141105_2
        query.Append("," & QueryWrapper.AddIsNull & "(HHCH.HANR004035,' ') HANR004035 ")  '手入力得意先名１
        query.Append("," & QueryWrapper.AddIsNull & "(HHCH.HANR004036,' ') HANR004036 ")  '手入力得意先名２
        query.Append(",HHCH.HANR004A004 HANR004A004 ")       'プロジェクトメインコード
        query.Append(",HHCH.HANR004A005 HANR004A005 ")       'プロジェクトサブコード
        query.Append(",HHCH.HANR004A010 HANR004A010 ")       '発注区分
        query.Append(",HHCH.HANR004A012 HANR004A012 ")       '完成品区分

        'A-CUST20190830↓
        '【発注】
        '発注明細項目
        query.Append(",MHCH.HANR005007 HANR005007 ") '担当者コード(HANR005007)
        query.Append(",MHCH.HANR005009 HANR005009 ") '発注明細.取引区分(HANR005009)
        query.Append(",MHCH.HANR005016 HANR005016 ") '発注明細.倉庫コード(HANR005016)
        query.Append(",MHCH.HANR005018 HANR005018 ") '発注明細.商品（品目）名(HANR005018)
        query.Append(",MHCH.HANR005A001 HANR005A001 ") '発注明細.品目名１(HANR005A001)
        query.Append(",MHCH.HANR005A002 HANR005A002 ") '発注明細.品目名２(HANR005A002)
        query.Append(",MHCH.HANR005A003 HANR005A003 ") '発注明細.品目名３(HANR005A003)
        query.Append(",MHCH.HANR005024 HANR005024 ") '発注明細.受発注単価(HANR005024)
        query.Append(",MHCH.HANR005028 HANR005028 ") '発注明細.単価掛率(HANR005028)
        query.Append(",MHCH.HANR005035 HANR005035 ") '発注明細.課税区分(HANR005035)
        query.Append(",MHCH.HANR005036 HANR005036 ") '発注明細.消費税率(HANR005036)
        query.Append(",MHCH.HANR005042 HANR005042 ") '発注明細テーブル. 仕入/売上数量(HANR005042)
        query.Append(",MHCH.HANR005039 HANR005039 ") '発注明細.行摘要コード(HANR005039)
        query.Append(",MHCH.HANR005040 HANR005040 ") '発注明細.行摘要１(HANR005040)
        query.Append(",MHCH.HANR005041 HANR005041 ") '発注明細.行摘要２(HANR005041)
        query.Append(",MHCH.HANR005A030 HANR005A030 ") '発注明細.仮単価区分(HANR005A030)
        query.Append(",MHCH.HANR005025 HANR005025 ") '発注明細テーブル.受発注金額(HANR005025)
        query.Append(",MHCH.HANR005043 HANR005043 ") '発注明細テーブル.仕入/売上済金額(HANR005043)
        query.Append(",MHCH.HANR005013 HANR005013 ") '発注明細テーブル.受（発）注番号(HANR005013)
        query.Append(",MHCH.HANR005A020 HANR005A020 ") '発注明細テーブル.発注区分(HANR005A020)
        query.Append(",MHCH.HANR005023 HANR005023 ") '受発注明細テーブル.受発注数量(HANR005023)

        '発注ヘッダー項目
        query.Append(",HHCH.HANR004012 HANR004012 ") '部門コード(HANR004012)
        query.Append(",HHCH.HANR004018 HANR004018  ") '発注ヘッダー.売掛区分(HANR004018)
        query.Append(",HHCH.HANR004022 HANR004022  ") '発注ヘッダー.備考コード(HANR004022)
        query.Append(",HHCH.HANR004023 HANR004023  ") '発注ヘッダー.備  考(HANR004023)


        '発注内訳項目
        query.Append("," & QueryWrapper.AddIsNull & "(SEIRA01007,' ') SEIRA01007 ") '発注内訳テーブル.ロットＮｏ(SEIRA01007)
        query.Append("," & QueryWrapper.AddIsNull & "(SEIRA01009,0) SEIRA01009 ") '発注内訳テーブル.発注数量(SEIRA01009)
        query.Append("," & QueryWrapper.AddIsNull & "(SEIRA01011,0) SEIRA01011 ") '発注内訳テーブル.仕入済数量(SEIRA01011)

        '発注拡張項目

        '発注　品目マスター項目
        query.Append("," & QueryWrapper.AddIsNull & "(MHCH_M003.HANM003A033,0) MHCH_M003_HANM003A033 ") '商品（品目）マスター.有効期間(HANM003A033) 


        '【受注】
        '受注明細項目

        '受注ヘッダー項目

        '受注拡張項目
        'A-CUST20190830↑

        '手配テーブル
        query.Append("," & QueryWrapper.AddIsNull & "(SEIR055002,0) SEIR055002 ")
        query.Append("," & QueryWrapper.AddIsNull & "(SEIR055024,0) SEIR055024 ")

        '仕入先マスター
        query.Append("," & QueryWrapper.AddIsNull & "(HANM002004,' ') HANM002004 ")
        query.Append("," & QueryWrapper.AddIsNull & "(HANM002005,' ') HANM002005 ")
        'A-CUST20190830↓
        query.Append("," & QueryWrapper.AddIsNull & "(HANM002043,0) HANM002043 ")
        query.Append("," & QueryWrapper.AddIsNull & "(HANM002046,0) HANM002044 ")
        query.Append("," & QueryWrapper.AddIsNull & "(HANM002047,0) HANM002045 ")
        query.Append("," & QueryWrapper.AddIsNull & "(HANM002046,0) HANM002046 ")
        query.Append("," & QueryWrapper.AddIsNull & "(HANM002047,0) HANM002047 ")
        query.Append("," & QueryWrapper.AddIsNull & "(HANM002050,0) HANM002050 ")       '仕入先マスター.消費税通知区分(HANM002050)
        'A-CUST20190830↑

        'query.Append("FROM " & MyBase.ExchangeTableName("HAN10R005JUHACHUM") & " ")            'D-2008/07/18_Ver7.30_GENKA    'X1変換Tool-20170509
        query.Append("FROM " & MyBase.ExchangeTableName("HAN10R005JUHACHUM") & " MHCH ")        'A-2008/07/18_Ver7.30_GENKA    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock(GetIndexHint("R005_C_1")))

        query.Append(" LEFT OUTER JOIN ")
        query.Append(Me.ExchangeTableName("HAN10R004JUHACHUH ") & " HHCH " & QueryWrapper.AddNoLock(GetIndexHint("R004_C_1")))    'X1変換Tool-20170509
        query.Append("  ON HHCH.HANR004004 = MHCH.HANR005002 ")
        query.Append(" AND HHCH.HANR004005 = MHCH.HANR005003 ")

        '↓A-2008/07/18_Ver7.30_GENKA
        If MyImportParam.Myコントロール情報.Myオプション区分.原価管理 = オプション区分定義型.区分型.行う Then
            '受発注明細(受注)
            query.Append(" LEFT OUTER JOIN ")
            query.Append(Me.ExchangeTableName("HAN10R005JUHACHUM ") & " MJCH " & QueryWrapper.AddNoLock(GetIndexHint("R005_C_2")))    'X1変換Tool-20170509
            query.Append("  ON MJCH.HANR005002 = 2 ")
            query.Append(" AND MJCH.HANR005003 = MHCH.HANR005013 ")
            query.Append(" AND MJCH.HANR005004 = MHCH.HANR005014 ")
            query.Append(" AND MJCH.HANR005013 = MHCH.HANR005003 ")
            query.Append(" AND MJCH.HANR005014 = MHCH.HANR005004 ")
        End If
        '↑A-2008/07/18_Ver7.30_GENKA

        '手配テーブル
        query.Append(" LEFT OUTER JOIN ")
        query.Append(Me.ExchangeTableName("SEI10R055TEHAI ") & " SR055 " & QueryWrapper.AddNoLock(GetIndexHint("R055_C_1")))    'X1変換Tool-20170509
        query.Append("  ON SR055.SEIR055074 = MHCH.HANR005003 ")

        query.Append(" LEFT OUTER JOIN " & MyBase.ExchangeTableName("HAN10M002SHIIRE") & " ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())
        query.Append("   ON HANM002003 = HHCH.HANR004002 ")

        'A-CUST20190830↓
        '発注内訳テーブル(SEI98RA01HACHUUTIWAKE)
        query.Append(" LEFT OUTER JOIN ")
        query.Append(Me.ExchangeTableName("SEI98RA01HACHUUTIWAKE ") & " " & QueryWrapper.AddNoLock())
        query.Append("  ON SEIRA01001 = MHCH.HANR005003 ")
        query.Append(" AND SEIRA01002 = 1 ")
        query.Append(" AND SEIRA01003 = 1 ")

        '商品（品目）マスター(HAN10M003SHOHIN)
        query.Append(" LEFT OUTER JOIN " & MyBase.ExchangeTableName("HAN10M003SHOHIN") & " MHCH_M003 ")
        query.Append(MyBase.QueryWrapper.AddNoLock())
        query.Append("   ON MHCH_M003.HANM003001 = MHCH.HANR005017 ")
        'A-CUST20190830↑

        '↓D-2008/07/18_Ver7.30_GENKA
        'query.Append("WHERE HANR005002 = 1 ")
        'query.Append("  AND HANR005003 = " & AddParamInfo(paramInfo, "HANR005003", DbType.Decimal, 0, 10, 0, 発注番号))
        'query.Append("  AND HANR005004 = " & AddParamInfo(paramInfo, "HANR005004", DbType.Decimal, 0, 3, 0, 発注行番号))
        '↑D-2008/07/18_Ver7.30_GENKA
        '↓A-2008/07/18_Ver7.30_GENKA
        query.Append("WHERE MHCH.HANR005002 = 1 ")
        query.Append("  AND MHCH.HANR005003 = " & AddParamInfo(paramInfo, "HANR005003", DbType.Decimal, 0, 10, 0, 発注番号))
        query.Append("  AND MHCH.HANR005004 = " & AddParamInfo(paramInfo, "HANR005004", DbType.Decimal, 0, 3, 0, 発注行番号))
        '↑A-2008/07/18_Ver7.30_GENKA

        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString

    End Function

    '存在チェック
    Public Function SelectHANR005関連受注(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                          ByVal 受注番号 As Long,
                                          ByVal 受注行番号 As Integer
                    ) As String Implements IMyQueryMaker.SelectHANR005関連受注    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")

        query.Append(" HHCH.HANR004002 HANR004002 ")
        query.Append(",HHCH.HANR004003 HANR004003 ")
        query.Append("," & QueryWrapper.AddIsNull & "(HHCH.HANR004035,' ') HANR004035 ")
        query.Append("," & QueryWrapper.AddIsNull & "(HHCH.HANR004036,' ') HANR004036 ")

        query.Append(",MHCH.HANR005001 HANR005001 ")
        query.Append(",MHCH.HANR005003 HANR005003 ")
        query.Append(",MHCH.HANR005004 HANR005004 ")
        query.Append(",MHCH.HANR005008 HANR005008 ")
        query.Append(",MHCH.HANR005017 HANR005017 ")

        query.Append("," & QueryWrapper.AddIsNull & "(MHCH.HANR005A001,' ') HANR005A001 ")
        query.Append("," & QueryWrapper.AddIsNull & "(MHCH.HANR005A002,' ') HANR005A002 ")
        query.Append("," & QueryWrapper.AddIsNull & "(MHCH.HANR005A003,' ') HANR005A003 ")
        query.Append(",MHCH.HANR005A011 HANR005A011 ")

        query.Append("," & QueryWrapper.AddIsNull & "(HANM001004,' ') HANM001004 ")
        query.Append("," & QueryWrapper.AddIsNull & "(HANM001005,' ') HANM001005 ")

        query.Append("FROM " & MyBase.ExchangeTableName("HAN10R005JUHACHUM") & " MHCH ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())

        query.Append(" LEFT OUTER JOIN ")
        query.Append(Me.ExchangeTableName("HAN10R004JUHACHUH ") & " HHCH " & QueryWrapper.AddNoLock())    'X1変換Tool-20170509
        query.Append("  ON HHCH.HANR004004 = MHCH.HANR005002 ")
        query.Append(" AND HHCH.HANR004005 = MHCH.HANR005003 ")

        query.Append(" LEFT OUTER JOIN " & MyBase.ExchangeTableName("HAN10M001TOKUI") & " ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())
        query.Append("   ON HANM001003 = HHCH.HANR004002 ")

        query.Append("WHERE MHCH.HANR005002 = 2 ")
        query.Append("  AND MHCH.HANR005003 = " & AddParamInfo(paramInfo, "HANR005003", DbType.Decimal, 0, 10, 0, 受注番号))
        query.Append("  AND MHCH.HANR005004 = " & AddParamInfo(paramInfo, "HANR005004", DbType.Decimal, 0, 3, 0, 受注行番号))

        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString

    End Function

    '存在チェック
    Public Function SelectHANR005見込受注(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                          ByVal 発注番号 As Long
                    ) As String Implements IMyQueryMaker.SelectHANR005見込受注    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")

        query.Append(" SEIM050019 ")
        query.Append(",SEIM050020 ")

        query.Append("," & QueryWrapper.AddIsNull & "(HANR004004,0) HANR004004 ")
        query.Append("," & QueryWrapper.AddIsNull & "(HANR004005,0) HANR004005 ")
        query.Append(",HANR004038 ")

        query.Append("," & QueryWrapper.AddIsNull & "(HANR005002,0) HANR005002 ")
        query.Append("," & QueryWrapper.AddIsNull & "(HANR005003,0) HANR005003 ")
        query.Append("," & QueryWrapper.AddIsNull & "(HANR005004,0) HANR005004 ")
        query.Append("," & QueryWrapper.AddIsNull & "(HANR005008,0) HANR005008 ")
        query.Append(",HANR005023 ")
        query.Append(",HANR005038 ")
        query.Append(",HANR005042 ")
        query.Append(",HANR005047 ")
        query.Append(",HANR005048 ")
        query.Append(",HANR005050 ")

        query.Append("FROM " & MyBase.ExchangeTableName("SEI10M050SEIMST") & " ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())

        query.Append(" LEFT OUTER JOIN ")
        query.Append(Me.ExchangeTableName("HAN10R004JUHACHUH ") & " " & QueryWrapper.AddNoLock())    'X1変換Tool-20170509
        query.Append("  ON HANR004004 = 2 ")
        query.Append(" AND HANR004005 = SEIM050019 ")

        query.Append(" LEFT OUTER JOIN ")
        query.Append(Me.ExchangeTableName("HAN10R005JUHACHUM ") & " " & QueryWrapper.AddNoLock())    'X1変換Tool-20170509
        query.Append("  ON HANR005002 = 2 ")
        query.Append(" AND HANR005003 = SEIM050019 ")

        query.Append(" WHERE SEIM050011 = " & AddParamInfo(paramInfo, "SEIM050011", DbType.Decimal, 0, 10, 0, 発注番号))
        query.Append("   AND SEIM050015 = 2 ")
        query.Append("   AND SEIM050022 = 2 ")
        'A-20170417_1↓
        If MyImportParam.Myコントロール情報.MyMOA機能追加.見込受注得意先以外の出庫予定制御 = MOA機能追加定義型.その他管理区分型.行う AndAlso
           MyImportParam.Myコントロール情報.MyMOA機能追加.生産計画機能 = MOA機能追加定義型.使用有無区分型.使用しない Then
            query.Append("   AND HANR004002 = " & AddParamInfo(paramInfo, "HANR004002", DbType.StringFixedLength, 11, 0, 0, MyImportParam.Myコントロール情報.MyMOAその他.見込受注用得意先コード))
        End If
        'A-20170417_1↑

        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString
    End Function

    '原価集計制御用受発注情報取得
    Public Function SelectHANR005原価集計制御情報(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                                  ByVal 発注番号 As Long,
                                                  ByVal 発注行番号 As Integer
                    ) As String Implements IMyQueryMaker.SelectHANR005原価集計制御情報     'A-2008/07/18_Ver7.30_GENKA    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(QueryWrapper.AddIndexHintOracle(GetIndexHint("SEL_D_1")))

        '--------------------
        '   取得項目定義
        '--------------------
        '発注明細
        query.Append(" HCHR05.HANR005003 HCHR05_HANR005003 ")               '発注番号
        query.Append(",HCHR05.HANR005004 HCHR05_HANR005004 ")               '行番号
        If MyImportParam.Myコントロール情報.My原価管理.明細単位原価集計入力_仕入 = 原価管理定義型.明細単位原価集計入力型.行う Then
            query.Append(",HCHR05.HANR005049 HCHR05_HANR005KANREN ")        '関連仕入伝票行数
        Else
            query.Append(",HCHR05MAX.HANR005049 HCHR05_HANR005KANREN ")     '関連仕入伝票行数の最大値
        End If

        '受注明細
        query.Append("," & QueryWrapper.AddIsNull & "(JCHR05.HANR005003,0) JCHR05_HANR005003 ")                 '受注番号
        query.Append("," & QueryWrapper.AddIsNull & "(JCHR05.HANR005004,0) JCHR05_HANR005004 ")                 '行番号
        query.Append("," & QueryWrapper.AddIsNull & "(JCHR05.HANR005013,0) JCHR05_HANR005013 ")                 '相手発注番号
        query.Append("," & QueryWrapper.AddIsNull & "(JCHR05.HANR005014,0) JCHR05_HANR005014 ")                 '相手行番号
        If MyImportParam.Myコントロール情報.My原価管理.明細単位原価集計入力_売上 = 原価管理定義型.明細単位原価集計入力型.行う Then
            query.Append("," & QueryWrapper.AddIsNull & "(JCHR05.HANR005049,0) JCHR05_HANR005KANREN ")          '関連売上伝票行数
            query.Append("," & QueryWrapper.AddIsNull & "(JCHR05.HANR005055,0) JCHR05_HANR005PICKING ")         'ピッキング抽出区分
        Else
            query.Append("," & QueryWrapper.AddIsNull & "(JCHR05MAX.HANR005049,0) JCHR05_HANR005KANREN ")       '関連売上伝票行数の最大値
            query.Append("," & QueryWrapper.AddIsNull & "(JCHR05MAX.HANR005055,0) JCHR05_HANR005PICKING ")      'ピッキング抽出区分の最大値
        End If

        '発注明細(同時の別発注)
        query.Append("," & QueryWrapper.AddIsNull & "(HCHR05OTHER.HANR005003,0) HCHR05OTHER_HANR005003 ")       '発注番号
        query.Append("," & QueryWrapper.AddIsNull & "(HCHR05OTHER.HANR005004,0) HCHR05OTHER_HANR005004 ")       '行番号
        query.Append("," & QueryWrapper.AddIsNull & "(HCHR05OTHER.HANR005049,0) HCHR05OTHER_HANR005KANREN ")    '関連仕入伝票行数

        '--------------------
        '   テーブル定義
        '--------------------
        '発注明細
        query.Append(" FROM ")
        query.Append(Me.ExchangeTableName("HAN10R005JUHACHUM ") & " HCHR05 " & QueryWrapper.AddNoLock(GetIndexHint("R005_D_1")))    'X1変換Tool-20170509

        '↓A-2009/08/18_1
        '受注明細(同時明細の受注番号取得用)
        query.Append(" LEFT OUTER JOIN ")
        query.Append(Me.ExchangeTableName("HAN10R005JUHACHUM ") & " JCHR05SUB " & QueryWrapper.AddNoLock(GetIndexHint("R005_D_3")))    'X1変換Tool-20170509
        query.Append("  ON JCHR05SUB.HANR005002 = 2 ")
        query.Append(" AND JCHR05SUB.HANR005003 = HCHR05.HANR005013 ")
        query.Append(" AND JCHR05SUB.HANR005004 = HCHR05.HANR005014 ")
        query.Append(" AND JCHR05SUB.HANR005013 = HCHR05.HANR005003 ")
        query.Append(" AND JCHR05SUB.HANR005014 = HCHR05.HANR005004 ")
        '↑A-2009/08/18_1

        '受注明細
        query.Append(" LEFT OUTER JOIN ")
        query.Append(Me.ExchangeTableName("HAN10R005JUHACHUM ") & " JCHR05 " & QueryWrapper.AddNoLock(GetIndexHint("R005_D_2")))    'X1変換Tool-20170509
        query.Append("  ON JCHR05.HANR005002 = 2 ")
        query.Append(" AND JCHR05.HANR005003 = JCHR05SUB.HANR005003 ")  'A-2009/08/18_1
        '↓D-2009/08/18_1
        'query.Append(" AND JCHR05.HANR005003 = ")
        'query.Append(" (SELECT ")
        'query.Append(QueryWrapper.AddIndexHintOracle(GetIndexHint("SEL_D_2")))
        'query.Append("  HANR005003 ")
        'query.Append("  FROM ")
        'query.Append(Me.ExchangeTableName("HAN10R005JUHACHUM ") & " JCHR05SUB " & QueryWrapper.AddNoLock(GetIndexHint("R005_D_3")))    'X1変換Tool-20170509
        'query.Append("  WHERE JCHR05SUB.HANR005002 = 2 ")
        'query.Append("    AND JCHR05SUB.HANR005003 = HCHR05.HANR005013 ")
        'query.Append("    AND JCHR05SUB.HANR005004 = HCHR05.HANR005014 ")
        'query.Append("    AND JCHR05SUB.HANR005013 = HCHR05.HANR005003 ")
        'query.Append("    AND JCHR05SUB.HANR005014 = HCHR05.HANR005004 ")
        'query.Append("  GROUP BY JCHR05SUB.HANR005003 ) ")
        '↑D-2009/08/18_1

        '発注明細(同時の別発注)
        query.Append(" LEFT OUTER JOIN ")
        query.Append(Me.ExchangeTableName("HAN10R005JUHACHUM ") & " HCHR05OTHER " & QueryWrapper.AddNoLock(GetIndexHint("R005_D_4")))    'X1変換Tool-20170509
        query.Append("  ON HCHR05OTHER.HANR005002 = 1 ")
        query.Append(" AND HCHR05OTHER.HANR005003 = JCHR05.HANR005013 ")
        query.Append(" AND HCHR05OTHER.HANR005004 = JCHR05.HANR005014 ")
        query.Append(" AND HCHR05OTHER.HANR005013 = JCHR05.HANR005003 ")
        query.Append(" AND HCHR05OTHER.HANR005014 = JCHR05.HANR005004 ")

        '発注明細（最大値取得）
        If MyImportParam.Myコントロール情報.My原価管理.明細単位原価集計入力_仕入 = 原価管理定義型.明細単位原価集計入力型.行う Then
        Else
            query.Append(" LEFT OUTER JOIN (SELECT ")
            query.Append(QueryWrapper.AddIndexHintOracle(GetIndexHint("SEL_D_3")))
            query.Append(" HANR005002 ")
            query.Append(",HANR005003 ")
            query.Append(",MAX(HANR005049) HANR005049 ")        '関連仕入伝票行数
            query.Append(" FROM ")
            query.Append(Me.ExchangeTableName("HAN10R005JUHACHUM ") & QueryWrapper.AddNoLock(GetIndexHint("R005_D_5")))    'X1変換Tool-20170509
            query.Append(" GROUP BY HANR005002,HANR005003) HCHR05MAX ")
            query.Append("  ON HCHR05MAX.HANR005002 = HCHR05.HANR005002 ")
            query.Append(" AND HCHR05MAX.HANR005003 = HCHR05.HANR005003 ")
        End If

        '受注明細（最大値取得）
        If MyImportParam.Myコントロール情報.My原価管理.明細単位原価集計入力_売上 = 原価管理定義型.明細単位原価集計入力型.行う Then
        Else
            query.Append(" LEFT OUTER JOIN (SELECT ")
            query.Append(QueryWrapper.AddIndexHintOracle(GetIndexHint("SEL_D_4")))
            query.Append(" HANR005002")
            query.Append(",HANR005003")
            query.Append(",MAX(HANR005049) HANR005049 ")        '関連売上伝票行数
            query.Append(",MAX(HANR005055) HANR005055 ")        'ピッキング抽出区分
            query.Append(" FROM ")
            query.Append(Me.ExchangeTableName("HAN10R005JUHACHUM ") & QueryWrapper.AddNoLock(GetIndexHint("R005_D_6")))    'X1変換Tool-20170509
            query.Append(" GROUP BY HANR005002,HANR005003) JCHR05MAX ")
            query.Append("  ON JCHR05MAX.HANR005002 = 2 ")
            query.Append(" AND JCHR05MAX.HANR005003 = JCHR05.HANR005003 ")
        End If

        '--------------------
        '   検索条件
        '--------------------
        query.Append(" WHERE ")
        query.Append("     HCHR05.HANR005002 = 1 ")
        query.Append(" AND HCHR05.HANR005003 = " & AddParamInfo(paramInfo, "HANR005003", DbType.Decimal, 0, 10, 0, 発注番号))
        query.Append(" AND HCHR05.HANR005004 = " & AddParamInfo(paramInfo, "HANR005004", DbType.Decimal, 0, 3, 0, 発注行番号))

        query.Append(" ORDER BY ")
        query.Append(" HCHR05.HANR005002 ")
        query.Append(",HCHR05.HANR005003 ")
        query.Append(",HCHR05.HANR005004 ")

        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString

    End Function

    'A-20121217_Ver7.50_2↓
    Public Function SelectHANR005元需要受注伝票(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                                ByVal 製番 As String,
                                                ByVal 品目 As String
                    ) As String Implements IMyQueryMaker.SelectHANR005元需要受注伝票    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(QueryWrapper.AddIndexHintOracle(GetIndexHint("SEL_Q_1")))
        query.Append(" HANR005003 ")
        'query.Append(",HANR005003 ")               'D-20130613_1
        query.Append(",HANR005004 ")                'A-20130613_1

        query.Append(" FROM ")
        query.Append(Me.ExchangeTableName("HAN10R005JUHACHUM ") & QueryWrapper.AddNoLock)    'X1変換Tool-20170509

        query.Append(" WHERE ")
        query.Append("     " & "HANR005002 = 2 ")
        query.Append(" AND " & "HANR005017 = " & AddParamInfo(paramInfo, "HANR005017", DbType.AnsiStringFixedLength, 25, 0, 0, 品目))
        query.Append(" AND " & "HANR005A004 = " & AddParamInfo(paramInfo, "HANR005A004", DbType.AnsiStringFixedLength, 12, 0, 0, 製番))

        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString
    End Function
    'A-20121217_Ver7.50_2↑

    Public Function UpdateHANR005(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                  ByVal 更新データ As WorkTableUnitData,
                                  ByVal line As Integer) As String Implements IMyQueryMaker.UpdateHANR005    'X1変換Tool-20170508
        Dim query As New System.Text.StringBuilder

        query.Append(" UPDATE ")
        query.Append(Me.ExchangeTableName("HAN10R005JUHACHUM"))    'X1変換Tool-20170509

        query.Append(" SET ")
        query.Append(" HANR005038 = " & AddParamInfo(paramInfo, "HANR005038", DbType.Decimal, 0, 1, 0, 更新データ.受注明細(line).R005038))
        query.Append(",HANR005042 = " & AddParamInfo(paramInfo, "HANR005042", DbType.Decimal, 0, 19, 4, 更新データ.受注明細(line).R005042))
        query.Append(",HANR005047 = " & AddParamInfo(paramInfo, "HANR005047", DbType.Decimal, 0, 4, 0, 更新データ.受注明細(line).R005047))
        query.Append(",HANR005048 = " & AddParamInfo(paramInfo, "HANR005048", DbType.Decimal, 0, 8, 0, 更新データ.受注明細(line).R005048))
        query.Append(",HANR005050 = " & AddParamInfo(paramInfo, "HANR005050", DbType.Decimal, 0, 1, 0, 更新データ.受注明細(line).R005050))

        query.Append(" WHERE HANR005002 = " & AddParamInfo(paramInfo, "HANR005002", DbType.Decimal, 0, 1, 0, 更新データ.受注明細(line).R005002))
        query.Append("   AND HANR005003 = " & AddParamInfo(paramInfo, "HANR004003", DbType.Decimal, 0, 10, 0, 更新データ.受注明細(line).R005003))
        query.Append("   AND HANR005004 = " & AddParamInfo(paramInfo, "HANR004004", DbType.Decimal, 0, 3, 0, 更新データ.受注明細(line).R005004))

        Return query.ToString
    End Function

#End Region

#Region "■支払予定テーブル■"      'A-2008/07/18_Ver7.30_SHIHARAI

    '存在チェック
    Public Function SelectHANR031PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal 伝票処理連番 As Long
                    ) As String Implements IMyQueryMaker.SelectHANR031PrimaryKey    'A-2008/07/18_Ver7.30_SHIHARAI    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append(" SELECT ")
        query.Append(QueryWrapper.AddIndexHintOracle(GetIndexHint("SEL_E_1")))
        query.Append(" HANR031001 ")
        query.Append(",HANR031002 ")
        query.Append(",HANR031003 ")
        query.Append(",HANR031005 ")
        query.Append(",HANR031006 ")
        query.Append(",HANR031007 ")
        query.Append(",HANR031008 ")
        query.Append(",HANR031009 ")
        query.Append(",HANR031010 ")
        query.Append(",HANR031014 ")
        query.Append(",HANR031016 ")
        query.Append(",HANR031017 ")
        query.Append(",HANR031019 ")
        query.Append(",HANR031020 ")
        query.Append(",HANR031021 ")
        query.Append(",HANR031999 ")
        query.Append(" FROM " & MyBase.ExchangeTableName("HAN10R031SHIHARAIY") & " ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock(GetIndexHint("R031_E_1")))
        query.Append(" WHERE HANR031001 = 2 ")       '回収支払管理区分：2固定
        query.Append("   AND HANR031011 = 0 ")       'データ区分：0(通常支払)
        query.Append("   AND HANR031003 = " & AddParamInfo(paramInfo, "HANR031003", DbType.Decimal, 0, 10, 0, 伝票処理連番))

        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString

    End Function

    Public Function InsertHANR031(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                  ByVal 更新データ As WorkTableUnitData,
                                  ByVal line As Integer) As String Implements IMyQueryMaker.InsertHANR031   'A-2008/07/18_Ver7.30_SHIHARAI    'X1変換Tool-20170508
        Dim query As New System.Text.StringBuilder

        query.Append(" INSERT INTO ")
        query.Append(Me.ExchangeTableName("HAN10R031SHIHARAIY"))    'X1変換Tool-20170509

        query.Append(" (")
        query.Append(" HANR031001")
        query.Append(",HANR031002")
        query.Append(",HANR031003")
        query.Append(",HANR031004")
        query.Append(",HANR031005")
        query.Append(",HANR031006")
        query.Append(",HANR031007")
        query.Append(",HANR031008")
        query.Append(",HANR031009")
        query.Append(",HANR031010")
        query.Append(",HANR031011")
        query.Append(",HANR031012")
        query.Append(",HANR031013")
        query.Append(",HANR031014")
        query.Append(",HANR031015")
        query.Append(",HANR031016")
        query.Append(",HANR031017")
        query.Append(",HANR031018")
        query.Append(",HANR031019")
        query.Append(",HANR031020")
        query.Append(",HANR031021")
        If _myImportParam.Myコントロール情報.Myオプション区分.原価管理 = オプション区分定義型.区分型.行う Then
            query.Append(",HANR031022")
            query.Append(",HANR031023")
        End If
        'A-20160324_1↓
        If MyImportParam.Myコントロール情報.使用条件(Myコントロール情報Param.条件型.外貨管理, 8D) = True Then
            query.Append(",HANR031024")
            query.Append(",HANR031025")
            query.Append(",HANR031026")
            query.Append(",HANR031027")
            query.Append(",HANR031028")
            query.Append(",HANR031029")
        End If
        'A-20160324_1↑
        'A-20121217_Ver7.50_1↓
        If MyImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 4.0 Then
            query.Append(",HANR031S001")
            query.Append(",HANR031S002")
            query.Append(",HANR031S003")
            query.Append(",HANR031S004")
        End If
        'A-20121217_Ver7.50_1↑
        query.Append(" )")

        query.Append(" VALUES (")
        query.Append(" " & AddParamInfo(paramInfo, "HANR031001", DbType.Decimal, 0, 1, 0, 更新データ.支払予定(line).R031001))
        query.Append("," & AddParamInfo(paramInfo, "HANR031002", DbType.Decimal, 0, 8, 0, 更新データ.支払予定(line).R031002))
        query.Append("," & AddParamInfo(paramInfo, "HANR031003", DbType.Decimal, 0, 10, 0, 更新データ.支払予定(line).R031003))
        query.Append("," & AddParamInfo(paramInfo, "HANR031004", DbType.Decimal, 0, 8, 0, 更新データ.支払予定(line).R031004))
        query.Append("," & AddParamInfo(paramInfo, "HANR031005", DbType.Decimal, 0, 1, 0, 更新データ.支払予定(line).R031005))
        query.Append("," & AddParamInfo(paramInfo, "HANR031006", DbType.Decimal, 0, 3, 0, 更新データ.支払予定(line).R031006))
        query.Append("," & AddParamInfo(paramInfo, "HANR031007", DbType.AnsiStringFixedLength, 11, 0, 0, 更新データ.支払予定(line).R031007))
        query.Append("," & AddParamInfo(paramInfo, "HANR031008", DbType.Decimal, 0, 8, 0, 更新データ.支払予定(line).R031008))
        query.Append("," & AddParamInfo(paramInfo, "HANR031009", DbType.Decimal, 0, 8, 0, 更新データ.支払予定(line).R031009))
        query.Append("," & AddParamInfo(paramInfo, "HANR031010", DbType.Decimal, 0, 8, 0, 更新データ.支払予定(line).R031010))
        query.Append("," & AddParamInfo(paramInfo, "HANR031011", DbType.Decimal, 0, 1, 0, 更新データ.支払予定(line).R031011))
        query.Append("," & AddParamInfo(paramInfo, "HANR031012", DbType.Decimal, 0, 19, 4, 更新データ.支払予定(line).R031012))
        query.Append("," & AddParamInfo(paramInfo, "HANR031013", DbType.Decimal, 0, 19, 4, 更新データ.支払予定(line).R031013))
        query.Append("," & AddParamInfo(paramInfo, "HANR031014", DbType.Decimal, 0, 19, 4, 更新データ.支払予定(line).R031014))
        query.Append("," & AddParamInfo(paramInfo, "HANR031015", DbType.AnsiStringFixedLength, 8, 0, 0, 更新データ.支払予定(line).R031015))
        query.Append("," & AddParamInfo(paramInfo, "HANR031016", DbType.Decimal, 0, 1, 0, 更新データ.支払予定(line).R031016))
        query.Append("," & AddParamInfo(paramInfo, "HANR031017", DbType.Decimal, 0, 1, 0, 更新データ.支払予定(line).R031017))
        query.Append("," & AddParamInfo(paramInfo, "HANR031018", DbType.Decimal, 0, 1, 0, 更新データ.支払予定(line).R031018))
        query.Append("," & AddParamInfo(paramInfo, "HANR031019", DbType.AnsiStringFixedLength, 8, 0, 0, 更新データ.支払予定(line).R031019))
        query.Append("," & AddParamInfo(paramInfo, "HANR031020", DbType.AnsiStringFixedLength, 6, 0, 0, 更新データ.支払予定(line).R031020))
        query.Append("," & AddParamInfo(paramInfo, "HANR031021", DbType.Decimal, 0, 4, 0, 更新データ.支払予定(line).R031021))
        If _myImportParam.Myコントロール情報.Myオプション区分.原価管理 = オプション区分定義型.区分型.行う Then
            query.Append("," & AddParamInfo(paramInfo, "HANR031022", DbType.AnsiStringFixedLength, 20, 0, 0, 更新データ.支払予定(line).R031022))
            query.Append("," & AddParamInfo(paramInfo, "HANR031023", DbType.AnsiStringFixedLength, 2, 0, 0, 更新データ.支払予定(line).R031023))
        End If
        'A-20160324_1↓
        If MyImportParam.Myコントロール情報.使用条件(Myコントロール情報Param.条件型.外貨管理, 8D) = True Then
            query.Append("," & AddParamInfo(paramInfo, "HANR031024", DbType.Decimal, 0, 19, 4, 更新データ.支払予定(line).R031024))
            query.Append("," & AddParamInfo(paramInfo, "HANR031025", DbType.Decimal, 0, 19, 4, 更新データ.支払予定(line).R031025))
            query.Append("," & AddParamInfo(paramInfo, "HANR031026", DbType.Decimal, 0, 19, 4, 更新データ.支払予定(line).R031026))
            query.Append("," & AddParamInfo(paramInfo, "HANR031027", DbType.Decimal, 0, 1, 0, 更新データ.支払予定(line).R031027))
            query.Append("," & AddParamInfo(paramInfo, "HANR031028", DbType.Decimal, 0, 9, 4, 更新データ.支払予定(line).R031028))
            query.Append("," & AddParamInfo(paramInfo, "HANR031029", DbType.Decimal, 0, 1, 0, 更新データ.支払予定(line).R031029))
        End If
        'A-20160324_1↑
        'A-20121217_Ver7.50_1↓
        If MyImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 4.0 Then
            query.Append("," & AddParamInfo(paramInfo, "HANR031S001", DbType.AnsiStringFixedLength, 3, 0, 0, 更新データ.支払予定(line).R031S001))
            query.Append("," & AddParamInfo(paramInfo, "HANR031S002", DbType.Decimal, 0, 19, 4, 更新データ.支払予定(line).R031S002))
            query.Append("," & AddParamInfo(paramInfo, "HANR031S003", DbType.Decimal, 0, 19, 4, 更新データ.支払予定(line).R031S003))
            query.Append("," & AddParamInfo(paramInfo, "HANR031S004", DbType.Decimal, 0, 9, 4, 更新データ.支払予定(line).R031S004))
        End If
        'A-20121217_Ver7.50_1↑
        query.Append(" )")

        Return query.ToString
    End Function

    Public Function DeleteHANR031(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                  ByVal 伝票処理連番 As Long
                    ) As String Implements IMyQueryMaker.DeleteHANR031  'A-2008/07/18_Ver7.30_SHIHARAI    'X1変換Tool-20170508
        Dim query As New System.Text.StringBuilder

        query.Append(" DELETE ")
        query.Append(" FROM " & MyBase.ExchangeTableName("HAN10R031SHIHARAIY") & " ")    'X1変換Tool-20170509
        query.Append(" WHERE HANR031001 = 2 ")
        query.Append("   AND HANR031011 = 0 ")       'データ区分：0(通常請求)
        query.Append("   AND HANR031003 = " & AddParamInfo(paramInfo, "HANR031003", DbType.Decimal, 0, 10, 0, 伝票処理連番) & " ")

        Return query.ToString
    End Function

#End Region

#Region "■支払内訳テーブル■"      'A-2008/07/18_Ver7.30_SHIHARAI

    '存在チェック
    Public Function SelectHANR032PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal 支払予定データ As ProgramLib.支払予定テーブル型
                    ) As String Implements IMyQueryMaker.SelectHANR032PrimaryKey    'A-2008/07/18_Ver7.30_SHIHARAI    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append(" SELECT ")
        query.Append(QueryWrapper.AddIndexHintOracle(GetIndexHint("SEL_F_1")))
        query.Append(" HANR032001 ")
        query.Append(" FROM " & MyBase.ExchangeTableName("HAN10R032SHIHARAIU") & " ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock(GetIndexHint("R032_F_1")))
        query.Append(" WHERE HANR032001 = 2 ")       '回収支払管理区分：2固定
        query.Append("   AND HANR032002 = " & AddParamInfo(paramInfo, "HANR032002", DbType.Decimal, 0, 8, 0, 支払予定データ.R031002))
        query.Append("   AND HANR032003 = " & AddParamInfo(paramInfo, "HANR032003", DbType.Decimal, 0, 10, 0, 支払予定データ.R031003))
        query.Append("   AND HANR032004 = " & AddParamInfo(paramInfo, "HANR032004", DbType.Decimal, 0, 1, 0, 支払予定データ.R031005))
        query.Append("   AND HANR032005 = " & AddParamInfo(paramInfo, "HANR032005", DbType.Decimal, 0, 3, 0, 支払予定データ.R031006))
        query.Append("   AND HANR032006 = " & AddParamInfo(paramInfo, "HANR032006", DbType.AnsiStringFixedLength, 11, 0, 0, 支払予定データ.R031007))
        query.Append("   AND HANR032007 = " & AddParamInfo(paramInfo, "HANR032007", DbType.Decimal, 0, 8, 0, 支払予定データ.R031008))
        query.Append("   AND HANR032008 = " & AddParamInfo(paramInfo, "HANR032008", DbType.Decimal, 0, 8, 0, 支払予定データ.R031009))
        query.Append("   AND HANR032009 = " & AddParamInfo(paramInfo, "HANR032009", DbType.Decimal, 0, 8, 0, 支払予定データ.R031010))

        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString

    End Function

#End Region

#Region "■仕入先月別実績テーブル■"

    '存在チェック
    Public Function SelectHANS002PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal 仕入先コード As String,
                                            ByVal 対象年月 As Integer
                    ) As String Implements IMyQueryMaker.SelectHANS002PrimaryKey    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(" HANS002004 ")
        query.Append(",HANS002005 ")
        query.Append(",HANS002006 ")
        query.Append(",HANS002007 ")
        query.Append(",HANS002008 ")
        query.Append(",HANS002009 ")
        query.Append(",HANS002010 ")
        query.Append("FROM " & MyBase.ExchangeTableName("HAN10S002SHIIRETJ") & " ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())
        query.Append("WHERE HANS002001 = " & AddParamInfo(paramInfo, "HANS002001", DbType.StringFixedLength, 11, 0, 0, 仕入先コード))
        query.Append("  AND HANS002002 = " & AddParamInfo(paramInfo, "HANS002002", DbType.Decimal, 0, 6, 0, 対象年月))
        query.Append("  AND HANS002003 = 1 ")

        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString

    End Function

    'A-20121217_Ver7.50_1↓
    '存在チェック
    Public Function SelectSEIS005PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal 仕入先コード As String,
                                            ByVal 対象年月 As Integer
                    ) As String Implements IMyQueryMaker.SelectSEIS005PrimaryKey    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(" SEIS005004 ")
        query.Append(",SEIS005005 ")
        query.Append(",SEIS005006 ")
        query.Append(",SEIS005007 ")
        query.Append(",SEIS005008 ")
        query.Append(",SEIS005009 ")
        query.Append(",SEIS005010 ")
        query.Append("FROM " & MyBase.ExchangeTableName("SEI10S005SHIIRETJ") & " ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())
        query.Append("WHERE SEIS005001 = " & AddParamInfo(paramInfo, "SEIS005001", DbType.StringFixedLength, 11, 0, 0, 仕入先コード))
        query.Append("  AND SEIS005002 = " & AddParamInfo(paramInfo, "SEIS005002", DbType.Decimal, 0, 6, 0, 対象年月))
        query.Append("  AND SEIS005003 = 1 ")

        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString

    End Function
    'A-20121217_Ver7.50_1↑

#End Region

#Region "■拡張項目入力設定テーブル■"

    '存在チェック
    Public Function SelectHANZ034PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal 明細区分 As Integer,
                                            ByVal 入力パターン番号 As String
                    ) As String Implements IMyQueryMaker.SelectHANZ034PrimaryKey    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(" HANZ034001 ")
        query.Append("FROM " & MyBase.ExchangeTableName("HAN10Z034NYURYOKUSET") & " ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())
        query.Append("WHERE HANZ034001 = 2 ")    'データ種類：2(仕入)
        query.Append("  AND HANZ034002 = " & AddParamInfo(paramInfo, "HANZ034002", DbType.Decimal, 0, 1, 0, 明細区分))
        query.Append("  AND HANZ034003 = " & AddParamInfo(paramInfo, "HANZ034003", DbType.Decimal, 0, 4, 0, 入力パターン番号))

        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString

    End Function

#End Region

#Region "■テキスト取込ワーク■"

    '任意項目チェック
    Public Function SelectHANW091任意項目(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                          ByVal 分割コード As String,
                                          ByVal 任意項目１ As String
                    ) As String Implements IMyQueryMaker.SelectHANW091任意項目    'X1変換Tool-20170508
        Dim query As String = ""

        query &= "SELECT "
        query &= _W091ColID.任意項目１ & " "
        query &= "FROM " & MyBase.ExchangeTableName(テキストファイル取込ワークテーブルID(分割コード)) & " "
        query &= MyBase.QueryWrapper.AddNoLock()
        query &= "WHERE "
        query &= _W091ColID.更新済区分 & " = 1 "
        'query &= "AND " & _W091ColID.任意項目１ & " = " & AddParamInfo(paramInfo, "任意項目１", DbType.String, 64, 0, 0, 任意項目１)                   'D-2007/10/29
        query &= "AND " & _W091ColID.任意項目１ & " = " & AddParamInfo(paramInfo, "任意項目１", DbType.AnsiStringFixedLength, 64, 0, 0, 任意項目１)     'A-2007/10/29
        query &= MyBase.QueryWrapper.AddUR()

        Return query
    End Function

#End Region

#Region "■仕訳ヘッダー■（会計）"  'A-2008/07/18_Ver7.30_SAIMU

    Public Function SelectZAIR001UpdateLock(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal 処理連番 As Long
                ) As String Implements IMyQueryMaker.SelectZAIR001UpdateLock     'A-2008/07/18_Ver7.30_SAIMU    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append(" SELECT ")
        query.Append(QueryWrapper.AddIndexHintOracle(GetIndexHint("SEL_G_1")))
        query.Append(" ZAIR001001 ")
        query.Append(",ZAIR001004 ")

        query.Append(" FROM ")
        query.Append(Me.ExchangeTableName("ZAI10R001SHIH ") & QueryWrapper.AddUpdLock(GetIndexHint("ZAI_R001_G_1"), True))    'X1変換Tool-20170509

        query.Append(" WHERE ")
        query.Append("     ZAIR001004 = " & AddParamInfo(paramInfo, "ZAIR001004", DbType.Decimal, 0, 10, 0, 処理連番))

        query.Append(QueryWrapper.AddForUpdate(True))

        Return query.ToString

    End Function

    Public Function UpdateZAIR001(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                  ByVal 処理連番 As Long
                    ) As String Implements IMyQueryMaker.UpdateZAIR001  'A-2008/07/18_Ver7.30_SAIMU    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append(" UPDATE ")
        query.Append(Me.ExchangeTableName("ZAI10R001SHIH"))    'X1変換Tool-20170509

        query.Append(" SET ")
        query.Append(" ZAIR001018 = 1 ")    '販売データ修正区分
        query.Append(" WHERE ZAIR001004 = " & AddParamInfo(paramInfo, "ZAIR001004", DbType.Decimal, 0, 10, 0, 処理連番))

        Return query.ToString

    End Function

#End Region

#Region "■仮仕訳ヘッダー■（会計）"    'A-2010/09/13_Ver7.4X_ZAISHONIN

    Public Function SelectZAIR101UpdateLock(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal 処理連番 As Long
                ) As String Implements IMyQueryMaker.SelectZAIR101UpdateLock    'A-2010/09/13_Ver7.4X_ZAISHONIN    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append(" SELECT ")
        query.Append(QueryWrapper.AddIndexHintOracle(GetIndexHint("SEL_K_1")))
        query.Append(" ZAIR101001 ")
        query.Append(",ZAIR101004 ")

        query.Append(" FROM ")
        query.Append(Me.ExchangeTableName("ZAI10R101SHIH ") & QueryWrapper.AddUpdLock(GetIndexHint("ZAI_R101_K_1"), True))    'X1変換Tool-20170509

        query.Append(" WHERE ")
        query.Append("     ZAIR101004 = " & AddParamInfo(paramInfo, "ZAIR101004", DbType.Decimal, 0, 10, 0, 処理連番))

        query.Append(QueryWrapper.AddForUpdate(True))

        Return query.ToString

    End Function

    Public Function UpdateZAIR101(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                  ByVal 処理連番 As Long
                    ) As String Implements IMyQueryMaker.UpdateZAIR101  'A-2010/09/13_Ver7.4X_ZAISHONIN    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append(" UPDATE ")
        query.Append(Me.ExchangeTableName("ZAI10R101SHIH"))    'X1変換Tool-20170509

        query.Append(" SET ")
        query.Append(" ZAIR101018 = 1 ")    '販売データ修正区分
        query.Append(" WHERE ZAIR101004 = " & AddParamInfo(paramInfo, "ZAIR101004", DbType.Decimal, 0, 10, 0, 処理連番))

        Return query.ToString

    End Function

#End Region

#Region "■債務内訳■（会計）"  'A-2008/07/18_Ver7.30_SAIMU

    Public Function SelectZAIR204会計債務消込チェック(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                                      ByVal 処理連番 As Long
                    ) As String Implements IMyQueryMaker.SelectZAIR204会計債務消込チェック  'A-2008/07/18_Ver7.30_SAIMU    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append(" SELECT ")
        query.Append(QueryWrapper.AddIndexHintOracle(GetIndexHint("SEL_H_1")))
        query.Append(" ZAIR204001 ")

        query.Append(" FROM ")
        query.Append(Me.ExchangeTableName("ZAI10R204SAIMUUCHI ") & " " & QueryWrapper.AddNoLock(GetIndexHint("ZAI_R204_H_1")))    'X1変換Tool-20170509

        query.Append(" WHERE ZAIR204001 = " & AddParamInfo(paramInfo, "ZAIR204001", DbType.Decimal, 0, 10, 0, 処理連番))

        query.Append(" GROUP BY ")
        query.Append("  ZAIR204001 ")

        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString

    End Function

#End Region

#Region "■支払予定■（会計）"  'A-2008/07/18_Ver7.30_SAIMU

    Public Function SelectZAIR205会計支払状態チェック(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                                      ByVal 処理連番 As Long
                    ) As String Implements IMyQueryMaker.SelectZAIR205会計支払状態チェック  'A-2008/07/18_Ver7.30_SAIMU    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append(" SELECT ")
        query.Append(QueryWrapper.AddIndexHintOracle(GetIndexHint("SEL_I_1")))
        query.Append(" ZAIR205001 ")
        query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (ZAIR205034, 0) ZAIR205034 ")

        query.Append(" FROM ")
        'query.Append(Me.ExchangeTableName("ZAI10R201SAIMUH ") & " " & QueryWrapper.AddNoLock(GetIndexHint("ZAI_R201_I_1")))        'D-2009/04/20_1    'X1変換Tool-20170509
        query.Append(Me.ExchangeTableName("ZAI10R201SAIMUH ") & " " & QueryWrapper.AddUpdLock(GetIndexHint("ZAI_R201_I_1"), True))  'A-2009/04/20_1    'X1変換Tool-20170509

        query.Append(" LEFT OUTER JOIN ")
        'query.Append(Me.ExchangeTableName("ZAI10R205SHIHAYOTEI ") & " " & QueryWrapper.AddNoLock(GetIndexHint("ZAI_R205_I_1")))        'D-2009/04/20_1    'X1変換Tool-20170509
        query.Append(Me.ExchangeTableName("ZAI10R205SHIHAYOTEI ") & " " & QueryWrapper.AddUpdLock(GetIndexHint("ZAI_R205_I_1"), True))  'A-2009/04/20_1    'X1変換Tool-20170509
        query.Append("  ON ZAIR205001 = ZAIR201023 ")

        query.Append(" WHERE ")
        query.Append("     ZAIR201001 = " & AddParamInfo(paramInfo, "ZAIR201001", DbType.Decimal, 0, 10, 0, 処理連番))

        'query.Append(MyBase.QueryWrapper.AddUR())              'D-2009/04/20_1
        query.Append(MyBase.QueryWrapper.AddForUpdate(True))    'A-2009/04/20_1

        Return query.ToString

    End Function

#End Region

#Region "■プロジェクト明細■（会計）"  'A-2009/12/18_Ver7.40_PRO

    Public Function SelectZAIR502完成原価自動振替チェック(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                                          ByVal 処理連番 As Long
                    ) As String Implements IMyQueryMaker.SelectZAIR502完成原価自動振替チェック  'A-2009/12/18_Ver7.40_PRO    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append(" SELECT ")
        query.Append(QueryWrapper.AddIndexHintOracle(GetIndexHint("SEL_J_1")))
        query.Append(" ZAIR502002 ")

        query.Append(" FROM ")
        query.Append(Me.ExchangeTableName("ZAI10R502GENKAM ") & " " & QueryWrapper.AddNoLock(GetIndexHint("ZAI_R502_J_1")))    'X1変換Tool-20170509

        query.Append(" WHERE ZAIR502001 = 30 ")
        query.Append("   AND ZAIR502002 = " & AddParamInfo(paramInfo, "ZAIR502002", DbType.Decimal, 0, 10, 0, 処理連番))
        query.Append("   AND ZAIR502063 <> 0 ")

        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString

    End Function

#End Region

#Region "■入出荷ヘッダー■"

    Public Function SelectSEIR010PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal 処理連番 As Long
                    ) As String Implements IMyQueryMaker.SelectSEIR010PrimaryKey    'X1変換Tool-20170508
        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(QueryWrapper.AddIndexHintOracle(GetIndexHint("SEL_L_1")))

        '/ 入出荷ヘッダー
        query.Append(" SEIR010001 ")                                                    '// (001)  取引先区分
        query.Append(",SEIR010002 ")                                                    '// (002)  取引先コード
        query.Append(",SEIR010003 ")                                                    '// (003)  入出荷日(年月日)
        query.Append(",SEIR010004 ")                                                    '// (004)  伝票区分
        query.Append(",SEIR010005 ")                                                    '// (005)  処理連番
        query.Append(",SEIR010006 ")                                                    '// (006)  入出荷伝票番号
        query.Append(",SEIR010007 ")                                                    '// (007)  売上(仕入)伝票番号
        query.Append(",SEIR010008 ")                                                    '// (008)  操作日付(年月日)
        query.Append("," & QueryWrapper.AddIsNull() & "(SEIR010009, ' ') SEIR010009 ")  '// (009)  ログインＩＤ
        query.Append(",SEIR010010 ")                                                    '// (010)  チェックマーク区分
        query.Append(",SEIR010011 ")                                                    '// (011)  担当者コード
        query.Append(",SEIR010012 ")                                                    '// (012)  納品先コード
        query.Append(",SEIR010013 ")                                                    '// (013)  部門コード
        query.Append(",SEIR010014 ")                                                    '// (014)  倉庫コード
        query.Append(",SEIR010015 ")                                                    '// (015)  オーダーコード
        query.Append(",SEIR010016 ")                                                    '// (016)  受(発)注番号
        query.Append(",SEIR010017 ")                                                    '// (017)  売掛区分
        query.Append(",SEIR010018 ")                                                    '// (018)  請求(支払)区分
        query.Append(",SEIR010019 ")                                                    '// (019)  消費税計算区分
        query.Append(",SEIR010020 ")                                                    '// (020)  消費税率
        query.Append(",SEIR010021 ")                                                    '// (021)  伝票行数
        query.Append(",SEIR010022 ")                                                    '// (022)  備考コード
        query.Append("," & QueryWrapper.AddIsNull() & "(SEIR010023, ' ') SEIR010023 ")  '// (023)  備考
        query.Append("," & QueryWrapper.AddIsNull() & "(SEIR010024, ' ') SEIR010024 ")  '// (024)  手入力得意先名１
        query.Append("," & QueryWrapper.AddIsNull() & "(SEIR010025, ' ') SEIR010025 ")  '// (025)  手入力得意先名２
        query.Append("," & QueryWrapper.AddIsNull() & "(SEIR010026, ' ') SEIR010026 ")  '// (026)  手入力納品先名
        query.Append(",SEIR010027 ")                                                    '// (027)  通貨コード
        query.Append(",SEIR010028 ")                                                    '// (028)  データ発生区分
        query.Append(",SEIR010029 ")                                                    '// (029)  検収残区分
        query.Append(",SEIR010030 ")                                                    '// (030)  関連検収伝票枚数
        query.Append(",SEIR010031 ")                                                    '// (031)  計上区分
        query.Append(",SEIR010032 ")                                                    '// (032)  営業所コード
        query.Append(",SEIR010033 ")                                                    '// (033)  受注区分
        query.Append(",SEIR010034 ")                                                    '// (034)  受注形態
        query.Append(",SEIR010035 ")                                                    '// (035)  プロジェクトメインコード
        query.Append(",SEIR010036 ")                                                    '// (036)  プロジェクトサブコード
        query.Append(",SEIR010037 ")                                                    '// (037)  製番
        query.Append(",SEIR010038 ")                                                    '// (038)  製番(メイン)
        query.Append(",SEIR010039 ")                                                    '// (039)  製番(枝番)
        query.Append(",SEIR010040 ")                                                    '// (040)  発注区分
        query.Append(",SEIR010041 ")                                                    '// (041)  完成品区分
        query.Append(",SEIR010042 ")                                                    '// (042)  計上区分
        query.Append(",SEIR010043 ")                                                    '// (043)  計算区分
        query.Append(",SEIR010044 ")                                                    '// (044)  構成品出庫生成区分
        query.Append(",SEIR010045 ")                                                    '// (045)  返品区分
        query.Append(",SEIR010046 ")                                                    '// (046)  元出荷処理連番
        query.Append(",SEIR010047 ")                                                    '// (047)  税込売上_売上額
        query.Append(",SEIR010048 ")                                                    '// (048)  税込売上_返品額
        query.Append(",SEIR010049 ")                                                    '// (049)  税込売上_値引額
        query.Append(",SEIR010050 ")                                                    '// (050)  内消費税_売上額
        query.Append(",SEIR010051 ")                                                    '// (051)  内消費税_返品額
        query.Append(",SEIR010052 ")                                                    '// (052)  内消費税_値引額
        query.Append(",SEIR010053 ")                                                    '// (053)  税抜売上_売上額
        query.Append(",SEIR010054 ")                                                    '// (054)  税抜売上_返品額
        query.Append(",SEIR010055 ")                                                    '// (055)  税抜売上_値引額
        query.Append(",SEIR010056 ")                                                    '// (056)  外税_売上額
        query.Append(",SEIR010057 ")                                                    '// (057)  外税_返品額
        query.Append(",SEIR010058 ")                                                    '// (058)  外税_値引額
        query.Append(",SEIR010059 ")                                                    '// (059)  非課税_売上額
        query.Append(",SEIR010060 ")                                                    '// (060)  非課税_返品額
        query.Append(",SEIR010061 ")                                                    '// (061)  非課税_値引額
        query.Append(",SEIR010062 ")                                                    '// (062)  粗利額
        query.Append(",SEIR010999 ")                                                    '// (999)  更新番号

        'A-20121217_Ver7.50_1↓
        If MyImportParam.Myコントロール情報.MyMOAオプション.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う Then
            query.Append(",SEIR010063 ")                                                'レート
            query.Append(",SEIR010064 ")                                                'レート種類
            query.Append(",SEIR010065 ")                                                'レート換算基準区分
            query.Append(",SEIR010066 ")                                                '非課税売上 売上額(外貨)
            query.Append(",SEIR010067 ")                                                '           返品額(外貨)
            query.Append(",SEIR010068 ")                                                '           値引額(外貨)
            query.Append(",SEIR010069 ")                                                '粗利額(外貨)
            query.Append(",SEIR010070 ")                                                'INVOICE№
        End If
        'A-20121217_Ver7.50_1↑
        'A-20160324_1↓
        If _myImportParam.Myコントロール情報.使用条件(Myコントロール情報Param.条件型.外貨管理, 8D) = True Then
            If _myImportParam.Myコントロール情報.MyMOA外貨管理.外貨複数伝票消込機能 = MOA外貨定義型.制御区分型.行う Then
                query.Append(",SEIR010071 ")                                            'レート固定区分
            End If
            query.Append(",SEIR010072 ")                                                '邦貨手入力区分
        End If
        'A-20160324_1↑

        '/ 入出荷明細
        query.Append(",SEIR011001 ")                                                    '// (001)  入出荷日（年月日）
        query.Append(",SEIR011002 ")                                                    '// (002)  伝票区分
        query.Append(",SEIR011003 ")                                                    '// (003)  処理連番
        query.Append(",SEIR011004 ")                                                    '// (004)  明細区分
        query.Append(",SEIR011005 ")                                                    '// (005)  行番号
        query.Append(",SEIR011006 ")                                                    '// (006)  入出荷伝票番号
        query.Append(",SEIR011007 ")                                                    '// (007)  売上(仕入)伝票番号
        query.Append(",SEIR011008 ")                                                    '// (008)  取引先区分
        query.Append(",SEIR011009 ")                                                    '// (009)  取引先コード
        query.Append(",SEIR011010 ")                                                    '// (010)  担当者コード
        query.Append(",SEIR011011 ")                                                    '// (011)  取引区分
        query.Append(",SEIR011012 ")                                                    '// (012)  受(発)注番号
        query.Append(",SEIR011013 ")                                                    '// (013)  受(発)注行番号
        query.Append(",SEIR011014 ")                                                    '// (014)  部門コード
        query.Append(",SEIR011015 ")                                                    '// (015)  倉庫コード
        query.Append(",SEIR011016 ")                                                    '// (016)  商品(品目)コード
        query.Append("," & QueryWrapper.AddIsNull() & "(SEIR011017, ' ') SEIR011017 ")  '// (017)  商品(品目)名
        query.Append("," & QueryWrapper.AddIsNull() & "(SEIR011018, ' ') SEIR011018 ")  '// (018)  数量単位
        query.Append(",SEIR011019 ")                                                    '// (019)  入数
        query.Append(",SEIR011020 ")                                                    '// (020)  個数
        query.Append("," & QueryWrapper.AddIsNull() & "(SEIR011021, ' ') SEIR011021 ")  '// (021)  個数単位
        query.Append(",SEIR011022 ")                                                    '// (022)  入出荷数量
        query.Append(",SEIR011023 ")                                                    '// (023)  入出荷単価
        query.Append(",SEIR011024 ")                                                    '// (024)  入出荷金額
        query.Append(",SEIR011025 ")                                                    '// (025)  原単価
        query.Append(",SEIR011026 ")                                                    '// (026)  単価計算方法
        query.Append(",SEIR011027 ")                                                    '// (027)  単価掛率
        query.Append(",SEIR011028 ")                                                    '// (028)  標準売上単価
        query.Append(",SEIR011029 ")                                                    '// (029)  標準仕入単価
        query.Append(",SEIR011030 ")                                                    '// (030)  上代単価
        query.Append(",SEIR011031 ")                                                    '// (031)  粗利額
        query.Append(",SEIR011032 ")                                                    '// (032)  入出荷金額
        query.Append(",SEIR011033 ")                                                    '// (033)  値引金額
        query.Append(",SEIR011034 ")                                                    '// (034)  課税区分
        query.Append(",SEIR011035 ")                                                    '// (035)  消費税率
        query.Append(",SEIR011036 ")                                                    '// (036)  内消費税額
        query.Append(",SEIR011037 ")                                                    '// (037)  強制検収完納区分
        query.Append(",SEIR011038 ")                                                    '// (038)  行摘要コード
        query.Append("," & QueryWrapper.AddIsNull() & "(SEIR011039, ' ') SEIR011039 ")  '// (039)  行摘要１
        query.Append("," & QueryWrapper.AddIsNull() & "(SEIR011040, ' ') SEIR011040 ")  '// (040)  行摘要２
        query.Append(",SEIR011041 ")                                                    '// (041)  検収済数量
        query.Append(",SEIR011042 ")                                                    '// (042)  検収済金額
        query.Append(",SEIR011043 ")                                                    '// (043)  検収済金額内消費税
        query.Append(",SEIR011044 ")                                                    '// (044)  検収済金額内訳売上
        query.Append(",SEIR011045 ")                                                    '// (045)  検収済金額内訳値引
        query.Append(",SEIR011046 ")                                                    '// (046)  検収回数
        query.Append(",SEIR011047 ")                                                    '// (047)  最終検収日
        query.Append(",SEIR011048 ")                                                    '// (048)  関連売上/仕入伝票行数
        query.Append(",SEIR011049 ")                                                    '// (049)  検収残区分
        query.Append(",SEIR011050 ")                                                    '// (050)  通貨コード
        query.Append(",SEIR011051 ")                                                    '// (051)  取引区分属性
        query.Append(",SEIR011052 ")                                                    '// (052)  入出庫区分
        query.Append(",SEIR011053 ")                                                    '// (053)  データ発生区分
        query.Append(",SEIR011054 ")                                                    '// (054)  上代課税区分
        query.Append(",SEIR011055 ")                                                    '// (055)  計上区分
        query.Append(",SEIR011056 ")                                                    '// (056)  売掛区分
        query.Append(",SEIR011057 ")                                                    '// (057)  原価金額
        query.Append(",SEIR011058 ")                                                    '// (058)  営業所コード
        query.Append(",SEIR011059 ")                                                    '// (059)  拡張項目入力パターン№
        query.Append("," & QueryWrapper.AddIsNull() & "(SEIR011060, ' ') SEIR011060 ")  '// (060)  品目名１
        query.Append("," & QueryWrapper.AddIsNull() & "(SEIR011061, ' ') SEIR011061 ")  '// (061)  品目名２
        query.Append("," & QueryWrapper.AddIsNull() & "(SEIR011062, ' ') SEIR011062 ")  '// (062)  品目名３
        query.Append(",SEIR011063 ")                                                    '// (063)  製　番
        query.Append(",SEIR011064 ")                                                    '// (064)  製番（メイン）
        query.Append(",SEIR011065 ")                                                    '// (065)  製番（枝番）
        query.Append(",SEIR011066 ")                                                    '// (066)  客先注番
        query.Append(",SEIR011067 ")                                                    '// (067)  検査方法
        query.Append(",SEIR011068 ")                                                    '// (068)  発注区分
        query.Append(",SEIR011069 ")                                                    '// (069)  子部品引当区分
        query.Append(",SEIR011070 ")                                                    '// (070)  工程コード
        query.Append(",SEIR011071 ")                                                    '// (071)  入出荷数量(発注単位)
        query.Append("," & QueryWrapper.AddIsNull() & "(SEIR011072, ' ') SEIR011072 ")  '// (072)  入出荷単位(発注単位)
        query.Append(",SEIR011073 ")                                                    '// (073)  発注単位変換係数
        query.Append(",SEIR011074 ")                                                    '// (074)  発注確定区分
        query.Append(",SEIR011075 ")                                                    '// (075)  手配番号
        query.Append(",SEIR011076 ")                                                    '// (076)  手配管理番号
        query.Append(",SEIR011077 ")                                                    '// (077)  仮単価区分
        query.Append(",SEIR011078 ")                                                    '// (078)  受注形態
        query.Append(",SEIR011079 ")                                                    '// (079)  個別発注連番
        query.Append(",SEIR011080 ")                                                    '// (080)  検収済数量(発注単位)
        query.Append(",SEIR011081 ")                                                    '// (081)  費目コード
        query.Append(",SEIR011082 ")                                                    '// (082)  費目区分
        query.Append(",SEIR011083 ")                                                    '// (083)  ロケーション
        query.Append(",SEIR011084 ")                                                    '// (084)  ロット№
        query.Append(",SEIR011085 ")                                                    '// (085)  不良数量(在庫単位)
        query.Append(",SEIR011086 ")                                                    '// (086)  不良数量(発注単位)
        query.Append(",SEIR011087 ")                                                    '// (087)  ロット管理区分
        query.Append(",SEIR011088 ")                                                    '// (088)  有効期限
        query.Append(",SEIR011089 ")                                                    '// (089)  最新検収単価
        query.Append(",SEIR011090 ")                                                    '// (090)  相手売上(仕入)処理連番
        query.Append(",SEIR011091 ")                                                    '// (091)  相手売上(仕入)行番号
        query.Append(",SEIR011092 ")                                                    '// (092)  相手入出庫処理連番
        query.Append(",SEIR011093 ")                                                    '// (093)  相手入出庫行番号
        query.Append(",SEIR011094 ")                                                    '// (094)  外税額(明細消費税用)
        query.Append(",SEIR011095 ")                                                    '// (095)  検収残金額
        query.Append(",SEIR011096 ")                                                    '// (096)  元入出荷処理連番
        query.Append(",SEIR011097 ")                                                    '// (097)  元入出荷行番号
        query.Append(",SEIR011098 ")                                                    '// (098)  受発注強制完納区分
        query.Append(",SEIR011099 ")                                                    '// (099)  消費税計算区分
        query.Append(",SEIR011999 ")                                                    '// (999)  更新番号

        'A-20121217_Ver7.50_1↓
        If MyImportParam.Myコントロール情報.MyMOAオプション.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う Then
            query.Append(",SEIR011100 ")                                                '単価(外貨)
            query.Append(",SEIR011101 ")                                                '金額(外貨)
            query.Append(",SEIR011102 ")                                                '税抜売上 売上額(外貨)
            query.Append(",SEIR011103 ")                                                '         値引額(外貨)
            query.Append(",SEIR011104 ")                                                '検収済金額(外貨)
            query.Append(",SEIR011105 ")                                                '検収済金額内訳売上(外貨)
            query.Append(",SEIR011106 ")                                                '検収済金額内訳値引(外貨)
            query.Append(",SEIR011107 ")                                                '最新検収単価(外貨)
            query.Append(",SEIR011108 ")                                                '検収残金額
            query.Append(",SEIR011109 ")                                                '原単価(外貨)
            query.Append(",SEIR011110 ")                                                '原価金額(外貨)
            query.Append(",SEIR011111 ")                                                '粗利額(外貨)
            query.Append(",SEIR011112 ")                                                '諸掛管理№
            query.Append(",SEIR011113 ")                                                '按分対象区分
            query.Append(",SEIR011114 ")                                                '按分基準
            query.Append(",SEIR011115 ")                                                '按分済区分
            query.Append("," & QueryWrapper.AddIsNull() & "(SEIR011116, ' ') SEIR011116 ")    '外国語品目名１
            query.Append("," & QueryWrapper.AddIsNull() & "(SEIR011117, ' ') SEIR011117 ")    '外国語品目名２
            query.Append("," & QueryWrapper.AddIsNull() & "(SEIR011118, ' ') SEIR011118 ")    '外国語品目名３
            query.Append("," & QueryWrapper.AddIsNull() & "(SEIR011119, ' ') SEIR011119 ")    '外国語単位
            query.Append("," & QueryWrapper.AddIsNull() & "(SEIR011120, ' ') SEIR011120 ")    '外国語個数単位
        End If
        'A-20121217_Ver7.50_1↑
        'A-20160324_2↓
        If MyImportParam.Myコントロール情報.使用条件(Myコントロール情報Param.条件型.品目別原価計算機能, 8D) = True Then
            query.Append(",SEIR011121 ")                                                '原価計上手配番号
        End If
        'A-20160324_2↑

        '取引ヘッダー(売上)
        query.Append(",HANR001002 ")                                                    '取引先コード
        query.Append(",HANR001003 ")                                                    '伝票日付
        query.Append(",HANR001005 ")                                                    '伝票番号
        query.Append(",HANR001006 ")                                                    '処理連番
        query.Append(",HANR001011 ")                                                    '担当者コード
        query.Append(",HANR001012 ")                                                    '納品先コード
        query.Append(",HANR001014 ")                                                    '部門コード
        query.Append(",HANR001015 ")                                                    '発注№         'A-20111025_1
        query.Append(",HANR001018 ")                                                    '売掛区分
        query.Append(",HANR001019 ")                                                    '請求区分
        query.Append(",HANR001020 ")                                                    '台帳用請求区分
        query.Append(",HANR001021 ")                                                    '請求処理連番
        query.Append(",HANR001022 ")                                                    '伝票消費税計算区分
        query.Append(",HANR001024 ")                                                    '自動生成データ区分
        query.Append(",HANR001025 ")                                                    '
        query.Append(",HANR001026 ")                                                    '備考コード
        query.Append("," & QueryWrapper.AddIsNull() & "(HANR001027, ' ') HANR001027 ")  '備考
        query.Append(",HANR001028 ")                                                    '税込売上 売上額
        query.Append(",HANR001029 ")                                                    '         返品額
        query.Append(",HANR001030 ")                                                    '         値引額
        query.Append(",HANR001031 ")                                                    '内消費税 売上額
        query.Append(",HANR001032 ")                                                    '         返品額
        query.Append(",HANR001033 ")                                                    '         値引額
        query.Append(",HANR001034 ")                                                    '税抜売上 売上額
        query.Append(",HANR001035 ")                                                    '         返品額
        query.Append(",HANR001036 ")                                                    '         値引額
        query.Append(",HANR001037 ")                                                    '外税     売上額
        query.Append(",HANR001038 ")                                                    '         返品額
        query.Append(",HANR001039 ")                                                    '         値引額
        query.Append(",HANR001040 ")                                                    '非課税   売上額
        query.Append(",HANR001041 ")                                                    '         返品額
        query.Append(",HANR001042 ")                                                    '         値引額
        query.Append(",HANR001046 ")                                                    '入金 売上
        query.Append(",HANR001052 ")                                                    '粗利
        query.Append("," & QueryWrapper.AddIsNull() & "(HANR001053, ' ') HANR001053 ")  '手入力得意先名１
        query.Append("," & QueryWrapper.AddIsNull() & "(HANR001054, ' ') HANR001054 ")  '手入力得意先名２
        query.Append("," & QueryWrapper.AddIsNull() & "(HANR001055, ' ') HANR001055 ")  '手入力納品先名
        query.Append(",HANR001056 ")                                                    '通貨コード
        query.Append(",HANR001059 ")                                                    '財務連結区分
        query.Append(",HANR001060 ")                                                    '財務処理連番
        query.Append(",HANR001061 ")                                                    'データ発生区分
        query.Append(",HANR001062 ")                                                    '消費税仮計上区分
        query.Append(",HANR001065 ")                                                    '仕訳対象外区分
        query.Append(",HANR001066 ")                                                    '請求締日付     
        query.Append(",HANR001067 ")                                                    '回収予定日     
        query.Append(",HANR001068 ")                                                    '入出荷処理連番
        query.Append(",HANR001069 ")                                                    '計上区分       'A-20111025_1
        query.Append(",HANR001073 ")                                                    '営業所コード
        query.Append(",HANR001075 ")                                                    '請求書番号
        query.Append(",HANR001076 ")                                                    '締処理グループ
        query.Append(",HANR001999 ")                                                    '更新番号

        query.Append(",HANR001A001 ")                                                   '製番
        query.Append(",HANR001A002 ")                                                   '製番(メイン)
        query.Append(",HANR001A003 ")                                                   '製番(枝番)
        query.Append(",HANR001A004 ")                                                   '発生区分
        query.Append(",HANR001A005 ")                                                   '発生元相手連番
        query.Append(",HANR001A006 ")                                                   '受入区分
        query.Append(",HANR001A007 ")                                                   '発注区分
        query.Append(",HANR001A008 ")                                                   '相手連番
        query.Append(",HANR001A009 ")                                                   '完成品区分
        query.Append(",HANR001A010 ")                                                   '返品区分
        query.Append(",HANR001A011 ")                                                   '元出荷連番
        query.Append(",HANR001A012 ")                                                   'プロジェクトメインコード
        query.Append(",HANR001A013 ")                                                   'プロジェクトサブコード
        query.Append(",HANR001A014 ")                                                   '売上データ生成区分
        query.Append(",HANR001A015 ")                                                   '構成品出庫生成区分
        query.Append(",HANR001A016 ")                                                   '入出荷伝票番号

        'A-20111124_11↓
        If MyImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 3D Then
            query.Append("," & QueryWrapper.AddIsNull() & "(HANR001S002, 0) HANR001S002 ")  '仕掛生成区分
        End If
        'A-20111124_11↑

        'A-20121217_Ver7.50_1↓
        If MyImportParam.Myコントロール情報.MyMOAオプション.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う Then
            query.Append(",HANR001087 ")                                                '入力通貨区分
            query.Append(",HANR001088 ")                                                'レート種別
            query.Append(",HANR001089 ")                                                'レート
            'A-20160324_1↓
            If _myImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 8D Then
                query.Append(",HANR001095 ")                                            '外貨管理 レート固定区分
                query.Append(",HANR001096 ")                                            '外貨管理 外貨　売上額
                query.Append(",HANR001097 ")                                            '外貨管理 外貨　返品額
                query.Append(",HANR001098 ")                                            '外貨管理 外貨　値引額
                query.Append(",HANR001099 ")                                            '外貨管理 外貨入金　現金
                query.Append(",HANR001100 ")                                            '外貨管理 外貨入金　振込
                query.Append(",HANR001101 ")                                            '外貨管理 外貨入金　相殺
                query.Append(",HANR001102 ")                                            '外貨管理 外貨入金　手形
                query.Append(",HANR001103 ")                                            '外貨管理 外貨入金　値引
                query.Append(",HANR001104 ")                                            '外貨管理 外貨入金　調整
                query.Append(",HANR001105 ")                                            '外貨管理 外貨　粗利額
            End If
            'A-20160324_1↑
            query.Append(",HANR001S003 ")                                               'レート換算基準区分
            query.Append(",HANR001S004 ")                                               '非課税売上 売上額(外貨)
            query.Append(",HANR001S005 ")                                               '           返品額(外貨)
            query.Append(",HANR001S006 ")                                               '           値引額(外貨)
            query.Append(",HANR001S007 ")                                               '入金 現金
            query.Append(",HANR001S008 ")                                               '     振込
            query.Append(",HANR001S009 ")                                               '     相殺
            query.Append(",HANR001S010 ")                                               '     手形
            query.Append(",HANR001S011 ")                                               '     値引
            query.Append(",HANR001S012 ")                                               '     調整
            query.Append(",HANR001S013 ")                                               '粗利額(外貨)
            query.Append(",HANR001S014 ")                                               'INVOICE№
            'A-20160324_1↓
            If MyImportParam.Myコントロール情報.使用条件(Myコントロール情報Param.条件型.外貨複数伝票消込機能, 8D) Then
                query.Append(",HANR001S015 ")                                           '邦貨手入力区分
            End If
            'A-20160324_1↑
        End If
        'A-20121217_Ver7.50_1↑

        '取引明細(売上)
        query.Append(",HANR002001 ")                                                    '
        query.Append(",HANR002004 ")                                                    '
        query.Append(",HANR002005 ")                                                    '明細区分
        query.Append(",HANR002006 ")                                                    '行番号
        query.Append(",HANR002010 ")                                                    '取引区分
        query.Append(",HANR002011 ")                                                    '受注番号
        query.Append(",HANR002012 ")                                                    '受注行番号
        query.Append(",HANR002013 ")                                                    '見積処理連番
        query.Append(",HANR002014 ")                                                    '見積行番号
        query.Append(",HANR002015 ")                                                    '相手処理連番
        query.Append(",HANR002018 ")                                                    '倉庫コード
        query.Append(",HANR002019 ")                                                    '商品コード
        query.Append("," & QueryWrapper.AddIsNull() & "(HANR002020, ' ') HANR002020 ")  '商品名
        query.Append("," & QueryWrapper.AddIsNull() & "(HANR002021, ' ') HANR002021 ")  '数量単位
        query.Append(",HANR002022 ")                                                    '入数
        query.Append(",HANR002023 ")                                                    '個数
        query.Append("," & QueryWrapper.AddIsNull() & "(HANR002024, ' ') HANR002024 ")  '個数単位
        query.Append(",HANR002025 ")                                                    '数量
        query.Append(",HANR002026 ")                                                    '単価
        query.Append(",HANR002027 ")                                                    '金額
        query.Append(",HANR002028 ")                                                    '原単価
        query.Append(",HANR002029 ")                                                    '単価計算方法
        query.Append(",HANR002030 ")                                                    '単価掛率
        query.Append(",HANR002033 ")                                                    '上代単価
        query.Append(",HANR002034 ")                                                    '粗利
        query.Append(",HANR002047 ")                                                    '課税区分
        query.Append(",HANR002048 ")                                                    '消費税率
        query.Append(",HANR002049 ")                                                    '内消費税
        query.Append(",HANR002050 ")                                                    '外税額(明細消費税用)
        query.Append(",HANR002051 ")                                                    '明細消費税計算区分
        query.Append(",HANR002052 ")                                                    '完納区分
        query.Append(",HANR002053 ")                                                    '行摘要コード
        query.Append("," & QueryWrapper.AddIsNull() & "(HANR002054, ' ') HANR002054 ")  '行摘要１
        query.Append("," & QueryWrapper.AddIsNull() & "(HANR002055, ' ') HANR002055 ")  '行摘要２
        query.Append(",HANR002057 ")                                                    '取引区分属性
        query.Append(",HANR002059 ")                                                    '通貨コード
        query.Append(",HANR002069 ")                                                    '上代課税区分
        query.Append(",HANR002075 ")                                                    '原価金額
        query.Append(",HANR002077 ")                                                    '拡張項目入力パターン№
        query.Append(",HANR002999 ")                                                    '更新番号

        query.Append("," & QueryWrapper.AddIsNull() & "(HANR002A001, ' ') HANR002A001 ") '品名1
        query.Append("," & QueryWrapper.AddIsNull() & "(HANR002A002, ' ') HANR002A002 ") '品名2
        query.Append("," & QueryWrapper.AddIsNull() & "(HANR002A003, ' ') HANR002A003 ") '品名3
        query.Append(",HANR002A004 ")                                                    '発生区分
        query.Append(",HANR002A005 ")                                                    '相手連番
        query.Append(",HANR002A006 ")                                                    '製番
        query.Append(",HANR002A007 ")                                                    '製番(メイン)
        query.Append(",HANR002A008 ")                                                    '製番(枝番)
        query.Append(",HANR002A009 ")                                                    'ロット管理区分
        query.Append(",HANR002A010 ")                                                    'ロット№
        query.Append(",HANR002A011 ")                                                    '有効期限
        query.Append(",HANR002A012 ")                                                    'ロケーション
        query.Append(",HANR002A013 ")                                                    '仮単価区分
        query.Append(",HANR002A014 ")                                                    '受入数量(在庫単位)
        query.Append("," & QueryWrapper.AddIsNull() & "(HANR002A015, ' ') HANR002A015 ") '受入単位(在庫単位)
        query.Append(",HANR002A016 ")                                                    '発注単位変換係数
        query.Append(",HANR002A017 ")                                                    '不良数量(在庫単位)
        query.Append(",HANR002A018 ")                                                    '不良数量(発注単位)
        query.Append(",HANR002A019 ")                                                    '受入区分
        query.Append(",HANR002A020 ")                                                    '発注区分
        query.Append(",HANR002A021 ")                                                    '子部品引当区分
        query.Append(",HANR002A022 ")                                                    '工程コード
        query.Append(",HANR002A023 ")                                                    '相手連番
        query.Append(",HANR002A024 ")                                                    '完成品区分
        query.Append(",HANR002A025 ")                                                    '発注確定区分
        query.Append(",HANR002A026 ")                                                    '手配番号
        query.Append(",HANR002A027 ")                                                    '手配管理番号
        query.Append(",HANR002A028 ")                                                    '個別発注連番
        query.Append(",HANR002A029 ")                                                    '展開順序番号
        query.Append(",HANR002A030 ")                                                    '費目コード
        query.Append(",HANR002A031 ")                                                    '出庫単価
        query.Append(",HANR002A032 ")                                                    '出庫金額
        query.Append(",HANR002A033 ")                                                    '費目区分
        query.Append(",HANR002A034 ")                                                    '元出荷連番
        query.Append(",HANR002A035 ")                                                    '元出荷行№
        query.Append(",HANR002A036 ")                                                    '入出荷伝票番号
        query.Append(",HANR002A037 ")                                                    '費目コード.材料費
        query.Append(",HANR002A038 ")                                                    '費目コード.労務費
        query.Append(",HANR002A039 ")                                                    '費目コード.外注費
        query.Append(",HANR002A040 ")                                                    '出庫金額.材料費
        query.Append(",HANR002A041 ")                                                    '出庫金額.労務費
        query.Append(",HANR002A042 ")                                                    '出庫金額.外注費

        'A-20121217_Ver7.50_1↓
        If MyImportParam.Myコントロール情報.MyMOAオプション.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う Then
            query.Append(",HANR002101 ")                                                '入力通貨区分
            query.Append(",HANR002102 ")                                                'レート種別
            query.Append(",HANR002103 ")                                                'レート
            query.Append(",HANR002104 ")                                                '外貨金額
            query.Append(",HANR002105 ")                                                '決算時評価替え区分
            query.Append(",HANR002106 ")                                                '売上(仕入)円貨金額
            query.Append(",HANR002107 ")                                                '売上(仕入)レート
            'A-20160324_1↓
            If MyImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 8D Then
                query.Append(",HANR002108 ")                                            '外貨管理 単価
                query.Append(",HANR002109 ")                                            '外貨管理 原単価
                query.Append(",HANR002110 ")                                            '外貨管理 原価金額
                query.Append(",HANR002112 ")                                            '外貨管理 粗利額
                query.Append(",HANR002113 ")                                            '外貨金額内訳 売上(仕入)金額
                query.Append(",HANR002114 ")                                            '外貨金額内訳 返品金額
                query.Append(",HANR002115 ")                                            '外貨金額内訳 値引金額
            End If
            'A-20160324_1↑
            query.Append(",HANR002S001 ")                                               '単価(外貨)
            query.Append(",HANR002S002 ")                                               '税抜売上 売上額(外貨)
            query.Append(",HANR002S003 ")                                               '         返品額(外貨)
            query.Append(",HANR002S004 ")                                               '         値引額(外貨)
            query.Append(",HANR002S005 ")                                               '原単価(外貨)
            query.Append(",HANR002S006 ")                                               '原価金額(外貨)
            query.Append(",HANR002S007 ")                                               '粗利額(外貨)
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANR002S008, ' ') HANR002S008 ")  '外国語品目名１
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANR002S009, ' ') HANR002S009 ")  '外国語品目名２
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANR002S010, ' ') HANR002S010 ")  '外国語品目名３
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANR002S011, ' ') HANR002S011 ")  '外国語単位
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANR002S012, ' ') HANR002S012 ")  '外国語個数単位
            query.Append(",HANR002S013 ")                                               '諸掛管理№
            query.Append(",HANR002S014 ")                                               '按分対象区分
            query.Append(",HANR002S015 ")                                               '按分基準
            query.Append(",HANR002S016 ")                                               '按分済区分
        End If
        'A-20121217_Ver7.50_1↑

        'A-20141105_1↓
        If MyImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 6D Then
            query.Append(",HANR002S017 ")                                               '費目コード・経費
            query.Append(",HANR002S018 ")                                               '出庫金額・経費
        End If
        'A-20141105_1↑
        'A-20160324_2↓
        If MyImportParam.Myコントロール情報.使用条件(Myコントロール情報Param.条件型.品目別原価計算機能, 8D) = True Then
            query.Append(",HANR002S020 ")                                               '原価計上手配番号
        End If
        'A-20160324_2↑

        '受発注ヘッダー(発注)
        query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANR004002, ' ') HANR004002 ")
        query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANR004003, 0) HANR004003 ")
        query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANR004004, 0) HANR004004 ")                    '伝票区分
        query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANR004005, 0) HANR004005 ")                    '受注番号
        query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANR004016, 0) HANR004016 ")                    '見積番号
        query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANR004035, ' ') HANR004035 ")
        query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANR004036, ' ') HANR004036 ")
        query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANR004045, 0) HANR004045 ")                    '計上区分
        query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANR004A001, 0) HANR004A001 ")                  '受注区分
        query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANR004A004, ' ') HANR004A004 ")                'プロジェクトメインコード
        query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANR004A005, ' ') HANR004A005 ")                'プロジェクトサブコード

        query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SHIIRE.HANM002001, ' ') HANM002001 ")           '支払先コード
        query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SHIIRE.HANM002043, 0) HANM002043 ")             '端数処理区分 金額
        query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SHIIRE.HANM002046, 0) HANM002046 ")             '端数処理区分 消費税分解
        query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SHIHARAI.HANM002989, 0) HANM002989SHIHARAI ")   '締日付
        If MyImportParam.Myコントロール情報.Myオプション区分.支払管理 = オプション区分定義型.区分型.行う Then
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SHIHARAI.HANM002027, 0) HANM002027SHIHARAI ")   '締日１         
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SHIHARAI.HANM002090, 0) HANM002090SHIHARAI ")   '支払管理区分    
            query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SHIHARAI.HANM002091, 0) HANM002091SHIHARAI ")   '支払管理単位   
        End If
        query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANM035011, 0) HANM035011 ")                    '支払処理連番

        If MyImportParam.Myコントロール情報.Myオプション区分.拡張項目_仕入伝票 = True Then
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_H.HANR030006, 0) HANR030006_H ")       '付箋色番号
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_H.HANR030007, ' ') HANR030007_H ")     '拡張項目０１
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_H.HANR030008, ' ') HANR030008_H ")     '拡張項目０２
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_H.HANR030009, ' ') HANR030009_H ")     '拡張項目０３
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_H.HANR030010, ' ') HANR030010_H ")     '拡張項目０４
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_H.HANR030011, ' ') HANR030011_H ")     '拡張項目０５
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_H.HANR030012, ' ') HANR030012_H ")     '拡張項目０６
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_H.HANR030013, ' ') HANR030013_H ")     '拡張項目０７
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_H.HANR030014, ' ') HANR030014_H ")     '拡張項目０８
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_H.HANR030015, ' ') HANR030015_H ")     '拡張項目０９
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_H.HANR030016, ' ') HANR030016_H ")     '拡張項目１０
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_H.HANR030017, ' ') HANR030017_H ")     '拡張項目１１
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_H.HANR030018, ' ') HANR030018_H ")     '拡張項目１２
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_H.HANR030019, ' ') HANR030019_H ")     '拡張項目１３
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_H.HANR030020, ' ') HANR030020_H ")     '拡張項目１４
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_H.HANR030021, ' ') HANR030021_H ")     '拡張項目１５
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_H.HANR030022, ' ') HANR030022_H ")     '拡張項目１６
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_H.HANR030023, ' ') HANR030023_H ")     '拡張項目１７
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_H.HANR030024, ' ') HANR030024_H ")     '拡張項目１８
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_H.HANR030025, ' ') HANR030025_H ")     '拡張項目１９
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_H.HANR030026, ' ') HANR030026_H ")     '拡張項目２０
        End If

        If MyImportParam.Myコントロール情報.Myオプション区分.拡張項目_仕入明細 = True Then
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_M.HANR030006, 0) HANR030006_M ")       '付箋色番号
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_M.HANR030007, ' ') HANR030007_M ")     '拡張項目０１
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_M.HANR030008, ' ') HANR030008_M ")     '拡張項目０２
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_M.HANR030009, ' ') HANR030009_M ")     '拡張項目０３
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_M.HANR030010, ' ') HANR030010_M ")     '拡張項目０４
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_M.HANR030011, ' ') HANR030011_M ")     '拡張項目０５
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_M.HANR030012, ' ') HANR030012_M ")     '拡張項目０６
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_M.HANR030013, ' ') HANR030013_M ")     '拡張項目０７
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_M.HANR030014, ' ') HANR030014_M ")     '拡張項目０８
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_M.HANR030015, ' ') HANR030015_M ")     '拡張項目０９
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_M.HANR030016, ' ') HANR030016_M ")     '拡張項目１０
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_M.HANR030017, ' ') HANR030017_M ")     '拡張項目１１
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_M.HANR030018, ' ') HANR030018_M ")     '拡張項目１２
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_M.HANR030019, ' ') HANR030019_M ")     '拡張項目１３
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_M.HANR030020, ' ') HANR030020_M ")     '拡張項目１４
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_M.HANR030021, ' ') HANR030021_M ")     '拡張項目１５
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_M.HANR030022, ' ') HANR030022_M ")     '拡張項目１６
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_M.HANR030023, ' ') HANR030023_M ")     '拡張項目１７
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_M.HANR030024, ' ') HANR030024_M ")     '拡張項目１８
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_M.HANR030025, ' ') HANR030025_M ")     '拡張項目１９
            query.Append("," & QueryWrapper.AddIsNull() & "(R030_M.HANR030026, ' ') HANR030026_M ")     '拡張項目２０
        End If

        query.Append("FROM " & MyBase.ExchangeTableName("SEI10R010NYUSHUKKAH"))    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock(GetIndexHint("R010_L_1")))

        query.Append("INNER JOIN " & MyBase.ExchangeTableName("SEI10R011NYUSHUKKAM") & " ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock(GetIndexHint("R011_L_1")))
        query.Append("   ON SEIR011002 = SEIR010004 ")
        query.Append("  AND SEIR011003 = SEIR010005 ")

        query.Append("LEFT OUTER JOIN " & MyBase.ExchangeTableName("HAN10R001TORIHIKIH"))    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock(GetIndexHint("R001_L_1")))
        query.Append("   ON HANR001001 = 2 ")
        query.Append("  AND HANR001004 = 1 ")
        query.Append("  AND HANR001068 = SEIR010005 ")
        query.Append("  AND HANR001069 = 0 ")

        query.Append("LEFT OUTER JOIN " & MyBase.ExchangeTableName("HAN10R002TORIHIKIM") & " ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock(GetIndexHint("R002_L_1")))
        query.Append("   ON HANR002002 = HANR001004 ")
        query.Append("  AND HANR002004 = HANR001006 ")
        query.Append("  AND HANR002005 = SEIR011004 ")
        query.Append("  AND HANR002006 = SEIR011091 ")

        query.Append("LEFT OUTER JOIN " & MyBase.ExchangeTableName("HAN10R004JUHACHUH"))    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock(GetIndexHint("R004_L_1")))
        query.Append("   ON HANR004004 = 1 ")
        query.Append("  AND HANR004005 = SEIR010016 ")

        query.Append("LEFT OUTER JOIN " & MyBase.ExchangeTableName("HAN10M002SHIIRE") & " SHIIRE ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())
        query.Append("   ON SHIIRE.HANM002003 = SEIR010002 ")

        query.Append("LEFT OUTER JOIN " & MyBase.ExchangeTableName("HAN10M002SHIIRE") & " SHIHARAI ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())
        query.Append("   ON SHIHARAI.HANM002003 = SHIIRE.HANM002001 ")

        query.Append("LEFT OUTER JOIN " & MyBase.ExchangeTableName("HAN10M035SHIMEG") & " ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())
        query.Append("   ON HANM035001 = 1 ")
        query.Append("  AND HANM035002 = SHIHARAI.HANM002991 ")

        If MyImportParam.Myコントロール情報.Myオプション区分.拡張項目_仕入伝票 = True Then
            query.Append("LEFT OUTER JOIN " & MyBase.ExchangeTableName("HAN10R030KAKUCHO") & " R030_H ")    'X1変換Tool-20170509
            query.Append(MyBase.QueryWrapper.AddNoLock())
            query.Append("   ON R030_H.HANR030001 = 3 ")
            query.Append("  AND R030_H.HANR030002 = SEIR010004 ")
            query.Append("  AND R030_H.HANR030003 = 0 ")
            query.Append("  AND R030_H.HANR030004 = SEIR010005 ")
            query.Append("  AND R030_H.HANR030005 = 0 ")
        End If

        If MyImportParam.Myコントロール情報.Myオプション区分.拡張項目_仕入明細 = True Then
            query.Append("LEFT OUTER JOIN " & MyBase.ExchangeTableName("HAN10R030KAKUCHO") & " R030_M ")    'X1変換Tool-20170509
            query.Append(MyBase.QueryWrapper.AddNoLock())
            query.Append("   ON R030_M.HANR030001 = 3 ")
            query.Append("  AND R030_M.HANR030002 = SEIR011002 ")
            query.Append("  AND R030_M.HANR030003 = SEIR011004 ")
            query.Append("  AND R030_M.HANR030004 = SEIR011003 ")
            query.Append("  AND R030_M.HANR030005 = SEIR011005 ")
        End If

        query.Append("WHERE SEIR010004 = 1")
        query.Append("  AND SEIR010005 = " & AddParamInfo(paramInfo, "SEIR010005", DbType.Decimal, 0, 10, 0, 処理連番) & " ")

        query.Append("ORDER BY SEIR010004,SEIR010005,SEIR011004,SEIR011005")
        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString
    End Function

    Public Function SelectSEIR010返品伝票存在(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                              ByVal 処理連番 As Long
                    ) As String Implements IMyQueryMaker.SelectSEIR010返品伝票存在    'X1変換Tool-20170508
        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")

        query.Append(" SEIR010001 ")

        query.Append("FROM " & MyBase.ExchangeTableName("SEI10R010NYUSHUKKAH"))    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock(GetIndexHint("R010_M_1")))

        query.Append("WHERE SEIR010004 = 1")
        query.Append("  AND SEIR010046 = " & AddParamInfo(paramInfo, "SEIR010046", DbType.Decimal, 0, 10, 0, 処理連番) & " ")

        query.Append("ORDER BY SEIR010004,SEIR010005")
        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString
    End Function

    Public Function InsertSEIR010(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                  ByVal 更新データ As WorkTableUnitData) As String Implements IMyQueryMaker.InsertSEIR010    'X1変換Tool-20170508
        Dim query As New System.Text.StringBuilder

        query.Append(" INSERT INTO ")
        query.Append(Me.ExchangeTableName("SEI10R010NYUSHUKKAH"))    'X1変換Tool-20170509

        query.Append(" (")
        query.Append(" SEIR010001")
        query.Append(",SEIR010002")
        query.Append(",SEIR010003")
        query.Append(",SEIR010004")
        query.Append(",SEIR010005")
        query.Append(",SEIR010006")
        query.Append(",SEIR010007")
        query.Append(",SEIR010008")
        query.Append(",SEIR010009")
        query.Append(",SEIR010010")
        query.Append(",SEIR010011")
        query.Append(",SEIR010012")
        query.Append(",SEIR010013")
        query.Append(",SEIR010014")
        query.Append(",SEIR010015")
        query.Append(",SEIR010016")
        query.Append(",SEIR010017")
        query.Append(",SEIR010018")
        query.Append(",SEIR010019")
        query.Append(",SEIR010020")
        query.Append(",SEIR010021")
        query.Append(",SEIR010022")
        query.Append(",SEIR010023")
        query.Append(",SEIR010024")
        query.Append(",SEIR010025")
        query.Append(",SEIR010026")
        query.Append(",SEIR010027")
        query.Append(",SEIR010028")
        query.Append(",SEIR010029")
        query.Append(",SEIR010030")
        query.Append(",SEIR010031")
        query.Append(",SEIR010032")
        query.Append(",SEIR010033")
        query.Append(",SEIR010034")
        query.Append(",SEIR010035")
        query.Append(",SEIR010036")
        query.Append(",SEIR010037")
        query.Append(",SEIR010038")
        query.Append(",SEIR010039")
        query.Append(",SEIR010040")
        query.Append(",SEIR010041")
        query.Append(",SEIR010042")
        query.Append(",SEIR010043")
        query.Append(",SEIR010044")
        query.Append(",SEIR010045")
        query.Append(",SEIR010046")
        query.Append(",SEIR010047")
        query.Append(",SEIR010048")
        query.Append(",SEIR010049")
        query.Append(",SEIR010050")
        query.Append(",SEIR010051")
        query.Append(",SEIR010052")
        query.Append(",SEIR010053")
        query.Append(",SEIR010054")
        query.Append(",SEIR010055")
        query.Append(",SEIR010056")
        query.Append(",SEIR010057")
        query.Append(",SEIR010058")
        query.Append(",SEIR010059")
        query.Append(",SEIR010060")
        query.Append(",SEIR010061")
        query.Append(",SEIR010062")
        query.Append(",SEIR010999")

        'A-20121217_Ver7.50_1↓
        If MyImportParam.Myコントロール情報.MyMOAオプション.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う Then
            query.Append(",SEIR010063 ")
            query.Append(",SEIR010064 ")
            query.Append(",SEIR010065 ")
            query.Append(",SEIR010066 ")
            query.Append(",SEIR010067 ")
            query.Append(",SEIR010068 ")
            query.Append(",SEIR010069 ")
            query.Append(",SEIR010070 ")
        End If
        'A-20121217_Ver7.50_1↑
        'A-20160324_1↓
        If _myImportParam.Myコントロール情報.使用条件(Myコントロール情報Param.条件型.外貨管理, 8D) = True Then
            query.Append(",SEIR010071 ")                                            'レート固定区分
            query.Append(",SEIR010072 ")                                            '邦貨手入力区分
        End If
        'A-20160324_1↑

        query.Append(" )")
        query.Append(" VALUES (")

        query.Append(" " & AddParamInfo(paramInfo, "SEIR010001", DbType.Decimal, 0, 1, 0, 更新データ.入荷ヘッダー.R010001))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010002", DbType.AnsiStringFixedLength, 11, 0, 0, 更新データ.入荷ヘッダー.R010002))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010003", DbType.Decimal, 0, 8, 0, 更新データ.入荷ヘッダー.R010003))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010004", DbType.Decimal, 0, 1, 0, 更新データ.入荷ヘッダー.R010004))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010005", DbType.Decimal, 0, 10, 0, 更新データ.入荷ヘッダー.R010005))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010006", DbType.Decimal, 0, 8, 0, 更新データ.入荷ヘッダー.R010006))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010007", DbType.Decimal, 0, 8, 0, 更新データ.入荷ヘッダー.R010007))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010008", DbType.Decimal, 0, 8, 0, 更新データ.入荷ヘッダー.R010008))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010009", DbType.String, 64, 0, 0, 更新データ.入荷ヘッダー.R010009))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010010", DbType.Decimal, 0, 1, 0, 更新データ.入荷ヘッダー.R010010))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010011", DbType.AnsiStringFixedLength, 8, 0, 0, 更新データ.入荷ヘッダー.R010011))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010012", DbType.AnsiStringFixedLength, 6, 0, 0, 更新データ.入荷ヘッダー.R010012))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010013", DbType.AnsiStringFixedLength, 8, 0, 0, 更新データ.入荷ヘッダー.R010013))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010014", DbType.AnsiStringFixedLength, 11, 0, 0, 更新データ.入荷ヘッダー.R010014))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010015", DbType.AnsiStringFixedLength, 20, 0, 0, 更新データ.入荷ヘッダー.R010015))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010016", DbType.Decimal, 0, 10, 0, 更新データ.入荷ヘッダー.R010016))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010017", DbType.Decimal, 0, 1, 0, 更新データ.入荷ヘッダー.R010017))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010018", DbType.Decimal, 0, 1, 0, 更新データ.入荷ヘッダー.R010018))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010019", DbType.Decimal, 0, 1, 0, 更新データ.入荷ヘッダー.R010019))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010020", DbType.Decimal, 0, 4, 2, 更新データ.入荷ヘッダー.R010020))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010021", DbType.Decimal, 0, 3, 0, 更新データ.入荷ヘッダー.R010021))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010022", DbType.AnsiStringFixedLength, 5, 0, 0, 更新データ.入荷ヘッダー.R010022))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010023", DbType.String, 36, 0, 0, 更新データ.入荷ヘッダー.R010023))
        '↓D-20170601-X1-桁数拡張
        'query.Append("," & AddParamInfo(paramInfo, "SEIR010024", DbType.String, 32, 0, 0, 更新データ.入荷ヘッダー.R010024))
        'query.Append("," & AddParamInfo(paramInfo, "SEIR010025", DbType.String, 32, 0, 0, 更新データ.入荷ヘッダー.R010025))
        'query.Append("," & AddParamInfo(paramInfo, "SEIR010026", DbType.String, 32, 0, 0, 更新データ.入荷ヘッダー.R010026))
        '↑D-20170601-X1-桁数拡張
        '↓A-20170601-X1-桁数拡張
        query.Append("," & AddParamInfo(paramInfo, "SEIR010024", DbType.String, 48, 0, 0, 更新データ.入荷ヘッダー.R010024))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010025", DbType.String, 48, 0, 0, 更新データ.入荷ヘッダー.R010025))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010026", DbType.String, 48, 0, 0, 更新データ.入荷ヘッダー.R010026))
        '↑A-20170601-X1-桁数拡張
        query.Append("," & AddParamInfo(paramInfo, "SEIR010027", DbType.AnsiStringFixedLength, 3, 0, 0, 更新データ.入荷ヘッダー.R010027))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010028", DbType.Decimal, 0, 2, 0, 更新データ.入荷ヘッダー.R010028))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010029", DbType.Decimal, 0, 1, 0, 更新データ.入荷ヘッダー.R010029))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010030", DbType.Decimal, 0, 4, 0, 更新データ.入荷ヘッダー.R010030))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010031", DbType.Decimal, 0, 1, 0, 更新データ.入荷ヘッダー.R010031))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010032", DbType.AnsiStringFixedLength, 8, 0, 0, 更新データ.入荷ヘッダー.R010032))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010033", DbType.Decimal, 0, 1, 0, 更新データ.入荷ヘッダー.R010033))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010034", DbType.Decimal, 0, 1, 0, 更新データ.入荷ヘッダー.R010034))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010035", DbType.AnsiStringFixedLength, 8, 0, 0, 更新データ.入荷ヘッダー.R010035))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010036", DbType.AnsiStringFixedLength, 2, 0, 0, 更新データ.入荷ヘッダー.R010036))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010037", DbType.AnsiStringFixedLength, 12, 0, 0, 更新データ.入荷ヘッダー.R010037))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010038", DbType.AnsiStringFixedLength, 10, 0, 0, 更新データ.入荷ヘッダー.R010038))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010039", DbType.AnsiStringFixedLength, 2, 0, 0, 更新データ.入荷ヘッダー.R010039))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010040", DbType.Decimal, 0, 1, 0, 更新データ.入荷ヘッダー.R010040))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010041", DbType.Decimal, 0, 1, 0, 更新データ.入荷ヘッダー.R010041))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010042", DbType.Decimal, 0, 1, 0, 更新データ.入荷ヘッダー.R010042))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010043", DbType.Decimal, 0, 1, 0, 更新データ.入荷ヘッダー.R010043))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010044", DbType.Decimal, 0, 1, 0, 更新データ.入荷ヘッダー.R010044))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010045", DbType.Decimal, 0, 1, 0, 更新データ.入荷ヘッダー.R010045))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010046", DbType.Decimal, 0, 10, 0, 更新データ.入荷ヘッダー.R010046))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010047", DbType.Decimal, 0, 19, 4, 更新データ.入荷ヘッダー.R010047))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010048", DbType.Decimal, 0, 19, 4, 更新データ.入荷ヘッダー.R010048))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010049", DbType.Decimal, 0, 19, 4, 更新データ.入荷ヘッダー.R010049))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010050", DbType.Decimal, 0, 19, 4, 更新データ.入荷ヘッダー.R010050))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010051", DbType.Decimal, 0, 19, 4, 更新データ.入荷ヘッダー.R010051))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010052", DbType.Decimal, 0, 19, 4, 更新データ.入荷ヘッダー.R010052))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010053", DbType.Decimal, 0, 19, 4, 更新データ.入荷ヘッダー.R010053))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010054", DbType.Decimal, 0, 19, 4, 更新データ.入荷ヘッダー.R010054))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010055", DbType.Decimal, 0, 19, 4, 更新データ.入荷ヘッダー.R010055))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010056", DbType.Decimal, 0, 19, 4, 更新データ.入荷ヘッダー.R010056))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010057", DbType.Decimal, 0, 19, 4, 更新データ.入荷ヘッダー.R010057))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010058", DbType.Decimal, 0, 19, 4, 更新データ.入荷ヘッダー.R010058))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010059", DbType.Decimal, 0, 19, 4, 更新データ.入荷ヘッダー.R010059))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010060", DbType.Decimal, 0, 19, 4, 更新データ.入荷ヘッダー.R010060))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010061", DbType.Decimal, 0, 19, 4, 更新データ.入荷ヘッダー.R010061))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010062", DbType.Decimal, 0, 19, 4, 更新データ.入荷ヘッダー.R010062))
        query.Append("," & AddParamInfo(paramInfo, "SEIR010999", DbType.Decimal, 0, 9, 0, 更新データ.入荷ヘッダー.R010999))

        'A-20121217_Ver7.50_1↓
        If MyImportParam.Myコントロール情報.MyMOAオプション.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う Then
            query.Append("," & AddParamInfo(paramInfo, "SEIR010063", DbType.Decimal, 0, 9, 4, 更新データ.入荷ヘッダー.R010063))
            query.Append("," & AddParamInfo(paramInfo, "SEIR010064", DbType.Decimal, 0, 1, 0, 更新データ.入荷ヘッダー.R010064))
            query.Append("," & AddParamInfo(paramInfo, "SEIR010065", DbType.Decimal, 0, 1, 0, 更新データ.入荷ヘッダー.R010065))
            query.Append("," & AddParamInfo(paramInfo, "SEIR010066", DbType.Decimal, 0, 19, 4, 更新データ.入荷ヘッダー.R010066))
            query.Append("," & AddParamInfo(paramInfo, "SEIR010067", DbType.Decimal, 0, 19, 4, 更新データ.入荷ヘッダー.R010067))
            query.Append("," & AddParamInfo(paramInfo, "SEIR010068", DbType.Decimal, 0, 19, 4, 更新データ.入荷ヘッダー.R010068))
            query.Append("," & AddParamInfo(paramInfo, "SEIR010069", DbType.Decimal, 0, 19, 4, 更新データ.入荷ヘッダー.R010069))
            query.Append("," & AddParamInfo(paramInfo, "SEIR010070", DbType.AnsiStringFixedLength, 20, 0, 0, 更新データ.入荷ヘッダー.R010070))
        End If
        'A-20121217_Ver7.50_1↑
        'A-20160324_1↓
        If _myImportParam.Myコントロール情報.使用条件(Myコントロール情報Param.条件型.外貨管理, 8D) = True Then
            query.Append("," & AddParamInfo(paramInfo, "SEIR010071", DbType.Decimal, 0, 1, 0, 更新データ.入荷ヘッダー.R010071))
            query.Append("," & AddParamInfo(paramInfo, "SEIR010072", DbType.Decimal, 0, 1, 0, 更新データ.入荷ヘッダー.R010072))
        End If
        'A-20160324_1↑

        query.Append(" )")

        Return query.ToString
    End Function

    'A-20130304_1↓
    Friend Function SelectSEIR010分納実績取得(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                              ByVal 発注番号 As Long,
                                              ByVal 処理連番 As Long
                   ) As String Implements IMyQueryMaker.SelectSEIR010分納実績取得    'X1変換Tool-20170508

        Dim sql As New System.Text.StringBuilder

        sql.Append(" SELECT ")
        sql.Append(" " & MyBase.QueryWrapper.AddIsNull() & " (SEIR011015, ' ') SEIR011015 ")
        sql.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SEIR011083, ' ') SEIR011083 ")
        sql.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SEIR011084, ' ') SEIR011084 ")

        sql.Append(" FROM ")
        sql.Append(Me.ExchangeTableName("SEI10R010NYUSHUKKAH ") & QueryWrapper.AddNoLock)    'X1変換Tool-20170509

        sql.Append(" INNER JOIN ")
        sql.Append(Me.ExchangeTableName("SEI10R011NYUSHUKKAM ") & QueryWrapper.AddNoLock)    'X1変換Tool-20170509
        sql.Append("  ON " & "SEIR011002 = " & "SEIR010004 ")
        sql.Append(" AND " & "SEIR011003 = " & "SEIR010005 ")
        sql.Append(" AND " & "SEIR011004 = 0 ")

        sql.Append(" WHERE SEIR010004 = 1 ")                      ' 伝票区分
        sql.Append("   AND SEIR010016 = " & AddParamInfo(paramInfo, "SEIR010016", DbType.Decimal, 0, 10, 0, 発注番号))
        If 処理連番 <> -1 Then
            sql.Append("   AND SEIR010005 <> " & AddParamInfo(paramInfo, "SEIR010005", DbType.Decimal, 0, 10, 0, 処理連番))
        End If

        sql.Append(QueryWrapper.AddUR())

        Return sql.ToString

    End Function
    'A-20130304_1↑

#End Region

#Region "■入出荷明細■"

    Public Function InsertSEIR011(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                  ByVal 更新データ As WorkTableUnitData,
                                  ByVal line As Integer) As String Implements IMyQueryMaker.InsertSEIR011    'X1変換Tool-20170508
        Dim query As New System.Text.StringBuilder

        query.Append(" INSERT INTO ")
        query.Append(Me.ExchangeTableName("SEI10R011NYUSHUKKAM"))    'X1変換Tool-20170509

        query.Append(" (")
        query.Append(" SEIR011001")
        query.Append(",SEIR011002")
        query.Append(",SEIR011003")
        query.Append(",SEIR011004")
        query.Append(",SEIR011005")
        query.Append(",SEIR011006")
        query.Append(",SEIR011007")
        query.Append(",SEIR011008")
        query.Append(",SEIR011009")
        query.Append(",SEIR011010")
        query.Append(",SEIR011011")
        query.Append(",SEIR011012")
        query.Append(",SEIR011013")
        query.Append(",SEIR011014")
        query.Append(",SEIR011015")
        query.Append(",SEIR011016")
        query.Append(",SEIR011017")
        query.Append(",SEIR011018")
        query.Append(",SEIR011019")
        query.Append(",SEIR011020")
        query.Append(",SEIR011021")
        query.Append(",SEIR011022")
        query.Append(",SEIR011023")
        query.Append(",SEIR011024")
        query.Append(",SEIR011025")
        query.Append(",SEIR011026")
        query.Append(",SEIR011027")
        query.Append(",SEIR011028")
        query.Append(",SEIR011029")
        query.Append(",SEIR011030")
        query.Append(",SEIR011031")
        query.Append(",SEIR011032")
        query.Append(",SEIR011033")
        query.Append(",SEIR011034")
        query.Append(",SEIR011035")
        query.Append(",SEIR011036")
        query.Append(",SEIR011037")
        query.Append(",SEIR011038")
        query.Append(",SEIR011039")
        query.Append(",SEIR011040")
        query.Append(",SEIR011041")
        query.Append(",SEIR011042")
        query.Append(",SEIR011043")
        query.Append(",SEIR011044")
        query.Append(",SEIR011045")
        query.Append(",SEIR011046")
        query.Append(",SEIR011047")
        query.Append(",SEIR011048")
        query.Append(",SEIR011049")
        query.Append(",SEIR011050")
        query.Append(",SEIR011051")
        query.Append(",SEIR011052")
        query.Append(",SEIR011053")
        query.Append(",SEIR011054")
        query.Append(",SEIR011055")
        query.Append(",SEIR011056")
        query.Append(",SEIR011057")
        query.Append(",SEIR011058")
        query.Append(",SEIR011059")
        query.Append(",SEIR011060")
        query.Append(",SEIR011061")
        query.Append(",SEIR011062")
        query.Append(",SEIR011063")
        query.Append(",SEIR011064")
        query.Append(",SEIR011065")
        query.Append(",SEIR011066")
        query.Append(",SEIR011067")
        query.Append(",SEIR011068")
        query.Append(",SEIR011069")
        query.Append(",SEIR011070")
        query.Append(",SEIR011071")
        query.Append(",SEIR011072")
        query.Append(",SEIR011073")
        query.Append(",SEIR011074")
        query.Append(",SEIR011075")
        query.Append(",SEIR011076")
        query.Append(",SEIR011077")
        query.Append(",SEIR011078")
        query.Append(",SEIR011079")
        query.Append(",SEIR011080")
        query.Append(",SEIR011081")
        query.Append(",SEIR011082")
        query.Append(",SEIR011083")
        query.Append(",SEIR011084")
        query.Append(",SEIR011085")
        query.Append(",SEIR011086")
        query.Append(",SEIR011087")
        query.Append(",SEIR011088")
        query.Append(",SEIR011089")
        query.Append(",SEIR011090")
        query.Append(",SEIR011091")
        query.Append(",SEIR011092")
        query.Append(",SEIR011093")
        query.Append(",SEIR011094")
        query.Append(",SEIR011095")
        query.Append(",SEIR011096")
        query.Append(",SEIR011097")
        query.Append(",SEIR011098")
        query.Append(",SEIR011099")
        query.Append(",SEIR011999")

        'A-20121217_Ver7.50_1↓
        If MyImportParam.Myコントロール情報.MyMOAオプション.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う Then
            query.Append(",SEIR011100 ")
            query.Append(",SEIR011101 ")
            query.Append(",SEIR011102 ")
            query.Append(",SEIR011103 ")
            query.Append(",SEIR011104 ")
            query.Append(",SEIR011105 ")
            query.Append(",SEIR011106 ")
            query.Append(",SEIR011107 ")
            query.Append(",SEIR011108 ")
            query.Append(",SEIR011109 ")
            query.Append(",SEIR011110 ")
            query.Append(",SEIR011111 ")
            query.Append(",SEIR011112 ")
            query.Append(",SEIR011113 ")
            query.Append(",SEIR011114 ")
            query.Append(",SEIR011115 ")
            query.Append(",SEIR011116 ")
            query.Append(",SEIR011117 ")
            query.Append(",SEIR011118 ")
            query.Append(",SEIR011119 ")
            query.Append(",SEIR011120 ")
        End If
        'A-20121217_Ver7.50_1↑
        'A-20160324_2↓
        If MyImportParam.Myコントロール情報.使用条件(Myコントロール情報Param.条件型.品目別原価計算機能, 8D) = True Then
            query.Append(",SEIR011121 ")
        End If
        'A-20160324_2↑

        query.Append(" )")
        query.Append(" VALUES (")
        query.Append(" " & AddParamInfo(paramInfo, "SEIR011001", DbType.Decimal, 0, 8, 0, 更新データ.入荷明細(line).R011001))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011002", DbType.Decimal, 0, 1, 0, 更新データ.入荷明細(line).R011002))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011003", DbType.Decimal, 0, 10, 0, 更新データ.入荷明細(line).R011003))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011004", DbType.Decimal, 0, 1, 0, 更新データ.入荷明細(line).R011004))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011005", DbType.Decimal, 0, 3, 0, 更新データ.入荷明細(line).R011005))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011006", DbType.Decimal, 0, 8, 0, 更新データ.入荷明細(line).R011006))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011007", DbType.Decimal, 0, 8, 0, 更新データ.入荷明細(line).R011007))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011008", DbType.Decimal, 0, 1, 0, 更新データ.入荷明細(line).R011008))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011009", DbType.AnsiStringFixedLength, 11, 0, 0, 更新データ.入荷明細(line).R011009))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011010", DbType.AnsiStringFixedLength, 8, 0, 0, 更新データ.入荷明細(line).R011010))

        query.Append("," & AddParamInfo(paramInfo, "SEIR011011", DbType.Decimal, 0, 2, 0, 更新データ.入荷明細(line).R011011))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011012", DbType.Decimal, 0, 10, 0, 更新データ.入荷明細(line).R011012))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011013", DbType.Decimal, 0, 3, 0, 更新データ.入荷明細(line).R011013))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011014", DbType.AnsiStringFixedLength, 8, 0, 0, 更新データ.入荷明細(line).R011014))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011015", DbType.AnsiStringFixedLength, 11, 0, 0, 更新データ.入荷明細(line).R011015))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011016", DbType.AnsiStringFixedLength, 25, 0, 0, 更新データ.入荷明細(line).R011016))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011017", DbType.String, 36, 0, 0, 更新データ.入荷明細(line).R011017))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011018", DbType.String, 4, 0, 0, 更新データ.入荷明細(line).R011018))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011019", DbType.Decimal, 0, 19, 4, 更新データ.入荷明細(line).R011019))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011020", DbType.Decimal, 0, 19, 4, 更新データ.入荷明細(line).R011020))

        query.Append("," & AddParamInfo(paramInfo, "SEIR011021", DbType.String, 4, 0, 0, 更新データ.入荷明細(line).R011021))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011022", DbType.Decimal, 0, 19, 4, 更新データ.入荷明細(line).R011022))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011023", DbType.Decimal, 0, 19, 4, 更新データ.入荷明細(line).R011023))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011024", DbType.Decimal, 0, 19, 4, 更新データ.入荷明細(line).R011024))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011025", DbType.Decimal, 0, 19, 4, 更新データ.入荷明細(line).R011025))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011026", DbType.Decimal, 0, 2, 0, 更新データ.入荷明細(line).R011026))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011027", DbType.Decimal, 0, 4, 1, 更新データ.入荷明細(line).R011027))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011028", DbType.Decimal, 0, 19, 4, 更新データ.入荷明細(line).R011028))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011029", DbType.Decimal, 0, 19, 4, 更新データ.入荷明細(line).R011029))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011030", DbType.Decimal, 0, 19, 4, 更新データ.入荷明細(line).R011030))

        query.Append("," & AddParamInfo(paramInfo, "SEIR011031", DbType.Decimal, 0, 19, 4, 更新データ.入荷明細(line).R011031))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011032", DbType.Decimal, 0, 19, 4, 更新データ.入荷明細(line).R011032))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011033", DbType.Decimal, 0, 19, 4, 更新データ.入荷明細(line).R011033))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011034", DbType.Decimal, 0, 1, 0, 更新データ.入荷明細(line).R011034))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011035", DbType.Decimal, 0, 4, 2, 更新データ.入荷明細(line).R011035))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011036", DbType.Decimal, 0, 19, 4, 更新データ.入荷明細(line).R011036))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011037", DbType.Decimal, 0, 1, 0, 更新データ.入荷明細(line).R011037))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011038", DbType.AnsiStringFixedLength, 5, 0, 0, 更新データ.入荷明細(line).R011038))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011039", DbType.String, 12, 0, 0, 更新データ.入荷明細(line).R011039))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011040", DbType.String, 12, 0, 0, 更新データ.入荷明細(line).R011040))

        query.Append("," & AddParamInfo(paramInfo, "SEIR011041", DbType.Decimal, 0, 19, 4, 更新データ.入荷明細(line).R011041))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011042", DbType.Decimal, 0, 19, 4, 更新データ.入荷明細(line).R011042))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011043", DbType.Decimal, 0, 19, 4, 更新データ.入荷明細(line).R011043))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011044", DbType.Decimal, 0, 19, 4, 更新データ.入荷明細(line).R011044))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011045", DbType.Decimal, 0, 19, 4, 更新データ.入荷明細(line).R011045))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011046", DbType.Decimal, 0, 4, 0, 更新データ.入荷明細(line).R011046))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011047", DbType.Decimal, 0, 8, 0, 更新データ.入荷明細(line).R011047))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011048", DbType.Decimal, 0, 4, 0, 更新データ.入荷明細(line).R011048))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011049", DbType.Decimal, 0, 1, 0, 更新データ.入荷明細(line).R011049))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011050", DbType.String, 3, 0, 0, 更新データ.入荷明細(line).R011050))

        query.Append("," & AddParamInfo(paramInfo, "SEIR011051", DbType.Decimal, 0, 1, 0, 更新データ.入荷明細(line).R011051))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011052", DbType.Decimal, 0, 1, 0, 更新データ.入荷明細(line).R011052))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011053", DbType.Decimal, 0, 2, 0, 更新データ.入荷明細(line).R011053))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011054", DbType.Decimal, 0, 1, 0, 更新データ.入荷明細(line).R011054))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011055", DbType.Decimal, 0, 1, 0, 更新データ.入荷明細(line).R011055))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011056", DbType.Decimal, 0, 1, 0, 更新データ.入荷明細(line).R011056))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011057", DbType.Decimal, 0, 19, 4, 更新データ.入荷明細(line).R011057))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011058", DbType.AnsiStringFixedLength, 8, 0, 0, 更新データ.入荷明細(line).R011058))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011059", DbType.AnsiStringFixedLength, 4, 0, 0, 更新データ.入荷明細(line).R011059))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011060", DbType.String, 36, 0, 0, 更新データ.入荷明細(line).R011060))

        query.Append("," & AddParamInfo(paramInfo, "SEIR011061", DbType.String, 36, 0, 0, 更新データ.入荷明細(line).R011061))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011062", DbType.String, 20, 0, 0, 更新データ.入荷明細(line).R011062))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011063", DbType.AnsiStringFixedLength, 12, 0, 0, 更新データ.入荷明細(line).R011063))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011064", DbType.AnsiStringFixedLength, 10, 0, 0, 更新データ.入荷明細(line).R011064))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011065", DbType.AnsiStringFixedLength, 2, 0, 0, 更新データ.入荷明細(line).R011065))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011066", DbType.AnsiStringFixedLength, 20, 0, 0, 更新データ.入荷明細(line).R011066))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011067", DbType.Decimal, 0, 1, 0, 更新データ.入荷明細(line).R011067))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011068", DbType.Decimal, 0, 1, 0, 更新データ.入荷明細(line).R011068))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011069", DbType.Decimal, 0, 1, 0, 更新データ.入荷明細(line).R011069))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011070", DbType.AnsiStringFixedLength, 11, 0, 0, 更新データ.入荷明細(line).R011070))

        query.Append("," & AddParamInfo(paramInfo, "SEIR011071", DbType.Decimal, 0, 19, 4, 更新データ.入荷明細(line).R011071))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011072", DbType.String, 4, 0, 0, 更新データ.入荷明細(line).R011072))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011073", DbType.Decimal, 0, 19, 4, 更新データ.入荷明細(line).R011073))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011074", DbType.Decimal, 0, 1, 0, 更新データ.入荷明細(line).R011074))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011075", DbType.Decimal, 0, 10, 0, 更新データ.入荷明細(line).R011075))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011076", DbType.Decimal, 0, 10, 0, 更新データ.入荷明細(line).R011076))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011077", DbType.Decimal, 0, 1, 0, 更新データ.入荷明細(line).R011077))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011078", DbType.Decimal, 0, 1, 0, 更新データ.入荷明細(line).R011078))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011079", DbType.Decimal, 0, 10, 0, 更新データ.入荷明細(line).R011079))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011080", DbType.Decimal, 0, 19, 4, 更新データ.入荷明細(line).R011080))

        query.Append("," & AddParamInfo(paramInfo, "SEIR011081", DbType.AnsiStringFixedLength, 6, 0, 0, 更新データ.入荷明細(line).R011081))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011082", DbType.Decimal, 0, 1, 0, 更新データ.入荷明細(line).R011082))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011083", DbType.AnsiStringFixedLength, 10, 0, 0, 更新データ.入荷明細(line).R011083))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011084", DbType.AnsiStringFixedLength, 20, 0, 0, 更新データ.入荷明細(line).R011084))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011085", DbType.Decimal, 0, 19, 4, 更新データ.入荷明細(line).R011085))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011086", DbType.Decimal, 0, 19, 4, 更新データ.入荷明細(line).R011086))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011087", DbType.Decimal, 0, 1, 0, 更新データ.入荷明細(line).R011087))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011088", DbType.Decimal, 0, 8, 0, 更新データ.入荷明細(line).R011088))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011089", DbType.Decimal, 0, 19, 4, 更新データ.入荷明細(line).R011089))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011090", DbType.Decimal, 0, 10, 0, 更新データ.入荷明細(line).R011090))

        query.Append("," & AddParamInfo(paramInfo, "SEIR011091", DbType.Decimal, 0, 3, 0, 更新データ.入荷明細(line).R011091))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011092", DbType.Decimal, 0, 10, 0, 更新データ.入荷明細(line).R011092))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011093", DbType.Decimal, 0, 3, 0, 更新データ.入荷明細(line).R011093))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011094", DbType.Decimal, 0, 19, 4, 更新データ.入荷明細(line).R011094))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011095", DbType.Decimal, 0, 19, 4, 更新データ.入荷明細(line).R011095))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011096", DbType.Decimal, 0, 10, 0, 更新データ.入荷明細(line).R011096))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011097", DbType.Decimal, 0, 3, 0, 更新データ.入荷明細(line).R011097))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011098", DbType.Decimal, 0, 1, 0, 更新データ.入荷明細(line).R011098))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011099", DbType.Decimal, 0, 1, 0, 更新データ.入荷明細(line).R011099))
        query.Append("," & AddParamInfo(paramInfo, "SEIR011999", DbType.Decimal, 0, 9, 0, 更新データ.入荷明細(line).R011999))

        'A-20121217_Ver7.50_1↓
        If MyImportParam.Myコントロール情報.MyMOAオプション.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う Then
            query.Append("," & AddParamInfo(paramInfo, "SEIR011100", DbType.Decimal, 0, 19, 4, 更新データ.入荷明細(line).R011100))
            query.Append("," & AddParamInfo(paramInfo, "SEIR011101", DbType.Decimal, 0, 19, 4, 更新データ.入荷明細(line).R011101))
            query.Append("," & AddParamInfo(paramInfo, "SEIR011102", DbType.Decimal, 0, 19, 4, 更新データ.入荷明細(line).R011102))
            query.Append("," & AddParamInfo(paramInfo, "SEIR011103", DbType.Decimal, 0, 19, 4, 更新データ.入荷明細(line).R011103))
            query.Append("," & AddParamInfo(paramInfo, "SEIR011104", DbType.Decimal, 0, 19, 4, 更新データ.入荷明細(line).R011104))
            query.Append("," & AddParamInfo(paramInfo, "SEIR011105", DbType.Decimal, 0, 19, 4, 更新データ.入荷明細(line).R011105))
            query.Append("," & AddParamInfo(paramInfo, "SEIR011106", DbType.Decimal, 0, 19, 4, 更新データ.入荷明細(line).R011106))
            query.Append("," & AddParamInfo(paramInfo, "SEIR011107", DbType.Decimal, 0, 19, 4, 更新データ.入荷明細(line).R011107))
            query.Append("," & AddParamInfo(paramInfo, "SEIR011108", DbType.Decimal, 0, 19, 4, 更新データ.入荷明細(line).R011108))
            query.Append("," & AddParamInfo(paramInfo, "SEIR011109", DbType.Decimal, 0, 19, 4, 更新データ.入荷明細(line).R011109))
            query.Append("," & AddParamInfo(paramInfo, "SEIR011110", DbType.Decimal, 0, 19, 4, 更新データ.入荷明細(line).R011110))
            query.Append("," & AddParamInfo(paramInfo, "SEIR011111", DbType.Decimal, 0, 19, 4, 更新データ.入荷明細(line).R011111))
            query.Append("," & AddParamInfo(paramInfo, "SEIR011112", DbType.AnsiStringFixedLength, 20, 0, 0, 更新データ.入荷明細(line).R011112))
            query.Append("," & AddParamInfo(paramInfo, "SEIR011113", DbType.Decimal, 0, 1, 0, 更新データ.入荷明細(line).R011113))
            query.Append("," & AddParamInfo(paramInfo, "SEIR011114", DbType.Decimal, 0, 1, 0, 更新データ.入荷明細(line).R011114))
            query.Append("," & AddParamInfo(paramInfo, "SEIR011115", DbType.Decimal, 0, 1, 0, 更新データ.入荷明細(line).R011115))
            query.Append("," & AddParamInfo(paramInfo, "SEIR011116", DbType.String, 36, 0, 0, 更新データ.入荷明細(line).R011116))
            query.Append("," & AddParamInfo(paramInfo, "SEIR011117", DbType.String, 36, 0, 0, 更新データ.入荷明細(line).R011117))
            query.Append("," & AddParamInfo(paramInfo, "SEIR011118", DbType.String, 36, 0, 0, 更新データ.入荷明細(line).R011118))
            query.Append("," & AddParamInfo(paramInfo, "SEIR011119", DbType.String, 10, 0, 0, 更新データ.入荷明細(line).R011119))
            query.Append("," & AddParamInfo(paramInfo, "SEIR011120", DbType.String, 10, 0, 0, 更新データ.入荷明細(line).R011120))
        End If
        'A-20121217_Ver7.50_1↑
        'A-20160324_2↓
        If MyImportParam.Myコントロール情報.使用条件(Myコントロール情報Param.条件型.品目別原価計算機能, 8D) = True Then
            query.Append("," & AddParamInfo(paramInfo, "SEIR011121", DbType.Decimal, 0, 10, 0, 更新データ.入荷明細(line).R011121))
        End If
        'A-20160324_2↑

        query.Append(" )")

        Return query.ToString
    End Function

#End Region

#Region "■費目マスター■"

    Public Function SelectSEIM012PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal 費目コード As String
                    ) As String Implements IMyQueryMaker.SelectSEIM012PrimaryKey    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(" SEIM012001 ")
        query.Append("FROM " & MyBase.ExchangeTableName("SEI10M012HIMOKU") & " ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())
        query.Append("WHERE ")
        query.Append("SEIM012001 = " & AddParamInfo(paramInfo, "SEIM012001", DbType.AnsiStringFixedLength, 6, 0, 0, 費目コード))
        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString

    End Function

#End Region

#Region "■製番マスター■"

    '存在チェック
    Public Function SelectSEIM050PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal 製番 As String
                    ) As String Implements IMyQueryMaker.SelectSEIM050PrimaryKey    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(" SEIM050001 ")
        query.Append(",SEIM050002 ")        'A-20111025_1
        query.Append(",SEIM050003 ")        'A-20111025_2
        query.Append(",SEIM050015 ")        'A-20111025_1
        query.Append(",SEIM050016 ")        'A-20111025_1
        query.Append(",SEIM050019 ")
        query.Append(",SEIM050020 ")
        query.Append(",SEIM050021 ")
        query.Append(",SEIM050022 ")
        query.Append(",SEIM050039 ")

        'A-20150520_2↓
        If MyImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 7D Then
            query.Append(",SEIM050046 ")
        End If
        'A-20150520_2↑

        query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANR005A011, ' ') HANR005A011 ")

        query.Append("FROM " & MyBase.ExchangeTableName("SEI10M050SEIMST") & " ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())

        query.Append(" LEFT OUTER JOIN ")
        query.Append(Me.ExchangeTableName("HAN10R005JUHACHUM ") & " " & QueryWrapper.AddNoLock())    'X1変換Tool-20170509
        query.Append("  ON HANR005002 = 2 ")
        query.Append(" AND HANR005003 = SEIM050019 ")
        query.Append(" AND HANR005004 = SEIM050020 ")

        query.Append(" WHERE ")
        query.Append(" SEIM050001 = " & AddParamInfo(paramInfo, "SEIM050001", DbType.AnsiStringFixedLength, 12, 0, 0, 製番))
        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString

    End Function

    Public Function UpdateSEIM050(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                  ByVal 更新データ As WorkTableUnitData,
                                  ByVal line As Integer) As String Implements IMyQueryMaker.UpdateSEIM050    'X1変換Tool-20170508
        Dim query As New System.Text.StringBuilder

        query.Append(" UPDATE ")
        query.Append(Me.ExchangeTableName("SEI10M050SEIMST"))    'X1変換Tool-20170509

        query.Append(" SET ")
        query.Append(" SEIM050003 = " & AddParamInfo(paramInfo, "SEIM050003", DbType.Decimal, 0, 1, 0, 更新データ.製番マスタ(line).M050003))
        If 更新データ.製番マスタ(line).M050038 <> -1 Then
            query.Append(",SEIM050038 = " & AddParamInfo(paramInfo, "SEIM050038", DbType.Decimal, 0, 8, 0, 更新データ.製番マスタ(line).M050038))
        End If

        query.Append(" WHERE SEIM050011 = " & AddParamInfo(paramInfo, "SEIM050011", DbType.Decimal, 0, 10, 0, 更新データ.製番マスタ(line).M050011))
        query.Append("   AND SEIM050015 = " & AddParamInfo(paramInfo, "SEIM050015", DbType.Decimal, 0, 1, 0, 更新データ.製番マスタ(line).M050015))

        Return query.ToString
    End Function

    'A-20111025_3↓
    Public Function UpdateSEIM050_手入力製番(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                             ByVal 更新データ As WorkTableUnitData) As String Implements IMyQueryMaker.UpdateSEIM050_手入力製番    'X1変換Tool-20170508
        Dim query As New System.Text.StringBuilder

        query.Append(" UPDATE ")
        query.Append(Me.ExchangeTableName("SEI10M050SEIMST"))    'X1変換Tool-20170509

        query.Append(" SET ")
        query.Append(" SEIM050003 = " & AddParamInfo(paramInfo, "SEIM050003", DbType.Decimal, 0, 1, 0, 更新データ.製番マスタ_更新用.M050003))
        query.Append(",SEIM050004 = " & AddParamInfo(paramInfo, "SEIM050004", DbType.AnsiStringFixedLength, 25, 0, 0, 更新データ.製番マスタ_更新用.M050004))
        query.Append(",SEIM050005 = " & AddParamInfo(paramInfo, "SEIM050005", DbType.String, 36, 0, 0, 更新データ.製番マスタ_更新用.M050005))
        query.Append(",SEIM050006 = " & AddParamInfo(paramInfo, "SEIM050006", DbType.String, 36, 0, 0, 更新データ.製番マスタ_更新用.M050006))
        query.Append(",SEIM050007 = " & AddParamInfo(paramInfo, "SEIM050007", DbType.String, 36, 0, 0, 更新データ.製番マスタ_更新用.M050007))
        query.Append(",SEIM050008 = " & AddParamInfo(paramInfo, "SEIM050008", DbType.String, 20, 0, 0, 更新データ.製番マスタ_更新用.M050008))
        query.Append(",SEIM050015 = " & AddParamInfo(paramInfo, "SEIM050015", DbType.Decimal, 0, 1, 0, 更新データ.製番マスタ_更新用.M050015))
        query.Append(",SEIM050038 = " & AddParamInfo(paramInfo, "SEIM050038", DbType.Decimal, 0, 8, 0, 更新データ.製番マスタ_更新用.M050038))

        query.Append(" WHERE SEIM050001 = " & AddParamInfo(paramInfo, "SEIM050001", DbType.AnsiStringFixedLength, 12, 0, 0, 更新データ.製番マスタ_更新用.M050001))

        Return query.ToString
    End Function
    'A-20111025_3↑

#End Region

#Region "■工程マスター■"

    '存在チェック
    Public Function SelectSEIM053PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal 工程コード As String
                    ) As String Implements IMyQueryMaker.SelectSEIM053PrimaryKey    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(" SEIM053001 ")
        query.Append(",SEIM053002 ")

        query.Append("FROM " & MyBase.ExchangeTableName("SEI10M053KOTEIMEI") & " ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())

        query.Append(" WHERE ")
        query.Append(" SEIM053001 = " & AddParamInfo(paramInfo, "SEIM053001", DbType.AnsiStringFixedLength, 11, 0, 0, 工程コード))
        query.Append(" AND ")
        query.Append(" SEIM053015 = 1 ")    '内外工程=1:社外
        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString

    End Function

#End Region

#Region "■品目別ロット№テーブル■"

    Public Function SelectSEIR009PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal 商品コード As String,
                                            ByVal ロットNO As String
                ) As String Implements IMyQueryMaker.SelectSEIR009PrimaryKey    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(" SEIR009001 ")
        query.Append(",SEIR009002 ")
        query.Append(",SEIR009003 ")

        query.Append("FROM " & MyBase.ExchangeTableName("SEI10R009SHOHINLOT") & " ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())

        query.Append(" WHERE ")
        query.Append(" SEIR009001 = " & AddParamInfo(paramInfo, "SEIR009001", DbType.AnsiStringFixedLength, 25, 0, 0, 商品コード))
        query.Append(" AND ")
        query.Append(" SEIR009002 = " & AddParamInfo(paramInfo, "SEIR009002", DbType.AnsiStringFixedLength, 20, 0, 0, ロットNO))

        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString
    End Function

#End Region

#Region "■手配テーブル■"

    Public Function SelectSEIR055PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal 手配番号 As Long) As String Implements IMyQueryMaker.SelectSEIR055PrimaryKey    'X1変換Tool-20170508
        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(" SEIR055001 ")                                                    '手配伝票区分
        query.Append(", SEIR055002 ")                                                   '手配番号
        query.Append(", SEIR055010 ")                                                   '製番           'A-20160324_2
        query.Append(", SEIR055018 ")                                                   '手順№
        query.Append(", SEIR055068 ")                                                   '手配管理番号

        query.Append(", SEIR055024 ")                                                   '手配数量
        query.Append(", SEIR055045 ")                                                   '報告済数量
        query.Append(", SEIR055067 ")                                                   '最終工程区分   'A-20111025_4
        query.Append(", SEIR055082 ")                                                   '
        query.Append(", SEIR055085 ")                                                   '手配数量(在庫単位)

        'A-20120125_1↓
        query.Append(", SEIR055013 ")                                                   '品目コード
        query.Append(", SEIR055021 ")                                                   '手配先コード
        query.Append(", SEIR055087 ")                                                   '発注単位変換係数
        'A-20120125_1↑
        query.Append(", SEIR055046 ")                                                   '報告回数       'A-20150713_1

        query.Append("FROM " & MyBase.ExchangeTableName("SEI10R055TEHAI"))    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())

        '--------------------
        '   検索条件
        '--------------------
        query.Append("WHERE SEIR055002 = " & AddParamInfo(paramInfo, "SEIR055002", DbType.Decimal, 0, 10, 0, 手配番号) & " ")

        query.Append("ORDER BY SEIR055002")
        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString
    End Function

    Public Function SelectSEIR055前後工程取得(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                              ByVal 手配管理番号 As Long,
                                              ByVal 手順番号 As Integer,
                                              ByVal 前後工程 As Integer) As String Implements IMyQueryMaker.SelectSEIR055前後工程取得    'X1変換Tool-20170508
        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(" SEIR055001 ")                                                    '手配伝票区分
        query.Append(", SEIR055002 ")                                                   '手配番号
        query.Append(", SEIR055018 ")                                                   '手順№
        query.Append(", SEIR055068 ")                                                   '手配管理番号

        '前後工程チェック用
        query.Append(", SEIR055045 ")                                                   '報告済数量
        query.Append(", SEIR055082 ")                                                   '不良数量

        'A-20120125_1↓
        query.Append(", SEIR055013 ")                                                   '品目コード
        query.Append(", SEIR055021 ")                                                   '手配先コード
        'A-20120125_1↑

        query.Append("FROM " & MyBase.ExchangeTableName("SEI10R055TEHAI"))    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())

        '--------------------
        '   検索条件
        '--------------------
        query.Append("WHERE SEIR055068 = " & AddParamInfo(paramInfo, "SEIR055068", DbType.Decimal, 0, 10, 0, 手配管理番号) & " ")
        If 前後工程 = 0 Then
            '前工程
            query.Append("  AND SEIR055018 < " & AddParamInfo(paramInfo, "SEIR055018", DbType.Decimal, 0, 5, 0, 手順番号) & " ")
            query.Append("ORDER BY SEIR055018 DESC")
        Else
            '後工程
            query.Append("  AND SEIR055018 > " & AddParamInfo(paramInfo, "SEIR055018", DbType.Decimal, 0, 5, 0, 手順番号) & " ")
            query.Append("ORDER BY SEIR055018")
        End If

        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString
    End Function

    'A-20160324_2↓
    Public Function SelectSEIR055_SEIM050同時取得(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                                  ByVal 手配番号 As Long) As String Implements IMyQueryMaker.SelectSEIR055_SEIM050同時取得    'X1変換Tool-20170508
        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(" SEIR055001 ")                                                   '手配伝票区分
        query.Append(",SEIR055002 ")                                                   '手配番号
        query.Append(",SEIR055010 ")                                                   '製番    
        query.Append(",SEIM050016 ")                                                   '内外区分

        '*** 製番M ***
        query.Append(",SEIM050001 ")
        query.Append(",SEIM050002 ")
        query.Append(",SEIM050003 ")
        query.Append(",SEIM050015 ")
        query.Append(",SEIM050016 ")
        query.Append(",SEIM050019 ")
        query.Append(",SEIM050020 ")
        query.Append(",SEIM050021 ")
        query.Append(",SEIM050022 ")
        query.Append(",SEIM050039 ")
        If MyImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 7D Then
            query.Append(",SEIM050046 ")
        End If

        '*** 受発注明細 ***
        query.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANR005A011, ' ') HANR005A011 ")    '客先注番

        query.Append("FROM " & MyBase.ExchangeTableName("SEI10R055TEHAI"))    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())

        query.Append("INNER JOIN " & MyBase.ExchangeTableName("SEI10M050SEIMST"))    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())
        query.Append(" ON SEIR055010 = SEIM050001 ")

        query.Append(" LEFT OUTER JOIN ")
        query.Append(Me.ExchangeTableName("HAN10R005JUHACHUM ") & " " & QueryWrapper.AddNoLock())    'X1変換Tool-20170509
        query.Append("  ON HANR005002 = 2 ")
        query.Append(" AND HANR005003 = SEIM050019 ")
        query.Append(" AND HANR005004 = SEIM050020 ")
        '--------------------
        '   検索条件
        '--------------------
        query.Append("WHERE SEIR055002 = " & AddParamInfo(paramInfo, "SEIR055002", DbType.Decimal, 0, 10, 0, 手配番号) & " ")

        query.Append("ORDER BY SEIR055002")
        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString
    End Function
    'A-20160324_2↑

#End Region
    'A-20110912_1↓
#Region "■手配予定テーブル■"
    Public Function SelectSEIW053前後工程仕掛取得(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                              ByVal 手配管理番号 As Long,
                                              ByVal 手順番号F As Integer,
                                              ByVal 手順番号T As Integer) As String Implements IMyQueryMaker.SelectSEIW053前後工程仕掛取得    'X1変換Tool-20170508
        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(" SEIW053002 ")                                                   '計算処理連番

        query.Append("FROM " & MyBase.ExchangeTableName("SEI10W053TEHAIYOTEI"))    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())

        '--------------------
        '   検索条件
        '--------------------
        query.Append("WHERE SEIW053055 = " & AddParamInfo(paramInfo, "SEIR055068", DbType.Decimal, 0, 10, 0, 手配管理番号) & " ")
        If 手順番号F <> -1 Then     'A-20111025_4
            query.Append("  AND SEIW053016 > " & AddParamInfo(paramInfo, "SEIR055018F", DbType.Decimal, 0, 5, 0, 手順番号F) & " ")
        End If                      'A-20111025_4
        If 手順番号T <> -1 Then     'A-20111025_4
            query.Append("  AND SEIW053016 < " & AddParamInfo(paramInfo, "SEIR055018T", DbType.Decimal, 0, 5, 0, 手順番号T) & " ")
        End If 'A-20111025_4

        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString
    End Function
#End Region
    'A-20110912_1↑
#Region "■従属需要テーブル■"

    Public Function SelectSEIR056PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal 手配番号 As Long,
                                            ByVal 展開順序番号 As Integer,
                                            ByVal 支給管理 As Integer) As String Implements IMyQueryMaker.SelectSEIR056PrimaryKey    'X1変換Tool-20170508
        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(" SEIR056001 ")                                                    '手配伝票区分
        query.Append(", SEIR056002 ")                                                   '手配番号
        query.Append(", SEIR056003 ")                                                   '展開順序番号
        query.Append(", SEIR056004 ")                                                   '部番
        query.Append(", SEIR056005 ")                                                   '操作日付
        query.Append(", " & QueryWrapper.AddIsNull() & "(SEIR056006, ' ') SEIR056006 ") 'ログインID
        query.Append(", SEIR056007 ")                                                   '品目コード
        query.Append(", " & QueryWrapper.AddIsNull() & "(SEIR056008, ' ') SEIR056008 ") '品目名
        query.Append(", " & QueryWrapper.AddIsNull() & "(SEIR056009, ' ') SEIR056009 ") '品目名１
        query.Append(", " & QueryWrapper.AddIsNull() & "(SEIR056010, ' ') SEIR056010 ") '品目名２
        query.Append(", " & QueryWrapper.AddIsNull() & "(SEIR056011, ' ') SEIR056011 ") '品目名３                                                  
        query.Append(", SEIR056012 ")                                                   '子部品出庫予定び
        query.Append(", SEIR056013 ")                                                   '倉庫コード
        query.Append(", SEIR056014 ")                                                   'ロケーション
        query.Append(", SEIR056015 ")                                                   '製番
        query.Append(", SEIR056016 ")                                                   '製番（メイン）
        query.Append(", SEIR056017 ")                                                   '製番（枝番）
        query.Append(", SEIR056018 ")                                                   '品目コード（親品目）
        query.Append(", SEIR056019 ")                                                   '手順№
        query.Append(", SEIR056020 ")                                                   '工程コード
        query.Append(", SEIR056021 ")                                                   '手配先コード
        query.Append(", SEIR056022 ")                                                   '支給/出庫予定数量
        query.Append(", " & QueryWrapper.AddIsNull() & "(SEIR056023, ' ') SEIR056023 ") '数量単位

        query.Append(", SEIR056024 ")                                                   '予定単価計算区分
        query.Append(", SEIR056025 ")                                                   '支給予定単価
        query.Append(", SEIR056026 ")                                                   '支給予定金額
        query.Append(", SEIR056027 ")                                                   '引落数量
        query.Append(", SEIR056028 ")                                                   '支給（出庫）済数量
        query.Append(", SEIR056029 ")                                                   '有償支給数量
        query.Append(", SEIR056030 ")                                                   '無償支給数量
        query.Append(", SEIR056031 ")                                                   '支給済金額
        query.Append(", SEIR056032 ")                                                   '出庫累計回数
        query.Append(", SEIR056033 ")                                                   '出庫残区分
        query.Append(", SEIR056034 ")                                                   '原単位区分
        query.Append(", SEIR056035 ")                                                   '取数（分子）
        query.Append(", SEIR056036 ")                                                   '取数（分母）
        query.Append(", SEIR056037 ")                                                   '支給区分
        query.Append(", SEIR056038 ")                                                   '不良率
        query.Append(", SEIR056039 ")                                                   '使用工程コード
        query.Append(", SEIR056040 ")                                                   '単価計算方法
        query.Append(", SEIR056041 ")                                                   '単価掛率
        query.Append(", SEIR056042 ")                                                   '標準売上単価
        query.Append(", SEIR056043 ")                                                   '標準仕入単価
        query.Append(", SEIR056044 ")                                                   '標準支給単価
        query.Append(", SEIR056045 ")                                                   '強制完納区分（出庫）
        query.Append(", SEIR056046 ")                                                   'オーダー製番
        query.Append(", SEIR056047 ")                                                   '課税区分
        query.Append(", SEIR056048 ")                                                   '費目コード
        query.Append(", SEIR056049 ")                                                   '費目区分
        query.Append(", SEIR056050 ")                                                   '発注番号
        query.Append(", SEIR056051 ")                                                   '品目連番
        query.Append(", SEIR056052 ")                                                   '手配管理番号
        query.Append(", SEIR056053 ")                                                   '支給累計回数
        query.Append(", SEIR056054 ")                                                   '支給残区分
        query.Append(", SEIR056055 ")                                                   '強制完納区分（支給）
        query.Append(", SEIR056999 ")                                                   '更新番号

        query.Append(", " & QueryWrapper.AddIsNull() & "(HANM003002, ' ') HANM003002 ") '品目名
        query.Append(", " & QueryWrapper.AddIsNull() & "(HANM003004, ' ') HANM003004 ") '単位
        query.Append(", " & QueryWrapper.AddIsNull() & "(HANM003008, 0) HANM003008 ")   '在庫管理区分
        query.Append(", " & QueryWrapper.AddIsNull() & "(HANM003016, 0) HANM003016 ")   '在庫評価単価
        query.Append(", " & QueryWrapper.AddIsNull() & "(HANM003036, 0) HANM003036 ")   '在庫評価単価(変更後単価)
        query.Append(", " & QueryWrapper.AddIsNull() & "(HANM003039, 0) HANM003039 ")   '単価変更日付
        query.Append(", " & QueryWrapper.AddIsNull() & "(HANM003040, 0) HANM003040 ")   '期間単価対象日付
        query.Append(", " & QueryWrapper.AddIsNull() & "(HANM003041, 0) HANM003041 ")   '変更後単価使用区分
        query.Append(", " & QueryWrapper.AddIsNull() & "(HANM003075, 0) HANM003075 ")   '在庫評価区分
        query.Append(", " & QueryWrapper.AddIsNull() & "(HANM003A013, 0) HANM003A013 ")   '需要数計算単位
        query.Append(", " & QueryWrapper.AddIsNull() & "(HANM003A024, 0) HANM003A024 ")   'ロット管理区分
        query.Append(", " & QueryWrapper.AddIsNull() & "(HANM003A026, 0) HANM003A026 ")   '発注単位変換係数
        query.Append(", " & QueryWrapper.AddIsNull() & "(HANM003A033, 0) HANM003A033 ")   '有効期間
        query.Append(", " & QueryWrapper.AddIsNull() & "(HANM003A034, 0) HANM003A034 ")   '有効期間単位
        query.Append(", " & QueryWrapper.AddIsNull() & "(HANM003A010, ' ') HANM003A010 ") '基準倉庫コード
        query.Append(", " & QueryWrapper.AddIsNull() & "(HANM003A027, ' ') HANM003A027 ") '基準ロケーション
        query.Append(", " & QueryWrapper.AddIsNull() & "(HANM003A028, 0) HANM003A028 ")   '品目区分
        query.Append(", " & QueryWrapper.AddIsNull() & "(HANM003A029, 0) HANM003A029 ")   '使用禁止日
        query.Append(", " & QueryWrapper.AddIsNull() & "(HANM003A030, 0) HANM003A030 ")   '材料費
        query.Append(", " & QueryWrapper.AddIsNull() & "(HANM003A031, 0) HANM003A031 ")   '労務費
        query.Append(", " & QueryWrapper.AddIsNull() & "(HANM003A032, 0) HANM003A032 ")   '外注費

        'A-20141105_1↓
        If MyImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 6D Then
            query.Append(", " & QueryWrapper.AddIsNull() & "(HANM003S030, 0) HANM003S030 ")   '経費
        End If
        'A-20141105_1↑

        query.Append(", " & QueryWrapper.AddIsNull() & "(HANM006002, ' ') HANM006002 ")   '倉庫名
        query.Append(", " & QueryWrapper.AddIsNull() & "(HANM006003, ' ') HANM006003 ")   '倉庫略称
        query.Append(", " & QueryWrapper.AddIsNull() & "(HANM006A001, 0) HANM006A001 ") '倉庫区分
        query.Append(", " & QueryWrapper.AddIsNull() & "(HANM006A002, 0) HANM006A002 ") '所要量計算対象区分

        query.Append("FROM " & MyBase.ExchangeTableName("SEI10R056JUZOKU"))    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())

        query.Append("LEFT OUTER JOIN " & MyBase.ExchangeTableName("HAN10M003SHOHIN") & " ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())
        query.Append("   ON HANM003001 = SEIR056007 ")

        query.Append("LEFT OUTER JOIN " & MyBase.ExchangeTableName("HAN10M006SOKO") & " ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())
        query.Append("   ON HANM006001 = SEIR056013 ")

        '--------------------
        '   検索条件
        '--------------------
        query.Append("WHERE SEIR056002 = " & AddParamInfo(paramInfo, "HANR056002", DbType.Decimal, 0, 10, 0, 手配番号) & " ")
        query.Append("  AND SEIR056003 = " & AddParamInfo(paramInfo, "SEIR056003", DbType.Decimal, 0, 5, 0, 展開順序番号) & " ")

        If 支給管理 = 1 Then
            '支給管理=1:行う 場合
            query.Append(" AND SEIR056037 = 0 ")
        Else
            query.Append(" AND (SEIR056037 = 0 ")
            query.Append("  OR  SEIR056037 = 1) ")
        End If

        query.Append("ORDER BY SEIR056003")
        query.Append(MyBase.QueryWrapper.AddUR())


        Return query.ToString
    End Function

#End Region

#Region "■工程明細テーブル■"

    Public Function SelectSEIR057PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal 手配番号 As Long) As String Implements IMyQueryMaker.SelectSEIR057PrimaryKey    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(" " & QueryWrapper.AddIsNull() & "(SEIR057016, ' ') SEIR057016 ")        '品目コード
        query.Append("," & QueryWrapper.AddIsNull() & "(SEIR057052, ' ') SEIR057052 ")        'ロット№
        query.Append("," & QueryWrapper.AddIsNull() & "(SEIR057004, ' ') SEIR057004 ")        '報告連番      'A-20121217_Ver7.50_2

        query.Append("FROM " & MyBase.ExchangeTableName("SEI10R057KOTEI"))    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())

        query.Append(" WHERE SEIR057012 = " & AddParamInfo(paramInfo, "SEIR057012", DbType.Decimal, 0, 10, 0, 手配番号))

        query.Append(" ORDER BY SEIR057001 DESC")
        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString

    End Function

    'A-20121217_Ver7.50_2↓
    Public Function SelectSEIR057工程明細取得(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                              ByVal 処理連番 As Long) As String Implements IMyQueryMaker.SelectSEIR057工程明細取得    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(" " & QueryWrapper.AddIsNull() & "(SEIR057016, ' ') SEIR057016 ")        '品目コード
        query.Append("," & QueryWrapper.AddIsNull() & "(SEIR057052, ' ') SEIR057052 ")        'ロット№
        query.Append("," & QueryWrapper.AddIsNull() & "(SEIR057004, ' ') SEIR057004 ")        '報告連番

        query.Append("FROM " & MyBase.ExchangeTableName("SEI10R057KOTEI"))    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())

        query.Append(" WHERE SEIR057048 = " & AddParamInfo(paramInfo, "SEIR057048", DbType.Decimal, 0, 10, 0, 処理連番))

        query.Append(" ORDER BY SEIR057004")
        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString

    End Function
    'A-20121217_Ver7.50_2↑

    Public Function SelectSEIR057実績数量合計(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                              ByVal 手配番号 As Long) As String Implements IMyQueryMaker.SelectSEIR057実績数量合計    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(" " & QueryWrapper.AddIsNull() & "(SEIR057016, ' ') 品目コード ")      '品目コード
        query.Append("," & QueryWrapper.AddIsNull() & "(SEIR057052, ' ') ロットNo ")        'ロット№
        query.Append("," & QueryWrapper.AddIsNull() & "(SUM(SEIR057027), 0) 受入数量合計 ") '受入数量合計
        query.Append("," & QueryWrapper.AddIsNull() & "(SUM(SEIR057028), 0) 不良数量合計 ") '不良数量合計

        query.Append("FROM " & MyBase.ExchangeTableName("SEI10R057KOTEI"))    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())

        query.Append(" WHERE SEIR057002 = 1")
        query.Append(" AND SEIR057012 = " & AddParamInfo(paramInfo, "SEIR057012", DbType.Decimal, 0, 10, 0, 手配番号))

        query.Append(" GROUP BY SEIR057016,SEIR057052")
        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString

    End Function

#End Region

#Region "■ロット連番管理テーブル■"

    Public Function SelectSEIC056PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal 管理区分 As Integer,
                                            ByVal 連番コード As String) As String Implements IMyQueryMaker.SelectSEIC056PrimaryKey    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(" SEIC056001 ")
        query.Append(",SEIC056002 ")
        query.Append(",SEIC056003 ")

        query.Append("FROM " & MyBase.ExchangeTableName("SEI10C056LOT"))    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())

        query.Append(" WHERE ")
        Select Case 管理区分
            Case MOA機能追加定義型.ロットNo管理区分_受入型.品目ｺｰﾄﾞ別連番
                query.Append(" SEIC056001 = '1' ")
            Case MOA機能追加定義型.ロットNo管理区分_受入型.受入日付_連番
                query.Append(" SEIC056001 = '2' ")
            Case MOA機能追加定義型.ロットNo管理区分_受入型.製番別
                query.Append(" SEIC056001 = '3' ")
        End Select
        query.Append(" AND SEIC056002 = " & AddParamInfo(paramInfo, "SEIC056002", DbType.AnsiStringFixedLength, 25, 0, 0, 連番コード))

        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString
    End Function

#End Region

#Region "■ロット明細■"

    Public Function SelectSEIR008PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal 処理連番 As Long,
                                            ByVal 行番号 As Integer
                ) As String Implements IMyQueryMaker.SelectSEIR008PrimaryKey    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(QueryWrapper.AddIndexHintOracle(GetIndexHint("SEL_O_1")))

        query.Append(" SEIR008001 ")
        query.Append(",SEIR008002 ")
        query.Append(",SEIR008003 ")
        query.Append(",SEIR008004 ")
        query.Append(",SEIR008005 ")
        query.Append(",SEIR008006 ")
        query.Append(",SEIR008007 ")
        query.Append("," & QueryWrapper.AddIsNull() & "(SEIR008008, ' ') SEIR008008 ")
        query.Append(",SEIR008009 ")
        query.Append(",SEIR008010 ")
        query.Append("," & QueryWrapper.AddIsNull() & "(SEIR008011, ' ') SEIR008011 ")
        query.Append("," & QueryWrapper.AddIsNull() & "(SEIR008012, ' ') SEIR008012 ")
        query.Append("," & QueryWrapper.AddIsNull() & "(SEIR008013, ' ') SEIR008013 ")
        query.Append(",SEIR008014 ")
        query.Append(",SEIR008015 ")
        query.Append(",SEIR008016 ")
        query.Append(",SEIR008017 ")
        query.Append("," & QueryWrapper.AddIsNull() & "(SEIR008018, ' ') SEIR008018 ")
        query.Append(",SEIR008019 ")
        query.Append(",SEIR008020 ")
        query.Append(",SEIR008021 ")
        query.Append(",SEIR008022 ")
        query.Append("," & QueryWrapper.AddIsNull() & "(SEIR008023, ' ') SEIR008023 ")
        query.Append("," & QueryWrapper.AddIsNull() & "(SEIR008024, ' ') SEIR008024 ")
        query.Append(",SEIR008025 ")
        query.Append(",SEIR008026 ")
        query.Append(",SEIR008027 ")
        query.Append(",SEIR008028 ")
        query.Append("," & QueryWrapper.AddIsNull() & "(SEIR008029, ' ') SEIR008029 ")
        query.Append("," & QueryWrapper.AddIsNull() & "(SEIR008030, ' ') SEIR008030 ")
        query.Append("," & QueryWrapper.AddIsNull() & "(SEIR008031, ' ') SEIR008031 ")
        query.Append(",SEIR008032 ")
        query.Append(",SEIR008033 ")
        query.Append("," & QueryWrapper.AddIsNull() & "(SEIR008034, ' ') SEIR008034 ")
        query.Append("," & QueryWrapper.AddIsNull() & "(SEIR008035, ' ') SEIR008035 ")
        query.Append(",SEIR008036 ")
        query.Append(",SEIR008037 ")
        query.Append(",SEIR008038 ")
        query.Append(",SEIR008039 ")
        query.Append("," & QueryWrapper.AddIsNull() & "(SEIR008040, ' ') SEIR008040 ")
        query.Append("," & QueryWrapper.AddIsNull() & "(SEIR008041, ' ') SEIR008041 ")
        query.Append(",SEIR008042 ")
        'A-20121217_Ver7.50_4↓
        If MyImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 4.0 Then
            query.Append(",SEIR008043 ")
        End If
        'A-20121217_Ver7.50_4↑

        query.Append("FROM " & MyBase.ExchangeTableName("SEI10R008LOTM") & " ")    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock(GetIndexHint("R008_O_1")))

        query.Append(" WHERE ")
        query.Append(" SEIR008001 = 5 ")
        query.Append(" AND ")
        query.Append(" SEIR008002 = " & AddParamInfo(paramInfo, "SEIR008002", DbType.Decimal, 0, 10, 0, 処理連番))

        If 行番号 <> -1 Then
            query.Append(" AND ")
            query.Append(" SEIR008003 = " & AddParamInfo(paramInfo, "SEIR008003", DbType.Decimal, 0, 3, 0, 行番号))
        End If

        query.Append(" ORDER BY ")
        query.Append(" SEIR008001,SEIR008002,SEIR008003,SEIR008004 ")

        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString
    End Function

    Public Function SelectSEIR008_自動ロット(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                             ByVal 倉庫コード As String,
                                             ByVal 商品コード As String,
                                             ByVal 期首年月 As Integer
                    ) As String Implements IMyQueryMaker.SelectSEIR008_自動ロット    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        'D-20111124_18↓
        'query.Append("SELECT")
        'query.Append(" SEIR008007 ")
        'query.Append(",SEIR008009 ")
        'query.Append(",SEIR008010 ")
        'query.Append(",SEIR008014 ")
        'query.Append(",MIN(SEIR008005) 入庫日")
        'query.Append(",MIN(在庫数) 在庫数")

        'query.Append(" FROM " & MyBase.ExchangeTableName("SEI10R008LOTM"))    'X1変換Tool-20170509
        'query.Append(MyBase.QueryWrapper.AddNoLock())

        'query.Append(" INNER JOIN (")
        'query.Append("SELECT")
        'query.Append(" SEIS001001")
        'query.Append(",SEIS001002")
        'query.Append(",SEIS001003")
        'query.Append(",SEIS001004")
        'query.Append(",SUM(CASE SEIS001006 WHEN 0 THEN SEIS001009 ELSE 0 END) +")
        'query.Append(" SUM(CASE SEIS001006 WHEN 1 THEN SEIS001007 ELSE 0 END) -")
        'query.Append(" SUM(CASE SEIS001006 WHEN 1 THEN SEIS001008 ELSE 0 END) 在庫数")

        'query.Append(" FROM " & MyBase.ExchangeTableName("SEI10S001LOTTJ"))    'X1変換Tool-20170509
        'query.Append(MyBase.QueryWrapper.AddNoLock())

        ''期首残の条件と入出庫数の条件を分離する(おそらく実績テーブルのデータの持ち方としては期首残レコードはロット毎に
        ''1レコードとなるはずだが、有効在庫算出部品も条件を分離しているので同じように実装)
        'query.Append(" WHERE ((SEIS001005 = " & AddParamInfo(paramInfo, "SEIS001005_1", DbType.Decimal, 0, 6, 0, 期首年月))
        'query.Append("         AND SEIS001006 = 0) OR")
        'query.Append("        (SEIS001005 >= " & AddParamInfo(paramInfo, "SEIS001005_2", DbType.Decimal, 0, 6, 0, 期首年月))
        'query.Append("         AND SEIS001006 = 1))")

        ''結合後のWHERE句でも絞りこんでいるので、結合テーブルに対する絞込みは必ずしも必要ないが、
        ''サンメンションするレコード数を極力少なくするために重複記述する。
        'query.Append(" AND SEIS001001 = " & AddParamInfo(paramInfo, "SEIS001001", DbType.AnsiStringFixedLength, 11, 0, 0, 倉庫コード))
        'query.Append(" AND SEIS001002 = " & AddParamInfo(paramInfo, "SEIS001002", DbType.AnsiStringFixedLength, 25, 0, 0, 商品コード))
        'query.Append(" GROUP BY SEIS001001, SEIS001002, SEIS001003, SEIS001004")
        'query.Append(") LOTTJ")

        'query.Append(" ON SEIR008010 = SEIS001002")
        'query.Append(" AND SEIR008007 = SEIS001001")
        'query.Append(" AND SEIR008009 = SEIS001003")
        'query.Append(" AND SEIR008014 = SEIS001004")

        'query.Append(" WHERE SEIR008007 = " & AddParamInfo(paramInfo, "SEIR008007", DbType.AnsiStringFixedLength, 11, 0, 0, 倉庫コード))
        'query.Append(" AND SEIR008010 = " & AddParamInfo(paramInfo, "SEIR008010", DbType.AnsiStringFixedLength, 25, 0, 0, 商品コード))
        'query.Append(" AND SEIR008015 = 1")

        'query.Append(" GROUP BY SEIR008010, SEIR008007, SEIR008009, SEIR008014")
        'query.Append(" ORDER BY 入庫日, SEIR008010, SEIR008007, SEIR008009, SEIR008014 ")
        'query.Append(MyBase.QueryWrapper.AddUR())
        'D-20111124_18↑

        'A-20111124_18↓
        query.Append("SELECT ")
        query.Append(" SEIS001001 SEIR008007")
        query.Append(",SEIS001003 SEIR008009")
        query.Append(",SEIS001002 SEIR008010")
        query.Append(",SEIS001004 SEIR008014")

        '入庫日：ロット明細がない場合は月初とする
        'query.Append(",MIN(CASE ISNULL(入庫日, 0) WHEN 0 THEN SEIS001005 * 100 + 1 ELSE 入庫日 END) 入庫日")                                   'D-20120125_3
        query.Append(",MIN(CASE " & MyBase.QueryWrapper.AddIsNull() & "(入庫日, 0) WHEN 0 THEN SEIS001005 * 100 + 1 ELSE 入庫日 END) 入庫日")   'A-20120125_3
        query.Append(",SUM(CASE SEIS001006 WHEN 0 THEN SEIS001009 ELSE 0 END) +")
        query.Append(" SUM(CASE SEIS001006 WHEN 1 THEN SEIS001007 ELSE 0 END) -")
        query.Append(" SUM(CASE SEIS001006 WHEN 1 THEN SEIS001008 ELSE 0 END) 在庫数")

        query.Append(" FROM " & MyBase.ExchangeTableName("SEI10S001LOTTJ"))    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())

        query.Append(" LEFT OUTER JOIN ")
        query.Append("(SELECT ")
        query.Append(" SEIR008007")
        query.Append(",SEIR008009")
        query.Append(",SEIR008010")
        query.Append(",SEIR008014")
        query.Append(",MIN(SEIR008005) 入庫日")
        query.Append(" FROM " & MyBase.ExchangeTableName("SEI10R008LOTM"))    'X1変換Tool-20170509
        query.Append(MyBase.QueryWrapper.AddNoLock())

        query.Append(" WHERE ")
        query.Append(" SEIR008007 = " & AddParamInfo(paramInfo, "SEIR008007", DbType.AnsiStringFixedLength, 11, 0, 0, 倉庫コード))
        query.Append(" AND SEIR008010 = " & AddParamInfo(paramInfo, "SEIR008010", DbType.AnsiStringFixedLength, 25, 0, 0, 商品コード))
        query.Append(" AND SEIR008015 = 1")              'ロット明細からは入庫データのみを対象とする
        query.Append(" GROUP BY SEIR008007, SEIR008010, SEIR008009, SEIR008014")
        query.Append(") LOTM")

        query.Append(" ON SEIR008010 = SEIS001002")
        query.Append(" AND SEIR008007 = SEIS001001")
        query.Append(" AND SEIR008009 = SEIS001003")
        query.Append(" AND SEIR008014 = SEIS001004")

        query.Append(" WHERE ")
        query.Append(" ((SEIS001005 = " & AddParamInfo(paramInfo, "SEIS001005_1", DbType.Decimal, 0, 6, 0, 期首年月))
        query.Append("   AND SEIS001006 = 0) OR")                                                                       '期首残は当期分のみ
        query.Append("  (SEIS001005 >= " & AddParamInfo(paramInfo, "SEIS001005_2", DbType.Decimal, 0, 6, 0, 期首年月))
        query.Append("   AND SEIS001006 = 1))")                                                                         '当期首以降を対象とする

        query.Append(" AND SEIS001001 = " & AddParamInfo(paramInfo, "SEIS001001", DbType.AnsiStringFixedLength, 11, 0, 0, 倉庫コード))
        query.Append(" AND SEIS001002 = " & AddParamInfo(paramInfo, "SEIS001002", DbType.AnsiStringFixedLength, 25, 0, 0, 商品コード))

        query.Append(" GROUP BY SEIS001001, SEIS001002, SEIS001003, SEIS001004")
        query.Append(" ORDER BY 入庫日, SEIS001002, SEIS001001, SEIS001003, SEIS001004")
        query.Append(MyBase.QueryWrapper.AddUR())
        'A-20111124_18↑

        Return query.ToString

    End Function

    'D-20111124_3↓
    'Public Function SelectSEIR008ロット明細合計(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList, _    'X1変換Tool-20170508
    '                                            ByVal 処理連番 As Long, _
    '                                            Optional ByVal 処理連番CH As Long = -1 _
    '                ) As String Implements IMyQueryMaker.SelectSEIR008ロット明細合計
    'D-20111124_3↑
    'A-20111124_3↓
    Public Function SelectSEIR008ロット明細合計(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                                ByVal 処理連番 As Long,
                                                Optional ByVal 処理連番CH As Long = -1,
                                                Optional ByVal 倉庫移動出庫処理連番 As Long = -1,
                                                Optional ByVal 入出庫区分 As 入出庫区分型 = 入出庫区分型.入庫
                    ) As String Implements IMyQueryMaker.SelectSEIR008ロット明細合計    'X1変換Tool-20170508
        'A-20111124_3↑

        Dim sql As New System.Text.StringBuilder

        '<SELECT句>
        sql.Append(" SELECT ")
        sql.Append(" SEIR008007")                 '倉庫コード
        sql.Append(",SEIR008009")                 'ロケーションコード
        sql.Append(",SEIR008010")                 '商品コード
        sql.Append(",SEIR008014")                 'ロット№
        sql.Append(",SUM(SEIR008016) SEIR008016") '入庫数量
        sql.Append(",SUM(SEIR008017) SEIR008017") '出庫数量
        sql.Append(",HANM003008")
        sql.Append(",HANM003A024")

        '<FROM句>
        sql.Append(" FROM ")
        sql.Append(Me.ExchangeTableName("SEI10R008LOTM ") & QueryWrapper.AddNoLock())    'X1変換Tool-20170509
        sql.Append(" LEFT OUTER JOIN ")
        sql.Append(Me.ExchangeTableName("HAN10R002TORIHIKIM ") & QueryWrapper.AddNoLock())    'X1変換Tool-20170509
        sql.Append(" ON ")
        sql.Append("HANR002002 = SEIR008001")
        sql.Append(" AND ")
        sql.Append("HANR002004 = SEIR008002")
        sql.Append(" AND ")
        sql.Append("HANR002006 = SEIR008003")
        sql.Append(" AND ")
        sql.Append("HANR002005 = 0")    '通常
        sql.Append(" AND ")
        sql.Append("HANR002010 <> 3")   '値引以外

        'A-20111124_3↓
        If MyImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 3D AndAlso
           MyImportParam.Myコントロール情報.MyMOA機能追加.仕掛管理区分 = MOA機能追加定義型.その他管理区分型.行う AndAlso
           入出庫区分 = 入出庫区分型.出庫 Then

            sql.Append(" LEFT OUTER JOIN ")
            sql.Append(Me.ExchangeTableName("SEI10R056JUZOKU ") & QueryWrapper.AddNoLock())    'X1変換Tool-20170509
            sql.Append(" ON ")
            sql.Append("HANR002A026 = SEIR056002")
            sql.Append(" AND ")
            sql.Append("HANR002A029 = SEIR056003")
            sql.Append(" AND ")
            sql.Append("SEIR056001 = 2")

        End If
        'A-20111124_3↑

        sql.Append(" LEFT OUTER JOIN ")
        sql.Append(Me.ExchangeTableName("HAN10M003SHOHIN ") & QueryWrapper.AddNoLock())    'X1変換Tool-20170509
        sql.Append(" ON ")
        sql.Append("HANM003001 = SEIR008010")

        '<WHERE句>
        sql.Append(" WHERE ")
        sql.Append("SEIR008001 = 5")
        sql.Append(" AND ")

        'D-20111124_3↓
        'If 処理連番CH = -1 Then
        '    sql.Append("SEIR008002 = " & AddParamInfo(paramInfo, "SEIR008002", DbType.Decimal, 0, 10, 0, 処理連番))
        'Else
        '    sql.Append(" ( ")
        '    sql.Append("SEIR008002 = " & AddParamInfo(paramInfo, "SEIR008002", DbType.Decimal, 0, 10, 0, 処理連番))
        '    sql.Append(" OR ")
        '    sql.Append("SEIR008002 = " & AddParamInfo(paramInfo, "SEIR008002CH", DbType.Decimal, 0, 10, 0, 処理連番CH))
        '    sql.Append(" ) ")
        'End If
        'D-20111124_3↑
        'A-20111124_3↓
        sql.Append(" ( ")
        sql.Append("SEIR008002 = " & AddParamInfo(paramInfo, "SEIR008002", DbType.Decimal, 0, 10, 0, 処理連番))
        If 処理連番CH > 0 Then
            sql.Append(" OR ")
            sql.Append("SEIR008002 = " & AddParamInfo(paramInfo, "SEIR008002CH", DbType.Decimal, 0, 10, 0, 処理連番CH))
        End If
        If 倉庫移動出庫処理連番 > 0 Then
            sql.Append(" OR ")
            sql.Append("SEIR008002 = " & AddParamInfo(paramInfo, "SEIR008002_SOKO_IDOU", DbType.Decimal, 0, 10, 0, 倉庫移動出庫処理連番))
        End If
        sql.Append(" ) ")

        If MyImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 3D AndAlso
           MyImportParam.Myコントロール情報.MyMOA機能追加.仕掛管理区分 = MOA機能追加定義型.その他管理区分型.行う AndAlso
           入出庫区分 = 入出庫区分型.出庫 Then

            'みなし移動有の製造出庫データを除外する(移動有時の外注倉庫は在庫チェックの対象としない)。
            sql.Append(" AND ")
            sql.Append(" ( ")
            sql.Append("SEIR008006 = 8 ")
            sql.Append(" OR ")
            sql.Append(MyBase.QueryWrapper.AddIsNull() & " (SEIR056056, 0) <> 2 ")
            sql.Append(" ) ")

        End If
        'A-20111124_3↑

        sql.Append(" AND ")
        sql.Append("HANM003073 = 0")

        '<GROUP BY句>
        sql.Append(" GROUP BY ")
        sql.Append("SEIR008007, SEIR008009, SEIR008010, SEIR008014, HANM003008, HANM003A024")

        '<ORDER BY句>
        sql.Append(" ORDER BY ")
        sql.Append("SEIR008007, SEIR008009, SEIR008010, SEIR008014")

        sql.Append(QueryWrapper.AddUR())

        Return sql.ToString
    End Function

    'A-20130402_2↓
    Public Function SelectSEIR008ロット明細_構成品(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                                   ByVal 処理連番 As Long,
                                                   Optional ByVal 処理連番CH As Long = -1,
                                                   Optional ByVal 倉庫移動出庫処理連番 As Long = -1,
                                                   Optional ByVal 入出庫区分 As 入出庫区分型 = 入出庫区分型.入庫
                    ) As String Implements IMyQueryMaker.SelectSEIR008ロット明細_構成品    'X1変換Tool-20170508
        Dim sql As New System.Text.StringBuilder

        '<SELECT句>
        sql.Append(" SELECT ")
        sql.Append(" SEIR008003")                   '行番号
        sql.Append(",SEIR008004")                   'ロット明細行番号
        sql.Append(",SEIR008007")                   '倉庫コード
        sql.Append(",SEIR008009")                   'ロケーションコード
        sql.Append(",SEIR008010")                   '商品コード
        sql.Append(",SEIR008014")                   'ロット№
        sql.Append(",SUM(SEIR008016) SEIR008016")   '入庫数量
        sql.Append(",SUM(SEIR008017) SEIR008017")   '出庫数量
        sql.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANM003008, 0) HANM003008 ")
        sql.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANM003A024, 0) HANM003A024 ")
        sql.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANR002A026, 0) HANR002A026 ")   '手配番号 
        sql.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANR002A029, 0) HANR002A029 ")   '展開順序番号

        '<FROM句>
        sql.Append(" FROM ")
        sql.Append(Me.ExchangeTableName("SEI10R008LOTM ") & QueryWrapper.AddNoLock())    'X1変換Tool-20170509
        sql.Append(" LEFT OUTER JOIN ")
        sql.Append(Me.ExchangeTableName("HAN10R002TORIHIKIM ") & QueryWrapper.AddNoLock())    'X1変換Tool-20170509
        sql.Append(" ON ")
        sql.Append("HANR002002 = SEIR008001")
        sql.Append(" AND ")
        sql.Append("HANR002004 = SEIR008002")
        sql.Append(" AND ")
        sql.Append("HANR002006 = SEIR008003")
        sql.Append(" AND ")
        sql.Append("HANR002005 = 0")    '通常
        sql.Append(" AND ")
        sql.Append("HANR002010 <> 3")   '値引以外

        If MyImportParam.Myコントロール情報.MyMOA機能追加.仕掛管理区分 = MOA機能追加定義型.その他管理区分型.行う AndAlso
           入出庫区分 = 入出庫区分型.出庫 Then
            sql.Append(" LEFT OUTER JOIN ")
            sql.Append(Me.ExchangeTableName("SEI10R056JUZOKU ") & QueryWrapper.AddNoLock())    'X1変換Tool-20170509
            sql.Append(" ON ")
            sql.Append("HANR002A026 = SEIR056002")
            sql.Append(" AND ")
            sql.Append("HANR002A029 = SEIR056003")
            sql.Append(" AND ")
            sql.Append("SEIR056001 = 2")

        End If

        sql.Append(" LEFT OUTER JOIN ")
        sql.Append(Me.ExchangeTableName("HAN10M003SHOHIN ") & QueryWrapper.AddNoLock())    'X1変換Tool-20170509
        sql.Append(" ON ")
        sql.Append("HANM003001 = SEIR008010")

        '<WHERE句>
        sql.Append(" WHERE ")
        sql.Append("SEIR008001 = 5")
        sql.Append(" AND ")

        sql.Append(" ( ")
        sql.Append("SEIR008002 = " & AddParamInfo(paramInfo, "SEIR008002", DbType.Decimal, 0, 10, 0, 処理連番))
        If 処理連番CH > 0 Then
            sql.Append(" OR ")
            sql.Append("SEIR008002 = " & AddParamInfo(paramInfo, "SEIR008002CH", DbType.Decimal, 0, 10, 0, 処理連番CH))
        End If
        If 倉庫移動出庫処理連番 > 0 Then
            sql.Append(" OR ")
            sql.Append("SEIR008002 = " & AddParamInfo(paramInfo, "SEIR008002_SOKO_IDOU", DbType.Decimal, 0, 10, 0, 倉庫移動出庫処理連番))
        End If
        sql.Append(" ) ")

        If MyImportParam.Myコントロール情報.MyMOA機能追加.仕掛管理区分 = MOA機能追加定義型.その他管理区分型.行う AndAlso
           入出庫区分 = 入出庫区分型.出庫 Then

            'みなし移動有の製造出庫データを除外する(移動有時の外注倉庫は在庫チェックの対象としない)。
            sql.Append(" AND ")
            sql.Append(" ( ")
            sql.Append("SEIR008006 = 8 ")
            sql.Append(" OR ")
            sql.Append(MyBase.QueryWrapper.AddIsNull() & " (SEIR056056, 0) <> 2 ")
            sql.Append(" ) ")

        End If

        sql.Append(" AND ")
        sql.Append("HANM003073 = 0")

        '<GROUP BY句>
        sql.Append(" GROUP BY ")
        sql.Append(" SEIR008003")
        sql.Append(",SEIR008004")
        sql.Append(",SEIR008007, SEIR008009, SEIR008010, SEIR008014, HANM003008, HANM003A024")
        sql.Append(", HANR002A026")
        sql.Append(", HANR002A029")

        '<ORDER BY句>
        '製造出庫>個別出庫の順序で取得するため、CASE文を使用(展開順序番号=0 の場合、個別出庫)
        sql.Append(" ORDER BY ")
        sql.Append(" HANR002A026, ")
        sql.Append(" ( CASE HANR002A029 WHEN 0 THEN 9999 ELSE HANR002A029 END ) ")
        sql.Append(", SEIR008003 ")
        sql.Append(", SEIR008004 ")

        sql.Append(QueryWrapper.AddUR())

        Return sql.ToString
    End Function
    'A-20130402_2↑

    Friend Function SelectSEIR008出庫伝票合計(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                              ByVal 手配番号 As Long,
                                              ByVal 処理連番 As Long) As String _
                    Implements IMyQueryMaker.SelectSEIR008出庫伝票合計    'X1変換Tool-20170508

        Dim sql As New System.Text.StringBuilder

        sql.Append("SELECT ")
        sql.Append("SEIR008010, ")                                                      '品目コード
        sql.Append("SEIR008014, ")                                                      'ロット№
        sql.Append(QueryWrapper.AddIsNull & "(SUM(SEIR008017), 0) SUM_SEIR008017 ")     '出庫数量の合計

        sql.Append("FROM " & Me.ExchangeTableName("SEI10R008LOTM ") & QueryWrapper.AddNoLock)    'X1変換Tool-20170509

        sql.Append(" INNER JOIN ")
        sql.Append(Me.ExchangeTableName("HAN10R001TORIHIKIH ") & QueryWrapper.AddNoLock)    'X1変換Tool-20170509

        sql.Append(" ON SEIR008001 = HANR001004 ")
        sql.Append("AND SEIR008002 = HANR001006 ")

        sql.Append("WHERE ")
        sql.Append("SEIR008001 = 5 ")
        sql.Append("AND SEIR008006 = 4 ")
        sql.Append("AND SEIR008015 = 2 ")
        sql.Append("AND SEIR008036 = " & AddParamInfo(paramInfo, "SEIR008036", DbType.Decimal, 0, 10, 0, 手配番号) & " ")
        sql.Append("AND HANR001A005 <> " & AddParamInfo(paramInfo, "HANR001A005", DbType.Decimal, 0, 10, 0, 処理連番) & " ")

        sql.Append(" GROUP BY SEIR008010, SEIR008014")

        Return sql.ToString

    End Function

    Public Function SelectSEIR008関連ロット明細(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                                ByVal 手配番号 As Long,
                                                ByVal 展開順序番号 As Integer) As String _
                    Implements IMyQueryMaker.SelectSEIR008関連ロット明細    'X1変換Tool-20170508

        Dim query As New System.Text.StringBuilder

        query.Append(" SELECT ")
        query.Append(" SEIR008007")             '倉庫コード
        query.Append(",SEIR008009")             'ロケーション
        query.Append(",SEIR008010")             '品目コード
        query.Append(",SEIR008014")             'ロット番号
        query.Append(",SUM(SEIR008017) SEIR008017") '出庫数量

        query.Append(" FROM " & Me.ExchangeTableName("HAN10R002TORIHIKIM ") & " " & QueryWrapper.AddNoLock)    'X1変換Tool-20170509

        query.Append(" INNER JOIN ")
        query.Append(Me.ExchangeTableName("SEI10R008LOTM ") & " " & QueryWrapper.AddNoLock)    'X1変換Tool-20170509

        query.Append(" ON  HANR002002 = SEIR008001")  '伝票区分
        query.Append(" AND HANR002004 = SEIR008002")  '処理連番
        query.Append(" AND HANR002006 = SEIR008003")  '行番号

        'A-20111124_3↓
        If MyImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 3D AndAlso MyImportParam.Myコントロール情報.MyMOA機能追加.仕掛管理区分 = MOA機能追加定義型.その他管理区分型.行う Then

            query.Append(" LEFT OUTER JOIN ")
            query.Append(Me.ExchangeTableName("SEI10R056JUZOKU ") & QueryWrapper.AddNoLock())    'X1変換Tool-20170509
            query.Append(" ON ")
            query.Append("HANR002A026 = SEIR056002")
            query.Append(" AND ")
            query.Append("HANR002A029 = SEIR056003")
            query.Append(" AND ")
            query.Append("SEIR056001 = 2")

        End If
        'A-20111124_3↑

        query.Append(" WHERE HANR002002 = 5")         '伝票区分
        query.Append(" AND HANR002005 = 0")           '明細区分
        query.Append(" AND HANR002058 = 2")           '入出庫区分
        query.Append(" AND HANR002A004 = 1 ")         '発生区分 '1:受入処理

        query.Append(" AND HANR002A026 = " & AddParamInfo(paramInfo, "HANR002A026", DbType.Decimal, 0, 10, 0, 手配番号) & " ")
        query.Append(" AND HANR002A029 = " & AddParamInfo(paramInfo, "HANR002A029", DbType.Decimal, 0, 5, 0, 展開順序番号) & " ")

        'A-20111124_3↓
        If MyImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 3D AndAlso MyImportParam.Myコントロール情報.MyMOA機能追加.仕掛管理区分 = MOA機能追加定義型.その他管理区分型.行う Then

            'みなし移動有の製造出庫データを除外する(移動有時の外注倉庫は在庫チェックの対象としない)。
            query.Append(" AND ")
            query.Append(" ( ")
            query.Append("SEIR008006 = 8 ")
            query.Append(" OR ")
            query.Append(MyBase.QueryWrapper.AddIsNull() & " (SEIR056056, 0) <> 2 ")
            query.Append(" ) ")

        End If
        'A-20111124_3↑

        query.Append(" GROUP BY SEIR008007, SEIR008009, SEIR008010, SEIR008014")

        Return query.ToString

    End Function

    Public Function InsertSEIR008(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                  ByVal 更新データ As WorkTableUnitData,
                                  ByVal line As Integer) As String Implements IMyQueryMaker.InsertSEIR008    'X1変換Tool-20170508
        Dim query As New System.Text.StringBuilder
        query.Append(" INSERT INTO ")
        query.Append(Me.ExchangeTableName("SEI10R008LOTM"))    'X1変換Tool-20170509

        query.Append(" (")
        query.Append(" SEIR008001")
        query.Append(",SEIR008002")
        query.Append(",SEIR008003")
        query.Append(",SEIR008004")
        query.Append(",SEIR008005")
        query.Append(",SEIR008006")
        query.Append(",SEIR008007")
        query.Append(",SEIR008008")
        query.Append(",SEIR008009")
        query.Append(",SEIR008010")
        query.Append(",SEIR008011")
        query.Append(",SEIR008012")
        query.Append(",SEIR008013")
        query.Append(",SEIR008014")
        query.Append(",SEIR008015")
        query.Append(",SEIR008016")
        query.Append(",SEIR008017")
        query.Append(",SEIR008018")
        query.Append(",SEIR008019")
        query.Append(",SEIR008020")
        query.Append(",SEIR008021")
        query.Append(",SEIR008022")
        query.Append(",SEIR008023")
        query.Append(",SEIR008024")
        query.Append(",SEIR008025")
        query.Append(",SEIR008026")
        query.Append(",SEIR008027")
        query.Append(",SEIR008028")
        query.Append(",SEIR008029")
        query.Append(",SEIR008030")
        query.Append(",SEIR008031")
        query.Append(",SEIR008032")
        query.Append(",SEIR008033")
        query.Append(",SEIR008034")
        query.Append(",SEIR008035")
        query.Append(",SEIR008036")
        query.Append(",SEIR008037")
        query.Append(",SEIR008038")
        query.Append(",SEIR008039")
        query.Append(",SEIR008040")
        query.Append(",SEIR008041")
        query.Append(",SEIR008042")
        'A-20121217_Ver7.50_4↓
        If MyImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 4.0 Then
            query.Append(",SEIR008043 ")
        End If
        'A-20121217_Ver7.50_4↑
        query.Append(",SEIR008999")
        query.Append(" )")

        query.Append(" VALUES (")
        query.Append(" " & AddParamInfo(paramInfo, "SEIR008001", DbType.Decimal, 0, 1, 0, 更新データ.ロット明細(line).R008001))
        query.Append("," & AddParamInfo(paramInfo, "SEIR008002", DbType.Decimal, 0, 10, 0, 更新データ.ロット明細(line).R008002))
        query.Append("," & AddParamInfo(paramInfo, "SEIR008003", DbType.Decimal, 0, 3, 0, 更新データ.ロット明細(line).R008003))
        query.Append("," & AddParamInfo(paramInfo, "SEIR008004", DbType.Decimal, 0, 3, 0, 更新データ.ロット明細(line).R008004))
        query.Append("," & AddParamInfo(paramInfo, "SEIR008005", DbType.Decimal, 0, 8, 0, 更新データ.ロット明細(line).R008005))
        query.Append("," & AddParamInfo(paramInfo, "SEIR008006", DbType.Decimal, 0, 2, 0, 更新データ.ロット明細(line).R008006))
        query.Append("," & AddParamInfo(paramInfo, "SEIR008007", DbType.AnsiStringFixedLength, 11, 0, 0, 更新データ.ロット明細(line).R008007))
        query.Append("," & AddParamInfo(paramInfo, "SEIR008008", DbType.String, 16, 0, 0, 更新データ.ロット明細(line).R008008))
        query.Append("," & AddParamInfo(paramInfo, "SEIR008009", DbType.AnsiStringFixedLength, 10, 0, 0, 更新データ.ロット明細(line).R008009))
        query.Append("," & AddParamInfo(paramInfo, "SEIR008010", DbType.AnsiStringFixedLength, 25, 0, 0, 更新データ.ロット明細(line).R008010))
        query.Append("," & AddParamInfo(paramInfo, "SEIR008011", DbType.String, 36, 0, 0, 更新データ.ロット明細(line).R008011))
        query.Append("," & AddParamInfo(paramInfo, "SEIR008012", DbType.String, 36, 0, 0, 更新データ.ロット明細(line).R008012))
        query.Append("," & AddParamInfo(paramInfo, "SEIR008013", DbType.String, 20, 0, 0, 更新データ.ロット明細(line).R008013))
        query.Append("," & AddParamInfo(paramInfo, "SEIR008014", DbType.AnsiStringFixedLength, 20, 0, 0, 更新データ.ロット明細(line).R008014))
        query.Append("," & AddParamInfo(paramInfo, "SEIR008015", DbType.Decimal, 0, 1, 0, 更新データ.ロット明細(line).R008015))
        query.Append("," & AddParamInfo(paramInfo, "SEIR008016", DbType.Decimal, 0, 19, 4, 更新データ.ロット明細(line).R008016))
        query.Append("," & AddParamInfo(paramInfo, "SEIR008017", DbType.Decimal, 0, 19, 4, 更新データ.ロット明細(line).R008017))
        query.Append("," & AddParamInfo(paramInfo, "SEIR008018", DbType.String, 4, 0, 0, 更新データ.ロット明細(line).R008018))
        query.Append("," & AddParamInfo(paramInfo, "SEIR008019", DbType.AnsiStringFixedLength, 12, 0, 0, 更新データ.ロット明細(line).R008019))
        query.Append("," & AddParamInfo(paramInfo, "SEIR008020", DbType.AnsiStringFixedLength, 10, 0, 0, 更新データ.ロット明細(line).R008020))
        query.Append("," & AddParamInfo(paramInfo, "SEIR008021", DbType.AnsiStringFixedLength, 2, 0, 0, 更新データ.ロット明細(line).R008021))
        query.Append("," & AddParamInfo(paramInfo, "SEIR008022", DbType.AnsiStringFixedLength, 11, 0, 0, 更新データ.ロット明細(line).R008022))
        '↓D-20170601-X1-桁数拡張
        'query.Append("," & AddParamInfo(paramInfo, "SEIR008023", DbType.AnsiStringFixedLength, 32, 0, 0, 更新データ.ロット明細(line).R008023))
        'query.Append("," & AddParamInfo(paramInfo, "SEIR008024", DbType.AnsiStringFixedLength, 32, 0, 0, 更新データ.ロット明細(line).R008024))
        '↑D-20170601-X1-桁数拡張
        '↓A-20170601-X1-桁数拡張
        query.Append("," & AddParamInfo(paramInfo, "SEIR008023", DbType.AnsiStringFixedLength, 48, 0, 0, 更新データ.ロット明細(line).R008023))
        query.Append("," & AddParamInfo(paramInfo, "SEIR008024", DbType.AnsiStringFixedLength, 48, 0, 0, 更新データ.ロット明細(line).R008024))
        '↑A-20170601-X1-桁数拡張
        query.Append("," & AddParamInfo(paramInfo, "SEIR008025", DbType.Decimal, 0, 10, 0, 更新データ.ロット明細(line).R008025))
        query.Append("," & AddParamInfo(paramInfo, "SEIR008026", DbType.Decimal, 0, 3, 0, 更新データ.ロット明細(line).R008026))
        query.Append("," & AddParamInfo(paramInfo, "SEIR008027", DbType.Decimal, 0, 8, 0, 更新データ.ロット明細(line).R008027))
        query.Append("," & AddParamInfo(paramInfo, "SEIR008028", DbType.AnsiStringFixedLength, 25, 0, 0, 更新データ.ロット明細(line).R008028))
        query.Append("," & AddParamInfo(paramInfo, "SEIR008029", DbType.String, 36, 0, 0, 更新データ.ロット明細(line).R008029))
        query.Append("," & AddParamInfo(paramInfo, "SEIR008030", DbType.String, 36, 0, 0, 更新データ.ロット明細(line).R008030))
        query.Append("," & AddParamInfo(paramInfo, "SEIR008031", DbType.String, 20, 0, 0, 更新データ.ロット明細(line).R008031))
        query.Append("," & AddParamInfo(paramInfo, "SEIR008032", DbType.AnsiStringFixedLength, 20, 0, 0, 更新データ.ロット明細(line).R008032))
        query.Append("," & AddParamInfo(paramInfo, "SEIR008033", DbType.AnsiStringFixedLength, 11, 0, 0, 更新データ.ロット明細(line).R008033))
        '↓D-20170601-X1-桁数拡張
        'query.Append("," & AddParamInfo(paramInfo, "SEIR008034", DbType.String, 32, 0, 0, 更新データ.ロット明細(line).R008034))
        'query.Append("," & AddParamInfo(paramInfo, "SEIR008035", DbType.String, 32, 0, 0, 更新データ.ロット明細(line).R008035))
        '↑D-20170601-X1-桁数拡張
        '↓A-20170601-X1-桁数拡張
        query.Append("," & AddParamInfo(paramInfo, "SEIR008034", DbType.String, 48, 0, 0, 更新データ.ロット明細(line).R008034))
        query.Append("," & AddParamInfo(paramInfo, "SEIR008035", DbType.String, 48, 0, 0, 更新データ.ロット明細(line).R008035))
        '↑A-20170601-X1-桁数拡張
        query.Append("," & AddParamInfo(paramInfo, "SEIR008036", DbType.Decimal, 0, 10, 0, 更新データ.ロット明細(line).R008036))
        query.Append("," & AddParamInfo(paramInfo, "SEIR008037", DbType.Decimal, 0, 8, 0, 更新データ.ロット明細(line).R008037))
        query.Append("," & AddParamInfo(paramInfo, "SEIR008038", DbType.Decimal, 0, 1, 0, 更新データ.ロット明細(line).R008038))
        query.Append("," & AddParamInfo(paramInfo, "SEIR008039", DbType.AnsiStringFixedLength, 11, 0, 0, 更新データ.ロット明細(line).R008039))
        '↓D-20170601-X1-桁数拡張
        'query.Append("," & AddParamInfo(paramInfo, "SEIR008040", DbType.String, 32, 0, 0, 更新データ.ロット明細(line).R008040))
        'query.Append("," & AddParamInfo(paramInfo, "SEIR008041", DbType.String, 32, 0, 0, 更新データ.ロット明細(line).R008041))
        '↑D-20170601-X1-桁数拡張
        '↓A-20170601-X1-桁数拡張
        query.Append("," & AddParamInfo(paramInfo, "SEIR008040", DbType.String, 48, 0, 0, 更新データ.ロット明細(line).R008040))
        query.Append("," & AddParamInfo(paramInfo, "SEIR008041", DbType.String, 48, 0, 0, 更新データ.ロット明細(line).R008041))
        '↑A-20170601-X1-桁数拡張
        query.Append("," & AddParamInfo(paramInfo, "SEIR008042", DbType.Decimal, 0, 10, 0, 更新データ.ロット明細(line).R008042))
        'A-20121217_Ver7.50_4↓
        If MyImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 4.0 Then
            query.Append("," & AddParamInfo(paramInfo, "SEIR008043", DbType.Decimal, 0, 1, 0, 更新データ.ロット明細(line).R008043))
        End If
        'A-20121217_Ver7.50_4↑
        query.Append("," & AddParamInfo(paramInfo, "SEIR008999", DbType.Decimal, 0, 9, 0, 更新データ.ロット明細(line).R008999))
        query.Append(" )")
        Return query.ToString
    End Function

#End Region

#Region "■受入索引テーブル■"

    ''' <summary>
    ''' 受入索引テーブルの更新（Insert）
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function InsertSEIR114(ByRef paramInfo As ParamInfoList,
                                  ByVal 更新データ As WorkTableUnitData) As String Implements IMyQueryMaker.InsertSEIR114

        Dim query As New System.Text.StringBuilder
        query.Append(" INSERT INTO ")
        query.Append(Me.ExchangeTableName("SEI10R114SAKUIN"))    'X1変換Tool-20170509

        query.Append(" (")
        query.Append(" SEIR114001")
        query.Append(",SEIR114002")
        query.Append(",SEIR114003")
        query.Append(",SEIR114004")
        query.Append(",SEIR114999")
        query.Append(" )")

        query.Append(" VALUES (")
        query.Append(" " & AddParamInfo(paramInfo, "SEIR114001", DbType.Decimal, 0, 1, 0, 更新データ.受入索引テーブル.R114001))
        query.Append("," & AddParamInfo(paramInfo, "SEIR114002", DbType.Decimal, 0, 1, 0, 更新データ.受入索引テーブル.R114002))
        query.Append("," & AddParamInfo(paramInfo, "SEIR114003", DbType.Decimal, 0, 10, 0, 更新データ.受入索引テーブル.R114003))
        query.Append("," & AddParamInfo(paramInfo, "SEIR114004", DbType.Decimal, 0, 8, 0, 更新データ.受入索引テーブル.R114004))
        query.Append("," & AddParamInfo(paramInfo, "SEIR114999", DbType.Decimal, 0, 9, 0, 更新データ.受入索引テーブル.R114999))
        query.Append(" )")

        Return query.ToString
    End Function

    ''' <summary>
    ''' 受入索引テーブルの削除（Delete）
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function DeleteSEIR114(ByRef paramInfo As ParamInfoList,
                                  ByVal 更新データ As WorkTableUnitData) As String Implements IMyQueryMaker.DeleteSEIR114

        'データ展開
        Dim query As New System.Text.StringBuilder

        query.Append(" DELETE FROM ")
        query.Append(Me.ExchangeTableName("SEI10R114SAKUIN"))    'X1変換Tool-20170509
        query.Append(" WHERE ")
        query.Append(" SEIR114001 = 1 ")
        query.Append(" AND SEIR114003 = " & AddParamInfo(paramInfo, "SEIC056002", DbType.Decimal, 0, 10, 0, 更新データ.修正前受入索引連番))

        Return query.ToString
    End Function

#End Region


#Region "■製造出庫■"

    'D-20150520_1↓
    '''' <summary>
    '''' MakeSQL製造出庫データの取得
    '''' </summary>
    '''' <returns></returns>
    '''' <remarks></remarks>
    'Friend Function Select製造出庫(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList, _    'X1変換Tool-20170508
    '                               ByVal 処理連番 As Long, _
    '                               ByVal 手配番号 As Long, _
    '                               ByVal 構成品出庫区分 As Integer, _
    '                               ByVal 支給管理 As Integer _
    '                ) As String Implements IMyQueryMaker.Select製造出庫
    'D-20150520_1↑
    'A-20150520_1↓
    ''' <summary>
    ''' MakeSQL製造出庫データの取得
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function Select製造出庫(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                   ByVal 処理連番 As Long,
                                   ByVal 手配番号 As Long,
                                   ByVal 構成品出庫区分 As Integer,
                                   ByVal 支給管理 As Integer,
                                   ByVal 対象年月度 As Integer
                    ) As String Implements IMyQueryMaker.Select製造出庫    'X1変換Tool-20170508
        'A-20150520_1↑
        Dim sp As String = Space(1)
        Dim comma As String = Space(1) & ","

        Dim sql As New System.Text.StringBuilder
        sql.Append(" SELECT ")
        '--------------------
        '   従属需要取得項目定義
        '--------------------

        sql.Append(sp & SelectItem製造出庫従属需要(支給管理, "SEIR056", "SEIZOU"))

        '--------------------
        '   従属需要テーブル定義
        '--------------------

        '従属需要テーブル
        sql.Append(" FROM ")
        Dim tableR056 As String = Me.ExchangeTableName("SEI10R056JUZOKU ") & "SEIR056" & sp & QueryWrapper.AddNoLock    'X1変換Tool-20170509
        sql.Append(tableR056)

        '品目マスター
        sql.Append(" LEFT OUTER JOIN ")
        sql.Append(Me.ExchangeTableName("HAN10M003SHOHIN ") & "HANM003" & sp & QueryWrapper.AddNoLock)    'X1変換Tool-20170509
        sql.Append(" ON " & "SEIR056" & ".SEIR056007 = " & "HANM003" & ".HANM003001 ")
        If 支給管理 = MOA機能追加定義型.支給管理区分型.行う Then
            '仕入先マスター
            sql.Append(" LEFT OUTER JOIN ")
            sql.Append(Me.ExchangeTableName("HAN10M002SHIIRE ") & "HANM002" & sp & QueryWrapper.AddNoLock)    'X1変換Tool-20170509
            sql.Append(" ON " & "SEIR056" & ".SEIR056021 = " & "HANM002" & ".HANM002003 ")

            '倉庫マスター
            sql.Append(" LEFT OUTER JOIN ")
            sql.Append(Me.ExchangeTableName("HAN10M006SOKO ") & "HANM006" & sp & QueryWrapper.AddNoLock)    'X1変換Tool-20170509
            sql.Append(" ON " & "HANM002" & ".HANM002A001 = " & "HANM006" & ".HANM006001 ")
        Else
            '倉庫マスター
            sql.Append(" LEFT OUTER JOIN ")
            sql.Append(Me.ExchangeTableName("HAN10M006SOKO ") & "HANM006" & sp & QueryWrapper.AddNoLock)    'X1変換Tool-20170509
            sql.Append(" ON " & "SEIR056" & ".SEIR056013 = " & "HANM006" & ".HANM006001 ")
        End If

        'A-20141105_1↓
        If _myImportParam.Myコントロール情報.MyMOA機能追加.標準原価積上機能 = MOA機能追加定義型.使用有無区分型.使用する Then
            sql.Append(" LEFT OUTER JOIN ")
            sql.Append(" ( ")
            sql.Append(MakeSQL標準原価積上(手配番号, paramInfo))
            sql.Append(" ) SEIS007 ")
            sql.Append(" ON " & "SEIR056" & ".SEIR056007 = " & "SEIS007" & ".SEIR056007 ")
        End If
        'A-20141105_1↑

        'A-20150520_1↓
        If _myImportParam.Myコントロール情報.使用条件(Myコントロール情報Param.条件型.出庫時原価採用区分, 7D) = True Then
            sql.Append(" LEFT OUTER JOIN ")
            sql.Append(" ( ")
            sql.Append(MakeSQL品目別原価計算結果(手配番号, 対象年月度, paramInfo))
            sql.Append(" ) SEIR129 ")
            sql.Append(" ON " & "SEIR056" & ".SEIR056007 = " & "SEIR129" & ".SEIR056007 ")
        End If
        'A-20150520_1↑

        sql.Append(" WHERE ")
        ' 伝票区分
        sql.Append("SEIR056" & ".SEIR056002 = " & AddParamInfo(paramInfo, "SEIR056002", DbType.Decimal, 0, 10, 0, 手配番号))


        '取引ヘッダーテーブル
        sql.Append(" UNION ALL ")



        sql.Append(" SELECT ")
        '--------------------
        '   取引明細取得項目定義
        '--------------------

        sql.Append(sp & SelectItem製造出庫取引明細(支給管理, "HANR002", "SEIZOU"))

        '--------------------
        '   取引明細テーブル定義
        '--------------------

        '取引ヘッダーテーブル
        sql.Append(" FROM ")
        Dim tableR001 As String = Me.ExchangeTableName("HAN10R001TORIHIKIH ") & "HANR001" & sp & QueryWrapper.AddNoLock    'X1変換Tool-20170509
        sql.Append(tableR001)

        '取引明細テーブル（結合）
        sql.Append(" INNER JOIN ")
        sql.Append(Me.ExchangeTableName("HAN10R002TORIHIKIM ") & "HANR002" & sp & QueryWrapper.AddNoLock)    'X1変換Tool-20170509
        ' 伝票区分 
        sql.Append("  ON " & "HANR001" & ".HANR001004 = " & "HANR002" & ".HANR002002 ")
        ' 処理連番 
        sql.Append(" AND " & "HANR001" & ".HANR001006 = " & "HANR002" & ".HANR002004 ")
        ' 手配番号
        sql.Append(" AND " & "HANR002" & ".HANR002A026 = " & AddParamInfo(paramInfo, "HANR002A026", DbType.Decimal, 0, 10, 0, 手配番号))

        '従属需要テーブル（結合）
        sql.Append(" LEFT OUTER JOIN ")
        sql.Append(Me.ExchangeTableName("SEI10R056JUZOKU ") & "SEIR056" & sp & QueryWrapper.AddNoLock)    'X1変換Tool-20170509
        sql.Append("  ON " & "HANR002" & ".HANR002A026 = " & "SEIR056" & ".SEIR056002 ")
        sql.Append(" AND " & "HANR002" & ".HANR002A029 = " & "SEIR056" & ".SEIR056003 ")

        'A-20111124_3↓
        If _myImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 3D AndAlso
           _myImportParam.Myコントロール情報.MyMOA機能追加.仕掛管理区分 = MOA機能追加定義型.その他管理区分型.行う Then

            '倉庫移動出庫データを結合する。
            sql.Append(" LEFT OUTER JOIN ")
            sql.Append(Me.ExchangeTableName("HAN10R002TORIHIKIM ") & "HANR002_SOKO_IDOU" & sp & QueryWrapper.AddNoLock)    'X1変換Tool-20170509
            sql.Append("  ON " & "HANR002.HANR002A005 = HANR002_SOKO_IDOU.HANR002A005 ")
            sql.Append(" AND HANR002_SOKO_IDOU.HANR002A004 = 1 ")
            sql.Append(" AND HANR002_SOKO_IDOU.HANR002002 = 5 ")
            sql.Append(" AND HANR002_SOKO_IDOU.HANR002010 = 2 ")
            sql.Append(" AND HANR002_SOKO_IDOU.HANR002058 = 2 ")
            sql.Append(" AND HANR002.HANR002006 = HANR002_SOKO_IDOU.HANR002006 ")
            sql.Append(" AND HANR002.HANR002010 = 5 ")
        End If
        'A-20111124_3↑

        '品目マスター
        sql.Append(" LEFT OUTER JOIN ")
        sql.Append(Me.ExchangeTableName("HAN10M003SHOHIN ") & "HANM003" & sp & QueryWrapper.AddNoLock)    'X1変換Tool-20170509
        sql.Append(" ON " & "HANR002" & ".HANR002019 = " & "HANM003" & ".HANM003001 ")

        'If 支給管理 = MOA機能追加定義型.支給管理区分型.行う Then
        '    '仕入先マスター
        '    sql.Append(" LEFT OUTER JOIN ")
        '    sql.Append(Me.ExchangeTableName("HAN10M002SHIIRE ") & "HANM002" & sp & QueryWrapper.AddNoLock)    'X1変換Tool-20170509
        '    sql.Append(" ON " & "HANR002" & ".HANR002008 = " & "HANM002" & ".HANM002003 ")

        '    '倉庫マスター
        '    sql.Append(" LEFT OUTER JOIN ")
        '    sql.Append(Me.ExchangeTableName("HAN10M006SOKO ") & "HANM006" & sp & QueryWrapper.AddNoLock)    'X1変換Tool-20170509
        '    sql.Append(" ON " & "HANM002" & ".HANM002A001 = " & "HANM006" & ".HANM006001 ")
        'Else
        '倉庫マスター
        sql.Append(" LEFT OUTER JOIN ")
        sql.Append(Me.ExchangeTableName("HAN10M006SOKO ") & "HANM006" & sp & QueryWrapper.AddNoLock)    'X1変換Tool-20170509
        sql.Append(" ON " & "HANR002" & ".HANR002018 = " & "HANM006" & ".HANM006001 ")
        'End If


        '--------------------
        '   検索条件
        '--------------------

        sql.Append(" WHERE ")
        ' 伝票区分
        sql.Append("HANR001" & ".HANR001004 = 5")
        sql.Append(" AND ")

        '取引区分
        sql.Append("HANR001" & ".HANR001010 = " & CType(出庫取引区分型.製造出庫, String))
        sql.Append(" AND ")

        '入出庫区分
        sql.Append("HANR001" & ".HANR001074 = 2 ")
        sql.Append(" AND ")

        ' 発生区分
        sql.Append("HANR001" & ".HANR001A004 = 1")
        sql.Append(" AND ")

        ' 発生元相手連番
        sql.Append("HANR001" & ".HANR001A005 = " & AddParamInfo(paramInfo, "HANR001A005", DbType.Decimal, 0, 10, 0, 処理連番))

        '--------------------
        '   並び順
        '--------------------
        sql.Append(" ORDER BY ")
        sql.Append("SEIZOU" & "_SEIZOU003 ASC")
        sql.Append(comma & "SEIZOU" & "_SEIZOU005 ASC")
        sql.Append(comma & "SEIZOU" & "_SEIZOU006 DESC")

        Return sql.ToString
    End Function

#End Region

#Region "■個別出庫■"

    ''' <summary>
    ''' MakeSQL個別品出庫データの取得
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function MakeSQL個別出庫(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                    ByVal 処理連番 As Long
                    ) As String Implements IMyQueryMaker.Select個別出庫    'X1変換Tool-20170508

        Dim sp As String = Space(1)
        Dim comma As String = Space(1) & ","

        Dim sql As New System.Text.StringBuilder
        sql.Append(" SELECT ")
        '--------------------
        '   取引明細取得項目定義
        '--------------------
        sql.Append(sp & SelectItem個別出庫取引明細("HANR002", "KOBETU"))

        '--------------------
        '   取得項目定義
        '--------------------

        '取引ヘッダーテーブル
        sql.Append(" FROM ")
        Dim tableR001 As String = Me.ExchangeTableName("HAN10R001TORIHIKIH ") & "HANR001" & sp & QueryWrapper.AddNoLock    'X1変換Tool-20170509
        sql.Append(tableR001)

        '取引明細テーブル（結合）
        sql.Append(" INNER JOIN ")
        sql.Append(Me.ExchangeTableName("HAN10R002TORIHIKIM ") & "HANR002" & sp & QueryWrapper.AddNoLock)    'X1変換Tool-20170509
        ' 伝票区分 
        sql.Append("  ON " & "HANR001" & ".HANR001004 = " & "HANR002" & ".HANR002002 ")
        ' 処理連番 
        sql.Append(" AND " & "HANR001" & ".HANR001006 = " & "HANR002" & ".HANR002004 ")

        '品目マスター
        sql.Append(" LEFT OUTER JOIN ")
        sql.Append(Me.ExchangeTableName("HAN10M003SHOHIN ") & "HANM003" & sp & QueryWrapper.AddNoLock)    'X1変換Tool-20170509
        sql.Append(" ON " & "HANR002" & ".HANR002019 = " & "HANM003" & ".HANM003001 ")

        '倉庫マスター
        sql.Append(" LEFT OUTER JOIN ")
        sql.Append(Me.ExchangeTableName("HAN10M006SOKO ") & "HANM006" & sp & QueryWrapper.AddNoLock)    'X1変換Tool-20170509
        sql.Append(" ON " & "HANR002" & ".HANR002018 = " & "HANM006" & ".HANM006001 ")

        '--------------------
        '   検索条件
        '--------------------
        sql.Append(" WHERE ")
        ' 伝票区分
        sql.Append("HANR001" & ".HANR001004 = 5")
        sql.Append(" AND ")

        '取引区分
        sql.Append("HANR001" & ".HANR001010 = 9 ")
        sql.Append(" AND ")

        '入出庫区分
        sql.Append("HANR001" & ".HANR001074 = 2 ")
        sql.Append(" AND ")

        ' 発生区分
        sql.Append("HANR001" & ".HANR001A004 = 1")
        sql.Append(" AND ")

        ' 発生元相手連番
        sql.Append("HANR001" & ".HANR001A005 = " & AddParamInfo(paramInfo, "HANR001A005", DbType.Decimal, 0, 10, 0, 処理連番))

        '--------------------
        '   並び順
        '--------------------
        sql.Append(" ORDER BY ")
        sql.Append("HANR001" & ".HANR001A005")
        sql.Append(comma & "HANR002" & ".HANR002004")
        sql.Append(comma & "HANR002" & ".HANR002006")

        Return sql.ToString
    End Function

#End Region

#Region "■ロット明細(製造実績)■"

    ''' <summary>
    ''' MakeSQL個別品出庫データの取得
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function MakeSQLロット明細(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                      ByVal 明細区分 As Integer,
                                      ByVal 取引区分 As Integer,
                                      ByVal 処理連番 As Long,
                                      ByVal 行番号 As Integer
                    ) As String Implements IMyQueryMaker.Selectロット明細    'X1変換Tool-20170508

        Dim sp As String = Space(1)
        Dim comma As String = Space(1) & ","

        Dim sql As New System.Text.StringBuilder
        sql.Append(" SELECT ")
        '--------------------
        '   ロット明細テーブル取得項目定義
        '--------------------
        sql.Append(sp & SelectItemロット明細_出庫("SEIR008"))

        '--------------------
        '   取得項目定義
        '--------------------

        '取引ヘッダーテーブル
        sql.Append(" FROM ")
        sql.Append(Me.ExchangeTableName("HAN10R001TORIHIKIH ") & "HANR001" & sp & QueryWrapper.AddNoLock)    'X1変換Tool-20170509

        '取引明細テーブル（結合）
        sql.Append(" INNER JOIN ")
        sql.Append(Me.ExchangeTableName("HAN10R002TORIHIKIM ") & "HANR002" & sp & QueryWrapper.AddNoLock)    'X1変換Tool-20170509
        ' 伝票区分 
        sql.Append("  ON " & "HANR001" & ".HANR001004 = " & "HANR002" & ".HANR002002 ")
        ' 処理連番 
        sql.Append(" AND " & "HANR001" & ".HANR001006 = " & "HANR002" & ".HANR002004 ")
        ' 行番号
        If 取引区分 = 出庫取引区分型.製造出庫 Then
            sql.Append(" AND " & "HANR002" & ".HANR002A029 = " & AddParamInfo(paramInfo, "HANR002A029", DbType.Decimal, 0, 5, 0, 行番号))
        Else
            sql.Append(" AND " & "HANR002" & ".HANR002006 = " & AddParamInfo(paramInfo, "HANR002006", DbType.Decimal, 0, 3, 0, 行番号))
        End If
        sql.Append(" INNER JOIN ")
        sql.Append(Me.ExchangeTableName("SEI10R008LOTM ") & "SEIR008" & sp & QueryWrapper.AddNoLock)    'X1変換Tool-20170509
        sql.Append("  ON " & "HANR002" & ".HANR002002 = " & "SEIR008" & ".SEIR008001 ")     ' 伝票区分
        sql.Append(" AND " & "HANR002" & ".HANR002004 = " & "SEIR008" & ".SEIR008002 ")     ' 処理連番
        sql.Append(" AND " & "HANR002" & ".HANR002006 = " & "SEIR008" & ".SEIR008003 ")     ' 行番号
        sql.Append(" AND " & "HANR002" & ".HANR002058 = " & "SEIR008" & ".SEIR008015 ")     ' 入出庫区分
        sql.Append(" AND " & "SEIR008" & ".SEIR008006 = " & AddParamInfo(paramInfo, "SEIR008006", DbType.Decimal, 0, 2, 0, 明細区分))

        '--------------------
        '   検索条件
        '--------------------
        sql.Append(" WHERE ")
        ' 伝票区分
        sql.Append("HANR001" & ".HANR001004 = 5")
        sql.Append(" AND ")

        '取引区分
        sql.Append("HANR001" & ".HANR001010 = " & AddParamInfo(paramInfo, "HANR001010", DbType.Decimal, 0, 2, 0, 取引区分))
        sql.Append(" AND ")

        '入出庫区分
        sql.Append("HANR001" & ".HANR001074 = 2 ")
        sql.Append(" AND ")

        ' 発生区分
        sql.Append("HANR001" & ".HANR001A004 = 1 ")
        sql.Append(" AND ")

        ' 発生元相手連番
        sql.Append("HANR001" & ".HANR001006 = " & AddParamInfo(paramInfo, "HANR001006", DbType.Decimal, 0, 10, 0, 処理連番))

        '--------------------
        '   並び順
        '--------------------
        sql.Append(" ORDER BY ")
        sql.Append("SEIR008" & ".SEIR008003")
        sql.Append(comma & "SEIR008" & ".SEIR008004")

        Return sql.ToString
    End Function

#End Region

    'A-20120125_1↓
#Region "■手配先別品目工程別仕掛月別実績テーブル■"

    ''' <summary>
    ''' MakeSQL仕掛在庫数量の取得
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function SelectSEIS003仕掛在庫数量取得(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                                  ByVal 内外区分 As Integer,
                                                  ByVal 手配先コード As String,
                                                  ByVal 品目コード As String,
                                                  ByVal 手順No As Integer,
                                                  ByVal 当期期首年月度 As Integer
                    ) As String Implements IMyQueryMaker.SelectSEIS003仕掛在庫数量取得    'X1変換Tool-20170508

        Dim sp As String = Space(1)
        Dim comma As String = Space(1) & ","

        Dim sql As New System.Text.StringBuilder

        sql.Append("SELECT ")
        sql.Append(QueryWrapper.AddIsNull() & "(")
        sql.Append(" SUM(CASE SEIS003007 WHEN 0 THEN SEIS003010 ELSE 0 END) ")
        sql.Append("+ SUM(CASE SEIS003007 WHEN 0 THEN 0 ELSE SEIS003008 END) ")
        sql.Append("- SUM(CASE SEIS003007 WHEN 0 THEN 0 ELSE SEIS003009 END) ")
        sql.Append(", 0) SIKAKARI_ZAIKO_SU ")

        'A-20121217_Ver7.50_4↓
        If MyImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 4.0 Then
            sql.Append(",")
            sql.Append(QueryWrapper.AddIsNull() & "(")
            sql.Append("  SUM(CASE SEIS003007 WHEN 0 THEN 0 ELSE SEIS003012 END) ")
            sql.Append("- SUM(CASE SEIS003007 WHEN 0 THEN 0 ELSE SEIS003013 END) ")
            sql.Append("+ SUM(CASE SEIS003007 WHEN 0 THEN SEIS003014 ELSE 0 END) ")
            sql.Append(", 0) UTI_MIKENSHU_NYUKASU ")
        End If
        'A-20121217_Ver7.50_4↑

        sql.Append(" FROM ")
        sql.Append(Me.ExchangeTableName("SEI10S003TEHAIHINKSTJ ") & QueryWrapper.AddNoLock)    'X1変換Tool-20170509

        sql.Append(" WHERE SEIS003001 = " & AddParamInfo(paramInfo, "SEIS003001", DbType.Decimal, 0, 1, 0, 内外区分))
        sql.Append(" AND SEIS003002 = " & AddParamInfo(paramInfo, "SEIS003002", DbType.AnsiStringFixedLength, 11, 0, 0, 手配先コード))
        sql.Append(" AND SEIS003003 = " & AddParamInfo(paramInfo, "SEIS003003", DbType.AnsiStringFixedLength, 25, 0, 0, 品目コード))
        sql.Append(" AND SEIS003004 = " & AddParamInfo(paramInfo, "SEIS003004", DbType.Decimal, 0, 5, 0, 手順No))
        sql.Append(" AND (")
        sql.Append(" (SEIS003006 = " & AddParamInfo(paramInfo, "SEIS003006_7From", DbType.Decimal, 0, 6, 0, 当期期首年月度))
        sql.Append("  AND SEIS003007 = 0) OR ")
        sql.Append(" (SEIS003006 >= " & AddParamInfo(paramInfo, "SEIS003001_7To", DbType.Decimal, 0, 6, 0, 当期期首年月度))
        sql.Append("  AND SEIS003007 = 1)) ")

        sql.Append(QueryWrapper.AddUR())

        Return sql.ToString
    End Function

#End Region
    'A-20120125_1↑

#Region "製造出庫取得値"

    ''' <summary>
    ''' 製造出庫データ取得列名定義
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function SelectItem製造出庫従属需要(ByVal 支給管理 As Integer,
                                               Optional ByVal tableAlias As String = "",
                                               Optional ByVal itemAlias As String = "") As String


        Dim typeString As String = GetDefault(属性.文字)
        Dim typeNumerical As String = GetDefault(属性.数値)
        Dim sp As String = Space(1)
        Dim comma As String = Space(1) & ","

        '
        Dim item As New System.Text.StringBuilder
        item.Append(sp & ItemAliasBuilder(tableAlias, "SEIR056052", itemAlias, 製造出庫項目型.手配管理番号, typeNumerical))
        item.Append(comma & ItemAliasBuilder(tableAlias, "SEIR056002", itemAlias, 製造出庫項目型.手配番号, typeNumerical))
        item.Append(comma & ItemDefultBuilder(tableAlias, "0 ", itemAlias, 製造出庫項目型.伝票日付, 属性.数値))
        item.Append(comma & ItemDefultBuilder(tableAlias, "0 ", itemAlias, 製造出庫項目型.伝票番号, 属性.数値))
        item.Append(comma & ItemDefultBuilder(tableAlias, "0 ", itemAlias, 製造出庫項目型.処理連番, 属性.数値))
        item.Append(comma & ItemAliasBuilder(tableAlias, "SEIR056003", itemAlias, 製造出庫項目型.行番号, typeNumerical))
        item.Append(comma & ItemDefultBuilder(tableAlias, "0 ", itemAlias, 製造出庫項目型.出庫行番号, 属性.数値))   'A-20130603_1
        item.Append(comma & ItemDefultBuilder(tableAlias, "SEIR056", itemAlias, 製造出庫項目型.テーブルID, 属性.文字))
        item.Append(comma & ItemAliasBuilder(tableAlias, "SEIR056007", itemAlias, 製造出庫項目型.品目コード, typeString))
        item.Append(comma & ItemAliasBuilder(tableAlias, "SEIR056008", itemAlias, 製造出庫項目型.品目名, typeString))
        If 支給管理 = MOA機能追加定義型.支給管理区分型.行う Then
            item.Append(comma & ItemAliasBuilder("HANM002", "HANM002A001", itemAlias, 製造出庫項目型.倉庫コード, typeString))
            item.Append(comma & ItemDefultBuilder(tableAlias, Space(1), itemAlias, 製造出庫項目型.ロケーション, 属性.文字))
        Else
            item.Append(comma & ItemAliasBuilder(tableAlias, "SEIR056013", itemAlias, 製造出庫項目型.倉庫コード, typeString))
            item.Append(comma & ItemAliasBuilder(tableAlias, "SEIR056014", itemAlias, 製造出庫項目型.ロケーション, typeString))
        End If
        item.Append(comma & ItemDefultBuilder(tableAlias, Space(1), itemAlias, 製造出庫項目型.ロットNo, 属性.文字))
        item.Append(comma & ItemAliasBuilder(tableAlias, "SEIR056022", itemAlias, 製造出庫項目型.支給出庫予定数量, typeNumerical))
        item.Append(comma & ItemAliasBuilder(tableAlias, "SEIR056027", itemAlias, 製造出庫項目型.引落数量, typeNumerical))
        item.Append(comma & ItemAliasBuilder(tableAlias, "SEIR056045", itemAlias, 製造出庫項目型.強制完納区分, typeNumerical))
        item.Append(comma & ItemAliasBuilder(tableAlias, "SEIR056023", itemAlias, 製造出庫項目型.数量単位, typeString))
        item.Append(comma & ItemAliasBuilder(tableAlias, "SEIR056004", itemAlias, 製造出庫項目型.部番, typeNumerical))
        item.Append(comma & ItemDefultBuilder(tableAlias, Space(1), itemAlias, 製造出庫項目型.行摘要コード, 属性.文字))
        item.Append(comma & ItemDefultBuilder(tableAlias, Space(1), itemAlias, 製造出庫項目型.行摘要１, 属性.文字))
        item.Append(comma & ItemDefultBuilder(tableAlias, Space(1), itemAlias, 製造出庫項目型.行摘要２, 属性.文字))
        item.Append(comma & ItemAliasBuilder(tableAlias, "SEIR056028", itemAlias, 製造出庫項目型.支給出庫済数量, typeNumerical))
        item.Append(comma & ItemAliasBuilder(tableAlias, "SEIR056048", itemAlias, 製造出庫項目型.費目コード, typeString))
        item.Append(comma & ItemAliasBuilder(tableAlias, "SEIR056049", itemAlias, 製造出庫項目型.費目区分, typeNumerical))
        item.Append(comma & ItemAliasBuilder(tableAlias, "SEIR056029", itemAlias, 製造出庫項目型.有償支給数量, typeNumerical))
        item.Append(comma & ItemAliasBuilder(tableAlias, "SEIR056030", itemAlias, 製造出庫項目型.無償支給数量, typeNumerical))
        item.Append(comma & ItemAliasBuilder(tableAlias, "SEIR056044", itemAlias, 製造出庫項目型.標準支給単価, typeNumerical))
        item.Append(comma & ItemAliasBuilder("HANM003", "HANM003008", itemAlias, 製造出庫項目型.在庫管理区分, typeNumerical))
        item.Append(comma & ItemAliasBuilder("HANM003", "HANM003054", itemAlias, 製造出庫項目型.在庫引当対象区分, typeNumerical))
        item.Append(comma & ItemAliasBuilder("HANM003", "HANM003A010", itemAlias, 製造出庫項目型.基準倉庫コード, typeString))
        item.Append(comma & ItemAliasBuilder("HANM003", "HANM003A013", itemAlias, 製造出庫項目型.需要数計算単位, typeNumerical))
        item.Append(comma & ItemAliasBuilder("HANM003", "HANM003A014", itemAlias, 製造出庫項目型.正式名称１, typeString))
        item.Append(comma & ItemAliasBuilder("HANM003", "HANM003A015", itemAlias, 製造出庫項目型.正式名称２, typeString))
        item.Append(comma & ItemAliasBuilder("HANM003", "HANM003A016", itemAlias, 製造出庫項目型.正式名称３, typeString))
        item.Append(comma & ItemAliasBuilder("HANM003", "HANM003A024", itemAlias, 製造出庫項目型.ロット管理区分, typeNumerical))
        item.Append(comma & ItemAliasBuilder("HANM003", "HANM003A027", itemAlias, 製造出庫項目型.基準ロケーション, typeString))
        item.Append(comma & ItemAliasBuilder("HANM006", "HANM006004", itemAlias, 製造出庫項目型.倉庫略称, typeString))
        item.Append(comma & ItemDefultBuilder(tableAlias, "0 ", itemAlias, 製造出庫項目型.数量, 属性.数値))
        item.Append(comma & ItemAliasBuilder(tableAlias, "SEIR056034", itemAlias, 製造出庫項目型.原単位区分, typeNumerical))
        item.Append(comma & ItemAliasBuilder(tableAlias, "SEIR056035", itemAlias, 製造出庫項目型.取数分子, typeNumerical))
        item.Append(comma & ItemAliasBuilder(tableAlias, "SEIR056036", itemAlias, 製造出庫項目型.取数分母, typeNumerical))
        item.Append(comma & ItemAliasBuilder(tableAlias, "SEIR056037", itemAlias, 製造出庫項目型.支給区分, typeNumerical))
        item.Append(comma & ItemAliasBuilder("HANM006", "HANM006A002", itemAlias, 製造出庫項目型.対象倉庫区分, typeNumerical))
        item.Append(comma & ItemAliasBuilder(tableAlias, "SEIR056012", itemAlias, 製造出庫項目型.出庫予定日, typeNumerical))

        'A-20150520_1↓
        If MyImportParam.Myコントロール情報.使用条件(Myコントロール情報Param.条件型.出庫時原価採用区分, 7D) = True Then
            item.Append(comma & ItemAliasBuilder("SEIR129", "SEIR129005", itemAlias, 製造出庫項目型.材料費, typeNumerical))
            item.Append(comma & ItemAliasBuilder("SEIR129", "SEIR129006", itemAlias, 製造出庫項目型.労務費, typeNumerical))
            item.Append(comma & ItemAliasBuilder("SEIR129", "SEIR129007", itemAlias, 製造出庫項目型.外注費, typeNumerical))
            'A-20150520_1↑
            'If MyImportParam.Myコントロール情報.MyMOA機能追加.標準原価積上機能 = MOA機能追加定義型.使用有無区分型.使用しない Then      'D-20150520_1
        ElseIf MyImportParam.Myコントロール情報.MyMOA機能追加.標準原価積上機能 = MOA機能追加定義型.使用有無区分型.使用しない Then       'A-20150520_1
            'A-20141105_1↓
            '生産強化区分＜6.0もしくは
            '生産強化区分≧6.0かつ標準原価積上機能を使用しない場合
            'A-20141105_1↑
            item.Append(comma & ItemAliasBuilder("HANM003", "HANM003A030", itemAlias, 製造出庫項目型.材料費, typeNumerical))
            item.Append(comma & ItemAliasBuilder("HANM003", "HANM003A031", itemAlias, 製造出庫項目型.労務費, typeNumerical))
            item.Append(comma & ItemAliasBuilder("HANM003", "HANM003A032", itemAlias, 製造出庫項目型.外注費, typeNumerical))
            'A-20141105_1↓
        Else
            item.Append(comma & ItemAliasBuilder("SEIS007", "SEIS007016", itemAlias, 製造出庫項目型.材料費, typeNumerical))
            item.Append(comma & ItemAliasBuilder("SEIS007", "SEIS007017", itemAlias, 製造出庫項目型.労務費, typeNumerical))
            item.Append(comma & ItemAliasBuilder("SEIS007", "SEIS007018", itemAlias, 製造出庫項目型.外注費, typeNumerical))
        End If
        'A-20141105_1↑

        'A-20111124_3↓
        '自動出庫時、みなし出庫(移動有)の場合は外注/工程倉庫ではなく従属需要の倉庫から出庫する必要がある。
        If _myImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 3D AndAlso
           _myImportParam.Myコントロール情報.MyMOA機能追加.仕掛管理区分 = MOA機能追加定義型.その他管理区分型.行う Then
            item.Append(comma & ItemAliasBuilder(tableAlias, "SEIR056056", itemAlias, 製造出庫項目型.みなし出庫区分, typeNumerical))
            item.Append(comma & ItemAliasBuilder(tableAlias, "SEIR056013", itemAlias, 製造出庫項目型.倉庫コード_みなし出庫移動有用, typeString))
            item.Append(comma & ItemAliasBuilder(tableAlias, "SEIR056014", itemAlias, 製造出庫項目型.ロケーション_みなし出庫移動有用, typeString))
            item.Append(comma & ItemDefultBuilder(tableAlias, "0 ", itemAlias, 製造出庫項目型.倉庫移動出庫処理連番, 属性.数値))
            'A-20121217_Ver7.50_4↓
        Else
            item.Append(comma & ItemDefultBuilder(tableAlias, "0 ", itemAlias, 製造出庫項目型.みなし出庫区分, 属性.数値))
            item.Append(comma & ItemDefultBuilder(tableAlias, Space(1), itemAlias, 製造出庫項目型.倉庫コード_みなし出庫移動有用, 属性.文字))
            item.Append(comma & ItemDefultBuilder(tableAlias, Space(1), itemAlias, 製造出庫項目型.ロケーション_みなし出庫移動有用, 属性.文字))
            item.Append(comma & ItemDefultBuilder(tableAlias, "0 ", itemAlias, 製造出庫項目型.倉庫移動出庫処理連番, 属性.数値))
            'A-20121217_Ver7.50_4↑
        End If
        'A-20111124_3↑

        'A-20121217_Ver7.50_4↓
        If _myImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 4.0 Then
            item.Append(comma & ItemAliasBuilder(tableAlias, "SEIR056003", itemAlias, 製造出庫項目型.展開順序番号, typeNumerical))
            item.Append(comma & ItemAliasBuilder(tableAlias, "SEIR056065", itemAlias, 製造出庫項目型.出庫引当済数, typeNumerical))
            item.Append(comma & ItemAliasBuilder(tableAlias, "SEIR056067", itemAlias, 製造出庫項目型.引落引当済数, typeNumerical))
            item.Append(comma & ItemAliasBuilder(tableAlias, "SEIR056071", itemAlias, 製造出庫項目型.引当状態, typeNumerical))
        Else
            item.Append(comma & ItemDefultBuilder(tableAlias, "0 ", itemAlias, 製造出庫項目型.展開順序番号, 属性.数値))
            item.Append(comma & ItemDefultBuilder(tableAlias, "0 ", itemAlias, 製造出庫項目型.出庫引当済数, 属性.数値))
            item.Append(comma & ItemDefultBuilder(tableAlias, "0 ", itemAlias, 製造出庫項目型.引落引当済数, 属性.数値))
            item.Append(comma & ItemDefultBuilder(tableAlias, "0 ", itemAlias, 製造出庫項目型.引当状態, 属性.数値))
        End If
        'A-20121217_Ver7.50_4↑

        'A-20141105_1↓
        If MyImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 6D Then
            'A-20150520_1↓
            If MyImportParam.Myコントロール情報.使用条件(Myコントロール情報Param.条件型.出庫時原価採用区分, 7D) = True Then
                item.Append(comma & ItemAliasBuilder("SEIR129", "SEIR129008", itemAlias, 製造出庫項目型.経費, typeNumerical))
                'A-20150520_1↑
                'If MyImportParam.Myコントロール情報.MyMOA機能追加.標準原価積上機能 = MOA機能追加定義型.使用有無区分型.使用しない Then   'D-20150520_1
            ElseIf MyImportParam.Myコントロール情報.MyMOA機能追加.標準原価積上機能 = MOA機能追加定義型.使用有無区分型.使用しない Then    'A-20150520_1

                item.Append(comma & ItemAliasBuilder("HANM003", "HANM003S030", itemAlias, 製造出庫項目型.経費, typeNumerical))
            Else
                item.Append(comma & ItemAliasBuilder("SEIS007", "SEIS007019", itemAlias, 製造出庫項目型.経費, typeNumerical))
            End If
        End If
        'A-20141105_1↑

        Return item.ToString
    End Function
    ''' <summary>
    ''' 製造出庫データ取得列名定義
    ''' </summary>
    ''' <param name="tableAlias"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function SelectItem製造出庫取引明細(ByVal 支給管理 As Integer,
                                               Optional ByVal tableAlias As String = "",
                                               Optional ByVal itemAlias As String = "") As String

        Dim typeString As String = GetDefault(属性.文字)
        Dim typeNumerical As String = GetDefault(属性.数値)
        Dim sp As String = Space(1)
        Dim comma As String = Space(1) & ","

        Dim item As New System.Text.StringBuilder
        item.Append(sp & ItemAliasBuilder(tableAlias, "HANR002A027", itemAlias, 製造出庫項目型.手配管理番号, typeNumerical))
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002A026", itemAlias, 製造出庫項目型.手配番号, typeNumerical))
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002001", itemAlias, 製造出庫項目型.伝票日付, typeNumerical))
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002003", itemAlias, 製造出庫項目型.伝票番号, typeNumerical))
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002004", itemAlias, 製造出庫項目型.処理連番, typeNumerical))
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002A029", itemAlias, 製造出庫項目型.行番号, typeNumerical))
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002006", itemAlias, 製造出庫項目型.出庫行番号, typeNumerical))    'A-20130603_1
        item.Append(comma & ItemDefultBuilder(tableAlias, "HANR002", itemAlias, 製造出庫項目型.テーブルID, 属性.文字))
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002019", itemAlias, 製造出庫項目型.品目コード, typeString))
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002020", itemAlias, 製造出庫項目型.品目名, typeString))
        'If 支給管理 = MOA機能追加定義型.支給管理区分型.行う Then
        '    item.Append(comma & ItemAliasBuilder("HANM002", "HANM002A001", itemAlias, 製造出庫項目型.倉庫コード, typeString))
        'Else
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002018", itemAlias, 製造出庫項目型.倉庫コード, typeString))
        'End If
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002A012", itemAlias, 製造出庫項目型.ロケーション, typeString))
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002A010", itemAlias, 製造出庫項目型.ロットNo, typeString))
        item.Append(comma & ItemAliasBuilder("SEIR056", "SEIR056022", itemAlias, 製造出庫項目型.支給出庫予定数量, typeNumerical))
        item.Append(comma & ItemAliasBuilder("SEIR056", "SEIR056027", itemAlias, 製造出庫項目型.引落数量, typeNumerical))
        item.Append(comma & ItemAliasBuilder("SEIR056", "SEIR056045", itemAlias, 製造出庫項目型.強制完納区分, typeNumerical))
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002021", itemAlias, 製造出庫項目型.数量単位, typeString))
        item.Append(comma & ItemAliasBuilder("SEIR056", "SEIR056004", itemAlias, 製造出庫項目型.部番, typeNumerical))
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002053", itemAlias, 製造出庫項目型.行摘要コード, typeString))
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002054", itemAlias, 製造出庫項目型.行摘要１, typeString))
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002055", itemAlias, 製造出庫項目型.行摘要２, typeString))
        item.Append(comma & ItemAliasBuilder("SEIR056", "SEIR056028", itemAlias, 製造出庫項目型.支給出庫済数量, typeNumerical))
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002A030", itemAlias, 製造出庫項目型.費目コード, typeString))
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002A033", itemAlias, 製造出庫項目型.費目区分, typeNumerical))
        item.Append(comma & ItemAliasBuilder("SEIR056", "SEIR056029", itemAlias, 製造出庫項目型.有償支給数量, typeNumerical))
        item.Append(comma & ItemAliasBuilder("SEIR056", "SEIR056030", itemAlias, 製造出庫項目型.無償支給数量, typeNumerical))
        item.Append(comma & ItemAliasBuilder("SEIR056", "SEIR056044", itemAlias, 製造出庫項目型.標準支給単価, typeNumerical))
        item.Append(comma & ItemAliasBuilder("HANM003", "HANM003008", itemAlias, 製造出庫項目型.在庫管理区分, typeNumerical))
        item.Append(comma & ItemAliasBuilder("HANM003", "HANM003054", itemAlias, 製造出庫項目型.在庫引当対象区分, typeNumerical))
        item.Append(comma & ItemAliasBuilder("HANM003", "HANM003A010", itemAlias, 製造出庫項目型.基準倉庫コード, typeString))
        item.Append(comma & ItemAliasBuilder("HANM003", "HANM003A013", itemAlias, 製造出庫項目型.需要数計算単位, typeNumerical))
        item.Append(comma & ItemAliasBuilder("HANM003", "HANM003A014", itemAlias, 製造出庫項目型.正式名称１, typeString))
        item.Append(comma & ItemAliasBuilder("HANM003", "HANM003A015", itemAlias, 製造出庫項目型.正式名称２, typeString))
        item.Append(comma & ItemAliasBuilder("HANM003", "HANM003A016", itemAlias, 製造出庫項目型.正式名称３, typeString))
        item.Append(comma & ItemAliasBuilder("HANM003", "HANM003A024", itemAlias, 製造出庫項目型.ロット管理区分, typeNumerical))
        item.Append(comma & ItemAliasBuilder("HANM003", "HANM003A027", itemAlias, 製造出庫項目型.基準ロケーション, typeString))
        item.Append(comma & ItemAliasBuilder("HANM006", "HANM006004", itemAlias, 製造出庫項目型.倉庫略称, typeString))
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002025", itemAlias, 製造出庫項目型.数量, typeNumerical))
        item.Append(comma & ItemAliasBuilder("SEIR056", "SEIR056034", itemAlias, 製造出庫項目型.原単位区分, typeNumerical))
        item.Append(comma & ItemAliasBuilder("SEIR056", "SEIR056035", itemAlias, 製造出庫項目型.取数分子, typeNumerical))
        item.Append(comma & ItemAliasBuilder("SEIR056", "SEIR056036", itemAlias, 製造出庫項目型.取数分母, typeNumerical))
        item.Append(comma & ItemAliasBuilder("SEIR056", "SEIR056037", itemAlias, 製造出庫項目型.支給区分, typeNumerical))
        item.Append(comma & ItemAliasBuilder("HANM006", "HANM006A002", itemAlias, 製造出庫項目型.対象倉庫区分, typeNumerical))
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002001", itemAlias, 製造出庫項目型.出庫予定日, typeNumerical))
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002A040", itemAlias, 製造出庫項目型.材料費, typeNumerical))
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002A041", itemAlias, 製造出庫項目型.労務費, typeNumerical))
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002A042", itemAlias, 製造出庫項目型.外注費, typeNumerical))

        'A-20111124_3↓
        '自動出庫時、みなし出庫(移動有)の場合は外注/工程倉庫ではなく従属需要の倉庫から出庫する必要がある。
        If _myImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 3D AndAlso
           _myImportParam.Myコントロール情報.MyMOA機能追加.仕掛管理区分 = MOA機能追加定義型.その他管理区分型.行う Then
            item.Append(comma & ItemAliasBuilder("SEIR056", "SEIR056056", itemAlias, 製造出庫項目型.みなし出庫区分, typeNumerical))
            item.Append(comma & ItemAliasBuilder("HANR002_SOKO_IDOU", "HANR002018", itemAlias, 製造出庫項目型.倉庫コード_みなし出庫移動有用, typeString))
            item.Append(comma & ItemAliasBuilder("HANR002_SOKO_IDOU", "HANR002A012", itemAlias, 製造出庫項目型.ロケーション_みなし出庫移動有用, typeString))
            item.Append(comma & ItemAliasBuilder("HANR002_SOKO_IDOU", "HANR002004", itemAlias, 製造出庫項目型.倉庫移動出庫処理連番, typeNumerical))
            'A-20121217_Ver7.50_4↓
        Else
            item.Append(comma & ItemDefultBuilder(tableAlias, "0 ", itemAlias, 製造出庫項目型.みなし出庫区分, 属性.数値))
            item.Append(comma & ItemDefultBuilder(tableAlias, Space(1), itemAlias, 製造出庫項目型.倉庫コード_みなし出庫移動有用, 属性.文字))
            item.Append(comma & ItemDefultBuilder(tableAlias, Space(1), itemAlias, 製造出庫項目型.ロケーション_みなし出庫移動有用, 属性.文字))
            item.Append(comma & ItemDefultBuilder(tableAlias, "0 ", itemAlias, 製造出庫項目型.倉庫移動出庫処理連番, 属性.数値))
            'A-20121217_Ver7.50_4↑
        End If
        'A-20111124_3↑

        'A-20121217_Ver7.50_4↓
        If _myImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 4.0 Then
            item.Append(comma & ItemAliasBuilder("SEIR056", "SEIR056003", itemAlias, 製造出庫項目型.展開順序番号, typeNumerical))
            item.Append(comma & ItemAliasBuilder("SEIR056", "SEIR056065", itemAlias, 製造出庫項目型.出庫引当済数, typeNumerical))
            item.Append(comma & ItemAliasBuilder("SEIR056", "SEIR056067", itemAlias, 製造出庫項目型.引落引当済数, typeNumerical))
            item.Append(comma & ItemAliasBuilder("SEIR056", "SEIR056071", itemAlias, 製造出庫項目型.引当状態, typeNumerical))
        Else
            item.Append(comma & ItemDefultBuilder(tableAlias, "0 ", itemAlias, 製造出庫項目型.展開順序番号, 属性.数値))
            item.Append(comma & ItemDefultBuilder(tableAlias, "0 ", itemAlias, 製造出庫項目型.出庫引当済数, 属性.数値))
            item.Append(comma & ItemDefultBuilder(tableAlias, "0 ", itemAlias, 製造出庫項目型.引落引当済数, 属性.数値))
            item.Append(comma & ItemDefultBuilder(tableAlias, "0 ", itemAlias, 製造出庫項目型.引当状態, 属性.数値))
        End If
        'A-20121217_Ver7.50_4↑

        'A-20141105_1↓
        If MyImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 6D Then
            item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002S018", itemAlias, 製造出庫項目型.経費, typeNumerical))
        End If
        'A-20141105_1↑

        Return item.ToString
    End Function

#End Region

#Region "個別出庫取得値"

    ''' <summary>
    ''' 個別出庫データ取得列名定義
    ''' </summary>
    ''' <param name="tableAlias"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function SelectItem個別出庫取引明細(Optional ByVal tableAlias As String = "",
                                               Optional ByVal itemAlias As String = "") As String

        Dim typeString As String = GetDefault(属性.文字)
        Dim typeNumerical As String = GetDefault(属性.数値)
        Dim sp As String = Space(1)
        Dim comma As String = Space(1) & ","

        Dim item As New System.Text.StringBuilder

        item.Append(sp & ItemAliasBuilder(tableAlias, "HANR002A027", itemAlias, 製造出庫項目型.手配管理番号, typeNumerical))
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002A026", itemAlias, 製造出庫項目型.手配番号, typeNumerical))
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002001", itemAlias, 製造出庫項目型.伝票日付, typeNumerical))
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002001", itemAlias, 製造出庫項目型.変更前伝票日付, typeNumerical))
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002003", itemAlias, 製造出庫項目型.伝票番号, typeNumerical))
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002004", itemAlias, 製造出庫項目型.処理連番, typeNumerical))
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002006", itemAlias, 製造出庫項目型.行番号, typeNumerical))
        item.Append(comma & ItemDefultBuilder(tableAlias, "HANR002", itemAlias, 製造出庫項目型.テーブルID, 属性.文字))
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002019", itemAlias, 製造出庫項目型.品目コード, typeString))
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002020", itemAlias, 製造出庫項目型.品目名, typeString))
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002018", itemAlias, 製造出庫項目型.倉庫コード, typeString))
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002A012", itemAlias, 製造出庫項目型.ロケーション, typeString))
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002A010", itemAlias, 製造出庫項目型.ロットNo, typeString))
        item.Append(comma & ItemDefultBuilder(tableAlias, "0", itemAlias, 製造出庫項目型.支給出庫予定数量, 属性.数値))
        item.Append(comma & ItemDefultBuilder(tableAlias, "0", itemAlias, 製造出庫項目型.引落数量, 属性.数値))
        item.Append(comma & ItemDefultBuilder(tableAlias, "0", itemAlias, 製造出庫項目型.強制完納区分, 属性.数値))
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002021", itemAlias, 製造出庫項目型.数量単位, typeString))
        item.Append(comma & ItemDefultBuilder(tableAlias, "0", itemAlias, 製造出庫項目型.部番, 属性.数値))
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002053", itemAlias, 製造出庫項目型.行摘要コード, typeString))
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002054", itemAlias, 製造出庫項目型.行摘要１, typeString))
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002055", itemAlias, 製造出庫項目型.行摘要２, typeString))
        item.Append(comma & ItemDefultBuilder(tableAlias, "0", itemAlias, 製造出庫項目型.支給出庫済数量, 属性.数値))
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002A030", itemAlias, 製造出庫項目型.費目コード, typeString))
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002A033", itemAlias, 製造出庫項目型.費目区分, typeNumerical))
        item.Append(comma & ItemDefultBuilder(tableAlias, "0", itemAlias, 製造出庫項目型.有償支給数量, 属性.数値))
        item.Append(comma & ItemDefultBuilder(tableAlias, "0", itemAlias, 製造出庫項目型.無償支給数量, 属性.数値))
        item.Append(comma & ItemDefultBuilder(tableAlias, "0", itemAlias, 製造出庫項目型.標準支給単価, 属性.数値))
        '
        item.Append(comma & ItemAliasBuilder("HANM003", "HANM003008", itemAlias, 製造出庫項目型.在庫管理区分, typeNumerical))
        item.Append(comma & ItemAliasBuilder("HANM003", "HANM003054", itemAlias, 製造出庫項目型.在庫引当対象区分, typeNumerical))
        item.Append(comma & ItemAliasBuilder("HANM003", "HANM003A010", itemAlias, 製造出庫項目型.基準倉庫コード, typeString))
        item.Append(comma & ItemAliasBuilder("HANM003", "HANM003A013", itemAlias, 製造出庫項目型.需要数計算単位, typeNumerical))
        item.Append(comma & ItemAliasBuilder("HANM003", "HANM003A014", itemAlias, 製造出庫項目型.正式名称１, typeString))
        item.Append(comma & ItemAliasBuilder("HANM003", "HANM003A015", itemAlias, 製造出庫項目型.正式名称２, typeString))
        item.Append(comma & ItemAliasBuilder("HANM003", "HANM003A016", itemAlias, 製造出庫項目型.正式名称３, typeString))
        item.Append(comma & ItemAliasBuilder("HANM003", "HANM003A024", itemAlias, 製造出庫項目型.ロット管理区分, typeNumerical))
        item.Append(comma & ItemAliasBuilder("HANM003", "HANM003A027", itemAlias, 製造出庫項目型.基準ロケーション, typeString))
        item.Append(comma & ItemAliasBuilder("HANM006", "HANM006004", itemAlias, 製造出庫項目型.倉庫略称, typeString))
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002025", itemAlias.ToString, 製造出庫項目型.数量, typeNumerical))
        item.Append(comma & ItemAliasBuilder("HANM006", "HANM006A002", itemAlias, 製造出庫項目型.対象倉庫区分, typeNumerical))
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002A040", itemAlias, 製造出庫項目型.材料費, typeNumerical))
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002A041", itemAlias, 製造出庫項目型.労務費, typeNumerical))
        item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002A042", itemAlias, 製造出庫項目型.外注費, typeNumerical))

        'A-20141105_1↓
        If MyImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 6D Then
            item.Append(comma & ItemAliasBuilder(tableAlias, "HANR002S018", itemAlias, 製造出庫項目型.経費, typeNumerical))
        End If
        'A-20141105_1↑

        Return item.ToString
    End Function

#End Region

#Region "ロット明細(製造実績)取得値"

    ''' <summary>
    ''' ロット明細取得列名定義
    ''' </summary>
    ''' <param name="tableAlias"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function SelectItemロット明細_出庫(Optional ByVal tableAlias As String = "") As String

        Dim typeString As String = GetDefault(属性.文字)
        Dim typeNumerical As String = GetDefault(属性.数値)
        Dim sp As String = Space(1)
        Dim comma As String = Space(1) & ","

        Dim item As New System.Text.StringBuilder

        item.Append(sp & ItemBuilder(tableAlias, "SEIR008001", "", typeNumerical))                  ' 伝票区分
        item.Append(comma & ItemBuilder(tableAlias, "SEIR008002", "", typeNumerical))               ' 処理連番
        item.Append(comma & ItemBuilder(tableAlias, "SEIR008003", "", typeNumerical))               ' 行番号
        item.Append(comma & ItemBuilder(tableAlias, "SEIR008004", "", typeNumerical))               ' ロット明細連番
        item.Append(comma & ItemBuilder(tableAlias, "SEIR008005", "", typeNumerical))               ' 入出庫日
        item.Append(comma & ItemBuilder(tableAlias, "SEIR008007", "", typeString))                  ' 倉庫コード
        item.Append(comma & ItemBuilder(tableAlias, "SEIR008009", "", typeString))                  ' ロケーションコード
        item.Append(comma & ItemBuilder(tableAlias, "SEIR008010", "", typeString))                  ' 品目コード
        item.Append(comma & ItemBuilder(tableAlias, "SEIR008014", "", typeString))                  ' ロットNO
        item.Append(comma & ItemBuilder(tableAlias, "SEIR008017", "", typeNumerical))               ' 出庫数量

        Return item.ToString
    End Function

#End Region

    'A-20121228_2↓
#Region "元需要取得"

    Friend Function Select元需要_個別受注(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                          ByVal 発注番号 As Long
                   ) As String Implements IMyQueryMaker.Select元需要_個別受注    'X1変換Tool-20170508

        Dim sql As New System.Text.StringBuilder

        sql.Append(" SELECT ")
        sql.Append(" " & MyBase.QueryWrapper.AddIsNull() & " (HANR005003, 0) RENBAN ")
        sql.Append("," & MyBase.QueryWrapper.AddIsNull() & " (HANR005004, 0) GYONO ")

        sql.Append(" FROM ")
        sql.Append(Me.ExchangeTableName("SEI10M050SEIMST") & " " & QueryWrapper.AddNoLock)    'X1変換Tool-20170509

        sql.Append(" INNER JOIN ")
        sql.Append(Me.ExchangeTableName("HAN10R005JUHACHUM") & " " & QueryWrapper.AddNoLock())    'X1変換Tool-20170509
        sql.Append(" ON HANR005002 = 2 ")      '伝票区分＝2:受注
        sql.Append("AND HANR005003 = SEIM050019 ")
        sql.Append("AND HANR005004 = SEIM050020 ")

        sql.Append(" WHERE ")
        sql.Append("     " & "SEIM050011 = " & AddParamInfo(paramInfo, "SEIM050011", DbType.Decimal, 0, 10, 0, 発注番号))
        sql.Append(" AND " & "SEIM050015 = 2 ")

        sql.Append(QueryWrapper.AddUR())

        Return sql.ToString

    End Function

    Friend Function Select元需要_従属需要(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                          ByVal 発注区分 As Integer,
                                          ByVal 発注番号 As Long,
                                          ByVal 手配管理番号 As Long
                   ) As String Implements IMyQueryMaker.Select元需要_従属需要    'X1変換Tool-20170508

        Dim sql As New System.Text.StringBuilder

        sql.Append(" SELECT ")
        sql.Append(" " & MyBase.QueryWrapper.AddIsNull() & " (SEIR056002, 0) RENBAN ")
        sql.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SEIR056003, 0) GYONO ")

        sql.Append(" FROM ")
        sql.Append(Me.ExchangeTableName("SEI10M050SEIMST") & " " & QueryWrapper.AddUpdLock)    'X1変換Tool-20170509

        sql.Append(" INNER JOIN ")
        sql.Append(Me.ExchangeTableName("SEI10R056JUZOKU") & " " & QueryWrapper.AddNoLock())    'X1変換Tool-20170509
        sql.Append("  ON SEIR056046 = SEIM050001 ")
        If MyImportParam.Myコントロール情報.Myオプション区分.原価管理 = オプション区分定義型.区分型.行う Then
            sql.Append(" AND SEIR056049 in (1, 2) ")       '製番手配 or 需要数在庫引当
        End If

        sql.Append(" WHERE ")
        If 発注区分 = 1 Then
            sql.Append("     " & "SEIM050011 = " & AddParamInfo(paramInfo, "SEIM050011", DbType.Decimal, 0, 10, 0, 発注番号))
            sql.Append(" AND " & "SEIM050015 = 2 ")
        Else
            sql.Append("     " & "SEIM050011 = " & AddParamInfo(paramInfo, "SEIM050011", DbType.Decimal, 0, 10, 0, 手配管理番号))
            sql.Append(" AND " & "SEIM050015 = 1 ")
        End If

        sql.Append(QueryWrapper.AddUR())

        Return sql.ToString

    End Function

    Friend Function Select元需要_従属需要予定(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                              ByVal 発注区分 As Integer,
                                              ByVal 発注番号 As Long,
                                              ByVal 手配管理番号 As Long
                   ) As String Implements IMyQueryMaker.Select元需要_従属需要予定    'X1変換Tool-20170508

        Dim sql As New System.Text.StringBuilder

        sql.Append(" SELECT ")
        sql.Append(" " & MyBase.QueryWrapper.AddIsNull() & " (SEIW054002, 0) RENBAN ")
        sql.Append("," & MyBase.QueryWrapper.AddIsNull() & " (SEIW054003, 0) GYONO ")

        sql.Append(" FROM ")
        sql.Append(Me.ExchangeTableName("SEI10M050SEIMST") & " " & QueryWrapper.AddUpdLock)    'X1変換Tool-20170509

        sql.Append(" INNER JOIN ")
        sql.Append(Me.ExchangeTableName("SEI10W054JUZOKUYOTEI") & " " & QueryWrapper.AddNoLock())    'X1変換Tool-20170509
        sql.Append("  ON SEIW054017 = SEIM050001 ")
        If MyImportParam.Myコントロール情報.Myオプション区分.原価管理 = オプション区分定義型.区分型.行う Then
            sql.Append(" AND SEIW054040 in (1, 2) ")       '製番手配 or 需要数在庫引当
        End If

        sql.Append(" WHERE ")
        If 発注区分 = 1 Then
            sql.Append("     " & "SEIM050011 = " & AddParamInfo(paramInfo, "SEIM050011", DbType.Decimal, 0, 10, 0, 発注番号))
            sql.Append(" AND " & "SEIM050015 = 2 ")
        Else
            sql.Append("     " & "SEIM050011 = " & AddParamInfo(paramInfo, "SEIM050011", DbType.Decimal, 0, 10, 0, 手配管理番号))
            sql.Append(" AND " & "SEIM050015 = 1 ")
        End If

        sql.Append(QueryWrapper.AddUR())

        Return sql.ToString

    End Function

#End Region
    'A-20121228_2↑

    'A-20141105_1↓
#Region "標準原価積上"

    ''' <summary>
    ''' 標準原価積上テーブルから最新年月のデータを取得
    ''' </summary>
    ''' <param name="手配番号"></param>
    ''' <param name="paramInfo"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function MakeSQL標準原価積上(ByVal 手配番号 As Long,
                                        ByRef paramInfo As ParamInfoList) As String

        Dim sql As New System.Text.StringBuilder

        sql.Append(" SELECT * FROM ")
        sql.Append(" ( ")
        sql.Append(" SELECT ")
        sql.Append(" " & SelectItem標準原価積上())

        sql.Append(" FROM ")
        sql.Append(Me.ExchangeTableName("SEI10R056JUZOKU ") & QueryWrapper.AddNoLock)    'X1変換Tool-20170509

        sql.Append(" LEFT OUTER JOIN ")
        sql.Append(Me.ExchangeTableName("SEI10S007TUMIAGE ") & QueryWrapper.AddNoLock)    'X1変換Tool-20170509
        sql.Append(" ON SEIR056007 =  SEIS007002 ")
        sql.Append("  AND SEIS007003 = 0 ")
        sql.Append("  AND SEIS007022 = 1 ")

        sql.Append(" WHERE ")
        '伝票区分
        sql.Append(" SEIR056002 = " & AddParamInfo(paramInfo, "SEIR056002_S007", DbType.Decimal, 0, 10, 0, 手配番号))

        '対象の品目で最新年月のを取得
        sql.Append(" AND SEIS007001 = ( SELECT MAX(SEIS007001) FROM ")
        sql.Append(Me.ExchangeTableName("SEI10S007TUMIAGE ") & "SEIS007_2" & QueryWrapper.AddNoLock)    'X1変換Tool-20170509
        sql.Append(" WHERE SEIR056007 = SEIS007_2.SEIS007002 ) ")

        sql.Append(" ) SUBTBL ")

        sql.Append(QueryWrapper.AddUR())

        Return sql.ToString

    End Function

    Friend Function SelectItem標準原価積上() As String

        Dim item As New System.Text.StringBuilder

        item.Append(" " & ItemBuilder("", "SEIR056007", "", GetDefault(属性.文字)))                 '品目コード
        item.Append("," & ItemBuilder("", "SEIS007001", "", GetDefault(属性.数値)))                 '対象年月度
        item.Append("," & ItemBuilder("", "SEIS007003", "", GetDefault(属性.数値)))                 '手順№
        item.Append("," & ItemBuilder("", "SEIS007016", "", GetDefault(属性.数値)))                 '積上　直接材料費
        item.Append("," & ItemBuilder("", "SEIS007017", "", GetDefault(属性.数値)))                 '積上　直接労務費
        item.Append("," & ItemBuilder("", "SEIS007018", "", GetDefault(属性.数値)))                 '積上　直接外注費
        item.Append("," & ItemBuilder("", "SEIS007019", "", GetDefault(属性.数値)))                 '積上　直接経費

        Return item.ToString

    End Function

#End Region
    'A-20141105_1↑

    'A-20150520_1↓
#Region "品目別原価"

    ''' <summary>
    ''' 品目別原価計算結果テーブルから伝票日付以前の最新年月のデータを取得
    ''' </summary>
    ''' <param name="手配番号"></param>
    ''' <param name="伝票日付"></param>
    ''' <param name="paramInfo"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function MakeSQL品目別原価計算結果(ByVal 手配番号 As Long,
                                        ByVal 伝票日付 As Decimal,
                                        ByRef paramInfo As ParamInfoList) As String

        Dim sql As New System.Text.StringBuilder

        sql.Append(" SELECT * FROM ")
        sql.Append(" ( ")
        sql.Append(" SELECT ")
        sql.Append(" " & SelectItem品目別原価計算結果())

        sql.Append(" FROM ")
        sql.Append(Me.ExchangeTableName("SEI10R056JUZOKU ") & QueryWrapper.AddNoLock)    'X1変換Tool-20170509

        sql.Append(" LEFT OUTER JOIN ")
        sql.Append(Me.ExchangeTableName("SEI10R129HINGENKEKKA ") & QueryWrapper.AddNoLock)    'X1変換Tool-20170509
        sql.Append(" ON SEIR056007 =  SEIR129002 ")
        sql.Append("  AND SEIR129003 = 0 ")

        sql.Append(" WHERE ")
        '伝票区分
        sql.Append(" SEIR056002 = " & AddParamInfo(paramInfo, "SEIR056002_R129", DbType.Decimal, 0, 10, 0, 手配番号))

        '対象の品目で伝票日付以前の最新年月を取得
        sql.Append(" AND SEIR129001 = ( SELECT MAX(SEIR129001) FROM ")
        sql.Append(Me.ExchangeTableName("SEI10R129HINGENKEKKA ") & "SEIR129_2" & QueryWrapper.AddNoLock)    'X1変換Tool-20170509
        sql.Append(" WHERE SEIR129_2.SEIR129001 <= " & AddParamInfo(paramInfo, "SEIR129001", DbType.Decimal, 0, 6, 0, 伝票日付))
        sql.Append("   AND SEIR056007 = SEIR129_2.SEIR129002  ")
        sql.Append("   AND SEIR129_2.SEIR129003 = 0 ) ")

        sql.Append(" ) SUBTBL ")

        sql.Append(QueryWrapper.AddUR())

        Return sql.ToString

    End Function

    Friend Function SelectItem品目別原価計算結果() As String

        Dim item As New System.Text.StringBuilder

        item.Append(" " & ItemBuilder("", "SEIR129001", "", GetDefault(属性.数値)))                 '対象年月度
        item.Append("," & ItemBuilder("", "SEIR056007", "", GetDefault(属性.文字)))                 '品目コード
        item.Append("," & ItemBuilder("", "SEIR129003", "", GetDefault(属性.数値)))                 '手順№
        item.Append("," & ItemBuilder("", "SEIR129005", "", GetDefault(属性.数値)))                 '直接材料費
        item.Append("," & ItemBuilder("", "SEIR129006", "", GetDefault(属性.数値)))                 '直接労務費
        item.Append("," & ItemBuilder("", "SEIR129007", "", GetDefault(属性.数値)))                 '直接外注費
        item.Append("," & ItemBuilder("", "SEIR129008", "", GetDefault(属性.数値)))                 '直接経費

        Return item.ToString

    End Function

#End Region
    'A-20150520_1↑

#Region "内部メソッド"

    ''' <summary>
    ''' 取得項目の組み立て
    ''' </summary>
    ''' <param name="tableAlias">対象テーブルの別名</param>
    ''' <param name="itemName">取得列名</param>
    ''' <param name="itemAlias">取得列名の別名</param>
    ''' <param name="itemDefault">NULL時の初期値</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ItemBuilder(
                                ByVal tableAlias As String,
                                ByVal itemName As String,
                                ByVal itemAlias As String,
                                ByVal itemDefault As String) As String

        Dim st As New System.Text.StringBuilder

        st.Append(QueryWrapper.AddIsNull)
        st.Append(" (")
        If Not String.IsNullOrEmpty(tableAlias) Then
            st.Append(tableAlias & ".")
        End If
        st.Append(itemName)
        st.Append(",")
        st.Append(itemDefault)
        st.Append(") ")
        If Not String.IsNullOrEmpty(itemAlias) Then
            st.Append(itemAlias)
        ElseIf Not String.IsNullOrEmpty(tableAlias) Then
            st.Append(tableAlias & "_" & itemName)
        Else
            st.Append(itemName)
        End If

        Return st.ToString
    End Function

    ''' <summary>
    ''' 取得項目の組み立て
    ''' </summary>
    ''' <param name="tableAlias">対象テーブルの別名</param>
    ''' <param name="itemName">取得列名</param>
    ''' <param name="itemAlias">取得列名の別名</param>
    ''' <param name="itemColum">列番号</param>
    ''' <param name="itemDefault">NULL時の初期値</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ItemAliasBuilder(
                                 ByVal tableAlias As String,
                                 ByVal itemName As String,
                                 ByVal itemAlias As String,
                                 ByVal itemColum As Integer,
                                 ByVal itemDefault As String) As String

        Dim st As New System.Text.StringBuilder
        Dim itemColumName As String
        st.Append(QueryWrapper.AddIsNull)
        st.Append(" (")
        If Not String.IsNullOrEmpty(tableAlias) Then
            st.Append(tableAlias & ".")
        End If
        st.Append(itemName)
        st.Append(",")
        st.Append(itemDefault)
        st.Append(") ")

        If Not String.IsNullOrEmpty(itemAlias) Then
            itemColumName = itemAlias & "_" & itemAlias & Format(itemColum, "000")
        ElseIf Not String.IsNullOrEmpty(tableAlias) Then
            itemColumName = tableAlias & "_" & itemName & Format(itemColum, "000")
        Else
            itemColumName = itemName
        End If

        st.Append(itemColumName)
        Return st.ToString
    End Function

    ''' <summary>
    ''' 取得項目の組み立て
    ''' </summary>
    ''' <param name="tableAlias">対象テーブルの別名</param>
    ''' <param name="itemValue">直接設定値</param>
    ''' <param name="itemAlias">取得列名の別名</param>
    ''' <param name="itemColum">列番号</param>
    ''' <param name="type">属性</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ItemDefultBuilder(
                                 ByVal tableAlias As String,
                                 ByVal itemValue As String,
                                 ByVal itemAlias As String,
                                 ByVal itemColum As Integer,
                                 ByVal type As 属性) As String

        Dim st As New System.Text.StringBuilder
        Dim itemColumName As String

        st.Append(Space(1))

        If type = 属性.数値 Then
            If Not String.IsNullOrEmpty(itemValue) Then
                st.Append(itemValue)
            Else
                st.Append("0 ")
            End If
        Else
            st.Append("'")
            If Not String.IsNullOrEmpty(itemValue) Then
                st.Append(itemValue)
            Else
                st.Append(Space(1))
            End If
            st.Append("' ")
        End If


        If Not String.IsNullOrEmpty(itemAlias) Then
            itemColumName = Space(1) & itemAlias & "_" & itemAlias & Format(itemColum, "000")
        ElseIf Not String.IsNullOrEmpty(tableAlias) Then
            itemColumName = Space(1) & tableAlias & "_" & tableAlias & Format(itemColum, "000")
        Else
            itemColumName = tableAlias
        End If

        st.Append(itemColumName)
        Return st.ToString
    End Function

    Private Enum 属性
        文字
        数値
    End Enum

    Private Function GetDefault(ByVal type As 属性) As String
        Dim st As String = ""

        Select Case type
            Case 属性.文字
                st = "' '"
            Case 属性.数値
                st = "0."
            Case Else
        End Select
        Return st

    End Function

#End Region

    'A-CUST20190830↓
#Region "カスタマイズ"

#Region "■発注明細■"

    '存在チェック
    Public Function Select発注伝票CUST(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal 発注番号 As Long,
                                            ByVal 発注行番号 As Integer
                    ) As String Implements IMyQueryMaker.Select発注伝票CUST

        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(QueryWrapper.AddIndexHintOracle(GetIndexHint("SEL_C_2")))
        query.Append(" MJCH.HANR005003 HANR005003 ")        '発注番号
        query.Append(",MJCH.HANR005004 HANR005004 ")        '発注行番号
        query.Append(",MJCH.HANR005017 HANR005017 ")        '商品コード
        query.Append(",MJCH.HANR005038 HANR005038 ")        '強制完納区分

        query.Append("FROM " & MyBase.ExchangeTableName("HAN10R005JUHACHUM") & " MJCH ")
        query.Append(MyBase.QueryWrapper.AddNoLock(GetIndexHint("R005_C_2")))

        query.Append("WHERE MJCH.HANR005002 = 1 ")
        query.Append("  AND MJCH.HANR005003 = " & AddParamInfo(paramInfo, "HANR005003", DbType.Decimal, 0, 10, 0, 発注番号))
        query.Append("  AND MJCH.HANR005004 = 1 ")

        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString

    End Function
#End Region

#Region "■発注内訳■"

    '存在チェック
    Public Function Select発注内訳伝票CUST(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal 発注番号 As Long,
                                            ByVal 発注行番号 As Integer,
                                            ByVal 内訳番号 As Integer
                    ) As String Implements IMyQueryMaker.Select発注内訳伝票CUST

        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(QueryWrapper.AddIndexHintOracle(GetIndexHint("SEL_M_1")))
        query.Append(" MJCH.SEIRA01001 SEIRA01001 ")        '発注番号
        query.Append(",MJCH.SEIRA01002 SEIRA01002 ")        '発注行番号
        query.Append(",MJCH.SEIRA01003 SEIRA01003 ")        '商品コード
        query.Append(",MJCH.SEIRA01009 SEIRA01009 ")        '発注数量 'A-CUST20190830 '2020/08/06
        query.Append(",MJCH.SEIRA01011 SEIRA01011 ")        '仕入済数量 'A-CUST20190830 '2020/08/06
        query.Append(",MJCH.SEIRA01014 SEIRA01014 ")        '強制完納区分
        query.Append(",MJCH.SEIRA01015 SEIRA01015 ")        '強制完納区分

        query.Append("FROM " & MyBase.ExchangeTableName("SEI98RA01HACHUUTIWAKE") & " MJCH ")
        query.Append(MyBase.QueryWrapper.AddNoLock(GetIndexHint("RA01_M_1")))

        query.Append("WHERE MJCH.SEIRA01001 = " & AddParamInfo(paramInfo, "SEIRA01001", DbType.Decimal, 0, 10, 0, 発注番号))
        query.Append("  AND MJCH.SEIRA01002 = 1 ")
        query.Append("  AND MJCH.SEIRA01003 = " & AddParamInfo(paramInfo, "SEIRA01003", DbType.Decimal, 0, 2, 0, 内訳番号))

        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString

    End Function
#End Region

#Region "■入出荷予定明細■"

    '存在チェック
    Public Function Select入出荷予定伝票CUST(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal 入出荷予定番号 As Long,
                                            ByVal 入出荷予定行番号 As Integer
                    ) As String Implements IMyQueryMaker.Select入出荷予定伝票CUST

        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(QueryWrapper.AddIndexHintOracle(GetIndexHint("SEL_C_3")))
        query.Append(" MJCH.SEIRA03001 SEIRA03001 ")        '発注番号
        query.Append(",MJCH.SEIRA03002 SEIRA03002 ")        '発注行番号
        query.Append(",MJCH.SEIRA03013 SEIRA03013 ")        '商品コード
        query.Append(",MJCH.SEIRA03018 SEIRA03018 ")        '
        query.Append(",MJCH.SEIRA03024 SEIRA03024 ")        '
        query.Append(",MJCH.SEIRA03029 SEIRA03029 ")        '強制完納区分

        query.Append("FROM " & MyBase.ExchangeTableName("SEI98RA03NYUSHUKOYOTEIM") & " MJCH ")
        query.Append(MyBase.QueryWrapper.AddNoLock(GetIndexHint("RA03_C_3")))

        query.Append("WHERE MJCH.SEIRA03001 = " & AddParamInfo(paramInfo, "SEIRA03001", DbType.Decimal, 0, 10, 0, 入出荷予定番号))
        query.Append("  AND MJCH.SEIRA03002 = " & AddParamInfo(paramInfo, "SEIRA03002", DbType.Decimal, 0, 3, 0, 入出荷予定行番号))
        query.Append("  AND MJCH.SEIRA03010 = 1 ")

        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString

    End Function

    Public Function Select入出荷予定伝票CUST(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal 入出荷予定番号 As Long
                    ) As String Implements IMyQueryMaker.Select入出荷予定伝票CUST

        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(QueryWrapper.AddIndexHintOracle(GetIndexHint("SEL_C_4")))
        query.Append(" MJCH.SEIRA03028 SEIRA03028 ")        '残区分

        query.Append("FROM " & MyBase.ExchangeTableName("SEI98RA03NYUSHUKOYOTEIM") & " MJCH ")
        query.Append(MyBase.QueryWrapper.AddNoLock(GetIndexHint("RA03_C_4")))

        query.Append("WHERE MJCH.SEIRA03001 = " & AddParamInfo(paramInfo, "SEIRA03001", DbType.Decimal, 0, 10, 0, 入出荷予定番号))
        query.Append("  AND MJCH.SEIRA03010 = 1 ")

        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString

    End Function
#End Region

#Region "■入出荷予定ヘッダー■"

    '存在チェック
    Public Function Select入出荷予定ヘッダーCUST(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal 入出荷予定番号 As Long
                    ) As String Implements IMyQueryMaker.Select入出荷予定ヘッダーCUST

        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(QueryWrapper.AddIndexHintOracle(GetIndexHint("SEL_C_4")))
        query.Append(" MJCH.SEIRA02001 SEIRA02001 ")        '発注番号
        query.Append(",MJCH.SEIRA02016 SEIRA02016 ")        '残区分

        query.Append("FROM " & MyBase.ExchangeTableName("SEI98RA02NYUSHUKOYOTEIH") & " MJCH ")
        query.Append(MyBase.QueryWrapper.AddNoLock(GetIndexHint("RA02_C_4")))

        query.Append("WHERE MJCH.SEIRA02001 = " & AddParamInfo(paramInfo, "SEIRA02001", DbType.Decimal, 0, 10, 0, 入出荷予定番号))
        query.Append("  AND MJCH.SEIRA02016 = 0 ")

        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString

    End Function
#End Region

#Region "■入出荷予定明細■"

    '存在チェック
    Public Function Select入出荷予定明細CUST(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal 入出荷予定番号 As Long,
                                            ByVal 入出荷予定行番号 As Integer
                    ) As String Implements IMyQueryMaker.Select入出荷予定明細CUST

        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(QueryWrapper.AddIndexHintOracle(GetIndexHint("SEL_C_4")))
        query.Append(" MJCH.SEIRA03001 SEIRA03001 ")        '発注番号
        query.Append(",MJCH.SEIRA03002 SEIRA03002 ")        '発注行番号
        query.Append(",MJCH.SEIRA03013 SEIRA03013 ")        '商品コード
        query.Append(",MJCH.SEIRA03018 SEIRA03018 ")        '
        query.Append(",MJCH.SEIRA03024 SEIRA03024 ")        '
        query.Append(",MJCH.SEIRA03029 SEIRA03029 ")        '強制完納区分

        query.Append("FROM " & MyBase.ExchangeTableName("SEI98RA03NYUSHUKOYOTEIM") & " MJCH ")
        query.Append(MyBase.QueryWrapper.AddNoLock(GetIndexHint("RA03_C_4")))

        query.Append("WHERE MJCH.SEIRA03001 = " & AddParamInfo(paramInfo, "SEIRA03001", DbType.Decimal, 0, 10, 0, 入出荷予定番号))
        query.Append("  AND MJCH.SEIRA03002 = " & AddParamInfo(paramInfo, "SEIRA03002", DbType.Decimal, 0, 3, 0, 入出荷予定行番号))
        query.Append("  AND MJCH.SEIRA03028 = 0 ")

        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString

    End Function
#End Region

#Region "■内職者マスター■"

    '存在チェック
    Public Function SelectSEIMA02PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                            ByVal コード As String
                    ) As String Implements IMyQueryMaker.SelectSEIMA02PrimaryKey

        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(" SEIMA02001 ")
        query.Append(",SEIMA02002 ")
        query.Append(",SEIMA02003 ")

        query.Append("FROM " & MyBase.ExchangeTableName("SEI98MA02NAISYOKUSYA") & " ")
        query.Append(MyBase.QueryWrapper.AddNoLock())
        query.Append("WHERE ")
        query.Append("SEIMA02001 = " & AddParamInfo(paramInfo, "SEIMA02001", DbType.AnsiStringFixedLength, 6, 0, 0, コード))
        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString

    End Function

#End Region

#Region "■テキスト管理■"
    '任意項目チェック
    Public Function UpdateHANC020(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                          ByVal importParam As ImportParam
                    ) As String Implements IMyQueryMaker.UpdateHANC020
        Dim query As New System.Text.StringBuilder

        query.Append(" UPDATE " & C020ExchangeTableID_S() & " ")

        query.Append(" SET ")
        query.Append(_C020ColID.x007入力元フォルダ & " = " & AddParamInfo(paramInfo, "HANC020007", DbType.String, 200, 0, 0, importParam.退避フォルダ))
        query.Append("," & _C020ColID.x008入力元ファイル名 & " = " & AddParamInfo(paramInfo, "HANC020008", DbType.String, 200, 0, 0, importParam.退避ファイル名))

        query.Append(" WHERE ")
        query.Append(_C020ColID.x001分割コード & " = " & AddParamInfo(paramInfo, "HANC020001", DbType.AnsiStringFixedLength, 3, 0, 0, importParam.KanriTableData.分割コード))

        Return query.ToString
    End Function

    Public Function C020ExchangeTableID_S() As String
        Return MyBase.ExchangeTableName(テキストファイル取込管理テーブルID)
    End Function
#End Region

    Public Function UpdateHANW091(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                              ByVal 更新データ As String,
                              ByVal 行番号 As Integer,
                              ByVal 分割コード As String
                ) As String Implements IMyQueryMaker.UpdateHANW091

        Dim query As New System.Text.StringBuilder

        query.Append("UPDATE " & W091ExchangeTableID(分割コード) & " ")

        query.Append(" SET ")
        query.Append(" HANW091002 = " & AddParamInfo(paramInfo, "HANW091002", DbType.String, 20000, 0, 0, 更新データ))
        query.Append(" WHERE ")
        query.Append(_W091ColID.行番号 & " = " & AddParamInfo(paramInfo, "行番号", DbType.Decimal, 0, 6, 0, 行番号))

        Return query.ToString

    End Function

#Region "発注内訳更新用"
    Public Function UpdateSEIRA01(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                  ByVal 更新データ As WorkTableUnitData,
                                  ByVal 発注内訳残区分 As Integer) As String Implements IMyQueryMaker.UpdateSEIRA01
        Dim query As New System.Text.StringBuilder

        query.Append(" UPDATE ")
        query.Append(Me.ExchangeTableName("SEI98RA01HACHUUTIWAKE"))

        query.Append(" SET ")
        query.Append("  SEIRA01011 = SEIRA01011 + " & AddParamInfo(paramInfo, "SEIRA01011", DbType.Decimal, 0, 19, 4, 更新データ.仕入明細(0).R002025))
        query.Append(" ,SEIRA01012 = SEIRA01012 + 1 ")
        query.Append(" ,SEIRA01013 = " & AddParamInfo(paramInfo, "SEIRA01013", DbType.Decimal, 0, 8, 0, 更新データ.仕入明細(0).R002001))
        query.Append(" ,SEIRA01014 = " & AddParamInfo(paramInfo, "SEIRA01014", DbType.Decimal, 0, 1, 0, 発注内訳残区分))
        query.Append(" ,SEIRA01015 = " & AddParamInfo(paramInfo, "SEIRA01015", DbType.Decimal, 0, 1, 0, 更新データ.仕入明細(0).R002052))

        query.Append(" WHERE SEIRA01001 = " & AddParamInfo(paramInfo, "SEIRA01001", DbType.Decimal, 0, 10, 0, 更新データ.仕入明細(0).R002011))
        query.Append("   AND SEIRA01002 = " & AddParamInfo(paramInfo, "SEIRA01002", DbType.Decimal, 0, 3, 0, 1))

        '拡張項目取得
        Dim 拡張項目情報 As I拡張項目入力情報型
        拡張項目情報 = 更新データ.仕入明細(0).拡張項目入力情報

        query.Append("   AND SEIRA01003 = " & AddParamInfo(paramInfo, "SEIRA01003", DbType.Decimal, 0, 2, 0, 拡張項目情報.拡張項目(16)))

        Return query.ToString
    End Function
#End Region

#Region "入出荷予定更新用"
    Public Function UpdateSEIRA02(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                              ByVal 更新データ As WorkTableUnitData,
                              ByVal 残区分 As Integer,
                              ByVal 番号 As Long) As String Implements IMyQueryMaker.UpdateSEIRA02
        Dim query As New System.Text.StringBuilder

        query.Append(" UPDATE ")
        query.Append(Me.ExchangeTableName("SEI98RA02NYUSHUKOYOTEIH"))

        query.Append(" SET ")
        query.Append("  SEIRA02016 = " & AddParamInfo(paramInfo, "SEIRA02016", DbType.Decimal, 0, 1, 0, 残区分))
        query.Append(" ,SEIRA02017 = SEIRA02017 + 1 ")

        query.Append(" WHERE SEIRA02001 = " & AddParamInfo(paramInfo, "SEIRA02001", DbType.Decimal, 0, 10, 0, 番号))

        Return query.ToString
    End Function

    Public Function UpdateSEIRA03(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                  ByVal 更新データ As WorkTableUnitData,
                                  ByVal 残区分 As Integer,
                                  ByVal 番号 As Long,
                                  ByVal 行番号 As Integer,
                                  ByVal line As Integer) As String Implements IMyQueryMaker.UpdateSEIRA03
        Dim query As New System.Text.StringBuilder

        query.Append(" UPDATE ")
        query.Append(Me.ExchangeTableName("SEI98RA03NYUSHUKOYOTEIM"))

        query.Append(" SET ")
        query.Append("  SEIRA03024 = SEIRA03024 + " & AddParamInfo(paramInfo, "SEIRA02024", DbType.Decimal, 0, 19, 4, 更新データ.取引明細(line).R002025))
        query.Append(" ,SEIRA03025 = SEIRA03025 + 1 ")
        query.Append(" ,SEIRA03026 = " & AddParamInfo(paramInfo, "SEIRA03026", DbType.Decimal, 0, 8, 0, 更新データ.取引明細(line).R002001))
        query.Append(" ,SEIRA03027 = SEIRA03027 + 1 ")
        query.Append(" ,SEIRA03028 = " & AddParamInfo(paramInfo, "SEIRA03028", DbType.Decimal, 0, 1, 0, 残区分))

        query.Append(" WHERE SEIRA03001 = " & AddParamInfo(paramInfo, "SEIRA03001", DbType.Decimal, 0, 10, 0, 番号))
        query.Append("   AND SEIRA03002 = " & AddParamInfo(paramInfo, "SEIRA03002", DbType.Decimal, 0, 3, 0, 行番号))

        Return query.ToString
    End Function
#End Region

#End Region
    'A-CUST20190830↑
End Class
