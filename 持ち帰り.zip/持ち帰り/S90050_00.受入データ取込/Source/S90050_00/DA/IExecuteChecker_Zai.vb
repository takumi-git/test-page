﻿'A-2008/07/18_Ver7.30_SAIMU ※クラス追加
Public Interface IExecuteChecker_Zai
    Inherits IInsideDataHandler

    Property MyImportParam() As S90050_00.ImportParam

    Property result_Han() As TextFileImport.IResult

    Function DoExecuteCheck(ByRef chkctrl As IExecuteControlerForUpdate, _
                            ByRef executeCheckInfo As IExecuteCheckInfo) As ExecuteCheck.DataAccess.ExecuteCheckResult

End Interface
