﻿Public Class ItemSetter
    Inherits Base

#Region "プロパティ"
    Private _myImportParam As S90050_00.ImportParam
    Public Property MyImportParam() As S90050_00.ImportParam
        Get
            Return _myImportParam
        End Get
        Set(ByVal value As S90050_00.ImportParam)
            _myImportParam = value
        End Set
    End Property

#End Region

#Region "ＤＢ値セット"

#Region "取引伝票"

    Public Sub SetHANR001Work(ByRef HANR001 As ProgramLib.仕入ヘッダー型, ByVal dataTable As DataTable)
        Dim HANR001Work As New ProgramLib.仕入ヘッダー型

        Call ClearHANR001Work(HANR001Work)
        If dataTable.Rows.Count = 0 Then GoTo SetHANR001Work_End

        With HANR001Work
            .R001002 = CStr(dataTable.Rows(0).Item("HANR001002")).TrimEnd       '取引先コード
            .R001003 = CInt(dataTable.Rows(0).Item("HANR001003"))               '伝票日付
            .R001005 = CInt(dataTable.Rows(0).Item("HANR001005"))               '伝票番号
            .R001006 = CLng(dataTable.Rows(0).Item("HANR001006"))               '処理連番
            .R001015 = CLng(dataTable.Rows(0).Item("HANR001015"))               '発注№             'A-20111025_1
            .R001018 = CInt(dataTable.Rows(0).Item("HANR001018"))               '買掛区分   
            .R001019 = CInt(dataTable.Rows(0).Item("HANR001019"))               '支払区分
            .R001020 = CInt(dataTable.Rows(0).Item("HANR001020"))               '台帳用支払区分
            .R001021 = CInt(dataTable.Rows(0).Item("HANR001021"))               '支払処理連番
            .R001022 = CInt(dataTable.Rows(0).Item("HANR001022"))               '消費税計算区分     'A-2008/07/18_Ver7.30_SHIHARAI
            .R001024 = CInt(dataTable.Rows(0).Item("HANR001024"))               '自動生成データ区分
            .R001025 = CInt(dataTable.Rows(0).Item("HANR001025"))               '伝票行数
            .R001028 = CDec(dataTable.Rows(0).Item("HANR001028"))               '税込仕入 仕入額
            .R001029 = CDec(dataTable.Rows(0).Item("HANR001029"))               '         返品額
            .R001030 = CDec(dataTable.Rows(0).Item("HANR001030"))               '         値引額
            .R001031 = CDec(dataTable.Rows(0).Item("HANR001031"))               '内消費税 仕入額
            .R001032 = CDec(dataTable.Rows(0).Item("HANR001032"))               '         返品額
            .R001033 = CDec(dataTable.Rows(0).Item("HANR001033"))               '         値引額
            .R001034 = CDec(dataTable.Rows(0).Item("HANR001034"))               '税抜仕入 仕入額
            .R001035 = CDec(dataTable.Rows(0).Item("HANR001035"))               '         返品額
            .R001036 = CDec(dataTable.Rows(0).Item("HANR001036"))               '         値引額
            .R001037 = CDec(dataTable.Rows(0).Item("HANR001037"))               '外税     仕入額
            .R001038 = CDec(dataTable.Rows(0).Item("HANR001038"))               '         返品額
            .R001039 = CDec(dataTable.Rows(0).Item("HANR001039"))               '         値引額
            .R001040 = CDec(dataTable.Rows(0).Item("HANR001040"))               '非課税   仕入額
            .R001041 = CDec(dataTable.Rows(0).Item("HANR001041"))               '         返品額
            .R001042 = CDec(dataTable.Rows(0).Item("HANR001042"))               '         値引額
            .R001046 = CDec(dataTable.Rows(0).Item("HANR001046"))               '支払 現金
            .R001056 = CStr(dataTable.Rows(0).Item("HANR001056")).TrimEnd       '通貨コード
            .R001059 = CInt(dataTable.Rows(0).Item("HANR001059"))               '財務連結区分
            .R001060 = CLng(dataTable.Rows(0).Item("HANR001060"))               '財務処理連番
            .R001065 = CInt(dataTable.Rows(0).Item("HANR001065"))               '仕訳対象外区分
            .R001066 = CInt(dataTable.Rows(0).Item("HANR001066"))               '支払締日付         'A-2008/07/18_Ver7.30_SAIMU
            .R001067 = CInt(dataTable.Rows(0).Item("HANR001067"))               '支払予定日         'A-2008/07/18_Ver7.30_SAIMU
            .R001068 = CLng(dataTable.Rows(0).Item("HANR001068"))               '
            .R001069 = CInt(dataTable.Rows(0).Item("HANR001069"))               '計上区分           'A-20111025_1
            .R001075 = CInt(dataTable.Rows(0).Item("HANR001075"))               '請求書番号
            .R001076 = CStr(dataTable.Rows(0).Item("HANR001076")).TrimEnd       '締処理グループ
            .R001999 = CLng(dataTable.Rows(0).Item("HANR001999"))               '更新番号
            .R001A008 = CLng(dataTable.Rows(0).Item("HANR001A008"))

            'A-20111124_11↓
            If MyImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 3D Then

                .R001S002 = CInt(dataTable.Rows(0).Item("HANR001S002"))         '仕掛生成区分

            End If
            'A-20111124_11↑

            'A-20121217_Ver7.50_1↓
            If MyImportParam.Myコントロール情報.MyMOAオプション.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う Then
                .R001087 = CInt(dataTable.Rows(0).Item("HANR001087"))
                .R001088 = CInt(dataTable.Rows(0).Item("HANR001088"))
                .R001089 = CDec(dataTable.Rows(0).Item("HANR001089"))
                .R001S003 = CInt(dataTable.Rows(0).Item("HANR001S003"))
                .R001S004 = CDec(dataTable.Rows(0).Item("HANR001S004"))
                .R001S005 = CDec(dataTable.Rows(0).Item("HANR001S005"))
                .R001S006 = CDec(dataTable.Rows(0).Item("HANR001S006"))
                .R001S007 = CDec(dataTable.Rows(0).Item("HANR001S007"))
                .R001S008 = CDec(dataTable.Rows(0).Item("HANR001S008"))
                .R001S009 = CDec(dataTable.Rows(0).Item("HANR001S009"))
                .R001S010 = CDec(dataTable.Rows(0).Item("HANR001S010"))
                .R001S011 = CDec(dataTable.Rows(0).Item("HANR001S011"))
                .R001S012 = CDec(dataTable.Rows(0).Item("HANR001S012"))
                .R001S013 = CDec(dataTable.Rows(0).Item("HANR001S013"))
                .R001S014 = CStr(dataTable.Rows(0).Item("HANR001S014"))
            End If
            'A-20121217_Ver7.50_1↑

            'A-20160324_1↓
            If MyImportParam.Myコントロール情報.使用条件(Myコントロール情報Param.条件型.外貨複数伝票消込機能, 8D) Then
                .R001S015 = CInt(dataTable.Rows(0).Item("HANR001S015"))
            End If
            'A-20160324_1↑

            If dataTable.Columns.Contains("HANR030006_H") = True Then
                If MyImportParam.Myコントロール情報.Myオプション区分.拡張項目_仕入伝票 = True Then
                    Dim 拡張項目情報 As I拡張項目入力情報型
                    拡張項目情報 = CommonFactory.CreateInstance(Of I拡張項目入力情報型)(Me, GetType(拡張項目入力情報型))

                    拡張項目情報.付箋色番号 = CInt(dataTable.Rows(0).Item("HANR030006_H"))
                    For itemNo As Integer = 1 To ProgramLib.MAX_EXPANDITEM_COUNT
                        拡張項目情報.拡張項目(itemNo) = CStr(dataTable.Rows(0).Item("HANR0300" & Format(6 + itemNo, "00") & "_H"))
                    Next
                    .拡張項目入力情報 = 拡張項目情報
                End If
            End If

        End With

SetHANR001Work_End:

        HANR001 = HANR001Work

    End Sub

    Public Sub SetHANR002Work(ByRef HANR002 As ProgramLib.仕入明細型, ByVal dataTable As DataTable, ByVal index As Integer)
        Dim HANR002Work As New ProgramLib.仕入明細型

        Call ClearHANR002Work(HANR002Work)
        If index >= dataTable.Rows.Count Then GoTo SetHANR002Work_End

        With HANR002Work
            .R002001 = CInt(dataTable.Rows(index).Item("HANR002001"))
            .R002004 = CLng(dataTable.Rows(index).Item("HANR002004"))
            .R002005 = CInt(dataTable.Rows(index).Item("HANR002005"))            '明細区分
            .R002006 = CInt(dataTable.Rows(index).Item("HANR002006"))            '行番号
            .R002010 = CInt(dataTable.Rows(index).Item("HANR002010"))            '取引区分          'A-20130402_2
            .R002011 = CLng(dataTable.Rows(index).Item("HANR002011"))            '
            .R002018 = CStr(dataTable.Rows(index).Item("HANR002018")).TrimEnd    '倉庫コード        'A-20130402_2
            .R002019 = CStr(dataTable.Rows(index).Item("HANR002019")).TrimEnd    '
            .R002021 = CStr(dataTable.Rows(index).Item("HANR002021")).TrimEnd    '
            .R002025 = CDec(dataTable.Rows(index).Item("HANR002025"))            '金額
            .R002027 = CDec(dataTable.Rows(index).Item("HANR002027"))            '金額              'A-2008/07/18_Ver7.30_SHIHARAI
            .R002029 = CInt(dataTable.Rows(index).Item("HANR002029"))            '単価計算方法
            .R002048 = CDec(dataTable.Rows(index).Item("HANR002048"))            '消費税率
            .R002050 = CDec(dataTable.Rows(index).Item("HANR002050"))            '外税額            'A-2008/07/18_Ver7.30_SHIHARAI
            .R002052 = CInt(dataTable.Rows(index).Item("HANR002052"))            '完納区分
            .R002057 = CInt(dataTable.Rows(index).Item("HANR002057"))            '取引区分属性
            .R002059 = CStr(dataTable.Rows(index).Item("HANR002059")).TrimEnd    '通貨コード
            .R002999 = CLng(dataTable.Rows(index).Item("HANR002999"))            '更新番号
            .R002A006 = CStr(dataTable.Rows(index).Item("HANR002A006")).TrimEnd    '製番 'A-20111027_3
            .R002A010 = CStr(dataTable.Rows(index).Item("HANR002A010")).TrimEnd    '
            .R002A012 = CStr(dataTable.Rows(index).Item("HANR002A012")).TrimEnd    'ロケーション    'A-20130402_2
            .R002A014 = CDec(dataTable.Rows(index).Item("HANR002A014"))
            .R002A015 = CStr(dataTable.Rows(index).Item("HANR002A015")).TrimEnd    '
            .R002A016 = CDec(dataTable.Rows(index).Item("HANR002A016"))            '
            .R002A033 = CInt(dataTable.Rows(index).Item("HANR002A033"))            '

            'A-20121217_Ver7.50_1↓
            If MyImportParam.Myコントロール情報.MyMOAオプション.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う Then
                .R002101 = CInt(dataTable.Rows(index).Item("HANR002101"))
                .R002102 = CInt(dataTable.Rows(index).Item("HANR002102"))
                .R002103 = CDec(dataTable.Rows(index).Item("HANR002103"))
                .R002104 = CDec(dataTable.Rows(index).Item("HANR002104"))
                .R002105 = CInt(dataTable.Rows(index).Item("HANR002105"))
                .R002106 = CDec(dataTable.Rows(index).Item("HANR002106"))
                .R002107 = CDec(dataTable.Rows(index).Item("HANR002107"))
                .R002S001 = CDec(dataTable.Rows(index).Item("HANR002S001"))
                .R002S002 = CDec(dataTable.Rows(index).Item("HANR002S002"))
                .R002S003 = CDec(dataTable.Rows(index).Item("HANR002S003"))
                .R002S004 = CDec(dataTable.Rows(index).Item("HANR002S004"))
                .R002S005 = CDec(dataTable.Rows(index).Item("HANR002S005"))
                .R002S006 = CDec(dataTable.Rows(index).Item("HANR002S006"))
                .R002S007 = CDec(dataTable.Rows(index).Item("HANR002S007"))
                .R002S008 = CStr(dataTable.Rows(index).Item("HANR002S008"))
                .R002S009 = CStr(dataTable.Rows(index).Item("HANR002S009"))
                .R002S010 = CStr(dataTable.Rows(index).Item("HANR002S010"))
                .R002S011 = CStr(dataTable.Rows(index).Item("HANR002S011"))
                .R002S012 = CStr(dataTable.Rows(index).Item("HANR002S012"))
                .R002S013 = CStr(dataTable.Rows(index).Item("HANR002S013"))
                .R002S014 = CInt(dataTable.Rows(index).Item("HANR002S014"))
                .R002S015 = CInt(dataTable.Rows(index).Item("HANR002S015"))
                .R002S016 = CInt(dataTable.Rows(index).Item("HANR002S016"))
            End If
            'A-20121217_Ver7.50_1↑
            'A-20141105_1↓
            If MyImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 6.0 Then
                .R002S017 = CStr(dataTable.Rows(index).Item("HANR002S017"))
                .R002S018 = CDec(dataTable.Rows(index).Item("HANR002S018"))
            End If
            'A-20141105_1↑

            If dataTable.Columns.Contains("HANR030006_M") = True Then
                If _myImportParam.Myコントロール情報.Myオプション区分.拡張項目_仕入明細 = True Then
                    Dim 拡張項目情報 As I拡張項目入力情報型
                    拡張項目情報 = CommonFactory.CreateInstance(Of I拡張項目入力情報型)(Me, GetType(拡張項目入力情報型))

                    拡張項目情報.付箋色番号 = CInt(dataTable.Rows(index).Item("HANR030006_M"))
                    For itemNo As Integer = 1 To ProgramLib.MAX_EXPANDITEM_COUNT
                        拡張項目情報.拡張項目(itemNo) = CStr(dataTable.Rows(index).Item("HANR0300" & Format(6 + itemNo, "00") & "_M"))
                    Next
                    .拡張項目入力情報 = 拡張項目情報
                End If
            End If
        End With

SetHANR002Work_End:

        HANR002 = HANR002Work

    End Sub

#End Region


#Region "受発注伝票"

    Public Sub SetHANR004Work(ByRef HANR004 As ProgramLib.受発注ヘッダー型, ByVal dataTable As DataTable)
        Dim HANR004Work As New ProgramLib.受発注ヘッダー型

        If dataTable.Rows.Count = 0 Then GoTo SetHANR001Work_End

        With HANR004Work
            .R004002 = CStr(dataTable.Rows(0).Item("HANR004002")).TrimEnd
            .R004003 = CInt(dataTable.Rows(0).Item("HANR004003"))
            .R004004 = CInt(dataTable.Rows(0).Item("HANR004004"))               '伝票区分
            .R004005 = CLng(dataTable.Rows(0).Item("HANR004005"))               '受発注番号
            .R004016 = CLng(dataTable.Rows(0).Item("HANR004016"))               '見積連番
            .R004035 = CStr(dataTable.Rows(0).Item("HANR004035")).TrimEnd
            .R004036 = CStr(dataTable.Rows(0).Item("HANR004036")).TrimEnd
            .R004045 = CInt(dataTable.Rows(0).Item("HANR004045"))               '計上区分
            .R004A001 = CInt(dataTable.Rows(0).Item("HANR004A001"))             '受注区分
            .R004A004 = CStr(dataTable.Rows(0).Item("HANR004A004")).TrimEnd     'プロジェクトメインコード
            .R004A005 = CStr(dataTable.Rows(0).Item("HANR004A005")).TrimEnd     'プロジェクトサブコード
        End With

SetHANR001Work_End:

        HANR004 = HANR004Work

    End Sub

#End Region

#Region "入出荷伝票"

    Public Sub SetSEIR010Work(ByRef SEIR010 As ProgramLib.入出荷ヘッダー型, ByVal dataTable As DataTable)
        Dim SEIR010Work As New ProgramLib.入出荷ヘッダー型

        Call ClearSEIR010Work(SEIR010Work)
        If dataTable.Rows.Count = 0 Then GoTo SetSEIR010Work_End

        With SEIR010Work
            .R010001 = CInt(dataTable.Rows(0).Item("SEIR010001"))               '

            .R010001 = CInt(dataTable.Rows(0).Item("SEIR010001"))          '// (001)  取引先区分
            .R010002 = CStr(dataTable.Rows(0).Item("SEIR010002")).TrimEnd  '// (002)  取引先コード
            .R010003 = CInt(dataTable.Rows(0).Item("SEIR010003"))          '// (003)  入出荷日(年月日)
            .R010004 = CInt(dataTable.Rows(0).Item("SEIR010004"))          '// (004)  伝票区分
            '.R010005 = CInt(dataTable.Rows(0).Item("SEIR010005"))          '// (005)  処理連番             'D-20121217_Ver7.50
            .R010005 = CLng(dataTable.Rows(0).Item("SEIR010005"))          '// (005)  処理連番              'A-20121217_Ver7.50
            .R010006 = CInt(dataTable.Rows(0).Item("SEIR010006"))          '// (006)  入出荷伝票番号
            .R010007 = CInt(dataTable.Rows(0).Item("SEIR010007"))          '// (007)  売上(仕入)伝票番号
            .R010008 = CInt(dataTable.Rows(0).Item("SEIR010008"))          '// (008)  操作日付(年月日)
            .R010009 = CStr(dataTable.Rows(0).Item("SEIR010009")).TrimEnd  '// (009)  ログインＩＤ
            .R010010 = CInt(dataTable.Rows(0).Item("SEIR010010"))          '// (010)  チェックマーク区分
            .R010011 = CStr(dataTable.Rows(0).Item("SEIR010011")).TrimEnd  '// (011)  担当者コード
            .R010012 = CStr(dataTable.Rows(0).Item("SEIR010012")).TrimEnd  '// (012)  納品先コード
            .R010013 = CStr(dataTable.Rows(0).Item("SEIR010013")).TrimEnd  '// (013)  部門コード
            .R010014 = CStr(dataTable.Rows(0).Item("SEIR010014")).TrimEnd  '// (014)  倉庫コード
            .R010015 = CStr(dataTable.Rows(0).Item("SEIR010015")).TrimEnd  '// (015)  オーダーコード
            .R010016 = CLng(dataTable.Rows(0).Item("SEIR010016"))          '// (016)  受(発)注番号
            .R010017 = CInt(dataTable.Rows(0).Item("SEIR010017"))          '// (017)  売掛区分
            .R010018 = CInt(dataTable.Rows(0).Item("SEIR010018"))          '// (018)  請求(支払)区分
            .R010019 = CInt(dataTable.Rows(0).Item("SEIR010019"))          '// (019)  消費税計算区分
            .R010020 = CDec(dataTable.Rows(0).Item("SEIR010020"))          '// (020)  消費税率
            .R010021 = CInt(dataTable.Rows(0).Item("SEIR010021"))          '// (021)  伝票行数
            .R010022 = CStr(dataTable.Rows(0).Item("SEIR010022")).TrimEnd  '// (022)  備考コード
            .R010023 = CStr(dataTable.Rows(0).Item("SEIR010023")).TrimEnd  '// (023)  備考
            .R010024 = CStr(dataTable.Rows(0).Item("SEIR010024")).TrimEnd  '// (024)  手入力得意先名１
            .R010025 = CStr(dataTable.Rows(0).Item("SEIR010025")).TrimEnd  '// (025)  手入力得意先名２
            .R010026 = CStr(dataTable.Rows(0).Item("SEIR010026")).TrimEnd  '// (026)  手入力納品先名
            .R010027 = CStr(dataTable.Rows(0).Item("SEIR010027")).TrimEnd  '// (027)  通貨コード
            .R010028 = CInt(dataTable.Rows(0).Item("SEIR010028"))          '// (028)  データ発生区分
            .R010029 = CInt(dataTable.Rows(0).Item("SEIR010029"))          '// (029)  検収残区分
            .R010030 = CInt(dataTable.Rows(0).Item("SEIR010030"))          '// (030)  関連検収伝票枚数
            .R010031 = CInt(dataTable.Rows(0).Item("SEIR010031"))          '// (031)  計上区分
            .R010032 = CStr(dataTable.Rows(0).Item("SEIR010032")).TrimEnd  '// (032)  営業所コード
            .R010033 = CInt(dataTable.Rows(0).Item("SEIR010033"))          '// (033)  受注区分
            .R010034 = CInt(dataTable.Rows(0).Item("SEIR010034"))          '// (034)  受注形態
            .R010035 = CStr(dataTable.Rows(0).Item("SEIR010035")).TrimEnd  '// (035)  プロジェクトメインコード
            .R010036 = CStr(dataTable.Rows(0).Item("SEIR010036")).TrimEnd  '// (036)  プロジェクトサブコード
            .R010037 = CStr(dataTable.Rows(0).Item("SEIR010037")).TrimEnd  '// (037)  製番
            .R010038 = CStr(dataTable.Rows(0).Item("SEIR010038")).TrimEnd  '// (038)  製番(メイン)
            .R010039 = CStr(dataTable.Rows(0).Item("SEIR010039")).TrimEnd  '// (039)  製番(枝番)
            .R010040 = CInt(dataTable.Rows(0).Item("SEIR010040"))          '// (040)  発注区分
            .R010041 = CInt(dataTable.Rows(0).Item("SEIR010041"))          '// (041)  完成品区分
            .R010042 = CInt(dataTable.Rows(0).Item("SEIR010042"))          '// (042)  計上区分
            .R010043 = CInt(dataTable.Rows(0).Item("SEIR010043"))          '// (043)  計算区分
            .R010044 = CInt(dataTable.Rows(0).Item("SEIR010044"))          '// (044)  構成品出庫生成区分
            .R010045 = CInt(dataTable.Rows(0).Item("SEIR010045"))          '// (045)  返品区分
            .R010046 = CLng(dataTable.Rows(0).Item("SEIR010046"))          '// (046)  元出荷処理連番
            .R010047 = CDec(dataTable.Rows(0).Item("SEIR010047"))          '// (047)  税込売上_売上額
            .R010048 = CDec(dataTable.Rows(0).Item("SEIR010048"))          '// (048)  税込売上_返品額
            .R010049 = CDec(dataTable.Rows(0).Item("SEIR010049"))          '// (049)  税込売上_値引額
            .R010050 = CDec(dataTable.Rows(0).Item("SEIR010050"))          '// (050)  内消費税_売上額
            .R010051 = CDec(dataTable.Rows(0).Item("SEIR010051"))          '// (051)  内消費税_返品額
            .R010052 = CDec(dataTable.Rows(0).Item("SEIR010052"))          '// (052)  内消費税_値引額
            .R010053 = CDec(dataTable.Rows(0).Item("SEIR010053"))          '// (053)  税抜売上_売上額
            .R010054 = CDec(dataTable.Rows(0).Item("SEIR010054"))          '// (054)  税抜売上_返品額
            .R010055 = CDec(dataTable.Rows(0).Item("SEIR010055"))          '// (055)  税抜売上_値引額
            .R010056 = CDec(dataTable.Rows(0).Item("SEIR010056"))          '// (056)  外税_売上額
            .R010057 = CDec(dataTable.Rows(0).Item("SEIR010057"))          '// (057)  外税_返品額
            .R010058 = CDec(dataTable.Rows(0).Item("SEIR010058"))          '// (058)  外税_値引額
            .R010059 = CDec(dataTable.Rows(0).Item("SEIR010059"))          '// (059)  非課税_売上額
            .R010060 = CDec(dataTable.Rows(0).Item("SEIR010060"))          '// (060)  非課税_返品額
            .R010061 = CDec(dataTable.Rows(0).Item("SEIR010061"))          '// (061)  非課税_値引額
            .R010062 = CDec(dataTable.Rows(0).Item("SEIR010062"))          '// (062)  粗利額
            .R010999 = CLng(dataTable.Rows(0).Item("SEIR010999"))          '// (999)  更新番号

            'A-20121217_Ver7.50_1↓
            If MyImportParam.Myコントロール情報.MyMOAオプション.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う Then
                .R010063 = CDec(dataTable.Rows(0).Item("SEIR010063"))
                .R010064 = CInt(dataTable.Rows(0).Item("SEIR010064"))
                .R010065 = CInt(dataTable.Rows(0).Item("SEIR010065"))
                .R010066 = CDec(dataTable.Rows(0).Item("SEIR010066"))
                .R010067 = CDec(dataTable.Rows(0).Item("SEIR010067"))
                .R010068 = CDec(dataTable.Rows(0).Item("SEIR010068"))
                .R010069 = CDec(dataTable.Rows(0).Item("SEIR010069"))
                .R010070 = CStr(dataTable.Rows(0).Item("SEIR010070"))
            End If
            'A-20121217_Ver7.50_1↑

            If MyImportParam.Myコントロール情報.Myオプション区分.拡張項目_仕入伝票 = True Then
                Dim 拡張項目情報 As I拡張項目入力情報型
                拡張項目情報 = CommonFactory.CreateInstance(Of I拡張項目入力情報型)(Me, GetType(拡張項目入力情報型))

                拡張項目情報.付箋色番号 = CInt(dataTable.Rows(0).Item("HANR030006_H"))
                For itemNo As Integer = 1 To ProgramLib.MAX_EXPANDITEM_COUNT
                    拡張項目情報.拡張項目(itemNo) = CStr(dataTable.Rows(0).Item("HANR0300" & Format(6 + itemNo, "00") & "_H"))
                Next
                .拡張項目入力情報 = 拡張項目情報
            End If

        End With

SetSEIR010Work_End:

        SEIR010 = SEIR010Work

    End Sub

    Public Sub SetSEIR011Work(ByRef SEIR011 As ProgramLib.入出荷明細型, ByVal dataTable As DataTable, ByVal index As Integer)
        Dim SEIR011Work As New ProgramLib.入出荷明細型

        Call ClearSEIR011Work(SEIR011Work)
        If index >= dataTable.Rows.Count Then GoTo SetSEIR011Work_End

        With SEIR011Work
            .R011001 = CInt(dataTable.Rows(index).Item("SEIR011001"))          '// (001)  入出荷日（年月日）
            .R011002 = CInt(dataTable.Rows(index).Item("SEIR011002"))          '// (002)  伝票区分
            .R011003 = CLng(dataTable.Rows(index).Item("SEIR011003"))          '// (003)  処理連番
            .R011004 = CInt(dataTable.Rows(index).Item("SEIR011004"))          '// (004)  明細区分
            .R011005 = CInt(dataTable.Rows(index).Item("SEIR011005"))          '// (005)  行番号
            .R011006 = CInt(dataTable.Rows(index).Item("SEIR011006"))          '// (006)  入出荷伝票番号
            .R011007 = CInt(dataTable.Rows(index).Item("SEIR011007"))          '// (007)  売上(仕入)伝票番号
            .R011008 = CInt(dataTable.Rows(index).Item("SEIR011008"))          '// (008)  取引先区分
            .R011009 = CStr(dataTable.Rows(index).Item("SEIR011009"))          '// (009)  取引先コード
            .R011010 = CStr(dataTable.Rows(index).Item("SEIR011010"))          '// (010)  担当者コード
            .R011011 = CInt(dataTable.Rows(index).Item("SEIR011011"))          '// (011)  取引区分
            .R011012 = CLng(dataTable.Rows(index).Item("SEIR011012"))          '// (012)  受(発)注番号
            .R011013 = CInt(dataTable.Rows(index).Item("SEIR011013"))          '// (013)  受(発)注行番号
            .R011014 = CStr(dataTable.Rows(index).Item("SEIR011014"))          '// (014)  部門コード
            .R011015 = CStr(dataTable.Rows(index).Item("SEIR011015"))          '// (015)  倉庫コード
            .R011016 = CStr(dataTable.Rows(index).Item("SEIR011016"))          '// (016)  商品(品目)コード
            .R011017 = CStr(dataTable.Rows(index).Item("SEIR011017"))          '// (017)  商品(品目)名
            .R011018 = CStr(dataTable.Rows(index).Item("SEIR011018"))          '// (018)  数量単位
            .R011019 = CDec(dataTable.Rows(index).Item("SEIR011019"))          '// (019)  入数
            .R011020 = CDec(dataTable.Rows(index).Item("SEIR011020"))          '// (020)  個数
            .R011021 = CStr(dataTable.Rows(index).Item("SEIR011021"))          '// (021)  個数単位
            .R011022 = CDec(dataTable.Rows(index).Item("SEIR011022"))          '// (022)  入出荷数量
            .R011023 = CDec(dataTable.Rows(index).Item("SEIR011023"))          '// (023)  入出荷単価
            .R011024 = CDec(dataTable.Rows(index).Item("SEIR011024"))          '// (024)  入出荷金額
            .R011025 = CDec(dataTable.Rows(index).Item("SEIR011025"))          '// (025)  原単価
            .R011026 = CInt(dataTable.Rows(index).Item("SEIR011026"))          '// (026)  単価計算方法
            .R011027 = CDec(dataTable.Rows(index).Item("SEIR011027"))          '// (027)  単価掛率
            .R011028 = CDec(dataTable.Rows(index).Item("SEIR011028"))          '// (028)  標準売上単価
            .R011029 = CDec(dataTable.Rows(index).Item("SEIR011029"))          '// (029)  標準仕入単価
            .R011030 = CDec(dataTable.Rows(index).Item("SEIR011030"))          '// (030)  上代単価
            .R011031 = CDec(dataTable.Rows(index).Item("SEIR011031"))          '// (031)  粗利額
            .R011032 = CDec(dataTable.Rows(index).Item("SEIR011032"))          '// (032)  入出荷金額
            .R011033 = CDec(dataTable.Rows(index).Item("SEIR011033"))          '// (033)  値引金額
            .R011034 = CInt(dataTable.Rows(index).Item("SEIR011034"))          '// (034)  課税区分
            .R011035 = CDec(dataTable.Rows(index).Item("SEIR011035"))          '// (035)  消費税率
            .R011036 = CDec(dataTable.Rows(index).Item("SEIR011036"))          '// (036)  内消費税額
            .R011037 = CInt(dataTable.Rows(index).Item("SEIR011037"))          '// (037)  強制検収完納区分
            .R011038 = CStr(dataTable.Rows(index).Item("SEIR011038"))          '// (038)  行摘要コード
            .R011039 = CStr(dataTable.Rows(index).Item("SEIR011039"))          '// (039)  行摘要１
            .R011040 = CStr(dataTable.Rows(index).Item("SEIR011040"))          '// (040)  行摘要２
            .R011041 = CDec(dataTable.Rows(index).Item("SEIR011041"))          '// (041)  検収済数量
            .R011042 = CDec(dataTable.Rows(index).Item("SEIR011042"))          '// (042)  検収済金額
            .R011043 = CDec(dataTable.Rows(index).Item("SEIR011043"))          '// (043)  検収済金額内消費税
            .R011044 = CDec(dataTable.Rows(index).Item("SEIR011044"))          '// (044)  検収済金額内訳売上
            .R011045 = CDec(dataTable.Rows(index).Item("SEIR011045"))          '// (045)  検収済金額内訳値引
            .R011046 = CInt(dataTable.Rows(index).Item("SEIR011046"))          '// (046)  検収回数
            .R011047 = CInt(dataTable.Rows(index).Item("SEIR011047"))          '// (047)  最終検収日
            .R011048 = CInt(dataTable.Rows(index).Item("SEIR011048"))          '// (048)  関連売上/仕入伝票行数
            .R011049 = CInt(dataTable.Rows(index).Item("SEIR011049"))          '// (049)  検収残区分
            .R011050 = CStr(dataTable.Rows(index).Item("SEIR011050"))          '// (050)  通貨コード
            .R011051 = CInt(dataTable.Rows(index).Item("SEIR011051"))          '// (051)  取引区分属性
            .R011052 = CInt(dataTable.Rows(index).Item("SEIR011052"))          '// (052)  入出庫区分
            .R011053 = CInt(dataTable.Rows(index).Item("SEIR011053"))          '// (053)  データ発生区分
            .R011054 = CInt(dataTable.Rows(index).Item("SEIR011054"))          '// (054)  上代課税区分
            .R011055 = CInt(dataTable.Rows(index).Item("SEIR011055"))          '// (055)  計上区分
            .R011056 = CInt(dataTable.Rows(index).Item("SEIR011056"))          '// (056)  売掛区分
            .R011057 = CDec(dataTable.Rows(index).Item("SEIR011057"))          '// (057)  原価金額
            .R011058 = CStr(dataTable.Rows(index).Item("SEIR011058"))          '// (058)  営業所コード
            .R011059 = CStr(dataTable.Rows(index).Item("SEIR011059"))          '// (059)  拡張項目入力パターン№
            .R011060 = CStr(dataTable.Rows(index).Item("SEIR011060"))          '// (060)  品目名１
            .R011061 = CStr(dataTable.Rows(index).Item("SEIR011061"))          '// (061)  品目名２
            .R011062 = CStr(dataTable.Rows(index).Item("SEIR011062"))          '// (062)  品目名３
            .R011063 = CStr(dataTable.Rows(index).Item("SEIR011063"))          '// (063)  製　番
            .R011064 = CStr(dataTable.Rows(index).Item("SEIR011064"))          '// (064)  製番（メイン）
            .R011065 = CStr(dataTable.Rows(index).Item("SEIR011065"))          '// (065)  製番（枝番）
            .R011066 = CStr(dataTable.Rows(index).Item("SEIR011066"))          '// (066)  客先注番
            .R011067 = CInt(dataTable.Rows(index).Item("SEIR011067"))          '// (067)  検査方法
            .R011068 = CInt(dataTable.Rows(index).Item("SEIR011068"))          '// (068)  発注区分
            .R011069 = CInt(dataTable.Rows(index).Item("SEIR011069"))          '// (069)  子部品引当区分
            .R011070 = CStr(dataTable.Rows(index).Item("SEIR011070"))          '// (070)  工程コード
            .R011071 = CDec(dataTable.Rows(index).Item("SEIR011071"))          '// (071)  入出荷数量(発注単位)
            .R011072 = CStr(dataTable.Rows(index).Item("SEIR011072"))          '// (072)  入出荷単位(発注単位)
            .R011073 = CDec(dataTable.Rows(index).Item("SEIR011073"))          '// (073)  発注単位変換係数
            .R011074 = CInt(dataTable.Rows(index).Item("SEIR011074"))          '// (074)  発注確定区分
            .R011075 = CLng(dataTable.Rows(index).Item("SEIR011075"))          '// (075)  手配番号
            .R011076 = CLng(dataTable.Rows(index).Item("SEIR011076"))          '// (076)  手配管理番号
            .R011077 = CInt(dataTable.Rows(index).Item("SEIR011077"))          '// (077)  仮単価区分
            .R011078 = CInt(dataTable.Rows(index).Item("SEIR011078"))          '// (078)  受注形態
            .R011079 = CLng(dataTable.Rows(index).Item("SEIR011079"))          '// (079)  個別発注連番
            .R011080 = CDec(dataTable.Rows(index).Item("SEIR011080"))          '// (080)  検収済数量(発注単位)
            .R011081 = CStr(dataTable.Rows(index).Item("SEIR011081"))          '// (081)  費目コード
            .R011082 = CInt(dataTable.Rows(index).Item("SEIR011082"))          '// (082)  費目区分
            .R011083 = CStr(dataTable.Rows(index).Item("SEIR011083"))          '// (083)  ロケーション
            .R011084 = CStr(dataTable.Rows(index).Item("SEIR011084"))          '// (084)  ロット№
            .R011085 = CDec(dataTable.Rows(index).Item("SEIR011085"))          '// (085)  不良数量(在庫単位)
            .R011086 = CDec(dataTable.Rows(index).Item("SEIR011086"))          '// (086)  不良数量(発注単位)
            .R011087 = CInt(dataTable.Rows(index).Item("SEIR011087"))          '// (087)  ロット管理区分
            .R011088 = CInt(dataTable.Rows(index).Item("SEIR011088"))          '// (088)  有効期限
            .R011089 = CDec(dataTable.Rows(index).Item("SEIR011089"))          '// (089)  最新検収単価
            .R011090 = CLng(dataTable.Rows(index).Item("SEIR011090"))          '// (090)  相手売上(仕入)処理連番
            .R011091 = CInt(dataTable.Rows(index).Item("SEIR011091"))          '// (091)  相手売上(仕入)行番号
            .R011092 = CLng(dataTable.Rows(index).Item("SEIR011092"))          '// (092)  相手入出庫処理連番
            .R011093 = CInt(dataTable.Rows(index).Item("SEIR011093"))          '// (093)  相手入出庫行番号
            .R011094 = CDec(dataTable.Rows(index).Item("SEIR011094"))          '// (094)  外税額(明細消費税用)
            .R011095 = CDec(dataTable.Rows(index).Item("SEIR011095"))          '// (095)  検収残金額
            .R011096 = CLng(dataTable.Rows(index).Item("SEIR011096"))          '// (096)  元入出荷処理連番
            .R011097 = CInt(dataTable.Rows(index).Item("SEIR011097"))          '// (097)  元入出荷行番号
            .R011098 = CInt(dataTable.Rows(index).Item("SEIR011098"))          '// (098)  受発注強制完納区分
            .R011099 = CInt(dataTable.Rows(index).Item("SEIR011099"))          '// (099)  消費税計算区分
            .R011999 = CLng(dataTable.Rows(index).Item("SEIR011999"))          '// (999)  更新番号

            'A-20121217_Ver7.50_1↓
            If MyImportParam.Myコントロール情報.MyMOAオプション.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う Then
                .R011100 = CDec(dataTable.Rows(index).Item("SEIR011100"))
                .R011101 = CDec(dataTable.Rows(index).Item("SEIR011101"))
                .R011102 = CDec(dataTable.Rows(index).Item("SEIR011102"))
                .R011103 = CDec(dataTable.Rows(index).Item("SEIR011103"))
                .R011104 = CDec(dataTable.Rows(index).Item("SEIR011104"))
                .R011105 = CDec(dataTable.Rows(index).Item("SEIR011105"))
                .R011106 = CDec(dataTable.Rows(index).Item("SEIR011106"))
                .R011107 = CDec(dataTable.Rows(index).Item("SEIR011107"))
                .R011108 = CDec(dataTable.Rows(index).Item("SEIR011108"))
                .R011109 = CDec(dataTable.Rows(index).Item("SEIR011109"))
                .R011110 = CDec(dataTable.Rows(index).Item("SEIR011110"))
                .R011111 = CDec(dataTable.Rows(index).Item("SEIR011111"))
                .R011112 = CStr(dataTable.Rows(index).Item("SEIR011112"))
                .R011113 = CInt(dataTable.Rows(index).Item("SEIR011113"))
                .R011114 = CInt(dataTable.Rows(index).Item("SEIR011114"))
                .R011115 = CInt(dataTable.Rows(index).Item("SEIR011115"))
                .R011116 = CStr(dataTable.Rows(index).Item("SEIR011116"))
                .R011117 = CStr(dataTable.Rows(index).Item("SEIR011117"))
                .R011118 = CStr(dataTable.Rows(index).Item("SEIR011118"))
                .R011119 = CStr(dataTable.Rows(index).Item("SEIR011119"))
                .R011120 = CStr(dataTable.Rows(index).Item("SEIR011120"))
            End If
            'A-20121217_Ver7.50_1↑
            'A-20160324_2↓
            If MyImportParam.Myコントロール情報.使用条件(Myコントロール情報Param.条件型.品目別原価計算機能, 8D) = True Then
                .R011121 = CLng(dataTable.Rows(index).Item("SEIR011121"))
            End If
            'A-20160324_2↑

            If _myImportParam.Myコントロール情報.Myオプション区分.拡張項目_仕入明細 = True Then
                Dim 拡張項目情報 As I拡張項目入力情報型
                拡張項目情報 = CommonFactory.CreateInstance(Of I拡張項目入力情報型)(Me, GetType(拡張項目入力情報型))

                拡張項目情報.付箋色番号 = CInt(dataTable.Rows(index).Item("HANR030006_M"))
                For itemNo As Integer = 1 To ProgramLib.MAX_EXPANDITEM_COUNT
                    拡張項目情報.拡張項目(itemNo) = CStr(dataTable.Rows(index).Item("HANR0300" & Format(6 + itemNo, "00") & "_M"))
                Next
                .拡張項目入力情報 = 拡張項目情報
            End If
        End With

SetSEIR011Work_End:

        SEIR011 = SEIR011Work

    End Sub

#End Region

#Region "ロット明細"

    Public Sub SetSEIR008Work(ByRef SEIR008 As ProgramLib.ロット明細型, ByVal dataTable As DataTable, ByVal index As Integer)
        Dim SEIR008Work As New ProgramLib.ロット明細型

        Call ClearSEIR008Work(SEIR008Work)
        If index >= dataTable.Rows.Count Then GoTo SetSEIR008Work_End

        With SEIR008Work
            .R008001 = CInt(dataTable.Rows(index).Item("SEIR008001"))          '// (001)  伝票区分
            .R008002 = CLng(dataTable.Rows(index).Item("SEIR008002"))          '// (002)  処理連番
            .R008003 = CInt(dataTable.Rows(index).Item("SEIR008003"))          '// (003)  行番号
            .R008004 = CInt(dataTable.Rows(index).Item("SEIR008004"))          '// (004)  ロット明細連番
            .R008005 = CInt(dataTable.Rows(index).Item("SEIR008005"))          '// (005)  入出庫日
            .R008006 = CInt(dataTable.Rows(index).Item("SEIR008006"))          '// (006)  伝票明細区分
            .R008007 = CStr(dataTable.Rows(index).Item("SEIR008007")).TrimEnd  '// (007)  倉庫コード
            .R008008 = CStr(dataTable.Rows(index).Item("SEIR008008")).TrimEnd  '// (008)  倉庫名
            .R008009 = CStr(dataTable.Rows(index).Item("SEIR008009")).TrimEnd  '// (009)  ロケーション
            .R008010 = CStr(dataTable.Rows(index).Item("SEIR008010")).TrimEnd  '// (010)  商品コード
            .R008011 = CStr(dataTable.Rows(index).Item("SEIR008011")).TrimEnd  '// (011)  商品名１
            .R008012 = CStr(dataTable.Rows(index).Item("SEIR008012")).TrimEnd  '// (012)  商品名２
            .R008013 = CStr(dataTable.Rows(index).Item("SEIR008013")).TrimEnd  '// (013)  商品名３
            .R008014 = CStr(dataTable.Rows(index).Item("SEIR008014")).TrimEnd  '// (014)  ロット№
            .R008015 = CInt(dataTable.Rows(index).Item("SEIR008015"))          '// (015)  入出庫区分
            .R008016 = CDec(dataTable.Rows(index).Item("SEIR008016"))          '// (016)  入庫数量
            .R008017 = CDec(dataTable.Rows(index).Item("SEIR008017"))          '// (017)  出庫数量
            .R008018 = CStr(dataTable.Rows(index).Item("SEIR008018")).TrimEnd  '// (018)  単位
            .R008019 = CStr(dataTable.Rows(index).Item("SEIR008019")).TrimEnd  '// (019)  製番
            .R008020 = CStr(dataTable.Rows(index).Item("SEIR008020")).TrimEnd  '// (020)  製番（メイン）
            .R008021 = CStr(dataTable.Rows(index).Item("SEIR008021")).TrimEnd  '// (021)  製番（枝番）
            .R008022 = CStr(dataTable.Rows(index).Item("SEIR008022")).TrimEnd  '// (022)  出庫先（元）コード
            .R008023 = CStr(dataTable.Rows(index).Item("SEIR008023")).TrimEnd  '// (023)  出庫先名１
            .R008024 = CStr(dataTable.Rows(index).Item("SEIR008024")).TrimEnd  '// (024)  出庫先名２
            .R008025 = CLng(dataTable.Rows(index).Item("SEIR008025"))          '// (025)  受注番号
            .R008026 = CInt(dataTable.Rows(index).Item("SEIR008026"))          '// (026)  受注行番号
            .R008027 = CInt(dataTable.Rows(index).Item("SEIR008027"))          '// (027)  受注日
            .R008028 = CStr(dataTable.Rows(index).Item("SEIR008028")).TrimEnd  '// (028)  製番品目コード
            .R008029 = CStr(dataTable.Rows(index).Item("SEIR008029")).TrimEnd  '// (029)  製番品目名１
            .R008030 = CStr(dataTable.Rows(index).Item("SEIR008030")).TrimEnd  '// (030)  製番品目名２
            .R008031 = CStr(dataTable.Rows(index).Item("SEIR008031")).TrimEnd  '// (031)  製番品目名３
            .R008032 = CStr(dataTable.Rows(index).Item("SEIR008032")).TrimEnd  '// (032)  客先注番
            .R008033 = CStr(dataTable.Rows(index).Item("SEIR008033")).TrimEnd  '// (033)  得意先コード
            .R008034 = CStr(dataTable.Rows(index).Item("SEIR008034")).TrimEnd  '// (034)  得意先名１
            .R008035 = CStr(dataTable.Rows(index).Item("SEIR008035")).TrimEnd  '// (035)  得意先名２
            .R008036 = CLng(dataTable.Rows(index).Item("SEIR008036"))          '// (036)  手配（発注）番号
            .R008037 = CInt(dataTable.Rows(index).Item("SEIR008037"))          '// (037)  手配日
            .R008038 = CInt(dataTable.Rows(index).Item("SEIR008038"))          '// (038)  内外区分（手配先）
            .R008039 = CStr(dataTable.Rows(index).Item("SEIR008039")).TrimEnd  '// (039)  手配先コード
            .R008040 = CStr(dataTable.Rows(index).Item("SEIR008040")).TrimEnd  '// (040)  手配先名１
            .R008041 = CStr(dataTable.Rows(index).Item("SEIR008041")).TrimEnd  '// (041)  手配先名２
            .R008042 = CLng(dataTable.Rows(index).Item("SEIR008042"))          '// (042)  手配管理番号
        End With

SetSEIR008Work_End:

        SEIR008 = SEIR008Work

    End Sub

#End Region

#Region "従属需要"

    Public Sub SetSEIR056Work(ByRef SEIR056 As ProgramLib.従属需要型, ByVal dataTable As DataTable)
        Dim SEIR056Work As New ProgramLib.従属需要型

        Call ClearSEIR056Work(SEIR056Work)

        With SEIR056Work
            .R056001 = CInt(dataTable.Rows(0).Item("SEIR056001"))
            .R056002 = CLng(dataTable.Rows(0).Item("SEIR056002"))
            .R056003 = CInt(dataTable.Rows(0).Item("SEIR056003"))
            .R056004 = CInt(dataTable.Rows(0).Item("SEIR056004"))
            .R056005 = CInt(dataTable.Rows(0).Item("SEIR056005"))
            .R056006 = CStr(dataTable.Rows(0).Item("SEIR056006")).TrimEnd
            .R056007 = CStr(dataTable.Rows(0).Item("SEIR056007")).TrimEnd
            .R056008 = CStr(dataTable.Rows(0).Item("SEIR056008")).TrimEnd
            .R056009 = CStr(dataTable.Rows(0).Item("SEIR056009")).TrimEnd
            .R056010 = CStr(dataTable.Rows(0).Item("SEIR056010")).TrimEnd
            .R056011 = CStr(dataTable.Rows(0).Item("SEIR056011")).TrimEnd
            .R056012 = CInt(dataTable.Rows(0).Item("SEIR056012"))
            .R056013 = CStr(dataTable.Rows(0).Item("SEIR056013")).TrimEnd
            .R056014 = CStr(dataTable.Rows(0).Item("SEIR056014")).TrimEnd
            .R056015 = CStr(dataTable.Rows(0).Item("SEIR056015")).TrimEnd
            .R056016 = CStr(dataTable.Rows(0).Item("SEIR056016")).TrimEnd
            .R056017 = CStr(dataTable.Rows(0).Item("SEIR056017")).TrimEnd
            .R056018 = CStr(dataTable.Rows(0).Item("SEIR056018")).TrimEnd
            .R056019 = CInt(dataTable.Rows(0).Item("SEIR056019"))
            .R056020 = CStr(dataTable.Rows(0).Item("SEIR056020")).TrimEnd
            .R056021 = CStr(dataTable.Rows(0).Item("SEIR056021")).TrimEnd
            .R056022 = CDec(dataTable.Rows(0).Item("SEIR056022"))
            .R056023 = CStr(dataTable.Rows(0).Item("SEIR056023")).TrimEnd
            .R056024 = CDec(dataTable.Rows(0).Item("SEIR056024"))
            .R056025 = CDec(dataTable.Rows(0).Item("SEIR056025"))
            .R056026 = CDec(dataTable.Rows(0).Item("SEIR056026"))
            .R056027 = CDec(dataTable.Rows(0).Item("SEIR056027"))
            .R056028 = CDec(dataTable.Rows(0).Item("SEIR056028"))
            .R056029 = CDec(dataTable.Rows(0).Item("SEIR056029"))
            .R056030 = CDec(dataTable.Rows(0).Item("SEIR056030"))
            .R056031 = CDec(dataTable.Rows(0).Item("SEIR056031"))
            .R056032 = CInt(dataTable.Rows(0).Item("SEIR056032"))
            .R056033 = CInt(dataTable.Rows(0).Item("SEIR056033"))
            .R056034 = CInt(dataTable.Rows(0).Item("SEIR056034"))
            .R056035 = CDec(dataTable.Rows(0).Item("SEIR056035"))
            .R056036 = CDec(dataTable.Rows(0).Item("SEIR056036"))
            .R056037 = CInt(dataTable.Rows(0).Item("SEIR056037"))
            .R056038 = CDec(dataTable.Rows(0).Item("SEIR056038"))
            .R056039 = CStr(dataTable.Rows(0).Item("SEIR056039")).TrimEnd
            .R056040 = CInt(dataTable.Rows(0).Item("SEIR056040"))
            .R056041 = CDec(dataTable.Rows(0).Item("SEIR056041"))
            .R056042 = CDec(dataTable.Rows(0).Item("SEIR056042"))
            .R056043 = CDec(dataTable.Rows(0).Item("SEIR056043"))
            .R056044 = CDec(dataTable.Rows(0).Item("SEIR056044"))
            .R056045 = CInt(dataTable.Rows(0).Item("SEIR056045"))
            .R056046 = CStr(dataTable.Rows(0).Item("SEIR056046")).TrimEnd
            .R056047 = CInt(dataTable.Rows(0).Item("SEIR056047"))
            .R056048 = CStr(dataTable.Rows(0).Item("SEIR056048")).TrimEnd
            .R056049 = CInt(dataTable.Rows(0).Item("SEIR056049"))
            .R056050 = CLng(dataTable.Rows(0).Item("SEIR056050"))
            .R056051 = CStr(dataTable.Rows(0).Item("SEIR056051")).TrimEnd
            .R056052 = CLng(dataTable.Rows(0).Item("SEIR056052"))
            .R056053 = CInt(dataTable.Rows(0).Item("SEIR056053"))
            .R056054 = CInt(dataTable.Rows(0).Item("SEIR056054"))
            .R056055 = CInt(dataTable.Rows(0).Item("SEIR056055"))
        End With

SetSEIR056Work_End:

        SEIR056 = SEIR056Work

    End Sub

#End Region


#End Region

#Region "ワーク初期化"

    Public Sub ClearHANR001Work(ByRef HANR001 As ProgramLib.仕入ヘッダー型)

        HANR001 = New ProgramLib.仕入ヘッダー型
        With HANR001
            .R001001 = 0
            .R001002 = ""
            .R001003 = 0
            .R001004 = 0
            .R001005 = 0
            .R001006 = 0
            .R001007 = 0
            .R001008 = ""
            .R001009 = 0
            .R001010 = 0
            .R001011 = ""
            .R001012 = "000000"
            .R001013 = "000000"
            .R001014 = ""
            .R001015 = 0
            .R001016 = 0
            .R001017 = 0
            .R001018 = 0
            .R001019 = 0
            .R001020 = 0
            .R001021 = 0
            .R001022 = 0
            .R001023 = 0
            .R001024 = 0
            .R001025 = 0
            .R001026 = "00000"
            .R001027 = ""
            .R001028 = 0
            .R001029 = 0
            .R001030 = 0
            .R001031 = 0
            .R001032 = 0
            .R001033 = 0
            .R001034 = 0
            .R001035 = 0
            .R001036 = 0
            .R001037 = 0
            .R001038 = 0
            .R001039 = 0
            .R001040 = 0
            .R001041 = 0
            .R001042 = 0
            .R001043 = 0
            .R001044 = 0
            .R001045 = 0
            .R001046 = 0
            .R001047 = 0
            .R001048 = 0
            .R001049 = 0
            .R001050 = 0
            .R001051 = 0
            .R001052 = 0
            .R001053 = ""
            .R001054 = ""
            .R001055 = ""
            .R001056 = "JPY"
            .R001057 = 0
            .R001058 = 0
            .R001059 = 0
            .R001060 = 0
            .R001061 = 0
            .R001062 = 0
            .R001063 = 0
            .R001064 = 0
            .R001065 = 0
            .R001066 = 0
            .R001067 = 0
            .R001068 = 0
            .R001069 = 0
            .R001070 = 0
            .R001071 = ""
            .R001072 = 0
            .R001073 = ""
            .R001074 = 0
            .R001075 = 0
            .R001076 = "000000"
            .R001999 = 0
            .R001077 = ""       'A-2008/07/18_Ver7.30_GENKA
            .R001078 = ""       'A-2008/07/18_Ver7.30_GENKA
            '↓A-2009/08/21_RIREKI
            .R001911 = 0
            .R001914 = 0
            .R001915 = 0
            .R001916 = ""
            .R001917 = ""
            .R001918 = 0
            .R001919 = ""
            '↑A-2009/08/21_RIREKI

            .R001A001 = ""
            .R001A002 = ""
            .R001A003 = ""
            .R001A004 = 0
            .R001A005 = 0
            .R001A006 = 0
            .R001A007 = 0
            .R001A008 = 0
            .R001A009 = 0
            .R001A010 = 0
            .R001A011 = 0
            .R001A012 = "00000000"
            .R001A013 = "00"
            .R001A014 = 0
            .R001A015 = 0
            .R001A016 = 0
            .R001S002 = 0       'A-20111124_11

            'A-20121217_Ver7.50_1↓
            .R001087 = 0
            .R001088 = 0
            .R001089 = 0D
            .R001S003 = 0
            .R001S004 = 0D
            .R001S005 = 0D
            .R001S006 = 0D
            .R001S007 = 0D
            .R001S008 = 0D
            .R001S009 = 0D
            .R001S010 = 0D
            .R001S011 = 0D
            .R001S012 = 0D
            .R001S013 = 0D
            .R001S014 = ""
            'A-20121217_Ver7.50_1↑
            'A-20160324_1↓
            .R001095 = 0
            .R001096 = 0
            .R001097 = 0
            .R001098 = 0
            .R001099 = 0
            .R001100 = 0
            .R001101 = 0
            .R001102 = 0
            .R001103 = 0
            .R001104 = 0
            .R001105 = 0
            .R001S015 = 0
            'A-20160324_1↑

            If _myImportParam.Myコントロール情報.Myオプション区分.拡張項目_仕入伝票 = True Then
                .拡張項目入力情報 = CommonFactory.CreateInstance(Of I拡張項目入力情報型)(Me, GetType(拡張項目入力情報型))
                .拡張項目入力情報.付箋色番号 = 0
                For i As Integer = 1 To 20
                    .拡張項目入力情報.拡張項目(i) = ""
                Next
            End If
        End With
    End Sub

    Public Sub ClearHANR002Work(ByRef HANR002 As ProgramLib.仕入明細型)

        HANR002 = New ProgramLib.仕入明細型
        With HANR002
            .R002001 = 0
            .R002002 = 0
            .R002003 = 0
            .R002004 = 0
            .R002005 = 0
            .R002006 = 0
            .R002007 = 0
            .R002008 = ""
            .R002009 = ""
            .R002010 = 0
            .R002011 = 0
            .R002012 = 0
            .R002013 = 0
            .R002014 = 0
            .R002015 = 0
            .R002016 = 0
            .R002017 = ""
            .R002018 = "000000"
            .R002019 = ""
            .R002020 = ""
            .R002021 = ""
            .R002022 = 0
            .R002023 = 0
            .R002024 = ""
            .R002025 = 0
            .R002026 = 0
            .R002027 = 0
            .R002028 = 0
            .R002029 = 0
            .R002030 = 0
            .R002031 = 0
            .R002032 = 0
            .R002033 = 0
            .R002034 = 0
            .R002035 = 0
            .R002036 = 0
            .R002037 = 0
            .R002038 = 0
            .R002039 = 0
            .R002040 = 0
            .R002041 = 0
            .R002042 = 0
            .R002043 = 0
            .R002044 = 0
            .R002045 = 0
            .R002046 = 0
            .R002047 = 0
            .R002048 = 0
            .R002049 = 0
            .R002050 = 0
            .R002051 = 0
            .R002052 = 0
            .R002053 = "00000"
            .R002054 = ""
            .R002055 = ""
            .R002056 = 0
            .R002057 = 0
            .R002058 = 0
            .R002059 = "JPY"
            .R002060 = 0
            .R002061 = 0
            .R002062 = 0
            .R002063 = 0
            .R002064 = 0
            .R002065 = 0
            .R002066 = ""
            .R002067 = ""
            .R002068 = ""
            .R002069 = 0
            .R002070 = 0
            .R002071 = 0
            .R002072 = 0
            .R002073 = ""
            .R002074 = 0
            .R002075 = 0
            .R002076 = ""
            .R002077 = "0000"
            .R002999 = 0
            .R002078 = ""       'A-2008/07/18_Ver7.30_GENKA
            .R002079 = ""       'A-2008/07/18_Ver7.30_GENKA
            .R002080 = ""       'A-2008/07/18_Ver7.30_GENKA
            .R002083 = 0        'A-2009/12/18_Ver7.40_UCHIWAKE
            .R002084 = 0        'A-2009/12/18_Ver7.40_UCHIWAKE
            .R002086 = ""       'A-2009/12/18_Ver7.40_LOT

            .R002A001 = ""
            .R002A002 = ""
            .R002A003 = ""
            .R002A004 = 0
            .R002A005 = 0
            .R002A006 = ""
            .R002A007 = ""
            .R002A008 = ""
            .R002A009 = 0
            .R002A010 = ""
            .R002A011 = 0
            .R002A012 = ""
            .R002A013 = 0
            .R002A014 = 0
            .R002A015 = ""
            .R002A016 = 0
            .R002A017 = 0
            .R002A018 = 0
            .R002A019 = 0
            .R002A020 = 0
            .R002A021 = 0
            .R002A022 = "000000"
            .R002A023 = 0
            .R002A024 = 0
            .R002A025 = 0
            .R002A026 = 0
            .R002A027 = 0
            .R002A028 = 0
            .R002A029 = 0
            .R002A030 = "000000"
            .R002A031 = 0
            .R002A032 = 0
            .R002A033 = 0
            .R002A034 = 0
            .R002A035 = 0
            .R002A036 = 0
            .R002A037 = "000000"
            .R002A038 = "000000"
            .R002A039 = "000000"
            .R002A040 = 0
            .R002A041 = 0
            .R002A042 = 0

            'A-20121217_Ver7.50_1↓
            .R002101 = 0
            .R002102 = 0
            .R002103 = 0D
            .R002104 = 0D
            .R002105 = 0
            .R002106 = 0D
            .R002107 = 0D
            'A-20160324_1↓
            .R002108 = 0D
            .R002109 = 0D
            .R002110 = 0D
            .R002112 = 0D
            .R002113 = 0D
            .R002114 = 0D
            .R002115 = 0D
            'A-20160324_1↑
            .R002S001 = 0D
            .R002S002 = 0D
            .R002S003 = 0D
            .R002S004 = 0D
            .R002S005 = 0D
            .R002S006 = 0D
            .R002S007 = 0D
            .R002S008 = ""
            .R002S009 = ""
            .R002S010 = ""
            .R002S011 = ""
            .R002S012 = ""
            .R002S013 = ""
            .R002S014 = 0
            .R002S015 = 0
            .R002S016 = 0
            'A-20121217_Ver7.50_1↑
            'A-20141105_1↓
            .R002S017 = "000000"
            .R002S018 = 0
            'A-20141105_1↑
            .R002S020 = 0    'A-20160324_2

            If _myImportParam.Myコントロール情報.Myオプション区分.拡張項目_仕入明細 = True Then
                .拡張項目入力情報 = CommonFactory.CreateInstance(Of I拡張項目入力情報型)(Me, GetType(拡張項目入力情報型))
                .拡張項目入力情報.付箋色番号 = 0
                For i As Integer = 1 To 20
                    .拡張項目入力情報.拡張項目(i) = ""
                Next
            End If
            .内訳更新情報.初期化()      'A-2009/12/18_Ver7.40_UCHIWAKE
            .ロット更新情報.初期化()    'A-2009/12/18_Ver7.40_LOT
        End With

    End Sub

    Public Sub ClearHANM003Work(ByRef HANM003 As ProgramLib.商品マスター型)

        HANM003 = New ProgramLib.商品マスター型
        With HANM003
            .M003002 = ""
            .M003007 = 0
            .M003008 = 0
            .M003039 = 0
            .M003042 = 0
            .M003045 = 0
            .M003051 = 0        'A-2009/12/18_Ver7.40_UCHIWAKE
            .M003052 = 0        'A-2009/12/18_Ver7.40_UCHIWAKE
            .M003053 = 0        'A-2009/12/18_Ver7.40_UCHIWAKE
            .M003086 = 0        'A-2009/12/18_Ver7.40_UCHIWAKE
            .M003092 = 0        'A-2009/12/18_Ver7.40_UCHIWAKE
            .M003093 = 0        'A-2009/12/18_Ver7.40_LOT
            .M003094 = 0        'A-2009/12/18_Ver7.40_LOT

            .M003A010 = ""      'A-20141105_2
            .M003A014 = ""
            .M003A015 = ""
            .M003A016 = ""
            .M003A017 = 0
            .M003A019 = 0
            .M003A024 = 0
            .M003A027 = ""      'A-20141105_2
            .M003A028 = 0
            .M003A029 = 0
            .M003A030 = 0
            .M003A031 = 0
            .M003A032 = 0

            .M003S015 = 0       'A-20130304_1
            .M003S030 = 0       'A-20141105_1

            .標準売上単価 = 0
            .標準仕入単価 = 0
        End With

    End Sub

    Public Sub ClearHANR005Work(ByRef HANR005 As ProgramLib.受注明細型)     'A-2008/07/18_Ver7.30_GENKA

        HANR005 = New ProgramLib.受注明細型
        With HANR005
            .R005003 = 0
            .R005004 = 0
            .R005017 = ""
            .R005019 = ""
            .R005038 = 0
            .R005050 = 0        'A-20120315_3
            .R005052 = 0
            .R005058 = ""       'A-2009/12/18_Ver7.40_UCHIWAKE
            .R005059 = ""       'A-2009/12/18_Ver7.40_UCHIWAKE
            .R005060 = ""       'A-2009/12/18_Ver7.40_UCHIWAKE
            .R005073 = 0
            .R005086 = ""
            .R005087 = ""
            .R005003JCH = 0
            .R005006JCH = ""
            .R005A004 = ""
            .R005A019 = 0
            .R005A020 = 0
            .R005A021 = 0
            .R005A022 = ""
            .R005A023 = 0D      'A-20120315_3
            .R005A025 = 0
            .R005A026 = 0
            .R005A027 = 0
            .R005A028 = 0
            .R005A033 = 0
            .R005A034 = 0D
            .R005S027 = 0       'A-20160324_2

            .R004002 = ""
            .R004003 = 0
            .R004013 = ""       'A-20141105_2
            .R004035 = ""
            .R004036 = ""
            .R004A004 = ""
            .R004A005 = ""
            .R004A010 = 0
            .R004A012 = 0

            .M002004 = ""
            .M002005 = ""

            '関連受注項目
            .JCH_R004002 = ""
            .JCH_R004003 = 0
            .JCH_R004035 = ""
            .JCH_R004036 = ""

            .JCH_R005003 = 0
            .JCH_R005004 = 0
            .JCH_R005017 = ""
            .JCH_R005A001 = ""
            .JCH_R005A002 = ""
            .JCH_R005A003 = ""
            .JCH_R005A011 = ""
        End With

    End Sub

    Public Sub ClearHANM006Work(ByRef HANM006 As ProgramLib.倉庫マスター型)

        HANM006 = New ProgramLib.倉庫マスター型
        With HANM006
            .M006A001 = 0
            .M006A002 = 0

            .マスタ存在 = False
        End With

    End Sub

    Public Sub ClearSEIM050Work(ByRef SEIM050 As ProgramLib.製番マスター型)

        SEIM050 = New ProgramLib.製番マスター型
        With SEIM050
            .M050001 = ""
            .M050002 = 0    'A-20111025_1
            .M050003 = 0
            .M050011 = 0
            .M050015 = 0
            .M050016 = 0    'A-20111025_1
            .M050019 = 0
            .M050020 = 0
            .M050021 = 0
            .M050022 = 0
            .M050038 = 0

            .客先注番 = ""
        End With

    End Sub

#Region "ロット明細"

    Public Sub ClearSEIR008Work(ByRef SEIR008 As ProgramLib.ロット明細型)

        SEIR008 = New ProgramLib.ロット明細型
        With SEIR008
            .R008001 = 0
            .R008002 = 0
            .R008003 = 0
            .R008004 = 0
            .R008005 = 0
            .R008006 = 0
            .R008007 = ""
            .R008008 = ""
            .R008009 = ""
            .R008010 = ""
            .R008011 = ""
            .R008012 = ""
            .R008013 = ""
            .R008014 = ""
            .R008015 = 0
            .R008016 = 0
            .R008017 = 0
            .R008018 = ""
            .R008019 = ""
            .R008020 = ""
            .R008021 = ""
            .R008022 = ""
            .R008023 = ""
            .R008024 = ""
            .R008025 = 0
            .R008026 = 0
            .R008027 = 0
            .R008028 = ""
            .R008029 = ""
            .R008030 = ""
            .R008031 = ""
            .R008032 = ""
            .R008033 = ""
            .R008034 = ""
            .R008035 = ""
            .R008036 = 0
            .R008037 = 0
            .R008038 = 0
            .R008039 = ""
            .R008040 = ""
            .R008041 = ""
            .R008042 = 0
        End With
    End Sub

#End Region

#Region "品目別ロット"

    Public Sub ClearSEIR009Work(ByRef SEIR009 As ProgramLib.品目別ロット型)

        SEIR009 = New ProgramLib.品目別ロット型
        With SEIR009
            .R009001 = ""
            .R009002 = ""
            .R009003 = 0
        End With
    End Sub

#End Region

#Region "入出荷伝票"

    Public Sub ClearSEIR010Work(ByRef SEIR010 As ProgramLib.入出荷ヘッダー型)

        SEIR010 = New ProgramLib.入出荷ヘッダー型
        With SEIR010
            .R010001 = 0
            .R010002 = ""
            .R010003 = 0
            .R010004 = 0
            .R010005 = 0
            .R010006 = 0
            .R010007 = 0
            .R010008 = 0
            .R010009 = ""
            .R010010 = 0
            .R010011 = ""
            .R010012 = ""
            .R010013 = ""
            .R010014 = ""
            .R010015 = ""
            .R010016 = 0
            .R010017 = 0
            .R010018 = 0
            .R010019 = 0
            .R010020 = 0
            .R010021 = 0
            .R010022 = ""
            .R010023 = ""
            .R010024 = ""
            .R010025 = ""
            .R010026 = ""
            .R010027 = ""
            .R010028 = 0
            .R010029 = 0
            .R010030 = 0
            .R010031 = 0
            .R010032 = ""
            .R010033 = 0
            .R010034 = 0
            .R010035 = ""
            .R010036 = ""
            .R010037 = ""
            .R010038 = ""
            .R010039 = ""
            .R010040 = 0
            .R010041 = 0
            .R010042 = 0
            .R010043 = 0
            .R010044 = 0
            .R010045 = 0
            .R010046 = 0
            .R010047 = 0
            .R010048 = 0
            .R010049 = 0
            .R010050 = 0
            .R010051 = 0
            .R010052 = 0
            .R010053 = 0
            .R010054 = 0
            .R010055 = 0
            .R010056 = 0
            .R010057 = 0
            .R010058 = 0
            .R010059 = 0
            .R010060 = 0
            .R010061 = 0
            .R010062 = 0

            'A-20121217_Ver7.50_1↓
            .R010063 = 0D
            .R010064 = 0
            .R010065 = 0
            .R010066 = 0D
            .R010067 = 0D
            .R010068 = 0D
            .R010069 = 0D
            .R010070 = ""
            'A-20121217_Ver7.50_1↑
            .R010071 = 0    'A-20160324_1
            .R010072 = 0    'A-20160324_1

            .拡張項目入力情報 = CommonFactory.CreateInstance(Of I拡張項目入力情報型)(Me, GetType(拡張項目入力情報型))
            .拡張項目入力情報.付箋色番号 = 0
            For i As Integer = 1 To 20
                .拡張項目入力情報.拡張項目(i) = ""
            Next
        End With
    End Sub

    Public Sub ClearSEIR011Work(ByRef SEIR011 As ProgramLib.入出荷明細型)

        SEIR011 = New ProgramLib.入出荷明細型
        With SEIR011
            .R011001 = 0
            .R011002 = 0
            .R011003 = 0
            .R011004 = 0
            .R011005 = 0
            .R011006 = 0
            .R011007 = 0
            .R011008 = 0
            .R011009 = ""
            .R011010 = ""
            .R011011 = 0
            .R011012 = 0
            .R011013 = 0
            .R011014 = ""
            .R011015 = ""
            .R011016 = ""
            .R011017 = ""
            .R011018 = ""
            .R011019 = 0
            .R011020 = 0
            .R011021 = ""
            .R011022 = 0
            .R011023 = 0
            .R011024 = 0
            .R011025 = 0
            .R011026 = 0
            .R011027 = 0
            .R011028 = 0
            .R011029 = 0
            .R011030 = 0
            .R011031 = 0
            .R011032 = 0
            .R011033 = 0
            .R011034 = 0
            .R011035 = 0
            .R011036 = 0
            .R011037 = 0
            .R011038 = ""
            .R011039 = ""
            .R011040 = ""
            .R011041 = 0
            .R011042 = 0
            .R011043 = 0
            .R011044 = 0
            .R011045 = 0
            .R011046 = 0
            .R011047 = 0
            .R011048 = 0
            .R011049 = 0
            .R011050 = ""
            .R011051 = 0
            .R011052 = 0
            .R011053 = 0
            .R011054 = 0
            .R011055 = 0
            .R011056 = 0
            .R011057 = 0
            .R011058 = ""
            .R011059 = ""
            .R011060 = ""
            .R011061 = ""
            .R011062 = ""
            .R011063 = ""
            .R011064 = ""
            .R011065 = ""
            .R011066 = ""
            .R011067 = 0
            .R011068 = 0
            .R011069 = 0
            .R011070 = ""
            .R011071 = 0
            .R011072 = ""
            .R011073 = 0
            .R011074 = 0
            .R011075 = 0
            .R011076 = 0
            .R011077 = 0
            .R011078 = 0
            .R011079 = 0
            .R011080 = 0
            .R011081 = ""
            .R011082 = 0
            .R011083 = ""
            .R011084 = ""
            .R011085 = 0
            .R011086 = 0
            .R011087 = 0
            .R011088 = 0
            .R011089 = 0
            .R011090 = 0
            .R011091 = 0
            .R011092 = 0
            .R011093 = 0
            .R011094 = 0
            .R011095 = 0
            .R011096 = 0
            .R011097 = 0
            .R011098 = 0
            .R011099 = 0

            'A-20121217_Ver7.50_1↓
            .R011100 = 0D
            .R011101 = 0D
            .R011102 = 0D
            .R011103 = 0D
            .R011104 = 0D
            .R011105 = 0D
            .R011106 = 0D
            .R011107 = 0D
            .R011108 = 0D
            .R011109 = 0D
            .R011110 = 0D
            .R011111 = 0D
            .R011112 = ""
            .R011113 = 0
            .R011114 = 0
            .R011115 = 0
            .R011116 = ""
            .R011117 = ""
            .R011118 = ""
            .R011119 = ""
            .R011120 = ""
            'A-20121217_Ver7.50_1↑
            .R011121 = 0    'A-20160324_2

            .拡張項目入力情報 = CommonFactory.CreateInstance(Of I拡張項目入力情報型)(Me, GetType(拡張項目入力情報型))
            .拡張項目入力情報.付箋色番号 = 0
            For i As Integer = 1 To 20
                .拡張項目入力情報.拡張項目(i) = ""
            Next
        End With

    End Sub

#End Region

#Region "受発注伝票"

    Public Sub ClearHANR005Work(ByRef HANR005 As ProgramLib.受発注明細型)

        HANR005 = New ProgramLib.受発注明細型
        With HANR005
            .R005001 = 0
            .R005002 = 0
            .R005003 = 0
            .R005004 = 0
            .R005005 = 0
            .R005006 = ""
            .R005007 = ""
            .R005008 = 0
            .R005009 = 0
            .R005010 = 0
            .R005011 = 0
            .R005012 = 0
            .R005013 = 0
            .R005014 = 0
            .R005015 = ""
            .R005016 = ""
            .R005017 = ""
            .R005018 = ""
            .R005019 = ""
            .R005020 = 0
            .R005021 = 0
            .R005022 = ""
            .R005023 = 0
            .R005024 = 0
            .R005025 = 0
            .R005026 = 0
            .R005027 = 0
            .R005028 = 0
            .R005029 = 0
            .R005030 = 0
            .R005031 = 0
            .R005032 = 0
            .R005033 = 0
            .R005034 = 0
            .R005035 = 0
            .R005036 = 0
            .R005037 = 0
            .R005038 = 0
            .R005039 = ""
            .R005040 = ""
            .R005041 = ""
            .R005042 = 0
            .R005043 = 0
            .R005044 = 0
            .R005045 = 0
            .R005046 = 0
            .R005047 = 0
            .R005048 = 0
            .R005049 = 0
            .R005050 = 0
            .R005051 = ""
            .R005052 = 0
            .R005053 = 0
            .R005054 = 0
            .R005055 = 0
            .R005056 = 0
            .R005057 = 0
            .R005058 = ""
            .R005059 = ""
            .R005060 = ""
            .R005061 = 0
            .R005062 = 0
            .R005063 = 0
            .R005064 = 0
            .R005065 = 0
            .R005066 = 0
            .R005067 = 0
            .R005068 = 0
            .R005069 = 0
            .R005070 = 0
            .R005071 = 0
            .R005072 = 0
            .R005073 = 0
            .R005074 = 0
            .R005075 = 0
            .R005076 = ""
            .R005077 = ""
            .R005078 = 0
            .R005079 = 0
            .R005080 = 0
            .R005081 = 0
            .R005082 = 0
            .R005083 = 0
            .R005084 = 0
            .R005085 = 0
            .R005999 = 0

            .R005A001 = ""
            .R005A002 = ""
            .R005A003 = ""
            .R005A004 = ""
            .R005A005 = ""
            .R005A006 = ""
            .R005A007 = 0
            .R005A008 = 0
            .R005A009 = 0
            .R005A010 = 0
            .R005A011 = ""
            .R005A012 = 0
            .R005A013 = 0
            .R005A014 = 0
            .R005A015 = 0
            .R005A016 = 0
            .R005A017 = ""
            .R005A018 = 0
            .R005A019 = 0
            .R005A020 = 0
            .R005A021 = 0
            .R005A022 = ""
            .R005A023 = 0
            .R005A024 = ""
            .R005A025 = 0
            .R005A026 = 0
            .R005A027 = 0
            .R005A028 = 0
            .R005A029 = 0
            .R005A030 = 0
            .R005A031 = 0
            .R005A032 = 0
            .R005A033 = 0
            .R005A034 = 0
            .R005A035 = 0
            .R005A036 = ""
            .R005A037 = 0
            .R005A038 = ""
        End With

    End Sub

#End Region

#Region "従属需要"

    Public Sub ClearSEIR056Work(ByRef SEIR056 As ProgramLib.従属需要型)

        SEIR056 = New ProgramLib.従属需要型
        With SEIR056
            .R056001 = 0
            .R056002 = 0L
            .R056003 = 0
            .R056004 = 0
            .R056005 = 0
            .R056006 = ""
            .R056007 = ""
            .R056008 = ""
            .R056009 = ""
            .R056010 = ""
            .R056011 = ""
            .R056012 = 0
            .R056013 = ""
            .R056014 = ""
            .R056015 = ""
            .R056016 = ""
            .R056017 = ""
            .R056018 = ""
            .R056019 = 0
            .R056020 = ""
            .R056021 = ""
            .R056022 = 0D
            .R056023 = ""
            .R056024 = 0D
            .R056025 = 0D
            .R056026 = 0D
            .R056027 = 0D
            .R056028 = 0D
            .R056029 = 0D
            .R056030 = 0D
            .R056031 = 0D
            .R056032 = 0
            .R056033 = 0
            .R056034 = 0
            .R056035 = 0D
            .R056036 = 0D
            .R056037 = 0
            .R056038 = 0D
            .R056039 = ""
            .R056040 = 0
            .R056041 = 0D
            .R056042 = 0D
            .R056043 = 0D
            .R056044 = 0D
            .R056045 = 0
            .R056046 = ""
            .R056047 = 0
            .R056048 = ""
            .R056049 = 0
            .R056050 = 0L
            .R056051 = ""
            .R056052 = 0L
            .R056053 = 0
            .R056054 = 0
            .R056055 = 0
        End With
    End Sub

#End Region

#End Region

End Class
