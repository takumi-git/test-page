﻿'A-CUST20190830↓
Public Class MasterReader
    Inherits DataHandlerBase
    Implements IMasterReader

    Private _readParam As ReadParam

    Public Function MasterRead(ByVal targetMaster As IMasterReader.テーブル一覧型, ByVal param As ReadParam) As System.Data.DataTable Implements IMasterReader.MasterRead

        SetUpDAC()

        Dim resultDataTable As New DataTable

        Using connection As DbConnection = OpenConnection()

            _readParam = param

            Select Case targetMaster
                Case IMasterReader.テーブル一覧型.JTB様コントロール
                    resultDataTable = ReadDataJTB様コントロール(connection)

                Case IMasterReader.テーブル一覧型.発注情報
                    resultDataTable = ReadData発注情報(connection)

                Case IMasterReader.テーブル一覧型.入出庫予定情報
                    resultDataTable = ReadData入出庫予定情報(connection)

                Case IMasterReader.テーブル一覧型.商品マスター
                    resultDataTable = ReadData商品マスター(connection)
            End Select

            CloseConnection(connection)
        End Using

        Return resultDataTable

    End Function

    Private Function ReadDataJTB様コントロール(ByVal connection As DbConnection) As DataTable

        Dim sql As String = ""
        Dim paramInfo As ParamInfoList = New ParamInfoList
        sql &= SelectJTB様コントロール(paramInfo)

        Dim dt As New DataTable
        dt = DataAccess.GetDataTable(connection, sql, paramInfo)
        dt.TableName = IMasterReader.テーブル一覧型.JTB様コントロール.ToString

        Return dt

    End Function

    Private Function ReadData発注情報(ByVal connection As DbConnection) As DataTable

        Dim sql As String = ""
        Dim paramInfo As ParamInfoList = New ParamInfoList
        sql &= Select発注情報PrimaryKey(paramInfo)

        Dim dt As New DataTable
        dt = DataAccess.GetDataTable(connection, sql, paramInfo)
        dt.TableName = IMasterReader.テーブル一覧型.発注情報.ToString

        Return dt

    End Function

    Private Function ReadData入出庫予定情報(ByVal connection As DbConnection) As DataTable

        Dim sql As String = ""
        Dim paramInfo As ParamInfoList = New ParamInfoList
        sql &= Select入出庫予定情報PrimaryKey(paramInfo)

        Dim dt As New DataTable
        dt = DataAccess.GetDataTable(connection, sql, paramInfo)
        dt.TableName = IMasterReader.テーブル一覧型.入出庫予定情報.ToString

        Return dt

    End Function

    Private Function ReadData商品マスター(ByVal connection As DbConnection) As DataTable

        Dim sql As String = ""
        Dim paramInfo As ParamInfoList = New ParamInfoList
        sql &= SelectHANM003PrimaryKey(paramInfo)

        Dim dt As New DataTable
        dt = DataAccess.GetDataTable(connection, sql, paramInfo)
        dt.TableName = IMasterReader.テーブル一覧型.商品マスター.ToString

        Return dt

    End Function

#Region "■JTB様コントロール■"
    Public Function SelectJTB様コントロール(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList
                    ) As String

        Dim query As New System.Text.StringBuilder

        '◆◇◆SQL文作成◇◆◇
        query.Append("SELECT ")
        query.Append(" SEICA01001 ")
        query.Append("," & MyBase.QueryWrapper.AddIsNull() & "(SEICA01002,N' ') SEICA01002 ")
        query.Append(" FROM ")
        query.Append(MyBase.ExchangeTableName("SEI98CA01JTBCONTROL"))
        query.Append(MyBase.QueryWrapper.AddNoLock())
        query.Append(" ")
        query.Append(" WHERE ")
        query.Append("SEICA01001 = " & GetParameter(ReadParam.項目名型.CA01KEY, paramInfo) & " ")
        query.Append(MyBase.QueryWrapper.AddUR)

        Return query.ToString

    End Function


#End Region

#Region "■発注情報■"
    Public Function Select発注情報PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList
                    ) As String

        Dim query As New System.Text.StringBuilder

        Dim aliasHHCHR04 As String = "HHCHR04"      '発注ヘッダー
        Dim aliasHHCHR30 As String = "HHCHR30"      'ヘッダー拡張
        Dim aliasHHCHM02SIR As String = "HHCHM02SIR"    '仕入先

        Dim aliasMHCHR05 As String = "MHCHR05"      '発注明細
        Dim aliasMHCHR30 As String = "MHCHR30"      '明細拡張
        Dim aliasMHCHR30手 As String = "MHCHR30TE"      '明細拡張-手配
        Dim aliasMHCHRA01 As String = "MHCHRA01"    '発注内訳
        Dim aliasMHCHM03 As String = "MHCHM03"      '商品
        Dim aliasMHCHM06 As String = "MHCHM06"      '倉庫


        query.Append("SELECT ")

        query.Append(QueryWrapper.AddIndexHintOracle(GetIndexHint("SEL_A_1")))
        query.Append(" " & SelectItem受発注ヘッダーテーブル(aliasHHCHR04))
        query.Append("," & SelectItem仕入先マスター(aliasHHCHM02SIR))
        query.Append("," & SelectItem明細拡張テーブル(aliasHHCHR30))

        query.Append("," & SelectItem受発注明細テーブル(aliasMHCHR05))
        query.Append("," & SelectItem倉庫マスター(aliasMHCHM06))
        query.Append("," & SelectItem商品マスター(aliasMHCHM03))
        query.Append("," & SelectItem明細拡張テーブル(aliasMHCHR30))
        query.Append("," & SelectItem明細拡張テーブル(aliasMHCHR30手))


        '受発注明細
        query.Append(" FROM ")
        query.Append(Me.ExchangeTableName("HAN10R005JUHACHUM ") & aliasMHCHR05 & " " & QueryWrapper.AddNoLock(GetIndexHint("R005_A_1")))

        '発注内訳
        query.Append(" INNER JOIN ")
        query.Append(Me.ExchangeTableName("SEI98RA01HACHUUTIWAKE ") & aliasMHCHRA01 & " " & QueryWrapper.AddNoLock)
        query.Append("  ON " & aliasMHCHRA01 & ".SEIRA01001 = " & aliasMHCHR05 & ".HANR005003 ")
        query.Append(" AND " & aliasMHCHRA01 & ".SEIRA01002 = 1 ")
        query.Append(" AND " & aliasMHCHRA01 & ".SEIRA01003 = " & GetParameter(ReadParam.項目名型.内訳NO, paramInfo) & " ")

        '受発注ヘッダー
        query.Append(" INNER JOIN ")
        query.Append(Me.ExchangeTableName("HAN10R004JUHACHUH ") & aliasHHCHR04 & " " & QueryWrapper.AddNoLock)
        query.Append("  ON " & aliasHHCHR04 & ".HANR004004 = 1 ")
        query.Append(" AND " & aliasHHCHR04 & ".HANR004005 = " & aliasMHCHR05 & ".HANR005003 ")

        '仕入先マスター（仕入先）
        query.Append(" LEFT OUTER JOIN ")
        query.Append(Me.ExchangeTableName("HAN10M002SHIIRE ") & aliasHHCHM02SIR & " " & QueryWrapper.AddNoLock)
        query.Append("  ON " & aliasHHCHM02SIR & ".HANM002003 = " & aliasHHCHR04 & ".HANR004002 ")

        '明細拡張テーブル(ヘッダー)
        query.Append(" LEFT OUTER JOIN ")
        query.Append(Me.ExchangeTableName("HAN10R030KAKUCHO ") & aliasHHCHR30 & QueryWrapper.AddNoLock)
        query.Append(" ON " & aliasHHCHR30 & ".HANR030001 = 2 ")
        query.Append(" AND " & aliasHHCHR30 & ".HANR030002 = " & aliasHHCHR04 & ".HANR004004 ")
        query.Append(" AND " & aliasHHCHR30 & ".HANR030003 = 0 ")
        query.Append(" AND " & aliasHHCHR30 & ".HANR030004 = " & aliasHHCHR04 & ".HANR004005 ")
        query.Append(" AND " & aliasHHCHR30 & ".HANR030005 = 0 ")

        '倉庫
        query.Append(" LEFT OUTER JOIN ")
        query.Append(Me.ExchangeTableName("HAN10M006SOKO ") & aliasMHCHM06 & QueryWrapper.AddNoLock)
        query.Append(" ON " & aliasMHCHM06 & ".HANM006001 = " & aliasMHCHR05 & ".HANR005016")

        '商品マスター
        query.Append(" LEFT OUTER JOIN ")
        query.Append(Me.ExchangeTableName("HAN10M003SHOHIN ") & aliasMHCHM03 & QueryWrapper.AddNoLock)
        query.Append(" ON " & aliasMHCHM03 & ".HANM003001 = " & aliasMHCHR05 & ".HANR005017")

        '明細拡張テーブル(明細)
        query.Append(" LEFT OUTER JOIN ")
        query.Append(Me.ExchangeTableName("HAN10R030KAKUCHO ") & aliasMHCHR30 & QueryWrapper.AddNoLock)
        query.Append(" ON " & aliasMHCHR30 & ".HANR030001 = 2 ")
        query.Append(" AND " & aliasMHCHR30 & ".HANR030002 = " & aliasMHCHR05 & ".HANR005002 ")
        query.Append(" AND " & aliasMHCHR30 & ".HANR030003 = 0 ")
        query.Append(" AND " & aliasMHCHR30 & ".HANR030004 = " & aliasMHCHR05 & ".HANR005003 ")
        query.Append(" AND " & aliasMHCHR30 & ".HANR030005 = " & aliasMHCHR05 & ".HANR005004 ")

        '明細拡張テーブル(手配)
        query.Append(" LEFT OUTER JOIN ")
        query.Append(Me.ExchangeTableName("HAN10R030KAKUCHO ") & aliasMHCHR30手 & QueryWrapper.AddNoLock)
        query.Append(" ON " & aliasMHCHR30手 & ".HANR030001 = 20 ")
        query.Append(" AND " & aliasMHCHR30手 & ".HANR030002 = 20 ")
        query.Append(" AND " & aliasMHCHR30手 & ".HANR030003 = 0 ")
        query.Append(" AND " & aliasMHCHR30手 & ".HANR030004 = " & aliasMHCHR05 & ".HANR005A027 ")
        query.Append(" AND " & aliasMHCHR30手 & ".HANR030005 = 0 ")

        query.Append("WHERE ")
        query.Append("HANR005002 = 1 ")
        query.Append("AND ")
        query.Append("HANR005003 = " & GetParameter(ReadParam.項目名型.受発注番号, paramInfo) & " ")
        query.Append("AND ")
        query.Append("HANR005004 = " & GetParameter(ReadParam.項目名型.受発注行番号, paramInfo) & " ")

        Return query.ToString

    End Function


#End Region

#Region "■発注情報■"
    Public Function Select入出庫予定情報PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList
                    ) As String

        Dim query As New System.Text.StringBuilder

        Dim aliasHHCHRA02 As String = "HHCHRA02"      '入出庫予定ヘッダー

        Dim aliasMHCHRA03 As String = "MHCHRA03"      '入出庫予定明細
        Dim aliasMHCHM03 As String = "MHCHM03"      '商品


        query.Append("SELECT ")

        query.Append(QueryWrapper.AddIndexHintOracle(GetIndexHint("SEL_A_1")))
        query.Append(" " & SelectItem入出庫予定ヘッダーテーブル(aliasHHCHRA02))

        query.Append("," & SelectItem入出庫予定明細テーブル(aliasMHCHRA03))
        query.Append("," & SelectItem商品マスター(aliasMHCHM03))


        '入出庫予定明細
        query.Append(" FROM ")
        query.Append(Me.ExchangeTableName("SEI98RA03NYUSHUKOYOTEIM ") & aliasMHCHRA03 & " " & QueryWrapper.AddNoLock(GetIndexHint("R005_A_1")))

        '入出庫予定ヘッダー
        query.Append(" INNER JOIN ")
        query.Append(Me.ExchangeTableName("SEI98RA02NYUSHUKOYOTEIH ") & aliasHHCHRA02 & " " & QueryWrapper.AddNoLock)
        query.Append("  ON " & aliasHHCHRA02 & ".SEIRA02001 = " & aliasMHCHRA03 & ".SEIRA03001 ")

        '商品マスター
        query.Append(" LEFT OUTER JOIN ")
        query.Append(Me.ExchangeTableName("HAN10M003SHOHIN ") & aliasMHCHM03 & QueryWrapper.AddNoLock)
        query.Append(" ON " & aliasMHCHM03 & ".HANM003001 = " & aliasMHCHRA03 & ".SEIRA03013")

        query.Append(" WHERE ")
        query.Append(" SEIRA03001 = " & GetParameter(ReadParam.項目名型.入庫予定番号, paramInfo) & " ")
        query.Append(" AND ")
        query.Append(" SEIRA03002 = " & GetParameter(ReadParam.項目名型.入庫予定行番号, paramInfo) & " ")
        query.Append(" AND ")
        query.Append(" SEIRA03010 = 1 ")

        Return query.ToString

    End Function


#End Region

#Region "■商品マスター■"

    '存在チェック
    Public Function SelectHANM003PrimaryKey(ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList
                    ) As String

        Dim query As New System.Text.StringBuilder

        query.Append("SELECT ")
        query.Append(" " & MyBase.QueryWrapper.AddIsNull() & " (HANM003002, ' ') HANM003002 ")
        query.Append(",HANM003009 ")
        query.Append(",HANM003015 ")
        query.Append(",HANM003018 ")
        query.Append(",HANM003029 ")
        query.Append(",HANM003035 ")
        query.Append(",HANM003038 ")
        query.Append(",HANM003039 ")
        query.Append(",HANM003040 ")
        query.Append(",HANM003041 ")
        query.Append(",HANM003042 ")
        query.Append(",HANM003044 ")
        query.Append(",HANM003048 ")
        query.Append(", " & MyBase.QueryWrapper.AddIsNull() & " (HANM003A014, ' ') HANM003A014 ")
        query.Append(", " & MyBase.QueryWrapper.AddIsNull() & " (HANM003A015, ' ') HANM003A015 ")
        query.Append(", " & MyBase.QueryWrapper.AddIsNull() & " (HANM003A016, ' ') HANM003A016 ")
        query.Append(",HANM003A019 ")
        query.Append(",HANM003A025 ")
        query.Append(",HANM003S005 ")       '同時仕入先

        query.Append(", " & MyBase.QueryWrapper.AddIsNull() & " (HANM002003, ' ') HANM002003 ")
        query.Append(", " & MyBase.QueryWrapper.AddIsNull() & " (HANM002015, ' ') HANM002015 ")
        query.Append(", " & MyBase.QueryWrapper.AddIsNull() & " (HANM002041, 0) HANM002041 ")
        query.Append(", " & MyBase.QueryWrapper.AddIsNull() & " (HANM002042, 0) HANM002042 ")
        query.Append(", " & MyBase.QueryWrapper.AddIsNull() & " (HANM002043, 0) HANM002043 ")
        query.Append(", " & MyBase.QueryWrapper.AddIsNull() & " (HANM002046, 0) HANM002046 ")
        query.Append(", " & MyBase.QueryWrapper.AddIsNull() & " (HANM002047, 0) HANM002047 ")
        query.Append(", " & MyBase.QueryWrapper.AddIsNull() & " (HANM002048, 0) HANM002048 ")
        query.Append(", " & MyBase.QueryWrapper.AddIsNull() & " (HANM002044, 0) HANM002044 ")
        query.Append(", " & MyBase.QueryWrapper.AddIsNull() & " (HANM002045, 0) HANM002045 ")

        '商品マスター
        query.Append("FROM " & MyBase.ExchangeTableName("HAN10M003SHOHIN") & " ")
        query.Append(MyBase.QueryWrapper.AddNoLock())

        '仕入先マスター
        query.Append(" Left outer join ")
        query.Append(" " & MyBase.ExchangeTableName("HAN10M002SHIIRE") & " ")
        query.Append(MyBase.QueryWrapper.AddNoLock())
        query.Append("   ON HANM002001 = HANM003S005 ")

        query.Append("WHERE ")
        query.Append("HANM003001 = " & GetParameter(ReadParam.項目名型.商品コード, paramInfo) & " ")
        query.Append(MyBase.QueryWrapper.AddUR())

        Return query.ToString

    End Function

#End Region

#Region "取得項目"

    ''' <summary>
    ''' 受発注ヘッダーテーブル取得列名定義
    ''' </summary>
    ''' <param name="tableAlias"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function SelectItem受発注ヘッダーテーブル(Optional ByVal tableAlias As String = "") As String

        Dim item As New System.Text.StringBuilder

        item.Append(" " & ItemBuilder(tableAlias, "HANR004001", "", GetDefault(属性.数値)))                 '取引先区分
        item.Append("," & ItemBuilder(tableAlias, "HANR004002", "", GetDefault(属性.文字)))                 '得意先コード
        item.Append("," & ItemBuilder(tableAlias, "HANR004003", "", GetDefault(属性.数値)))                 '受発注日
        item.Append("," & ItemBuilder(tableAlias, "HANR004004", "", GetDefault(属性.数値)))                 '伝票区分
        item.Append("," & ItemBuilder(tableAlias, "HANR004005", "", GetDefault(属性.数値)))                 '受注番号
        item.Append("," & ItemBuilder(tableAlias, "HANR004006", "", GetDefault(属性.数値)))                 '納期
        item.Append("," & ItemBuilder(tableAlias, "HANR004007", "", GetDefault(属性.数値)))                 '操作日付
        item.Append("," & ItemBuilder(tableAlias, "HANR004008", "", GetDefault(属性.文字)))                 'ログインＩＤ
        item.Append("," & ItemBuilder(tableAlias, "HANR004009", "", GetDefault(属性.数値)))                 'チェックマーク区分
        item.Append("," & ItemBuilder(tableAlias, "HANR004010", "", GetDefault(属性.文字)))                 '担当者コード
        item.Append("," & ItemBuilder(tableAlias, "HANR004011", "", GetDefault(属性.文字)))                 '納品先コード
        item.Append("," & ItemBuilder(tableAlias, "HANR004012", "", GetDefault(属性.文字)))                 '部門コード
        item.Append("," & ItemBuilder(tableAlias, "HANR004013", "", GetDefault(属性.文字)))                 '倉庫コード
        item.Append("," & ItemBuilder(tableAlias, "HANR004014", "", GetDefault(属性.文字)))                 'オーダーコード
        item.Append("," & ItemBuilder(tableAlias, "HANR004015", "", GetDefault(属性.数値)))                 '出荷予定日
        item.Append("," & ItemBuilder(tableAlias, "HANR004016", "", GetDefault(属性.数値)))                 '見積処理連番
        item.Append("," & ItemBuilder(tableAlias, "HANR004017", "", GetDefault(属性.数値)))                 '相手処理連番
        item.Append("," & ItemBuilder(tableAlias, "HANR004018", "", GetDefault(属性.数値)))                 '売掛区分
        item.Append("," & ItemBuilder(tableAlias, "HANR004019", "", GetDefault(属性.数値)))                 '消費税計算区分
        item.Append("," & ItemBuilder(tableAlias, "HANR004020", "", GetDefault(属性.数値)))                 '消費税率
        item.Append("," & ItemBuilder(tableAlias, "HANR004021", "", GetDefault(属性.数値)))                 '伝票行数
        item.Append("," & ItemBuilder(tableAlias, "HANR004022", "", GetDefault(属性.文字)))                 '備考コード
        item.Append("," & ItemBuilder(tableAlias, "HANR004023", "", GetDefault(属性.文字)))                 '備考
        item.Append("," & ItemBuilder(tableAlias, "HANR004024", "", GetDefault(属性.数値)))                 '税込売上 売上額
        item.Append("," & ItemBuilder(tableAlias, "HANR004025", "", GetDefault(属性.数値)))                 '         値引額
        item.Append("," & ItemBuilder(tableAlias, "HANR004026", "", GetDefault(属性.数値)))                 '内消費税 売上額
        item.Append("," & ItemBuilder(tableAlias, "HANR004027", "", GetDefault(属性.数値)))                 '         値引額
        item.Append("," & ItemBuilder(tableAlias, "HANR004028", "", GetDefault(属性.数値)))                 '税抜売上 売上額
        item.Append("," & ItemBuilder(tableAlias, "HANR004029", "", GetDefault(属性.数値)))                 '         値引額
        item.Append("," & ItemBuilder(tableAlias, "HANR004030", "", GetDefault(属性.数値)))                 '非 課 税 売上額
        item.Append("," & ItemBuilder(tableAlias, "HANR004031", "", GetDefault(属性.数値)))                 '         値引額
        item.Append("," & ItemBuilder(tableAlias, "HANR004032", "", GetDefault(属性.数値)))                 '粗利額
        item.Append("," & ItemBuilder(tableAlias, "HANR004033", "", GetDefault(属性.数値)))                 '納入済　金額
        item.Append("," & ItemBuilder(tableAlias, "HANR004034", "", GetDefault(属性.数値)))                 '　　　　内消費税額
        item.Append("," & ItemBuilder(tableAlias, "HANR004035", "", GetDefault(属性.文字)))                 '手入力 得意先名１
        item.Append("," & ItemBuilder(tableAlias, "HANR004036", "", GetDefault(属性.文字)))                 '       得意先名２
        item.Append("," & ItemBuilder(tableAlias, "HANR004037", "", GetDefault(属性.文字)))                 '       納品先名
        item.Append("," & ItemBuilder(tableAlias, "HANR004038", "", GetDefault(属性.数値)))                 '受発注残区分
        item.Append("," & ItemBuilder(tableAlias, "HANR004039", "", GetDefault(属性.数値)))                 '関連売上伝票枚数
        item.Append("," & ItemBuilder(tableAlias, "HANR004040", "", GetDefault(属性.文字)))                 '通貨コード
        item.Append("," & ItemBuilder(tableAlias, "HANR004042", "", GetDefault(属性.数値)))                 'データ発生区分
        item.Append("," & ItemBuilder(tableAlias, "HANR004043", "", GetDefault(属性.数値)))                 '検収基準　入出荷残区分
        item.Append("," & ItemBuilder(tableAlias, "HANR004044", "", GetDefault(属性.数値)))                 '　　　　　関連出荷伝票枚数
        item.Append("," & ItemBuilder(tableAlias, "HANR004045", "", GetDefault(属性.数値)))                 '　　　　　計上区分
        item.Append("," & ItemBuilder(tableAlias, "HANR004046", "", GetDefault(属性.数値)))                 '出荷済　金額
        item.Append("," & ItemBuilder(tableAlias, "HANR004047", "", GetDefault(属性.数値)))                 '　　　　内消費税額
        item.Append("," & ItemBuilder(tableAlias, "HANR004048", "", GetDefault(属性.文字)))                 '営業所コード
        item.Append("," & ItemBuilder(tableAlias, "HANR004999", "", GetDefault(属性.数値)))                 '更新番号
        item.Append("," & ItemBuilder(tableAlias, "HANR004A001", "", GetDefault(属性.数値)))                 '受注区分
        item.Append("," & ItemBuilder(tableAlias, "HANR004A002", "", GetDefault(属性.数値)))                 '受注形態
        item.Append("," & ItemBuilder(tableAlias, "HANR004A003", "", GetDefault(属性.数値)))                 '見積枝番
        item.Append("," & ItemBuilder(tableAlias, "HANR004A004", "", GetDefault(属性.文字)))                 'プロジェクトメインコード
        item.Append("," & ItemBuilder(tableAlias, "HANR004A005", "", GetDefault(属性.文字)))                 'プロジェクトサブコード
        item.Append("," & ItemBuilder(tableAlias, "HANR004A006", "", GetDefault(属性.数値)))                 '製造納期
        item.Append("," & ItemBuilder(tableAlias, "HANR004A007", "", GetDefault(属性.文字)))                 '製番
        item.Append("," & ItemBuilder(tableAlias, "HANR004A008", "", GetDefault(属性.文字)))                 '製番メイン
        item.Append("," & ItemBuilder(tableAlias, "HANR004A009", "", GetDefault(属性.文字)))                 '製番枝番
        item.Append("," & ItemBuilder(tableAlias, "HANR004A010", "", GetDefault(属性.数値)))                 '発注区分
        item.Append("," & ItemBuilder(tableAlias, "HANR004A011", "", GetDefault(属性.数値)))                 '二社購買区分
        item.Append("," & ItemBuilder(tableAlias, "HANR004A012", "", GetDefault(属性.数値)))                 '完成品区分
        item.Append("," & ItemBuilder(tableAlias, "HANR004A013", "", GetDefault(属性.数値)))                 '注文書発行区分
        item.Append("," & ItemBuilder(tableAlias, "HANR004A014", "", GetDefault(属性.数値)))                 '差分注文書発行区分
        item.Append("," & ItemBuilder(tableAlias, "HANR004A015", "", GetDefault(属性.数値)))                 '注文書　番号
        item.Append("," & ItemBuilder(tableAlias, "HANR004A016", "", GetDefault(属性.数値)))                 '注文書区分
        item.Append("," & ItemBuilder(tableAlias, "HANR004A017", "", GetDefault(属性.数値)))                 '出力順番
        item.Append("," & ItemBuilder(tableAlias, "HANR004A018", "", GetDefault(属性.数値)))                 '納品書発行区分
        item.Append("," & ItemBuilder(tableAlias, "HANR004A019", "", GetDefault(属性.数値)))                 '差分納品書発行区分
        item.Append("," & ItemBuilder(tableAlias, "HANR004A020", "", GetDefault(属性.数値)))                 '支給（出庫）残区分
        item.Append("," & ItemBuilder(tableAlias, "HANR004A021", "", GetDefault(属性.数値)))                 '支給（出庫）回数
        item.Append("," & ItemBuilder(tableAlias, "HANR004S001", "", GetDefault(属性.文字)))             '備考コード２
        item.Append("," & ItemBuilder(tableAlias, "HANR004S002", "", GetDefault(属性.文字)))             '備考２

        Return item.ToString

    End Function

    Friend Function SelectItem受発注明細テーブル(Optional ByVal tableAlias As String = "") As String

        Dim item As New System.Text.StringBuilder

        item.Append(" " & ItemBuilder(tableAlias, "HANR005001", "", GetDefault(属性.数値)))                 '受発注日
        item.Append("," & ItemBuilder(tableAlias, "HANR005002", "", GetDefault(属性.数値)))                 '伝票区分
        item.Append("," & ItemBuilder(tableAlias, "HANR005003", "", GetDefault(属性.数値)))                 '受発注番号
        item.Append("," & ItemBuilder(tableAlias, "HANR005004", "", GetDefault(属性.数値)))                 '行番号
        item.Append("," & ItemBuilder(tableAlias, "HANR005005", "", GetDefault(属性.数値)))                 '取引先区分
        item.Append("," & ItemBuilder(tableAlias, "HANR005006", "", GetDefault(属性.文字)))                 '取引先コード
        item.Append("," & ItemBuilder(tableAlias, "HANR005007", "", GetDefault(属性.文字)))                 '担当者コード
        item.Append("," & ItemBuilder(tableAlias, "HANR005008", "", GetDefault(属性.数値)))                 '納期
        item.Append("," & ItemBuilder(tableAlias, "HANR005009", "", GetDefault(属性.数値)))                 '取引区分
        item.Append("," & ItemBuilder(tableAlias, "HANR005010", "", GetDefault(属性.数値)))                 '出荷予定日
        item.Append("," & ItemBuilder(tableAlias, "HANR005011", "", GetDefault(属性.数値)))                 '見積処理連番
        item.Append("," & ItemBuilder(tableAlias, "HANR005012", "", GetDefault(属性.数値)))                 '見積行番号
        item.Append("," & ItemBuilder(tableAlias, "HANR005013", "", GetDefault(属性.数値)))                 '相手受発注番号
        item.Append("," & ItemBuilder(tableAlias, "HANR005014", "", GetDefault(属性.数値)))                 '相手行番号  
        item.Append("," & ItemBuilder(tableAlias, "HANR005015", "", GetDefault(属性.文字)))                 '部門コード
        item.Append("," & ItemBuilder(tableAlias, "HANR005016", "", GetDefault(属性.文字)))                 '倉庫コード
        item.Append("," & ItemBuilder(tableAlias, "HANR005017", "", GetDefault(属性.文字)))                 '商品コード
        item.Append("," & ItemBuilder(tableAlias, "HANR005018", "", GetDefault(属性.文字)))                 '商品名
        item.Append("," & ItemBuilder(tableAlias, "HANR005019", "", GetDefault(属性.文字)))                 '在庫数量単位
        item.Append("," & ItemBuilder(tableAlias, "HANR005020", "", GetDefault(属性.数値)))                 '入数
        item.Append("," & ItemBuilder(tableAlias, "HANR005021", "", GetDefault(属性.数値)))                 '個数
        item.Append("," & ItemBuilder(tableAlias, "HANR005022", "", GetDefault(属性.文字)))                 '個数単位
        item.Append("," & ItemBuilder(tableAlias, "HANR005023", "", GetDefault(属性.数値)))                 '在庫数量
        item.Append("," & ItemBuilder(tableAlias, "HANR005024", "", GetDefault(属性.数値)))                 '単価
        item.Append("," & ItemBuilder(tableAlias, "HANR005025", "", GetDefault(属性.数値)))                 '金額
        item.Append("," & ItemBuilder(tableAlias, "HANR005026", "", GetDefault(属性.数値)))                 '原単価
        item.Append("," & ItemBuilder(tableAlias, "HANR005027", "", GetDefault(属性.数値)))                 '単価計算方法
        item.Append("," & ItemBuilder(tableAlias, "HANR005028", "", GetDefault(属性.数値)))                 '単価掛率
        item.Append("," & ItemBuilder(tableAlias, "HANR005029", "", GetDefault(属性.数値)))                 '標準売上単価
        item.Append("," & ItemBuilder(tableAlias, "HANR005030", "", GetDefault(属性.数値)))                 '標準仕入単価
        item.Append("," & ItemBuilder(tableAlias, "HANR005031", "", GetDefault(属性.数値)))                 '上代単価
        item.Append("," & ItemBuilder(tableAlias, "HANR005032", "", GetDefault(属性.数値)))                 '粗利額
        item.Append("," & ItemBuilder(tableAlias, "HANR005033", "", GetDefault(属性.数値)))                 '受発注金額内訳(税抜き)　受発注金額
        item.Append("," & ItemBuilder(tableAlias, "HANR005034", "", GetDefault(属性.数値)))                 '　　　　〃　　　　　　　値引金額
        item.Append("," & ItemBuilder(tableAlias, "HANR005035", "", GetDefault(属性.数値)))                 '課税区分
        item.Append("," & ItemBuilder(tableAlias, "HANR005036", "", GetDefault(属性.数値)))                 '消費税率
        item.Append("," & ItemBuilder(tableAlias, "HANR005037", "", GetDefault(属性.数値)))                 '内消費税額
        item.Append("," & ItemBuilder(tableAlias, "HANR005038", "", GetDefault(属性.数値)))                 '完納区分
        item.Append("," & ItemBuilder(tableAlias, "HANR005039", "", GetDefault(属性.文字)))                 '行摘要コード
        item.Append("," & ItemBuilder(tableAlias, "HANR005040", "", GetDefault(属性.文字)))                 '行摘要１
        item.Append("," & ItemBuilder(tableAlias, "HANR005041", "", GetDefault(属性.文字)))                 '行摘要２
        item.Append("," & ItemBuilder(tableAlias, "HANR005042", "", GetDefault(属性.数値)))                 '納入済数量
        item.Append("," & ItemBuilder(tableAlias, "HANR005043", "", GetDefault(属性.数値)))                 '　〃　金額
        item.Append("," & ItemBuilder(tableAlias, "HANR005044", "", GetDefault(属性.数値)))                 '　〃　内消費税額
        item.Append("," & ItemBuilder(tableAlias, "HANR005045", "", GetDefault(属性.数値)))                 '納入済金額内訳　売上
        item.Append("," & ItemBuilder(tableAlias, "HANR005046", "", GetDefault(属性.数値)))                 '　　　〃　　　　値引
        item.Append("," & ItemBuilder(tableAlias, "HANR005047", "", GetDefault(属性.数値)))                 '納入回数
        item.Append("," & ItemBuilder(tableAlias, "HANR005048", "", GetDefault(属性.数値)))                 '最終納入日
        item.Append("," & ItemBuilder(tableAlias, "HANR005049", "", GetDefault(属性.数値)))                 '関連伝票行数
        item.Append("," & ItemBuilder(tableAlias, "HANR005050", "", GetDefault(属性.数値)))                 '残区分
        item.Append("," & ItemBuilder(tableAlias, "HANR005051", "", GetDefault(属性.文字)))                 '通貨コード
        item.Append("," & ItemBuilder(tableAlias, "HANR005052", "", GetDefault(属性.数値)))                 '取引区分属性
        item.Append("," & ItemBuilder(tableAlias, "HANR005053", "", GetDefault(属性.数値)))                 '入出庫区分
        item.Append("," & ItemBuilder(tableAlias, "HANR005054", "", GetDefault(属性.数値)))                 '入出庫指示番号
        item.Append("," & ItemBuilder(tableAlias, "HANR005057", "", GetDefault(属性.数値)))                 'データ発生区分
        item.Append("," & ItemBuilder(tableAlias, "HANR005058", "", GetDefault(属性.数値)))                 '内訳コード１
        item.Append("," & ItemBuilder(tableAlias, "HANR005059", "", GetDefault(属性.数値)))                 '内訳コード２
        item.Append("," & ItemBuilder(tableAlias, "HANR005060", "", GetDefault(属性.数値)))                 '内訳コード３
        item.Append("," & ItemBuilder(tableAlias, "HANR005061", "", GetDefault(属性.数値)))                 '引当済数量
        item.Append("," & ItemBuilder(tableAlias, "HANR005062", "", GetDefault(属性.数値)))                 '引当出荷数量
        item.Append("," & ItemBuilder(tableAlias, "HANR005063", "", GetDefault(属性.数値)))                 '上代課税区分
        item.Append("," & ItemBuilder(tableAlias, "HANR005064", "", GetDefault(属性.数値)))                 '検収基準　出荷済数量
        item.Append("," & ItemBuilder(tableAlias, "HANR005065", "", GetDefault(属性.数値)))                 '　　　　〃　　　金額
        item.Append("," & ItemBuilder(tableAlias, "HANR005066", "", GetDefault(属性.数値)))                 '　　　　〃　　　内消費税額
        item.Append("," & ItemBuilder(tableAlias, "HANR005067", "", GetDefault(属性.数値)))                 '　　〃　　出荷済金額内訳　売上
        item.Append("," & ItemBuilder(tableAlias, "HANR005068", "", GetDefault(属性.数値)))                 '　　　　〃　　　　　　　　値引
        item.Append("," & ItemBuilder(tableAlias, "HANR005069", "", GetDefault(属性.数値)))                 '出荷回数
        item.Append("," & ItemBuilder(tableAlias, "HANR005070", "", GetDefault(属性.数値)))                 '最終出荷日
        item.Append("," & ItemBuilder(tableAlias, "HANR005071", "", GetDefault(属性.数値)))                 '関連出荷伝票行数
        item.Append("," & ItemBuilder(tableAlias, "HANR005072", "", GetDefault(属性.数値)))                 '入出荷残区分
        item.Append("," & ItemBuilder(tableAlias, "HANR005073", "", GetDefault(属性.数値)))                 '計上区分
        item.Append("," & ItemBuilder(tableAlias, "HANR005074", "", GetDefault(属性.数値)))                 '売掛区分
        item.Append("," & ItemBuilder(tableAlias, "HANR005075", "", GetDefault(属性.数値)))                 '原価金額
        item.Append("," & ItemBuilder(tableAlias, "HANR005076", "", GetDefault(属性.文字)))                 '営業所コード
        item.Append("," & ItemBuilder(tableAlias, "HANR005077", "", GetDefault(属性.文字)))                 '拡張項目入力パターン№
        item.Append("," & ItemBuilder(tableAlias, "HANR005078", "", GetDefault(属性.数値)))                 '受発注残　受発注残金額
        item.Append("," & ItemBuilder(tableAlias, "HANR005079", "", GetDefault(属性.数値)))                 '　 〃 　　税抜受発注残金額
        item.Append("," & ItemBuilder(tableAlias, "HANR005080", "", GetDefault(属性.数値)))                 '　 〃 　　税抜受発注残金額(値引)
        item.Append("," & ItemBuilder(tableAlias, "HANR005081", "", GetDefault(属性.数値)))                 '　 〃 　　内消費税
        item.Append("," & ItemBuilder(tableAlias, "HANR005082", "", GetDefault(属性.数値)))                 '入出荷残　受発注残金額
        item.Append("," & ItemBuilder(tableAlias, "HANR005083", "", GetDefault(属性.数値)))                 '　 〃 　　税抜受発注残金額
        item.Append("," & ItemBuilder(tableAlias, "HANR005084", "", GetDefault(属性.数値)))                 '　 〃 　　税抜受発注残金額(値引)
        item.Append("," & ItemBuilder(tableAlias, "HANR005085", "", GetDefault(属性.数値)))                 '　 〃 　　内消費税
        item.Append("," & ItemBuilder(tableAlias, "HANR005999", "", GetDefault(属性.数値)))                 '更新番号
        item.Append("," & ItemBuilder(tableAlias, "HANR005A001", "", GetDefault(属性.文字)))                '品目名1
        item.Append("," & ItemBuilder(tableAlias, "HANR005A002", "", GetDefault(属性.文字)))                '品目名2
        item.Append("," & ItemBuilder(tableAlias, "HANR005A003", "", GetDefault(属性.文字)))                '品目名3
        item.Append("," & ItemBuilder(tableAlias, "HANR005A004", "", GetDefault(属性.文字)))                '製　番
        item.Append("," & ItemBuilder(tableAlias, "HANR005A005", "", GetDefault(属性.文字)))                '製番（メイン）
        item.Append("," & ItemBuilder(tableAlias, "HANR005A006", "", GetDefault(属性.文字)))                '製番（枝番）
        item.Append("," & ItemBuilder(tableAlias, "HANR005A007", "", GetDefault(属性.数値)))                '当初納期
        item.Append("," & ItemBuilder(tableAlias, "HANR005A008", "", GetDefault(属性.数値)))                '当初製造納期
        item.Append("," & ItemBuilder(tableAlias, "HANR005A009", "", GetDefault(属性.数値)))                '当初出荷予定日
        item.Append("," & ItemBuilder(tableAlias, "HANR005A010", "", GetDefault(属性.数値)))                '見積枝番
        item.Append("," & ItemBuilder(tableAlias, "HANR005A011", "", GetDefault(属性.文字)))                '客先注番
        item.Append("," & ItemBuilder(tableAlias, "HANR005A012", "", GetDefault(属性.数値)))                '製造納期日
        item.Append("," & ItemBuilder(tableAlias, "HANR005A013", "", GetDefault(属性.数値)))                '在庫引当区分
        item.Append("," & ItemBuilder(tableAlias, "HANR005A014", "", GetDefault(属性.数値)))                '製造数量
        item.Append("," & ItemBuilder(tableAlias, "HANR005A015", "", GetDefault(属性.数値)))                '手配区分
        item.Append("," & ItemBuilder(tableAlias, "HANR005A016", "", GetDefault(属性.数値)))                '手配属性
        item.Append("," & ItemBuilder(tableAlias, "HANR005A017", "", GetDefault(属性.数値)))                '手配区分名
        item.Append("," & ItemBuilder(tableAlias, "HANR005A018", "", GetDefault(属性.数値)))                'リードタイム
        item.Append("," & ItemBuilder(tableAlias, "HANR005A019", "", GetDefault(属性.数値)))                '検査方法
        item.Append("," & ItemBuilder(tableAlias, "HANR005A020", "", GetDefault(属性.数値)))                '発注区分
        item.Append("," & ItemBuilder(tableAlias, "HANR005A021", "", GetDefault(属性.数値)))                '子部品引当区分
        item.Append("," & ItemBuilder(tableAlias, "HANR005A022", "", GetDefault(属性.文字)))                '工程コード
        item.Append("," & ItemBuilder(tableAlias, "HANR005A023", "", GetDefault(属性.数値)))                '発注数量
        item.Append("," & ItemBuilder(tableAlias, "HANR005A024", "", GetDefault(属性.文字)))                '発注単位
        item.Append("," & ItemBuilder(tableAlias, "HANR005A025", "", GetDefault(属性.数値)))                '発注単位変換係数
        item.Append("," & ItemBuilder(tableAlias, "HANR005A026", "", GetDefault(属性.数値)))                '発注確定情報
        item.Append("," & ItemBuilder(tableAlias, "HANR005A027", "", GetDefault(属性.数値)))                '手配番号
        item.Append("," & ItemBuilder(tableAlias, "HANR005A028", "", GetDefault(属性.数値)))                '手配管理番号
        item.Append("," & ItemBuilder(tableAlias, "HANR005A029", "", GetDefault(属性.数値)))                '発注予定日
        item.Append("," & ItemBuilder(tableAlias, "HANR005A030", "", GetDefault(属性.数値)))                '仮単価区分
        item.Append("," & ItemBuilder(tableAlias, "HANR005A031", "", GetDefault(属性.数値)))                '受注形態
        item.Append("," & ItemBuilder(tableAlias, "HANR005A032", "", GetDefault(属性.数値)))                '直送区分
        item.Append("," & ItemBuilder(tableAlias, "HANR005A033", "", GetDefault(属性.数値)))                '個別発注連番
        item.Append("," & ItemBuilder(tableAlias, "HANR005A034", "", GetDefault(属性.数値)))                '受入数量
        item.Append("," & ItemBuilder(tableAlias, "HANR005A035", "", GetDefault(属性.数値)))                '入荷済数量
        item.Append("," & ItemBuilder(tableAlias, "HANR005A036", "", GetDefault(属性.文字)))                '費目コード
        item.Append("," & ItemBuilder(tableAlias, "HANR005A037", "", GetDefault(属性.数値)))                '費目区分
        item.Append("," & ItemBuilder(tableAlias, "HANR005A038", "", GetDefault(属性.文字)))                '品目連番
        item.Append("," & ItemBuilder(tableAlias, "HANR005S001", "", GetDefault(属性.文字)))                '原価計上整番   

        Return item.ToString

    End Function

    Friend Function SelectItem明細拡張テーブル(Optional ByVal tableAlias As String = "") As String

        Dim item As New System.Text.StringBuilder

        item.Append(" " & ItemBuilder(tableAlias, "HANR030006", "", GetDefault(属性.数値)))                 '付箋色番号
        item.Append("," & ItemBuilder(tableAlias, "HANR030007", "", GetDefault(属性.文字)))                 '拡張項目１
        item.Append("," & ItemBuilder(tableAlias, "HANR030008", "", GetDefault(属性.文字)))                 '拡張項目２
        item.Append("," & ItemBuilder(tableAlias, "HANR030009", "", GetDefault(属性.文字)))                 '拡張項目３
        item.Append("," & ItemBuilder(tableAlias, "HANR030010", "", GetDefault(属性.文字)))                 '拡張項目４
        item.Append("," & ItemBuilder(tableAlias, "HANR030011", "", GetDefault(属性.文字)))                 '拡張項目５
        item.Append("," & ItemBuilder(tableAlias, "HANR030012", "", GetDefault(属性.文字)))                 '拡張項目６
        item.Append("," & ItemBuilder(tableAlias, "HANR030013", "", GetDefault(属性.文字)))                 '拡張項目７
        item.Append("," & ItemBuilder(tableAlias, "HANR030014", "", GetDefault(属性.文字)))                 '拡張項目８
        item.Append("," & ItemBuilder(tableAlias, "HANR030015", "", GetDefault(属性.文字)))                 '拡張項目９
        item.Append("," & ItemBuilder(tableAlias, "HANR030016", "", GetDefault(属性.文字)))                 '拡張項目１０
        item.Append("," & ItemBuilder(tableAlias, "HANR030017", "", GetDefault(属性.文字)))                 '拡張項目１１
        item.Append("," & ItemBuilder(tableAlias, "HANR030018", "", GetDefault(属性.文字)))                 '拡張項目１２
        item.Append("," & ItemBuilder(tableAlias, "HANR030019", "", GetDefault(属性.文字)))                 '拡張項目１３
        item.Append("," & ItemBuilder(tableAlias, "HANR030020", "", GetDefault(属性.文字)))                 '拡張項目１４
        item.Append("," & ItemBuilder(tableAlias, "HANR030021", "", GetDefault(属性.文字)))                 '拡張項目１５
        item.Append("," & ItemBuilder(tableAlias, "HANR030022", "", GetDefault(属性.文字)))                 '拡張項目１６
        item.Append("," & ItemBuilder(tableAlias, "HANR030023", "", GetDefault(属性.文字)))                 '拡張項目１７
        item.Append("," & ItemBuilder(tableAlias, "HANR030024", "", GetDefault(属性.文字)))                 '拡張項目１８
        item.Append("," & ItemBuilder(tableAlias, "HANR030025", "", GetDefault(属性.文字)))                 '拡張項目１９
        item.Append("," & ItemBuilder(tableAlias, "HANR030026", "", GetDefault(属性.文字)))                 '拡張項目２０

        Return item.ToString

    End Function

    ''' <summary>
    ''' 仕入先マスター取得列名定義
    ''' </summary>
    ''' <param name="tableAlias"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function SelectItem仕入先マスター(Optional ByVal tableAlias As String = "") As String

        Dim item As New System.Text.StringBuilder

        item.Append(" " & ItemBuilder(tableAlias, "HANM002001", "", GetDefault(属性.文字)))                 '支払先コード
        item.Append("," & ItemBuilder(tableAlias, "HANM002002", "", GetDefault(属性.数値)))                 '支払先区分
        item.Append("," & ItemBuilder(tableAlias, "HANM002003", "", GetDefault(属性.文字)))                 '仕入先コード
        item.Append("," & ItemBuilder(tableAlias, "HANM002004", "", GetDefault(属性.文字)))                 '仕入先名１
        item.Append("," & ItemBuilder(tableAlias, "HANM002005", "", GetDefault(属性.文字)))                 '仕入先名２
        item.Append("," & ItemBuilder(tableAlias, "HANM002006", "", GetDefault(属性.文字)))                 '仕入先略称
        item.Append("," & ItemBuilder(tableAlias, "HANM002008", "", GetDefault(属性.数値)))                 '郵便番号         'A-20110511_Ver7.40_2
        item.Append("," & ItemBuilder(tableAlias, "HANM002009", "", GetDefault(属性.文字)))                 '住所１
        item.Append("," & ItemBuilder(tableAlias, "HANM002010", "", GetDefault(属性.文字)))                 '住所２
        item.Append("," & ItemBuilder(tableAlias, "HANM002011", "", GetDefault(属性.文字)))                 '住所３
        item.Append("," & ItemBuilder(tableAlias, "HANM002012", "", GetDefault(属性.文字)))                 '電話番号
        item.Append("," & ItemBuilder(tableAlias, "HANM002013", "", GetDefault(属性.文字)))                 'FAX番号
        item.Append("," & ItemBuilder(tableAlias, "HANM002014", "", GetDefault(属性.文字)))                 'カスタマバーコード
        item.Append("," & ItemBuilder(tableAlias, "HANM002015", "", GetDefault(属性.文字)))                 '仕入担当者コード
        item.Append("," & ItemBuilder(tableAlias, "HANM002016", "", GetDefault(属性.文字)))                 '分類コード１
        item.Append("," & ItemBuilder(tableAlias, "HANM002017", "", GetDefault(属性.文字)))                 '    〃    ２
        item.Append("," & ItemBuilder(tableAlias, "HANM002018", "", GetDefault(属性.文字)))                 '    〃    ３
        item.Append("," & ItemBuilder(tableAlias, "HANM002019", "", GetDefault(属性.文字)))                 '    〃    ４
        item.Append("," & ItemBuilder(tableAlias, "HANM002020", "", GetDefault(属性.文字)))                 '    〃    ５
        item.Append("," & ItemBuilder(tableAlias, "HANM002021", "", GetDefault(属性.文字)))                 '    〃    ６
        item.Append("," & ItemBuilder(tableAlias, "HANM002022", "", GetDefault(属性.文字)))                 '    〃    ７
        item.Append("," & ItemBuilder(tableAlias, "HANM002023", "", GetDefault(属性.文字)))                 '    〃    ８
        item.Append("," & ItemBuilder(tableAlias, "HANM002024", "", GetDefault(属性.文字)))                 '    〃    ９
        item.Append("," & ItemBuilder(tableAlias, "HANM002025", "", GetDefault(属性.文字)))                 '    〃    10
        item.Append("," & ItemBuilder(tableAlias, "HANM002039", "", GetDefault(属性.数値)))                 '掛率計算区分
        item.Append("," & ItemBuilder(tableAlias, "HANM002040", "", GetDefault(属性.数値)))                 '単価掛率
        item.Append("," & ItemBuilder(tableAlias, "HANM002041", "", GetDefault(属性.数値)))                 '端数処理 単価       処理区分
        item.Append("," & ItemBuilder(tableAlias, "HANM002042", "", GetDefault(属性.数値)))                 '   〃    単価       処理単位
        item.Append("," & ItemBuilder(tableAlias, "HANM002043", "", GetDefault(属性.数値)))                 '   〃    金額       処理区分
        item.Append("," & ItemBuilder(tableAlias, "HANM002044", "", GetDefault(属性.数値)))                 '   〃    消費税計算 処理区分
        item.Append("," & ItemBuilder(tableAlias, "HANM002045", "", GetDefault(属性.数値)))                 '   〃    消費税計算 処理単位
        item.Append("," & ItemBuilder(tableAlias, "HANM002046", "", GetDefault(属性.数値)))                 '   〃    消費税分解 処理区分
        item.Append("," & ItemBuilder(tableAlias, "HANM002048", "", GetDefault(属性.数値)))                 '免税区分
        item.Append("," & ItemBuilder(tableAlias, "HANM002049", "", GetDefault(属性.数値)))                 '仕入単価設定区分
        item.Append("," & ItemBuilder(tableAlias, "HANM002050", "", GetDefault(属性.数値)))
        item.Append("," & ItemBuilder(tableAlias, "HANM002052", "", GetDefault(属性.数値)))                 '直前単価優先表示
        item.Append("," & ItemBuilder(tableAlias, "HANM002053", "", GetDefault(属性.数値)))                 '日付印字区分
        item.Append("," & ItemBuilder(tableAlias, "HANM002057", "", GetDefault(属性.文字)))                 '相手先担当者名
        item.Append("," & ItemBuilder(tableAlias, "HANM002062", "", GetDefault(属性.数値)))                 '消費税総額 上代単価設定区分
        item.Append("," & ItemBuilder(tableAlias, "HANM002063", "", GetDefault(属性.数値)))                 '    〃     単価変換区分
        item.Append("," & ItemBuilder(tableAlias, "HANM002064", "", GetDefault(属性.数値)))                 '計上区分               'A-20090818_1
        item.Append("," & ItemBuilder(tableAlias, "HANM002065", "", GetDefault(属性.数値)))                 '取引区分
        item.Append("," & ItemBuilder(tableAlias, "HANM002066", "", GetDefault(属性.文字)))                 '自社名－注文書             
        item.Append("," & ItemBuilder(tableAlias, "HANM002083", "", GetDefault(属性.数値)))                 '注文書出力区分         'A-2008/08/18_1
        item.Append("," & ItemBuilder(tableAlias, "HANM002084", "", GetDefault(属性.数値)))                 '個別設定入力行数
        item.Append("," & ItemBuilder(tableAlias, "HANM002085", "", GetDefault(属性.文字)))                 '営業所コード
        item.Append("," & ItemBuilder(tableAlias, "HANM002089", "", GetDefault(属性.数値)))                 '入力処理モード初期値
        item.Append("," & ItemBuilder(tableAlias, "HANM002087", "", GetDefault(属性.数値)))                 '商品変換コード注文書出力   
        item.Append("," & ItemBuilder(tableAlias, "HANM002A002", "", GetDefault(属性.数値)))                 '注文書タイプ           'A-20110511_Ver7.40_2
        'If _my販売コントロール情報.拡張項目 = True AndAlso _
        '   _my販売コントロール情報.拡張項目入力処理画面表示 = True Then
        '    item.Append("," & ItemBuilder(tableAlias, "HANM002K001", "", GetDefault(属性.文字)))            '拡張項目１
        '    item.Append("," & ItemBuilder(tableAlias, "HANM002K002", "", GetDefault(属性.文字)))            '拡張項目２
        '    item.Append("," & ItemBuilder(tableAlias, "HANM002K003", "", GetDefault(属性.文字)))            '拡張項目３
        '    item.Append("," & ItemBuilder(tableAlias, "HANM002K004", "", GetDefault(属性.文字)))            '拡張項目４
        '    item.Append("," & ItemBuilder(tableAlias, "HANM002K005", "", GetDefault(属性.文字)))            '拡張項目５
        '    item.Append("," & ItemBuilder(tableAlias, "HANM002K006", "", GetDefault(属性.文字)))            '拡張項目６
        '    item.Append("," & ItemBuilder(tableAlias, "HANM002K007", "", GetDefault(属性.文字)))            '拡張項目７
        '    item.Append("," & ItemBuilder(tableAlias, "HANM002K008", "", GetDefault(属性.文字)))            '拡張項目８
        '    item.Append("," & ItemBuilder(tableAlias, "HANM002K009", "", GetDefault(属性.文字)))            '拡張項目９
        '    item.Append("," & ItemBuilder(tableAlias, "HANM002K010", "", GetDefault(属性.文字)))            '拡張項目１０
        '    item.Append("," & ItemBuilder(tableAlias, "HANM002K011", "", GetDefault(属性.文字)))            '拡張項目１１
        '    item.Append("," & ItemBuilder(tableAlias, "HANM002K012", "", GetDefault(属性.文字)))            '拡張項目１２
        '    item.Append("," & ItemBuilder(tableAlias, "HANM002K013", "", GetDefault(属性.文字)))            '拡張項目１３
        '    item.Append("," & ItemBuilder(tableAlias, "HANM002K014", "", GetDefault(属性.文字)))            '拡張項目１４
        '    item.Append("," & ItemBuilder(tableAlias, "HANM002K015", "", GetDefault(属性.文字)))            '拡張項目１５
        '    item.Append("," & ItemBuilder(tableAlias, "HANM002K016", "", GetDefault(属性.文字)))            '拡張項目１６
        '    item.Append("," & ItemBuilder(tableAlias, "HANM002K017", "", GetDefault(属性.文字)))            '拡張項目１７
        '    item.Append("," & ItemBuilder(tableAlias, "HANM002K018", "", GetDefault(属性.文字)))            '拡張項目１８
        '    item.Append("," & ItemBuilder(tableAlias, "HANM002K019", "", GetDefault(属性.文字)))            '拡張項目１９
        '    item.Append("," & ItemBuilder(tableAlias, "HANM002K020", "", GetDefault(属性.文字)))            '拡張項目２０
        '    item.Append("," & ItemBuilder(tableAlias, "HANM002K999", "", GetDefault(属性.数値)))            '付箋色番号
        'End If

        Return item.ToString

    End Function

    Friend Function SelectItem商品マスター(Optional ByVal tableAlias As String = "") As String

        Dim item As New System.Text.StringBuilder

        item.Append(" " & ItemBuilder(tableAlias, "HANM003001", "", GetDefault(属性.文字)))                 '商品コード
        item.Append("," & ItemBuilder(tableAlias, "HANM003002", "", GetDefault(属性.文字)))                 '商品名
        item.Append("," & ItemBuilder(tableAlias, "HANM003004", "", GetDefault(属性.文字)))                 '単位
        item.Append("," & ItemBuilder(tableAlias, "HANM003005", "", GetDefault(属性.文字)))                 '個数単位
        item.Append("," & ItemBuilder(tableAlias, "HANM003006", "", GetDefault(属性.数値)))                 '入数
        item.Append("," & ItemBuilder(tableAlias, "HANM003008", "", GetDefault(属性.数値)))                 '在庫管理区分
        item.Append("," & ItemBuilder(tableAlias, "HANM003009", "", GetDefault(属性.数値)))                 '標準売上単価
        item.Append("," & ItemBuilder(tableAlias, "HANM003010", "", GetDefault(属性.数値)))                 'ランク１単価
        item.Append("," & ItemBuilder(tableAlias, "HANM003011", "", GetDefault(属性.数値)))                 'ランク２単価
        item.Append("," & ItemBuilder(tableAlias, "HANM003012", "", GetDefault(属性.数値)))                 'ランク３単価
        item.Append("," & ItemBuilder(tableAlias, "HANM003013", "", GetDefault(属性.数値)))                 'ランク４単価
        item.Append("," & ItemBuilder(tableAlias, "HANM003014", "", GetDefault(属性.数値)))                 'ランク５単価
        item.Append("," & ItemBuilder(tableAlias, "HANM003015", "", GetDefault(属性.数値)))                 '標準仕入単価
        item.Append("," & ItemBuilder(tableAlias, "HANM003016", "", GetDefault(属性.数値)))                 '在庫評価単価
        item.Append("," & ItemBuilder(tableAlias, "HANM003017", "", GetDefault(属性.数値)))                 '粗利算出用原単価
        item.Append("," & ItemBuilder(tableAlias, "HANM003018", "", GetDefault(属性.数値)))                 '上代単価
        item.Append("," & ItemBuilder(tableAlias, "HANM003019", "", GetDefault(属性.文字)))                 '分類コード０
        item.Append("," & ItemBuilder(tableAlias, "HANM003020", "", GetDefault(属性.文字)))                 '    〃    １
        item.Append("," & ItemBuilder(tableAlias, "HANM003021", "", GetDefault(属性.文字)))                 '    〃    ２
        item.Append("," & ItemBuilder(tableAlias, "HANM003022", "", GetDefault(属性.文字)))                 '    〃    ３
        item.Append("," & ItemBuilder(tableAlias, "HANM003023", "", GetDefault(属性.文字)))                 '    〃    ４
        item.Append("," & ItemBuilder(tableAlias, "HANM003024", "", GetDefault(属性.文字)))                 '    〃    ５
        item.Append("," & ItemBuilder(tableAlias, "HANM003025", "", GetDefault(属性.文字)))                 '    〃    ６
        item.Append("," & ItemBuilder(tableAlias, "HANM003026", "", GetDefault(属性.文字)))                 '    〃    ７
        item.Append("," & ItemBuilder(tableAlias, "HANM003027", "", GetDefault(属性.文字)))                 '    〃    ８
        item.Append("," & ItemBuilder(tableAlias, "HANM003028", "", GetDefault(属性.文字)))                 '    〃    ９
        item.Append("," & ItemBuilder(tableAlias, "HANM003029", "", GetDefault(属性.数値)))                 '変更後単価 標準売上単価
        item.Append("," & ItemBuilder(tableAlias, "HANM003030", "", GetDefault(属性.数値)))                 '    〃     ランク１単価
        item.Append("," & ItemBuilder(tableAlias, "HANM003031", "", GetDefault(属性.数値)))                 '    〃     ランク２単価
        item.Append("," & ItemBuilder(tableAlias, "HANM003032", "", GetDefault(属性.数値)))                 '    〃     ランク３単価
        item.Append("," & ItemBuilder(tableAlias, "HANM003033", "", GetDefault(属性.数値)))                 '    〃     ランク４単価
        item.Append("," & ItemBuilder(tableAlias, "HANM003034", "", GetDefault(属性.数値)))                 '    〃     ランク５単価
        item.Append("," & ItemBuilder(tableAlias, "HANM003035", "", GetDefault(属性.数値)))                 '    〃     標準仕入単価
        item.Append("," & ItemBuilder(tableAlias, "HANM003036", "", GetDefault(属性.数値)))                 '    〃     在庫評価単価
        item.Append("," & ItemBuilder(tableAlias, "HANM003037", "", GetDefault(属性.数値)))                 '    〃     粗利算出用原単価
        item.Append("," & ItemBuilder(tableAlias, "HANM003038", "", GetDefault(属性.数値)))                 '    〃     上代単価
        item.Append("," & ItemBuilder(tableAlias, "HANM003039", "", GetDefault(属性.数値)))                 '単価変更日付
        item.Append("," & ItemBuilder(tableAlias, "HANM003040", "", GetDefault(属性.数値)))                 '期間単価対象日付
        item.Append("," & ItemBuilder(tableAlias, "HANM003041", "", GetDefault(属性.数値)))                 '変更後単価使用区分
        item.Append("," & ItemBuilder(tableAlias, "HANM003042", "", GetDefault(属性.数値)))                 '消費税 非課税区分
        item.Append("," & ItemBuilder(tableAlias, "HANM003043", "", GetDefault(属性.数値)))                 '  〃   売上単価設定区分
        item.Append("," & ItemBuilder(tableAlias, "HANM003044", "", GetDefault(属性.数値)))                 '  〃   仕入単価設定区分
        item.Append("," & ItemBuilder(tableAlias, "HANM003045", "", GetDefault(属性.数値)))                 '  〃   消費税率区分
        item.Append("," & ItemBuilder(tableAlias, "HANM003055", "", GetDefault(属性.数値)))                 '消費税総額 上代単価設定区分
        item.Append("," & ItemBuilder(tableAlias, "HANM003056", "", GetDefault(属性.数値)))                 '    〃     変更後売上単価設定区分
        item.Append("," & ItemBuilder(tableAlias, "HANM003057", "", GetDefault(属性.数値)))                 '    〃       〃  仕入単価設定区分
        item.Append("," & ItemBuilder(tableAlias, "HANM003058", "", GetDefault(属性.数値)))                 '    〃       〃  上代単価設定区分
        item.Append("," & ItemBuilder(tableAlias, "HANM003059", "", GetDefault(属性.数値)))                 '    〃     売上単価税込変換計算区分
        item.Append("," & ItemBuilder(tableAlias, "HANM003060", "", GetDefault(属性.数値)))                 '    〃       〃         〃     単位
        item.Append("," & ItemBuilder(tableAlias, "HANM003061", "", GetDefault(属性.数値)))                 '    〃       〃    税抜変換計算区分
        item.Append("," & ItemBuilder(tableAlias, "HANM003062", "", GetDefault(属性.数値)))                 '    〃       〃         〃     単位
        item.Append("," & ItemBuilder(tableAlias, "HANM003063", "", GetDefault(属性.数値)))                 '    〃     仕入単価税込変換計算区分
        item.Append("," & ItemBuilder(tableAlias, "HANM003064", "", GetDefault(属性.数値)))                 '    〃       〃         〃     単位
        item.Append("," & ItemBuilder(tableAlias, "HANM003065", "", GetDefault(属性.数値)))                 '    〃       〃    税抜変換計算区分
        item.Append("," & ItemBuilder(tableAlias, "HANM003066", "", GetDefault(属性.数値)))                 '    〃       〃         〃     単位
        item.Append("," & ItemBuilder(tableAlias, "HANM003067", "", GetDefault(属性.数値)))                 '    〃     上代単価税込変換計算区分
        item.Append("," & ItemBuilder(tableAlias, "HANM003068", "", GetDefault(属性.数値)))                 '    〃       〃         〃     単位
        item.Append("," & ItemBuilder(tableAlias, "HANM003069", "", GetDefault(属性.数値)))                 '    〃       〃    税抜変換計算区分
        item.Append("," & ItemBuilder(tableAlias, "HANM003070", "", GetDefault(属性.数値)))                 '    〃       〃         〃     単位
        item.Append("," & ItemBuilder(tableAlias, "HANM003075", "", GetDefault(属性.数値)))                 '在庫評価区分
        item.Append("," & ItemBuilder(tableAlias, "HANM003A002", "", GetDefault(属性.数値)))                 '累積リードタイム      'A-20110511_Ver7.40
        item.Append("," & ItemBuilder(tableAlias, "HANM003A005", "", GetDefault(属性.数値)))                 '手配方式              'A-20110511_Ver7.40
        item.Append("," & ItemBuilder(tableAlias, "HANM003A006", "", GetDefault(属性.数値)))                 '発注点手配            'A-20110511_Ver7.40
        item.Append("," & ItemBuilder(tableAlias, "HANM003A012", "", GetDefault(属性.数値)))                 '猶予期間              'A-20110511_Ver7.40
        item.Append("," & ItemBuilder(tableAlias, "HANM003A010", "", GetDefault(属性.文字)))                 '基準倉庫コード
        item.Append("," & ItemBuilder(tableAlias, "HANM003A011", "", GetDefault(属性.数値)))                 '購買リードタイム
        item.Append("," & ItemBuilder(tableAlias, "HANM003A014", "", GetDefault(属性.文字)))                 '正式名称１
        item.Append("," & ItemBuilder(tableAlias, "HANM003A015", "", GetDefault(属性.文字)))                 '正式名称２
        item.Append("," & ItemBuilder(tableAlias, "HANM003A016", "", GetDefault(属性.文字)))                 '正式名称３
        item.Append("," & ItemBuilder(tableAlias, "HANM003A017", "", GetDefault(属性.数値)))                 '在庫引当区分          'A-20110511_Ver7.40
        item.Append("," & ItemBuilder(tableAlias, "HANM003A018", "", GetDefault(属性.数値)))                 '二社購買区分
        item.Append("," & ItemBuilder(tableAlias, "HANM003A019", "", GetDefault(属性.数値)))                 '検査方法
        item.Append("," & ItemBuilder(tableAlias, "HANM003A020", "", GetDefault(属性.文字)))                 '備考コード
        item.Append("," & ItemBuilder(tableAlias, "HANM003A021", "", GetDefault(属性.文字)))                 '備考内容
        item.Append("," & ItemBuilder(tableAlias, "HANM003A024", "", GetDefault(属性.数値)))                 'ロット管理区分        'A-20110511_Ver7.40_2
        item.Append("," & ItemBuilder(tableAlias, "HANM003A025", "", GetDefault(属性.文字)))                 '発注単位
        item.Append("," & ItemBuilder(tableAlias, "HANM003A026", "", GetDefault(属性.数値)))                 '発注単位変換係数
        item.Append("," & ItemBuilder(tableAlias, "HANM003A027", "", GetDefault(属性.文字)))                 '基準ロケーション      'A-20110511_Ver7.40_2
        item.Append("," & ItemBuilder(tableAlias, "HANM003A028", "", GetDefault(属性.数値)))                 '品目区分
        item.Append("," & ItemBuilder(tableAlias, "HANM003A029", "", GetDefault(属性.数値)))                 '使用禁止日
        item.Append("," & ItemBuilder(tableAlias, "HANM003A035", "", GetDefault(属性.文字)))                 '費目コード
        item.Append("," & ItemBuilder(tableAlias, "HANM003S001", "", GetDefault(属性.文字)))                 '備考コード２
        item.Append("," & ItemBuilder(tableAlias, "HANM003S002", "", GetDefault(属性.文字)))                 '備考内容２
        'If _my販売コントロール情報.拡張項目 = True AndAlso _
        '   _my販売コントロール情報.拡張項目入力処理画面表示 = True Then
        '    item.Append("," & ItemBuilder(tableAlias, "HANM003077", "", GetDefault(属性.文字)))             'パターン№(仕入)
        '    item.Append("," & ItemBuilder(tableAlias, "HANM003K001", "", GetDefault(属性.文字)))            '拡張項目１
        '    item.Append("," & ItemBuilder(tableAlias, "HANM003K002", "", GetDefault(属性.文字)))            '拡張項目２
        '    item.Append("," & ItemBuilder(tableAlias, "HANM003K003", "", GetDefault(属性.文字)))            '拡張項目３
        '    item.Append("," & ItemBuilder(tableAlias, "HANM003K004", "", GetDefault(属性.文字)))            '拡張項目４
        '    item.Append("," & ItemBuilder(tableAlias, "HANM003K005", "", GetDefault(属性.文字)))            '拡張項目５
        '    item.Append("," & ItemBuilder(tableAlias, "HANM003K006", "", GetDefault(属性.文字)))            '拡張項目６
        '    item.Append("," & ItemBuilder(tableAlias, "HANM003K007", "", GetDefault(属性.文字)))            '拡張項目７
        '    item.Append("," & ItemBuilder(tableAlias, "HANM003K008", "", GetDefault(属性.文字)))            '拡張項目８
        '    item.Append("," & ItemBuilder(tableAlias, "HANM003K009", "", GetDefault(属性.文字)))            '拡張項目９
        '    item.Append("," & ItemBuilder(tableAlias, "HANM003K010", "", GetDefault(属性.文字)))            '拡張項目１０
        '    item.Append("," & ItemBuilder(tableAlias, "HANM003K011", "", GetDefault(属性.文字)))            '拡張項目１１
        '    item.Append("," & ItemBuilder(tableAlias, "HANM003K012", "", GetDefault(属性.文字)))            '拡張項目１２
        '    item.Append("," & ItemBuilder(tableAlias, "HANM003K013", "", GetDefault(属性.文字)))            '拡張項目１３
        '    item.Append("," & ItemBuilder(tableAlias, "HANM003K014", "", GetDefault(属性.文字)))            '拡張項目１４
        '    item.Append("," & ItemBuilder(tableAlias, "HANM003K015", "", GetDefault(属性.文字)))            '拡張項目１５
        '    item.Append("," & ItemBuilder(tableAlias, "HANM003K016", "", GetDefault(属性.文字)))            '拡張項目１６
        '    item.Append("," & ItemBuilder(tableAlias, "HANM003K017", "", GetDefault(属性.文字)))            '拡張項目１７
        '    item.Append("," & ItemBuilder(tableAlias, "HANM003K018", "", GetDefault(属性.文字)))            '拡張項目１８
        '    item.Append("," & ItemBuilder(tableAlias, "HANM003K019", "", GetDefault(属性.文字)))            '拡張項目１９
        '    item.Append("," & ItemBuilder(tableAlias, "HANM003K020", "", GetDefault(属性.文字)))            '拡張項目２０
        '    item.Append("," & ItemBuilder(tableAlias, "HANM003K999", "", GetDefault(属性.数値)))            '付箋色番号
        'End If

        Return item.ToString


    End Function

    Friend Function SelectItem倉庫マスター(Optional ByVal tableAlias As String = "") As String

        Dim item As New System.Text.StringBuilder

        item.Append(" " & ItemBuilder(tableAlias, "HANM006001", "", GetDefault(属性.文字)))                 '倉庫コード
        item.Append("," & ItemBuilder(tableAlias, "HANM006002", "", GetDefault(属性.文字)))                 '倉庫名
        item.Append("," & ItemBuilder(tableAlias, "HANM006004", "", GetDefault(属性.文字)))                 '倉庫略称
        'If _my販売コントロール情報.拡張項目 = True AndAlso _
        '   _my販売コントロール情報.拡張項目入力処理画面表示 = True Then
        '    item.Append("," & ItemBuilder(tableAlias, "HANM006K001", "", GetDefault(属性.文字)))            '拡張項目１
        '    item.Append("," & ItemBuilder(tableAlias, "HANM006K002", "", GetDefault(属性.文字)))            '拡張項目２
        '    item.Append("," & ItemBuilder(tableAlias, "HANM006K003", "", GetDefault(属性.文字)))            '拡張項目３
        '    item.Append("," & ItemBuilder(tableAlias, "HANM006K004", "", GetDefault(属性.文字)))            '拡張項目４
        '    item.Append("," & ItemBuilder(tableAlias, "HANM006K005", "", GetDefault(属性.文字)))            '拡張項目５
        '    item.Append("," & ItemBuilder(tableAlias, "HANM006K006", "", GetDefault(属性.文字)))            '拡張項目６
        '    item.Append("," & ItemBuilder(tableAlias, "HANM006K007", "", GetDefault(属性.文字)))            '拡張項目７
        '    item.Append("," & ItemBuilder(tableAlias, "HANM006K008", "", GetDefault(属性.文字)))            '拡張項目８
        '    item.Append("," & ItemBuilder(tableAlias, "HANM006K009", "", GetDefault(属性.文字)))            '拡張項目９
        '    item.Append("," & ItemBuilder(tableAlias, "HANM006K010", "", GetDefault(属性.文字)))            '拡張項目１０
        '    item.Append("," & ItemBuilder(tableAlias, "HANM006K011", "", GetDefault(属性.文字)))            '拡張項目１１
        '    item.Append("," & ItemBuilder(tableAlias, "HANM006K012", "", GetDefault(属性.文字)))            '拡張項目１２
        '    item.Append("," & ItemBuilder(tableAlias, "HANM006K013", "", GetDefault(属性.文字)))            '拡張項目１３
        '    item.Append("," & ItemBuilder(tableAlias, "HANM006K014", "", GetDefault(属性.文字)))            '拡張項目１４
        '    item.Append("," & ItemBuilder(tableAlias, "HANM006K015", "", GetDefault(属性.文字)))            '拡張項目１５
        '    item.Append("," & ItemBuilder(tableAlias, "HANM006K016", "", GetDefault(属性.文字)))            '拡張項目１６
        '    item.Append("," & ItemBuilder(tableAlias, "HANM006K017", "", GetDefault(属性.文字)))            '拡張項目１７
        '    item.Append("," & ItemBuilder(tableAlias, "HANM006K018", "", GetDefault(属性.文字)))            '拡張項目１８
        '    item.Append("," & ItemBuilder(tableAlias, "HANM006K019", "", GetDefault(属性.文字)))            '拡張項目１９
        '    item.Append("," & ItemBuilder(tableAlias, "HANM006K020", "", GetDefault(属性.文字)))            '拡張項目２０
        '    item.Append("," & ItemBuilder(tableAlias, "HANM006K999", "", GetDefault(属性.数値)))            '付箋色番号
        'End If

        Return item.ToString

    End Function

    ''' <summary>
    ''' 受発注ヘッダーテーブル取得列名定義
    ''' </summary>
    ''' <param name="tableAlias"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function SelectItem入出庫予定ヘッダーテーブル(Optional ByVal tableAlias As String = "") As String

        Dim item As New System.Text.StringBuilder

        item.Append(" " & ItemBuilder(tableAlias, "SEIRA02012", "", GetDefault(属性.文字)))                 '備考コード
        item.Append("," & ItemBuilder(tableAlias, "SEIRA02013", "", GetDefault(属性.文字)))                 '備考

        Return item.ToString

    End Function

    Friend Function SelectItem入出庫予定明細テーブル(Optional ByVal tableAlias As String = "") As String

        Dim item As New System.Text.StringBuilder

        item.Append(" " & ItemBuilder(tableAlias, "SEIRA03006", "", GetDefault(属性.数値)))                 '取引区分
        item.Append("," & ItemBuilder(tableAlias, "SEIRA03007", "", GetDefault(属性.文字)))                 '倉庫コード
        item.Append("," & ItemBuilder(tableAlias, "SEIRA03010", "", GetDefault(属性.数値)))                 '
        item.Append("," & ItemBuilder(tableAlias, "SEIRA03014", "", GetDefault(属性.文字)))                 '品目名１
        item.Append("," & ItemBuilder(tableAlias, "SEIRA03015", "", GetDefault(属性.文字)))                 '品目名２
        item.Append("," & ItemBuilder(tableAlias, "SEIRA03016", "", GetDefault(属性.文字)))                 '品目名３
        item.Append("," & ItemBuilder(tableAlias, "SEIRA03017", "", GetDefault(属性.文字)))                 '数量単位
        item.Append("," & ItemBuilder(tableAlias, "SEIRA03021", "", GetDefault(属性.文字)))                 '行摘要ｺｰﾄﾞ
        item.Append("," & ItemBuilder(tableAlias, "SEIRA03022", "", GetDefault(属性.文字)))                 '行摘要１
        item.Append("," & ItemBuilder(tableAlias, "SEIRA03023", "", GetDefault(属性.文字)))                 '行摘要２

        Return item.ToString

    End Function
#End Region

#Region "内部メソッド"

    ''' <summary>
    ''' 取得項目の組み立て
    ''' </summary>
    ''' <param name="tableAlias">対象テーブルの別名</param>
    ''' <param name="itemName">取得列名</param>
    ''' <param name="itemAlias">取得列名の別名</param>
    ''' <param name="itemDefault">NULL時の初期値</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ItemBuilder(
                                ByVal tableAlias As String,
                                ByVal itemName As String,
                                ByVal itemAlias As String,
                                ByVal itemDefault As String) As String

        Dim st As New System.Text.StringBuilder

        st.Append(QueryWrapper.AddIsNull)
        st.Append(" (")
        If Not String.IsNullOrEmpty(tableAlias) Then
            st.Append(tableAlias & ".")
        End If
        st.Append(itemName)
        st.Append(",")
        st.Append(itemDefault)
        st.Append(") ")
        If Not String.IsNullOrEmpty(itemAlias) Then
            st.Append(itemAlias)
        ElseIf Not String.IsNullOrEmpty(tableAlias) Then
            st.Append(tableAlias & "_" & itemName)
        Else
            st.Append(itemName)
        End If

        Return st.ToString
    End Function

    Private Enum 属性
        文字
        数値
    End Enum

    Private Function GetDefault(ByVal type As 属性) As String
        Dim st As String = ""

        Select Case type
            Case 属性.文字
                st = "' '"
            Case 属性.数値
                st = "0."   'A-2008/08/19_DB2
            Case Else
        End Select
        Return st

    End Function

#End Region

#Region "パラメータ"

    Private Const PARAMETER_MARKER As String = "?"

    Private Function GetParameter(ByVal targetType As ReadParam.項目名型,
                                  ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList) As String

        Dim newParameter As New OSK.X1.DataAccess.ParamInfo

        newParameter.Name = "Param" & CStr(paramInfo.Count)

        Select Case targetType
            Case ReadParam.項目名型.受発注番号
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 10
                    .Scale = 0
                    .Value = CDec(_readParam.Container(ReadParam.項目名型.受発注番号))
                End With

            Case ReadParam.項目名型.受発注行番号
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 3
                    .Scale = 0
                    .Value = CDec(_readParam.Container(ReadParam.項目名型.受発注行番号))
                End With

            Case ReadParam.項目名型.内訳NO
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 2
                    .Scale = 0
                    .Value = CDec(_readParam.Container(ReadParam.項目名型.内訳NO))
                End With

            Case ReadParam.項目名型.入庫予定番号
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 10
                    .Scale = 0
                    .Value = CDec(_readParam.Container(ReadParam.項目名型.入庫予定番号))
                End With

            Case ReadParam.項目名型.入庫予定行番号
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 3
                    .Scale = 0
                    .Value = CDec(_readParam.Container(ReadParam.項目名型.入庫予定行番号))
                End With

            Case ReadParam.項目名型.CA01KEY
                With newParameter
                    .Type = DbType.AnsiStringFixedLength
                    .Size = 20
                    .Value = CStr(_readParam.Container(ReadParam.項目名型.CA01KEY))
                End With

            Case ReadParam.項目名型.商品コード
                With newParameter
                    .Type = DbType.AnsiStringFixedLength
                    .Size = 25
                    .Value = CStr(_readParam.Container(ReadParam.項目名型.商品コード))
                End With

            Case Else
                Throw New System.Exception("paramTypeパラメータ不正")
        End Select

        paramInfo.Add(newParameter)

        Return PARAMETER_MARKER

    End Function

#End Region

End Class
'A-CUST20190830↑
