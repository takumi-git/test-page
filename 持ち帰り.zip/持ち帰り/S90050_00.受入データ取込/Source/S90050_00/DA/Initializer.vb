﻿''' <summary>
''' 初期処理実装部
''' </summary>
''' <remarks>FrameworkInitializerBaseを継承して下さい</remarks>
Public Class Initializer
    Inherits FrameworkInitializerBase

    Public Overrides Function Startup(ByVal connection As System.Data.Common.DbConnection,
                                      ByRef initInfo As System.Collections.IDictionary,
                                      ByRef resultMessage As String,
                                      ByRef checkInfo As Foundation.ExecuteCheck.IExecuteCheckInfo
                              ) As Foundation.Startup.IStarter.AccessResultType

        Dim result As Foundation.Startup.IStarter.AccessResultType = Foundation.Startup.IStarter.AccessResultType.成功

        '■排他チェック
        Dim executeForStartup As Foundation.ExecuteCheck.DataAccess.IExecuteControlerForStartup
        executeForStartup = New Foundation.ExecuteCheck.DataAccess.ExecuteControlerForStartup
        executeForStartup.Initialize(Me)
        If executeForStartup.CheckExecution(checkInfo) = Foundation.ExecuteCheck.DataAccess.ExecuteCheckResult.排他エラー Then
            Return Foundation.Startup.IStarter.AccessResultType.同時実行不可
        End If

        '■フレームワークの共通処理を実行
        result = MyBase.InitializeFramework(connection, initInfo, resultMessage, checkInfo)
        If result <> Foundation.Startup.IStarter.AccessResultType.成功 Then
            Return result
        End If

        '■基準コントロール情報取得
        Dim myコントロール情報 As New Myコントロール情報型      'A-2008/07/18_Ver7.30_SAIMU
        Dim biscontrolReader As BIS.LIB.ControlInfo.DataAccess.IBISControlReader = New BIS.LIB.ControlInfo.DataAccess.BISControlReader
        biscontrolReader.Initialize(Me)
        biscontrolReader.GetControlInfo(connection, initInfo, IBISControlReader.コントロール型.BISコントロールテーブル)
        '↓A-2008/07/18_Ver7.30_SAIMU
        Dim BIScontrolInfoGetter As BIS.LIB.ControlInfo.DataAccess.IBISControlInfoGetter = New BIS.LIB.ControlInfo.DataAccess.BISControlInfoGetter
        Dim controlInfoBISC001 As IDictionary = BIScontrolInfoGetter.GetControlInfo(initInfo, BIS.LIB.ControlInfo.DataAccess.IBISControlInfoGetter.コントロール型.BISコントロールテーブル)
        myコントロール情報.InitializeBISC001(controlInfoBISC001)
        '↑A-2008/07/18_Ver7.30_SAIMU

        '■販売コントロール情報取得と利用可能設定
        Dim controlInfoReader As SEI.LIB.ControlInfo.DataAccess.ISEIControlReader = New SEI.LIB.ControlInfo.DataAccess.SEIControlReader
        controlInfoReader.Initialize(Me)
        controlInfoReader.GetControlInfo(connection, initInfo, SEI.LIB.ControlInfo.DataAccess.ISEIControlReader.コントロール型.SEIコントロールテーブル)
        controlInfoReader.GetControlInfo(connection, initInfo, SEI.LIB.ControlInfo.DataAccess.ISEIControlReader.コントロール型.SEI分類種別管理テーブル)     'A-2008/07/18_Ver7.30_GENKA
        Dim controlInfoGetter As SEI.LIB.ControlInfo.DataAccess.ISEIControlInfoGetter = New SEI.LIB.ControlInfo.DataAccess.SEIControlInfoGetter
        Dim controlInfoC001 As IDictionary = controlInfoGetter.GetControlInfo(initInfo, SEI.LIB.ControlInfo.DataAccess.ISEIControlInfoGetter.コントロール型.SEIコントロールテーブル)
        'Dim myコントロール情報 As New Myコントロール情報型     'D-2008/07/18_Ver7.30_SAIMU
        myコントロール情報.InitializeC001(controlInfoC001)

        '↓A-2008/07/18_Ver7.30_SAIMU
        '■会計コントロール情報取得
        If myコントロール情報.販売財務連動区分 = 販売財務連動定義型.販売財務連動区分型.行う Then
            Dim controlGetter_Zai As IControlGetter_Zai
            controlGetter_Zai = OSK.X1.Foundation.GeneralFactory(Of IControlGetter_Zai).CreateInstance(Me, "OSK.X1.SEI.S90050_00.SUB1.DA", "ControlGetter_Zai")    'X1変換Tool-20170508
            controlGetter_Zai.Initialize(Me)
            controlGetter_Zai.Startup(connection, initInfo, myコントロール情報)
        End If
        '↑A-2008/07/18_Ver7.30_SAIMU

        '■項目名称設定情報取得
        Dim itemNameReader As CMN.LIB.ItemNameInfo.DataAccess.IItemNameReader
        itemNameReader = CMN.LIB.PartReplacement.CommonFactory.CreateInstance(Of CMN.LIB.ItemNameInfo.DataAccess.IItemNameReader)(Me, GetType(CMN.LIB.ItemNameInfo.DataAccess.ItemNameReader))
        itemNameReader.Initialize(Me)
        itemNameReader.GetItemNameInfo(connection, initInfo)

        '■仕入拡張項目有無の判定と取得
        Dim 仕入伝票拡張項目有無 As Boolean = False
        Dim 仕入明細拡張項目有無 As Boolean = False
        Dim 入荷伝票拡張項目有無 As Boolean = False
        Dim 入荷明細拡張項目有無 As Boolean = False

        If myコントロール情報.拡張項目 = SEI.LIB.ControlInfoC001.オプション区分定義型.区分型.行う Then
            Dim expandItemReader As SEI.LIB.ExpandItemControl.DataAccess.ISEIExpandItemReader
            expandItemReader = CMN.LIB.PartReplacement.CommonFactory.CreateInstance(Of SEI.LIB.ExpandItemControl.DataAccess.ISEIExpandItemReader)(Me, GetType(SEI.LIB.ExpandItemControl.DataAccess.SEIExpandItemReader))
            expandItemReader.Initialize(Me)
            Dim expandItemGetter As SEI.LIB.ExpandItemControl.DataAccess.ISEIExpandItemInfoGetter
            expandItemGetter = CMN.LIB.PartReplacement.CommonFactory.CreateInstance(Of SEI.LIB.ExpandItemControl.DataAccess.ISEIExpandItemInfoGetter)(Me, GetType(SEI.LIB.ExpandItemControl.DataAccess.SEIExpandItemInfoGetter))

            '仕入
            expandItemReader.SetExpandItemInfo(connection, initInfo, [LIB].ExpandItemControl.I拡張項目定義型.SEI拡張項目型.仕入伝票)
            Dim 仕入伝票拡張項目定義 As SEI.LIB.ExpandItemControl.I拡張項目定義型
            仕入伝票拡張項目定義 = CMN.LIB.PartReplacement.CommonFactory.CreateInstance(Of SEI.LIB.ExpandItemControl.I拡張項目定義型)(Me, GetType(SEI.LIB.ExpandItemControl.拡張項目定義型))
            仕入伝票拡張項目有無 = expandItemGetter.GetExpandItemInfo(initInfo, [LIB].ExpandItemControl.I拡張項目定義型.SEI拡張項目型.仕入伝票, 仕入伝票拡張項目定義)

            expandItemReader.SetExpandItemInfo(connection, initInfo, [LIB].ExpandItemControl.I拡張項目定義型.SEI拡張項目型.仕入明細)
            Dim 仕入明細拡張項目定義 As SEI.LIB.ExpandItemControl.I拡張項目定義型
            仕入明細拡張項目定義 = CMN.LIB.PartReplacement.CommonFactory.CreateInstance(Of SEI.LIB.ExpandItemControl.I拡張項目定義型)(Me, GetType(SEI.LIB.ExpandItemControl.拡張項目定義型))
            仕入明細拡張項目有無 = expandItemGetter.GetExpandItemInfo(initInfo, [LIB].ExpandItemControl.I拡張項目定義型.SEI拡張項目型.仕入明細, 仕入明細拡張項目定義)

            Call Set仕入拡張更新番号(connection, initInfo)

            '入荷
            expandItemReader.SetExpandItemInfo(connection, initInfo, [LIB].ExpandItemControl.I拡張項目定義型.SEI拡張項目型.入荷伝票)
            Dim 入荷伝票拡張項目定義 As SEI.LIB.ExpandItemControl.I拡張項目定義型
            入荷伝票拡張項目定義 = CMN.LIB.PartReplacement.CommonFactory.CreateInstance(Of SEI.LIB.ExpandItemControl.I拡張項目定義型)(Me, GetType(SEI.LIB.ExpandItemControl.拡張項目定義型))
            入荷伝票拡張項目有無 = expandItemGetter.GetExpandItemInfo(initInfo, [LIB].ExpandItemControl.I拡張項目定義型.SEI拡張項目型.入荷伝票, 仕入伝票拡張項目定義)

            expandItemReader.SetExpandItemInfo(connection, initInfo, [LIB].ExpandItemControl.I拡張項目定義型.SEI拡張項目型.入荷明細)
            Dim 入荷明細拡張項目定義 As SEI.LIB.ExpandItemControl.I拡張項目定義型
            入荷明細拡張項目定義 = CMN.LIB.PartReplacement.CommonFactory.CreateInstance(Of SEI.LIB.ExpandItemControl.I拡張項目定義型)(Me, GetType(SEI.LIB.ExpandItemControl.拡張項目定義型))
            入荷明細拡張項目有無 = expandItemGetter.GetExpandItemInfo(initInfo, [LIB].ExpandItemControl.I拡張項目定義型.SEI拡張項目型.入荷明細, 仕入明細拡張項目定義)

            Call Set入荷拡張更新番号(connection, initInfo)
        End If
        initInfo.Add(ProgramLib.プログラム専用_仕入伝票拡張項目有無, 仕入伝票拡張項目有無)
        initInfo.Add(ProgramLib.プログラム専用_仕入明細拡張項目有無, 仕入明細拡張項目有無)
        initInfo.Add(ProgramLib.プログラム専用_入荷伝票拡張項目有無, 入荷伝票拡張項目有無)
        initInfo.Add(ProgramLib.プログラム専用_入荷明細拡張項目有無, 入荷明細拡張項目有無)

        'A-CUST20190830↓
        '■入出庫拡張項目有無の判定と取得
        Dim 入出庫伝票拡張項目有無 As Boolean = False
        Dim 入出庫明細拡張項目有無 As Boolean = False
        If myコントロール情報.拡張項目 = SEI.LIB.ControlInfoC001.オプション区分定義型.区分型.行う Then
            Dim expandItemReader As SEI.LIB.ExpandItemControl.DataAccess.ISEIExpandItemReader
            expandItemReader = CMN.LIB.PartReplacement.CommonFactory.CreateInstance(Of SEI.LIB.ExpandItemControl.DataAccess.ISEIExpandItemReader)(Me, GetType(SEI.LIB.ExpandItemControl.DataAccess.SEIExpandItemReader))
            expandItemReader.Initialize(Me)
            Dim expandItemGetter As SEI.LIB.ExpandItemControl.DataAccess.ISEIExpandItemInfoGetter
            expandItemGetter = CMN.LIB.PartReplacement.CommonFactory.CreateInstance(Of SEI.LIB.ExpandItemControl.DataAccess.ISEIExpandItemInfoGetter)(Me, GetType(SEI.LIB.ExpandItemControl.DataAccess.SEIExpandItemInfoGetter))

            expandItemReader.SetExpandItemInfo(connection, initInfo, [LIB].ExpandItemControl.I拡張項目定義型.SEI拡張項目型.入出庫伝票)
            Dim 入出庫伝票拡張項目定義 As SEI.LIB.ExpandItemControl.I拡張項目定義型
            入出庫伝票拡張項目定義 = CMN.LIB.PartReplacement.CommonFactory.CreateInstance(Of SEI.LIB.ExpandItemControl.I拡張項目定義型)(Me, GetType(SEI.LIB.ExpandItemControl.拡張項目定義型))
            入出庫伝票拡張項目有無 = expandItemGetter.GetExpandItemInfo(initInfo, [LIB].ExpandItemControl.I拡張項目定義型.SEI拡張項目型.入出庫伝票, 入出庫伝票拡張項目定義)

            expandItemReader.SetExpandItemInfo(connection, initInfo, [LIB].ExpandItemControl.I拡張項目定義型.SEI拡張項目型.入出庫明細)
            Dim 入出庫明細拡張項目定義 As SEI.LIB.ExpandItemControl.I拡張項目定義型
            入出庫明細拡張項目定義 = CMN.LIB.PartReplacement.CommonFactory.CreateInstance(Of SEI.LIB.ExpandItemControl.I拡張項目定義型)(Me, GetType(SEI.LIB.ExpandItemControl.拡張項目定義型))
            入出庫明細拡張項目有無 = expandItemGetter.GetExpandItemInfo(initInfo, SEI.[LIB].ExpandItemControl.I拡張項目定義型.SEI拡張項目型.入出庫明細, 入出庫明細拡張項目定義)
            Call Set入出庫拡張更新番号(connection, initInfo)
        End If
        initInfo.Add(ProgramLib.プログラム専用_入出庫伝票拡張項目有無, 入出庫伝票拡張項目有無)
        initInfo.Add(ProgramLib.プログラム専用_入出庫明細拡張項目有無, 入出庫明細拡張項目有無)

        '販売日付情報取得
        Dim dateReader As HAN.LIB.DateInfo.DataAccess.IHANDateReader
        dateReader = CommonFactory.CreateInstance(Of HAN.LIB.DateInfo.DataAccess.IHANDateReader)(Me, GetType(HAN.LIB.DateInfo.DataAccess.HANDateReader))
        dateReader.Initialize(Me)
        dateReader.GetDateInfo(connection, initInfo)
        'A-CUST20190830↑

    End Function

    Protected Overrides Function 帳票タイトル() As String
        Return ProgramLib.帳票タイトル
    End Function

    Private Sub Set仕入拡張更新番号(ByRef connection As DbConnection, ByRef initInfo As IDictionary)
        Dim expandItemReader As SEI.LIB.ExpandItemControl.DataAccess.ISEIExpandItemReader
        expandItemReader = CMN.LIB.PartReplacement.CommonFactory.CreateInstance(Of SEI.LIB.ExpandItemControl.DataAccess.ISEIExpandItemReader)(Me, GetType(SEI.LIB.ExpandItemControl.DataAccess.SEIExpandItemReader))
        With expandItemReader
            .Initialize(Me)
            Dim 更新番号 As Long

            '仕入
            更新番号 = .GetExpandItemUpdateNumber(connection, SEI.LIB.ExpandItemControl.I拡張項目定義型.SEI拡張項目型.仕入伝票)
            initInfo.Add(ProgramLib.プログラム専用_仕入伝票拡張更新番号, 更新番号)

            更新番号 = .GetExpandItemUpdateNumber(connection, SEI.LIB.ExpandItemControl.I拡張項目定義型.SEI拡張項目型.仕入明細)
            initInfo.Add(ProgramLib.プログラム専用_仕入明細拡張更新番号, 更新番号)
        End With
    End Sub

    Private Sub Set入荷拡張更新番号(ByRef connection As DbConnection, ByRef initInfo As IDictionary)
        Dim expandItemReader As SEI.LIB.ExpandItemControl.DataAccess.ISEIExpandItemReader
        expandItemReader = CMN.LIB.PartReplacement.CommonFactory.CreateInstance(Of SEI.LIB.ExpandItemControl.DataAccess.ISEIExpandItemReader)(Me, GetType(SEI.LIB.ExpandItemControl.DataAccess.SEIExpandItemReader))
        With expandItemReader
            .Initialize(Me)
            Dim 更新番号 As Long

            '仕入
            更新番号 = .GetExpandItemUpdateNumber(connection, SEI.LIB.ExpandItemControl.I拡張項目定義型.SEI拡張項目型.入荷伝票)
            initInfo.Add(ProgramLib.プログラム専用_入荷伝票拡張更新番号, 更新番号)

            更新番号 = .GetExpandItemUpdateNumber(connection, SEI.LIB.ExpandItemControl.I拡張項目定義型.SEI拡張項目型.入荷明細)
            initInfo.Add(ProgramLib.プログラム専用_入荷明細拡張更新番号, 更新番号)
        End With
    End Sub

    'A-CUST20190830↓
    Private Sub Set入出庫拡張更新番号(ByRef connection As DbConnection, ByRef initInfo As IDictionary)
        Dim expandItemReader As SEI.LIB.ExpandItemControl.DataAccess.ISEIExpandItemReader
        expandItemReader = CMN.LIB.PartReplacement.CommonFactory.CreateInstance(Of SEI.LIB.ExpandItemControl.DataAccess.ISEIExpandItemReader)(Me, GetType(SEI.LIB.ExpandItemControl.DataAccess.SEIExpandItemReader))
        With expandItemReader
            .Initialize(Me)
            Dim 更新番号 As Long
            更新番号 = .GetExpandItemUpdateNumber(connection, SEI.LIB.ExpandItemControl.I拡張項目定義型.SEI拡張項目型.入出庫伝票)
            initInfo.Add(ProgramLib.プログラム専用_入出庫伝票拡張更新番号, 更新番号)
            更新番号 = .GetExpandItemUpdateNumber(connection, SEI.LIB.ExpandItemControl.I拡張項目定義型.SEI拡張項目型.入出庫明細)
            initInfo.Add(ProgramLib.プログラム専用_入出庫明細拡張更新番号, 更新番号)
        End With
    End Sub
    'A-CUST20190830↑

End Class
