﻿Public Class UpdateController
    Inherits UpdateControllerBase

    Protected Overrides Function DoImportMain() As Foundation.TextFileImport.IResult
        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase

        '実行可否チェック
        Dim executeForUpdate As Foundation.ExecuteCheck.DataAccess.IExecuteControlerForUpdate = New Foundation.ExecuteCheck.DataAccess.ExecuteControlerForUpdate
        executeForUpdate.Initialize(Me)
        Try
            '↓A-2008/07/18_Ver7.30_SAIMU
            If Is会計排他制御判定() = True Then
                Dim executeChecker_Zai As IExecuteChecker_Zai
                executeChecker_Zai = OSK.X1.Foundation.GeneralFactory(Of IExecuteChecker_Zai).CreateInstance(Me, "OSK.X1.SEI.S90050_00.SUB1.DA", "ExecuteChecker_Zai")    'X1変換Tool-20170508
                executeChecker_Zai.Initialize(Me)
                With executeChecker_Zai
                    .MyImportParam = CType(Me.ImportParam, S90050_00.ImportParam)
                End With

                Select Case executeChecker_Zai.DoExecuteCheck(executeForUpdate, Me.ExecuteCheckInfo)
                    Case ExecuteCheck.DataAccess.ExecuteCheckResult.成功
                    Case ExecuteCheck.DataAccess.ExecuteCheckResult.排他エラー
                        Call result.SetInfo(ResultType.同時実行不可)
                        Return result
                    Case ExecuteCheck.DataAccess.ExecuteCheckResult.アプリケーションエラー
                        If executeChecker_Zai.result_Han.Code <> ResultType.成功 Then
                            Return executeChecker_Zai.result_Han
                        End If
                End Select
            Else
                '↑A-2008/07/18_Ver7.30_SAIMU
                Dim checkExecution As New CheckExecution
                With checkExecution
                    .MyImportParam = CType(Me.ImportParam, S90050_00.ImportParam)
                End With
                Select Case executeForUpdate.StartExecution(Me.ExecuteCheckInfo, checkExecution)
                    Case ExecuteCheck.DataAccess.ExecuteCheckResult.成功
                    Case ExecuteCheck.DataAccess.ExecuteCheckResult.排他エラー
                        Call result.SetInfo(ResultType.同時実行不可)
                        Return result
                    Case ExecuteCheck.DataAccess.ExecuteCheckResult.アプリケーションエラー
                        Return checkExecution.Result
                End Select
            End If  'A-2008/07/18_Ver7.30_SAIMU

            result = MyBase.DoImportMainImpl()

            executeForUpdate.EndExecution()

        Finally
            executeForUpdate.Release()

        End Try

        Return result
    End Function

    ''' <summary>
    ''' 会計側の排他制御を行うか判定
    ''' </summary>
    ''' <returns>False：行わない／True：行う</returns>
    ''' <remarks></remarks>
    Private Function Is会計排他制御判定() As Boolean    'A-2008/07/18_Ver7.30_SAIMU

        Dim myImportParam As S90050_00.ImportParam
        myImportParam = CType(Me.ImportParam, S90050_00.ImportParam)

        If myImportParam.Myコントロール情報.My会計オプション.会計債務管理 = True Then
            Return True
        End If

        Return False
    End Function

    'A-CUST20190830↓
    Protected Overrides Function DoImportImpl(ByRef connection As System.Data.Common.DbConnection) As Foundation.TextFileImport.IResult

        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase
        Dim resultC020 As TextFileImport.IResult = New TextFileImport.ResultBase

        result = MyBase.DoImportImpl(connection)

        '管理テーブルに更新(置き返したファイル名ではなく、取込元ファイル名を更新)
        resultC020 = UpdateHANC020()

        Return result
    End Function

    Private Function UpdateHANC020() As TextFileImport.IResult
        Dim result As TextFileImport.IResult = New TextFileImport.ResultBase
        Try
            Using connection As DbConnection = OpenConnection()
                Using transaction As DbTransaction = connection.BeginTransaction()
                    Dim myDataUpdater As New MyDataUpdater
                    myDataUpdater.Initialize(Me, CType(Me.ImportParam, S90050_00.ImportParam))
                    result = myDataUpdater.UpdateHANC020(transaction, CType(Me.ImportParam, S90050_00.ImportParam))

                    If result.Code <> ResultType.成功 Then
                        transaction.Rollback()
                        Return result
                    End If
                    transaction.Commit()
                End Using

                CloseConnection(connection)
            End Using
        Finally

        End Try
        Return result
    End Function
    'A-CUST20190830↑

End Class
