﻿''' <summary>
''' データ読み込み用インターフェース
''' </summary>
''' <remarks></remarks>
Public Class MyDataReader
    Inherits OSK.X1.Foundation.DataAccess.InsideDataHandlerBase    'X1変換Tool-20170508

    Private _queryMaker As IMyQueryMaker
    Private _myImportParam As S90050_00.ImportParam

#Region "■初期処理関連■"

    Public Overloads Sub Initialize(ByRef base As Foundation.IBase,
                                    ByVal myImportParam As S90050_00.ImportParam
                         )

        MyBase.Initialize(CType(base, Foundation.DataAccess.IDataHandler))
        _myImportParam = myImportParam
        _queryMaker = CType(TextFileImportDALib.CreateQueryMaker(base), IMyQueryMaker)
        _queryMaker.MyImportParam = myImportParam

    End Sub

#End Region

#Region "■公開メソッド■"

    Public Function ReadHANC015UpdateLock(ByRef transaction As DbTransaction,
                                          ByVal 伝票日付 As Integer
                    ) As Foundation.ResultType

        Return ReadHANC015UpdateLockImpl(transaction, 伝票日付)

    End Function

    Public Function ReadSEIC056PrimaryKey(ByRef transaction As DbTransaction,
                                          ByRef 取得したデータ As DataTable,
                                          ByVal 管理区分 As Integer,
                                          ByVal 連番コード As String
                    ) As Foundation.ResultType

        Return ReadSEIC056PrimaryKeyImpl(transaction, 取得したデータ, 管理区分, 連番コード)

    End Function

    Public Function ReadHANC021PrimaryKey(ByRef transaction As DbTransaction,
                                          ByRef 取得したデータ As DataTable
                    ) As Foundation.ResultType

        Return ReadHANC021PrimaryKeyImpl(transaction, 取得したデータ)

    End Function

    Public Function ReadHANC022PrimaryKey(ByRef transaction As DbTransaction,
                                          ByRef 取得したデータ As DataTable
                    ) As Foundation.ResultType

        Return ReadHANC022PrimaryKeyImpl(transaction, 取得したデータ)

    End Function

    Public Function ReadHANC023PrimaryKey(ByRef transaction As DbTransaction,
                                         ByRef 取得したデータ As DataTable
                   ) As Foundation.ResultType   'A-2009/12/18_Ver7.40_LOT

        Return ReadHANC023PrimaryKeyImpl(transaction, 取得したデータ)

    End Function

    Public Function ReadHANM002PrimaryKey(ByRef transaction As DbTransaction,
                                           ByRef 取得したデータ As DataTable,
                                           ByVal 仕入先コード As String
                     ) As Foundation.ResultType

        Return ReadHANM002PrimaryKeyImpl(transaction, 取得したデータ, 仕入先コード)

    End Function

    Public Function ReadHANM003PrimaryKey(ByRef transaction As DbTransaction,
                                          ByRef 取得したデータ As DataTable,
                                          ByVal 商品コード As String
                    ) As Foundation.ResultType

        Return ReadHANM003PrimaryKeyImpl(transaction, 取得したデータ, 商品コード)

    End Function

    Public Function ReadHANM005PrimaryKey(ByRef transaction As DbTransaction,
                                          ByVal 担当者コード As String
                    ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Return ReadHANM005PrimaryKeyImpl(transaction, 担当者コード)

    End Function

    Public Function ReadHANM006PrimaryKey(ByRef transaction As DbTransaction,
                                          ByRef 取得したデータ As DataTable,
                                          ByVal 倉庫コード As String
                    ) As Foundation.ResultType

        Return ReadHANM006PrimaryKeyImpl(transaction, 取得したデータ, 倉庫コード)

    End Function

    Public Function ReadHANM008PrimaryKey(ByRef transaction As DbTransaction,
                                          ByVal 備考コード As String
                    ) As Foundation.ResultType

        Return ReadHANM008PrimaryKeyImpl(transaction, 備考コード)

    End Function

    Public Function ReadHANM009PrimaryKey(ByRef transaction As DbTransaction,
                                          ByVal 摘要コード As String
                    ) As Foundation.ResultType

        Return ReadHANM009PrimaryKeyImpl(transaction, 摘要コード)

    End Function

    Public Function ReadHANM010PrimaryKey(ByRef transaction As DbTransaction,
                                      ByVal マスター区分 As Integer,
                                      ByVal 分類種別番号 As Integer,
                                      ByVal 分類コード As String
                ) As Foundation.ResultType  'A-2008/07/18_Ver7.30_GENKA

        Return ReadHANM010PrimaryKeyImpl(transaction, マスター区分, 分類種別番号, 分類コード)

    End Function

    Public Function ReadHANM015PrimaryKey(ByRef transaction As DbTransaction,
                                          ByVal 部門コード As String
                    ) As Foundation.ResultType

        Return ReadHANM015PrimaryKeyImpl(transaction, 部門コード)

    End Function

    Public Function ReadHANM021PrimaryKey(ByRef transaction As DbTransaction,
                                          ByVal 内訳種別 As Integer,
                                          ByVal 内訳コード As String
                    ) As Foundation.ResultType  'A-2009/12/18_Ver7.40_UCHIWAKE

        Return ReadHANM021PrimaryKeyImpl(transaction, 内訳種別, 内訳コード)

    End Function

    Public Function ReadHANM023PrimaryKey(ByRef transaction As DbTransaction,
                                          ByRef 取得したデータ As DataTable,
                                          ByVal 読込キー As ProgramLib.商品内訳マスター型
                    ) As Foundation.ResultType  'A-2009/12/18_Ver7.40_UCHIWAKE

        Return ReadHANM023PrimaryKeyImpl(transaction, 取得したデータ, 読込キー)

    End Function

    Public Function ReadHANM031PrimaryKey(ByRef transaction As DbTransaction,
                                          ByVal 参照定義コード As String,
                                          ByVal コード As String
                    ) As Foundation.ResultType

        Return ReadHANM031PrimaryKeyImpl(transaction, 参照定義コード, コード)

    End Function

    Public Function ReadHANM036PrimaryKey(ByRef transaction As DbTransaction,
                                          ByVal 営業所コード As String
                    ) As Foundation.ResultType

        Return ReadHANM036PrimaryKeyImpl(transaction, 営業所コード)

    End Function

    Public Function ReadHANM040PrimaryKey(ByRef transaction As DbTransaction,
                                          ByRef 取得したデータ As DataTable,
                                          ByVal 原価集計メインコード As String,
                                          ByVal 原価集計サブコード As String
                    ) As Foundation.ResultType      'A-2008/07/18_Ver7.30_GENKA

        Return ReadHANM040PrimaryKeyImpl(transaction, 取得したデータ, 原価集計メインコード, 原価集計サブコード)

    End Function

    Public Function ReadHANM045PrimaryKey(ByRef transaction As DbTransaction,
                                          ByRef 取得したデータ As DataTable,
                                          ByVal 読込キー As ProgramLib.ロットマスター型
                    ) As Foundation.ResultType  'A-2009/12/18_Ver7.40_LOT

        Return ReadHANM045PrimaryKeyImpl(transaction, 取得したデータ, 読込キー)

    End Function

    Public Function ReadSEIR009PrimaryKey(ByRef transaction As DbTransaction,
                                      ByRef 取得したデータ As DataTable,
                                      ByVal 商品コード As String,
                                      ByVal ロットNO As String
                ) As Foundation.ResultType

        Return ReadSEIR009PrimaryKeyImpl(transaction, 取得したデータ, 商品コード, ロットNO)

    End Function

    Public Function ReadSEIR010PrimaryKey(ByRef transaction As DbTransaction,
                                          ByRef 取得したデータ As DataTable,
                                          ByVal 処理連番 As Long
                    ) As Foundation.ResultType

        Return ReadSEIR010PrimaryKeyImpl(transaction, 取得したデータ, 処理連番)

    End Function

    Public Function ReadSEIR010返品伝票存在(ByRef transaction As DbTransaction,
                                            ByVal 処理連番 As Long
                    ) As Foundation.ResultType

        Return ReadSEIR010返品伝票存在Impl(transaction, 処理連番)

    End Function

    Public Function ReadSEIR055PrimaryKey(ByRef transaction As DbTransaction,
                                          ByRef 取得したデータ As DataTable,
                                          ByVal 手配番号 As Long
                    ) As Foundation.ResultType

        Return ReadSEIR055PrimaryKeyImpl(transaction, 取得したデータ, 手配番号)

    End Function

    Public Function ReadSEIR055前後工程取得(ByRef transaction As DbTransaction,
                                            ByRef 取得したデータ As DataTable,
                                            ByVal 手配管理番号 As Long,
                                            ByVal 手順番号 As Integer,
                                            ByVal 前後工程 As Integer
                    ) As Foundation.ResultType

        Return ReadSEIR055前後工程取得Impl(transaction, 取得したデータ, 手配管理番号, 手順番号, 前後工程)

    End Function

    'A-20160324_2↓
    Public Function ReadSEIR055_SEIM050同時取得(ByRef transaction As DbTransaction,
                                                ByRef 取得したデータ As DataTable,
                                                ByVal 手配番号 As Long
                    ) As Foundation.ResultType

        Return ReadSEIR055_SEIM050同時取得Impl(transaction, 取得したデータ, 手配番号)

    End Function
    'A-20160324_2↑

    Public Function ReadSEIR056PrimaryKey(ByRef transaction As DbTransaction,
                                          ByRef 取得したデータ As DataTable,
                                          ByVal 手配番号 As Long,
                                          ByVal 展開順序番号 As Integer,
                                          ByVal 支給管理 As Integer
                    ) As Foundation.ResultType

        Return ReadSEIR056PrimaryKeyImpl(transaction, 取得したデータ, 手配番号, 展開順序番号, 支給管理)

    End Function

    Public Function ReadSEIR057PrimaryKey(ByRef transaction As DbTransaction,
                                          ByRef 取得したデータ As DataTable,
                                          ByVal 手配番号 As Long) As Foundation.ResultType

        Return ReadSEIR057PrimaryKeyImpl(transaction, 取得したデータ, 手配番号)

    End Function

    'A-20121217_Ver7.50_2↓
    Public Function ReadSEIR057工程明細取得(ByRef transaction As DbTransaction,
                                            ByRef 取得したデータ As DataTable,
                                            ByVal 処理連番 As Long) As Foundation.ResultType

        Return ReadSEIR057工程明細取得Impl(transaction, 取得したデータ, 処理連番)

    End Function
    'A-20121217_Ver7.50_2↑

    Public Function ReadSEIR057実績数量合計(ByRef transaction As DbTransaction,
                                            ByRef 取得したデータ As DataTable,
                                            ByVal 手配番号 As Long) As Foundation.ResultType

        Return ReadSEIR057実績数量合計Impl(transaction, 取得したデータ, 手配番号)

    End Function

    Public Function ReadSEIM012PrimaryKey(ByRef transaction As DbTransaction,
                                          ByVal 費目コード As String
                    ) As Foundation.ResultType

        Return ReadSEIM012PrimaryKeyImpl(transaction, 費目コード)

    End Function

    Public Function ReadSEIM050PrimaryKey(ByRef transaction As DbTransaction,
                                          ByRef 取得したデータ As DataTable,
                                          ByVal 製番 As String
                ) As Foundation.ResultType

        Return ReadSEIM050PrimaryKeyImpl(transaction, 取得したデータ, 製番)

    End Function

    Public Function ReadSEIM053PrimaryKey(ByRef transaction As DbTransaction,
                                          ByRef 取得したデータ As DataTable,
                                          ByVal 工程コード As String
                ) As Foundation.ResultType

        Return ReadSEIM053PrimaryKeyImpl(transaction, 取得したデータ, 工程コード)

    End Function

    Public Function ReadHANR001PrimaryKey(ByRef transaction As DbTransaction,
                                          ByRef 取得したデータ As DataTable,
                                          ByVal 処理連番 As Long,
                                          Optional ByVal 明細区分 As Integer = -1,
                                          Optional ByVal 行番号 As Integer = -1,
                                          Optional ByVal 相手存在チェック As Boolean = False
                    ) As Foundation.ResultType

        Return ReadHANR001PrimaryKeyImpl(transaction, 取得したデータ, 処理連番, 明細区分, 行番号, 相手存在チェック)

    End Function

    Public Function ReadHANR001PrimaryKey(ByRef transaction As DbTransaction,
                                          ByRef 取得したデータ As DataTable,
                                          ByVal 取引区分 As Integer,
                                          ByVal 処理連番 As Long
                    ) As Foundation.ResultType

        Return ReadHANR001PrimaryKeyImpl(transaction, 取得したデータ, 取引区分, 処理連番)

    End Function

    Public Function ReadHANR001出庫伝票存在(ByRef transaction As DbTransaction,
                                            ByVal 処理連番 As Long,
                                            ByVal 取引区分 As Integer
                    ) As Foundation.ResultType

        Return ReadHANR001出庫伝票存在Impl(transaction, 処理連番, 取引区分)

    End Function

    Public Function ReadHANR001入庫伝票取得(ByRef transaction As DbTransaction,
                                            ByRef 取得したデータ As DataTable,
                                            ByVal 処理連番 As Long
                ) As Foundation.ResultType

        Return ReadHANR001入庫伝票取得Impl(transaction, 取得したデータ, 処理連番)

    End Function

    'A-20120125_2↓
    Public Function ReadHANR001出庫伝票取得(ByRef transaction As DbTransaction,
                                            ByRef 取得したデータ As DataTable,
                                            ByVal 処理連番 As Long
                ) As Foundation.ResultType

        Return ReadHANR001出庫伝票取得Impl(transaction, 取得したデータ, 処理連番)

    End Function
    'A-20120125_2↑

    'A-20121217_Ver7.50_1↓
    Public Function ReadHANR001按分済受入伝票(ByRef transaction As DbTransaction,
                                              ByRef 取得したデータ As DataTable,
                                              ByVal 諸掛管理番号 As String
                ) As Foundation.ResultType

        Return ReadHANR001按分済受入伝票Impl(transaction, 取得したデータ, 諸掛管理番号)

    End Function
    'A-20121217_Ver7.50_1↑

    Public Function ReadHANR004PrimaryKey(ByRef transaction As DbTransaction,
                                          ByRef 取得したデータ As DataTable,
                                          ByVal 発注番号 As Long
                    ) As Foundation.ResultType

        Return ReadHANR004PrimaryKeyImpl(transaction, 取得したデータ, 発注番号)

    End Function

    Public Function ReadHANR005PrimaryKey(ByRef transaction As DbTransaction,
                                          ByRef 取得したデータ As DataTable,
                                          ByVal 発注番号 As Long,
                                          ByVal 発注行番号 As Integer
                    ) As Foundation.ResultType

        Return ReadHANR005PrimaryKeyImpl(transaction, 取得したデータ, 発注番号, 発注行番号)

    End Function

    Public Function ReadHANR005関連受注(ByRef transaction As DbTransaction,
                                        ByRef 取得したデータ As DataTable,
                                        ByVal 受注番号 As Long,
                                        ByVal 受注行番号 As Integer
                    ) As Foundation.ResultType

        Return ReadHANR005関連受注Impl(transaction, 取得したデータ, 受注番号, 受注行番号)

    End Function

    Public Function ReadHANR005見込受注(ByRef transaction As DbTransaction,
                                        ByRef 取得したデータ As DataTable,
                                        ByVal 発注番号 As Long
                    ) As Foundation.ResultType

        Return ReadHANR005見込受注Impl(transaction, 取得したデータ, 発注番号)

    End Function

    Public Function ReadHANR005原価集計制御情報(ByRef transaction As DbTransaction,
                                                ByRef 取得したデータ As DataTable,
                                                ByVal 発注番号 As Long,
                                                ByVal 発注行番号 As Integer
                    ) As Foundation.ResultType      'A-2008/07/18_Ver7.30_GENKA

        Return ReadHANR005原価集計制御情報Impl(transaction, 取得したデータ, 発注番号, 発注行番号)

    End Function

    'A-20121217_Ver7.50_2↓
    Public Function ReadHANR005元需要受注伝票(ByRef transaction As DbTransaction,
                                              ByRef 取得したデータ As DataTable,
                                              ByVal 製番 As String,
                                              ByVal 品目 As String
                    ) As Foundation.ResultType

        Return ReadHANR005元需要受注伝票Impl(transaction, 取得したデータ, 製番, 品目)

    End Function
    'A-20121217_Ver7.50_2↑

    Public Function ReadSEIR008PrimaryKey(ByRef transaction As DbTransaction,
                                          ByRef 取得したデータ As DataTable,
                                          ByVal 処理連番 As Long,
                                          ByVal 行番号 As Integer
                    ) As Foundation.ResultType

        Return ReadSEIR008PrimaryKeyImpl(transaction, 取得したデータ, 処理連番, 行番号)

    End Function

    Public Function ReadSEIR008_自動ロット(ByRef transaction As DbTransaction,
                                           ByRef 取得したデータ As DataTable,
                                           ByVal 倉庫コード As String,
                                           ByVal 商品コード As String,
                                           ByVal 期首年月 As Integer
                    ) As Foundation.ResultType

        Return ReadSEIR008_自動ロットImpl(transaction, 取得したデータ, 倉庫コード, 商品コード, 期首年月)

    End Function

    'D-20111124_3↓
    'Public Function ReadSEIR008_ロット明細合計(ByRef transaction As DbTransaction, _
    '                                           ByRef 取得したデータ As DataTable, _
    '                                           ByVal 処理連番 As Long, _
    '                                           Optional ByVal 処理連番CH As Long = -1 _
    '                ) As Foundation.ResultType

    '    Return ReadSEIR008_ロット明細合計Impl(transaction, 取得したデータ, 処理連番, 処理連番CH)

    'End Function
    'D-20111124_3↑
    'A-20111124_3↓
    Public Function ReadSEIR008_ロット明細合計(ByRef transaction As DbTransaction,
                                               ByRef 取得したデータ As DataTable,
                                               ByVal 処理連番 As Long,
                                               Optional ByVal 処理連番CH As Long = -1,
                                               Optional ByVal 倉庫移動出庫処理連番 As Long = -1,
                                               Optional ByVal 入出庫区分 As 入出庫区分型 = 入出庫区分型.入庫
                    ) As Foundation.ResultType

        Return ReadSEIR008_ロット明細合計Impl(transaction, 取得したデータ, 処理連番, 処理連番CH, 倉庫移動出庫処理連番, 入出庫区分)

    End Function
    'A-20111124_3↑

    Public Function ReadSEIR008出庫伝票合計(ByRef transaction As DbTransaction,
                                            ByRef 取得したデータ As DataTable,
                                            ByVal 手配番号 As Long,
                                            ByVal 処理連番 As Long
                    ) As Foundation.ResultType

        Return ReadSEIR008出庫伝票合計Impl(transaction, 取得したデータ, 手配番号, 処理連番)

    End Function

    Public Function ReadSEIR008関連ロット明細(ByRef transaction As DbTransaction,
                                              ByRef 取得したデータ As DataTable,
                                              ByVal 手配番号 As Long, ByVal 展開順序番号 As Integer) As Foundation.ResultType

        Return ReadSEIR008関連ロット明細Impl(transaction, 取得したデータ, 手配番号, 展開順序番号)

    End Function

    Public Function ReadHANR031PrimaryKey(ByRef transaction As DbTransaction,
                                          ByRef 取得したデータ As DataTable,
                                          ByVal 伝票処理連番 As Long
                    ) As Foundation.ResultType      'A-2008/07/18_Ver7.30_SHIHARAI

        Return ReadHANR031PrimaryKeyImpl(transaction, 取得したデータ, 伝票処理連番)

    End Function

    Public Function ReadHANR032PrimaryKey(ByRef transaction As DbTransaction,
                                          ByVal 支払予定データ As ProgramLib.支払予定テーブル型
                    ) As Foundation.ResultType      'A-2008/07/18_Ver7.30_SHIHARAI

        Return ReadHANR032PrimaryKeyImpl(transaction, 支払予定データ)

    End Function

    Public Function ReadHANS002PrimaryKey(ByRef transaction As DbTransaction,
                                          ByRef 取得したデータ As DataTable,
                                          ByVal 仕入先コード As String,
                                          ByVal 対象年月 As Integer
                    ) As Foundation.ResultType

        Return ReadHANS002PrimaryKeyImpl(transaction, 取得したデータ, 仕入先コード, 対象年月)

    End Function

    'A-20121217_Ver7.50_1↓
    Public Function ReadSEIS005PrimaryKey(ByRef transaction As DbTransaction,
                                          ByRef 取得したデータ As DataTable,
                                          ByVal 仕入先コード As String,
                                          ByVal 対象年月 As Integer
                    ) As Foundation.ResultType

        Return ReadSEIS005PrimaryKeyImpl(transaction, 取得したデータ, 仕入先コード, 対象年月)

    End Function
    'A-20121217_Ver7.50_1↑

    Public Function ReadHANZ034PrimaryKey(ByRef transaction As DbTransaction,
                                          ByVal 明細区分 As Integer,
                                          ByVal 入力パターン番号 As String
                    ) As Foundation.ResultType

        Return ReadHANZ034PrimaryKeyImpl(transaction, 明細区分, 入力パターン番号)

    End Function

    Public Function ReadHANW091任意項目(ByRef transaction As DbTransaction,
                                        ByVal 分割コード As String,
                                        ByVal 任意項目１ As String
                    ) As Foundation.ResultType

        Return ReadHANW091任意項目Impl(transaction, 分割コード, 任意項目１)

    End Function

    Public Function ReadZAIR001UpdateLock(ByRef transaction As DbTransaction,
                                          ByRef 取得したデータ As DataTable,
                                          ByVal 処理連番 As Long
                    ) As Foundation.ResultType      'A-2008/07/18_Ver7.30_SAIMU

        Return ReadZAIR001UpdateLockImpl(transaction, 取得したデータ, 処理連番)

    End Function

    Public Function ReadZAIR101UpdateLock(ByRef transaction As DbTransaction,
                                          ByRef 取得したデータ As DataTable,
                                          ByVal 処理連番 As Long
                    ) As Foundation.ResultType  'A-2010/09/13_Ver7.4X_ZAISHONIN

        Return ReadZAIR101UpdateLockImpl(transaction, 取得したデータ, 処理連番)

    End Function

    Public Function ReadZAIR204会計債務消込チェック(ByRef transaction As DbTransaction,
                                                    ByRef 取得したデータ As DataTable,
                                                    ByVal 処理連番 As Long
                    ) As Foundation.ResultType      'A-2008/07/18_Ver7.30_SAIMU

        Return ReadZAIR204会計債務消込チェックImpl(transaction, 取得したデータ, 処理連番)

    End Function

    Public Function ReadZAIR205会計支払状態チェック(ByRef transaction As DbTransaction,
                                                    ByRef 取得したデータ As DataTable,
                                                    ByVal 処理連番 As Long
                    ) As Foundation.ResultType      'A-2008/07/18_Ver7.30_SAIMU

        Return ReadZAIR205会計支払状態チェックImpl(transaction, 取得したデータ, 処理連番)

    End Function

    Public Function ReadZAIR502完成原価自動振替チェック(ByRef transaction As DbTransaction,
                                                        ByRef 取得したデータ As DataTable,
                                                        ByVal 処理連番 As Long
                    ) As Foundation.ResultType      'A-2009/12/18_Ver7.40_PRO

        Return ReadZAIR502完成原価自動振替チェックImpl(transaction, 取得したデータ, 処理連番)

    End Function

    'D-20150520_1↓
    'Public Function Read製造出庫(ByRef transaction As DbTransaction, _
    '                         ByRef 取得したデータ As DataTable, _
    '                         ByVal 処理連番 As Long, _
    '                         ByVal 手配番号 As Long, _
    '                         ByVal 構成品出庫区分 As Integer, _
    '                         ByVal 支給管理 As Integer _
    '        ) As Foundation.ResultType
    'D-20150520_1↑
    'A-20150520_1↓
    Public Function Read製造出庫(ByRef transaction As DbTransaction,
                             ByRef 取得したデータ As DataTable,
                             ByVal 処理連番 As Long,
                             ByVal 手配番号 As Long,
                             ByVal 構成品出庫区分 As Integer,
                             ByVal 支給管理 As Integer,
                             ByVal 対象年月度 As Integer
            ) As Foundation.ResultType
        'A-20150520_1↑
        'Return Read製造出庫Impl(transaction, 取得したデータ, 処理連番, 手配番号, 構成品出庫区分, 支給管理)                 'D-20150520_1
        Return Read製造出庫Impl(transaction, 取得したデータ, 処理連番, 手配番号, 構成品出庫区分, 支給管理, 対象年月度)      'A-20150520_1

    End Function

    Public Function Read個別出庫(ByRef transaction As DbTransaction,
                                 ByRef 取得したデータ As DataTable,
                                 ByVal 処理連番 As Long
                ) As Foundation.ResultType

        Return Read個別出庫Impl(transaction, 取得したデータ, 処理連番)

    End Function

    Public Function Readロット明細(ByRef transaction As DbTransaction,
                                   ByRef 取得したデータ As DataTable,
                                   ByVal 明細区分 As Integer,
                                   ByVal 取引区分 As Integer,
                                   ByVal 処理連番 As Long,
                                   ByVal 行番号 As Integer
                ) As Foundation.ResultType

        Return Readロット明細Impl(transaction, 取得したデータ, 取引区分, 取引区分, 処理連番, 行番号)

    End Function
    'A-20110912_1↓
    Public Function ReadHANR001SK(ByRef transaction As DbTransaction,
                                   ByRef 取得したデータ As DataTable,
                                   ByVal 処理連番 As Long) As Foundation.ResultType

        Return ReadHANR001SKImpl(transaction, 取得したデータ, 処理連番)

    End Function

    Public Function ReadSEIW053前後工程仕掛取得(ByRef transaction As DbTransaction,
                                            ByRef 取得したデータ As DataTable,
                                            ByVal 手配管理番号 As Long,
                                            ByVal 手順番号F As Integer,
                                            ByVal 手順番号T As Integer
                    ) As Foundation.ResultType

        Return ReadSEIW053前後工程仕掛取得Impl(transaction, 取得したデータ, 手配管理番号, 手順番号F, 手順番号T)

    End Function
    'A-20110912_1↑

    'A-20120125_1↓
    Public Function ReadSEIS003仕掛在庫数量取得(ByRef transaction As DbTransaction,
                                                ByRef 取得したデータ As DataTable,
                                                ByVal 内外区分 As Integer,
                                                ByVal 手配先コード As String,
                                                ByVal 品目コード As String,
                                                ByVal 手順No As Integer,
                                                ByVal 当期期首年月度 As Integer
                    ) As Foundation.ResultType

        Return ReadSEIS003仕掛在庫数量取得Impl(transaction, 取得したデータ, 内外区分, 手配先コード, 品目コード, 手順No, 当期期首年月度)

    End Function
    'A-20120125_1↑

    'A-20130304_1↓
    Public Function ReadSEIR010分納実績取得(ByRef transaction As DbTransaction,
                                            ByRef 取得したデータ As DataTable,
                                            ByVal 発注番号 As Long,
                                            ByVal 処理連番 As Long
                ) As Foundation.ResultType

        Return ReadSEIR010分納実績取得Impl(transaction, 取得したデータ, 発注番号, 処理連番)

    End Function
    'A-20130304_1↑

    'A-20130304_2↓
    Public Function Read元需要(ByRef transaction As DbTransaction,
                               ByRef 取得したデータ As DataTable,
                               ByVal 発注区分 As Integer,
                               ByVal 発注番号 As Long,
                               ByVal 手配管理番号 As Long
                ) As Foundation.ResultType

        Return Read元需要Impl(transaction, 取得したデータ, 発注区分, 発注番号, 手配管理番号)

    End Function
    'A-20130304_2↑

    'A-20130402_2↓
    Public Function ReadDataCommon(ByRef transaction As DbTransaction,
                                   ByRef 取得したデータ As DataTable,
                                   ByVal targetData As readDataType,
                                   ByVal ParamArray key() As String) As Foundation.ResultType

        Return ReadDataCommonImpl(transaction, 取得したデータ, targetData, key)

    End Function
    'A-20130402_2↑

    'A-CUST20190830↓
    Public Function Read発注伝票CUST(ByRef transaction As DbTransaction,
                                      ByRef 取得したデータ As DataTable,
                                      ByVal 発注番号 As Long,
                                      ByVal 発注行番号 As Integer
                ) As Foundation.ResultType

        Return Read発注伝票_CUST(transaction, 取得したデータ, 発注番号, 発注行番号)

    End Function

    Public Function Read発注内訳伝票CUST(ByRef transaction As DbTransaction,
                                  ByRef 取得したデータ As DataTable,
                                  ByVal 発注番号 As Long,
                                  ByVal 発注行番号 As Integer,
                                  ByVal 内訳番号 As Integer
            ) As Foundation.ResultType

        Return Read発注内訳伝票_CUST(transaction, 取得したデータ, 発注番号, 発注行番号, 内訳番号)

    End Function

    Public Function Read入出荷予定伝票CUST(ByRef transaction As DbTransaction,
                                  ByRef 取得したデータ As DataTable,
                                  ByVal 入出荷予定番号 As Long,
                                  ByVal 入出荷予定行番号 As Integer
            ) As Foundation.ResultType

        Return Read入出荷予定伝票_CUST(transaction, 取得したデータ, 入出荷予定番号, 入出荷予定行番号)

    End Function

    Public Function Read入出荷予定伝票CUST(ByRef transaction As DbTransaction,
                                  ByRef 取得したデータ As DataTable,
                                  ByVal 入出荷予定番号 As Long
            ) As Foundation.ResultType

        Return Read入出荷予定伝票_CUST(transaction, 取得したデータ, 入出荷予定番号)

    End Function

    Public Function Read入出荷予定ヘッダーCUST(ByRef transaction As DbTransaction,
                                  ByRef 取得したデータ As DataTable,
                                  ByVal 入出荷予定番号 As Long
            ) As Foundation.ResultType

        Return Read入出荷予定ヘッダー_CUST(transaction, 取得したデータ, 入出荷予定番号)

    End Function

    Public Function Read入出荷予定明細CUST(ByRef transaction As DbTransaction,
                                  ByRef 取得したデータ As DataTable,
                                  ByVal 入出荷予定番号 As Long,
                                  ByVal 入出荷予定行番号 As Integer
            ) As Foundation.ResultType

        Return Read入出荷予定明細_CUST(transaction, 取得したデータ, 入出荷予定番号, 入出荷予定行番号)

    End Function

    Public Function ReadSEIMA02PrimaryKey(ByRef transaction As DbTransaction,
                                      ByRef 取得したデータ As DataTable,
                                      ByVal コード As String
                ) As Foundation.ResultType

        Return ReadSEIMA02PrimaryKeyImpl(transaction, 取得したデータ, コード)

    End Function
    'A-CUST20190830↑
#End Region

#Region "■内部メソッド■"

    Private Function ReadHANC015UpdateLockImpl(ByRef transaction As DbTransaction,
                                               ByVal 伝票日付 As Integer
                     ) As Foundation.ResultType
        Dim result As New Foundation.ResultType
        Dim reader As DbDataReader = Nothing

        Try
            Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
            Dim query As String = _queryMaker.SelectHANC015UpdateLock(paramInfo, 伝票日付)
            Dim hasRows As Boolean
            Dim command As DbCommand = Nothing
            reader = MyBase.DataAccess.GetDataReader(transaction, query, paramInfo, hasRows, command)
            If hasRows = True Then
                result = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508
            Else
                result = ResultType.レコード無し
            End If
            '必ずクローズする必要があります。でないとエラーになる...
            MyBase.DataAccess.CloseReader(reader)

        Finally
            If reader IsNot Nothing Then
                '必ずクローズする必要があります。でないとエラーになる...
                MyBase.DataAccess.CloseReader(reader)
            End If

        End Try

        Return result
    End Function

    Private Function ReadSEIC056PrimaryKeyImpl(ByRef transaction As DbTransaction,
                                               ByRef 取得したデータ As DataTable,
                                               ByVal 管理区分 As Integer,
                                               ByVal 連番コード As String
                     ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        If 管理区分 < 1 AndAlso 管理区分 > 3 Then
            '管理区分が範囲対象外の場合
            Return ResultType.レコード無し
        End If

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.SelectSEIC056PrimaryKey(paramInfo, 管理区分, 連番コード)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function

    Private Function ReadHANC021PrimaryKeyImpl(ByRef transaction As DbTransaction,
                                               ByRef 取得したデータ As DataTable
                     ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.SelectHANC021PrimaryKey
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function

    Private Function ReadHANC022PrimaryKeyImpl(ByRef transaction As DbTransaction,
                                               ByRef 取得したデータ As DataTable
                     ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.SelectHANC022PrimaryKey
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function

    Private Function ReadHANC023PrimaryKeyImpl(ByRef transaction As DbTransaction,
                                              ByRef 取得したデータ As DataTable
                    ) As Foundation.ResultType  'A-2009/12/18_Ver7.40_LOT
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.SelectHANC023PrimaryKey
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function

    Private Function ReadHANM002PrimaryKeyImpl(ByRef transaction As DbTransaction,
                                                ByRef 取得したデータ As DataTable,
                                                ByVal 仕入先コード As String
                      ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.SelectHANM002PrimaryKey(paramInfo, 仕入先コード)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function

    Private Function ReadHANM003PrimaryKeyImpl(ByRef transaction As DbTransaction,
                                               ByRef 取得したデータ As DataTable,
                                               ByVal 商品コード As String
                     ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.SelectHANM003PrimaryKey(paramInfo, 商品コード)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function

    Private Function ReadHANM005PrimaryKeyImpl(ByRef transaction As DbTransaction,
                                               ByVal 担当者コード As String
                     ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.SelectHANM005PrimaryKey(paramInfo, 担当者コード)
        Dim reader As DbDataReader
        Dim hasRows As Boolean
        Dim command As DbCommand = Nothing
        reader = MyBase.DataAccess.GetDataReader(transaction, query, paramInfo, hasRows, command)
        If hasRows = True Then
            result = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508
        Else
            result = ResultType.レコード無し
        End If
        '必ずクローズする必要があります。でないとエラーになる...
        MyBase.DataAccess.CloseReader(reader)

        Return result
    End Function

    Private Function ReadHANM006PrimaryKeyImpl(ByRef transaction As DbTransaction,
                                               ByRef 取得したデータ As DataTable,
                                               ByVal 倉庫コード As String
                     ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.SelectHANM006PrimaryKey(paramInfo, 倉庫コード)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function

    Private Function ReadHANM008PrimaryKeyImpl(ByRef transaction As DbTransaction,
                                               ByVal 備考コード As String
                     ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.SelectHANM008PrimaryKey(paramInfo, 備考コード)
        Dim reader As DbDataReader
        Dim hasRows As Boolean
        Dim command As DbCommand = Nothing
        reader = MyBase.DataAccess.GetDataReader(transaction, query, paramInfo, hasRows, command)
        If hasRows = True Then
            result = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508
        Else
            result = ResultType.レコード無し
        End If
        '必ずクローズする必要があります。でないとエラーになる...
        MyBase.DataAccess.CloseReader(reader)

        Return result
    End Function

    Private Function ReadHANM009PrimaryKeyImpl(ByRef transaction As DbTransaction,
                                               ByVal 摘要コード As String
                     ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.SelectHANM009PrimaryKey(paramInfo, 摘要コード)
        Dim reader As DbDataReader
        Dim hasRows As Boolean
        Dim command As DbCommand = Nothing
        reader = MyBase.DataAccess.GetDataReader(transaction, query, paramInfo, hasRows, command)
        If hasRows = True Then
            result = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508
        Else
            result = ResultType.レコード無し
        End If
        '必ずクローズする必要があります。でないとエラーになる...
        MyBase.DataAccess.CloseReader(reader)

        Return result
    End Function

    Private Function ReadHANM010PrimaryKeyImpl(ByRef transaction As DbTransaction,
                                               ByVal マスター区分 As Integer,
                                               ByVal 分類種別番号 As Integer,
                                               ByVal 分類コード As String
                 ) As Foundation.ResultType     'A-2008/07/18_Ver7.30_GENKA
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.SelectHANM010PrimaryKey(paramInfo, マスター区分, 分類種別番号, 分類コード)
        Dim reader As DbDataReader
        Dim hasRows As Boolean
        Dim command As DbCommand = Nothing
        reader = MyBase.DataAccess.GetDataReader(transaction, query, paramInfo, hasRows, command)
        If hasRows = True Then
            result = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508
        Else
            result = ResultType.レコード無し
        End If
        '必ずクローズする必要があります。でないとエラーになる...
        MyBase.DataAccess.CloseReader(reader)

        Return result
    End Function

    Private Function ReadHANM015PrimaryKeyImpl(ByRef transaction As DbTransaction,
                                               ByVal 部門コード As String
                     ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.SelectHANM015PrimaryKey(paramInfo, 部門コード)
        Dim reader As DbDataReader
        Dim hasRows As Boolean
        Dim command As DbCommand = Nothing
        reader = MyBase.DataAccess.GetDataReader(transaction, query, paramInfo, hasRows, command)
        If hasRows = True Then
            result = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508
        Else
            result = ResultType.レコード無し
        End If
        '必ずクローズする必要があります。でないとエラーになる...
        MyBase.DataAccess.CloseReader(reader)

        Return result
    End Function

    Private Function ReadHANM021PrimaryKeyImpl(ByRef transaction As DbTransaction,
                                               ByVal 内訳種別 As Integer,
                                               ByVal 内訳コード As String
                     ) As Foundation.ResultType 'A-2009/12/18_Ver7.40_UCHIWAKE
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.SelectHANM021PrimaryKey(paramInfo, 内訳種別, 内訳コード)
        Dim reader As DbDataReader
        Dim hasRows As Boolean
        Dim command As DbCommand = Nothing
        reader = MyBase.DataAccess.GetDataReader(transaction, query, paramInfo, hasRows, command)
        If hasRows = True Then
            result = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508
        Else
            result = ResultType.レコード無し
        End If
        '必ずクローズする必要があります。でないとエラーになる...
        MyBase.DataAccess.CloseReader(reader)

        Return result
    End Function

    Private Function ReadHANM023PrimaryKeyImpl(ByRef transaction As DbTransaction,
                                               ByRef 取得したデータ As DataTable,
                                               ByVal 読込キー As ProgramLib.商品内訳マスター型
                     ) As Foundation.ResultType 'A-2009/12/18_Ver7.40_UCHIWAKE
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.SelectHANM023PrimaryKey(paramInfo, 読込キー)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function

    Private Function ReadHANM031PrimaryKeyImpl(ByRef transaction As DbTransaction,
                                               ByVal 参照定義コード As String,
                                               ByVal コード As String
                     ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.SelectHANM031PrimaryKey(paramInfo, 参照定義コード, コード)
        Dim reader As DbDataReader
        Dim hasRows As Boolean
        Dim command As DbCommand = Nothing
        reader = MyBase.DataAccess.GetDataReader(transaction, query, paramInfo, hasRows, command)
        If hasRows = True Then
            result = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508
        Else
            result = ResultType.レコード無し
        End If
        '必ずクローズする必要があります。でないとエラーになる...
        MyBase.DataAccess.CloseReader(reader)

        Return result
    End Function

    Private Function ReadHANM036PrimaryKeyImpl(ByRef transaction As DbTransaction,
                                               ByVal 営業所コード As String
                     ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.SelectHANM036PrimaryKey(paramInfo, 営業所コード)
        Dim reader As DbDataReader
        Dim hasRows As Boolean
        Dim command As DbCommand = Nothing
        reader = MyBase.DataAccess.GetDataReader(transaction, query, paramInfo, hasRows, command)
        If hasRows = True Then
            result = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508
        Else
            result = ResultType.レコード無し
        End If
        '必ずクローズする必要があります。でないとエラーになる...
        MyBase.DataAccess.CloseReader(reader)

        Return result
    End Function

    Private Function ReadHANM040PrimaryKeyImpl(ByRef transaction As DbTransaction,
                                               ByRef 取得したデータ As DataTable,
                                               ByVal 原価集計メインコード As String,
                                               ByVal 原価集計サブコード As String
                     ) As Foundation.ResultType     'A-2008/07/18_Ver7.30_GENKA
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.SelectHANM040PrimaryKey(paramInfo, 原価集計メインコード, 原価集計サブコード)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function

    Private Function ReadHANM045PrimaryKeyImpl(ByRef transaction As DbTransaction,
                                               ByRef 取得したデータ As DataTable,
                                               ByVal 読込キー As ProgramLib.ロットマスター型
                     ) As Foundation.ResultType 'A-2009/12/18_Ver7.40_LOT
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.SelectHANM045PrimaryKey(paramInfo, 読込キー)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function

    Private Function ReadSEIR009PrimaryKeyImpl(ByRef transaction As DbTransaction,
                                               ByRef 取得したデータ As DataTable,
                                               ByVal 商品コード As String,
                                               ByVal ロットNO As String
                     ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = ""

        query = _queryMaker.SelectSEIR009PrimaryKey(paramInfo, 商品コード, ロットNO)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = Foundation.ResultType.成功
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function

    Private Function ReadSEIR010PrimaryKeyImpl(ByRef transaction As DbTransaction,
                                               ByRef 取得したデータ As DataTable,
                                               ByVal 処理連番 As Long
                     ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = ""

        query = _queryMaker.SelectSEIR010PrimaryKey(paramInfo, 処理連番)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = Foundation.ResultType.成功
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function

    Private Function ReadSEIR010返品伝票存在Impl(ByRef transaction As DbTransaction,
                                                 ByVal 処理連番 As Long
                 ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.SelectSEIR010返品伝票存在(paramInfo, 処理連番)
        Dim reader As DbDataReader
        Dim hasRows As Boolean
        Dim command As DbCommand = Nothing
        reader = MyBase.DataAccess.GetDataReader(transaction, query, paramInfo, hasRows, command)
        If hasRows = True Then
            result = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508
        Else
            result = ResultType.レコード無し
        End If
        '必ずクローズする必要があります。でないとエラーになる...
        MyBase.DataAccess.CloseReader(reader)

        Return result
    End Function

    Private Function ReadSEIR055PrimaryKeyImpl(ByRef transaction As DbTransaction,
                                               ByRef 取得したデータ As DataTable,
                                               ByVal 手配番号 As Long
                     ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = ""

        query = _queryMaker.SelectSEIR055PrimaryKey(paramInfo, 手配番号)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = Foundation.ResultType.成功
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function

    Private Function ReadSEIR055前後工程取得Impl(ByRef transaction As DbTransaction,
                                                 ByRef 取得したデータ As DataTable,
                                                 ByVal 手配管理番号 As Long,
                                                 ByVal 手順番号 As Integer,
                                                 ByVal 前後工程 As Integer
                     ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = ""

        query = _queryMaker.SelectSEIR055前後工程取得(paramInfo, 手配管理番号, 手順番号, 前後工程)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = Foundation.ResultType.成功
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function

    'A-20160324_2↓
    Private Function ReadSEIR055_SEIM050同時取得Impl(ByRef transaction As DbTransaction,
                                                     ByRef 取得したデータ As DataTable,
                                                     ByVal 手配番号 As Long
                     ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = ""

        query = _queryMaker.SelectSEIR055_SEIM050同時取得(paramInfo, 手配番号)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = Foundation.ResultType.成功
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function
    'A-20160324_2↑

    Private Function ReadSEIR056PrimaryKeyImpl(ByRef transaction As DbTransaction,
                                               ByRef 取得したデータ As DataTable,
                                               ByVal 手配番号 As Long,
                                               ByVal 展開順序番号 As Integer,
                                               ByVal 支給管理 As Integer
                     ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = ""

        query = _queryMaker.SelectSEIR056PrimaryKey(paramInfo, 手配番号, 展開順序番号, 支給管理)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = Foundation.ResultType.成功
            取得したデータ = table
        Else
            result = ResultType.レコード無し
            取得したデータ = table.Clone
        End If

        Return result
    End Function

    Private Function ReadSEIR057PrimaryKeyImpl(ByRef transaction As DbTransaction,
                                               ByRef 取得したデータ As DataTable,
                                               ByVal 手配番号 As Long) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = ""

        query = _queryMaker.SelectSEIR057PrimaryKey(paramInfo, 手配番号)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = Foundation.ResultType.成功
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result

    End Function

    'A-20121217_Ver7.50_2↓
    Private Function ReadSEIR057工程明細取得Impl(ByRef transaction As DbTransaction,
                                                 ByRef 取得したデータ As DataTable,
                                                 ByVal 処理連番 As Long) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = ""

        query = _queryMaker.SelectSEIR057工程明細取得(paramInfo, 処理連番)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = Foundation.ResultType.成功
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result

    End Function
    'A-20121217_Ver7.50_2↑

    Private Function ReadSEIR057実績数量合計Impl(ByRef transaction As DbTransaction,
                                                 ByRef 取得したデータ As DataTable,
                                                 ByVal 手配番号 As Long) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = ""

        query = _queryMaker.SelectSEIR057実績数量合計(paramInfo, 手配番号)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = Foundation.ResultType.成功
        Else
            result = ResultType.レコード無し
        End If
        取得したデータ = table

        Return result

    End Function

    Private Function ReadSEIM012PrimaryKeyImpl(ByRef transaction As DbTransaction,
                                               ByVal 費目コード As String
                     ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.SelectSEIM012PrimaryKey(paramInfo, 費目コード)
        Dim reader As DbDataReader
        Dim hasRows As Boolean
        Dim command As DbCommand = Nothing
        reader = MyBase.DataAccess.GetDataReader(transaction, query, paramInfo, hasRows, command)
        If hasRows = True Then
            result = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508
        Else
            result = ResultType.レコード無し
        End If
        '必ずクローズする必要があります。でないとエラーになる...
        MyBase.DataAccess.CloseReader(reader)

        Return result
    End Function

    Private Function ReadSEIM050PrimaryKeyImpl(ByRef transaction As DbTransaction,
                                               ByRef 取得したデータ As DataTable,
                                               ByVal 製番 As String
                 ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = ""

        query = _queryMaker.SelectSEIM050PrimaryKey(paramInfo, 製番)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = Foundation.ResultType.成功
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function

    Private Function ReadSEIM053PrimaryKeyImpl(ByRef transaction As DbTransaction,
                                               ByRef 取得したデータ As DataTable,
                                               ByVal 工程コード As String
                 ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = ""

        query = _queryMaker.SelectSEIM053PrimaryKey(paramInfo, 工程コード)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = Foundation.ResultType.成功
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function

    Private Function ReadHANR001PrimaryKeyImpl(ByRef transaction As DbTransaction,
                                               ByRef 取得したデータ As DataTable,
                                               ByVal 処理連番 As Long,
                                               Optional ByVal 明細区分 As Integer = -1,
                                               Optional ByVal 行番号 As Integer = -1,
                                               Optional ByVal 相手存在チェック As Boolean = False
                     ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = ""

        query = _queryMaker.SelectHANR001PrimaryKey(paramInfo, 処理連番, 明細区分, 行番号, 相手存在チェック)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = Foundation.ResultType.成功
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function

    Private Function ReadHANR001PrimaryKeyImpl(ByRef transaction As DbTransaction,
                                               ByRef 取得したデータ As DataTable,
                                               ByVal 取引区分 As Integer,
                                               ByVal 処理連番 As Long
                     ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = ""

        query = _queryMaker.SelectHANR001PrimaryKey(paramInfo, 取引区分, 処理連番)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = Foundation.ResultType.成功
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function

    Private Function ReadHANR001出庫伝票存在Impl(ByRef transaction As DbTransaction,
                                                 ByVal 処理連番 As Long,
                                                 Optional ByVal 取引区分 As Integer = -1
                 ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.SelectHANR001出庫伝票存在(paramInfo, 処理連番, 取引区分)
        Dim reader As DbDataReader
        Dim hasRows As Boolean
        Dim command As DbCommand = Nothing
        reader = MyBase.DataAccess.GetDataReader(transaction, query, paramInfo, hasRows, command)
        If hasRows = True Then
            result = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508
        Else
            result = ResultType.レコード無し
        End If
        '必ずクローズする必要があります。でないとエラーになる...
        MyBase.DataAccess.CloseReader(reader)

        Return result
    End Function

    Private Function ReadHANR001入庫伝票取得Impl(ByRef transaction As DbTransaction,
                                                 ByRef 取得したデータ As DataTable,
                                                 ByVal 処理連番 As Long
                     ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = ""

        query = _queryMaker.SelectHANR001入庫伝票取得(paramInfo, 処理連番)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = Foundation.ResultType.成功
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function

    'A-20120125_2↓
    Private Function ReadHANR001出庫伝票取得Impl(ByRef transaction As DbTransaction,
                                                 ByRef 取得したデータ As DataTable,
                                                 ByVal 処理連番 As Long
                     ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = ""

        query = _queryMaker.SelectHANR001出庫伝票存在(paramInfo, 処理連番, -1)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = Foundation.ResultType.成功
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function
    'A-20120125_2↑

    'A-20121217_Ver7.50_1↓
    Private Function ReadHANR001按分済受入伝票Impl(ByRef transaction As DbTransaction,
                                                   ByRef 取得したデータ As DataTable,
                                                   ByVal 諸掛管理番号 As String
                         ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = ""

        query = _queryMaker.SelectHANR001按分済受入伝票(paramInfo, 諸掛管理番号)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = Foundation.ResultType.成功
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function
    'A-20121217_Ver7.50_1↑

    Private Function ReadHANR004PrimaryKeyImpl(ByRef transaction As DbTransaction,
                                               ByRef 取得したデータ As DataTable,
                                               ByVal 発注番号 As Long
                     ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.SelectHANR004PrimaryKey(paramInfo, 発注番号)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function

    Private Function ReadHANR005PrimaryKeyImpl(ByRef transaction As DbTransaction,
                                               ByRef 取得したデータ As DataTable,
                                               ByVal 発注番号 As Long,
                                               ByVal 発注行番号 As Integer
                     ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.SelectHANR005PrimaryKey(paramInfo, 発注番号, 発注行番号)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function

    Private Function ReadHANR005関連受注Impl(ByRef transaction As DbTransaction,
                                             ByRef 取得したデータ As DataTable,
                                             ByVal 受注番号 As Long,
                                             ByVal 受注行番号 As Integer
                     ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.SelectHANR005関連受注(paramInfo, 受注番号, 受注行番号)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function

    Private Function ReadHANR005見込受注Impl(ByRef transaction As DbTransaction,
                                             ByRef 取得したデータ As DataTable,
                                             ByVal 発注番号 As Long
                     ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.SelectHANR005見込受注(paramInfo, 発注番号)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function

    Private Function ReadHANR005原価集計制御情報Impl(ByRef transaction As DbTransaction,
                                                     ByRef 取得したデータ As DataTable,
                                                     ByVal 発注番号 As Long,
                                                     ByVal 発注行番号 As Integer
                     ) As Foundation.ResultType     'A-2008/07/18_Ver7.30_GENKA
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.SelectHANR005原価集計制御情報(paramInfo, 発注番号, 発注行番号)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function

    'A-20121217_Ver7.50_2↓
    Private Function ReadHANR005元需要受注伝票Impl(ByRef transaction As DbTransaction,
                                                   ByRef 取得したデータ As DataTable,
                                                   ByVal 製番 As String,
                                                   ByVal 品目 As String
                     ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.SelectHANR005元需要受注伝票(paramInfo, 製番, 品目)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)

        result = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508
        取得したデータ = table

        Return result
    End Function
    'A-20121217_Ver7.50_2↑

    Private Function ReadSEIR008PrimaryKeyImpl(ByRef transaction As DbTransaction,
                                               ByRef 取得したデータ As DataTable,
                                               ByVal 処理連番 As Long,
                                               ByVal 行番号 As Integer
                     ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = ""

        query = _queryMaker.SelectSEIR008PrimaryKey(paramInfo, 処理連番, 行番号)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = Foundation.ResultType.成功
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function

    Private Function ReadSEIR008_自動ロットImpl(ByRef transaction As DbTransaction,
                                                ByRef 取得したデータ As DataTable,
                                                ByVal 倉庫コード As String,
                                                ByVal 商品コード As String,
                                                ByVal 期首年月 As Integer
                     ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = ""

        query = _queryMaker.SelectSEIR008_自動ロット(paramInfo, 倉庫コード, 商品コード, 期首年月)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = Foundation.ResultType.成功
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function

    'D-20111124_3↓
    'Private Function ReadSEIR008_ロット明細合計Impl(ByRef transaction As DbTransaction, _
    '                                                ByRef 取得したデータ As DataTable, _
    '                                                ByVal 処理連番 As Long, _
    '                                                Optional ByVal 処理連番CH As Long = -1 _
    '                 ) As Foundation.ResultType
    'D-20111124_3↑
    'A-20111124_3↓
    Private Function ReadSEIR008_ロット明細合計Impl(ByRef transaction As DbTransaction,
                                                    ByRef 取得したデータ As DataTable,
                                                    ByVal 処理連番 As Long,
                                                    Optional ByVal 処理連番CH As Long = -1,
                                                    Optional ByVal 倉庫移動出庫処理連番 As Long = -1,
                                                    Optional ByVal 入出庫区分 As 入出庫区分型 = 入出庫区分型.入庫
                     ) As Foundation.ResultType
        'A-20111124_3↑
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = ""

        'query = _queryMaker.SelectSEIR008ロット明細合計(paramInfo, 処理連番, 処理連番CH)                                   'A-20111124_3
        query = _queryMaker.SelectSEIR008ロット明細合計(paramInfo, 処理連番, 処理連番CH, 倉庫移動出庫処理連番, 入出庫区分)  'A-20111124_3
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = Foundation.ResultType.成功
        Else
            result = ResultType.レコード無し
        End If
        取得したデータ = table

        Return result
    End Function

    Private Function ReadSEIR008出庫伝票合計Impl(ByRef transaction As DbTransaction,
                                                 ByRef 取得したデータ As DataTable,
                                                 ByVal 手配番号 As Long,
                                                 ByVal 処理連番 As Long
                     ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = ""

        query = _queryMaker.SelectSEIR008出庫伝票合計(paramInfo, 手配番号, 処理連番)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = Foundation.ResultType.成功
        Else
            result = ResultType.レコード無し
        End If
        取得したデータ = table

        Return result
    End Function

    Private Function ReadSEIR008関連ロット明細Impl(ByRef transaction As DbTransaction,
                                                   ByRef 取得したデータ As DataTable,
                                                   ByVal 手配番号 As Long, ByVal 展開順序番号 As Integer) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = ""

        query = _queryMaker.SelectSEIR008関連ロット明細(paramInfo, 手配番号, 展開順序番号)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = Foundation.ResultType.成功
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result

    End Function

    Private Function ReadHANR031PrimaryKeyImpl(ByRef transaction As DbTransaction,
                                               ByRef 取得したデータ As DataTable,
                                               ByVal 伝票処理連番 As Long
                     ) As Foundation.ResultType     'A-2008/07/18_Ver7.30_SHIHARAI
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.SelectHANR031PrimaryKey(paramInfo, 伝票処理連番)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function

    Private Function ReadHANR032PrimaryKeyImpl(ByRef transaction As DbTransaction,
                                               ByVal 支払予定データ As ProgramLib.支払予定テーブル型
                     ) As Foundation.ResultType     'A-2008/07/18_Ver7.30_SHIHARAI
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.SelectHANR032PrimaryKey(paramInfo, 支払予定データ)
        Dim reader As DbDataReader
        Dim hasRows As Boolean
        Dim command As DbCommand = Nothing
        reader = MyBase.DataAccess.GetDataReader(transaction, query, paramInfo, hasRows, command)
        If hasRows = True Then
            result = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508
        Else
            result = ResultType.レコード無し
        End If
        '必ずクローズする必要があります。でないとエラーになる...
        MyBase.DataAccess.CloseReader(reader)

        Return result
    End Function

    Private Function ReadHANS002PrimaryKeyImpl(ByRef transaction As DbTransaction,
                                               ByRef 取得したデータ As DataTable,
                                               ByVal 仕入先コード As String,
                                               ByVal 対象年月 As Integer
                     ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.SelectHANS002PrimaryKey(paramInfo, 仕入先コード, 対象年月)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function

    'A-20121217_Ver7.50_1↓
    Private Function ReadSEIS005PrimaryKeyImpl(ByRef transaction As DbTransaction,
                                               ByRef 取得したデータ As DataTable,
                                               ByVal 仕入先コード As String,
                                               ByVal 対象年月 As Integer
                     ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.SelectSEIS005PrimaryKey(paramInfo, 仕入先コード, 対象年月)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function
    'A-20121217_Ver7.50_1↑

    Private Function ReadHANZ034PrimaryKeyImpl(ByRef transaction As DbTransaction,
                                               ByVal 明細区分 As Integer,
                                               Optional ByVal 入力パターン番号 As String = "0000"
                     ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.SelectHANZ034PrimaryKey(paramInfo, 明細区分, 入力パターン番号)
        Dim reader As DbDataReader
        Dim hasRows As Boolean
        Dim command As DbCommand = Nothing
        reader = MyBase.DataAccess.GetDataReader(transaction, query, paramInfo, hasRows, command)
        If hasRows = True Then
            result = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508
        Else
            result = ResultType.レコード無し
        End If
        '必ずクローズする必要があります。でないとエラーになる...
        MyBase.DataAccess.CloseReader(reader)

        Return result
    End Function

    Private Function ReadHANW091任意項目Impl(ByRef transaction As DbTransaction,
                                             ByVal 分割コード As String,
                                             ByVal 任意項目１ As String
                     ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.SelectHANW091任意項目(paramInfo, 分割コード, 任意項目１)
        Dim reader As DbDataReader
        Dim hasRows As Boolean
        Dim command As DbCommand = Nothing
        reader = MyBase.DataAccess.GetDataReader(transaction, query, paramInfo, hasRows, command)
        If hasRows = True Then
            result = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508
        Else
            result = ResultType.レコード無し
        End If
        '複数存在する場合があるので...
        MyBase.DataAccess.CancelCommand(command)
        '必ずクローズする必要があります。でないとエラーになる...
        MyBase.DataAccess.CloseReader(reader)

        Return result
    End Function

    Private Function ReadZAIR001UpdateLockImpl(ByRef transaction As DbTransaction,
                                               ByRef 取得したデータ As DataTable,
                                               ByVal 処理連番 As Long
                     ) As Foundation.ResultType     'A-2008/07/18_Ver7.30_SAIMU
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.SelectZAIR001UpdateLock(paramInfo, 処理連番)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function

    Private Function ReadZAIR101UpdateLockImpl(ByRef transaction As DbTransaction,
                                               ByRef 取得したデータ As DataTable,
                                               ByVal 処理連番 As Long
                     ) As Foundation.ResultType     'A-2010/09/13_Ver7.4X_ZAISHONIN
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.SelectZAIR101UpdateLock(paramInfo, 処理連番)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function

    Private Function ReadZAIR204会計債務消込チェックImpl(ByRef transaction As DbTransaction,
                                                         ByRef 取得したデータ As DataTable,
                                                         ByVal 処理連番 As Long
                     ) As Foundation.ResultType     'A-2008/07/18_Ver7.30_SAIMU
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.SelectZAIR204会計債務消込チェック(paramInfo, 処理連番)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function

    Private Function ReadZAIR205会計支払状態チェックImpl(ByRef transaction As DbTransaction,
                                                         ByRef 取得したデータ As DataTable,
                                                         ByVal 処理連番 As Long
                     ) As Foundation.ResultType     'A-2008/07/18_Ver7.30_SAIMU
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.SelectZAIR205会計支払状態チェック(paramInfo, 処理連番)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function

    Private Function ReadZAIR502完成原価自動振替チェックImpl(ByRef transaction As DbTransaction,
                                                             ByRef 取得したデータ As DataTable,
                                                             ByVal 処理連番 As Long
                     ) As Foundation.ResultType     'A-2009/12/18_Ver7.40_PRO
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = _queryMaker.SelectZAIR502完成原価自動振替チェック(paramInfo, 処理連番)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = OSK.X1.Foundation.ResultType.成功    'X1変換Tool-20170508
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function

    'D-20150520_1↓
    'Private Function Read製造出庫Impl(ByRef transaction As DbTransaction, _
    '                                  ByRef 取得したデータ As DataTable, _
    '                                  ByVal 処理連番 As Long, _
    '                                  ByVal 手配番号 As Long, _
    '                                  ByVal 構成品出庫区分 As Integer, _
    '                                  ByVal 支給管理 As Integer _
    '            ) As Foundation.ResultType
    'D-20150520_1↑
    'A-20150520_1↓
    Private Function Read製造出庫Impl(ByRef transaction As DbTransaction,
                                      ByRef 取得したデータ As DataTable,
                                      ByVal 処理連番 As Long,
                                      ByVal 手配番号 As Long,
                                      ByVal 構成品出庫区分 As Integer,
                                      ByVal 支給管理 As Integer,
                                      ByVal 対象年月度 As Integer
                ) As Foundation.ResultType
        'A-20150520_1↑
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = ""

        'query = _queryMaker.Select製造出庫(paramInfo, 処理連番, 手配番号, 構成品出庫区分, 支給管理)                    'D-20150520_1
        query = _queryMaker.Select製造出庫(paramInfo, 処理連番, 手配番号, 構成品出庫区分, 支給管理, 対象年月度)         'A-20150520_1
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = Foundation.ResultType.成功
        Else
            result = ResultType.レコード無し
        End If

        取得したデータ = table

        Return result
    End Function

    Private Function Read個別出庫Impl(ByRef transaction As DbTransaction,
                                      ByRef 取得したデータ As DataTable,
                                      ByVal 処理連番 As Long
                ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = ""

        query = _queryMaker.Select個別出庫(paramInfo, 処理連番)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = Foundation.ResultType.成功
        Else
            result = ResultType.レコード無し
        End If

        取得したデータ = table

        Return result
    End Function

    Private Function Readロット明細Impl(ByRef transaction As DbTransaction,
                                        ByRef 取得したデータ As DataTable,
                                        ByVal 明細区分 As Integer,
                                        ByVal 取引区分 As Integer,
                                        ByVal 処理連番 As Long,
                                        ByVal 行番号 As Integer
                ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = ""

        query = _queryMaker.Selectロット明細(paramInfo, 明細区分, 取引区分, 処理連番, 行番号)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = Foundation.ResultType.成功
        Else
            result = ResultType.レコード無し
        End If

        取得したデータ = table

        Return result
    End Function
    'A-20110912_1↓
    Private Function ReadHANR001SKImpl(ByRef transaction As DbTransaction,
                                    ByRef 取得したデータ As DataTable,
                                    ByVal 処理連番 As Long) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = ""

        query = _queryMaker.SelectHANR001SK(paramInfo, 処理連番)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = Foundation.ResultType.成功
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function

    Private Function ReadSEIW053前後工程仕掛取得Impl(ByRef transaction As DbTransaction,
                                                 ByRef 取得したデータ As DataTable,
                                                 ByVal 手配管理番号 As Long,
                                                 ByVal 手順番号F As Integer,
                                                 ByVal 手順番号T As Integer
                     ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = ""

        query = _queryMaker.SelectSEIW053前後工程仕掛取得(paramInfo, 手配管理番号, 手順番号F, 手順番号T)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = Foundation.ResultType.成功
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function
    'A-20110912_1↑

    'A-20120125_1↓
    Private Function ReadSEIS003仕掛在庫数量取得Impl(ByRef transaction As DbTransaction,
                                                     ByRef 取得したデータ As DataTable,
                                                     ByVal 内外区分 As Integer,
                                                     ByVal 手配先コード As String,
                                                     ByVal 品目コード As String,
                                                     ByVal 手順No As Integer,
                                                     ByVal 当期期首年月度 As Integer
                     ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = ""

        query = _queryMaker.SelectSEIS003仕掛在庫数量取得(paramInfo, 内外区分, 手配先コード, 品目コード, 手順No, 当期期首年月度)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = Foundation.ResultType.成功
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function
    'A-20120125_1↑

    'A-20130304_1↓
    Private Function ReadSEIR010分納実績取得Impl(ByRef transaction As DbTransaction,
                                                 ByRef 取得したデータ As DataTable,
                                                 ByVal 発注番号 As Long,
                                                 ByVal 処理連番 As Long
                 ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = ""
        query = _queryMaker.SelectSEIR010分納実績取得(paramInfo, 発注番号, 処理連番)

        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = Foundation.ResultType.成功
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function
    'A-20130304_1↑

    'A-20130304_2↓
    Public Function Read元需要Impl(ByRef transaction As DbTransaction,
                                   ByRef 取得したデータ As DataTable,
                                   ByVal 発注区分 As Integer,
                                   ByVal 発注番号 As Long,
                                   ByVal 手配管理番号 As Long
                ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = ""
        Dim table As New DataTable

        '*** 元需要 受注伝票取得
        '発注区分=1:購買 かつ 製番マスタ.受注形態=1:個別 の場合
        paramInfo = New ParamInfoList
        query = _queryMaker.Select元需要_個別受注(paramInfo, 発注番号)
        table = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)

        If table.Rows.Count > 0 Then
            取得したデータ = table
            Return result
        End If

        '*** 元需要 従属需要予定取得
        paramInfo = New ParamInfoList
        query = _queryMaker.Select元需要_従属需要予定(paramInfo, 発注区分, 発注番号, 手配管理番号)
        table = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)

        If table.Rows.Count > 0 Then
            取得したデータ = table
            Return result
        End If

        '*** 元需要 従属需要取得
        paramInfo = New ParamInfoList
        'query = _queryMaker.Select元需要_従属需要予定(paramInfo, 発注区分, 発注番号, 手配管理番号)   'D-20130612_1
        query = _queryMaker.Select元需要_従属需要(paramInfo, 発注区分, 発注番号, 手配管理番号)        'A-20130612_1
        table = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)

        If table.Rows.Count > 0 Then
            取得したデータ = table
            Return result
        End If

        result = ResultType.レコード無し

        Return result
    End Function
    'A-20130304_2↑

    'A-20130402_2↓
    Private Function ReadDataCommonImpl(ByRef transaction As DbTransaction,
                                        ByRef 取得したデータ As DataTable,
                                        ByVal targetData As readDataType,
                                        ByVal ParamArray key() As String) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing    'X1変換Tool-20170508
        Dim query As String = ""

        Select Case targetData
            Case readDataType.ロット明細_構成品
                Dim 処理連番 As Long = CLng(key(0))
                Dim 処理連番CH As Long = CLng(key(1))
                Dim 倉庫移動出庫処理連番 As Long = CLng(key(2))
                Dim 入出庫区分 As 入出庫区分型 = CType(key(3), 入出庫区分型)
                query = _queryMaker.SelectSEIR008ロット明細_構成品(paramInfo, 処理連番, 処理連番CH, 倉庫移動出庫処理連番, 入出庫区分)
        End Select


        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = Foundation.ResultType.成功
        Else
            result = ResultType.レコード無し
        End If
        取得したデータ = table

        Return result
    End Function
    'A-20130402_2↑

    ''' <summary>
    ''' テーブルに列を設定する
    ''' </summary>
    ''' <param name="reader">reader</param>
    ''' <param name="table">datatable</param>
    ''' <remarks></remarks>
    Private Sub SetUpTable(ByVal reader As DbDataReader, ByRef table As DataTable)

        Dim dc As DataColumn
        For i As Integer = 0 To reader.FieldCount - 1
            dc = New DataColumn(reader.GetName(i), reader(i).GetType)
            table.Columns.Add(dc)
        Next

    End Sub

    ''' <summary>
    ''' 行データを設定する
    ''' </summary>
    ''' <param name="reader"></param>
    ''' <param name="table"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function MakeNewDataRow(ByVal reader As DbDataReader, ByVal table As DataTable) As DataRow

        Dim dr As DataRow
        dr = table.NewRow()
        For i As Integer = 0 To reader.FieldCount - 1
            dr(reader.GetName(i)) = reader.GetValue(i)
        Next
        Return dr

    End Function

    'A-CUST20190830↓
    Private Function Read発注伝票_CUST(ByRef transaction As DbTransaction,
                                               ByRef 取得したデータ As DataTable,
                                               ByVal 発注番号 As Long,
                                               ByVal 発注行番号 As Integer
                     ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing
        Dim query As String = _queryMaker.Select発注伝票CUST(paramInfo, 発注番号, 発注行番号)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = OSK.X1.Foundation.ResultType.成功
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function

    Private Function Read入出荷予定伝票_CUST(ByRef transaction As DbTransaction,
                                               ByRef 取得したデータ As DataTable,
                                               ByVal 入出荷予定番号 As Long,
                                               ByVal 入出荷予定行番号 As Integer
                     ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing
        Dim query As String = _queryMaker.Select入出荷予定伝票CUST(paramInfo, 入出荷予定番号, 入出荷予定行番号)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = OSK.X1.Foundation.ResultType.成功
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function

    Private Function Read入出荷予定伝票_CUST(ByRef transaction As DbTransaction,
                                               ByRef 取得したデータ As DataTable,
                                               ByVal 入出荷予定番号 As Long
                     ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing
        Dim query As String = _queryMaker.Select入出荷予定伝票CUST(paramInfo, 入出荷予定番号)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = OSK.X1.Foundation.ResultType.成功
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function

    Private Function Read入出荷予定ヘッダー_CUST(ByRef transaction As DbTransaction,
                                               ByRef 取得したデータ As DataTable,
                                               ByVal 入出荷予定番号 As Long
                     ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing
        Dim query As String = _queryMaker.Select入出荷予定ヘッダーCUST(paramInfo, 入出荷予定番号)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = OSK.X1.Foundation.ResultType.成功
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function

    Private Function Read入出荷予定明細_CUST(ByRef transaction As DbTransaction,
                                               ByRef 取得したデータ As DataTable,
                                               ByVal 入出荷予定番号 As Long,
                                               ByVal 入出荷予定行番号 As Integer
                     ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing
        Dim query As String = _queryMaker.Select入出荷予定明細CUST(paramInfo, 入出荷予定番号, 入出荷予定行番号)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = OSK.X1.Foundation.ResultType.成功
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function

    Private Function Read発注内訳伝票_CUST(ByRef transaction As DbTransaction,
                                           ByRef 取得したデータ As DataTable,
                                           ByVal 発注番号 As Long,
                                           ByVal 発注行番号 As Integer,
                                           ByVal 内訳番号 As Integer
                 ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing
        Dim query As String = _queryMaker.Select発注内訳伝票CUST(paramInfo, 発注番号, 発注行番号, 内訳番号)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = OSK.X1.Foundation.ResultType.成功
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function

    Private Function ReadSEIMA02PrimaryKeyImpl(ByRef transaction As DbTransaction,
                                           ByRef 取得したデータ As DataTable,
                                           ByVal コード As String
                 ) As Foundation.ResultType
        Dim result As New Foundation.ResultType

        Dim paramInfo As OSK.X1.DataAccess.ParamInfoList = Nothing
        Dim query As String = _queryMaker.SelectSEIMA02PrimaryKey(paramInfo, コード)
        Dim table As DataTable = MyBase.DataAccess.GetDataTable(transaction, query, paramInfo)
        If table.Rows.Count > 0 Then
            result = OSK.X1.Foundation.ResultType.成功
            取得したデータ = table
        Else
            result = ResultType.レコード無し
        End If

        Return result
    End Function
    'A-CUST20190830↑

#End Region

End Class
