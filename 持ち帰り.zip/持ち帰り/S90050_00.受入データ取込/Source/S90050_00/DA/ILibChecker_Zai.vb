﻿'A-2008/07/18_Ver7.30_SAIMU ※クラス追加
Public Interface ILibChecker_Zai
    Inherits IInsideDataHandler

    Enum 会計チェック結果型
        成功
        日付範囲エラー
    End Enum

    Property MyImportParam() As S90050_00.ImportParam

    Function DoDateCheck(ByRef transaction As DbTransaction, ByVal 対象日付 As String) As 会計チェック結果型

End Interface
