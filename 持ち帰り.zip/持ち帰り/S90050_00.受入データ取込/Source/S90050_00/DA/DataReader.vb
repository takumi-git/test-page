﻿Public Class DataReader
    Inherits TextFileImport.DataAccess.DataReaderBase

    Protected Overrides Function CreateTextDataConvertor(ByVal readParam As TextFileImport.IReportDataReadParam) As Foundation.TextFileImport.ITextDataConvertor
        Return New TextDataConvertor
    End Function

    Protected Overrides Function EditReportData(ByRef connection As DbConnection, _
                                                ByVal readParam As TextFileImport.IReportDataReadParam, _
                                                ByRef reportDataBlock As List(Of TextFileImportLib.ReportData型)) As Boolean

        Dim テキスト内容配列() As String = Nothing
        Dim table As New DataTable
        Dim reportData As TextFileImportLib.ReportData型

        For iData As Integer = 0 To reportDataBlock.Count - 1
            reportData = reportDataBlock(iData)
            ReDim テキスト内容配列(仕入データ型._項目数 - 1)

            Call _textDataConvertor.ConvertData(reportData.テキスト内容, テキスト内容配列)

            reportData.テキスト内容帳票出力用 = Join(テキスト内容配列, TextFileImportLib.TAB_STRING)
            reportDataBlock(iData) = reportData

        Next

        Return True
    End Function

End Class
