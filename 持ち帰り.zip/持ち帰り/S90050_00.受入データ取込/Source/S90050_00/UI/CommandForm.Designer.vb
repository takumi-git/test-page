﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CommandForm
    Inherits OSK.X1.Foundation.TextFileImport.UserInterface.CommandFormBase

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim Item11 As OSK.X1.Foundation.Controls.GroupOptionImpl.Item = New OSK.X1.Foundation.Controls.GroupOptionImpl.Item
        Dim Item12 As OSK.X1.Foundation.Controls.GroupOptionImpl.Item = New OSK.X1.Foundation.Controls.GroupOptionImpl.Item
        Dim Item9 As OSK.X1.Foundation.Controls.GroupOptionImpl.Item = New OSK.X1.Foundation.Controls.GroupOptionImpl.Item
        Dim Item10 As OSK.X1.Foundation.Controls.GroupOptionImpl.Item = New OSK.X1.Foundation.Controls.GroupOptionImpl.Item
        Dim Item7 As OSK.X1.Foundation.Controls.GroupOptionImpl.Item = New OSK.X1.Foundation.Controls.GroupOptionImpl.Item
        Dim Item8 As OSK.X1.Foundation.Controls.GroupOptionImpl.Item = New OSK.X1.Foundation.Controls.GroupOptionImpl.Item
        Dim Item4 As OSK.X1.Foundation.Controls.GroupOptionImpl.Item = New OSK.X1.Foundation.Controls.GroupOptionImpl.Item
        Dim Item5 As OSK.X1.Foundation.Controls.GroupOptionImpl.Item = New OSK.X1.Foundation.Controls.GroupOptionImpl.Item
        Dim Item6 As OSK.X1.Foundation.Controls.GroupOptionImpl.Item = New OSK.X1.Foundation.Controls.GroupOptionImpl.Item
        Dim Item1 As OSK.X1.Foundation.Controls.GroupOptionImpl.Item = New OSK.X1.Foundation.Controls.GroupOptionImpl.Item
        Dim Item2 As OSK.X1.Foundation.Controls.GroupOptionImpl.Item = New OSK.X1.Foundation.Controls.GroupOptionImpl.Item
        Dim Item3 As OSK.X1.Foundation.Controls.GroupOptionImpl.Item = New OSK.X1.Foundation.Controls.GroupOptionImpl.Item
        Me.overWrite = New OSK.X1.Foundation.SimpleControl.CheckBox
        Me.renbanSaiban = New OSK.X1.Foundation.SimpleControl.GroupOption
        Me.denpyoNoSaiban = New OSK.X1.Foundation.SimpleControl.GroupOption
        Me.lotNoSaiban = New OSK.X1.Foundation.SimpleControl.GroupOption
        Me.HacchuZanOverCheckPanel = New OSK.X1.Foundation.SimpleControl.GroupOption
        Me.KannoZumiCheckPanel = New OSK.X1.Foundation.SimpleControl.GroupOption
        Me.conditionTabPage.SuspendLayout()
        Me.textLayoutBox.SuspendLayout()
        Me.filePathPanel.SuspendLayout()
        Me.updateStylePanel.SuspendLayout()
        Me.tab.SuspendLayout()
        Me.baseContainer.ContentPanel.SuspendLayout()
        Me.baseContainer.SuspendLayout()
        Me.SuspendLayout()
        '
        'conditionTabPage
        '
        Me.conditionTabPage.Controls.Add(Me.KannoZumiCheckPanel)
        Me.conditionTabPage.Controls.Add(Me.HacchuZanOverCheckPanel)
        Me.conditionTabPage.Controls.Add(Me.lotNoSaiban)
        Me.conditionTabPage.Controls.Add(Me.denpyoNoSaiban)
        Me.conditionTabPage.Controls.Add(Me.renbanSaiban)
        Me.conditionTabPage.Size = New System.Drawing.Size(501, 571)
        Me.conditionTabPage.Controls.SetChildIndex(Me.itemNumberTextImport, 0)
        Me.conditionTabPage.Controls.SetChildIndex(Me.filePathPanel, 0)
        Me.conditionTabPage.Controls.SetChildIndex(Me.textLayoutBox, 0)
        Me.conditionTabPage.Controls.SetChildIndex(Me.updateStylePanel, 0)
        Me.conditionTabPage.Controls.SetChildIndex(Me.renbanSaiban, 0)
        Me.conditionTabPage.Controls.SetChildIndex(Me.denpyoNoSaiban, 0)
        Me.conditionTabPage.Controls.SetChildIndex(Me.lotNoSaiban, 0)
        Me.conditionTabPage.Controls.SetChildIndex(Me.HacchuZanOverCheckPanel, 0)
        Me.conditionTabPage.Controls.SetChildIndex(Me.KannoZumiCheckPanel, 0)
        '
        'itemNumberTextImport
        '
        Me.itemNumberTextImport.Location = New System.Drawing.Point(9, 279)
        Me.itemNumberTextImport.TabIndex = 5
        '
        'textLayoutBox
        '
        Me.textLayoutBox.Location = New System.Drawing.Point(9, 304)
        Me.textLayoutBox.TabIndex = 6
        '
        'filePathPanel
        '
        Me.filePathPanel.Location = New System.Drawing.Point(9, 177)
        Me.filePathPanel.TabIndex = 4
        '
        'updateStylePanel
        '
        Me.updateStylePanel.Controls.Add(Me.overWrite)
        Me.updateStylePanel.Location = New System.Drawing.Point(9, 381)
        Me.updateStylePanel.TabIndex = 7
        Me.updateStylePanel.Controls.SetChildIndex(Me.topRowTitleCheck, 0)
        Me.updateStylePanel.Controls.SetChildIndex(Me.overWrite, 0)
        '
        'tab
        '
        Me.tab.Size = New System.Drawing.Size(507, 601)
        '
        'baseContainer
        '
        Me.baseContainer.BottomToolStripPanelVisible = True
        '
        'baseContainer.ContentPanel
        '
        Me.baseContainer.ContentPanel.Size = New System.Drawing.Size(632, 625)
        Me.baseContainer.LeftToolStripPanelVisible = True
        Me.baseContainer.RightToolStripPanelVisible = True
        Me.baseContainer.Size = New System.Drawing.Size(632, 697)
        Me.baseContainer.TopToolStripPanelVisible = True
        '
        'overWrite
        '
        Me.overWrite.CheckState = System.Windows.Forms.CheckState.Unchecked
        Me.overWrite.DependCheckState = False
        Me.overWrite.DrawFocusFrame = True
        Me.overWrite.FocusBackColor = System.Drawing.Color.Empty
        Me.overWrite.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.overWrite.IndeterminateText = ""
        Me.overWrite.Location = New System.Drawing.Point(9, 43)
        Me.overWrite.Name = "overWrite"
        Me.overWrite.RemarkString = Nothing
        Me.overWrite.Size = New System.Drawing.Size(442, 19)
        Me.overWrite.TabIndex = 1
        Me.overWrite.Text = "同一処理連番存在時は上書き"
        Me.overWrite.UncheckedText = ""
        '
        'renbanSaiban
        '
        Me.renbanSaiban.FocusBackColor = System.Drawing.Color.Empty
        Me.renbanSaiban.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.renbanSaiban.ItemCount = 2
        Item11.Enabled = True
        Item11.Text = "入力処理連番を採用する"
        Item11.Visible = True
        Item12.Enabled = True
        Item12.Text = "新規に採番する"
        Item12.Visible = True
        Me.renbanSaiban.Items = New OSK.X1.Foundation.Controls.GroupOptionImpl.Item() {Item11, Item12}
        Me.renbanSaiban.Location = New System.Drawing.Point(9, 9)
        Me.renbanSaiban.Name = "renbanSaiban"
        Me.renbanSaiban.RemarkString = Nothing
        Me.renbanSaiban.Size = New System.Drawing.Size(484, 50)
        Me.renbanSaiban.TabIndex = 1
        Me.renbanSaiban.Title = "処理連番の採番方法"
        '
        'denpyoNoSaiban
        '
        Me.denpyoNoSaiban.FocusBackColor = System.Drawing.Color.Empty
        Me.denpyoNoSaiban.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.denpyoNoSaiban.ItemCount = 2
        Item9.Enabled = True
        Item9.Text = "入力伝票№を採用する"
        Item9.Visible = True
        Item10.Enabled = True
        Item10.Text = "新規に採番する"
        Item10.Visible = True
        Me.denpyoNoSaiban.Items = New OSK.X1.Foundation.Controls.GroupOptionImpl.Item() {Item9, Item10}
        Me.denpyoNoSaiban.Location = New System.Drawing.Point(9, 65)
        Me.denpyoNoSaiban.Name = "denpyoNoSaiban"
        Me.denpyoNoSaiban.RemarkString = Nothing
        Me.denpyoNoSaiban.Size = New System.Drawing.Size(484, 50)
        Me.denpyoNoSaiban.TabIndex = 2
        Me.denpyoNoSaiban.Title = "伝票№の採番方法"
        '
        'lotNoSaiban
        '
        Me.lotNoSaiban.FocusBackColor = System.Drawing.Color.Empty
        Me.lotNoSaiban.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.lotNoSaiban.ItemCount = 2
        Item7.Enabled = True
        Item7.Text = "入力ロット№を採用する"
        Item7.Visible = True
        Item8.Enabled = True
        Item8.Text = "新規に採番する"
        Item8.Visible = True
        Me.lotNoSaiban.Items = New OSK.X1.Foundation.Controls.GroupOptionImpl.Item() {Item7, Item8}
        Me.lotNoSaiban.Location = New System.Drawing.Point(9, 121)
        Me.lotNoSaiban.Name = "lotNoSaiban"
        Me.lotNoSaiban.RemarkString = Nothing
        Me.lotNoSaiban.Size = New System.Drawing.Size(484, 50)
        Me.lotNoSaiban.TabIndex = 3
        Me.lotNoSaiban.Title = "ロット№の採番方法"
        '
        'HacchuZanOverCheckPanel
        '
        Me.HacchuZanOverCheckPanel.FocusBackColor = System.Drawing.Color.Empty
        Me.HacchuZanOverCheckPanel.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.HacchuZanOverCheckPanel.ItemCount = 3
        Item4.Enabled = True
        Item4.Text = "なし"
        Item4.Visible = True
        Item5.Enabled = True
        Item5.Text = "警告"
        Item5.Visible = True
        Item6.Enabled = True
        Item6.Text = "エラー"
        Item6.Visible = True
        Me.HacchuZanOverCheckPanel.Items = New OSK.X1.Foundation.Controls.GroupOptionImpl.Item() {Item4, Item5, Item6}
        Me.HacchuZanOverCheckPanel.Location = New System.Drawing.Point(9, 458)
        Me.HacchuZanOverCheckPanel.Name = "HacchuZanOverCheckPanel"
        Me.HacchuZanOverCheckPanel.RemarkString = Nothing
        Me.HacchuZanOverCheckPanel.Size = New System.Drawing.Size(484, 50)
        Me.HacchuZanOverCheckPanel.TabIndex = 8
        Me.HacchuZanOverCheckPanel.Title = "発注残以上のデータ取込チェック"
        '
        'KannoZumiCheckPanel
        '
        Me.KannoZumiCheckPanel.FocusBackColor = System.Drawing.Color.Empty
        Me.KannoZumiCheckPanel.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.KannoZumiCheckPanel.ItemCount = 3
        Item1.Enabled = True
        Item1.Text = "なし"
        Item1.Visible = True
        Item2.Enabled = True
        Item2.Text = "警告"
        Item2.Visible = True
        Item3.Enabled = True
        Item3.Text = "エラー"
        Item3.Visible = True
        Me.KannoZumiCheckPanel.Items = New OSK.X1.Foundation.Controls.GroupOptionImpl.Item() {Item1, Item2, Item3}
        Me.KannoZumiCheckPanel.Location = New System.Drawing.Point(9, 514)
        Me.KannoZumiCheckPanel.Name = "KannoZumiCheckPanel"
        Me.KannoZumiCheckPanel.RemarkString = Nothing
        Me.KannoZumiCheckPanel.Size = New System.Drawing.Size(484, 50)
        Me.KannoZumiCheckPanel.TabIndex = 9
        Me.KannoZumiCheckPanel.Title = "完納済みデータ取込チェック"
        '
        'CommandForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.ClientSize = New System.Drawing.Size(632, 721)
        Me.Name = "CommandForm"
        Me.conditionTabPage.ResumeLayout(False)
        Me.textLayoutBox.ResumeLayout(False)
        Me.filePathPanel.ResumeLayout(False)
        Me.updateStylePanel.ResumeLayout(False)
        Me.tab.ResumeLayout(False)
        Me.baseContainer.ContentPanel.ResumeLayout(False)
        Me.baseContainer.ContentPanel.PerformLayout()
        Me.baseContainer.ResumeLayout(False)
        Me.baseContainer.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents overWrite As OSK.X1.Foundation.SimpleControl.CheckBox
    Friend WithEvents renbanSaiban As OSK.X1.Foundation.SimpleControl.GroupOption
    Friend WithEvents denpyoNoSaiban As OSK.X1.Foundation.SimpleControl.GroupOption
    Friend WithEvents lotNoSaiban As OSK.X1.Foundation.SimpleControl.GroupOption
    Friend WithEvents HacchuZanOverCheckPanel As OSK.X1.Foundation.SimpleControl.GroupOption
    Friend WithEvents KannoZumiCheckPanel As OSK.X1.Foundation.SimpleControl.GroupOption
End Class
