﻿'A-CUST20190830↓
Public Class TextConvert
    Inherits OSK.X1.Foundation.UserInterface.InsideJobBase

    Public Function File_convert(ByVal targetfilepath As String, ByVal target出力filepath As String, ByVal targetfilename() As String,
                                                                 ByVal 文字コード() As String, ByVal renban As Long, ByVal 先頭行はタイトル As CheckState,
                                                                 ByVal dataAccess As IMasterReader) As Boolean

        Dim InputTXT As TextExp = New TextExp
        Dim OutputTXT As TextExp = New TextExp
        Dim kugiri As String = vbTab
        Dim str As String = ""
        Dim GetData1 As List(Of String) = New List(Of String)
        Dim Getcount As Integer = 0

        Dim ｼｽﾃﾑ日付 As Integer = CInt(Format$(Now, "yyyyMMdd"))

        '取込対象ファイルを指定
        Dim ReadFile As String
        ReadFile = targetfilepath & "\" & targetfilename(0)

        '出力対象ファイルを指定
        Dim WriteFile As String
        WriteFile = target出力filepath & "\" & targetfilename(1)

        'テキストファイルのパスを指定
        InputTXT.InputFileName = ReadFile
        OutputTXT.OutputFileName = WriteFile

        'テキストファイルの文字コードを指定
        InputTXT.文字コード = 文字コード(0)
        OutputTXT.文字コード = 文字コード(1)

        'テキストオープン
        InputTXT.InputText_Open()
        OutputTXT.OutputText_Open()

        'テキストを読み込み値を保持
        GetData1 = InputTXT.Text_SetList()

        '取込ファイル用のDataTableを作成
        Dim FormatDt As New DataTable
        Dim dataFormatter As New DataFormatter

        '作成したテーブルの編集作業
        dataFormatter.GetData1 = GetData1
        dataFormatter.Settinginfo = SettinginfoCUST
        dataFormatter.Renban = renban

        Dim textData As String()
        'テキスト書き込み
        Dim Start As Integer = 0

        Dim 区切 As String = vbTab

        '想定外のファイル(項目多いor少ない場合)
        Dim templine As String() = Nothing
        For 行数 As Integer = Start To GetData1.Count - 1
            Dim 項目数 As Integer = Split(GetData1(行数), 区切).Length

            If 項目数 <> 出力位置型._項目数 Then
                '補完またはカット
                For i As Integer = 項目数 To 出力位置型._項目数
                    GetData1(行数) &= 区切 & " "
                Next
                templine = Split(GetData1(行数), 区切)
            End If
        Next

        '発注情報の取得
        Dim 発注情報取得 As Boolean = False
        Dim readData発注情報 As New DataTable
        Dim 受発注番号 As String = ""
        Dim 内訳番号 As String = ""

        '入出荷予定情報の取得
        Dim 入出荷予定情報取得 As Boolean = False
        Dim readData入出荷予定情報 As New DataTable
        Dim 入出荷予定番号 As String = ""
        Dim 入出荷予定行番号 As String = ""

        For i As Integer = Start To GetData1.Count - 1
            textData = Split(GetData1(i), vbTab)
            Dim 編集データ As String = ""
            Dim line As String()
            line = Split(GetData1(i), 区切)

            If IsNumeric(line(出力位置型._001)) = True Then

                If CInt(line(出力位置型._001)) = 1 OrElse CInt(line(出力位置型._001)) = 3 Then
                    '----------発注----------
                    受発注番号 = CStr(line(出力位置型._002))
                    内訳番号 = CStr(line(出力位置型._004))
                    '型のチェックが必要！
                    If テキスト値チェック(受発注番号, チェック対象型.受発注番号) = True AndAlso テキスト値チェック(内訳番号, チェック対象型.内訳番号) = True Then
                        Dim param同時仕入先 As New ReadParam
                        param同時仕入先.Container(ReadParam.項目名型.受発注番号) = 受発注番号
                        param同時仕入先.Container(ReadParam.項目名型.受発注行番号) = 1
                        param同時仕入先.Container(ReadParam.項目名型.内訳NO) = 内訳番号
                        If ReadMaster_発注情報(param同時仕入先, readData発注情報, dataAccess) = False Then
                            編集データ &= ""
                            '空行セット
                            readData発注情報.Clear()
                            InitializeDataTable発注情報(readData発注情報)
                        End If
                    Else
                        '空行セット
                        readData発注情報.Clear()
                        InitializeDataTable発注情報(readData発注情報)
                    End If

                ElseIf CInt(line(出力位置型._001)) = 2 Then
                    '----------入出荷予定----------
                    入出荷予定番号 = CStr(line(出力位置型._002))
                    入出荷予定行番号 = CStr(line(出力位置型._003))
                    内訳番号 = CStr(line(出力位置型._004))
                    '型のチェックが必要！
                    If テキスト値チェック(入出荷予定番号, チェック対象型.受発注番号) = True AndAlso テキスト値チェック(入出荷予定行番号, チェック対象型.受発注行番号) = True Then
                        Dim param入出荷予定 As New ReadParam
                        param入出荷予定.Container(ReadParam.項目名型.入庫予定番号) = 入出荷予定番号
                        param入出荷予定.Container(ReadParam.項目名型.入庫予定行番号) = 入出荷予定行番号
                        param入出荷予定.Container(ReadParam.項目名型.内訳NO) = 内訳番号    'テキスト.内訳No
                        If ReadMaster_入出庫予定情報(param入出荷予定, readData入出荷予定情報, dataAccess) = False Then
                            編集データ &= ""
                            '空行セット
                            readData入出荷予定情報.Clear()
                            InitializeDataTable入出荷予定(readData入出荷予定情報)
                        End If
                    Else
                        '空行セット
                        readData入出荷予定情報.Clear()
                        InitializeDataTable入出荷予定(readData入出荷予定情報)
                    End If

                Else

                End If

            Else
                line(出力位置型._001) = "0"
            End If


            '★が付いている項目はDA側でセット
            For col As Integer = 0 To 仕入データ型._項目数 - 1

                If CInt(line(出力位置型._001)) = 1 OrElse CInt(line(出力位置型._001)) = 3 Then
                    '----------発注----------
                    Select Case col
                        Case 仕入データ型.伝票日付 : 編集データ &= ｼｽﾃﾑ日付                                  'ｼｽﾃﾑ日付
                        Case 仕入データ型.入荷番号 : 編集データ &= 0                                         '★
                        Case 仕入データ型.受入番号 : 編集データ &= i + 1                                     'テキストの行番号
                        Case 仕入データ型.処理連番 : 編集データ &= i + 1                                     'テキストの行番号
                        Case 仕入データ型.明細区分 : 編集データ &= 0
                        Case 仕入データ型.行番号 : 編集データ &= 1                                         '1固定
                        Case 仕入データ型.製番 : 編集データ &= CStr(readData発注情報.Rows(0).Item("MHCHR05_HANR005A004"))  '発注明細.製番
                        Case 仕入データ型.仕入先コード : 編集データ &= CStr(readData発注情報.Rows(0).Item("MHCHR05_HANR005006"))  '発注明細.仕入先コード
                        Case 仕入データ型.仕入先名１ : 編集データ &= ""
                        Case 仕入データ型.仕入先名２ : 編集データ &= ""
                        Case 仕入データ型.担当者コード : 編集データ &= CStr(readData発注情報.Rows(0).Item("MHCHR05_HANR005007"))
                        Case 仕入データ型.部門コード : 編集データ &= CStr(readData発注情報.Rows(0).Item("HHCHR04_HANR004012"))
                        Case 仕入データ型.営業所コード : 編集データ &= ""
                        Case 仕入データ型.支払区分 : 編集データ &= 0
                        Case 仕入データ型.買掛区分 : 編集データ &= CInt(readData発注情報.Rows(0).Item("HHCHR04_HANR004018"))
                        Case 仕入データ型.取引区分 : 編集データ &= CInt(readData発注情報.Rows(0).Item("MHCHR05_HANR005009"))
                        Case 仕入データ型.取引区分属性 : 編集データ &= CInt(readData発注情報.Rows(0).Item("MHCHR05_HANR005052"))
                        Case 仕入データ型.倉庫コード : 編集データ &= CStr(readData発注情報.Rows(0).Item("MHCHR05_HANR005016"))
                        Case 仕入データ型.ロケーション : 編集データ &= line(出力位置型._008)
                        Case 仕入データ型.ロット_Ｎｏ
                            If CInt(readData発注情報.Rows(0).Item("MHCHM03_HANM003A024")) = 0 Then
                                編集データ &= line(出力位置型._007)
                            Else
                                編集データ &= ""
                            End If

                        Case 仕入データ型.有効期限 : 編集データ &= 0        '★

                        Case 仕入データ型.商品コード : 編集データ &= line(出力位置型._005)                     'テキスト.商品コード
                        Case 仕入データ型.商品名 : 編集データ &= CStr(readData発注情報.Rows(0).Item("MHCHR05_HANR005018"))
                        Case 仕入データ型.品名１ : 編集データ &= CStr(readData発注情報.Rows(0).Item("MHCHR05_HANR005A001"))
                        Case 仕入データ型.品名２ : 編集データ &= CStr(readData発注情報.Rows(0).Item("MHCHR05_HANR005A002"))
                        Case 仕入データ型.品名３ : 編集データ &= CStr(readData発注情報.Rows(0).Item("MHCHR05_HANR005A003"))
                        Case 仕入データ型.工程コード : 編集データ &= ""
                        Case 仕入データ型.完成品区分 : 編集データ &= 1                                         '1固定
                        Case 仕入データ型.入数 : 編集データ &= 0
                        Case 仕入データ型.個数 : 編集データ &= 0
                        Case 仕入データ型.個数単位 : 編集データ &= ""
                        Case 仕入データ型.数量 : 編集データ &= line(出力位置型._006)                     'テキスト.納品数
                        Case 仕入データ型.数量単位 : 編集データ &= CStr(readData発注情報.Rows(0).Item("MHCHR05_HANR005A024"))
                        Case 仕入データ型.単価 : 編集データ &= CDec(readData発注情報.Rows(0).Item("MHCHR05_HANR005024"))        'テキスト.単価
                        Case 仕入データ型.金額 : 編集データ &= 0    '★
                        Case 仕入データ型.上代単価 : 編集データ &= 0
                        Case 仕入データ型.単価掛率 : 編集データ &= CDec(readData発注情報.Rows(0).Item("MHCHR05_HANR005028"))
                        Case 仕入データ型.課税区分 : 編集データ &= CInt(readData発注情報.Rows(0).Item("MHCHR05_HANR005035"))
                        Case 仕入データ型.上代課税区分 : 編集データ &= 0
                        Case 仕入データ型.消費税率 : 編集データ &= CDec(readData発注情報.Rows(0).Item("MHCHR05_HANR005036"))
                        Case 仕入データ型.内消費税等 : 編集データ &= 0    '★
                        Case 仕入データ型.明細消費税等 : 編集データ &= 0
                        Case 仕入データ型.不良数量 : 編集データ &= 0
                        Case 仕入データ型.完納区分 : 編集データ &= 0
                        Case 仕入データ型.行摘要コード : 編集データ &= CStr(readData発注情報.Rows(0).Item("MHCHR05_HANR005039"))
                        Case 仕入データ型.行摘要１ : 編集データ &= CStr(readData発注情報.Rows(0).Item("MHCHR05_HANR005040"))
                        Case 仕入データ型.行摘要２ : 編集データ &= CStr(readData発注情報.Rows(0).Item("MHCHR05_HANR005041"))
                        Case 仕入データ型.備考コード : 編集データ &= CStr(readData発注情報.Rows(0).Item("HHCHR04_HANR004022"))
                        Case 仕入データ型.備考 : 編集データ &= CStr(readData発注情報.Rows(0).Item("HHCHR04_HANR004023"))
                        Case 仕入データ型.発注区分 : 編集データ &= CInt(readData発注情報.Rows(0).Item("HHCHR04_HANR004A010"))
                        Case 仕入データ型.発注番号 : 編集データ &= line(出力位置型._002)
                        Case 仕入データ型.自動生成区分 : 編集データ &= 0
                        Case 仕入データ型.消費税仮計上区分 : 編集データ &= 0
                        Case 仕入データ型.伝票消費税計算区分
                            Select Case True
                                Case CInt(readData発注情報.Rows(0).Item("HHCHM02SIR_HANM002048")) = 0 And
                                     CInt(readData発注情報.Rows(0).Item("HHCHM02SIR_HANM002050")) = 0
                                    編集データ &= 0
                                Case Else
                                    編集データ &= 1
                            End Select
                        Case 仕入データ型.明細消費税計算区分 : 編集データ &= 1                                         '1固定
                        Case 仕入データ型.データ発生区分 : 編集データ &= 0
                        Case 仕入データ型.拡張項目入力パターン番号 : 編集データ &= ""
                        Case 仕入データ型.伝票拡張項目０１ : 編集データ &= CStr(readData発注情報.Rows(0).Item("HHCHR30_HANR030007"))
                        Case 仕入データ型.伝票拡張項目０２ : 編集データ &= CStr(readData発注情報.Rows(0).Item("HHCHR30_HANR030008"))
                        Case 仕入データ型.伝票拡張項目０３ : 編集データ &= CStr(readData発注情報.Rows(0).Item("HHCHR30_HANR030009"))
                        Case 仕入データ型.伝票拡張項目０４ : 編集データ &= CStr(readData発注情報.Rows(0).Item("HHCHR30_HANR030010"))
                        Case 仕入データ型.伝票拡張項目０５ : 編集データ &= CStr(readData発注情報.Rows(0).Item("HHCHR30_HANR030011"))
                        Case 仕入データ型.伝票拡張項目０６ : 編集データ &= CStr(readData発注情報.Rows(0).Item("HHCHR30_HANR030012"))
                        Case 仕入データ型.伝票拡張項目０７ : 編集データ &= CStr(readData発注情報.Rows(0).Item("HHCHR30_HANR030013"))
                        Case 仕入データ型.伝票拡張項目０８ : 編集データ &= CStr(readData発注情報.Rows(0).Item("HHCHR30_HANR030014"))
                        Case 仕入データ型.伝票拡張項目０９ : 編集データ &= CStr(readData発注情報.Rows(0).Item("HHCHR30_HANR030015"))
                        Case 仕入データ型.伝票拡張項目１０ : 編集データ &= CStr(readData発注情報.Rows(0).Item("HHCHR30_HANR030016"))
                        Case 仕入データ型.伝票拡張項目１１ : 編集データ &= CStr(readData発注情報.Rows(0).Item("HHCHR30_HANR030017"))
                        Case 仕入データ型.伝票拡張項目１２ : 編集データ &= CStr(readData発注情報.Rows(0).Item("HHCHR30_HANR030018"))
                        Case 仕入データ型.伝票拡張項目１３ : 編集データ &= CStr(readData発注情報.Rows(0).Item("HHCHR30_HANR030019"))
                        Case 仕入データ型.伝票拡張項目１４ : 編集データ &= CStr(readData発注情報.Rows(0).Item("HHCHR30_HANR030020"))
                        Case 仕入データ型.伝票拡張項目１５ : 編集データ &= CStr(readData発注情報.Rows(0).Item("HHCHR30_HANR030021"))
                        Case 仕入データ型.伝票拡張項目１６ : 編集データ &= CStr(readData発注情報.Rows(0).Item("HHCHR30_HANR030022"))
                        Case 仕入データ型.伝票拡張項目１７ : 編集データ &= CStr(readData発注情報.Rows(0).Item("HHCHR30_HANR030023"))
                        Case 仕入データ型.伝票拡張項目１８ : 編集データ &= CStr(readData発注情報.Rows(0).Item("HHCHR30_HANR030024"))
                        Case 仕入データ型.伝票拡張項目１９ : 編集データ &= CStr(readData発注情報.Rows(0).Item("HHCHR30_HANR030025"))
                        Case 仕入データ型.伝票拡張項目２０ : 編集データ &= CStr(readData発注情報.Rows(0).Item("HHCHR30_HANR030026"))
                        Case 仕入データ型.伝票拡張項目付箋色番号 : 編集データ &= 0
                        Case 仕入データ型.明細拡張項目０１ : 編集データ &= CStr(readData発注情報.Rows(0).Item("MHCHR30_HANR030007"))
                        Case 仕入データ型.明細拡張項目０２ : 編集データ &= CStr(readData発注情報.Rows(0).Item("MHCHR30_HANR030008"))
                        Case 仕入データ型.明細拡張項目０３ : 編集データ &= CStr(readData発注情報.Rows(0).Item("MHCHR30_HANR030009"))
                        Case 仕入データ型.明細拡張項目０４ : 編集データ &= CStr(readData発注情報.Rows(0).Item("MHCHR30_HANR030010"))
                        Case 仕入データ型.明細拡張項目０５ : 編集データ &= CStr(readData発注情報.Rows(0).Item("MHCHR30_HANR030011"))
                        Case 仕入データ型.明細拡張項目０６ : 編集データ &= CStr(readData発注情報.Rows(0).Item("MHCHR30_HANR030012"))
                        Case 仕入データ型.明細拡張項目０７ : 編集データ &= CStr(readData発注情報.Rows(0).Item("MHCHR30_HANR030013"))
                        Case 仕入データ型.明細拡張項目０８ : 編集データ &= CStr(readData発注情報.Rows(0).Item("MHCHR30_HANR030014"))
                        Case 仕入データ型.明細拡張項目０９ : 編集データ &= CStr(readData発注情報.Rows(0).Item("MHCHR30_HANR030015"))
                        Case 仕入データ型.明細拡張項目１０ : 編集データ &= CStr(readData発注情報.Rows(0).Item("MHCHR30_HANR030016"))
                        Case 仕入データ型.明細拡張項目１１ : 編集データ &= CStr(readData発注情報.Rows(0).Item("MHCHR30_HANR030017"))
                        Case 仕入データ型.明細拡張項目１２ : 編集データ &= CStr(readData発注情報.Rows(0).Item("MHCHR30_HANR030018"))
                        Case 仕入データ型.明細拡張項目１３ : 編集データ &= CStr(readData発注情報.Rows(0).Item("MHCHR30_HANR030019"))
                        Case 仕入データ型.明細拡張項目１４ : 編集データ &= CStr(readData発注情報.Rows(0).Item("MHCHR30_HANR030020"))
                        Case 仕入データ型.明細拡張項目１５ : 編集データ &= CStr(readData発注情報.Rows(0).Item("MHCHR30_HANR030021"))
                        Case 仕入データ型.明細拡張項目１６ : 編集データ &= line(出力位置型._004)
                        Case 仕入データ型.明細拡張項目１７
                            If CInt(readData発注情報.Rows(0).Item("MHCHR05_HANR005A020")) = 2 Then
                                編集データ &= CStr(readData発注情報.Rows(0).Item("MHCHR30TE_HANR030023"))
                            Else
                                編集データ &= "0"
                            End If

                        Case 仕入データ型.明細拡張項目１８
                            If CInt(readData発注情報.Rows(0).Item("MHCHR05_HANR005A020")) = 2 Then
                                編集データ &= line(出力位置型._009)
                            Else
                                編集データ &= "000000"
                            End If

                        Case 仕入データ型.明細拡張項目１９ : 編集データ &= ""
                        Case 仕入データ型.明細拡張項目２０ : 編集データ &= ""
                        Case 仕入データ型.明細拡張項目付箋色番号 : 編集データ &= 0
                        Case 仕入データ型.計上区分 : 編集データ &= 0
                        Case 仕入データ型.仮単価区分 : 編集データ &= CInt(readData発注情報.Rows(0).Item("MHCHR05_HANR005A030"))
                        Case 仕入データ型.費目コード : 編集データ &= ""
                        'A-CUST20190830↓
                        Case 仕入データ型.レート : 編集データ &= 0
                        Case 仕入データ型.レート種類 : 編集データ &= 0
                        Case 仕入データ型.換算基準 : 編集データ &= 0
                        Case 仕入データ型.諸掛管理_Ｎｏ : 編集データ &= ""
                        Case 仕入データ型.按分対象 : 編集データ &= 0
                        Case 仕入データ型.按分基準 : 編集データ &= 0
                        Case 仕入データ型.INVOICE_Ｎｏ : 編集データ &= ""
                        Case 仕入データ型.レート固定区分 : 編集データ &= 0
                        Case 仕入データ型.原価計上手配番号 : 編集データ &= 0
                        'A-CUST20190830↑
                        Case 仕入データ型.構成品出庫生成区分
                            If CInt(readData発注情報.Rows(0).Item("MHCHR05_HANR005A020")) = 2 Then
                                編集データ &= 0                                         '0:自動
                            Else
                                編集データ &= 2                                         '2:(しない
                            End If

                        Case 仕入データ型.入出庫予定No : 編集データ &= 0
                        Case 仕入データ型.入出庫予定行No : 編集データ &= line(出力位置型._003)      'テキスト値をチェックする為。
                        Case 仕入データ型.データ区分 : 編集データ &= line(出力位置型._001)

                        Case 仕入データ型.伝票種別
                            If CInt(readData発注情報.Rows(0).Item("MHCHR05_HANR005A020")) = 1 Then
                                編集データ &= 伝票種別型._発注_購買
                            ElseIf CInt(readData発注情報.Rows(0).Item("MHCHR05_HANR005A020")) = 2 Then
                                編集データ &= 伝票種別型._発注_手配
                            Else
                                編集データ &= CInt(readData発注情報.Rows(0).Item("MHCHR05_HANR005A020"))
                            End If

                            '空欄設定
                        Case Else
                            編集データ &= ""


                    End Select
                    If col <> 仕入データ型._項目数 Then
                        編集データ &= vbTab
                    End If

                ElseIf CInt(line(出力位置型._001)) = 2 Then
                    '----------入出荷予定----------
                    Select Case col
                        Case 仕入データ型.伝票日付 : 編集データ &= ｼｽﾃﾑ日付                                  'ｼｽﾃﾑ日付
                        Case 仕入データ型.入荷番号 : 編集データ &= 0                                         '★
                        Case 仕入データ型.受入番号 : 編集データ &= i + 1                                     'テキストの行番号
                        Case 仕入データ型.処理連番 : 編集データ &= line(出力位置型._002)
                        Case 仕入データ型.明細区分 : 編集データ &= 0
                        Case 仕入データ型.行番号 : 編集データ &= 1                                         '1固定
                        Case 仕入データ型.製番 : 編集データ &= "          00"                                           '製番
                        Case 仕入データ型.仕入先コード : 編集データ &= "00000000"  '仕入先コード
                        Case 仕入データ型.仕入先名１ : 編集データ &= ""
                        Case 仕入データ型.仕入先名２ : 編集データ &= ""
                        Case 仕入データ型.担当者コード : 編集データ &= "000000"
                        Case 仕入データ型.部門コード : 編集データ &= "000000"
                        Case 仕入データ型.営業所コード : 編集データ &= "00000000"
                        Case 仕入データ型.支払区分 : 編集データ &= 0
                        Case 仕入データ型.買掛区分 : 編集データ &= 0
                        Case 仕入データ型.取引区分 : 編集データ &= CInt(readData入出荷予定情報.Rows(0).Item("MHCHRA03_SEIRA03006"))
                        Case 仕入データ型.取引区分属性 : 編集データ &= 0        '★
                        Case 仕入データ型.倉庫コード : 編集データ &= CStr(readData入出荷予定情報.Rows(0).Item("MHCHRA03_SEIRA03007"))
                        Case 仕入データ型.ロケーション : 編集データ &= line(出力位置型._008)
                        Case 仕入データ型.ロット_Ｎｏ
                            If CInt(readData入出荷予定情報.Rows(0).Item("MHCHM03_HANM003A024")) = 0 Then
                                編集データ &= line(出力位置型._007)
                            Else
                                編集データ &= ""
                            End If
                        Case 仕入データ型.有効期限 : 編集データ &= 0        '★

                        Case 仕入データ型.商品コード : 編集データ &= line(出力位置型._005)                     'テキスト.商品コード
                        Case 仕入データ型.商品名 : 編集データ &= CStr(readData入出荷予定情報.Rows(0).Item("MHCHM03_HANM003002"))
                        Case 仕入データ型.品名１ : 編集データ &= CStr(readData入出荷予定情報.Rows(0).Item("MHCHRA03_SEIRA03014"))
                        Case 仕入データ型.品名２ : 編集データ &= CStr(readData入出荷予定情報.Rows(0).Item("MHCHRA03_SEIRA03015"))
                        Case 仕入データ型.品名３ : 編集データ &= CStr(readData入出荷予定情報.Rows(0).Item("MHCHRA03_SEIRA03016"))
                        Case 仕入データ型.工程コード : 編集データ &= "000000"
                        Case 仕入データ型.完成品区分 : 編集データ &= 0
                        Case 仕入データ型.入数 : 編集データ &= 0
                        Case 仕入データ型.個数 : 編集データ &= 0
                        Case 仕入データ型.個数単位 : 編集データ &= ""
                        Case 仕入データ型.数量 : 編集データ &= line(出力位置型._006)                     'テキスト.納品数
                        Case 仕入データ型.数量単位 : 編集データ &= CStr(readData入出荷予定情報.Rows(0).Item("MHCHRA03_SEIRA03017"))
                        Case 仕入データ型.単価 : 編集データ &= 0    '★
                        Case 仕入データ型.金額 : 編集データ &= 0    '★
                        Case 仕入データ型.上代単価 : 編集データ &= 0
                        Case 仕入データ型.単価掛率 : 編集データ &= 0
                        Case 仕入データ型.課税区分 : 編集データ &= 0
                        Case 仕入データ型.上代課税区分 : 編集データ &= 0
                        Case 仕入データ型.消費税率 : 編集データ &= 0
                        Case 仕入データ型.内消費税等 : 編集データ &= 0
                        Case 仕入データ型.明細消費税等 : 編集データ &= 0
                        Case 仕入データ型.不良数量 : 編集データ &= 0
                        Case 仕入データ型.完納区分 : 編集データ &= 0
                        Case 仕入データ型.行摘要コード : 編集データ &= CStr(readData入出荷予定情報.Rows(0).Item("MHCHRA03_SEIRA03021"))
                        Case 仕入データ型.行摘要１ : 編集データ &= CStr(readData入出荷予定情報.Rows(0).Item("MHCHRA03_SEIRA03022"))
                        Case 仕入データ型.行摘要２ : 編集データ &= CStr(readData入出荷予定情報.Rows(0).Item("MHCHRA03_SEIRA03023"))
                        Case 仕入データ型.備考コード : 編集データ &= CStr(readData入出荷予定情報.Rows(0).Item("HHCHRA02_SEIRA02012"))
                        Case 仕入データ型.備考 : 編集データ &= CStr(readData入出荷予定情報.Rows(0).Item("HHCHRA02_SEIRA02013"))
                        Case 仕入データ型.発注区分 : 編集データ &= 0
                        Case 仕入データ型.発注番号 : 編集データ &= 0
                        Case 仕入データ型.自動生成区分 : 編集データ &= 0
                        Case 仕入データ型.消費税仮計上区分 : 編集データ &= 0
                        Case 仕入データ型.伝票消費税計算区分 : 編集データ &= 0
                        Case 仕入データ型.明細消費税計算区分 : 編集データ &= 1                                         '1固定
                        Case 仕入データ型.データ発生区分 : 編集データ &= 0
                        Case 仕入データ型.拡張項目入力パターン番号 : 編集データ &= ""
                        Case 仕入データ型.伝票拡張項目０１ To 仕入データ型.伝票拡張項目２０ : 編集データ &= ""
                        Case 仕入データ型.伝票拡張項目付箋色番号 : 編集データ &= 0
                        Case 仕入データ型.明細拡張項目０１ To 仕入データ型.明細拡張項目２０
                            編集データ &= ""

                            Select Case col
                                Case 仕入データ型.明細拡張項目１６ : 編集データ &= 0
                                Case 仕入データ型.明細拡張項目１７ : 編集データ &= 0
                                Case 仕入データ型.明細拡張項目１８ : 編集データ &= "000000"
                            End Select

                        Case 仕入データ型.明細拡張項目付箋色番号 : 編集データ &= 0
                        Case 仕入データ型.計上区分 : 編集データ &= 0
                        Case 仕入データ型.仮単価区分 : 編集データ &= 0
                        Case 仕入データ型.費目コード : 編集データ &= "000000"
                        'A-CUST20190830↓
                        Case 仕入データ型.レート : 編集データ &= 0
                        Case 仕入データ型.レート種類 : 編集データ &= 0
                        Case 仕入データ型.換算基準 : 編集データ &= 0
                        Case 仕入データ型.諸掛管理_Ｎｏ : 編集データ &= ""
                        Case 仕入データ型.按分対象 : 編集データ &= 0
                        Case 仕入データ型.按分基準 : 編集データ &= 0
                        Case 仕入データ型.INVOICE_Ｎｏ : 編集データ &= ""
                        Case 仕入データ型.レート固定区分 : 編集データ &= 0
                        Case 仕入データ型.原価計上手配番号 : 編集データ &= 0
                        'A-CUST20190830↑
                        Case 仕入データ型.構成品出庫生成区分 : 編集データ &= 2                                         '2:(しない
                        Case 仕入データ型.入出庫予定No : 編集データ &= line(出力位置型._002)
                        Case 仕入データ型.入出庫予定行No : 編集データ &= line(出力位置型._003)
                        Case 仕入データ型.データ区分 : 編集データ &= line(出力位置型._001)

                        Case 仕入データ型.伝票種別
                            If CInt(readData入出荷予定情報.Rows(0).Item("MHCHRA03_SEIRA03010")) * 100 + CInt(readData入出荷予定情報.Rows(0).Item("MHCHRA03_SEIRA03006")) = 102 Then
                                編集データ &= 伝票種別型._予定入庫_移動
                            Else
                                編集データ &= 伝票種別型._予定入庫_預入庫
                            End If

                            '空欄設定
                        Case Else
                            編集データ &= ""


                    End Select
                    If col <> 仕入データ型._項目数 Then
                        編集データ &= vbTab
                    End If

                Else
                    '想定外のデータ区分用(テキスト値のみセット)
                    Select Case col
                        Case 仕入データ型.伝票日付 : 編集データ &= ｼｽﾃﾑ日付                                  'ｼｽﾃﾑ日付
                        Case 仕入データ型.入荷番号 : 編集データ &= 0                                         '★
                        Case 仕入データ型.受入番号 : 編集データ &= i + 1                                     'テキストの行番号
                        Case 仕入データ型.処理連番 : 編集データ &= line(出力位置型._002)
                        Case 仕入データ型.明細区分 : 編集データ &= 0
                        Case 仕入データ型.行番号 : 編集データ &= 1                                         '1固定
                        Case 仕入データ型.製番 : 編集データ &= "          00"                                           '製番
                        Case 仕入データ型.仕入先コード : 編集データ &= "00000000"  '仕入先コード
                        Case 仕入データ型.仕入先名１ : 編集データ &= ""
                        Case 仕入データ型.仕入先名２ : 編集データ &= ""
                        Case 仕入データ型.担当者コード : 編集データ &= "000000"
                        Case 仕入データ型.部門コード : 編集データ &= "000000"
                        Case 仕入データ型.営業所コード : 編集データ &= "00000000"
                        Case 仕入データ型.支払区分 : 編集データ &= 0
                        Case 仕入データ型.買掛区分 : 編集データ &= 0
                        Case 仕入データ型.取引区分 : 編集データ &= 0
                        Case 仕入データ型.取引区分属性 : 編集データ &= 0        '★
                        Case 仕入データ型.倉庫コード : 編集データ &= ""
                        Case 仕入データ型.ロケーション : 編集データ &= line(出力位置型._008)
                        Case 仕入データ型.ロット_Ｎｏ : 編集データ &= line(出力位置型._007)
                        Case 仕入データ型.有効期限 : 編集データ &= 0        '★

                        Case 仕入データ型.商品コード : 編集データ &= line(出力位置型._005)                     'テキスト.商品コード
                        Case 仕入データ型.商品名 : 編集データ &= ""
                        Case 仕入データ型.品名１ : 編集データ &= ""
                        Case 仕入データ型.品名２ : 編集データ &= ""
                        Case 仕入データ型.品名３ : 編集データ &= ""
                        Case 仕入データ型.工程コード : 編集データ &= "000000"
                        Case 仕入データ型.完成品区分 : 編集データ &= 1                                         '1固定
                        Case 仕入データ型.入数 : 編集データ &= 0
                        Case 仕入データ型.個数 : 編集データ &= 0
                        Case 仕入データ型.個数単位 : 編集データ &= ""
                        Case 仕入データ型.数量 : 編集データ &= line(出力位置型._006)                     'テキスト.納品数
                        Case 仕入データ型.数量単位 : 編集データ &= ""
                        Case 仕入データ型.単価 : 編集データ &= 0    '★
                        Case 仕入データ型.金額 : 編集データ &= 0    '★
                        Case 仕入データ型.上代単価 : 編集データ &= 0
                        Case 仕入データ型.単価掛率 : 編集データ &= 0
                        Case 仕入データ型.課税区分 : 編集データ &= 0
                        Case 仕入データ型.上代課税区分 : 編集データ &= 0
                        Case 仕入データ型.消費税率 : 編集データ &= 0
                        Case 仕入データ型.内消費税等 : 編集データ &= 0
                        Case 仕入データ型.明細消費税等 : 編集データ &= 0
                        Case 仕入データ型.不良数量 : 編集データ &= 0
                        Case 仕入データ型.完納区分 : 編集データ &= 0
                        Case 仕入データ型.行摘要コード : 編集データ &= ""
                        Case 仕入データ型.行摘要１ : 編集データ &= ""
                        Case 仕入データ型.行摘要２ : 編集データ &= ""
                        Case 仕入データ型.備考コード : 編集データ &= ""
                        Case 仕入データ型.備考 : 編集データ &= ""
                        Case 仕入データ型.発注区分 : 編集データ &= 0
                        Case 仕入データ型.発注番号 : 編集データ &= 0
                        Case 仕入データ型.自動生成区分 : 編集データ &= 0
                        Case 仕入データ型.消費税仮計上区分 : 編集データ &= 0
                        Case 仕入データ型.伝票消費税計算区分 : 編集データ &= 0
                        Case 仕入データ型.明細消費税計算区分 : 編集データ &= 1                                         '1固定
                        Case 仕入データ型.データ発生区分 : 編集データ &= 0
                        Case 仕入データ型.拡張項目入力パターン番号 : 編集データ &= ""
                        Case 仕入データ型.伝票拡張項目０１ To 仕入データ型.伝票拡張項目２０ : 編集データ &= ""
                        Case 仕入データ型.伝票拡張項目付箋色番号 : 編集データ &= 0
                        Case 仕入データ型.明細拡張項目０１ To 仕入データ型.明細拡張項目２０ : 編集データ &= ""
                        Case 仕入データ型.明細拡張項目付箋色番号 : 編集データ &= 0
                        Case 仕入データ型.計上区分 : 編集データ &= 0
                        Case 仕入データ型.仮単価区分 : 編集データ &= 0
                        Case 仕入データ型.費目コード : 編集データ &= "000000"
                        'A-CUST20190830↓
                        Case 仕入データ型.レート : 編集データ &= 0
                        Case 仕入データ型.レート種類 : 編集データ &= 0
                        Case 仕入データ型.換算基準 : 編集データ &= 0
                        Case 仕入データ型.諸掛管理_Ｎｏ : 編集データ &= ""
                        Case 仕入データ型.按分対象 : 編集データ &= 0
                        Case 仕入データ型.按分基準 : 編集データ &= 0
                        Case 仕入データ型.INVOICE_Ｎｏ : 編集データ &= ""
                        Case 仕入データ型.レート固定区分 : 編集データ &= 0
                        Case 仕入データ型.原価計上手配番号 : 編集データ &= 0
                        'A-CUST20190830↑
                        Case 仕入データ型.構成品出庫生成区分 : 編集データ &= 2                                         '2:(しない
                        Case 仕入データ型.入出庫予定No : 編集データ &= line(出力位置型._002)
                        Case 仕入データ型.入出庫予定行No : 編集データ &= line(出力位置型._003)
                        Case 仕入データ型.データ区分 : 編集データ &= line(出力位置型._001)
                        Case 仕入データ型.伝票種別 : 編集データ &= 伝票種別型._想定外

                            '空欄設定
                        Case Else
                            編集データ &= ""


                    End Select
                    If col <> 仕入データ型._項目数 Then
                        編集データ &= vbTab
                    End If

                End If


            Next
            OutputTXT.Text_WriteLine(編集データ)
        Next

        'テキストクローズ
        InputTXT.InputText_Close()
        OutputTXT.OutputText_Close()

        Return True
    End Function

    '●元ファイルの内容をParamにセットする。(エラーリストやエラーテキスト出力時に使用する為)
    Public Function File_convert(ByVal targetfilepath As String,
                                 ByVal target出力filepath As String,
                                 ByVal targetfilename() As String,
                                 ByVal 文字コード() As String,
                                 ByVal renban As Long,
                                 ByRef param As ImportParam) As Boolean

        Dim InputTXT As TextExp = New TextExp
        Dim kugiri As String = vbTab
        Dim str As String = ""
        Dim GetData1 As List(Of String) = New List(Of String)
        Dim Getcount As Integer = 0

        '取込対象ファイルを指定
        Dim ReadFile As String
        ReadFile = targetfilepath & "\" & targetfilename(0)

        'テキストファイルのパスを指定
        InputTXT.InputFileName = ReadFile

        'テキストファイルの文字コードを指定
        InputTXT.文字コード = 文字コード(0)

        'テキストオープン
        InputTXT.InputText_Open()

        'テキストを読み込み値を保持
        GetData1 = InputTXT.Text_SetList()

        '取込ファイル用のDataTableを作成
        Dim FormatDt As New DataTable
        Dim dataFormatter As New DataFormatter

        '作成したテーブルの編集作業
        dataFormatter.GetData1 = GetData1
        dataFormatter.Settinginfo = SettinginfoCUST
        dataFormatter.Renban = renban

        'テキスト書き込み
        Dim 区切 As String = vbTab

        ReDim param.元ファイル内容(0 To GetData1.Count - 1)

        For i As Integer = 0 To GetData1.Count - 1

            '実テキストの項目数と、取込想定項目数が異なる場合を想定
            Dim 項目数 As Integer = Split(GetData1(i), 区切).Length
            If 項目数 <> 出力位置型._項目数 Then
                '補完またはカット
                For j As Integer = 項目数 To 出力位置型._項目数
                    GetData1(i) &= 区切 & " "
                Next
            End If

            param.入力元ファイル名 = ""
            param.元ファイル内容(i) = GetData1(i)
        Next

        'テキストクローズ
        InputTXT.InputText_Close()

        Return True
    End Function


#Region "プロパティ"

    Private _myコントロール情報 As Myコントロール情報型
    Public Property myコントロール情報() As Myコントロール情報型
        Get
            Return _myコントロール情報
        End Get
        Set(ByVal value As Myコントロール情報型)
            _myコントロール情報 = value
        End Set
    End Property

    Private _Settinginfo As IDictionary
    Public Property SettinginfoCUST() As IDictionary
        Get
            Return _Settinginfo
        End Get
        Set(ByVal value As IDictionary)
            _Settinginfo = value
        End Set
    End Property

#End Region

#Region "■データRead"

    ''' <summary>
    ''' 発注情報Read
    ''' </summary>
    ''' <param name="param"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ReadMaster_発注情報(ByVal param As ReadParam,
                                         ByRef readData As DataTable,
                                         ByVal dataAccess As IMasterReader) As Boolean

        Dim result As Boolean
        Dim resultData As DataTable

        resultData = dataAccess.MasterRead(IMasterReader.テーブル一覧型.発注情報, param)

        If resultData.Rows.Count > 0 Then
            result = True
            readData = resultData.Copy
        Else
            result = False
        End If

        Return result

    End Function

    ''' <summary>
    ''' 入出庫予定情報Read
    ''' </summary>
    ''' <param name="param"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ReadMaster_入出庫予定情報(ByVal param As ReadParam,
                                         ByRef readData As DataTable,
                                         ByVal dataAccess As IMasterReader) As Boolean

        Dim result As Boolean
        Dim resultData As DataTable

        resultData = dataAccess.MasterRead(IMasterReader.テーブル一覧型.入出庫予定情報, param)

        If resultData.Rows.Count > 0 Then
            result = True
            readData = resultData.Copy
        Else
            result = False
        End If

        Return result

    End Function
#End Region

#Region "内部メソッド"
    Private Sub InitializeDataTable発注情報(ByVal dt As DataTable)
        With dt.Columns
            .Clear()
            .Add(New DataColumn("HHCHR04_HANR004012", GetType(String)))
            .Add(New DataColumn("HHCHR04_HANR004018", GetType(Integer)))
            .Add(New DataColumn("HHCHR04_HANR004022", GetType(String)))
            .Add(New DataColumn("HHCHR04_HANR004023", GetType(String)))
            .Add(New DataColumn("HHCHR04_HANR004A010", GetType(Integer)))
            .Add(New DataColumn("HHCHM02SIR_HANM002050", GetType(Integer)))
            .Add(New DataColumn("HHCHR30_HANR030007", GetType(String)))
            .Add(New DataColumn("HHCHR30_HANR030008", GetType(String)))
            .Add(New DataColumn("HHCHR30_HANR030009", GetType(String)))
            .Add(New DataColumn("HHCHR30_HANR030010", GetType(String)))
            .Add(New DataColumn("HHCHR30_HANR030011", GetType(String)))
            .Add(New DataColumn("HHCHR30_HANR030012", GetType(String)))
            .Add(New DataColumn("HHCHR30_HANR030013", GetType(String)))
            .Add(New DataColumn("HHCHR30_HANR030014", GetType(String)))
            .Add(New DataColumn("HHCHR30_HANR030015", GetType(String)))
            .Add(New DataColumn("HHCHR30_HANR030016", GetType(String)))
            .Add(New DataColumn("HHCHR30_HANR030017", GetType(String)))
            .Add(New DataColumn("HHCHR30_HANR030018", GetType(String)))
            .Add(New DataColumn("HHCHR30_HANR030019", GetType(String)))
            .Add(New DataColumn("HHCHR30_HANR030020", GetType(String)))
            .Add(New DataColumn("HHCHR30_HANR030021", GetType(String)))
            .Add(New DataColumn("HHCHR30_HANR030022", GetType(String)))
            .Add(New DataColumn("HHCHR30_HANR030023", GetType(String)))
            .Add(New DataColumn("HHCHR30_HANR030024", GetType(String)))
            .Add(New DataColumn("HHCHR30_HANR030025", GetType(String)))
            .Add(New DataColumn("HHCHR30_HANR030026", GetType(String)))

            .Add(New DataColumn("MHCHR05_HANR005006", GetType(String)))
            .Add(New DataColumn("MHCHR05_HANR005007", GetType(String)))
            .Add(New DataColumn("MHCHR05_HANR005009", GetType(Integer)))
            .Add(New DataColumn("MHCHR05_HANR005016", GetType(String)))
            .Add(New DataColumn("MHCHR05_HANR005018", GetType(String)))
            .Add(New DataColumn("MHCHR05_HANR005024", GetType(Decimal)))
            .Add(New DataColumn("MHCHR05_HANR005028", GetType(Decimal)))
            .Add(New DataColumn("MHCHR05_HANR005035", GetType(Integer)))
            .Add(New DataColumn("MHCHR05_HANR005036", GetType(Decimal)))
            .Add(New DataColumn("MHCHR05_HANR005039", GetType(String)))
            .Add(New DataColumn("MHCHR05_HANR005040", GetType(String)))
            .Add(New DataColumn("MHCHR05_HANR005041", GetType(String)))
            .Add(New DataColumn("MHCHR05_HANR005052", GetType(Integer)))
            .Add(New DataColumn("MHCHR05_HANR005A001", GetType(String)))
            .Add(New DataColumn("MHCHR05_HANR005A002", GetType(String)))
            .Add(New DataColumn("MHCHR05_HANR005A003", GetType(String)))
            .Add(New DataColumn("MHCHR05_HANR005A004", GetType(String)))
            .Add(New DataColumn("MHCHR05_HANR005A020", GetType(Integer)))
            .Add(New DataColumn("MHCHR05_HANR005A024", GetType(String)))
            .Add(New DataColumn("MHCHR05_HANR005A030", GetType(Integer)))

            .Add(New DataColumn("MHCHR30_HANR030007", GetType(String)))
            .Add(New DataColumn("MHCHR30_HANR030008", GetType(String)))
            .Add(New DataColumn("MHCHR30_HANR030009", GetType(String)))
            .Add(New DataColumn("MHCHR30_HANR030010", GetType(String)))
            .Add(New DataColumn("MHCHR30_HANR030011", GetType(String)))
            .Add(New DataColumn("MHCHR30_HANR030012", GetType(String)))
            .Add(New DataColumn("MHCHR30_HANR030013", GetType(String)))
            .Add(New DataColumn("MHCHR30_HANR030014", GetType(String)))
            .Add(New DataColumn("MHCHR30_HANR030015", GetType(String)))
            .Add(New DataColumn("MHCHR30_HANR030016", GetType(String)))
            .Add(New DataColumn("MHCHR30_HANR030017", GetType(String)))
            .Add(New DataColumn("MHCHR30_HANR030018", GetType(String)))
            .Add(New DataColumn("MHCHR30_HANR030019", GetType(String)))
            .Add(New DataColumn("MHCHR30_HANR030020", GetType(String)))
            .Add(New DataColumn("MHCHR30_HANR030021", GetType(String)))

            .Add(New DataColumn("MHCHR30TE_HANR030023", GetType(Decimal)))
            .Add(New DataColumn("MHCHM03_HANM003A024", GetType(Integer)))

            .Add(New DataColumn("HHCHM02SIR_HANM002048", GetType(Integer)))

        End With

        CreateAddRow(dt)

    End Sub

    Private Sub InitializeDataTable入出荷予定(ByVal dt As DataTable)
        With dt.Columns
            .Clear()
            .Add(New DataColumn("HHCHRA02_SEIRA02012", GetType(String)))
            .Add(New DataColumn("HHCHRA02_SEIRA02013", GetType(String)))

            .Add(New DataColumn("MHCHRA03_SEIRA03006", GetType(Integer)))
            .Add(New DataColumn("MHCHRA03_SEIRA03007", GetType(String)))
            .Add(New DataColumn("MHCHRA03_SEIRA03010", GetType(Integer)))
            .Add(New DataColumn("MHCHRA03_SEIRA03014", GetType(String)))
            .Add(New DataColumn("MHCHRA03_SEIRA03015", GetType(String)))
            .Add(New DataColumn("MHCHRA03_SEIRA03016", GetType(String)))
            .Add(New DataColumn("MHCHRA03_SEIRA03017", GetType(String)))
            .Add(New DataColumn("MHCHRA03_SEIRA03021", GetType(String)))
            .Add(New DataColumn("MHCHRA03_SEIRA03022", GetType(String)))
            .Add(New DataColumn("MHCHRA03_SEIRA03023", GetType(String)))

            .Add(New DataColumn("MHCHM03_HANM003002", GetType(String)))
            .Add(New DataColumn("MHCHM03_HANM003A024", GetType(Integer)))

        End With

        CreateAddRow(dt)

    End Sub

    Friend Sub CreateAddRow(ByRef targetDataTable As DataTable)
        SetAddDefaultValue(targetDataTable)
        targetDataTable.Rows.Add(targetDataTable.NewRow)
    End Sub

    Private Sub SetAddDefaultValue(ByRef targetDataTable As DataTable)

        For index As Integer = 0 To targetDataTable.Columns.Count - 1

            If targetDataTable.Columns(index).DataType Is GetType(String) Then
                targetDataTable.Columns(index).DefaultValue = ""
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Integer) Then
                targetDataTable.Columns(index).DefaultValue = 0
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Long) Then
                targetDataTable.Columns(index).DefaultValue = 0
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Decimal) Then
                targetDataTable.Columns(index).DefaultValue = 0
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Boolean) Then
                targetDataTable.Columns(index).DefaultValue = False
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Date) Then
                targetDataTable.Columns(index).DefaultValue = 0
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Object) Then
                targetDataTable.Columns(index).DefaultValue = Nothing
            End If
            If targetDataTable.Columns(index).DataType Is GetType(DataTable) Then
                targetDataTable.Columns(index).DefaultValue = New DataTable
            End If
            If targetDataTable.Columns(index).DataType Is GetType(IDictionary) Then
                targetDataTable.Columns(index).DefaultValue = Nothing
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Short) Then
                targetDataTable.Columns(index).DefaultValue = 0
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Single) Then
                targetDataTable.Columns(index).DefaultValue = 0
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Double) Then
                targetDataTable.Columns(index).DefaultValue = 0
            End If
        Next

    End Sub

    ''' <summary>
    '''文字列が数値であるかどうかを返します。</summary>
    ''' <param name="stTarget">
    '''     検査対象となる文字列。</param>
    ''' <returns>
    '''     指定した文字列が数値であれば True。それ以外は False。</returns>
    Public Overloads Shared Function IsNumeric(ByVal stTarget As String) As Boolean
        Return Double.TryParse(
            stTarget,
            System.Globalization.NumberStyles.Any,
            Nothing,
            0.0#
        )
    End Function

    ''' <summary>
    '''     オブジェクトが数値であるかどうかを返します。</summary>
    ''' <param name="oTarget">
    '''     検査対象となるオブジェクト。</param>
    ''' <returns>
    '''     指定したオブジェクトが数値であれば True。それ以外は False。</returns>
    Public Overloads Shared Function IsNumeric(ByVal oTarget As Object) As Boolean
        Return IsNumeric(oTarget.ToString())
    End Function

    Private Function テキスト値チェック(ByVal val As String, ByVal target As チェック対象型) As Boolean

        Dim ret As Boolean = True

        Select Case target
            Case チェック対象型.受発注番号
                If IsNumeric(CChar(val)) = False Then
                    ret = False
                End If
                If val.Length >= 11 Then
                    ret = False
                End If
            Case チェック対象型.受発注行番号
                If IsNumeric(CChar(val)) = False Then
                    ret = False
                End If
                If val.Length >= 3 Then
                    ret = False
                End If
            Case チェック対象型.内訳番号
                If IsNumeric(CChar(val)) = False Then
                    ret = False
                End If
                If val.Length >= 3 Then
                    ret = False
                End If
        End Select

        Return ret

    End Function

#End Region
End Class
'A-CUST20190830↑
