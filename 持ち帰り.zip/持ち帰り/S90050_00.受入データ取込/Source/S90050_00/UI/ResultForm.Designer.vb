﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ResultForm
    Inherits OSK.X1.Foundation.TextFileImport.UserInterface.ResultFormBase

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ResultCountInfo = New OSK.X1.SEI.S90050_00.UI.ResultCountControl
        'Me.resultBase.SuspendLayout()
        'Me.SuspendLayout()
        '
        'ResultCountInfo
        '
        Me.ResultCountInfo.Location = New System.Drawing.Point(0, 24)
        Me.ResultCountInfo.Name = "ResultCountInfo"
        Me.ResultCountInfo.Size = New System.Drawing.Size(610, 150)
        Me.ResultCountInfo.TabIndex = 3
        Me.ResultCountInfo.単位 = "件"
        '
        'ResultForm
        '
        'Me.ClientSize = New System.Drawing.Size(608, 341)
        Me.Controls.Add(Me.ResultCountInfo)
        'Me.Name = "ResultForm"
        Me.Controls.SetChildIndex(Me.ResultCountInfo, 0)
        'Me.Controls.SetChildIndex(Me.resultBase, 0)
        'Me.resultBase.ResumeLayout(False)
        'Me.ResumeLayout(False)
        'Me.PerformLayout()

    End Sub
    Friend WithEvents ResultCountInfo As OSK.X1.SEI.S90050_00.UI.ResultCountControl
End Class
