﻿'A-CUST20190830↓
Public Class DataChecker
    Function 数値_Check(ByRef value As String, ByVal 桁数 As Integer,
                                              ByVal 小数以下桁数 As Integer,
                                              Optional ByVal マイナス値可能 As Boolean = True) As Boolean
        '数値タイプかどうかのチェックを行う
        Dim buff As String = value.ToString.Trim

        '全角文字はNG
        If 全角文字_Check(buff) = True Then
            Return False
        End If

        'ブランクは0として扱う
        If buff.Length = 0 Then
            buff = "0"
        End If

        '数値でなければNG
        If IsNumeric(buff) = False Then
            Return False
        End If

        'カンマ(,)をカット
        buff = Replace(buff, ",", "")

        If IsNumericChar(buff) = False Then
            Return False
        End If

        Dim 符号 As String = ""
        Select Case buff.Substring(0, 1)
            Case "-"
                符号 = "-"
                buff = buff.Substring(1, buff.Length - 1)
            Case "+"
                '+はカットする
                buff = buff.Substring(1, buff.Length - 1)
        End Select

        If マイナス値可能 = False Then
            If 符号 <> "" Then
                Return False
            End If
        End If

        '".1", "1." の場合の対応
        Select Case True
            Case buff.StartsWith(".")
                buff = "0" & buff
            Case buff.EndsWith(".")
                buff = buff & "0"
        End Select

        Dim 整数部 As String = ""
        Dim 小数部 As String = ""
        Dim 小数点位置 As Integer = InStr(buff, ".")

        If 小数点位置 = 0 Then
            整数部 = buff
        Else
            整数部 = buff.Substring(0, 小数点位置 - 1)
            小数部 = buff.Substring(小数点位置, buff.Length - 小数点位置)
        End If

        '整数部チェック
        Dim 整数部最大値 As String = New String(CChar("9"), 桁数 - 小数以下桁数)
        '前"0"をカット
        Do
            If 整数部.Length <= 1 Then
                Exit Do
            End If
            If 整数部.StartsWith("0") = True Then
                整数部 = Right(整数部, 整数部.Length - 1)
            Else
                Exit Do
            End If
        Loop
        If 整数部.Length > 整数部最大値.Length Then
            Return False
        End If

        '小数部チェック
        If 小数以下桁数 = 0 Then
            Dim result As String = 小数部.Replace("0", "")
            If result.Length <> 0 Then
                '0以外の文字が存在する場合エラーとする
                Return False
            End If
        Else
            Dim 小数部最大値 As String = New String(CChar("9"), 小数以下桁数)
            Dim 小数部ZeroFill As String = New String(CChar("0"), 小数以下桁数)
            '後"0"をカット
            Do
                If 小数部.EndsWith("0") = True Then
                    小数部 = Left(小数部, 小数部.Length - 1)
                Else
                    Exit Do
                End If
            Loop
            If 小数部.Length > 小数以下桁数 Then
                Return False
            Else
                小数部 = Left(小数部 & 小数部ZeroFill, 小数以下桁数)
            End If
        End If

        '整形した値を返す
        If 小数以下桁数 = 0 Then
            value = 整数部.ToString
        Else
            value = 整数部.ToString & "." & 小数部.ToString
        End If
        If Val(value) <> 0 Then
            value = 符号 & value
        End If

        Return True
    End Function

    Private Function IsNumericChar(ByRef value As String) As Boolean
        Dim values() As Char = value.ToCharArray
        For i As Integer = 0 To values.Length - 1
            Select Case values(i)
                Case "-"c, "+"c
                    If i <> 0 Then Return False
                Case "."c, "0"c To "9"c
                Case Else
                    Return False
            End Select
        Next
        Return True
    End Function

    Function 桁Over_Check(ByVal value As String, ByVal length As Integer) As Boolean
        '全角文字かどうかのチェックを行う

        Dim buffLength As Integer = OSK.X1.Foundation.TextUtility.GetTextLength(value.ToString.TrimEnd)

        '桁オーバーはダメです
        If buffLength > length Then
            Return False
        End If

    End Function

    Function 全角文字_Check(ByVal value As String) As Boolean
        '全角文字かどうかのチェックを行う

        Dim length As Integer = OSK.X1.Foundation.TextUtility.GetTextLength(value.ToString.TrimEnd)
        Return (length <> value.Length)
        Return True

    End Function

    Function 日付Type_Check(ByRef value As String, Optional ByVal Zeroはエラーとする As Boolean = True) As Boolean

        Dim buff As String = value.ToString.Trim

        '全角文字はNG
        If 全角文字_Check(buff) = True Then
            Return False
        End If

        buff = Replace(buff, "/", "")
        If IsAllZero(buff) = True Then
            If Zeroはエラーとする = True Then
                Return False
            Else
                If buff.Length > 8 Then
                    Return False
                Else
                    value = "00000000"
                    Return True
                End If
            End If
        End If

        If buff.Length <> 8 Then
            Return False
        End If

        '"yyyy/MM/dd"に変換して日付妥当性チェック
        buff = Left(buff, 4) & "/" & Mid(buff, 5, 2) & "/" & Right(buff, 2)
        If IsDate(buff) = False Then
            Return False
        End If

        Dim dateValue As Date = Date.Parse(buff)
        buff = dateValue.ToString("yyyyMMdd")

        '整形した値を返す
        value = buff

        'ここまでくればＯＫ
        Return True

    End Function

    Private Function IsAllZero(ByVal value As String,
                               Optional ByVal ブランクは0とする As Boolean = True) As Boolean

        If ブランクは0とする = True Then
            value = value.ToString.Trim
        End If

        If value.Length = 0 Then
            If ブランクは0とする = True Then
                Return True
            Else
                Return False
            End If
        End If

        Dim zeroFill As String = New String(CChar("0"), value.Length)
        Return (value = zeroFill)

    End Function
End Class
'A-CUST20190830↑
