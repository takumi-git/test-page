﻿Public Class ReportController
    Inherits ReportControllerBase

#Region "■定義■"

    'Private Const 警告＿エラー出力列数 As Integer = 2    'X1変換Tool-20170508  'D-CUST20190830
    Private Const 警告＿エラー出力列数 As Integer = 3     'A-CUST20190830
    Private Const LINE_COUNT_MAX As Integer = 68

    '一件毎に格納し出力する為の変数
    Private Structure _reportEditData定義
        Dim MaxIndex As Integer
        Dim 行番号 As Integer
        Dim 警告＿エラータイトル As String    'X1変換Tool-20170508
        Dim テキスト内容配列() As String
        Dim エラー内容１配列() As String
        Dim エラー内容２配列() As String
        Dim エラー内容３配列() As String    'A-CUST20190830
    End Structure

    '■インスタンス生成時に初期化して使用
    '帳票ID 
    Private _reportID As String = ""

    '■初回のみ初期化して使用
    '実行情報
    Private _myImportParam As S90050_00.ImportParam
    Private _myコントロール情報 As Myコントロール情報Param
    Private _my項目名称 As My項目名称型
    'オプションにより見出しと明細の行数が変わる。但し、見出と明細の行数は同一
    Private _見出明細行数_ヘッダー As Integer
    Private _見出明細行数_明細 As Integer
    Private _明細開始行 As Integer
    Private _伝票拡張項目行出力有無(5) As Boolean   '5行 .. 1オリジン
    Private _明細拡張項目行出力有無(5) As Boolean   '5行 .. 1オリジン
    Private _明細追加行出力有無() As Boolean        'X行 .. 1オリジン       'A-2008/07/18_Ver7.30_GENKA
    '文字列桁合わせ
    Private _stringFormat As CMN.LIB.StringFormat.IStringFormat

    '■印刷実行毎に初期化して使用する
    '【警告】or【エラー】の印字制御用
    Private _newエラー区分 As String = ""
    Private _oldエラー区分 As String = ""
    Private _エラーデータ読込終了フラグ As Boolean = False
    Private _警告データ読込終了フラグ As Boolean = False
    Private _reportEditData As _reportEditData定義
    Private _reportDataBlock As List(Of TextFileImportLib.ReportData型)
    '印刷有無
    Private _isPrint As Boolean = False
    '一頁分のデータを格納するオブジェクト
    Private _pageParam As OSK.X1.Printing.IFormatBase.PageParam    'X1変換Tool-20170508
    Private _pageCount As Integer
    '一頁分のデータ件数
    Private _文字データ件数 As Integer = 0
    Private _罫線データ件数 As Integer = 0
    Private _網掛データ件数 As Integer = 0
    Private _lineCount As Integer

    '■処理内で随時設定
    'テキストのブレイク判定
    Private _firstData As Boolean
    Private _headerFlg As Boolean   'ヘッダー行処理時:True

    Private _伝票明細行数 As Integer
    Private _伝票合計金額 As Decimal
    Private _伝票合計金額不正 As Boolean

    Private _構成品時改頁 As Boolean

    Private _ロット内訳有無 As Boolean    'A-20121217_Ver7.50_3

    'A-CUST20190830↓
    Private _前回値 As String
    Private _今回値 As String
    'A-CUST20190830↑

#End Region

#Region "列挙型"

    Enum 伝票種類型 As Integer
        ヘッダー
        明細
    End Enum

    Enum KeyType As Integer
        処理連番 = 0
        明細区分
        行番号
        構成品出庫生成区分
        構成品_取引区分
        構成品_行番号
        親品目判断     '処理連番+明細区分+行番号
        子品目判断     '親品目判断+(構成品)取引区分+(構成品)行番号
        W091行番号
        項目数
    End Enum

#End Region

#Region "プロパティ"

    Private _oldKey(0 To KeyType.項目数 - 1) As String
    Private Property OldKey(ByVal keyWord As KeyType) As String
        Get
            Return _oldKey(keyWord)
        End Get
        Set(ByVal value As String)
            _oldKey(keyWord) = value
        End Set
    End Property

    Private _newKey(0 To KeyType.項目数 - 1) As String
    Private Property NewKey(ByVal keyWord As KeyType) As String
        Get
            Return _newKey(keyWord)
        End Get
        Set(ByVal value As String)
            _newKey(keyWord) = value
        End Set
    End Property

    Public ReadOnly Property 拡張伝票() As [LIB].ExpandItemControl.I拡張項目定義型
        Get
            If _myImportParam.Myコントロール情報.MyMOA機能追加.仕入検収基準 = MOA機能追加定義型.その他管理区分型.行う Then
                Return _myImportParam.拡張項目情報_入荷伝票
            Else
                Return _myImportParam.拡張項目情報_仕入伝票
            End If
        End Get
    End Property

    Public ReadOnly Property 拡張明細() As [LIB].ExpandItemControl.I拡張項目定義型
        Get
            If _myImportParam.Myコントロール情報.MyMOA機能追加.仕入検収基準 = MOA機能追加定義型.その他管理区分型.行う Then
                Return _myImportParam.拡張項目情報_入荷明細
            Else
                Return _myImportParam.拡張項目情報_仕入明細
            End If
        End Get
    End Property

    '↓A-20170601-X1-桁数拡張
    Private ReadOnly Property kingaku_MaxValue() As Decimal
        Get
            Return CDec(New String(CChar("9"), _myコントロール情報.My桁数拡張.金額桁数))
        End Get
    End Property

    Private ReadOnly Property kingaku_MaxValue_Gaika() As Decimal
        Get
            Return kingaku_MaxValue + CDec(0.9999)
        End Get
    End Property
    '↑A-20170601-X1-桁数拡張

#End Region

#Region "■初期処理関連■"

    Protected Overrides Sub SetupImpl()
        '↓A-20170601-X1-行ピッチ変更
        _行倍率適用基準行位置 = 7
        _行倍率適用前行数 = 70 - _行倍率適用基準行位置
        '↑A-20170601-X1-行ピッチ変更
        Call MyBase.InitPrintingController(S90050_00.ProgramLib.帳票タイトル, _reportID)
        Call ClearKey()

        'A-CUST20190830↓
        _前回値 = ""
        _今回値 = ""
        'A-CUST20190830↑
    End Sub

    Private Sub ClearKey()

        For i As Integer = 0 To UBound(_oldKey)
            OldKey(CType(i, KeyType)) = ""
        Next
        For i As Integer = 0 To UBound(_newKey)
            NewKey(CType(i, KeyType)) = ""
        Next

    End Sub

#End Region

#Region "■印刷実行■"

    Private _initPrinting As Boolean = False
    Protected Overrides Sub PrintInitializeImpl()

        _newエラー区分 = ""
        _oldエラー区分 = ""
        _エラーデータ読込終了フラグ = False
        _警告データ読込終了フラグ = False
        _reportDataBlock = Nothing

        _isPrint = False
        _pageParam = Nothing
        _pageCount = 0
        _文字データ件数 = 0
        _罫線データ件数 = 0
        _網掛データ件数 = 0
        _lineCount = LINE_COUNT_MAX + 1 '最初に必ず改頁させる

        _firstData = True
        _headerFlg = True

        _伝票明細行数 = 0
        _伝票合計金額 = 0
        _伝票合計金額不正 = False

        '印刷ボタン押下する毎にこの処理が呼ばれる
        If _initPrinting = False Then
            _initPrinting = True

            _myImportParam = CType(MyBase.ImportParam, S90050_00.ImportParam)
            _myコントロール情報 = _myImportParam.Myコントロール情報
            _my項目名称 = New My項目名称型
            _my項目名称.Initialize(Me.InitInfo)

            'A-20121217_Ver7.50_3↓
            _ロット内訳有無 = False

            If _myコントロール情報.MyMOAオプション.MOA品質管理 = MOAオプション定義型.その他管理区分型.行う Then
                _ロット内訳有無 = True
            Else
                If _myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 4D AndAlso
                   _myコントロール情報.MyMOA機能追加.ロケーション単位数量指定列 = MOA機能追加定義型.ロケーション単位数量指定列.数量列_ロケ＿ロット別 Then    'X1変換Tool-20170508
                    _ロット内訳有無 = True
                End If
            End If
            'A-20121217_Ver7.50_3↑

            '_見出明細行数_ヘッダー = 2 + Get伝票拡張項目行数()
            '_見出明細行数_明細 = 3 + Get明細拡張項目行数()
            '_見出明細行数_明細 += Get明細追加行数()             'A-2008/07/18_Ver7.30_GENKA

            _見出明細行数_ヘッダー = 2 + Get伝票拡張項目行数()

            'If _myコントロール情報.MyMOAオプション.MOA品質管理 = MOAオプション定義型.その他管理区分型.行う Then   'D-20121217_Ver7.50_3
            If _ロット内訳有無 = True Then                                                                         'A-20121217_Ver7.50_3
                _見出明細行数_明細 = 7 + Get明細拡張項目行数()
            Else
                _見出明細行数_明細 = 6 + Get明細拡張項目行数()
            End If

            'A-20121217_Ver7.50_1↓
            If _myコントロール情報.MyMOAオプション.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う Then
                _見出明細行数_明細 += 1
            End If
            'A-20121217_Ver7.50_1↑

            _明細開始行 = 9 + _見出明細行数_ヘッダー + _見出明細行数_明細

            _明細開始行 = 11 'A-CUST20190830

            _stringFormat = CMN.LIB.PartReplacement.CommonFactory.CreateInstance(Of CMN.LIB.StringFormat.IStringFormat)(Me, GetType(CMN.LIB.StringFormat.StringFormat))

        End If

        _明細開始行 = 11 'A-CUST20190830

    End Sub

    Private Function Get伝票拡張項目行数() As Integer
        If _myコントロール情報.Myオプション区分.拡張項目_仕入伝票 = False Then
            Return 0
        End If
        Dim lineCount As Integer = 0
        Dim iEXP As Integer = 1
        For iEXP1 As Integer = 1 To 5
            For iEXP2 As Integer = iEXP To iEXP + 3
                If 拡張伝票.項目情報.項目(iEXP2).属性 <> SEI.LIB.ExpandItemControl.項目属性型.拡張項目属性型.未使用 Then
                    lineCount += 1
                    _伝票拡張項目行出力有無(iEXP1) = True
                    Exit For
                End If
            Next iEXP2
            iEXP = iEXP + 4
        Next iEXP1
        Return lineCount
    End Function

    Private Function Get明細拡張項目行数() As Integer
        If _myコントロール情報.Myオプション区分.拡張項目_仕入明細 = False Then
            Return 0
        End If
        Dim lineCount As Integer = 0
        Dim iEXP As Integer = 1
        For iEXP1 As Integer = 1 To 5
            For iEXP2 As Integer = iEXP To iEXP + 3
                If 拡張明細.項目情報.項目(iEXP2).属性 <> SEI.LIB.ExpandItemControl.項目属性型.拡張項目属性型.未使用 Then
                    lineCount += 1
                    _明細拡張項目行出力有無(iEXP1) = True
                    Exit For
                End If
            Next iEXP2
            iEXP = iEXP + 4
        Next iEXP1
        Return lineCount
    End Function

    Private Function Get明細追加行数() As Integer       'A-2008/07/18_Ver7.30_GENKA
        Dim 明細追加行数 As Integer = 0
        Dim 明細追加行最大数 As Integer = 1
        明細追加行最大数 += 1       'A-2009/12/18_Ver7.40_LOT

        ReDim _明細追加行出力有無(0 To 明細追加行最大数)
        For i As Integer = 1 To _明細追加行出力有無.Length - 1
            _明細追加行出力有無(i) = False
        Next

        Dim line As Integer = 0

        '** 追加行１出力判定 **
        line += 1
        If _myコントロール情報.MyＲＥＶ.強化区分 >= 3.0 Then
            _明細追加行出力有無(line) = True
        End If

        '↓A-2009/12/18_Ver7.40_UCHIWAKE
        If _myコントロール情報.MyＲＥＶ.強化区分 >= 4.0 Then
            _明細追加行出力有無(line) = True
        End If
        '↑A-2009/12/18_Ver7.40_UCHIWAKE

        '↓A-2009/12/18_Ver7.40_LOT
        '** 追加行２出力判定 **
        line += 1
        If _myコントロール情報.MyＲＥＶ.強化区分 >= 4.0 Then
            _明細追加行出力有無(line) = True
        End If
        '↑A-2009/12/18_Ver7.40_LOT

        '** 追加行数判定 **
        For i As Integer = 0 To _明細追加行出力有無.Length - 1
            If _明細追加行出力有無(i) = True Then
                明細追加行数 += 1
            End If
        Next

        Return 明細追加行数
    End Function

    Protected Overrides Sub PrintMainImpl()

        Dim dataStatus As _GetReportDataResultType

        '* ========== >
        '*  先読み
        '* < ==========
        dataStatus = GetReportData()
        If dataStatus = _GetReportDataResultType.データ取得 Then
            Call MyBase.StanbyPrintPreview()
            Call MyBase.GetMaxLineCount(_reportID, _明細開始行, LINE_COUNT_MAX)  'A-20170601-X1-行ピッチ変更
        End If

        _lineCount = CInt(MyBase.PageMaxLineCount) + 1  'A-20170601-X1-行ピッチ変更

        Do Until _処理終了フラグ = True

            '* ========== >
            '*  編集・出力
            '* < ==========
            Call EditReport(_pageParam)

            '* ========== >
            '*  次データ読み込み
            '* < ==========
            dataStatus = GetReportData()

            If dataStatus = _GetReportDataResultType.データ終了_全データ OrElse
               NewKey(KeyType.処理連番) <> OldKey(KeyType.処理連番) OrElse
               (_伝票明細行数 <> 0 AndAlso Val(NewKey(KeyType.W091行番号)) <> Val(OldKey(KeyType.W091行番号)) + 1) Then
                '伝票フッター印字
                Call EditTextData_Footer(_pageParam, _lineCount)
            End If

        Loop

        If _isPrint = True Then
            '* ========== >
            '*  フッター編集と１頁出力
            '* < ==========
            Call EditReportFooter(_pageParam)
        End If

        If _pageCount = 0 Then
            Call RaiseEventReportEnd(Foundation.ResultType.レコード無し)
        Else
            MyBase.PrintingController.ActionEnd()
        End If

    End Sub

#Region "■データ取得関連■"

    Private Function GetReportData() As _GetReportDataResultType
        Dim reportReadData As TextFileImportLib.ReportData型

        If _firstData = True Then
            ClearKey()
        End If

        If _firstData = True OrElse _headerFlg = False Then
            _reportData配列位置 += 1

            If IsDataRead(_reportData配列位置) = True Then
                If _読込終了フラグ = True Then
                    _処理終了フラグ = True
                    Return _GetReportDataResultType.データ終了_全データ
                Else
                    If MyBase.ReadReportData(MyBase.ReportDataReadParam, _reportDataBlock) = _GetReportDataResultType.データ終了_全データ Then
                        Return _GetReportDataResultType.データ終了_全データ
                    End If
                    _reportData配列位置 = 0
                End If
            End If
        End If

        '配列から1件取り出す...
        reportReadData = _reportDataBlock.Item(_reportData配列位置)
        _reportEditData.テキスト内容配列 = Split(reportReadData.テキスト内容帳票出力用, TextFileImportLib.TAB_STRING)
        _reportEditData.行番号 = reportReadData.行番号

        'NewKey(KeyType.処理連番) = _reportEditData.テキスト内容配列(仕入データ型.処理連番).TrimEnd   'D-CUST20190830
        NewKey(KeyType.処理連番) = _reportEditData.テキスト内容配列(出力位置型._002).TrimEnd          'A-CUST20190830
        NewKey(KeyType.明細区分) = _reportEditData.テキスト内容配列(仕入データ型.明細区分).TrimEnd
        NewKey(KeyType.行番号) = _reportEditData.テキスト内容配列(仕入データ型.行番号).TrimEnd
        NewKey(KeyType.構成品出庫生成区分) = _reportEditData.テキスト内容配列(仕入データ型.構成品出庫生成区分).TrimEnd
        NewKey(KeyType.構成品_取引区分) = _reportEditData.テキスト内容配列(仕入データ型.構成品_取引区分).TrimEnd
        NewKey(KeyType.構成品_行番号) = _reportEditData.テキスト内容配列(仕入データ型.構成品_行).TrimEnd

        NewKey(KeyType.親品目判断) = _reportEditData.テキスト内容配列(仕入データ型.処理連番).TrimEnd.PadLeft(10, " "c) &
                                     _reportEditData.テキスト内容配列(仕入データ型.明細区分).TrimEnd.PadLeft(1, " "c) &
                                     _reportEditData.テキスト内容配列(仕入データ型.行番号).TrimEnd.PadLeft(3, " "c)

        NewKey(KeyType.子品目判断) = NewKey(KeyType.親品目判断) &
                                     _reportEditData.テキスト内容配列(仕入データ型.構成品_取引区分).TrimEnd.PadLeft(1, " "c) &
                                     _reportEditData.テキスト内容配列(仕入データ型.構成品_行).TrimEnd.PadLeft(3, " "c)

        NewKey(KeyType.W091行番号) = CStr(_reportEditData.行番号)

        _今回値 = _reportEditData.テキスト内容配列(出力位置型._002).TrimEnd 'A-CUST20190830

        'D-CUST20190830↓
        'If _firstData = True OrElse
        '   NewKey(KeyType.処理連番) <> OldKey(KeyType.処理連番) OrElse
        '   (_伝票明細行数 <> 0 AndAlso Val(NewKey(KeyType.W091行番号)) <> Val(OldKey(KeyType.W091行番号)) + 1) Then
        '    _firstData = False
        '    'ヘッダー行
        '    SetReportEditData(伝票種類型.ヘッダー, reportReadData)
        '    _headerFlg = True
        'Else
        '    '明細行
        '    SetReportEditData(伝票種類型.明細, reportReadData)
        '    _headerFlg = False
        'End If
        'D-CUST20190830↑
        'A-CUST20190830↓
        SetReportEditData(伝票種類型.ヘッダー, reportReadData)
        _headerFlg = True
        'A-CUST20190830↑

    End Function

    Private Sub SetReportEditData(ByVal type As 伝票種類型,
                                  ByVal reportReadData As TextFileImportLib.ReportData型)

        Dim エラー内容() As String
        Dim 警告＿エラー出力行数 As Integer    'X1変換Tool-20170508

        If type = 伝票種類型.ヘッダー Then
            エラー内容 = Split(reportReadData.エラー内容１, TextFileImportLib.TAB_STRING)
            'A-CUST20190830↓
            If エラー内容(0).TrimEnd = "" Then
                'ヘッダー分が無い
                エラー内容 = Split(reportReadData.エラー内容２, TextFileImportLib.TAB_STRING)
            Else
                エラー内容 = Split(reportReadData.エラー内容１ & TextFileImportLib.TAB_STRING & reportReadData.エラー内容２, TextFileImportLib.TAB_STRING)
            End If
            'A-CUST20190830↑
        Else
            エラー内容 = Split(reportReadData.エラー内容２, TextFileImportLib.TAB_STRING)
        End If

        警告＿エラー出力行数 = CType(Fix(エラー内容.Length / 警告＿エラー出力列数), Integer)    'X1変換Tool-20170508

        If エラー内容.Length <> 警告＿エラー出力行数 * 警告＿エラー出力列数 Then    'X1変換Tool-20170508
            警告＿エラー出力行数 += 1    'X1変換Tool-20170508
        End If

        With _reportEditData
            Select Case CType(reportReadData.エラー区分, TextFileImportLib.エラー区分型)
                Case TextFileImportLib.エラー区分型.警告_登録, TextFileImportLib.エラー区分型.警告_修正
                    .警告＿エラータイトル = "【警　告】"    'X1変換Tool-20170508
                Case TextFileImportLib.エラー区分型.エラー
                    .警告＿エラータイトル = "【エラー】"    'X1変換Tool-20170508
                Case Else
                    .警告＿エラータイトル = "【" & reportReadData.エラー区分 & "】"    'X1変換Tool-20170508
            End Select
            _newエラー区分 = .警告＿エラータイトル    'X1変換Tool-20170508

            ReDim .エラー内容１配列(警告＿エラー出力行数 - 1)    'X1変換Tool-20170508
            ReDim .エラー内容２配列(警告＿エラー出力行数 - 1)    'X1変換Tool-20170508
            ReDim .エラー内容３配列(警告＿エラー出力行数 - 1) 'A-CUST20190830
            Dim i1 As Integer
            Dim i2 As Integer = -1
            For i1 = 0 To エラー内容.Length - 1 Step 警告＿エラー出力列数    'X1変換Tool-20170508
                i2 += 1
                .エラー内容１配列(i2) = エラー内容(i1)
                If i1 + 1 > エラー内容.Length - 1 Then
                    .エラー内容２配列(i2) = ""
                Else
                    .エラー内容２配列(i2) = エラー内容(i1 + 1)
                End If

                'A-CUST20190830↓
                If i1 + 2 > エラー内容.Length - 2 Then
                    .エラー内容３配列(i2) = ""
                Else
                    .エラー内容３配列(i2) = エラー内容(i1 + 2)
                End If
                'A-CUST20190830↑
            Next
            .MaxIndex = 警告＿エラー出力行数 - 1    'X1変換Tool-20170508
        End With

    End Sub

    Private Function IsDataRead(ByVal nextReportData配列位置 As Integer) As Boolean

        If _reportDataBlock Is Nothing Then
            Return True
        End If

        If _reportData配列位置 > _reportDataBlock.Count - 1 Then
            Return True
        End If

        Return False

    End Function

#End Region

#Region "■帳票出力関連■"

    ''' <summary>
    ''' 帳票編集
    ''' </summary>
    ''' <param name="pageParam"></param>
    ''' <remarks></remarks>
    Private Sub EditReport(ByRef pageParam As Printing.IFormatBase.PageParam)

        If _headerFlg = True Then
            _伝票明細行数 = 0
        Else
            _伝票明細行数 += 1
        End If

        '最大明細行数以降の行データは印字しない
        If _伝票明細行数 > ProgramLib.MAX_DETAIL_COUNT Then Exit Sub

        '【警告】or【エラー】とテキスト内容が印字可能か判定する
        'If _lineCount + printLine() > LINE_COUNT_MAX Then          'D-20170601-X1-行ピッチ変更
        If _lineCount + printLine() > MyBase.PageMaxLineCount Then  'A-20170601-X1-行ピッチ変更
            '* ========== >
            '*  ヘッダー編集
            '* < ==========
            Call EditReportHeader(pageParam)
            _lineCount = _明細開始行
        End If

        Dim startLineCount As Integer = 0

        Dim iテキスト内容 As Integer
        'テキスト内容を出力し、行数を返す
        If _headerFlg = True Then
            iテキスト内容 = EditTextData_Header(pageParam, _lineCount, startLineCount)
        Else
            If OldKey(KeyType.親品目判断) <> NewKey(KeyType.親品目判断) Then

                _構成品時改頁 = False

                iテキスト内容 = EditTextData_Detail(pageParam, _lineCount, startLineCount)

                If _構成品時改頁 = True Then
                    _lineCount = iテキスト内容
                    Exit Sub
                End If
            Else
                OldKey(KeyType.明細区分) = NewKey(KeyType.明細区分)
                OldKey(KeyType.行番号) = NewKey(KeyType.行番号)
                OldKey(KeyType.構成品出庫生成区分) = NewKey(KeyType.構成品出庫生成区分)
                OldKey(KeyType.構成品_取引区分) = NewKey(KeyType.構成品_取引区分)
                OldKey(KeyType.構成品_行番号) = NewKey(KeyType.構成品_行番号)

                OldKey(KeyType.子品目判断) = NewKey(KeyType.子品目判断)
                OldKey(KeyType.W091行番号) = NewKey(KeyType.W091行番号)
                Exit Sub
            End If
        End If

        '警告・エラー内容を出力し、行数を返す
        Dim 改頁有無 As TextFileImportLib.有無区分型
        Dim i警告＿エラー As Integer = EditErrorAndWorning(pageParam, startLineCount - 1, 改頁有無)    'X1変換Tool-20170508

        'テキスト内容 or 警告・エラー内容 の行数の多い方を採用
        If 改頁有無 = TextFileImportLib.有無区分型.無 AndAlso iテキスト内容 > i警告＿エラー Then    'X1変換Tool-20170508
            _lineCount = iテキスト内容
        Else
            _lineCount = i警告＿エラー    'X1変換Tool-20170508
        End If

    End Sub

    Private Function printLine() As Integer
        Dim 見出明細行数 As Integer
        If _headerFlg = True Then
            見出明細行数 = _見出明細行数_ヘッダー
        Else
            見出明細行数 = _見出明細行数_明細
        End If

        Select Case True
            'Case _lineCount > LINE_COUNT_MAX OrElse _lineCount = _明細開始行 - 1            'D-20170601-X1-行ピッチ変更
            Case _lineCount > MyBase.PageMaxLineCount OrElse _lineCount = _明細開始行 - 1    'A-20170601-X1-行ピッチ変更
                '先頭行は【警　告】or【エラー】+ 明細行数
                Return 見出明細行数 + 1

            Case _oldエラー区分 <> _newエラー区分
                '【警　告】or【エラー】も出力する場合
                Return 見出明細行数 + 2

            Case Else
                '明細のみ出力する場合
                Return 見出明細行数 + 1
        End Select

    End Function

    ''' <summary>
    ''' ヘッダー編集
    ''' </summary>
    ''' <param name="pageParam"></param>
    ''' <remarks></remarks>
    Private Sub EditReportHeader(ByRef pageParam As Printing.IFormatBase.PageParam)

        If _isPrint = True Then
            '* ========== >
            '*  フッター編集と１頁出力
            '* < ==========
            Call EditReportFooter(pageParam)
        End If

        If Me.システム環境情報.システム構成情報.動作モード = OSK.X1.Foundation.動作モード型.デバッグ Then    'X1変換Tool-20170508
            Dim layoutSheet As CMN.LIB.PrintingHelper.ILayoutSheet
            layoutSheet = CMN.LIB.PartReplacement.CommonFactory.CreateInstance(Of CMN.LIB.PrintingHelper.ILayoutSheet)(Me, GetType(CMN.LIB.PrintingHelper.LayoutSheet))
            layoutSheet.StyleSheet(OSK.X1.CMN.LIB.PrintingHelper.ILayoutSheet.用紙サイズ.Ａ４横, _文字データ件数, _罫線データ件数, pageParam)    'X1変換Tool-20170508
        End If

        Dim work As String
        Dim reportHelper As IReportHelper = New ReportHelper
        _pageParam.ReportID = _reportID
        _isPrint = True
        _lineCount = 7

        '会社名、帳票タイトル
        Dim headerWriter As OSK.X1.SEI.LIB.PrintingAssist.IHeaderWriter    'X1変換Tool-20170508
        headerWriter = CMN.LIB.PartReplacement.CommonFactory.CreateInstance(Of SEI.LIB.PrintingAssist.HeaderWriter)(Me, GetType(SEI.LIB.PrintingAssist.HeaderWriter))
        headerWriter.Initialize(Me)
        headerWriter.Write(_lineCount, 12, 84, 122, S90050_00.ProgramLib.帳票タイトル, pageParam, _文字データ件数)

        '■明細見出(ヘッダー項目) - １行目
        _lineCount = _lineCount + 2

        'A-CUST20190830↓
        work = "ﾃﾞｰﾀ区分"
        SetStringParam(_項目分類文字型.項目見出し, 0, 14, _lineCount, 21, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        work = "連  番"
        SetStringParam(_項目分類文字型.項目見出し, 0, 22, _lineCount, 28, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        work = "行№"
        SetStringParam(_項目分類文字型.項目見出し, 0, 33, _lineCount, 37, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        work = "内訳№"
        SetStringParam(_項目分類文字型.項目見出し, 0, 38, _lineCount, 44, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        work = _my項目名称.販売商品 & "コード"
        SetStringParam(_項目分類文字型.項目見出し, 0, 45, _lineCount, 55, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        work = "数  量"
        SetStringParam(_項目分類文字型.項目見出し, 0, 59, _lineCount, 65, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        work = "ロット№"
        SetStringParam(_項目分類文字型.項目見出し, 0, 72, _lineCount, 80, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        work = "ﾛｹｰｼｮﾝ"
        SetStringParam(_項目分類文字型.項目見出し, 0, 93, _lineCount, 99, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        work = "内職者ｺｰﾄﾞ"
        SetStringParam(_項目分類文字型.項目見出し, 0, 104, _lineCount, 113, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        work = "エ ラ ー 内 容"
        SetStringParam(_項目分類文字型.項目見出し, 0, 114, _lineCount, 128, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        _lineCount = _lineCount + 1
        'A-CUST20190830↑
        'D-CUST20190830↓
        'work = "連番"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 20, _lineCount, 24, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = "伝票日付"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 25, _lineCount, 33, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        ''work = "伝票№"
        ''SetStringParam(_項目分類文字型.項目見出し, 0, 38, _lineCount, 44, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = "入荷№"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 38, _lineCount, 44, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = _my項目名称.販売仕入先
        'SetStringParam(_項目分類文字型.項目見出し, 0, 45, _lineCount, 51, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = "支払"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 103, _lineCount, 107, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = "計上"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 109, _lineCount, 113, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        ''work = "相手処理連番"
        ''SetStringParam(_項目分類文字型.項目見出し, 0, 113, _lineCount, 125, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        ''A-20160324_1↓
        'If _myコントロール情報.使用条件(Myコントロール情報Param.条件型.外貨複数伝票消込機能, 8D) = True Then
        '    work = "ﾚｰﾄ固定"
        '    SetStringParam(_項目分類文字型.項目見出し, 0, 114, _lineCount, 121, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'End If
        ''A-20160324_1↑
        'work = "発生"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 126, _lineCount, 130, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = "仮計上"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 131, _lineCount, 137, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = "エ ラ ー 内 容"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 144, _lineCount, 158, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        ''■明細見出(ヘッダー項目) - ２行目
        '_lineCount += 1

        'work = _my項目名称.販売営業所
        'SetStringParam(_項目分類文字型.項目見出し, 0, 14, _lineCount, 20, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = "買掛"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 23, _lineCount, 27, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'If _myコントロール情報.Myオプション区分.拡張項目_仕入伝票 = True AndAlso
        '   拡張伝票.付箋情報.使用区分 = [LIB].ExpandItemControl.付箋情報型.使用区分型.使用する Then
        '    work = "伝票付箋"
        '    SetStringParam(_項目分類文字型.項目見出し, 0, 28, _lineCount, 36, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'End If
        'work = "受入№"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 38, _lineCount, 44, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = _my項目名称.販売仕入担当者_項目
        'SetStringParam(_項目分類文字型.項目見出し, 0, 45, _lineCount, 51, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = _my項目名称.販売部門
        'SetStringParam(_項目分類文字型.項目見出し, 0, 54, _lineCount, 60, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        ''A-20160324_2↓
        'If _myコントロール情報.使用条件(Myコントロール情報Param.条件型.品目別原価計算機能, 8D) = True Then
        '    'work = "原価計上手配番号"  'D-20170601-X1-項目名統一
        '    work = "原価計上手配№"     'A-20170601-X1-項目名統一
        '    SetStringParam(_項目分類文字型.項目見出し, 0, 63, _lineCount, 75, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'End If
        ''A-20160324_2↑
        'work = "備考"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 76, _lineCount, 80, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = "自動生成"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 107, _lineCount, 115, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = "製番"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 117, _lineCount, 121, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = "伝票消費税"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 131, _lineCount, 141, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        'If _myコントロール情報.Myオプション区分.拡張項目_仕入伝票 = True Then
        '    '■明細見出(ヘッダー項目) - ３行目～７行目
        '    Dim 拡張項目番号 As Integer = 0
        '    Dim i行, i列 As Integer
        '    Dim startCol As Single
        '    Dim endCol As Single
        '    For i行 = 1 To 5
        '        If _伝票拡張項目行出力有無(i行) = True Then
        '            _lineCount += 1
        '            For i列 = 1 To 4
        '                拡張項目番号 += 1
        '                If 拡張伝票.項目情報.項目(拡張項目番号).属性 <> SEI.LIB.ExpandItemControl.項目属性型.拡張項目属性型.未使用 Then
        '                    If 拡張項目番号 >= 10 Then
        '                        work = "伝票拡張" & 拡張項目番号.ToString
        '                    Else
        '                        work = "伝票拡張" & StrConv(拡張項目番号.ToString, VbStrConv.Wide)
        '                    End If
        '                    startCol = 20 + (i列 - 1) * 31
        '                    endCol = startCol + 10
        '                    SetStringParam(_項目分類文字型.項目見出し, 0, startCol, _lineCount, endCol, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        '                    '拡張項目名
        '                    work = "(" & _stringFormat.GetKahenchouStr(拡張伝票.項目情報.項目(拡張項目番号).項目名.TrimEnd, 20) & ")"
        '                    startCol = 30 + (i列 - 1) * 31
        '                    endCol = startCol + 20
        '                    SetStringParam(_項目分類文字型.項目見出し, 0, startCol, _lineCount, endCol, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        '                End If
        '            Next i列
        '        Else
        '            拡張項目番号 += 4
        '        End If
        '    Next i行
        'End If

        ''■明細見出(明細項目) - １行目
        '_lineCount += 1

        'work = "発注№"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 23, _lineCount, 29, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = "明細区分"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 32, _lineCount, 40, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = _my項目名称.販売倉庫
        'SetStringParam(_項目分類文字型.項目見出し, 0, 55, _lineCount, 61, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = "入数"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 68, _lineCount, 72, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = "個数"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 77, _lineCount, 81, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'If _myコントロール情報.My機能区分.消費税改正対応区分 = 機能区分定義型.消費税改正対応区分型.行う Then
        '    work = "上代税"
        '    SetStringParam(_項目分類文字型.項目見出し, 0, 98, _lineCount, 104, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'End If
        'work = "上代単価"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 105, _lineCount, 113, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = "税"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 114, _lineCount, 116, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = "摘要"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 130, _lineCount, 134, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        ''■明細見出(明細項目) - ２行目
        '_lineCount += 1

        'work = "行"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 19, _lineCount, 21, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = "区分"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 27, _lineCount, 31, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = "属性"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 32, _lineCount, 36, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = _my項目名称.販売商品
        'SetStringParam(_項目分類文字型.項目見出し, 0, 37, _lineCount, 43, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = "掛率"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 61, _lineCount, 65, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = "数量"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 77, _lineCount, 81, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = "単位"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 82, _lineCount, 86, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = "仕入単価"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 92, _lineCount, 100, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = "金額"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 109, _lineCount, 113, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = "内消費税等"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 118, _lineCount, 128, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = "税率"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 130, _lineCount, 134, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        ''■明細見出(明細項目) - ３行目
        '_lineCount += 1

        'work = "明細消費税"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 37, _lineCount, 47, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'If _myコントロール情報.Myオプション区分.拡張項目 = オプション区分定義型.区分型.行う AndAlso
        '   _myコントロール情報.My拡張項目.拡張項目入力処理画面表示 = 拡張項目設計型.利用区分型.行う Then
        '    work = "ﾊﾟﾀｰﾝ№"
        '    SetStringParam(_項目分類文字型.項目見出し, 0, 55, _lineCount, 62, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'End If
        'If _myコントロール情報.Myオプション区分.拡張項目_仕入明細 = True AndAlso
        '   拡張明細.付箋情報.使用区分 = [LIB].ExpandItemControl.付箋情報型.使用区分型.使用する Then
        '    work = "明細付箋"
        '    SetStringParam(_項目分類文字型.項目見出し, 0, 64, _lineCount, 72, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'End If
        'work = "ロケーション"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 73, _lineCount, 85, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = "ロット№"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 86, _lineCount, 94, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = _my項目名称.販売有効期限
        'SetStringParam(_項目分類文字型.項目見出し, 0, 107, _lineCount, 115, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = "明細消費税等"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 116, _lineCount, 126, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        'work = "工程"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 130, _lineCount, 134, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = "完成品"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 137, _lineCount, 143, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        ''■明細見出(明細項目) - ４行目
        '_lineCount += 1

        'work = _my項目名称.販売品目名１
        'SetStringParam(_項目分類文字型.項目見出し, 0, 19, _lineCount, 27, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = _my項目名称.販売品目名２
        'SetStringParam(_項目分類文字型.項目見出し, 0, 44, _lineCount, 52, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = _my項目名称.販売品目名３
        'SetStringParam(_項目分類文字型.項目見出し, 0, 69, _lineCount, 77, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = "完納"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 88, _lineCount, 92, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = "発注"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 93, _lineCount, 97, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = "仮単価"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 103, _lineCount, 109, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = "不良数量"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 110, _lineCount, 118, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        'work = "費目"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 124, _lineCount, 128, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = "構成品"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 131, _lineCount, 137, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = "出庫日"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 137, _lineCount, 143, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        ''A-20121217_Ver7.50_1↓
        'If _myコントロール情報.MyMOAオプション.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う Then
        '    '■明細見出(明細項目) - ５行目
        '    _lineCount += 1

        '    work = "換算基準"
        '    SetStringParam(_項目分類文字型.項目見出し, 0, 20, _lineCount, 28, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        '    work = "ﾚｰﾄ種類"
        '    SetStringParam(_項目分類文字型.項目見出し, 0, 29, _lineCount, 36, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        '    work = "レート"
        '    SetStringParam(_項目分類文字型.項目見出し, 0, 40, _lineCount, 46, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        '    work = "諸掛管理№"
        '    SetStringParam(_項目分類文字型.項目見出し, 0, 48, _lineCount, 58, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        '    work = "按分対象"
        '    SetStringParam(_項目分類文字型.項目見出し, 0, 69, _lineCount, 77, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        '    work = "按分基準"
        '    SetStringParam(_項目分類文字型.項目見出し, 0, 78, _lineCount, 86, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        '    work = "INVOICE№"
        '    SetStringParam(_項目分類文字型.項目見出し, 0, 87, _lineCount, 96, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'End If
        ''A-20121217_Ver7.50_1↑

        ''■明細見出(明細項目) - ５行目
        '_lineCount += 1

        'work = "取引"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 20, _lineCount, 24, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = "行"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 25, _lineCount, 27, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = "展開"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 28, _lineCount, 32, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = _my項目名称.販売倉庫
        'SetStringParam(_項目分類文字型.項目見出し, 0, 33, _lineCount, 39, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        ''If _myコントロール情報.MyMOAオプション.MOA品質管理 = MOAオプション定義型.その他管理区分型.行わない Then   'D-20121217_Ver7.50_3
        'If _ロット内訳有無 = False Then                                                                            'A-20121217_Ver7.50_3
        '    work = "ロケーション"
        '    SetStringParam(_項目分類文字型.項目見出し, 0, 40, _lineCount, 52, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'End If
        'work = _my項目名称.販売商品
        'SetStringParam(_項目分類文字型.項目見出し, 0, 53, _lineCount, 59, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = "出庫数量"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 99, _lineCount, 107, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = "単位"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 113, _lineCount, 117, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = "摘要"
        'SetStringParam(_項目分類文字型.項目見出し, 0, 118, _lineCount, 122, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        ''■明細見出(明細項目) - ６行目
        '_lineCount += 1

        'work = _my項目名称.販売品目名１
        'SetStringParam(_項目分類文字型.項目見出し, 0, 20, _lineCount, 28, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = _my項目名称.販売品目名２
        'SetStringParam(_項目分類文字型.項目見出し, 0, 45, _lineCount, 53, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'work = _my項目名称.販売品目名３
        'SetStringParam(_項目分類文字型.項目見出し, 0, 70, _lineCount, 78, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        ''A-20120315_1↓
        'If _myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 3.2D Then
        '    work = "出庫完納"
        '    SetStringParam(_項目分類文字型.項目見出し, 0, 99, _lineCount, 107, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'End If
        ''A-20120315_1↑

        ''If _myコントロール情報.MyMOAオプション.MOA品質管理 = MOAオプション定義型.その他管理区分型.行う Then   'D-20121217_Ver7.50_3
        'If _ロット内訳有無 = True Then                                                                         'A-20121217_Ver7.50_3

        '    '■明細見出(明細項目) - ７行目
        '    _lineCount += 1

        '    work = "ロケーション"
        '    SetStringParam(_項目分類文字型.項目見出し, 0, 22, _lineCount, 34, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        '    If _myコントロール情報.MyMOAオプション.MOA品質管理 = MOAオプション定義型.その他管理区分型.行う Then   'A-20121217_Ver7.50_3
        '        work = "ロット№"
        '        SetStringParam(_項目分類文字型.項目見出し, 0, 35, _lineCount, 43, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        '    End If                                                                                                'A-20121217_Ver7.50_3
        '    work = "ロット別数量"
        '    SetStringParam(_項目分類文字型.項目見出し, 0, 56, _lineCount, 68, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'End If

        ''↓A-2008/07/18_Ver7.30_GENKA
        ''Dim 明細追加行 As Integer = 0

        ''■明細見出(明細項目) - 追加行１
        ''明細追加行 += 1
        ''If _明細追加行出力有無(明細追加行) = True Then
        ''    _lineCount += 1

        ''    If _myコントロール情報.MyＲＥＶ.強化区分 >= 3.0 Then
        ''        work = _my項目名称.販売原価集計
        ''        SetStringParam(_項目分類文字型.項目見出し, 0, 20, _lineCount, 32, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        ''        work = StringFormat(_myImportParam.My項目名称.要素タイトル, 12)
        ''        SetStringParam(_項目分類文字型.項目見出し, 0, 36, _lineCount, 44, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        ''    End If

        ''    '↓A-2009/12/18_Ver7.40_UCHIWAKE
        ''    If _myコントロール情報.MyＲＥＶ.強化区分 >= 4.0 Then
        ''        work = "内訳１"
        ''        SetStringParam(_項目分類文字型.項目見出し, 0, 47, _lineCount, 53, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        ''        work = "内訳２"
        ''        SetStringParam(_項目分類文字型.項目見出し, 0, 60, _lineCount, 66, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        ''        work = "内訳３"
        ''        SetStringParam(_項目分類文字型.項目見出し, 0, 73, _lineCount, 79, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        ''        work = _my項目名称.販売換算数量
        ''        SetStringParam(_項目分類文字型.項目見出し, 0, 88, _lineCount, 100, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        ''        work = "金額算出"
        ''        SetStringParam(_項目分類文字型.項目見出し, 0, 105, _lineCount, 113, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        ''    End If
        ''    '↑A-2009/12/18_Ver7.40_UCHIWAKE

        ''End If
        ''↑A-2008/07/18_Ver7.30_GENKA

        ''↓A-2009/12/18_Ver7.40_LOT
        ''■明細見出(明細項目) - 追加行２
        ''明細追加行 += 1
        ''If _明細追加行出力有無(明細追加行) = True Then
        ''    _lineCount += 1

        ''    If _myコントロール情報.MyＲＥＶ.強化区分 >= 4.0 Then
        ''        work = _my項目名称.販売ロットNo
        ''        SetStringParam(_項目分類文字型.項目見出し, 0, 20, _lineCount, 32, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        ''        work = _my項目名称.販売サブロットNo
        ''        SetStringParam(_項目分類文字型.項目見出し, 0, 47, _lineCount, 59, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        ''        work = "有効期限"
        ''        SetStringParam(_項目分類文字型.項目見出し, 0, 73, _lineCount, 81, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        ''    End If
        ''End If
        ''↑A-2009/12/18_Ver7.40_LOT

        'If _myコントロール情報.Myオプション区分.拡張項目_仕入明細 = True Then
        '    '■明細見出(明細項目) - ４行目～８行目
        '    Dim 拡張項目番号 As Integer = 0
        '    Dim i行, i列 As Integer
        '    Dim startCol As Single
        '    Dim endCol As Single
        '    For i行 = 1 To 5
        '        If _明細拡張項目行出力有無(i行) = True Then
        '            _lineCount += 1
        '            For i列 = 1 To 4
        '                拡張項目番号 += 1
        '                If 拡張明細.項目情報.項目(拡張項目番号).属性 <> SEI.LIB.ExpandItemControl.項目属性型.拡張項目属性型.未使用 Then
        '                    If 拡張項目番号 >= 10 Then
        '                        work = "明細拡張" & 拡張項目番号.ToString
        '                    Else
        '                        work = "明細拡張" & StrConv(拡張項目番号.ToString, VbStrConv.Wide)
        '                    End If
        '                    startCol = 20 + (i列 - 1) * 31
        '                    endCol = startCol + 10
        '                    SetStringParam(_項目分類文字型.項目見出し, 0, startCol, _lineCount, endCol, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        '                    '拡張項目名
        '                    work = "(" & _stringFormat.GetKahenchouStr(拡張明細.項目情報.項目(拡張項目番号).項目名.TrimEnd, 20) & ")"
        '                    startCol = 30 + (i列 - 1) * 31
        '                    endCol = startCol + 20
        '                    SetStringParam(_項目分類文字型.項目見出し, 0, startCol, _lineCount, endCol, _lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        '                End If
        '            Next i列
        '        Else
        '            拡張項目番号 += 4
        '        End If
        '    Next i行
        'End If
        'D-CUST20190830↑

        '■罫線
        'SetLineParam(_項目分類罫線型.枠組み, 0, 13.5, 8, 193.5, 68, ICommon.DrawType.箱, pageParam, _罫線データ件数)                     'D-20170601-X1-行ピッチ変更
        SetLineParam(_項目分類罫線型.枠組み, 0, 13.5, 8, 193.5, MyBase.PageMaxLineCount, ICommon.DrawType.箱, pageParam, _罫線データ件数) 'A-20170601-X1-行ピッチ変更
        SetLineParam(_項目分類罫線型.枠組み, 0, 13.5, 8, 193.5, _lineCount, ICommon.DrawType.箱, pageParam, _罫線データ件数)

        '■網掛
        SetMeshParam(_項目分類網掛型.項目見出し, 0, 13.5, 9, 193.5, _lineCount, pageParam, _網掛データ件数)
        Dim meshSheet As CMN.LIB.PrintingHelper.IMeshSheet
        meshSheet = CMN.LIB.PartReplacement.CommonFactory.CreateInstance(Of CMN.LIB.PrintingHelper.IMeshSheet)(Me, GetType(CMN.LIB.PrintingHelper.MeshSheet))
        meshSheet.Initialize(Me, MyBase.PrintingController)
        'meshSheet.Draw(13.5, _lineCount + 1, 193.5, 68, pageParam, _網掛データ件数)                       'D-20170601-X1-行ピッチ変更
        meshSheet.Draw(13.5, _lineCount + 1, 193.5, MyBase.PageMaxLineCount, pageParam, _網掛データ件数)   'A-20170601-X1-行ピッチ変更

    End Sub

    Private Function EditTextData_Header(ByRef pageParam As Printing.IFormatBase.PageParam,
                                         ByVal lineCount As Integer,
                                         ByRef startLineCount As Integer
                     ) As Integer

        Dim work As String
        Dim テキスト内容配列() As String = _reportEditData.テキスト内容配列

        If lineCount = _明細開始行 OrElse _oldエラー区分 <> _newエラー区分 Then
            If lineCount = _明細開始行 Then
                '先頭行はそのまま印字
            Else
                '先頭行以外は、一行空けて印字
                lineCount += 2
            End If
            work = _newエラー区分
            Call SetStringParam(_項目分類文字型.明細, 0, 14, lineCount, 24, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
            _oldエラー区分 = _newエラー区分
        Else
            lineCount += 1
        End If

        '■テキスト内容 - １行目
        lineCount += 1
        startLineCount = lineCount

        'A-CUST20190830↓
        If _前回値 <> _今回値 Then
            work = テキスト内容配列(出力位置型._001)
            SetStringParam(_項目分類文字型.明細, 0, 15, lineCount, 16, lineCount, work, ICommon.AlignmentType.右詰め, pageParam, _文字データ件数)
            work = テキスト内容配列(出力位置型._002)
            SetStringParam(_項目分類文字型.明細, 0, 22, lineCount, 32, lineCount, work, ICommon.AlignmentType.右詰め, pageParam, _文字データ件数)
        End If

        '以下、明細項目
        work = テキスト内容配列(出力位置型._003)
        SetStringParam(_項目分類文字型.明細, 0, 33, lineCount, 36, lineCount, work, ICommon.AlignmentType.右詰め, pageParam, _文字データ件数)
        work = テキスト内容配列(出力位置型._004)
        SetStringParam(_項目分類文字型.明細, 0, 38, lineCount, 40, lineCount, work, ICommon.AlignmentType.右詰め, pageParam, _文字データ件数)
        work = StringFormat(テキスト内容配列(出力位置型._005), 25)
        SetStringParam(_項目分類文字型.明細, 0, 45, lineCount, 58, lineCount, work, ICommon.AlignmentType.両端揃え, pageParam, _文字データ件数)
        work = テキスト内容配列(出力位置型._006)
        SetStringParam(_項目分類文字型.明細, 0, 59, lineCount, 71, lineCount, work, ICommon.AlignmentType.右詰め, pageParam, _文字データ件数)
        work = テキスト内容配列(出力位置型._007)
        SetStringParam(_項目分類文字型.明細, 0, 72, lineCount, 92, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        work = テキスト内容配列(出力位置型._008)
        SetStringParam(_項目分類文字型.明細, 0, 93, lineCount, 103, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        work = テキスト内容配列(出力位置型._009)
        SetStringParam(_項目分類文字型.明細, 0, 104, lineCount, 110, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        _前回値 = _今回値
        'A-CUST20190830↑

        'D-CUST20190830↓
        'work = テキスト内容配列(仕入データ型.処理連番)
        'SetStringParam(_項目分類文字型.明細, 0, 14, lineCount, 24, lineCount, work, ICommon.AlignmentType.右詰め, pageParam, _文字データ件数)

        'work = テキスト内容配列(仕入データ型.伝票日付)
        'SetStringParam(_項目分類文字型.明細, 0, 25, lineCount, 33, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        'work = テキスト内容配列(仕入データ型.入荷番号)
        'SetStringParam(_項目分類文字型.明細, 0, 36, lineCount, 44, lineCount, work, ICommon.AlignmentType.右詰め, pageParam, _文字データ件数)

        'work = テキスト内容配列(仕入データ型.仕入先コード)
        'SetStringParam(_項目分類文字型.明細, 0, 45, lineCount, 56, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        'work = StringFormat(テキスト内容配列(仕入データ型.仕入先名１), 32)
        'SetStringParam(_項目分類文字型.明細, 0, 57, lineCount, 79, lineCount, work, ICommon.AlignmentType.両端揃え, pageParam, _文字データ件数)

        'work = StringFormat(テキスト内容配列(仕入データ型.仕入先名２), 32)
        'SetStringParam(_項目分類文字型.明細, 0, 80, lineCount, 102, lineCount, work, ICommon.AlignmentType.両端揃え, pageParam, _文字データ件数)

        'work = テキスト内容配列(仕入データ型.支払区分)
        'SetStringParam(_項目分類文字型.明細, 0, 103, lineCount, 104, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        'If _myコントロール情報.MyMOA機能追加.仕入検収基準 = MOA機能追加定義型.その他管理区分型.行う Then
        '    work = テキスト内容配列(仕入データ型.計上区分)
        '    SetStringParam(_項目分類文字型.明細, 0, 109, lineCount, 110, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'End If

        ''work = テキスト内容配列(仕入データ型.相手処理連番)
        ''SetStringParam(_項目分類文字型.明細, 0, 115, lineCount, 125, lineCount, work, ICommon.AlignmentType.右詰め, pageParam, _文字データ件数)

        ''A-20160324_1↓
        'If _myコントロール情報.使用条件(Myコントロール情報Param.条件型.外貨複数伝票消込機能, 8D) = True Then
        '    work = テキスト内容配列(仕入データ型.レート固定区分)
        '    SetStringParam(_項目分類文字型.明細, 0, 114, lineCount, 115, lineCount, work, ICommon.AlignmentType.右詰め, pageParam, _文字データ件数)
        'End If
        ''A-20160324_1↑

        'work = テキスト内容配列(仕入データ型.データ発生区分)
        'SetStringParam(_項目分類文字型.明細, 0, 126, lineCount, 128, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        'work = テキスト内容配列(仕入データ型.消費税仮計上区分)
        'SetStringParam(_項目分類文字型.明細, 0, 131, lineCount, 132, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        ''■テキスト内容 - ２行目
        'lineCount += 1

        'work = テキスト内容配列(仕入データ型.営業所コード)
        'SetStringParam(_項目分類文字型.明細, 0, 14, lineCount, 22, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        'work = テキスト内容配列(仕入データ型.買掛区分)
        'SetStringParam(_項目分類文字型.明細, 0, 23, lineCount, 24, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        'If _myコントロール情報.Myオプション区分.拡張項目_仕入伝票 = True AndAlso
        '   拡張伝票.付箋情報.使用区分 = [LIB].ExpandItemControl.付箋情報型.使用区分型.使用する Then
        '    work = テキスト内容配列(仕入データ型.伝票拡張項目付箋色番号)
        '    SetStringParam(_項目分類文字型.明細, 0, 28, lineCount, 29, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'End If

        'work = テキスト内容配列(仕入データ型.受入番号)
        'SetStringParam(_項目分類文字型.明細, 0, 36, lineCount, 44, lineCount, work, ICommon.AlignmentType.右詰め, pageParam, _文字データ件数)

        'work = テキスト内容配列(仕入データ型.担当者コード)
        'SetStringParam(_項目分類文字型.明細, 0, 45, lineCount, 53, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        'work = テキスト内容配列(仕入データ型.部門コード)
        'SetStringParam(_項目分類文字型.明細, 0, 54, lineCount, 62, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        ''A-20160324_2↓
        'If _myコントロール情報.使用条件(Myコントロール情報Param.条件型.品目別原価計算機能, 8D) = True Then
        '    work = テキスト内容配列(仕入データ型.原価計上手配番号)
        '    SetStringParam(_項目分類文字型.明細, 0, 65, lineCount, 75, lineCount, work, ICommon.AlignmentType.右詰め, pageParam, _文字データ件数)
        'End If
        ''A-20160324_2↑

        'work = テキスト内容配列(仕入データ型.備考コード)
        'SetStringParam(_項目分類文字型.明細, 0, 76, lineCount, 81, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        'work = StringFormat(テキスト内容配列(仕入データ型.備考), 36)
        'SetStringParam(_項目分類文字型.明細, 0, 82, lineCount, 106, lineCount, work, ICommon.AlignmentType.両端揃え, pageParam, _文字データ件数)

        'work = テキスト内容配列(仕入データ型.自動生成区分)
        'SetStringParam(_項目分類文字型.明細, 0, 107, lineCount, 108, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        'work = テキスト内容配列(仕入データ型.製番)
        'SetStringParam(_項目分類文字型.明細, 0, 117, lineCount, 129, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        'work = テキスト内容配列(仕入データ型.伝票消費税計算区分)
        'SetStringParam(_項目分類文字型.明細, 0, 131, lineCount, 132, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        ''■テキスト内容 - ３行目～７行目
        'If _myコントロール情報.Myオプション区分.拡張項目_仕入伝票 = True Then
        '    Dim 拡張項目番号 As Integer = 0
        '    Dim i行, i列 As Integer
        '    Dim startCol As Single
        '    Dim endCol As Single
        '    For i行 = 1 To 5
        '        If _伝票拡張項目行出力有無(i行) = True Then
        '            lineCount += 1
        '            For i列 = 1 To 4
        '                拡張項目番号 += 1
        '                If 拡張伝票.項目情報.項目(拡張項目番号).属性 <> SEI.LIB.ExpandItemControl.項目属性型.拡張項目属性型.未使用 Then
        '                    'work = StringFormat(テキスト内容配列(仕入データ型.伝票拡張項目０１ + 拡張項目番号 - 1), 64)            'D-20170601-X1-桁数拡張
        '                    work = StringFormat拡張項目(テキスト内容配列(仕入データ型.伝票拡張項目０１ + 拡張項目番号 - 1), 64)     'A-20170601-X1-桁数拡張
        '                    startCol = 20 + (i列 - 1) * 31
        '                    endCol = startCol + 30
        '                    SetStringParam(_項目分類文字型.明細, 0, startCol, lineCount, endCol, lineCount, work, ICommon.AlignmentType.両端揃え, pageParam, _文字データ件数)
        '                End If
        '            Next i列
        '        Else
        '            拡張項目番号 += 4
        '        End If
        '    Next i行
        'End If
        'D-CUST20190830↑

        OldKey(KeyType.処理連番) = NewKey(KeyType.処理連番)

        Return lineCount

    End Function

    Private Function EditTextData_Detail(ByRef pageParam As Printing.IFormatBase.PageParam,
                                         ByVal lineCount As Integer,
                                         ByRef startLineCount As Integer
                     ) As Integer

        Dim work As String
        Dim テキスト内容配列() As String = _reportEditData.テキスト内容配列

        If lineCount = _明細開始行 OrElse _oldエラー区分 <> _newエラー区分 Then
            If lineCount = _明細開始行 Then
                '先頭行はそのまま印字
            Else
                lineCount += 2
            End If
            work = _newエラー区分
            Call SetStringParam(_項目分類文字型.明細, 0, 14, lineCount, 24, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
            _oldエラー区分 = _newエラー区分
        Else
            lineCount += 1
        End If

        '■テキスト内容 - １行目
        lineCount += 1
        startLineCount = lineCount

        'A-CUST20190830↓
        work = テキスト内容配列(出力位置型._003)
        SetStringParam(_項目分類文字型.明細, 0, 33, lineCount, 36, lineCount, work, ICommon.AlignmentType.右詰め, pageParam, _文字データ件数)
        work = テキスト内容配列(出力位置型._004)
        SetStringParam(_項目分類文字型.明細, 0, 38, lineCount, 40, lineCount, work, ICommon.AlignmentType.右詰め, pageParam, _文字データ件数)
        work = StringFormat(テキスト内容配列(出力位置型._005), 25)
        SetStringParam(_項目分類文字型.明細, 0, 45, lineCount, 58, lineCount, work, ICommon.AlignmentType.両端揃え, pageParam, _文字データ件数)
        work = テキスト内容配列(出力位置型._006)
        SetStringParam(_項目分類文字型.明細, 0, 59, lineCount, 71, lineCount, work, ICommon.AlignmentType.右詰め, pageParam, _文字データ件数)
        work = テキスト内容配列(出力位置型._007)
        SetStringParam(_項目分類文字型.明細, 0, 72, lineCount, 92, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        work = テキスト内容配列(出力位置型._008)
        SetStringParam(_項目分類文字型.明細, 0, 93, lineCount, 103, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        work = テキスト内容配列(出力位置型._009)
        SetStringParam(_項目分類文字型.明細, 0, 104, lineCount, 110, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'A-CUST20190830↑

        'D-CUST20190830↓
        '        work = テキスト内容配列(仕入データ型.発注番号)
        '        SetStringParam(_項目分類文字型.明細, 0, 19, lineCount, 29, lineCount, work, ICommon.AlignmentType.右詰め, pageParam, _文字データ件数)

        '        work = テキスト内容配列(仕入データ型.明細区分)
        '        SetStringParam(_項目分類文字型.明細, 0, 32, lineCount, 33, lineCount, work, ICommon.AlignmentType.右詰め, pageParam, _文字データ件数)

        '        work = StringFormat(テキスト内容配列(仕入データ型.商品コード), 25)
        '        SetStringParam(_項目分類文字型.明細, 0, 34, lineCount, 54, lineCount, work, ICommon.AlignmentType.両端揃え, pageParam, _文字データ件数)

        '        work = テキスト内容配列(仕入データ型.倉庫コード)
        '        SetStringParam(_項目分類文字型.明細, 0, 55, lineCount, 61, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '        work = テキスト内容配列(仕入データ型.入数)
        '        SetStringParam(_項目分類文字型.明細, 0, 62, lineCount, 72, lineCount, work, ICommon.AlignmentType.右詰め, pageParam, _文字データ件数)

        '        work = テキスト内容配列(仕入データ型.個数)
        '        SetStringParam(_項目分類文字型.明細, 0, 75, lineCount, 81, lineCount, work, ICommon.AlignmentType.右詰め, pageParam, _文字データ件数)

        '        work = テキスト内容配列(仕入データ型.個数単位)
        '        SetStringParam(_項目分類文字型.明細, 0, 82, lineCount, 86, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '        If _myコントロール情報.My機能区分.消費税改正対応区分 = 機能区分定義型.消費税改正対応区分型.行う Then
        '            work = テキスト内容配列(仕入データ型.上代課税区分)
        '            SetStringParam(_項目分類文字型.明細, 0, 98, lineCount, 99, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        '        End If

        '        If _myコントロール情報.My仕入処理.上代 = 仕入処理定義型.上代使用区分型.使用する Then
        '            work = テキスト内容配列(仕入データ型.上代単価)
        '            SetStringParam(_項目分類文字型.明細, 0, 105, lineCount, 113, lineCount, work, ICommon.AlignmentType.右詰め, pageParam, _文字データ件数)
        '        End If

        '        work = テキスト内容配列(仕入データ型.課税区分)
        '        SetStringParam(_項目分類文字型.明細, 0, 114, lineCount, 115, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '        work = テキスト内容配列(仕入データ型.行摘要コード)
        '        SetStringParam(_項目分類文字型.明細, 0, 129, lineCount, 134, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '        work = StringFormat(テキスト内容配列(仕入データ型.行摘要１), 12)
        '        SetStringParam(_項目分類文字型.明細, 0, 135, lineCount, 143, lineCount, work, ICommon.AlignmentType.両端揃え, pageParam, _文字データ件数)

        '        '■テキスト内容 - ２行目
        '        lineCount += 1

        '        work = テキスト内容配列(仕入データ型.行番号)
        '        SetStringParam(_項目分類文字型.明細, 0, 18, lineCount, 21, lineCount, work, ICommon.AlignmentType.右詰め, pageParam, _文字データ件数)

        '        'work = "("
        '        'SetStringParam(_項目分類文字型.明細, 0, 21, lineCount, 22, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '        'work = テキスト内容配列(仕入データ型.発注行番号)
        '        'SetStringParam(_項目分類文字型.明細, 0, 22, lineCount, 25, lineCount, work, ICommon.AlignmentType.右詰め, pageParam, _文字データ件数)

        '        'work = ")"
        '        'SetStringParam(_項目分類文字型.明細, 0, 25, lineCount, 26, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '        work = テキスト内容配列(仕入データ型.取引区分)
        '        SetStringParam(_項目分類文字型.明細, 0, 27, lineCount, 29, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '        work = テキスト内容配列(仕入データ型.取引区分属性)
        '        SetStringParam(_項目分類文字型.明細, 0, 32, lineCount, 33, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '        work = StringFormat(テキスト内容配列(仕入データ型.商品名), 36)
        '        SetStringParam(_項目分類文字型.明細, 0, 34, lineCount, 58, lineCount, work, ICommon.AlignmentType.両端揃え, pageParam, _文字データ件数)

        '        work = テキスト内容配列(仕入データ型.単価掛率)
        '        SetStringParam(_項目分類文字型.明細, 0, 60, lineCount, 65, lineCount, work, ICommon.AlignmentType.右詰め, pageParam, _文字データ件数)

        '        work = テキスト内容配列(仕入データ型.数量)
        '        SetStringParam(_項目分類文字型.明細, 0, 68, lineCount, 81, lineCount, work, ICommon.AlignmentType.右詰め, pageParam, _文字データ件数)

        '        work = テキスト内容配列(仕入データ型.数量単位)
        '        SetStringParam(_項目分類文字型.明細, 0, 82, lineCount, 86, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '        work = テキスト内容配列(仕入データ型.単価)
        '        SetStringParam(_項目分類文字型.明細, 0, 87, lineCount, 100, lineCount, work, ICommon.AlignmentType.右詰め, pageParam, _文字データ件数)

        '        work = テキスト内容配列(仕入データ型.金額)
        '        SetStringParam(_項目分類文字型.明細, 0, 102, lineCount, 113, lineCount, work, ICommon.AlignmentType.右詰め, pageParam, _文字データ件数)
        '        If _伝票合計金額不正 = False Then
        '            If 伝票合計金額加算(work) = False Then
        '                _伝票合計金額不正 = True
        '            End If
        '        End If

        '        work = テキスト内容配列(仕入データ型.内消費税等)
        '        SetStringParam(_項目分類文字型.明細, 0, 117, lineCount, 128, lineCount, work, ICommon.AlignmentType.右詰め, pageParam, _文字データ件数)

        '        work = テキスト内容配列(仕入データ型.消費税率)
        '        SetStringParam(_項目分類文字型.明細, 0, 129, lineCount, 134, lineCount, work, ICommon.AlignmentType.右詰め, pageParam, _文字データ件数)

        '        work = StringFormat(テキスト内容配列(仕入データ型.行摘要２), 12)
        '        SetStringParam(_項目分類文字型.明細, 0, 135, lineCount, 143, lineCount, work, ICommon.AlignmentType.両端揃え, pageParam, _文字データ件数)

        '        '■テキスト内容 - ３行目
        '        lineCount += 1

        '        work = テキスト内容配列(仕入データ型.明細消費税計算区分)
        '        SetStringParam(_項目分類文字型.明細, 0, 37, lineCount, 38, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '        If _myコントロール情報.Myオプション区分.拡張項目 = オプション区分定義型.区分型.行う AndAlso
        '           _myコントロール情報.My拡張項目.拡張項目入力処理画面表示 = 拡張項目設計型.利用区分型.行う Then
        '            work = テキスト内容配列(仕入データ型.拡張項目入力パターン番号)
        '            SetStringParam(_項目分類文字型.明細, 0, 55, lineCount, 59, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        '        End If

        '        If _myコントロール情報.Myオプション区分.拡張項目_仕入明細 = True AndAlso
        '           拡張明細.付箋情報.使用区分 = [LIB].ExpandItemControl.付箋情報型.使用区分型.使用する Then
        '            work = テキスト内容配列(仕入データ型.明細拡張項目付箋色番号)
        '            SetStringParam(_項目分類文字型.明細, 0, 64, lineCount, 65, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        '        End If

        '        work = テキスト内容配列(仕入データ型.ロケーション)
        '        SetStringParam(_項目分類文字型.明細, 0, 73, lineCount, 83, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '        If _myコントロール情報.MyMOAオプション.MOA品質管理 = MOAオプション定義型.その他管理区分型.行う Then
        '            work = テキスト内容配列(仕入データ型.ロット_Ｎｏ)
        '            SetStringParam(_項目分類文字型.明細, 0, 86, lineCount, 106, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '            work = テキスト内容配列(仕入データ型.有効期限)
        '            SetStringParam(_項目分類文字型.明細, 0, 107, lineCount, 115, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        '        End If

        '        work = テキスト内容配列(仕入データ型.明細消費税等)
        '        SetStringParam(_項目分類文字型.明細, 0, 117, lineCount, 128, lineCount, work, ICommon.AlignmentType.右詰め, pageParam, _文字データ件数)

        '        work = テキスト内容配列(仕入データ型.工程コード)
        '        SetStringParam(_項目分類文字型.明細, 0, 130, lineCount, 136, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '        work = テキスト内容配列(仕入データ型.完成品区分)
        '        SetStringParam(_項目分類文字型.明細, 0, 137, lineCount, 138, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '        '■テキスト内容 - ４行目
        '        lineCount += 1

        '        work = テキスト内容配列(仕入データ型.品名１)
        '        SetStringParam(_項目分類文字型.明細, 0, 19, lineCount, 43, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '        work = テキスト内容配列(仕入データ型.品名２)
        '        SetStringParam(_項目分類文字型.明細, 0, 44, lineCount, 68, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '        work = テキスト内容配列(仕入データ型.品名３)
        '        SetStringParam(_項目分類文字型.明細, 0, 69, lineCount, 87, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '        work = テキスト内容配列(仕入データ型.完納区分)
        '        SetStringParam(_項目分類文字型.明細, 0, 88, lineCount, 89, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '        work = テキスト内容配列(仕入データ型.発注区分)
        '        SetStringParam(_項目分類文字型.明細, 0, 93, lineCount, 94, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '        work = テキスト内容配列(仕入データ型.仮単価区分)
        '        SetStringParam(_項目分類文字型.明細, 0, 103, lineCount, 104, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '        work = テキスト内容配列(仕入データ型.不良数量)
        '        SetStringParam(_項目分類文字型.明細, 0, 111, lineCount, 123, lineCount, work, ICommon.AlignmentType.右詰め, pageParam, _文字データ件数)

        '        If _myコントロール情報.MyMOAオプション.MOA原価管理 = MOAオプション定義型.その他管理区分型.行う Then
        '            work = テキスト内容配列(仕入データ型.費目コード)
        '            SetStringParam(_項目分類文字型.明細, 0, 124, lineCount, 130, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        '        End If

        '        work = テキスト内容配列(仕入データ型.構成品出庫生成区分)
        '        SetStringParam(_項目分類文字型.明細, 0, 131, lineCount, 132, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '        work = テキスト内容配列(仕入データ型.出庫日)
        '        SetStringParam(_項目分類文字型.明細, 0, 135, lineCount, 143, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '        'A-20121217_Ver7.50_1↓
        '        If _myコントロール情報.MyMOAオプション.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う Then
        '            '■テキスト内容 - ５行目
        '            lineCount += 1

        '            work = テキスト内容配列(仕入データ型.換算基準)
        '            SetStringParam(_項目分類文字型.明細, 0, 20, lineCount, 21, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '            work = テキスト内容配列(仕入データ型.レート種類)
        '            SetStringParam(_項目分類文字型.明細, 0, 29, lineCount, 30, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '            work = テキスト内容配列(仕入データ型.レート)
        '            SetStringParam(_項目分類文字型.明細, 0, 36, lineCount, 46, lineCount, work, ICommon.AlignmentType.右詰め, pageParam, _文字データ件数)

        '            work = テキスト内容配列(仕入データ型.諸掛管理_Ｎｏ)
        '            SetStringParam(_項目分類文字型.明細, 0, 48, lineCount, 68, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '            work = テキスト内容配列(仕入データ型.按分対象)
        '            SetStringParam(_項目分類文字型.明細, 0, 69, lineCount, 70, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '            work = テキスト内容配列(仕入データ型.按分基準)
        '            SetStringParam(_項目分類文字型.明細, 0, 79, lineCount, 80, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '            work = テキスト内容配列(仕入データ型.INVOICE_Ｎｏ)
        '            SetStringParam(_項目分類文字型.明細, 0, 87, lineCount, 107, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        '        End If
        '        'A-20121217_Ver7.50_1↑


        '        '*** 同一入荷内の構成品-内訳ロットを出力
        '        Dim reportReadData As New TextFileImportLib.ReportData型
        '        Dim 配列位置 As Integer = _reportData配列位置
        '        Dim テキスト内容配列_構成品() As String
        '        Dim setKey(0 To KeyType.項目数 - 1) As String
        '        Dim 同一構成品_内訳行数 As Integer = 0
        '        Dim firstflg As Boolean = True

        '        'テキスト１行目のデータを設定
        '        setKey = _newKey

        '        Do While 配列位置 <= _reportDataBlock.Count - 1

        '            '配列から1件取り出す...
        '            reportReadData = _reportDataBlock.Item(配列位置)
        '            テキスト内容配列_構成品 = Split(reportReadData.テキスト内容帳票出力用, TextFileImportLib.TAB_STRING)

        '            If setKey(KeyType.処理連番) = テキスト内容配列_構成品(仕入データ型.処理連番).TrimEnd AndAlso
        '               setKey(KeyType.明細区分) = テキスト内容配列_構成品(仕入データ型.明細区分).TrimEnd AndAlso
        '               setKey(KeyType.行番号) = テキスト内容配列_構成品(仕入データ型.行番号).TrimEnd Then
        '                '同一親品目
        '            Else
        '                GoTo EditTestData_Detail_構成品後
        '            End If

        '            If firstflg = False AndAlso
        '               setKey(KeyType.構成品出庫生成区分) = テキスト内容配列_構成品(仕入データ型.構成品出庫生成区分).TrimEnd AndAlso
        '               setKey(KeyType.構成品_取引区分) = テキスト内容配列_構成品(仕入データ型.構成品_取引区分).TrimEnd AndAlso
        '               setKey(KeyType.構成品_行番号) = テキスト内容配列_構成品(仕入データ型.構成品_行).TrimEnd Then
        '                '同一子品目

        '                'If _myコントロール情報.MyMOAオプション.MOA品質管理 = MOAオプション定義型.その他管理区分型.行う Then   'D-20121217_Ver7.50_3
        '                If _ロット内訳有無 = True Then                                                                         'A-20121217_Ver7.50_3

        '                    '■テキスト内容 - ７行目(構成品３行目-内訳)
        '                    lineCount += 1

        '                    'If lineCount + 1 > LINE_COUNT_MAX Then         'D-20170601-X1-行ピッチ変更
        '                    If lineCount + 1 > MyBase.PageMaxLineCount Then 'A-20170601-X1-行ピッチ変更
        '                        If _構成品時改頁 = False Then
        '                            '警告・エラー内容を出力し、行数を返す
        '                            Dim 改頁有無 As TextFileImportLib.有無区分型
        '                            Dim i警告＿エラー As Integer = EditErrorAndWorning(pageParam, startLineCount - 1, 改頁有無)    'X1変換Tool-20170508

        '                            'テキスト内容 or 警告・エラー内容 の行数の多い方を採用
        '                            If 改頁有無 = TextFileImportLib.有無区分型.有 Then
        '                                lineCount = _明細開始行
        '                            End If
        '                        End If

        '                        _構成品時改頁 = True

        '                        '* ========== >
        '                        '*  ヘッダー編集
        '                        '* < ==========
        '                        Call EditReportHeader(pageParam)
        '                        lineCount = _明細開始行

        '                        work = _newエラー区分
        '                        Call SetStringParam(_項目分類文字型.明細, 0, 14, _明細開始行, 24, _明細開始行, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '                        lineCount += 1
        '                    End If

        '                    work = テキスト内容配列_構成品(仕入データ型.構成品_ロケーション)
        '                    SetStringParam(_項目分類文字型.明細, 0, 22, lineCount, 32, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '                    If テキスト内容配列_構成品(仕入データ型.構成品出庫生成区分).TrimEnd = "1" Then
        '                        '構成品出庫生成区分=1:する の場合

        '                        If _myコントロール情報.MyMOAオプション.MOA品質管理 = MOAオプション定義型.その他管理区分型.行う Then   'A-20121217_Ver7.50_3
        '                            work = テキスト内容配列_構成品(仕入データ型.内訳_ロット_Ｎｏ)
        '                            SetStringParam(_項目分類文字型.明細, 0, 35, lineCount, 55, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        '                        End If                                                                                                'A-20121217_Ver7.50_3

        '                        work = テキスト内容配列_構成品(仕入データ型.内訳_ロット別数量)
        '                        SetStringParam(_項目分類文字型.明細, 0, 56, lineCount, 69, lineCount, work, ICommon.AlignmentType.右詰め, pageParam, _文字データ件数)
        '                    End If

        '                End If
        '            Else
        '                '■テキスト内容 - ５行目(構成品１行目)
        '                lineCount += 1

        '                'If lineCount + 1 > LINE_COUNT_MAX Then         'D-20170601-X1-行ピッチ変更
        '                If lineCount + 1 > MyBase.PageMaxLineCount Then 'A-20170601-X1-行ピッチ変更
        '                    If _構成品時改頁 = False Then
        '                        '警告・エラー内容を出力し、行数を返す
        '                        Dim 改頁有無 As TextFileImportLib.有無区分型
        '                        Dim i警告＿エラー As Integer = EditErrorAndWorning(pageParam, startLineCount - 1, 改頁有無)    'X1変換Tool-20170508

        '                        'テキスト内容 or 警告・エラー内容 の行数の多い方を採用
        '                        If 改頁有無 = TextFileImportLib.有無区分型.有 Then
        '                            lineCount = _明細開始行
        '                        End If
        '                    End If

        '                    _構成品時改頁 = True

        '                    '* ========== >
        '                    '*  ヘッダー編集
        '                    '* < ==========
        '                    Call EditReportHeader(pageParam)
        '                    lineCount = _明細開始行

        '                    work = _newエラー区分
        '                    Call SetStringParam(_項目分類文字型.明細, 0, 14, _明細開始行, 24, _明細開始行, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '                    lineCount += 1
        '                End If

        '                work = テキスト内容配列_構成品(仕入データ型.構成品_取引区分)
        '                SetStringParam(_項目分類文字型.明細, 0, 20, lineCount, 21, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '                work = テキスト内容配列_構成品(仕入データ型.構成品_行)
        '                SetStringParam(_項目分類文字型.明細, 0, 24, lineCount, 27, lineCount, work, ICommon.AlignmentType.右詰め, pageParam, _文字データ件数)

        '                work = テキスト内容配列_構成品(仕入データ型.構成品_展開順序番号)
        '                SetStringParam(_項目分類文字型.明細, 0, 29, lineCount, 32, lineCount, work, ICommon.AlignmentType.右詰め, pageParam, _文字データ件数)

        '                work = テキスト内容配列_構成品(仕入データ型.構成品_倉庫コード)
        '                SetStringParam(_項目分類文字型.明細, 0, 33, lineCount, 39, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '                'If _myコントロール情報.MyMOAオプション.MOA品質管理 = MOAオプション定義型.その他管理区分型.行わない Then   'D-20121217_Ver7.50_3
        '                If _ロット内訳有無 = False Then                                                                            'A-20121217_Ver7.50_3
        '                    work = テキスト内容配列_構成品(仕入データ型.構成品_ロケーション)
        '                    SetStringParam(_項目分類文字型.明細, 0, 40, lineCount, 50, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        '                End If

        '                work = テキスト内容配列_構成品(仕入データ型.構成品_商品コード)
        '                SetStringParam(_項目分類文字型.明細, 0, 52, lineCount, 72, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '                work = テキスト内容配列_構成品(仕入データ型.構成品_商品名)
        '                SetStringParam(_項目分類文字型.明細, 0, 73, lineCount, 97, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '                work = テキスト内容配列_構成品(仕入データ型.構成品_出庫数量)
        '                SetStringParam(_項目分類文字型.明細, 0, 99, lineCount, 112, lineCount, work, ICommon.AlignmentType.右詰め, pageParam, _文字データ件数)

        '                work = テキスト内容配列_構成品(仕入データ型.構成品_出庫単位)
        '                SetStringParam(_項目分類文字型.明細, 0, 113, lineCount, 117, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '                work = テキスト内容配列_構成品(仕入データ型.構成品_行摘要コード)
        '                SetStringParam(_項目分類文字型.明細, 0, 118, lineCount, 123, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '                work = テキスト内容配列_構成品(仕入データ型.構成品_行摘要１)
        '                SetStringParam(_項目分類文字型.明細, 0, 124, lineCount, 132, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '                work = テキスト内容配列_構成品(仕入データ型.構成品_行摘要２)
        '                SetStringParam(_項目分類文字型.明細, 0, 133, lineCount, 141, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '                '■テキスト内容 - ６行目(構成品２行目)
        '                lineCount += 1

        '                'If lineCount + 1 > LINE_COUNT_MAX Then         'D-20170601-X1-行ピッチ変更
        '                If lineCount + 1 > MyBase.PageMaxLineCount Then 'A-20170601-X1-行ピッチ変更
        '                    If _構成品時改頁 = False Then
        '                        '警告・エラー内容を出力し、行数を返す
        '                        Dim 改頁有無 As TextFileImportLib.有無区分型
        '                        Dim i警告＿エラー As Integer = EditErrorAndWorning(pageParam, startLineCount - 1, 改頁有無)    'X1変換Tool-20170508

        '                        'テキスト内容 or 警告・エラー内容 の行数の多い方を採用
        '                        If 改頁有無 = TextFileImportLib.有無区分型.有 Then
        '                            lineCount = _明細開始行
        '                        End If
        '                    End If

        '                    _構成品時改頁 = True

        '                    '* ========== >
        '                    '*  ヘッダー編集
        '                    '* < ==========
        '                    Call EditReportHeader(pageParam)
        '                    lineCount = _明細開始行

        '                    work = _newエラー区分
        '                    Call SetStringParam(_項目分類文字型.明細, 0, 14, _明細開始行, 24, _明細開始行, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '                    lineCount += 1
        '                End If

        '                work = テキスト内容配列_構成品(仕入データ型.構成品_品名１)
        '                SetStringParam(_項目分類文字型.明細, 0, 20, lineCount, 44, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '                work = テキスト内容配列_構成品(仕入データ型.構成品_品名２)
        '                SetStringParam(_項目分類文字型.明細, 0, 45, lineCount, 69, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '                work = テキスト内容配列_構成品(仕入データ型.構成品_品名３)
        '                SetStringParam(_項目分類文字型.明細, 0, 70, lineCount, 88, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '                'A-20120315_1↓
        '                If _myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 3.2D Then
        '                    work = テキスト内容配列_構成品(仕入データ型.構成品_完納区分)
        '                    SetStringParam(_項目分類文字型.明細, 0, 99, lineCount, 100, lineCount, work, ICommon.AlignmentType.右詰め, pageParam, _文字データ件数)
        '                End If
        '                'A-20120315_1↑

        '                'If _myコントロール情報.MyMOAオプション.MOA品質管理 = MOAオプション定義型.その他管理区分型.行う Then   'D-20121217_Ver7.50_3
        '                If _ロット内訳有無 = True Then                                                                         'A-20121217_Ver7.50_3

        '                    '■テキスト内容 - ７行目(構成品３行目-内訳)
        '                    lineCount += 1

        '                    'If lineCount + 1 > LINE_COUNT_MAX Then         'D-20170601-X1-行ピッチ変更
        '                    If lineCount + 1 > MyBase.PageMaxLineCount Then 'A-20170601-X1-行ピッチ変更
        '                        If _構成品時改頁 = False Then
        '                            '警告・エラー内容を出力し、行数を返す
        '                            Dim 改頁有無 As TextFileImportLib.有無区分型
        '                            Dim i警告＿エラー As Integer = EditErrorAndWorning(pageParam, startLineCount - 1, 改頁有無)    'X1変換Tool-20170508

        '                            'テキスト内容 or 警告・エラー内容 の行数の多い方を採用
        '                            If 改頁有無 = TextFileImportLib.有無区分型.有 Then
        '                                lineCount = _明細開始行
        '                            End If
        '                        End If

        '                        _構成品時改頁 = True

        '                        '* ========== >
        '                        '*  ヘッダー編集
        '                        '* < ==========
        '                        Call EditReportHeader(pageParam)
        '                        lineCount = _明細開始行

        '                        work = _newエラー区分
        '                        Call SetStringParam(_項目分類文字型.明細, 0, 14, _明細開始行, 24, _明細開始行, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '                        lineCount += 1
        '                    End If

        '                    work = テキスト内容配列_構成品(仕入データ型.構成品_ロケーション)
        '                    SetStringParam(_項目分類文字型.明細, 0, 22, lineCount, 32, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '                    If テキスト内容配列_構成品(仕入データ型.構成品出庫生成区分).TrimEnd = "1" Then
        '                        '構成品出庫生成区分=1:する の場合

        '                        If _myコントロール情報.MyMOAオプション.MOA品質管理 = MOAオプション定義型.その他管理区分型.行う Then   'A-20121217_Ver7.50_3
        '                            work = テキスト内容配列_構成品(仕入データ型.内訳_ロット_Ｎｏ)
        '                            SetStringParam(_項目分類文字型.明細, 0, 35, lineCount, 55, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        '                        End If                                                                                                'A-20121217_Ver7.50_3

        '                        work = テキスト内容配列_構成品(仕入データ型.内訳_ロット別数量)
        '                        SetStringParam(_項目分類文字型.明細, 0, 56, lineCount, 69, lineCount, work, ICommon.AlignmentType.右詰め, pageParam, _文字データ件数)

        '                    End If

        '                End If
        '            End If

        '            '表示内容[KEY]の退避
        '            setKey(KeyType.構成品出庫生成区分) = テキスト内容配列_構成品(仕入データ型.構成品出庫生成区分).TrimEnd
        '            setKey(KeyType.構成品_取引区分) = テキスト内容配列_構成品(仕入データ型.構成品_取引区分).TrimEnd
        '            setKey(KeyType.構成品_行番号) = テキスト内容配列_構成品(仕入データ型.構成品_行).TrimEnd

        '            配列位置 += 1
        '            firstflg = False
        '        Loop

        'EditTestData_Detail_構成品後:

        '        ''↓A-2008/07/18_Ver7.30_GENKA
        '        'Dim 明細追加行 As Integer = 0

        '        ''■明細見出(明細項目) - 追加行１
        '        '明細追加行 += 1
        '        'If _明細追加行出力有無(明細追加行) = True Then
        '        '    lineCount += 1

        '        '    If _myコントロール情報.MyＲＥＶ.強化区分 >= 3.0 Then
        '        '        If テキスト内容配列(仕入データ型.原価集計メインコード).TrimEnd <> "" OrElse _
        '        '           テキスト内容配列(仕入データ型.原価集計サブコード).TrimEnd <> "" Then
        '        '            Dim 原価集計コード As String
        '        '            原価集計コード = テキスト内容配列(仕入データ型.原価集計メインコード) & "-" & テキスト内容配列(仕入データ型.原価集計サブコード)
        '        '            work = StringFormat(原価集計コード, 23)
        '        '            SetStringParam(_項目分類文字型.明細, 0, 20, lineCount, 35, lineCount, work, ICommon.AlignmentType.両端揃え, pageParam, _文字データ件数)
        '        '        End If

        '        '        work = テキスト内容配列(仕入データ型.要素コード)
        '        '        SetStringParam(_項目分類文字型.明細, 0, 36, lineCount, 44, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        '        '    End If

        '        '    '↓A-2009/12/18_Ver7.40_UCHIWAKE
        '        '    If _myコントロール情報.MyＲＥＶ.強化区分 >= 4.0 Then
        '        '        If _myコントロール情報.My商品内訳管理.内訳タイプ = 商品管理拡張定義型.内訳タイプ型.マスター Then
        '        '            '内訳タイプ：マスター
        '        '            work = テキスト内容配列(仕入データ型.内訳コード１)
        '        '            SetStringParam(_項目分類文字型.明細, 0, 47, lineCount, 59, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '        '            work = テキスト内容配列(仕入データ型.内訳コード２)
        '        '            SetStringParam(_項目分類文字型.明細, 0, 60, lineCount, 72, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '        '            work = テキスト内容配列(仕入データ型.内訳コード３)
        '        '            SetStringParam(_項目分類文字型.明細, 0, 73, lineCount, 85, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        '        '        Else
        '        '            '内訳タイプ：数値
        '        '            work = テキスト内容配列(仕入データ型.内訳コード１)
        '        '            SetStringParam(_項目分類文字型.明細, 0, 49, lineCount, 59, lineCount, work, ICommon.AlignmentType.右詰め, pageParam, _文字データ件数)

        '        '            work = テキスト内容配列(仕入データ型.内訳コード２)
        '        '            SetStringParam(_項目分類文字型.明細, 0, 62, lineCount, 72, lineCount, work, ICommon.AlignmentType.右詰め, pageParam, _文字データ件数)

        '        '            work = テキスト内容配列(仕入データ型.内訳コード３)
        '        '            SetStringParam(_項目分類文字型.明細, 0, 75, lineCount, 85, lineCount, work, ICommon.AlignmentType.右詰め, pageParam, _文字データ件数)
        '        '        End If

        '        '        work = テキスト内容配列(仕入データ型.換算数量)
        '        '        SetStringParam(_項目分類文字型.明細, 0, 87, lineCount, 100, lineCount, work, ICommon.AlignmentType.右詰め, pageParam, _文字データ件数)

        '        '        work = テキスト内容配列(仕入データ型.金額算出モード)
        '        '        SetStringParam(_項目分類文字型.明細, 0, 112, lineCount, 113, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        '        '    End If
        '        '    '↑A-2009/12/18_Ver7.40_UCHIWAKE
        '        'End If
        '        ''↑A-2008/07/18_Ver7.30_GENKA

        '        ''↓A-2009/12/18_Ver7.40_LOT
        '        ''■明細見出(明細項目) - 追加行２
        '        '明細追加行 += 1
        '        'If _明細追加行出力有無(明細追加行) = True Then
        '        '    lineCount += 1

        '        '    If _myコントロール情報.MyＲＥＶ.強化区分 >= 4.0 Then
        '        '        work = テキスト内容配列(仕入データ型.ロットNo)
        '        '        SetStringParam(_項目分類文字型.明細, 0, 20, lineCount, 40, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '        '        work = テキスト内容配列(仕入データ型.サブロットNo)
        '        '        SetStringParam(_項目分類文字型.明細, 0, 47, lineCount, 67, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)

        '        '        work = テキスト内容配列(仕入データ型.有効期限)
        '        '        SetStringParam(_項目分類文字型.明細, 0, 73, lineCount, 81, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        '        '    End If
        '        'End If
        '        ''↑A-2009/12/18_Ver7.40_LOT

        '        '■テキスト内容 - ４行目～８行目
        '        If _myコントロール情報.Myオプション区分.拡張項目_仕入明細 = True Then
        '            Dim 拡張項目番号 As Integer = 0
        '            Dim i行, i列 As Integer
        '            Dim startCol As Single
        '            Dim endCol As Single
        '            For i行 = 1 To 5
        '                If _明細拡張項目行出力有無(i行) = True Then
        '                    lineCount += 1
        '                    For i列 = 1 To 4
        '                        拡張項目番号 += 1
        '                        If 拡張明細.項目情報.項目(拡張項目番号).属性 <> SEI.LIB.ExpandItemControl.項目属性型.拡張項目属性型.未使用 Then
        '                            'work = StringFormat(テキスト内容配列(仕入データ型.明細拡張項目０１ + 拡張項目番号 - 1), 64)            'D-20170601-X1-桁数拡張
        '                            work = StringFormat拡張項目(テキスト内容配列(仕入データ型.明細拡張項目０１ + 拡張項目番号 - 1), 64)     'A-20170601-X1-桁数拡張
        '                            startCol = 20 + (i列 - 1) * 31
        '                            endCol = startCol + 30
        '                            SetStringParam(_項目分類文字型.明細, 0, startCol, lineCount, endCol, lineCount, work, ICommon.AlignmentType.両端揃え, pageParam, _文字データ件数)
        '                        End If
        '                    Next i列
        '                Else
        '                    拡張項目番号 += 4
        '                End If
        '            Next i行
        '        End If
        'D-CUST20190830↑

        OldKey(KeyType.明細区分) = NewKey(KeyType.明細区分)
        OldKey(KeyType.行番号) = NewKey(KeyType.行番号)
        OldKey(KeyType.構成品出庫生成区分) = NewKey(KeyType.構成品出庫生成区分)
        OldKey(KeyType.構成品_取引区分) = NewKey(KeyType.構成品_取引区分)
        OldKey(KeyType.構成品_行番号) = NewKey(KeyType.構成品_行番号)

        OldKey(KeyType.親品目判断) = NewKey(KeyType.親品目判断)
        OldKey(KeyType.子品目判断) = NewKey(KeyType.子品目判断)

        OldKey(KeyType.W091行番号) = NewKey(KeyType.W091行番号)

        Return lineCount
    End Function

    Private Function EditTextData_Footer(ByRef pageParam As Printing.IFormatBase.PageParam,
                                         ByVal lineCount As Integer
                     ) As Integer
        Dim work As String

        'If lineCount + 1 > LINE_COUNT_MAX Then         'D-20170601-X1-行ピッチ変更
        If lineCount + 1 > MyBase.PageMaxLineCount Then 'A-20170601-X1-行ピッチ変更
            '* ========== >
            '*  ヘッダー編集
            '* < ==========
            Call EditReportHeader(pageParam)
            lineCount = _明細開始行

            work = _newエラー区分
            Call SetStringParam(_項目分類文字型.明細, 0, 14, lineCount, 24, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        End If

        'D-CUST20190830↓
        'lineCount += 1

        ''伝票合計金額
        'work = "【伝票合計】"
        'Call SetStringParam(_項目分類文字型.明細, 0, 89, lineCount, 101, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
        'If _伝票合計金額不正 = True Then
        '    work = "***********"
        'Else
        '    work = CStr(_伝票合計金額)
        'End If
        'Call SetStringParam(_項目分類文字型.明細, 0, 102, lineCount, 113, lineCount, work, ICommon.AlignmentType.右詰め, pageParam, _文字データ件数)
        'D-CUST20190830↑

        _伝票合計金額 = 0
        _伝票合計金額不正 = False

        _lineCount = lineCount

    End Function

    Private Function EditErrorAndWorning(ByRef pageParam As Printing.IFormatBase.PageParam,
                                         ByVal lineCount As Integer,
                                         ByRef 改頁有無 As TextFileImportLib.有無区分型
                     ) As Integer

        改頁有無 = TextFileImportLib.有無区分型.無
        Dim work As String
        Dim reportHelper As IReportHelper = New ReportHelper

        Dim i As Integer
        For i = 0 To _reportEditData.MaxIndex

            'If lineCount + 1 > LINE_COUNT_MAX Then         'D-20170601-X1-行ピッチ変更
            If lineCount + 1 > MyBase.PageMaxLineCount Then 'A-20170601-X1-行ピッチ変更
                '* ========== >
                '*  ヘッダー編集
                '* < ==========
                Call EditReportHeader(pageParam)
                lineCount = _明細開始行
                改頁有無 = TextFileImportLib.有無区分型.有

                work = _newエラー区分
                Call SetStringParam(_項目分類文字型.明細, 0, 14, _明細開始行, 24, _明細開始行, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
            End If

            lineCount += 1
            '■警告・エラー内容
            work = _reportEditData.エラー内容１配列(i)
            'SetStringParam(_項目分類文字型.明細, 0, 144, lineCount, 168, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)   'D-CUST20190830
            SetStringParam(_項目分類文字型.明細, 0, 113, lineCount, 139, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)    'A-CUST20190830
            work = _reportEditData.エラー内容２配列(i)
            'SetStringParam(_項目分類文字型.明細, 0, 169, lineCount, 193, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)   'D-CUST20190830
            SetStringParam(_項目分類文字型.明細, 0, 140, lineCount, 166, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)    'A-CUST20190830
            'A-CUST20190830↓
            work = _reportEditData.エラー内容３配列(i)
            SetStringParam(_項目分類文字型.明細, 0, 167, lineCount, 193, lineCount, work, ICommon.AlignmentType.左詰め, pageParam, _文字データ件数)
            'A-CUST20190830↑
        Next

        Return lineCount

    End Function

    ''' <summary>
    ''' フッター編集
    ''' </summary>
    ''' <param name="pageParam"></param>
    ''' <remarks></remarks>
    Private Sub EditReportFooter(ByRef pageParam As OSK.X1.Printing.IFormatBase.PageParam)    'X1変換Tool-20170508

        _pageCount += 1

        Dim footerWriter As SEI.LIB.PrintingAssist.IFooterWriter
        footerWriter = CMN.LIB.PartReplacement.CommonFactory.CreateInstance(Of SEI.LIB.PrintingAssist.IFooterWriter)(Me, GetType(SEI.LIB.PrintingAssist.FooterWriter))
        footerWriter.Initialize(Me) '必須
        'footerWriter.Write(70, 12, 193, _printDataTime, _pageCount, MyBase.PrintingController, pageParam, _文字データ件数)                                'D-20170601-X1-行ピッチ変更
        footerWriter.Write(CInt(MyBase.PageMaxLineCount) + 2, 12, 193, _printDataTime, _pageCount, MyBase.PrintingController, pageParam, _文字データ件数)  'A-20170601-X1-行ピッチ変更

        'フッターを編集したら１頁分のデータを格納!!
        MyBase.PrintingController.Action(_pageParam, ICommon.JobMode.既存のジョブに追加して処理続行)
        Call MyBase.WaitPrintPreview()
        pageParam = Nothing

        '↓A-2007/10/24
        _罫線データ件数 = 0
        _文字データ件数 = 0
        _網掛データ件数 = 0
        '↑A-2007/10/24

        _isPrint = False

    End Sub

    ''' <summary>
    ''' 文字列整形
    ''' </summary>
    ''' <param name="text">文字列</param>
    ''' <param name="length">桁数</param>
    ''' <returns></returns>
    ''' <remarks>
    ''' 渡された文字列を指定した桁数に編集する
    ''' (渡された文字列桁数 > 指定桁数の場合はそのまま)
    ''' </remarks>
    Private Function StringFormat(ByVal text As String, ByVal length As Integer) As String

        Dim stringFormatter As CMN.LIB.StringFormat.IStringFormat
        stringFormatter = CMN.LIB.PartReplacement.CommonFactory.CreateInstance(Of CMN.LIB.StringFormat.IStringFormat)(Me, GetType(CMN.LIB.StringFormat.StringFormat))

        If length < 1 Then
            Return ""
        End If

        If OSK.X1.Foundation.TextUtility.GetTextLength(text) > length Then    'X1変換Tool-20170508
            Return text
        End If

        Return stringFormatter.GetKahenchouStr(text, length)

    End Function

    '↓A-20170601-X1-桁数拡張
    ''' <summary>
    ''' 文字列整形（拡張項目）
    ''' </summary>
    ''' <param name="text">文字列</param>
    ''' <param name="length">桁数</param>
    ''' <returns></returns>
    ''' <remarks>
    ''' 渡された文字列を指定した桁数に編集する
    ''' (渡された文字列桁数 > 指定桁数の場合はそのまま)
    ''' </remarks>
    Private Function StringFormat拡張項目(ByVal text As String, ByVal length As Integer) As String

        If _myコントロール情報.My桁数拡張.拡張項目データリンク桁数拡張 = True Then
            If OSK.X1.Foundation.TextUtility.GetTextLength(text.TrimEnd) > 64 Then
                Dim 拡張項目省略 As String = _stringFormat.GetKahenchouStr(text, 61) & "..."
                Return 拡張項目省略
            End If
        End If

        Return StringFormat(text, length)

    End Function
    '↑A-20170601-X1-桁数拡張

    ''' <summary>
    ''' 引き渡した金額テキスト値が有効値なら伝票合計に加算する
    ''' </summary>
    ''' <param name="kingakuText"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function 伝票合計金額加算(ByVal kingakuText As String) As Boolean
        Dim buff As String = kingakuText.TrimEnd

        '全角文字チェック
        If OSK.X1.Foundation.TextUtility.GetTextLength(buff) <> buff.Length Then    'X1変換Tool-20170508
            Return False
        End If
        'ブランクは0に変換
        If buff.Length = 0 Then
            buff = "0"
        End If

        If IsNumeric(kingakuText) = False Then
            Return False
        End If

        'カンマ(,)をカット
        buff = TextFileImportLib.MyReplace(buff, ",", "")

        If _myコントロール情報.MyMOAオプション.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行わない Then   'A-20121217_Ver7.50_1
            '小数は不可
            If InStr(buff, ".") <> 0 Then
                Return False
            End If

            'If CDec(buff) > 999999999D OrElse CDec(buff) < -999999999D Then                'D-20170601-X1-桁数拡張
            If CDec(buff) > kingaku_MaxValue OrElse CDec(buff) < -(kingaku_MaxValue) Then   'A-20170601-X1-桁数拡張
                Return False
            End If

            _伝票合計金額 += CDec(buff)

            'If _伝票合計金額 > 999999999D OrElse _伝票合計金額 < -999999999D Then              'D-20170601-X1-桁数拡張
            If _伝票合計金額 > kingaku_MaxValue OrElse _伝票合計金額 < -(kingaku_MaxValue) Then 'A-20170601-X1-桁数拡張
                Return False
            End If
            'A-20121217_Ver7.50_1↓
        Else
            'If CDec(buff) > 999999999.9999D OrElse CDec(buff) < -999999999.9999D Then                      'D-20170601-X1-桁数拡張
            If CDec(buff) > kingaku_MaxValue_Gaika OrElse CDec(buff) < -(kingaku_MaxValue_Gaika) Then       'A-20170601-X1-桁数拡張
                Return False
            End If

            _伝票合計金額 += CDec(buff)

            'If _伝票合計金額 > 999999999.9999D OrElse _伝票合計金額 < -999999999.9999D Then                'D-20170601-X1-桁数拡張
            If _伝票合計金額 > kingaku_MaxValue_Gaika OrElse _伝票合計金額 < -(kingaku_MaxValue_Gaika) Then 'A-20170601-X1-桁数拡張
                Return False
            End If
        End If
        'A-20121217_Ver7.50_1↑

        Return True
    End Function
#End Region

#Region "■印刷データ格納■"
    ''' <summary>
    ''' 文字情報の登録
    ''' </summary>
    ''' <param name="itemType">項目分類番号</param>
    ''' <param name="itemNumber">項目番号</param>
    ''' <param name="startCol">開始位置.列</param>
    ''' <param name="startRow">開始位置.行</param>
    ''' <param name="endCol">終了位置.列</param>
    ''' <param name="endRow">終了位置.行</param>
    ''' <param name="buffer">文字列</param>
    ''' <param name="alignment">配置</param>
    ''' <param name="pageParam">ページ情報</param>
    ''' <param name="index">格納位置</param>
    ''' <remarks></remarks>
    Private Overloads Sub SetStringParam(
                               ByVal itemType As _項目分類文字型,
                               ByVal itemNumber As Integer,
                               ByVal startCol As Single,
                               ByVal startRow As Single,
                               ByVal endCol As Single,
                               ByVal endRow As Single,
                               ByVal buffer As String,
                               ByVal alignment As Printing.ICommon.AlignmentType,
                               ByRef pageParam As OSK.X1.Printing.IFormatBase.PageParam,
                               ByRef index As Integer)    'X1変換Tool-20170508

        MyBase.SetStringParam(itemType, itemNumber, startCol, startRow, endCol, endRow, buffer, alignment, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, pageParam, index)

    End Sub

    ''' <summary>
    ''' 罫線情報の登録
    ''' </summary>
    ''' <param name="itemType">項目分類番号</param>
    ''' <param name="itemNumber">項目番号</param>
    ''' <param name="startCol">開始位置.列</param>
    ''' <param name="startRow">開始位置.行</param>
    ''' <param name="endCol">終了位置.列</param>
    ''' <param name="endRow">終了位置.行</param>
    ''' <param name="drawType">罫線の描画方法</param>
    ''' <param name="pageParam">ページ情報</param>
    ''' <param name="index">格納位置</param>
    ''' <remarks></remarks>
    Private Overloads Sub SetLineParam(
                             ByVal itemType As _項目分類罫線型,
                             ByVal itemNumber As Integer,
                             ByVal startCol As Single,
                             ByVal startRow As Single,
                             ByVal endCol As Single,
                             ByVal endRow As Single,
                             ByVal drawType As Printing.ICommon.DrawType,
                             ByRef pageParam As OSK.X1.Printing.IFormatBase.PageParam,
                             ByRef index As Integer)    'X1変換Tool-20170508

        MyBase.SetLineParam(itemType, itemNumber, startCol, startRow, endCol, endRow, drawType, ICommon.DirectionType.なし, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, pageParam, index)

    End Sub

    ''' <summary>
    ''' 網掛情報の登録
    ''' </summary>
    ''' <param name="itemType">項目分類番号</param>
    ''' <param name="itemNumber">項目番号</param>
    ''' <param name="startCol">開始位置.列</param>
    ''' <param name="startRow">開始位置.行</param>
    ''' <param name="endCol">終了位置.列</param>
    ''' <param name="endRow">終了位置.行</param>
    ''' <param name="pageParam">ページ情報</param>
    ''' <param name="index">格納位置</param>
    ''' <remarks></remarks>
    Private Overloads Sub SetMeshParam(
                             ByVal itemType As _項目分類網掛型,
                             ByVal itemNumber As Integer,
                             ByVal startCol As Single,
                             ByVal startRow As Single,
                             ByVal endCol As Single,
                             ByVal endRow As Single,
                             ByRef pageParam As OSK.X1.Printing.IFormatBase.PageParam,
                             ByRef index As Integer)    'X1変換Tool-20170508

        MyBase.SetMeshParam(itemType, itemNumber, startCol, startRow, endCol, endRow, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, Nothing, pageParam, index)

    End Sub
#End Region

#End Region

End Class
