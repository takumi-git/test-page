﻿'A-CUST20190830↓
Public Class TextExp
    Private sw As IO.StreamWriter
    Private sr As IO.StreamReader


#Region "コンストラクタ"

    Public Sub New()

    End Sub

#End Region

#Region "ファイル存在チェック"
    Public Function FileExistsCheck(ByVal pass As String) As Boolean

        If IO.File.Exists(pass) Then
            Return True
        Else
            Return False
        End If

    End Function
#End Region

#Region "ファイルコピー"

    Public Sub CopyFile(ByVal Frompass As String, ByVal Topass As String)

        IO.File.Copy(Frompass, Topass)
    End Sub
#End Region

#Region "ファイルデリート"

    Public Sub DeleteFile(ByVal pass As String)

        IO.File.Delete(pass)
    End Sub
#End Region


#Region "フォルダ存在チェック"
    Public Function FoldaExistsCheck(ByVal pass As String) As Boolean

        If IO.Directory.Exists(pass) Then
            Return True
        Else
            Return False
        End If

    End Function
#End Region

#Region "フォルダ作成"

    Public Sub CreateFolda(ByVal pass As String)

        IO.Directory.CreateDirectory(pass)
    End Sub
#End Region

#Region "フォルダ削除"

    Public Sub DeleteFolda(ByVal pass As String)

        IO.Directory.Delete(pass)
    End Sub
#End Region


#Region "出力テキストＯＰＥＮ"

    Public Sub OutputText_Open()

        sw = New IO.StreamWriter(OutputFileName, True, System.Text.Encoding.GetEncoding(文字コード))

    End Sub
#End Region

#Region "取込テキストＯＰＥＮ"

    Public Sub InputText_Open()

        sr = New IO.StreamReader(InputFileName, System.Text.Encoding.GetEncoding("shift_jis"))

    End Sub
#End Region

#Region "出力テキストＣＬＯＳＥ"

    Public Sub OutputText_Close()

        sw.Close()

    End Sub
#End Region

#Region "取込テキストＣＬＯＳＥ"

    Public Sub InputText_Close()

        sr.Close()

    End Sub
#End Region

#Region "テキストＷｉｒｔｅ"

    Public Sub Text_WriteLine(ByVal str As String)

        sw.WriteLine(str)

    End Sub

#End Region

#Region "テキストＲｅａｄ"

    Public Function Text_ReadLine() As String

        Return sr.ReadLine()

    End Function

    Public Function Text_SetList() As List(Of String)
        '読み込んだテキストの内容をリストに溜め込む

        Dim textData As String = ""
        Dim Getdata As List(Of String) = New List(Of String)
        Dim Titleflg As Boolean = False
        Do
            textData = Text_ReadLine()
            '1件目がタイトルの場合、読み直し
            If Titleflg = True Then
                Titleflg = False
                Continue Do
            End If

            If sr.EndOfStream = True Then
                If Not textData Is Nothing AndAlso
                   textData.Trim.Length > 0 Then
                    Getdata.Add(textData)
                End If
                Exit Do
            End If

            If Not textData Is Nothing AndAlso
               textData.Trim.Length > 0 Then
                Getdata.Add(textData)
            End If
        Loop

        Return Getdata
    End Function

#End Region


#Region "プロパティ"
    '取込ファイル名を設定
    Private _InputFileName As String
    Public Property InputFileName() As String
        Get
            Return _InputFileName
        End Get
        Set(ByVal value As String)
            _InputFileName = value
        End Set
    End Property

    '出力ファイル名を設定
    Private _OutputFileName As String
    Public Property OutputFileName() As String
        Get
            Return _OutputFileName
        End Get
        Set(ByVal value As String)
            _OutputFileName = value
        End Set
    End Property

    '文字コードを設定
    Private _文字コード As String
    Public Property 文字コード() As String
        Get
            Return _文字コード
        End Get
        Set(ByVal value As String)
            _文字コード = value
        End Set
    End Property
#End Region
End Class

'A-CUST20190830↑