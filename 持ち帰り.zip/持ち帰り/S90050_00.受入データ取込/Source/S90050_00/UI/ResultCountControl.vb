﻿Public Class ResultCountControl

End Class
