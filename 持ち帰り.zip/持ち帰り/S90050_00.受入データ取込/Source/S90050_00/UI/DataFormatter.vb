﻿'A-CUST20190830↓
Public Class DataFormatter
    Private _InColumnName(仕入データ型._項目数 - 1) As String
    Private _InColumnType(仕入データ型._項目数 - 1) As String
    Private _OutColumnName(仕入データ型._項目数 - 1) As String
    Private _OutColumnType(仕入データ型._項目数 - 1) As String

    Private _BreakKey As String
    Private _走行キロ As Decimal
    Private No50_発地名 As String = ""
    Private No52_着地名 As String = ""
    Private No55_出発年月日 As String = ""
    Private No56_出発年月日_時 As String = ""
    Private No57_出発年月日_分 As String = ""
    Private No58_終了年月日 As String = ""
    Private No59_終了年月日_時 As String = ""
    Private No60_終了年月日_分 As String = ""
    Private No63_出発メーター As String = ""
    Private No64_終了メーター As String = ""
    Private _レコード区分 As String = ""
    Private _日常点検 As String = ""
    Private _作業名称 As String = ""

    Function DataFomat() As DataTable
        'プログラム毎にやりたいように編集作業

        '取込ファイル用のDataTableを作成
        Dim CreateDt As New DataTable
        Dim FormatDt As New DataTable
        Dim DataFormatter As New DataFormatter
        CreateDt = DataFormatter.InEdit_DataTable(_InColumnName)

        '保持した内容をDataTableへ書き込み
        DataFormatter.TextWrite(CreateDt, GetData1, True, _InColumnName)
        Dim NewDt As New DataTable
        Dim NewRow As DataRow

        CreateOutColumnList()

        NewDt = OutEdit_DataTable()
        NewRow = NewDt.NewRow

        '明細行の挿入
        _BreakKey = ""
        Dim AddFlg As Boolean = True

        For I As Integer = 0 To CreateDt.Rows.Count - 1
            NewRow = NewDt.NewRow
            NewRow = ConvertData(CreateDt, NewDt, I)
            NewDt.Rows.Add(NewRow)
        Next

        Return NewDt

    End Function

    Function InEdit_DataTable(ByVal InColumnName() As String) As DataTable

        'データテーブルの作成
        Dim DataTable As New DataTable
        Dim col As DataColumn

        Dim dimension As Integer
        Dim returnValue As Integer

        returnValue = InColumnName.GetUpperBound(dimension)

        For i As Integer = 0 To returnValue
            col = New DataColumn
            DataTable.Columns.Add(col)
        Next
        Return DataTable

    End Function

    Function OutEdit_DataTable() As DataTable

        'データテーブルの作成
        Dim DataTable As New DataTable
        Dim col As DataColumn

        Dim dimension As Integer
        Dim returnValue As Integer

        returnValue = _OutColumnName.GetUpperBound(dimension)

        For i As Integer = 0 To returnValue
            col = New DataColumn
            col.ColumnName = _OutColumnName(i)
            DataTable.Columns.Add(col)
        Next
        Return DataTable

    End Function

    Function TextWrite(ByRef fileDt As DataTable, ByVal buff As List(Of String), ByVal 行No追加 As Boolean, ByVal InColumnName() As String) As Boolean
        '保持しておいた内容をDatatableへ移項する

        Dim delimiter As Char = CChar(vbTab)
        Dim textItems() As String
        Dim Dt行No As Integer = 0

        For row As Integer = 0 To buff.Count - 1

            textItems = SplitTextData(buff(row), vbTab)

            Dim NewRow As DataRow = fileDt.NewRow
            Dim dimension As Integer
            Dim returnValue As Integer
            Dim ColCount As Integer = 0
            If textItems.GetUpperBound(dimension) <= InColumnName.GetUpperBound(dimension) - 1 Then
                returnValue = textItems.GetUpperBound(dimension)
            Else
                returnValue = InColumnName.GetUpperBound(dimension) - 1
            End If
            returnValue = textItems.GetUpperBound(dimension)
            Dt行No += 1
            For col As Integer = 0 To returnValue
                NewRow.Item(col) = textItems(col)
            Next
            fileDt.Rows.Add(NewRow)
        Next

    End Function

    Function SplitTextData(ByVal textData As String, ByVal Kugiri As String) As String()

        Dim textItems() As String
        textItems = Split(textData, Kugiri)

        Dim item As String
        For i As Integer = 0 To textItems.Length - 1

            item = textItems(i).TrimEnd

            '文字の前後に二重引用符(")がある場合は不要
            If item.Length >= 2 AndAlso item.StartsWith("""") AndAlso item.EndsWith("""") Then
                item = item.Substring(1, item.Length - 2)
            End If

            '文字が変換されている場合があるので元に戻す
            '・二重引用符(")は、二重引用符ふたつ("")に変換されて格納されているので、二重引用符ひとつ(")に戻す
            item = item.Replace("""""", """")

            textItems(i) = item

        Next i

        Return textItems
    End Function

    'DataTableの内容をソートする
    Function SortTable(ByVal TargetDt As DataTable, ByVal ParamArray TargetCode() As String) As DataTable

        Dim dvSort As DataView = New DataView(TargetDt)
        Dim SortCode As String = ""

        Dim dimension As Integer
        Dim returnValue As Integer

        returnValue = TargetCode.GetUpperBound(dimension)

        For i As Integer = 0 To returnValue
            SortCode &= TargetCode(i)
            If i <> returnValue Then
                SortCode &= ", "
            End If
        Next

        dvSort.Sort = SortCode

        '指定した項目でSortしたDataTableを返す
        Return dvSort.ToTable()

    End Function

    Sub CreateOutColumnList()

    End Sub

    '対象のDataTableから値を取得し、出力用のDataTableを作成
    Public Function ConvertData(ByVal FromDt As DataTable, ByRef ToDt As DataTable, ByVal Row As Integer) As DataRow

        Dim ColNo As Integer = 0
        Dim DataChecker As New DataChecker

        Dim NewRow As DataRow = ToDt.NewRow

        'ファイル区分
        NewRow.Item(ColNo) = _Renban : ColNo += 1

        Return NewRow

    End Function

    Private Sub Setdaytime(ByVal 年月日時刻 As Date, ByRef 年月日 As String, ByRef 時間 As String, ByRef 分 As String)

        年月日 = "0"
        時間 = "0"
        分 = "0"

        年月日 = Format(年月日時刻, "yyyyMMdd")
        時間 = Format(年月日時刻, "HH")
        分 = Format(年月日時刻, "mm")

    End Sub

    Private Sub Setdaytimess(ByVal 年月日時刻 As Date, ByRef 年月日 As String, ByRef 時間 As String, ByRef 分 As String, ByRef 秒 As String)
        年月日 = "0"
        時間 = "0"
        分 = "0"
        秒 = "0"

        年月日 = Format(年月日時刻, "yyyyMMdd")
        時間 = Format(年月日時刻, "HH")
        分 = Format(年月日時刻, "mm")
        秒 = Format(年月日時刻, "ss")

    End Sub

    Public Function ToHalfAdjust四捨五入(ByVal dValue As Decimal, ByVal iDigits As Integer) As Decimal
        '端数処理(DECIMAL、四捨五入専用)

        Return Decimal.Round(dValue, iDigits, System.MidpointRounding.AwayFromZero)

    End Function

    Public Function 金額端数四捨五入(ByVal dValue As Decimal, ByVal iDigits As Integer) As Decimal
        '金額端数処理(DECIMAL、四捨五入専用)

        Dim W_Value As Decimal

        W_Value = CDec(dValue / iDigits)
        W_Value = Decimal.Round(W_Value, 0, System.MidpointRounding.AwayFromZero) * iDigits
        Return W_Value
    End Function

    Public Function 金額端数切上(ByVal dValue As Decimal, ByVal iDigits As Integer) As Decimal
        '金額端数処理(DECIMAL、切上専用)

        If dValue > 0 Then
            Return CDec(System.Math.Ceiling((dValue / iDigits)) * iDigits)
        Else
            Return CDec(System.Math.Floor((dValue / iDigits)) * iDigits)
        End If

    End Function

    Public Function 金額端数切捨(ByVal dValue As Decimal, ByVal iDigits As Integer) As Decimal
        '金額端数処理(DECIMAL、切捨専用)

        If dValue > 0 Then
            Return CDec(System.Math.Floor((dValue / iDigits)) * iDigits)
        Else
            Return CDec(System.Math.Ceiling((dValue / iDigits)) * iDigits)
        End If

    End Function

    Public Function CutValue(ByVal Value As String, ByVal Kigou As String, ByVal Mode As String) As String
        '指定した文字まで(LEFT)、または文字から(RIGHT)の文字列を取得
        Dim STR As String = ""
        Dim WSTR As String = ""
        For i As Integer = 1 To Value.Length
            WSTR = Mid(Value, i, 1)
            Select Case Mode
                Case "LEFT"
                    If WSTR = Kigou Then
                        Exit For
                    End If
                    STR &= WSTR
                Case "RIGHT"
                    If WSTR = Kigou Then
                        For m As Integer = i + 1 To Value.Length
                            WSTR = Mid(Value, m, 1)
                            STR &= WSTR
                        Next
                        Exit For
                    End If
            End Select
        Next

        Return STR
    End Function

    '文字列長を抽出
    Public Function ValueLength(ByVal Value As String) As Integer

        Return OSK.X1.Foundation.TextUtility.GetTextLength(Value)

    End Function

    '出力用のDataTableから値を取り出し、テキスト出力用の文字列を作成
    Public Function ConvertTextData(ByVal TargetDt As DataTable, ByVal kugiri As String, ByVal row As Integer) As String

        Dim Str As String = ""
        Dim DataChecker As New DataChecker

        For i As Integer = 0 To TargetDt.Columns.Count - 1

            If _OutColumnType(i) = "System.String" OrElse row = 0 OrElse CStr(TargetDt.Rows(row).Item(i)) = "項目値不正" Then
                'string項目、または1行目（タイトル行）の場合は文字出力
                Str &= """" & CStr(TargetDt.Rows(row).Item(i)) & """"
            Else
                If DataChecker.数値_Check(CStr(TargetDt.Rows(row).Item(i)).TrimEnd, 9, 0) = True AndAlso
                   CStr(TargetDt.Rows(row).Item(i)).TrimEnd <> "" Then
                    Str &= CDec(TargetDt.Rows(row).Item(i))
                Else
                    Str &= CStr(TargetDt.Rows(row).Item(i))
                End If
            End If
            If i <> TargetDt.Columns.Count - 1 Then
                Str &= kugiri
            End If
        Next

        Return Str

    End Function

    Public Function ConvertTextData2(ByVal TargetDt As String(), ByVal kugiri As String, ByVal row As Integer) As String

        Dim Str As String = ""
        Dim DataChecker As New DataChecker

        For i As Integer = 0 To TargetDt.Length - 1
            Str &= CStr(TargetDt(i))
            If i <> TargetDt.Length - 1 Then
                Str &= kugiri
            End If
        Next

        Return Str

    End Function

    Public Function ConvertTextData3(ByVal TargetDt As String(), ByVal kugiri As String, ByVal row As Integer) As String

        Dim Str As String = ""
        Dim DataChecker As New DataChecker

        For i As Integer = 1 To TargetDt.Length - 1
            Str &= CStr(TargetDt(i))
            If i <> TargetDt.Length - 1 Then
                Str &= kugiri
            End If
        Next

        Return Str

    End Function

    Function GetDataTableItem(ByVal DataTable As DataTable, ByVal SelectString As String,
                                                            ByVal Col As String,
                                                            Optional ByVal 規定値 As String = "") As String

        'DATATABLEから項目値を取得する（項目名の値がユニークな場合に使用可能）
        Dim DataRow() As DataRow
        DataRow = DataTable.Select(SelectString)

        If DataRow.Length = 0 Then
            Return 規定値
        End If
        Return DataRow(0).Item(Col).ToString

    End Function

    Function GetDataTableRow(ByVal DataTable As DataTable, ByVal SelectString As String, Optional ByVal OrderItem As String = "") As DataRow()

        'DATATABLEから項目値を取得する（項目名の値がユニークな場合に使用可能）
        Dim DataRow() As DataRow
        DataRow = DataTable.Select(SelectString, OrderItem)

        Return DataRow

    End Function

#Region "プロパティ"

    Private _GetData1 As List(Of String)
    Public Property GetData1() As List(Of String)
        Get
            Return _GetData1
        End Get
        Set(ByVal value As List(Of String))
            _GetData1 = value
        End Set
    End Property

    Private _GetData2 As List(Of String)
    Public Property GetData2() As List(Of String)
        Get
            Return _GetData2
        End Get
        Set(ByVal value As List(Of String))
            _GetData2 = value
        End Set
    End Property

    Private _GetData3 As List(Of String)
    Public Property GetData3() As List(Of String)
        Get
            Return _GetData3
        End Get
        Set(ByVal value As List(Of String))
            _GetData3 = value
        End Set
    End Property


    Private _myコントロール情報 As Myコントロール情報型
    Public Property myコントロール情報() As Myコントロール情報型
        Get
            Return _myコントロール情報
        End Get
        Set(ByVal value As Myコントロール情報型)
            _myコントロール情報 = value
        End Set
    End Property

    Private _日報日付 As String
    Public Property 日報日付() As String
        Get
            Return _日報日付
        End Get
        Set(ByVal value As String)
            _日報日付 = value
        End Set
    End Property
    Private _運転者コード As String
    Public Property 運転者コード() As String
        Get
            Return _運転者コード
        End Get
        Set(ByVal value As String)
            _運転者コード = value
        End Set
    End Property
    Private _車両コード As String
    Public Property 車両コード() As String
        Get
            Return _車両コード
        End Get
        Set(ByVal value As String)
            _車両コード = value
        End Set
    End Property

    Private _日報番号 As Integer
    Public Property 日報番号() As Integer
        Get
            Return _日報番号
        End Get
        Set(ByVal value As Integer)
            _日報番号 = value
        End Set
    End Property

    Private _得意先コード As String
    Public Property 得意先コード() As String
        Get
            Return _得意先コード
        End Get
        Set(ByVal value As String)
            _得意先コード = value
        End Set
    End Property

    Private _取込ファイル名 As String
    Public Property 取込ファイル名() As String
        Get
            Return _取込ファイル名
        End Get
        Set(ByVal value As String)
            _取込ファイル名 = value
        End Set
    End Property

    Private _Settinginfo As IDictionary
    Public Property Settinginfo() As IDictionary
        Get
            Return _Settinginfo
        End Get
        Set(ByVal value As IDictionary)
            _Settinginfo = value
        End Set
    End Property

    Private _Renban As Long
    Public Property Renban() As Long
        Get
            Return _Renban
        End Get
        Set(ByVal value As Long)
            _Renban = value
        End Set
    End Property

#End Region
End Class
'A-CUST20190830↑
