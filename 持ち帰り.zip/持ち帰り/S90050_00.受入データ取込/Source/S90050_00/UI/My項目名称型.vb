﻿''' <summary>
''' My項目名称型
''' </summary>
''' <remarks></remarks>
Public Class My項目名称型
    Inherits OSK.X1.CMN.LIB.ItemNameInfo.項目名称型Base    'X1変換Tool-20170508

#Region "販売購買"

#Region "営業所"

    Public ReadOnly Property 販売営業所() As String
        Get
            Return GetItemName("販売営業所").TrimEnd
        End Get
    End Property

#End Region

    '#Region "得意先"

    '    Public ReadOnly Property 販売得意先() As String
    '        Get
    '            Return GetItemName("販売得意先").TrimEnd
    '        End Get
    '    End Property

    '#End Region

#Region "得意先"    'A-2008/07/18_Ver7.30_GENKA

    Public ReadOnly Property 販売得意先() As String     'A-2008/07/18_Ver7.30_GENKA
        Get
            Return GetItemName("販売得意先").TrimEnd
        End Get
    End Property

#End Region

#Region "仕入先"

    Public ReadOnly Property 販売仕入先() As String
        Get
            Return GetItemName("販売仕入先").TrimEnd
        End Get
    End Property

#End Region

    '#Region "担当者(項目)"

    '    Public ReadOnly Property 販売担当者_項目() As String
    '        Get
    '            Return GetItemName("販売担当者_項目").TrimEnd
    '        End Get
    '    End Property

    '#End Region

#Region "仕入担当者(項目)"

    Public ReadOnly Property 販売仕入担当者_項目() As String
        Get
            Return GetItemName("販売仕入担当者_項目").TrimEnd
        End Get
    End Property

#End Region

#Region "部門"

    Public ReadOnly Property 販売部門() As String
        Get
            Return GetItemName("販売部門").TrimEnd
        End Get
    End Property

#End Region

    '#Region "納品先"

    '    Public ReadOnly Property 販売納品先() As String
    '        Get
    '            Return GetItemName("販売納品先").TrimEnd
    '        End Get
    '    End Property

    '#End Region

#Region "倉庫"

    Public ReadOnly Property 販売倉庫() As String
        Get
            Return GetItemName("販売倉庫").TrimEnd
        End Get
    End Property

#End Region

#Region "商品"

    Public ReadOnly Property 販売商品() As String
        Get
            Return GetItemName("販売商品").TrimEnd
        End Get
    End Property

#End Region

#Region "原価集計"      'A-2008/07/18_Ver7.30_GENKA

    Public ReadOnly Property 販売原価集計() As String       'A-2008/07/18_Ver7.30_GENKA
        Get
            Return GetItemName("販売原価集計").TrimEnd
        End Get
    End Property

    Public ReadOnly Property 販売原価集計メイン() As String 'A-2008/07/18_Ver7.30_GENKA
        Get
            Return GetItemName("販売原価集計メイン").TrimEnd
        End Get
    End Property

    Public ReadOnly Property 販売原価集計サブ() As String   'A-2008/07/18_Ver7.30_GENKA
        Get
            Return GetItemName("販売原価集計サブ").TrimEnd
        End Get
    End Property

#End Region

#Region "商品内訳管理"  'A-2009/12/18_Ver7.40_UCHIWAKE

    Public ReadOnly Property 販売換算数量() As String       'A-2009/12/18_Ver7.40_UCHIWAKE
        Get
            Return GetItemName("販売換算数量").TrimEnd
        End Get
    End Property

    Public ReadOnly Property 販売単位換算数量() As String   'A-2009/12/18_Ver7.40_UCHIWAKE
        Get
            Return GetItemName("販売単位換算数量").TrimEnd
        End Get
    End Property

#End Region

#Region "ロット"    'A-2009/12/18_Ver7.40_LOT

    Public ReadOnly Property 販売ロット() As String     'A-2009/12/18_Ver7.40_LOT
        Get
            Return GetItemName("販売ロット").TrimEnd
        End Get
    End Property

    Public ReadOnly Property 販売ロットNo() As String   'A-2009/12/18_Ver7.40_LOT
        Get
            Return GetItemName("販売ロット№").TrimEnd
        End Get
    End Property

    Public ReadOnly Property 販売サブロットNo() As String   'A-2009/12/18_Ver7.40_LOT
        Get
            Return GetItemName("販売サブロット№").TrimEnd
        End Get
    End Property

#End Region

    Public ReadOnly Property 販売品目名１() As String
        Get
            Return GetItemName("販売商品１").TrimEnd
        End Get
    End Property

    Public ReadOnly Property 販売品目名２() As String
        Get
            Return GetItemName("販売商品２").TrimEnd
        End Get
    End Property

    Public ReadOnly Property 販売品目名３() As String
        Get
            Return GetItemName("販売商品３").TrimEnd
        End Get
    End Property

    Public ReadOnly Property 販売客先注番() As String
        Get
            Return GetItemName("販売客先注番").TrimEnd
        End Get
    End Property

    Public ReadOnly Property 販売有効期限() As String
        Get
            Return GetItemName("販売有効期限").TrimEnd
        End Get
    End Property

#End Region

#Region "会計"  'A-2009/12/18_Ver7.40_PRO

    Public ReadOnly Property 会計完成() As String   'A-2009/12/18_Ver7.40_PRO
        Get
            Return GetItemName("会計完成").TrimEnd
        End Get
    End Property

#End Region

End Class
