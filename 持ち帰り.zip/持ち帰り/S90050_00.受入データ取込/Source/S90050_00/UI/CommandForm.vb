﻿''' <summary>
''' </summary>
''' <remarks></remarks>
Public Class CommandForm

    Private _systemDate As Integer

    Private _myコントロール情報 As New Myコントロール情報型
    Private _my項目名称 As New My項目名称型
    Private _拡張項目情報_仕入伝票 As SEI.LIB.ExpandItemControl.I拡張項目定義型
    Private _拡張項目情報_仕入明細 As SEI.LIB.ExpandItemControl.I拡張項目定義型
    Private _拡張項目情報_入荷伝票 As SEI.LIB.ExpandItemControl.I拡張項目定義型
    Private _拡張項目情報_入荷明細 As SEI.LIB.ExpandItemControl.I拡張項目定義型

    'A-CUST20190830↓
    Private _拡張項目情報_入出庫伝票 As SEI.LIB.ExpandItemControl.I拡張項目定義型
    Private _拡張項目情報_入出庫明細 As SEI.LIB.ExpandItemControl.I拡張項目定義型

    Private _販売日付情報 As IDateInfoGetter
    Private _textConvert As TextConvert
    Private _変換テキスト名 As String
    'A-CUST20190830↑

#Region "■画面起動関連■"

#Region "Setup関連"
    <Conditional("Debug")>
    Protected Overrides Sub SetupImpl()
        If Me.システム環境情報.システム構成情報.動作モード = Foundation.動作モード型.通常 Then
            Return
        End If
        Me.InitInfo.Add(TextFileImportLib.プログラム専用_テキストデータ転送単位, 10)
    End Sub
#End Region

#Region "Start関連"

    Protected Overrides Sub StartImpl()
        Dim BISControlInfoGetter As BIS.LIB.ControlInfo.UserInterface.IBISControlInfoGetter = New BIS.LIB.ControlInfo.UserInterface.BISControlInfoGetter
        Dim controlInfoGetter As ISEIControlInfoGetter = New SEIControlInfoGetter

        Dim biscontrolInfoC001 As IDictionary = BISControlInfoGetter.GetControlInfo(Me.InitInfo, IBISControlInfoGetter.コントロール型.BISコントロールテーブル)
        Dim controlInfoC001 As IDictionary = controlInfoGetter.GetControlInfo(Me.InitInfo, ISEIControlInfoGetter.コントロール型.SEIコントロールテーブル)
        Dim controlInfoC002 As IDictionary = controlInfoGetter.GetControlInfo(Me.InitInfo, ISEIControlInfoGetter.コントロール型.SEI分類種別管理テーブル)    'A-2008/07/18_Ver7.30_GENKA

        _myコントロール情報.InitializeC001(controlInfoC001)
        _myコントロール情報.InitializeC002(controlInfoC002)     'A-2008/07/18_Ver7.30_GENKA
        _myコントロール情報.InitializeBISC001(biscontrolInfoC001)
        '↓A-2008/07/18_Ver7.30_SAIMU
        If _myコントロール情報.販売財務連動区分 = 販売財務連動定義型.販売財務連動区分型.行う Then
            Dim controlInfoZAIC001 As IDictionary = New Hashtable
            Dim controlGetter_Zai As IControlGetter_Zai
            'controlGetter_Zai = OSK.X1.Foundation.GeneralFactory(Of IControlGetter_Zai).CreateInstance(Me, "OSK.X1.HAN.S90050_00.SUB1.UI", "ControlGetter_Zai")    'X1変換Tool-20170508
            controlGetter_Zai = OSK.X1.Foundation.GeneralFactory(Of IControlGetter_Zai).CreateInstance(Me, "OSK.X1.SEI.S90050_00.SUB1.UI", "ControlGetter_Zai")    'X1変換Tool-20170508
            controlGetter_Zai.Initialize(Me)
            controlGetter_Zai.Startup(InitInfo, controlInfoZAIC001)
            controlGetter_Zai.ControlGet(controlInfoZAIC001, _myコントロール情報)
        End If
        '↑A-2008/07/18_Ver7.30_SAIMU
        If _myコントロール情報.仕入検収基準 = MOA機能追加定義型.その他管理区分型.行う Then
            _myコントロール情報.拡張項目_仕入伝票 = MyBase.GetInitInfo(ProgramLib.プログラム専用_入荷伝票拡張項目有無, False)
            _myコントロール情報.拡張項目_仕入明細 = MyBase.GetInitInfo(ProgramLib.プログラム専用_入荷明細拡張項目有無, False)
        Else
            _myコントロール情報.拡張項目_仕入伝票 = MyBase.GetInitInfo(ProgramLib.プログラム専用_仕入伝票拡張項目有無, False)
            _myコントロール情報.拡張項目_仕入明細 = MyBase.GetInitInfo(ProgramLib.プログラム専用_仕入明細拡張項目有無, False)
        End If
        _my項目名称.Initialize(InitInfo)

        '拡張項目情報.仕入伝票
        If MyBase.GetInitInfo(ProgramLib.プログラム専用_仕入伝票拡張項目有無, False) = True Then
            _拡張項目情報_仕入伝票 = CMN.LIB.PartReplacement.CommonFactory.CreateInstance(Of SEI.LIB.ExpandItemControl.I拡張項目定義型)(Me, GetType(SEI.LIB.ExpandItemControl.拡張項目定義型))
            Dim expandItemGetter As SEI.LIB.ExpandItemControl.UserInterface.ISEIExpandItemInfoGetter
            expandItemGetter = CMN.LIB.PartReplacement.CommonFactory.CreateInstance(Of SEI.LIB.ExpandItemControl.UserInterface.ISEIExpandItemInfoGetter)(Me, GetType(SEI.LIB.ExpandItemControl.UserInterface.SEIExpandItemInfoGetter))
            Call expandItemGetter.GetExpandItemInfo(InitInfo, [LIB].ExpandItemControl.I拡張項目定義型.SEI拡張項目型.仕入伝票, _拡張項目情報_仕入伝票)
        End If

        If MyBase.GetInitInfo(ProgramLib.プログラム専用_入荷伝票拡張項目有無, False) = True Then
            _拡張項目情報_入荷伝票 = CMN.LIB.PartReplacement.CommonFactory.CreateInstance(Of SEI.LIB.ExpandItemControl.I拡張項目定義型)(Me, GetType(SEI.LIB.ExpandItemControl.拡張項目定義型))
            Dim expandItemGetter As SEI.LIB.ExpandItemControl.UserInterface.ISEIExpandItemInfoGetter
            expandItemGetter = CMN.LIB.PartReplacement.CommonFactory.CreateInstance(Of SEI.LIB.ExpandItemControl.UserInterface.ISEIExpandItemInfoGetter)(Me, GetType(SEI.LIB.ExpandItemControl.UserInterface.SEIExpandItemInfoGetter))
            Call expandItemGetter.GetExpandItemInfo(InitInfo, [LIB].ExpandItemControl.I拡張項目定義型.SEI拡張項目型.入荷伝票, _拡張項目情報_入荷伝票)
        End If

        '拡張項目情報.仕入明細
        If MyBase.GetInitInfo(ProgramLib.プログラム専用_仕入明細拡張項目有無, False) = True Then
            _拡張項目情報_仕入明細 = CMN.LIB.PartReplacement.CommonFactory.CreateInstance(Of SEI.LIB.ExpandItemControl.I拡張項目定義型)(Me, GetType(SEI.LIB.ExpandItemControl.拡張項目定義型))
            Dim expandItemGetter As SEI.LIB.ExpandItemControl.UserInterface.ISEIExpandItemInfoGetter
            expandItemGetter = CMN.LIB.PartReplacement.CommonFactory.CreateInstance(Of SEI.LIB.ExpandItemControl.UserInterface.ISEIExpandItemInfoGetter)(Me, GetType(SEI.LIB.ExpandItemControl.UserInterface.SEIExpandItemInfoGetter))
            Call expandItemGetter.GetExpandItemInfo(InitInfo, [LIB].ExpandItemControl.I拡張項目定義型.SEI拡張項目型.仕入明細, _拡張項目情報_仕入明細)
        End If

        If MyBase.GetInitInfo(ProgramLib.プログラム専用_入荷明細拡張項目有無, False) = True Then
            _拡張項目情報_入荷明細 = CMN.LIB.PartReplacement.CommonFactory.CreateInstance(Of SEI.LIB.ExpandItemControl.I拡張項目定義型)(Me, GetType(SEI.LIB.ExpandItemControl.拡張項目定義型))
            Dim expandItemGetter As SEI.LIB.ExpandItemControl.UserInterface.ISEIExpandItemInfoGetter
            expandItemGetter = CMN.LIB.PartReplacement.CommonFactory.CreateInstance(Of SEI.LIB.ExpandItemControl.UserInterface.ISEIExpandItemInfoGetter)(Me, GetType(SEI.LIB.ExpandItemControl.UserInterface.SEIExpandItemInfoGetter))
            Call expandItemGetter.GetExpandItemInfo(InitInfo, [LIB].ExpandItemControl.I拡張項目定義型.SEI拡張項目型.入荷明細, _拡張項目情報_入荷明細)
        End If

        'A-CUST20190830↓
        _myコントロール情報.拡張項目_入出庫伝票 = MyBase.GetInitInfo(ProgramLib.プログラム専用_入出庫伝票拡張項目有無, False)
        _myコントロール情報.拡張項目_入出庫明細 = MyBase.GetInitInfo(ProgramLib.プログラム専用_入出庫明細拡張項目有無, False)
        '拡張項目情報.入出庫伝票
        If _myコントロール情報.拡張項目_入出庫伝票 = True Then
            _拡張項目情報_入出庫伝票 = CMN.LIB.PartReplacement.CommonFactory.CreateInstance(Of SEI.LIB.ExpandItemControl.I拡張項目定義型)(Me, GetType(SEI.LIB.ExpandItemControl.拡張項目定義型))
            Dim expandItemGetter As SEI.LIB.ExpandItemControl.UserInterface.ISEIExpandItemInfoGetter
            expandItemGetter = CMN.LIB.PartReplacement.CommonFactory.CreateInstance(Of SEI.LIB.ExpandItemControl.UserInterface.ISEIExpandItemInfoGetter)(Me, GetType(SEI.LIB.ExpandItemControl.UserInterface.SEIExpandItemInfoGetter))
            Call expandItemGetter.GetExpandItemInfo(InitInfo, SEI.[LIB].ExpandItemControl.I拡張項目定義型.SEI拡張項目型.入出庫伝票, _拡張項目情報_入出庫伝票)
        End If

        '拡張項目情報.入出庫明細
        If _myコントロール情報.拡張項目_入出庫明細 = True Then
            _拡張項目情報_入出庫明細 = CMN.LIB.PartReplacement.CommonFactory.CreateInstance(Of SEI.LIB.ExpandItemControl.I拡張項目定義型)(Me, GetType(SEI.LIB.ExpandItemControl.拡張項目定義型))
            Dim expandItemGetter As SEI.LIB.ExpandItemControl.UserInterface.ISEIExpandItemInfoGetter
            expandItemGetter = CMN.LIB.PartReplacement.CommonFactory.CreateInstance(Of SEI.LIB.ExpandItemControl.UserInterface.ISEIExpandItemInfoGetter)(Me, GetType(SEI.LIB.ExpandItemControl.UserInterface.SEIExpandItemInfoGetter))
            Call expandItemGetter.GetExpandItemInfo(InitInfo, SEI.[LIB].ExpandItemControl.I拡張項目定義型.SEI拡張項目型.入出庫明細, _拡張項目情報_入出庫明細)
        End If

        _販売日付情報 = CMN.LIB.PartReplacement.CommonFactory.CreateInstance(Of IDateInfoGetter)(Me, GetType(DateInfoGetter))
        _販売日付情報.SetData(InitInfo)

        _textConvert = New TextConvert
        'A-CUST20190830↑

    End Sub

#End Region

#Region "LoadImpl関連"

    Public Overrides Sub LoadImpl(ByVal sender As Object, ByVal e As System.EventArgs)
        MyBase.LoadImpl(sender, e)

        '操作日付
        _systemDate = CInt(Format$(Now, "yyyyMMdd"))

        Me.menuBar.Items("_help").Visible = False     'A-CUST20190830
        Me.menuBar.Items("setupMenu").Visible = False 'A-CUST20190830

    End Sub
    Protected Overrides Sub InitializeControlsImpl()

        Dim diff As Integer
        Dim FormHeight As Integer = Me.Height

        Dim diffCUST As Integer = 0 'A-CUST20190830

        '↓A-2009/12/18_Ver7.40_LOT
        Dim controlHeightGap As Integer = 6
        Dim diffLotSaiban As Integer = 0

        If Is画面条件有効判定_ロットNo採番() = True Then
            '「ロット№の採番方法」の項目名称変換
            lotNoSaiban.Title = lotNoSaiban.Title.Replace("ロット№", _my項目名称.販売ロットNo)
            lotNoSaiban.Items(0).Text = lotNoSaiban.Items(0).Text.Replace("ロット№", _my項目名称.販売ロットNo)
        Else
            '「ロット№の採番方法」を非表示とし、詰める分の高さを設定する
            lotNoSaiban.Visible = False
            diffLotSaiban += lotNoSaiban.Height + controlHeightGap
        End If

        MyBase.filePathPanel.Top -= diffLotSaiban
        '↑A-2009/12/18_Ver7.40_LOT

        'A-CUST20190830↓
        Me.encodingSelectCombo.Visible = False
        Me.renbanSaiban.Visible = False
        diffCUST += renbanSaiban.Height + controlHeightGap
        Me.denpyoNoSaiban.Visible = False
        diffCUST += denpyoNoSaiban.Height + controlHeightGap
        MyBase.filePathPanel.Top -= diffCUST
        'A-CUST20190830↑

        '伝票系取込では項目番号付テキストの取込はなし
        MyBase.itemNumberTextImport.Visible = False

        '項目番号付テキストチェックボックスの高さを詰める
        diff = MyBase.textLayoutBox.Top - MyBase.itemNumberTextImport.Top
        diff += diffLotSaiban       'A-2009/12/18_Ver7.40_LOT
        diff += diffCUST    'A-CUST20190830
        MyBase.textLayoutBox.Top -= diff
        'A-CUST20190830↓
        MyBase.textLayoutBox.Visible = False
        diffCUST = MyBase.textLayoutBox.Height + controlHeightGap
        diff += diffCUST
        'A-CUST20190830↑
        MyBase.updateStylePanel.Top -= diff

        'A-CUST20190830↓
        Me.HacchuZanOverCheckPanel.Visible = False
        diffCUST = Me.HacchuZanOverCheckPanel.Height + controlHeightGap
        Me.KannoZumiCheckPanel.Visible = False
        diffCUST += Me.KannoZumiCheckPanel.Height + controlHeightGap
        diff += diffCUST
        'A-CUST20190830↑

        'A-20120315_3↓
        Me.HacchuZanOverCheckPanel.Top -= diff
        Me.KannoZumiCheckPanel.Top -= diff
        'A-20120315_3↑

        MyBase.tab.Height -= diff
        MyBase.conditionTabPage.Height -= diff
        FormHeight -= diff
        Me.Size = New System.Drawing.Size(Me.Width, FormHeight)

        If _myコントロール情報.汎用受入連番区分 = 機能区分定義型.汎用受入連番区分型.上書きのみ Then
            Me.overWrite.Visible = False
        Else
            Me.overWrite.Visible = True
        End If

    End Sub

#End Region

#End Region

#Region "任意に継承するメソッド(Overridable => Overrides)"

    Protected Overrides Function CreateImportParam() As IImportParam
        Dim importParam As New S90050_00.ImportParam

        Dim myオプション区分 As New Myコントロール情報Param.Myオプション区分型
        With myオプション区分
            .受発注管理 = _myコントロール情報.受発注管理
            .部門管理 = _myコントロール情報.部門管理
            .拡張項目 = _myコントロール情報.拡張項目
            .拡張項目_仕入伝票 = _myコントロール情報.拡張項目_仕入伝票
            .拡張項目_仕入明細 = _myコントロール情報.拡張項目_仕入明細
            .原価管理 = _myコントロール情報.原価管理        'A-2008/07/18_Ver7.30_GENKA
            .支払管理 = _myコントロール情報.支払管理        'A-2008/07/18_Ver7.30_SHIHARAI
            .商品内訳管理 = _myコントロール情報.商品内訳管理    'A-2009/12/18_Ver7.40_UCHIWAKE
            .ロット管理 = _myコントロール情報.ロット管理        'A-2009/12/18_Ver7.40_UCHIWAKE
            'A-CUST20190830↓
            .拡張項目_入出庫伝票 = _myコントロール情報.拡張項目_入出庫伝票
            .拡張項目_入出庫明細 = _myコントロール情報.拡張項目_入出庫明細
            'A-CUST20190830↑
        End With

        Dim my機能区分 As New Myコントロール情報Param.My機能区分型
        With my機能区分
            .倉庫別在庫管理 = _myコントロール情報.倉庫別在庫管理
            .商品コード_タイプ = _myコントロール情報.商品コード_タイプ
            .商品コード_桁数 = _myコントロール情報.商品コード_桁数
            .得意先_仕入先_コード_タイプ = _myコントロール情報.得意先_仕入先_コード_タイプ
            .得意先_仕入先_コード_桁数 = _myコントロール情報.得意先_仕入先_コード_桁数
            .小数以下桁数_数量 = _myコントロール情報.小数以下桁数.数量
            .小数以下桁数_仕入単価 = _myコントロール情報.小数以下桁数.仕入単価
            .明細単位処理_受発注引当 = _myコントロール情報.明細単位処理_受発注引当
            .明細単位処理_消費税計算 = _myコントロール情報.明細単位処理_消費税計算
            .明細単位処理_倉庫入力 = _myコントロール情報.明細単位処理_倉庫入力
            .汎用受入連番区分 = _myコントロール情報.汎用受入連番区分
            .担当者コード_タイプ = _myコントロール情報.担当者コード_タイプ
            .担当者コード_桁数 = _myコントロール情報.担当者コード_桁数
            .入数小数桁区分 = _myコントロール情報.入数小数桁区分
            .消費税改正対応区分 = _myコントロール情報.消費税改正対応区分
            .分類コード_タイプ = _myコントロール情報.分類コード_タイプ              'A-2008/07/18_Ver7.30_GENKA
            .分類コード_桁数 = _myコントロール情報.分類コード_桁数                  'A-2008/07/18_Ver7.30_GENKA
            .部門コード_タイプ = _myコントロール情報.部門コード_タイプ
            .部門コード_桁数 = _myコントロール情報.部門コード_桁数
            .営業所管理 = _myコントロール情報.営業所管理
            .営業所コード_タイプ = _myコントロール情報.営業所コード_タイプ
            .営業所コード_桁数 = _myコントロール情報.営業所コード_桁数
            .注残更新区分 = _myコントロール情報.注残更新区分
            .原価集計コード_タイプ = _myコントロール情報.原価集計コード_タイプ      'A-2008/07/18_Ver7.30_GENKA
            .原価集計コード_桁数 = _myコントロール情報.原価集計コード_桁数          'A-2008/07/18_Ver7.30_GENKA
            .小数以下桁数_換算数量 = _myコントロール情報.小数以下桁数.換算数量      'A-2009/12/18_Ver7.40_UCHIWAKE
            .受注在庫引当 = _myコントロール情報.受注在庫引当                                 'A-20121217_Ver7.50_2
            .マイナス在庫警告_未検収入荷 = _myコントロール情報.マイナス在庫警告_未検収入荷   'A-20121217_Ver7.50_4
            .在庫評価区分 = _myコントロール情報.在庫評価区分    'A-CUST20190830
        End With

        Dim my初期値 As New Myコントロール情報Param.My初期値型
        With my初期値
            .倉庫コード = _myコントロール情報.初期値_倉庫コード
            .部門コード_仕入 = _myコントロール情報.初期値_部門コード_仕入
            .営業所コード = _myコントロール情報.初期値_営業所コード
        End With

        Dim my仕入処理 As New Myコントロール情報Param.My仕入処理型
        With my仕入処理
            .入数個数 = _myコントロール情報.入数個数使用区分
            .上代 = _myコントロール情報.上代使用区分
        End With

        Dim my消費税 As New Myコントロール情報Param.My消費税型
        With my消費税
            .税抜消費税算出方法_仕入 = _myコントロール情報.税抜消費税算出方法_仕入
            .仮計上消費税使用区分 = _myコントロール情報.仮計上消費税使用区分
            .新税率区分 = _myコントロール情報.新税率使用区分
        End With

        Dim my受発注管理 As New Myコントロール情報Param.My受発注管理型
        With my受発注管理
            .売上_仕入_完納区分表示 = _myコントロール情報.売上_仕入_完納区分表示
        End With

        'A-20121217_Ver7.50_4↓
        Dim my受注在庫引当 As New Myコントロール情報Param.My受注在庫引当型
        With my受注在庫引当
            .在庫引当警告_未検収入荷 = _myコントロール情報.在庫引当警告_未検収入荷
        End With
        'A-20121217_Ver7.50_4↑

        Dim my拡張項目 As New Myコントロール情報Param.My拡張項目型
        With my拡張項目
            .拡張項目入力処理画面表示 = _myコントロール情報.拡張項目入力処理画面表示
        End With

        '↓A-2008/07/18_Ver7.30_GENKA
        Dim myＲＥＶ As New Myコントロール情報Param.MyＲＥＶ型
        With myＲＥＶ
            .強化区分 = _myコントロール情報.強化区分
        End With
        '↑A-2008/07/18_Ver7.30_GENKA

        '↓A-2008/07/18_Ver7.30_GENKA
        Dim my原価管理 As New Myコントロール情報Param.My原価管理型
        With my原価管理
            .要素使用分類種別 = _myコントロール情報.要素使用分類種別
            .明細単位原価集計入力_売上 = _myコントロール情報.明細単位原価集計入力_売上
            .明細単位原価集計入力_仕入 = _myコントロール情報.明細単位原価集計入力_仕入
        End With
        '↑A-2008/07/18_Ver7.30_GENKA

        '↓A-2008/07/18_Ver7.30_SHIHARAI
        Dim my支払管理 As New Myコントロール情報Param.My支払管理型
        With my支払管理
            .支払先別支払管理単位設定 = _myコントロール情報.支払先別支払管理単位設定
            .支払管理単位 = _myコントロール情報.支払管理単位
            .支払_原価集計別管理 = _myコントロール情報.支払_原価集計別管理
        End With
        '↑A-2008/07/18_Ver7.30_SHIHARAI

        '↓A-2009/08/21_RIREKI
        Dim my変更履歴 As New Myコントロール情報Param.My変更履歴型
        With my変更履歴
            .変更履歴使用区分 = _myコントロール情報.変更履歴使用区分
            .変更履歴_仕入 = _myコントロール情報.変更履歴_仕入
            .変更履歴_発注 = _myコントロール情報.変更履歴_発注
            .変更履歴_内訳 = _myコントロール情報.変更履歴_内訳              'A-2009/12/18_Ver7.40_UCHIWAKE
            .変更履歴_商品内訳 = _myコントロール情報.変更履歴_商品内訳      'A-2009/12/18_Ver7.40_UCHIWAKE
            .変更履歴_ロット = _myコントロール情報.変更履歴_ロット          'A-2009/12/18_Ver7.40_LOT
        End With
        '↑A-2009/08/21_RIREKI

        '↓A-2009/12/18_Ver7.40_UCHIWAKE
        Dim my商品内訳管理 As New Myコントロール情報Param.My商品内訳管理型
        With my商品内訳管理
            ReDim .内訳コードタイプ(0 To [Enum].GetNames(GetType(内訳種別型)).Length)       '※0番目は未使用
            ReDim .内訳コード桁数(0 To [Enum].GetNames(GetType(内訳種別型)).Length)         '※0番目は未使用
            ReDim .内訳数値小数桁数(0 To [Enum].GetNames(GetType(内訳種別型)).Length)       '※0番目は未使用

            For 内訳Index As Integer = 1 To [Enum].GetNames(GetType(内訳種別型)).Length
                Dim 内訳種別 As 内訳種別型 = CType(内訳Index, 内訳種別型)
                .内訳コードタイプ(内訳種別) = _myコントロール情報.内訳コードタイプ(内訳種別)
                .内訳コード桁数(内訳種別) = _myコントロール情報.内訳コード桁数(内訳種別)
                .内訳数値小数桁数(内訳種別) = _myコントロール情報.内訳数値小数桁数(内訳種別)
            Next
            .内訳管理数 = _myコントロール情報.内訳管理数
            .内訳マスター自動登録 = _myコントロール情報.内訳マスター自動登録
            .売上_仕入_処理_内訳変更区分 = _myコントロール情報.売上_仕入_処理_内訳変更区分
            .内訳タイプ = _myコントロール情報.内訳タイプ
            .換算数量使用区分 = _myコントロール情報.換算数量使用区分
        End With
        '↑A-2009/12/18_Ver7.40_UCHIWAKE

        '↓A-2009/12/18_Ver7.40_LOT
        Dim myロット管理 As New Myコントロール情報Param.Myロット管理型
        With myロット管理
            .手入力ロットNo桁数 = _myコントロール情報.手入力ロットNo桁数
            .ロットNo採番方法 = _myコントロール情報.ロットNo採番方法
            .有効期限機能 = _myコントロール情報.有効期限機能
        End With
        '↑A-2009/12/18_Ver7.40_LOT

        '↓A-2009/12/18_Ver7.40_LOT
        Dim my端数処理 As New Myコントロール情報Param.My端数処理型
        With my端数処理
            .単価端数処理_仕入_処理区分 = _myコントロール情報.単価端数処理_仕入.処理区分
            .単価端数処理_仕入_単位 = _myコントロール情報.単価端数処理_仕入.単位
        End With
        '↑A-2009/12/18_Ver7.40_LOT

        Dim my販売財務連動 As New Myコントロール情報Param.My販売財務連動型
        With my販売財務連動
            .販売財務連動区分 = _myコントロール情報.販売財務連動区分
            .仕入データ連動区分 = _myコントロール情報.仕入データ連動区分
        End With

        '↓A-2008/07/18_Ver7.30_SAIMU
        Dim my会計オプション As New Myコントロール情報Param.My会計オプション型
        With my会計オプション
            .会計債務管理 = _myコントロール情報.会計債務管理
            .会計債務残消込管理 = _myコントロール情報.会計債務残消込管理
            .会計原価振替処理 = _myコントロール情報.会計原価振替処理                'A-2009/12/18_Ver7.40_PRO
        End With
        '↑A-2008/07/18_Ver7.30_SAIMU

        '↓A-2010/09/13_Ver7.4X_ZAISHONIN
        Dim my会計伝票承認 As New Myコントロール情報Param.My会計伝票承認型
        With my会計伝票承認
            .会計伝票承認機能 = _myコントロール情報.会計伝票承認機能
        End With
        '↑A-2010/09/13_Ver7.4X_ZAISHONIN

        Dim myMOA初期値 As New Myコントロール情報Param.MyMOA初期値型
        With myMOA初期値
            .ダミーロットNo = _myコントロール情報.ダミーロットNo
            'A-20120315_3↓
            .残以上の取込を許可 = _myコントロール情報.残以上の取込を許可
            .完納データに対する取込を許可 = _myコントロール情報.完納データに対する取込を許可
            'A-20120315_3↑

            'A-20120522_1↓
            .需要数計算端数処理 = _myコントロール情報.需要数計算端数処理
            .需要数計算端数処理_計算単位 = _myコントロール情報.需要数計算端数処理_計算単位
            'A-20120522_1↑
        End With

        Dim myMOAオプション As New Myコントロール情報Param.MyMOAオプション型
        With myMOAオプション
            .MOA品質管理 = _myコントロール情報.MOA品質管理
            .MOA原価管理 = _myコントロール情報.MOA原価管理
            .MOA外貨管理 = _myコントロール情報.MOA外貨管理     'A-20121217_Ver7.50_1
        End With

        Dim myMOAロット管理 As New Myコントロール情報Param.MyMOAロット管理型
        With myMOAロット管理
            .有効期限更新方法設定 = _myコントロール情報.有効期限更新方法設定
        End With

        Dim myMOA機能追加 As New Myコントロール情報Param.MyMOA機能追加型
        With myMOA機能追加
            .マイナス在庫チェック = _myコントロール情報.マイナス在庫チェック
            .品目名既定値_代表品名 = _myコントロール情報.品目名既定値_代表品名
            .構成品自動出庫 = _myコントロール情報.構成品自動出庫
            .仕入検収基準 = _myコントロール情報.仕入検収基準
            .ロットNo管理区分_受入 = _myコントロール情報.ロットNo管理区分_受入
            .支給管理区分 = _myコントロール情報.支給管理区分
            .仕掛管理区分 = _myコントロール情報.仕掛管理区分        'A-20110912_1
            .仕掛計上区分 = _myコントロール情報.仕掛計上区分        'A-20110912_1
            .ロケーション単位数量指定列 = _myコントロール情報.ロケーション単位数量指定列            'A-20121217_Ver7.50_3
            .未検収在庫機能 = _myコントロール情報.未検収在庫機能                                    'A-20121217_Ver7.50_4
            .マイナス仕掛在庫警告_未検収入荷 = _myコントロール情報.マイナス仕掛在庫警告_未検収入荷  'A-20121217_Ver7.50_4
            .標準原価積上機能 = _myコントロール情報.標準原価積上機能    'A-20141105_1
            .品目別原価計算機能 = _myコントロール情報.品目別原価計算機能    'A-20150520_1
            .外貨管理明細邦貨額積上機能 = _myコントロール情報.外貨管理明細邦貨額積上機能    'A-20160324_1
            .製番別締機能 = _myコントロール情報.製番別締機能                                'A-20160324_2
            'A-20170417_1↓
            .見込受注得意先以外の出庫予定制御 = _myコントロール情報.見込受注得意先以外の出庫予定制御
            .生産計画機能 = _myコントロール情報.生産計画機能
            'A-20170417_1↑
        End With

        Dim myMOA受入処理 As New Myコントロール情報Param.MyMOA受入処理型
        With myMOA受入処理
            .納期前チェック = _myコントロール情報.納期前チェック
            .仮単価チェック = _myコントロール情報.仮単価チェック
            .前工程チェック = _myコントロール情報.前工程チェック
        End With

        Dim my項目名称 As New My項目名称Param型
        With my項目名称
            .販売営業所 = _my項目名称.販売営業所
            .販売仕入先 = _my項目名称.販売仕入先
            .販売仕入担当者_項目 = _my項目名称.販売仕入担当者_項目
            .販売部門 = _my項目名称.販売部門
            .販売倉庫 = _my項目名称.販売倉庫
            .販売商品 = _my項目名称.販売商品
            .販売得意先 = _my項目名称.販売得意先                                    'A-2008/07/18_Ver7.30_GENKA
            .販売原価集計 = _my項目名称.販売原価集計                                'A-2008/07/18_Ver7.30_GENKA
            .販売原価集計メイン = _my項目名称.販売原価集計メイン                    'A-2008/07/18_Ver7.30_GENKA
            .販売原価集計サブ = _my項目名称.販売原価集計サブ                        'A-2008/07/18_Ver7.30_GENKA
            'エラー内容取得メソッドで用いる為、要素タイトルを項目名称Paramに設定    'A-2008/07/18_Ver7.30_GENKA
            .要素タイトル = Get要素タイトル()                                       'A-2008/07/18_Ver7.30_GENKA
            .販売換算数量 = _my項目名称.販売換算数量                'A-2009/12/18_Ver7.40_UCHIWAKE
            .販売単位換算数量 = _my項目名称.販売単位換算数量        'A-2009/12/18_Ver7.40_UCHIWAKE
            .販売ロット = _my項目名称.販売ロット                    'A-2009/12/18_Ver7.40_LOT
            .販売ロットNo = _my項目名称.販売ロットNo                'A-2009/12/18_Ver7.40_LOT
            .販売サブロットNo = _my項目名称.販売サブロットNo        'A-2009/12/18_Ver7.40_LOT
            .会計完成 = _my項目名称.会計完成                        'A-2009/12/18_Ver7.40_PRO
            .販売品目名１ = _my項目名称.販売品目名１
            .販売品目名２ = _my項目名称.販売品目名２
            .販売品目名３ = _my項目名称.販売品目名３
            .販売客先注番 = _my項目名称.販売客先注番
            .販売有効期限 = _my項目名称.販売有効期限
        End With
        'A-20110912_1↓
        Dim myMOAＲＥＶ As New Myコントロール情報Param.MyMOAＲＥＶ型
        With myMOAＲＥＶ
            .MOA強化区分 = _myコントロール情報.MOA強化区分
        End With
        'A-20110912_1↑

        'A-20121217_Ver7.50_1↓
        Dim myMOA外貨管理 As New Myコントロール情報Param.MyMOA外貨管理型
        With myMOA外貨管理
            .日本円通貨コード = _myコントロール情報.日本円通貨コード
            '
            ReDim .レート使用区分(9)
            ReDim .レート名称(9)
            For i As Integer = 1 To 9
                .レート使用区分(i) = _myコントロール情報.レート使用区分(i)
                .レート名称(i) = _myコントロール情報.レート名称(i)
            Next
            .外貨複数伝票消込機能 = _myコントロール情報.外貨複数伝票消込機能    'A-20160324_1
        End With
        'A-20121217_Ver7.50_1↑
        'A-20121217_Ver7.50_2↓
        Dim myMOA在庫引当 As New Myコントロール情報Param.MyMOA在庫引当型
        With myMOA在庫引当
            .引当数量算出区分_未検収入荷 = _myコントロール情報.引当数量算出区分_未検収入荷
            .在庫引当_自動出庫区分 = _myコントロール情報.在庫引当_自動出庫区分
            .需要数_入庫時即引当 = _myコントロール情報.需要数_入庫時即引当
            .出庫まるめ引当単位区分 = _myコントロール情報.出庫まるめ引当単位区分     'A-20180723-X1-引当
        End With
        'A-20121217_Ver7.50_2↑

        'A-20150520_1↓
        Dim myMOA品目別原価 As New Myコントロール情報Param.MyMOA品目別原価型
        With myMOA品目別原価
            .出庫時原価採用区分 = _myコントロール情報.出庫時原価採用区分
        End With
        'A-20150520_1↑
        'A-20170417_1↓
        Dim myMOAその他 As New Myコントロール情報Param.MyMOAその他型
        With myMOAその他
            .見込受注用得意先コード = _myコントロール情報.見込受注用得意先コード
        End With
        'A-20170417_1↑

        '↓A-20170601-X1-桁数拡張
        Dim my桁数拡張 As New Myコントロール情報Param.My桁数拡張型
        With my桁数拡張
            .名称桁数 = _myコントロール情報.名称桁数
            .金額桁数 = _myコントロール情報.金額桁数
            .金額桁数_実績 = _myコントロール情報.金額桁数_実績
            .拡張項目データリンク桁数拡張 = _myコントロール情報.拡張項目データリンク桁数拡張
        End With
        '↑A-20170601-X1-桁数拡張

        With importParam
            .Myコントロール情報.Myオプション区分 = myオプション区分
            .Myコントロール情報.My機能区分 = my機能区分
            .Myコントロール情報.My初期値 = my初期値
            .Myコントロール情報.My仕入処理 = my仕入処理
            .Myコントロール情報.My消費税 = my消費税
            .Myコントロール情報.My受発注管理 = my受発注管理
            .Myコントロール情報.My拡張項目 = my拡張項目
            .Myコントロール情報.MyＲＥＶ = myＲＥＶ         'A-2008/07/18_Ver7.30_GENKA
            .Myコントロール情報.My原価管理 = my原価管理     'A-2008/07/18_Ver7.30_GENKA
            .Myコントロール情報.My支払管理 = my支払管理     'A-2008/07/18_Ver7.30_SHIHARAI
            .Myコントロール情報.My変更履歴 = my変更履歴     'A-2009/08/21_RIREKI
            .Myコントロール情報.My商品内訳管理 = my商品内訳管理     'A-2009/12/18_Ver7.40_UCHIWAKE
            .Myコントロール情報.Myロット管理 = myロット管理         'A-2009/12/18_Ver7.40_LOT
            .Myコントロール情報.My端数処理 = my端数処理             'A-2009/12/18_Ver7.40_LOT
            .Myコントロール情報.My受注在庫引当 = my受注在庫引当     'A-20121217_Ver7.50_4
            .Myコントロール情報.My桁数拡張 = my桁数拡張             'A-20170601-X1-桁数拡張
            .Myコントロール情報.My販売財務連動 = my販売財務連動
            .Myコントロール情報.My会計オプション = my会計オプション     'A-2008/07/18_Ver7.30_SAIMU
            .Myコントロール情報.My会計伝票承認 = my会計伝票承認         'A-2010/09/13_Ver7.4X_ZAISHONIN
            .Myコントロール情報.MyMOA初期値 = myMOA初期値
            .Myコントロール情報.MyMOAオプション = myMOAオプション
            .Myコントロール情報.MyMOAロット管理 = myMOAロット管理
            .Myコントロール情報.MyMOA機能追加 = myMOA機能追加
            .Myコントロール情報.MyMOA受入処理 = myMOA受入処理
            .Myコントロール情報.MyMOAＲＥＶ = myMOAＲＥＶ           'A-20110912_1
            .Myコントロール情報.MyMOA外貨管理 = myMOA外貨管理       'A-20121217_Ver7.50_1
            .Myコントロール情報.MyMOA在庫引当 = myMOA在庫引当       'A-20121217_Ver7.50_2
            .My項目名称 = my項目名称
            .Myコントロール情報.MyMOA品目別原価 = myMOA品目別原価   'A-20150520_1
            .Myコントロール情報.MyMOAその他 = myMOAその他           'A-20170417_1
        End With

        '拡張項目情報.仕入伝票
        importParam.拡張項目情報_仕入伝票_使用 = MyBase.GetInitInfo(ProgramLib.プログラム専用_仕入伝票拡張項目有無, False)
        If MyBase.GetInitInfo(ProgramLib.プログラム専用_仕入伝票拡張項目有無, False) = True Then
            importParam.拡張項目情報_仕入伝票 = _拡張項目情報_仕入伝票
            importParam.拡張項目情報_仕入伝票_更新番号 = MyBase.GetInitInfo(ProgramLib.プログラム専用_仕入伝票拡張更新番号, 0)
        End If

        '拡張項目情報.仕入明細
        importParam.拡張項目情報_仕入明細_使用 = MyBase.GetInitInfo(ProgramLib.プログラム専用_仕入明細拡張項目有無, False)
        If MyBase.GetInitInfo(ProgramLib.プログラム専用_仕入明細拡張項目有無, False) = True Then
            importParam.拡張項目情報_仕入明細 = _拡張項目情報_仕入明細
            importParam.拡張項目情報_仕入明細_更新番号 = MyBase.GetInitInfo(ProgramLib.プログラム専用_仕入明細拡張更新番号, 0)
        End If

        '拡張項目情報.入荷伝票
        importParam.拡張項目情報_入荷伝票_使用 = MyBase.GetInitInfo(ProgramLib.プログラム専用_入荷伝票拡張項目有無, False)
        If MyBase.GetInitInfo(ProgramLib.プログラム専用_入荷伝票拡張項目有無, False) = True Then
            importParam.拡張項目情報_入荷伝票 = _拡張項目情報_入荷伝票
            importParam.拡張項目情報_入荷伝票_更新番号 = MyBase.GetInitInfo(ProgramLib.プログラム専用_入荷伝票拡張更新番号, 0)
        End If

        '拡張項目情報.入荷明細
        importParam.拡張項目情報_入荷明細_使用 = MyBase.GetInitInfo(ProgramLib.プログラム専用_入荷明細拡張項目有無, False)
        If MyBase.GetInitInfo(ProgramLib.プログラム専用_入荷明細拡張項目有無, False) = True Then
            importParam.拡張項目情報_入荷明細 = _拡張項目情報_入荷明細
            importParam.拡張項目情報_入荷明細_更新番号 = MyBase.GetInitInfo(ProgramLib.プログラム専用_入荷明細拡張更新番号, 0)
        End If

        importParam.操作日付 = _systemDate

        'A-CUST20190830↓
        '拡張項目情報.入出庫伝票
        If _myコントロール情報.拡張項目_入出庫伝票 = True Then
            importParam.拡張項目情報_入出庫伝票 = _拡張項目情報_入出庫伝票
            importParam.拡張項目情報_入出庫伝票_更新番号 = MyBase.GetInitInfo(ProgramLib.プログラム専用_入出庫伝票拡張更新番号, 0)
        End If

        '拡張項目情報.入出庫明細
        If _myコントロール情報.拡張項目_入出庫明細 = True Then
            importParam.拡張項目情報_入出庫明細 = _拡張項目情報_入出庫明細
            importParam.拡張項目情報_入出庫明細_更新番号 = MyBase.GetInitInfo(ProgramLib.プログラム専用_入出庫明細拡張更新番号, 0)
        End If

        Dim ymd As String = CStr(_systemDate)   '年月日
        Dim nendo As String = ""                        '対象年度
        Dim hygn As String = ""                         '年月表現
        Dim hniF As String = ""                         '対象年月のFrom年月日
        Dim hniT As String = ""                         '対象年月のTo年月日
        Dim gaitoki As Integer                          '該当期
        Dim mm As Integer                               '該当月数
        Dim kanri As Integer                            '明細管理区分
        If _販売日付情報.GetByYMD(ymd, nendo, hygn, hniF, hniT, gaitoki, mm, kanri) = False Then
            'GoTo Check_Error
        Else
            importParam.年月度 = hygn
        End If

        'JTB様コントロール取得
        Dim dt As New DataTable
        Dim dataAccess As IMasterReader = CreateDataAccessMasterReader()
        Dim 移動中倉庫コード As String = ""
        Dim param As New ReadParam
        param.Container(ReadParam.項目名型.CA01KEY) = "NYUSHUKOYOTEI01"
        If ReadMaster_JTB様コントロール(param, dt, dataAccess) = True Then
            移動中倉庫コード = CStr(dt.Rows(0).Item("SEICA01002"))
        End If

        importParam.移動中倉庫コード = 移動中倉庫コード

        MakeImportText元ファイル内容の退避(folderInput.TextValue, "", fileInput.TextValue.Trim, 0, importParam)
        'A-CUST20190830↑

        Return importParam
    End Function

    ''' <summary>
    ''' 前回の処理情報が残っている場合、画面にセットする
    ''' </summary>
    ''' <remarks></remarks>
    Protected Overrides Sub SetSaveInfoToFormImpl()

        With MyBase.KanriTableData
            Try
                Select Case TextFileImportLib.GetKeywordValue(.取込条件, "処理連番の採番方法")
                    Case ImportParam.処理連番採番型.入力処理連番を採用する.ToString
                        renbanSaiban.Value = ImportParam.処理連番採番型.入力処理連番を採用する
                    Case ImportParam.処理連番採番型.新規に採番する.ToString
                        renbanSaiban.Value = ImportParam.処理連番採番型.新規に採番する
                    Case Else
                        renbanSaiban.Value = ImportParam.処理連番採番型.入力処理連番を採用する
                End Select

                Select Case TextFileImportLib.GetKeywordValue(.取込条件, "伝票№の採番方法")
                    Case ImportParam.伝票番号採番型.入力伝票番号を採用する.ToString
                        denpyoNoSaiban.Value = ImportParam.伝票番号採番型.入力伝票番号を採用する
                    Case ImportParam.伝票番号採番型.新規に採番する.ToString
                        denpyoNoSaiban.Value = ImportParam.伝票番号採番型.新規に採番する
                    Case Else
                        denpyoNoSaiban.Value = ImportParam.伝票番号採番型.入力伝票番号を採用する
                End Select

                '↓A-2009/12/18_Ver7.40_LOT
                If Is画面条件有効判定_ロットNo採番() = True Then
                    Select Case TextFileImportLib.GetKeywordValue(.取込条件, "ロット№の採番方法")
                        Case ImportParam.ロットNo採番型.入力ロットNoを採用する.ToString
                            lotNoSaiban.Value = ImportParam.ロットNo採番型.入力ロットNoを採用する
                        Case ImportParam.ロットNo採番型.新規に採番する.ToString
                            lotNoSaiban.Value = ImportParam.ロットNo採番型.新規に採番する
                        Case Else
                            lotNoSaiban.Value = ImportParam.ロットNo採番型.入力ロットNoを採用する
                    End Select
                End If
                '↑A-2009/12/18_Ver7.40_LOT

                If CType(TextFileImportLib.GetKeywordValue(.更新方法, "同一処理連番存在時は上書き"), Boolean) = True Then
                    overWrite.CheckState = CheckState.Checked
                Else
                    overWrite.CheckState = CheckState.Unchecked
                End If

                'A-20120315_3↓
                Select Case TextFileImportLib.GetKeywordValue(.取込条件, "発注残以上のデータ取込チェック")
                    Case CStr(ImportParam.残チェック区分型.エラー)
                        HacchuZanOverCheckPanel.Value = ImportParam.残チェック区分型.エラー
                    Case CStr(ImportParam.残チェック区分型.警告)
                        HacchuZanOverCheckPanel.Value = ImportParam.残チェック区分型.警告
                    Case Else
                        HacchuZanOverCheckPanel.Value = ImportParam.残チェック区分型.なし
                End Select

                Select Case TextFileImportLib.GetKeywordValue(.取込条件, "完納済みデータ取込チェック")
                    Case CStr(ImportParam.残チェック区分型.エラー)
                        KannoZumiCheckPanel.Value = ImportParam.残チェック区分型.エラー
                    Case CStr(ImportParam.残チェック区分型.警告)
                        KannoZumiCheckPanel.Value = ImportParam.残チェック区分型.警告
                    Case Else
                        KannoZumiCheckPanel.Value = ImportParam.残チェック区分型.なし
                End Select
                'A-20120315_3↑

            Catch ex As Exception
                'DB値が不正な場合は何もしない

            End Try
        End With

    End Sub

    ''' <summary>
    ''' パラメータの編集
    ''' </summary>
    ''' <remarks></remarks>
    Protected Overrides Sub EditImportParamProgram(ByRef importParam As IImportParam)

        Dim param As ImportParam = CType(importParam, ImportParam)

        With param
            .処理連番採番 = CType(Me.renbanSaiban.Value, ImportParam.処理連番採番型)
            .伝票番号採番 = CType(Me.denpyoNoSaiban.Value, ImportParam.伝票番号採番型)
            '↓A-2009/12/18_Ver7.40_LOT
            If Is画面条件有効判定_ロットNo採番() = True Then
                .ロットNo採番 = CType(Me.lotNoSaiban.Value, ImportParam.ロットNo採番型)
            End If
            '↑A-2009/12/18_Ver7.40_LOT

            Select Case _myコントロール情報.汎用受入連番区分
                Case 機能区分定義型.汎用受入連番区分型.上書きのみ
                    .同一処理連番存在時は上書き = True
                Case Else
                    If Me.renbanSaiban.Value = S90050_00.ImportParam.処理連番採番型.新規に採番する Then
                        .同一処理連番存在時は上書き = False
                    Else
                        .同一処理連番存在時は上書き = (Me.overWrite.CheckState = CheckState.Checked)
                    End If
            End Select

            'A-20120315_3↓
            .発注残以上のデータ取込チェック = CType(HacchuZanOverCheckPanel.Value, ImportParam.残チェック区分型)
            .完納済みデータ取込チェック = CType(KannoZumiCheckPanel.Value, ImportParam.残チェック区分型)
            'A-20120315_3↑

            'A-CUST20190830↓
            .処理連番採番 = S90050_00.ImportParam.処理連番採番型.新規に採番する
            .伝票番号採番 = S90050_00.ImportParam.伝票番号採番型.新規に採番する
            .発注残以上のデータ取込チェック = S90050_00.ImportParam.残チェック区分型.警告
            .完納済みデータ取込チェック = S90050_00.ImportParam.残チェック区分型.エラー

            .退避フォルダ = .入力元フォルダ
            .退避ファイル名 = .入力元ファイル名

            .入力元ファイル名 = _変換テキスト名
            'A-CUST20190830↑

        End With

    End Sub

    Protected Overrides Function EndImportPrivateImpl(ByRef result As Foundation.TextFileImport.IResult,
                                                      ByRef resultImport As Foundation.TextFileImport.IResultImport,
                                                      ByRef executeCheckInfo As Foundation.ExecuteCheck.IExecuteCheckInfo
                      ) As Boolean

        'A-CUST20190830↓
        Dim fromFolder As String = TextFileImportLib.EditFolder(folderInput.TextValue.Trim)
        IO.File.Delete(fromFolder & _変換テキスト名)
        'A-CUST20190830↑

        If result.Code = Foundation.ResultType.他で更新済 AndAlso result.TableID = "HANZ030" Then
            MyBase.MessageViewer.Show(ProgramLib.Myメッセージ.HAN3005_拡張項目の定義が変更されています_拡張項目内容を確認して下さい)
            _無条件終了フラグ = True
            Me.Close()
            Return True
        End If

        Return False
    End Function

    Protected Overrides Function Get処理タイプ() As Foundation.TextFileImport.TextFileImportLib.処理タイプ型
        Return TextFileImportLib.処理タイプ型.伝票タイプ
    End Function

#End Region

#Region "■条件パターンバー関連処理■"

    Protected Overrides Sub KeyDownPatternComboImpl(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs)
        If e.KeyCode = Keys.Return Then
            tab.SetCurrentTabPage(0)
            'Me.renbanSaiban.Focus()                'D-CUST20190830
            Me.folderInput.InputTextControl.Focus() 'A-CUST20190830
        End If
    End Sub

    ''' <summary>
    ''' 条件パターン選択
    ''' </summary>
    ''' <param name="patternData"></param>
    ''' <remarks></remarks>
    Protected Overrides Sub SelctedPatternChangedImpl(ByVal patternData As OSK.X1.Foundation.PairKeyDictionary)    'X1変換Tool-20170508
        Call MyBase.SelctedPatternChangedImpl(patternData) '必須

        Select Case patternData.GetValue("処理連番の採番方法", "", "入力処理連番を採用する")
            Case "入力処理連番を採用する"
                Me.renbanSaiban.Value = ImportParam.処理連番採番型.入力処理連番を採用する
            Case "新規に採番する"
                Me.renbanSaiban.Value = ImportParam.処理連番採番型.新規に採番する
        End Select

        Select Case patternData.GetValue("伝票№の採番方法", "", "入力伝票№を採用する")
            Case "入力伝票№を採用する"
                Me.denpyoNoSaiban.Value = ImportParam.伝票番号採番型.入力伝票番号を採用する
            Case "新規に採番する"
                Me.denpyoNoSaiban.Value = ImportParam.伝票番号採番型.新規に採番する
        End Select

        '↓A-2009/12/18_Ver7.40_LOT
        If Is画面条件有効判定_ロットNo採番() = True Then
            Select Case patternData.GetValue("ロット№の採番方法", "", "入力ロット№を採用する")
                Case "入力ロット№を採用する"
                    Me.lotNoSaiban.Value = ImportParam.ロットNo採番型.入力ロットNoを採用する
                Case "新規に採番する"
                    Me.lotNoSaiban.Value = ImportParam.ロットNo採番型.新規に採番する
            End Select
        End If
        '↑A-2009/12/18_Ver7.40_LOT

        If _myコントロール情報.汎用受入連番区分 <> 機能区分定義型.汎用受入連番区分型.上書きのみ Then
            If patternData.GetValue("同一処理連番存在時は上書き", "", CheckState.Unchecked.ToString) = CheckState.Checked.ToString Then
                overWrite.CheckState = CheckState.Checked
            Else
                overWrite.CheckState = CheckState.Unchecked
            End If
        End If

        'A-20120315_3↓
        Dim 発注残以上チェック初期値 As String = "なし"
        If _myコントロール情報.MOA強化区分 >= 3.2D Then
            Select Case _myコントロール情報.残以上の取込を許可
                Case MOA追加初期値定義型.取込処理残チェック区分型.エラー
                    発注残以上チェック初期値 = "エラー"
                Case MOA追加初期値定義型.取込処理残チェック区分型.警告
                    発注残以上チェック初期値 = "警告"
            End Select
        End If

        Select Case patternData.GetValue("発注残以上のデータ取込チェック", "", 発注残以上チェック初期値)
            Case "エラー"
                Me.HacchuZanOverCheckPanel.Value = ImportParam.残チェック区分型.エラー
            Case "警告"
                Me.HacchuZanOverCheckPanel.Value = ImportParam.残チェック区分型.警告
            Case Else
                Me.HacchuZanOverCheckPanel.Value = ImportParam.残チェック区分型.なし
        End Select

        Dim 完納済みチェック初期値 As String = "なし"
        If _myコントロール情報.MOA強化区分 >= 3.2D Then
            Select Case _myコントロール情報.完納データに対する取込を許可
                Case MOA追加初期値定義型.取込処理残チェック区分型.エラー
                    完納済みチェック初期値 = "エラー"
                Case MOA追加初期値定義型.取込処理残チェック区分型.警告
                    完納済みチェック初期値 = "警告"
            End Select
        End If

        Select Case patternData.GetValue("完納済みデータ取込チェック", "", 完納済みチェック初期値)
            Case "エラー"
                Me.KannoZumiCheckPanel.Value = ImportParam.残チェック区分型.エラー
            Case "警告"
                Me.KannoZumiCheckPanel.Value = ImportParam.残チェック区分型.警告
            Case Else
                Me.KannoZumiCheckPanel.Value = ImportParam.残チェック区分型.なし
        End Select
        'A-20120315_3↑

        'A-CUST20190830↓
        '内部値セット
        Me.renbanSaiban.Value = ImportParam.処理連番採番型.新規に採番する
        Me.denpyoNoSaiban.Value = ImportParam.伝票番号採番型.新規に採番する
        Me.lotNoSaiban.Value = ImportParam.ロットNo採番型.新規に採番する
        overWrite.CheckState = CheckState.Unchecked
        Me.HacchuZanOverCheckPanel.Value = ImportParam.残チェック区分型.警告
        Me.KannoZumiCheckPanel.Value = ImportParam.残チェック区分型.エラー
        'A-CUST20190830↑

    End Sub

    ''' <summary>
    ''' 条件パターン保存
    ''' </summary>
    ''' <param name="patternData"></param>
    ''' <remarks></remarks>
    Protected Overrides Sub ClickSavePatternImpl(ByRef patternData As OSK.X1.Foundation.PairKeyDictionary)    'X1変換Tool-20170508
        Call MyBase.ClickSavePatternImpl(patternData) '必須

        Select Case Me.renbanSaiban.Value
            Case ImportParam.処理連番採番型.入力処理連番を採用する
                patternData.Add("処理連番の採番方法", "", "入力処理連番を採用する")
            Case ImportParam.処理連番採番型.新規に採番する
                patternData.Add("処理連番の採番方法", "", "新規に採番する")
        End Select

        Select Case Me.denpyoNoSaiban.Value
            Case ImportParam.伝票番号採番型.入力伝票番号を採用する
                patternData.Add("伝票№の採番方法", "", "入力伝票№を採用する")
            Case ImportParam.伝票番号採番型.新規に採番する
                patternData.Add("伝票№の採番方法", "", "新規に採番する")
        End Select

        '↓A-2009/12/18_Ver7.40_LOT
        If Is画面条件有効判定_ロットNo採番() = True Then
            Select Case Me.lotNoSaiban.Value
                Case ImportParam.ロットNo採番型.入力ロットNoを採用する
                    patternData.Add("ロット№の採番方法", "", "入力ロット№を採用する")
                Case ImportParam.ロットNo採番型.新規に採番する
                    patternData.Add("ロット№の採番方法", "", "新規に採番する")
            End Select
        End If
        '↑A-2009/12/18_Ver7.40_LOT

        If _myコントロール情報.汎用受入連番区分 <> 機能区分定義型.汎用受入連番区分型.上書きのみ Then
            patternData.Add("同一処理連番存在時は上書き", "", overWrite.CheckState.ToString)
        End If

        'A-20120315_3↓
        Select Case Me.HacchuZanOverCheckPanel.Value
            Case ImportParam.残チェック区分型.エラー
                patternData.Add("発注残以上のデータ取込チェック", "", "エラー")
            Case ImportParam.残チェック区分型.警告
                patternData.Add("発注残以上のデータ取込チェック", "", "警告")
            Case Else
                patternData.Add("発注残以上のデータ取込チェック", "", "なし")
        End Select

        Select Case Me.KannoZumiCheckPanel.Value
            Case ImportParam.残チェック区分型.エラー
                patternData.Add("完納済みデータ取込チェック", "", "エラー")
            Case ImportParam.残チェック区分型.警告
                patternData.Add("完納済みデータ取込チェック", "", "警告")
            Case Else
                patternData.Add("完納済みデータ取込チェック", "", "なし")
        End Select
        'A-20120315_3↑

    End Sub

#End Region

#Region "■ファンクションバー関連■"


#End Region

#Region "イベント"

    Private Sub CommandForm_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        Me.tab.SetCurrentTabPage(0)
        'Me.renbanSaiban.Focus()                'D-CUST20190830
        Me.folderInput.InputTextControl.Focus() 'A-CUST20190830
    End Sub

    Private Sub renbanSaiban_SelChange(ByVal sender As Object, ByVal e As System.EventArgs) Handles renbanSaiban.SelChange
        ChangeRenbanSaiban()
    End Sub

    Private Sub ChangeRenbanSaiban()

        If _myコントロール情報.汎用受入連番区分 <> 機能区分定義型.汎用受入連番区分型.上書きのみ Then
            Select Case Me.renbanSaiban.Value
                Case ImportParam.処理連番採番型.新規に採番する
                    Me.overWrite.Visible = False
                Case Else
                    Me.overWrite.Visible = True
            End Select
        End If

    End Sub

#End Region

#Region "操作実行ログ作成"

    Protected Overrides Function GetDoImportLog取込条件() As String
        Dim log As String = ""
        Dim logInfoHelper As CMN.LIB.AppLog.UserInterface.ILogInfoHelper = CMN.LIB.PartReplacement.CommonFactory.CreateInstance(Of CMN.LIB.AppLog.UserInterface.ILogInfoHelper)(Me, GetType(CMN.LIB.AppLog.UserInterface.LogInfoHelper))

        Select Case Me.renbanSaiban.Value
            Case ImportParam.処理連番採番型.入力処理連番を採用する
                log &= logInfoHelper.MakeLog("処理連番の採番方法", "入力処理連番を採用する")
            Case ImportParam.処理連番採番型.新規に採番する
                log &= logInfoHelper.MakeLog("処理連番の採番方法", "新規に採番する")
        End Select

        Select Case Me.denpyoNoSaiban.Value
            Case ImportParam.伝票番号採番型.入力伝票番号を採用する
                log &= logInfoHelper.MakeLog("伝票№の採番方法", "入力伝票№を採用する")
            Case ImportParam.伝票番号採番型.新規に採番する
                log &= logInfoHelper.MakeLog("伝票№の採番方法", "新規に採番する")
        End Select

        '↓A-2009/12/18_Ver7.40_LOT
        If Is画面条件有効判定_ロットNo採番() = True Then
            Select Case Me.lotNoSaiban.Value
                Case ImportParam.ロットNo採番型.入力ロットNoを採用する
                    log &= logInfoHelper.MakeLog(_my項目名称.販売ロットNo & "の採番方法", "入力" & _my項目名称.販売ロットNo & "を採用する")
                Case ImportParam.ロットNo採番型.新規に採番する
                    log &= logInfoHelper.MakeLog(_my項目名称.販売ロットNo & "の採番方法", "新規に採番する")
            End Select
        End If
        '↑A-2009/12/18_Ver7.40_LOT

        Return log
    End Function

    Protected Overrides Function GetDoImportLog更新方法の指定() As String
        Dim log As String = ""
        Dim logInfoHelper As CMN.LIB.AppLog.UserInterface.ILogInfoHelper = CMN.LIB.PartReplacement.CommonFactory.CreateInstance(Of CMN.LIB.AppLog.UserInterface.ILogInfoHelper)(Me, GetType(CMN.LIB.AppLog.UserInterface.LogInfoHelper))
        log &= MyBase.GetDoImportLog更新方法の指定()
        If Me.overWrite.Visible = True Then
            log &= logInfoHelper.MakeCheckBoxLog("更新方法の指定.同一処理連番存在時は上書き", Me.overWrite.CheckState)
        End If

        'A-20120315_3↓
        Select Case Me.HacchuZanOverCheckPanel.Value
            Case ImportParam.残チェック区分型.エラー
                log &= logInfoHelper.MakeLog("発注残以上のデータ取込チェック", "エラー")
            Case ImportParam.残チェック区分型.警告
                log &= logInfoHelper.MakeLog("発注残以上のデータ取込チェック", "警告")
            Case Else
                log &= logInfoHelper.MakeLog("発注残以上のデータ取込チェック", "なし")
        End Select

        Select Case Me.KannoZumiCheckPanel.Value
            Case ImportParam.残チェック区分型.エラー
                log &= logInfoHelper.MakeLog("完納済みデータ取込チェック", "エラー")
            Case ImportParam.残チェック区分型.警告
                log &= logInfoHelper.MakeLog("完納済みデータ取込チェック", "警告")
            Case Else
                log &= logInfoHelper.MakeLog("完納済みデータ取込チェック", "なし")
        End Select
        'A-20120315_3↑

        Return log
    End Function

#End Region

#Region "■変換パターン関連■"

    Protected Overrides Function Get取込項目リスト() As List(Of CMN.LIB.ImportFileConvert.取込項目型)
        Dim result As New List(Of CMN.LIB.ImportFileConvert.取込項目型)
        Dim item As CMN.LIB.ImportFileConvert.取込項目型

        Dim adjustCount As Integer = 0 'A-20160324_1
        For i As Integer = 0 To 仕入データ型._項目数 - 1
            Dim 項目名 As String = ""
            Dim 項目タイプ As ImportFileConvertLib.属性型 = ImportFileConvertLib.属性型.文字
            Dim 項目桁数 As Integer = 0
            Dim 小数桁 As Integer = 0
            Dim 対象区分 As Boolean = False

            item = New CMN.LIB.ImportFileConvert.取込項目型
            'item.項目番号 = i + 1                  'D-20160324_1
            item.項目番号 = i + 1 - adjustCount     'A-20160324_1

            項目名 = Get置換後名称(CType(i, 仕入データ型).ToString)

            Select Case CType(i, 仕入データ型)
                Case 仕入データ型.伝票日付
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 8, 0, True)

                Case 仕入データ型.入荷番号
                    項目名 = "入荷№"  'A-20170601-X1-項目名統一
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 8, 0, True)

                Case 仕入データ型.受入番号
                    項目名 = "受入№"  'A-20170601-X1-項目名統一
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 8, 0, True)

                Case 仕入データ型.処理連番
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 10, 0, True)

                Case 仕入データ型.明細区分
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 1, 0, True)

                Case 仕入データ型.行番号
                    Call Set取込項目情報(item, "行", ImportFileConvertLib.属性型.数値, 2, 0, True)

                Case 仕入データ型.製番
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, 12, 0, True)

                Case 仕入データ型.仕入先コード
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, _myコントロール情報.得意先_仕入先_コード_桁数, 0, True)

                Case 仕入データ型.仕入先名１
                    'Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, 32, 0, True)
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, _myコントロール情報.名称桁数, 0, True)

                Case 仕入データ型.仕入先名２
                    'Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, 32, 0, True)
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, _myコントロール情報.名称桁数, 0, True)

                Case 仕入データ型.担当者コード
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, _myコントロール情報.担当者コード_桁数, 0, True)

                Case 仕入データ型.部門コード
                    対象区分 = (_myコントロール情報.部門管理 = オプション区分定義型.区分型.行う)
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, _myコントロール情報.部門コード_桁数, 0, 対象区分)

                Case 仕入データ型.営業所コード
                    対象区分 = (_myコントロール情報.営業所管理 = 機能区分定義型.営業所管理区分型.行う)
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, _myコントロール情報.営業所コード_桁数, 0, 対象区分)

                Case 仕入データ型.支払区分
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 1, 0, True)

                Case 仕入データ型.買掛区分
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 1, 0, True)

                Case 仕入データ型.取引区分
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 2, 0, True)

                Case 仕入データ型.取引区分属性
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 1, 0, True)

                Case 仕入データ型.倉庫コード
                    対象区分 = (_myコントロール情報.倉庫別在庫管理 = 機能区分定義型.倉庫別在庫管理型.行う)
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, 6, 0, 対象区分)

                Case 仕入データ型.ロケーション
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, 10, 0, True)

                Case 仕入データ型.ロット_Ｎｏ
                    対象区分 = (_myコントロール情報.MOA品質管理 = MOAオプション定義型.その他管理区分型.行う)
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, 20, 0, 対象区分)

                Case 仕入データ型.有効期限
                    対象区分 = (_myコントロール情報.MOA品質管理 = MOAオプション定義型.その他管理区分型.行う)
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 8, 0, 対象区分)

                Case 仕入データ型.商品コード
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, _myコントロール情報.商品コード_桁数, 0, True)

                Case 仕入データ型.商品名
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, 36, 0, True)

                Case 仕入データ型.品名１
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, 36, 0, True)

                Case 仕入データ型.品名２
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, 36, 0, True)

                Case 仕入データ型.品名３
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, 20, 0, True)

                Case 仕入データ型.工程コード
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, 6, 0, True)

                Case 仕入データ型.完成品区分
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 1, 0, True)

                Case 仕入データ型.入数
                    If _myコントロール情報.入数小数桁区分 = 機能区分定義型.入数小数桁区分型.数量小数以下桁に従う Then
                        小数桁 = _myコントロール情報.小数以下桁数.数量
                    Else
                        小数桁 = 0
                    End If
                    対象区分 = (_myコントロール情報.入数個数使用区分 = 仕入処理定義型.入数個数使用区分型.使用する)
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 6, 小数桁, 対象区分)

                Case 仕入データ型.個数
                    対象区分 = (_myコントロール情報.入数個数使用区分 = 仕入処理定義型.入数個数使用区分型.使用する)
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 6, 0, 対象区分)

                Case 仕入データ型.個数単位
                    対象区分 = (_myコントロール情報.入数個数使用区分 = 仕入処理定義型.入数個数使用区分型.使用する)
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, 4, 0, 対象区分)

                Case 仕入データ型.数量
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 8, _myコントロール情報.小数以下桁数.数量, True)

                Case 仕入データ型.数量単位
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, 4, 0, True)

                Case 仕入データ型.単価
                    If _myコントロール情報.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う Then          'A-20121217_Ver7.50_1
                        Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 9, 4, True)         'A-20121217_Ver7.50_1
                    Else                                                                                         'A-20121217_Ver7.50_1
                        Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 9, _myコントロール情報.小数以下桁数.仕入単価, True)
                    End If                                                                                       'A-20121217_Ver7.50_1

                Case 仕入データ型.金額
                    If _myコントロール情報.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う Then          'A-20121217_Ver7.50_1
                        'Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 9, 4, True)         'A-20121217_Ver7.50_1   'D-20170601-X1-桁数拡張
                        Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, _myコントロール情報.金額桁数, 4, True)       'A-20170601-X1-桁数拡張
                    Else                                                                                         'A-20121217_Ver7.50_1
                        'Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 9, 0, True)                                 'D-20170601-X1-桁数拡張
                        Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, _myコントロール情報.金額桁数, 0, True)       'A-20170601-X1-桁数拡張
                    End If                                                                                       'A-20121217_Ver7.50_1

                Case 仕入データ型.上代単価
                    対象区分 = (_myコントロール情報.上代使用区分 = 仕入処理定義型.上代使用区分型.使用する)
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 8, 0, 対象区分)

                Case 仕入データ型.単価掛率
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 3, 1, True)

                Case 仕入データ型.課税区分
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 1, 0, True)

                Case 仕入データ型.上代課税区分
                    対象区分 = (_myコントロール情報.上代使用区分 = 仕入処理定義型.上代使用区分型.使用する AndAlso
                                _myコントロール情報.消費税改正対応区分 = 機能区分定義型.消費税改正対応区分型.行う)
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 1, 0, 対象区分)

                Case 仕入データ型.消費税率
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 2, 2, True)

                Case 仕入データ型.内消費税等
                    'Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 9, 0, True)                             'D-20170601-X1-桁数拡張
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, _myコントロール情報.金額桁数, 0, True)   'A-20170601-X1-桁数拡張

                Case 仕入データ型.明細消費税等
                    対象区分 = (_myコントロール情報.明細単位処理_消費税計算 = 機能区分定義型.消費税計算型.行う)
                    'Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 9, 0, 対象区分)                             'D-20170601-X1-桁数拡張
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, _myコントロール情報.金額桁数, 0, 対象区分)   'A-20170601-X1-桁数拡張

                Case 仕入データ型.不良数量
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 8, _myコントロール情報.小数以下桁数.数量, True)

                Case 仕入データ型.完納区分
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 1, 0, True)

                Case 仕入データ型.行摘要コード
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, 5, 0, True)

                Case 仕入データ型.行摘要１
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, 12, 0, True)

                Case 仕入データ型.行摘要２
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, 12, 0, True)

                Case 仕入データ型.備考コード
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, 5, 0, True)

                Case 仕入データ型.備考
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, 36, 0, True)

                Case 仕入データ型.発注区分
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 1, 0, True)

                Case 仕入データ型.発注番号
                    項目名 = "発注№" 'A-20170601-X1-項目名統一
                    対象区分 = (_myコントロール情報.受発注管理 = オプション区分定義型.区分型.行う)
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 10, 0, 対象区分)

                    'Case 仕入データ型.発注行番号
                    '    対象区分 = (_myコントロール情報.受発注管理 = オプション区分定義型.区分型.行う)
                    '    Call Set取込項目情報(item, "発注行", ImportFileConvertLib.属性型.数値, 2, 0, 対象区分)

                Case 仕入データ型.自動生成区分
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 1, 0, True)

                Case 仕入データ型.消費税仮計上区分
                    対象区分 = (_myコントロール情報.仮計上消費税使用区分 = 消費税定義型.仮計上消費税使用区分型.行う)
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 1, 0, 対象区分)

                Case 仕入データ型.伝票消費税計算区分
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 1, 0, True)

                Case 仕入データ型.明細消費税計算区分
                    対象区分 = (_myコントロール情報.明細単位処理_消費税計算 = 機能区分定義型.消費税計算型.行う)
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 1, 0, 対象区分)

                Case 仕入データ型.データ発生区分
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 2, 0, True)

                    'Case 仕入データ型.相手処理連番
                    '    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 10, 0, True)

                Case 仕入データ型.拡張項目入力パターン番号
                    対象区分 = (_myコントロール情報.拡張項目 = オプション区分定義型.区分型.行う AndAlso
                                _myコントロール情報.拡張項目入力処理画面表示 = 拡張項目設計型.利用区分型.行う)
                    Call Set取込項目情報(item, "入力ﾊﾟﾀｰﾝ№", ImportFileConvertLib.属性型.文字, 4, 0, 対象区分)

                Case 仕入データ型.伝票拡張項目０１ To 仕入データ型.伝票拡張項目２０
                    If _myコントロール情報.拡張項目_仕入伝票 = True Then
                        Call Get拡張項目情報(CType(i, 仕入データ型), 項目名, 項目タイプ, 項目桁数, 小数桁, 対象区分)
                    Else
                        対象区分 = False
                    End If
                    Call Set取込項目情報(item, 項目名, 項目タイプ, 項目桁数, 小数桁, 対象区分)

                Case 仕入データ型.伝票拡張項目付箋色番号
                    If _myコントロール情報.拡張項目_仕入伝票 = True Then
                        If _myコントロール情報.仕入検収基準 = MOA機能追加定義型.その他管理区分型.行う Then
                            対象区分 = (_拡張項目情報_入荷伝票.付箋情報.使用区分 = SEI.LIB.ExpandItemControl.付箋情報型.使用区分型.使用する)
                        Else
                            対象区分 = (_拡張項目情報_仕入伝票.付箋情報.使用区分 = SEI.LIB.ExpandItemControl.付箋情報型.使用区分型.使用する)
                        End If
                    Else
                        対象区分 = False
                    End If
                    Call Set取込項目情報(item, "伝票付箋色", ImportFileConvertLib.属性型.数値, 1, 0, 対象区分)

                Case 仕入データ型.明細拡張項目０１ To 仕入データ型.明細拡張項目２０
                    If _myコントロール情報.拡張項目_仕入明細 = True Then
                        Call Get拡張項目情報(CType(i, 仕入データ型), 項目名, 項目タイプ, 項目桁数, 小数桁, 対象区分)
                    Else
                        対象区分 = False
                    End If
                    Call Set取込項目情報(item, 項目名, 項目タイプ, 項目桁数, 小数桁, 対象区分)

                Case 仕入データ型.明細拡張項目付箋色番号
                    If _myコントロール情報.拡張項目_仕入明細 = True Then
                        If _myコントロール情報.仕入検収基準 = MOA機能追加定義型.その他管理区分型.行う Then
                            対象区分 = (_拡張項目情報_入荷明細.付箋情報.使用区分 = SEI.LIB.ExpandItemControl.付箋情報型.使用区分型.使用する)
                        Else
                            対象区分 = (_拡張項目情報_仕入明細.付箋情報.使用区分 = SEI.LIB.ExpandItemControl.付箋情報型.使用区分型.使用する)
                        End If
                    Else
                        対象区分 = False
                    End If
                    Call Set取込項目情報(item, "明細付箋色", ImportFileConvertLib.属性型.数値, 1, 0, 対象区分)

                Case 仕入データ型.計上区分
                    対象区分 = (_myコントロール情報.仕入検収基準 = MOA機能追加定義型.その他管理区分型.行う)
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 1, 0, 対象区分)

                Case 仕入データ型.仮単価区分
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 1, 0, True)

                Case 仕入データ型.費目コード
                    対象区分 = (_myコントロール情報.MOA原価管理 = MOAオプション定義型.その他管理区分型.行う)
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, 6, 0, 対象区分)

                Case 仕入データ型.構成品出庫生成区分
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 1, 0, True)

                Case 仕入データ型.出庫日
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 8, 0, True)

                Case 仕入データ型.構成品_行
                    Call Set取込項目情報(item, "行", ImportFileConvertLib.属性型.数値, 3, 0, True)

                Case 仕入データ型.構成品_展開順序番号
                    項目名 = "展開順序№"    'A-20170601-X1-項目名統一
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 5, 0, True)

                Case 仕入データ型.構成品_取引区分
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 1, 0, True)

                Case 仕入データ型.構成品_倉庫コード
                    対象区分 = (_myコントロール情報.倉庫別在庫管理 = 機能区分定義型.倉庫別在庫管理型.行う)
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, 6, 0, 対象区分)

                Case 仕入データ型.構成品_ロケーション
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, 10, 0, True)

                Case 仕入データ型.構成品_商品コード
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, _myコントロール情報.商品コード_桁数, 0, True)

                Case 仕入データ型.構成品_商品名
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, 36, 0, True)

                Case 仕入データ型.構成品_品名１
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, 36, 0, True)

                Case 仕入データ型.構成品_品名２
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, 36, 0, True)

                Case 仕入データ型.構成品_品名３
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, 20, 0, True)

                Case 仕入データ型.構成品_出庫数量
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 8, _myコントロール情報.小数以下桁数.数量, True)

                Case 仕入データ型.構成品_出庫単位
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, 4, 0, True)

                Case 仕入データ型.構成品_行摘要コード
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, 5, 0, True)

                Case 仕入データ型.構成品_行摘要１
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, 12, 0, True)

                Case 仕入データ型.構成品_行摘要２
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, 12, 0, True)

                Case 仕入データ型.内訳_ロット_Ｎｏ
                    対象区分 = (_myコントロール情報.MOA品質管理 = MOAオプション定義型.その他管理区分型.行う)
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, 20, 0, 対象区分)

                Case 仕入データ型.内訳_ロット別数量
                    '対象区分 = (_myコントロール情報.MOA品質管理 = MOAオプション定義型.その他管理区分型.行う)   'D-20121217_Ver7.50_3
                    'A-20121217_Ver7.50_3↓
                    If _myコントロール情報.MOA品質管理 = MOAオプション定義型.その他管理区分型.行う Then
                        対象区分 = True
                    Else
                        If _myコントロール情報.MOA強化区分 >= 4D AndAlso
                           _myコントロール情報.ロケーション単位数量指定列 = MOA機能追加定義型.ロケーション単位数量指定列.数量列_ロケ＿ロット別 Then    'X1変換Tool-20170508
                            対象区分 = True
                        End If
                    End If
                    'A-20121217_Ver7.50_3↑
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 8, _myコントロール情報.小数以下桁数.数量, 対象区分)

                    'A-20120315_1↓
                Case 仕入データ型.構成品_完納区分
                    If _myコントロール情報.MOA強化区分 >= 3.2D Then
                        対象区分 = True
                    Else
                        対象区分 = False
                    End If
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 1, 0, 対象区分)
                    'A-20120315_1↑

                    'A-20121217_Ver7.50_1↓
                Case 仕入データ型.レート
                    対象区分 = (_myコントロール情報.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う)
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 5, 4, 対象区分)

                Case 仕入データ型.レート種類
                    対象区分 = (_myコントロール情報.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う)
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 1, 0, 対象区分)

                Case 仕入データ型.換算基準
                    対象区分 = (_myコントロール情報.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う)
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 1, 0, 対象区分)

                Case 仕入データ型.諸掛管理_Ｎｏ
                    対象区分 = (_myコントロール情報.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う)
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, 20, 0, 対象区分)

                Case 仕入データ型.按分対象
                    対象区分 = (_myコントロール情報.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う)
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 1, 0, 対象区分)

                Case 仕入データ型.按分基準
                    対象区分 = (_myコントロール情報.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う)
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 1, 0, 対象区分)

                Case 仕入データ型.INVOICE_Ｎｏ
                    対象区分 = (_myコントロール情報.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う)
                    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, 20, 0, 対象区分)
                    'A-20121217_Ver7.50_1↑

                    'A-20160324_1↓
                Case 仕入データ型.レート固定区分
                    対象区分 = (_myコントロール情報.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う AndAlso _myコントロール情報.外貨複数伝票消込機能 = MOA外貨定義型.制御区分型.行う)
                    '途中追加した項目のため、強化区分8未満では対象項目としない
                    If _myコントロール情報.MOA強化区分 >= 8D Then
                        Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 1, 0, 対象区分)
                    Else
                        '取込対象外の場合、取込項目として追加しない
                        adjustCount += 1
                        Continue For
                    End If
                    'A-20160324_1↓
                    'A-20160324_2↑
                Case 仕入データ型.原価計上手配番号
                    項目名 = "原価計上手配№"  'A-20170601-X1-項目名統一
                    If _myコントロール情報.MOA強化区分 >= 8D AndAlso
                       _myコントロール情報.MOA原価管理 = オプション区分定義型.区分型.行う AndAlso
                       _myコントロール情報.品目別原価計算機能 = MOA機能追加定義型.使用有無区分型.使用する Then
                        対象区分 = True
                    Else
                        対象区分 = False
                    End If
                    '途中追加した項目のため、強化区分8未満では対象項目としない
                    If _myコントロール情報.MOA強化区分 >= 8D Then
                        Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 10, 0, 対象区分)
                    Else
                        '取込対象外の場合、取込項目として追加しない
                        adjustCount += 1
                        Continue For
                    End If
                    'A-20160324_2↑

                    '    '↓A-2008/07/18_Ver7.30_GENKA
                    'Case 仕入データ型.原価集計メインコード
                    '    対象区分 = (_myコントロール情報.原価管理 = オプション区分定義型.区分型.行う)
                    '    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, _myコントロール情報.原価集計コード_桁数, 0, 対象区分)

                    'Case 仕入データ型.原価集計サブコード
                    '    対象区分 = (_myコントロール情報.原価管理 = オプション区分定義型.区分型.行う)
                    '    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, 2, 0, 対象区分)

                    'Case 仕入データ型.要素コード
                    '    対象区分 = (_myコントロール情報.原価管理 = オプション区分定義型.区分型.行う)
                    '    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, _myコントロール情報.分類コード_桁数, 0, 対象区分)
                    '    '↑A-2008/07/18_Ver7.30_GENKA

                    '    '↓A-2009/12/18_Ver7.40_UCHIWAKE
                    'Case 仕入データ型.内訳コード１, _
                    '     仕入データ型.内訳コード２, _
                    '     仕入データ型.内訳コード３
                    '    Dim 内訳種別 As 内訳種別型
                    '    Select Case CType(i, 仕入データ型)
                    '        Case 仕入データ型.内訳コード１ : 内訳種別 = 内訳種別型.内訳種別１
                    '        Case 仕入データ型.内訳コード２ : 内訳種別 = 内訳種別型.内訳種別２
                    '        Case 仕入データ型.内訳コード３ : 内訳種別 = 内訳種別型.内訳種別３
                    '    End Select
                    '    対象区分 = Is内訳コード使用可否判定(内訳種別)
                    '    項目名 = _myコントロール情報.内訳名称(内訳種別)
                    '    If _myコントロール情報.内訳タイプ = 商品管理拡張定義型.内訳タイプ型.マスター Then
                    '        '内訳タイプ：マスター
                    '        項目名 &= "コード"
                    '        Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, _myコントロール情報.内訳コード桁数(内訳種別), 0, 対象区分)
                    '    Else
                    '        '内訳タイプ：数値
                    '        Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 5, _myコントロール情報.内訳数値小数桁数(内訳種別), 対象区分)
                    '    End If

                    'Case 仕入データ型.換算数量
                    '    対象区分 = _myコントロール情報.換算数量使用区分
                    '    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 8, _myコントロール情報.小数以下桁数.換算数量, 対象区分)

                    'Case 仕入データ型.金額算出モード
                    '    対象区分 = _myコントロール情報.換算数量使用区分
                    '    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 1, 0, 対象区分)
                    '    '↑A-2009/12/18_Ver7.40_UCHIWAKE

                    '    '↓A-2009/12/18_Ver7.40_LOT
                    'Case 仕入データ型.ロットNo
                    '    対象区分 = _myコントロール情報.ロット管理
                    '    If _myコントロール情報.ロットNo採番方法 = ロット管理定義型.ロットNo採番方法型.手入力 Then
                    '        Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, _myコントロール情報.手入力ロットNo桁数, 0, 対象区分)
                    '    Else
                    '        Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 20, 0, 対象区分)
                    '    End If

                    'Case 仕入データ型.サブロットNo
                    '    対象区分 = _myコントロール情報.ロット管理
                    '    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.文字, 20, 0, 対象区分)

                    'Case 仕入データ型.有効期限
                    '    対象区分 = _myコントロール情報.有効期限機能
                    '    Call Set取込項目情報(item, 項目名, ImportFileConvertLib.属性型.数値, 8, 0, 対象区分)
                    '    '↑A-2009/12/18_Ver7.40_LOT

            End Select

            result.Add(item)
        Next

        Return result
    End Function

    Private Function Get置換後名称(ByVal value As String) As String
        Dim result As String = value
        result = TextFileImportLib.MyReplace(result, "営業所", _my項目名称.販売営業所)
        result = TextFileImportLib.MyReplace(result, "仕入先", _my項目名称.販売仕入先)
        result = TextFileImportLib.MyReplace(result, "担当者", _my項目名称.販売仕入担当者_項目)
        result = TextFileImportLib.MyReplace(result, "部門", _my項目名称.販売部門)
        result = TextFileImportLib.MyReplace(result, "倉庫", _my項目名称.販売倉庫)
        result = TextFileImportLib.MyReplace(result, "商品", _my項目名称.販売商品)
        result = TextFileImportLib.MyReplace(result, "原価集計メイン", _my項目名称.販売原価集計 & _my項目名称.販売原価集計メイン)   'A-2008/07/18_Ver7.30_GENKA
        result = TextFileImportLib.MyReplace(result, "原価集計サブ", _my項目名称.販売原価集計 & _my項目名称.販売原価集計サブ)       'A-2008/07/18_Ver7.30_GENKA
        result = TextFileImportLib.MyReplace(result, "要素", Get要素タイトル)                                                       'A-2008/07/18_Ver7.30_GENKA

        result = TextFileImportLib.MyReplace(result, "品名１", _my項目名称.販売品目名１)
        result = TextFileImportLib.MyReplace(result, "品名２", _my項目名称.販売品目名２)
        result = TextFileImportLib.MyReplace(result, "品名３", _my項目名称.販売品目名３)
        result = TextFileImportLib.MyReplace(result, "客先注番", _my項目名称.販売客先注番)
        result = TextFileImportLib.MyReplace(result, "有効期限", _my項目名称.販売有効期限)

        result = TextFileImportLib.MyReplace(result, "構成品_", "")
        result = TextFileImportLib.MyReplace(result, "内訳_", "")
        result = TextFileImportLib.MyReplace(result, "_Ｎｏ", "№")

        ''↓A-2009/12/18_Ver7.40_UCHIWAKE
        'Select Case value
        '    Case 仕入データ型.換算数量.ToString
        '        result = TextFileImportLib.MyReplace(result, "換算数量", _my項目名称.販売換算数量)

        '    Case 仕入データ型.ロットNo.ToString                                                             'A-2009/12/18_Ver7.40_LOT
        '        result = TextFileImportLib.MyReplace(result, "ロットNo", _my項目名称.販売ロットNo)          'A-2009/12/18_Ver7.40_LOT

        '    Case 仕入データ型.サブロットNo.ToString                                                         'A-2009/12/18_Ver7.40_LOT
        '        result = TextFileImportLib.MyReplace(result, "サブロットNo", _my項目名称.販売サブロットNo)  'A-2009/12/18_Ver7.40_LOT

        'End Select
        ''↑A-2009/12/18_Ver7.40_UCHIWAKE
        Return result
    End Function

    Private Sub Get拡張項目情報(ByVal itemNo As 仕入データ型,
                                ByRef 項目名 As String,
                                ByRef 項目タイプ As ImportFileConvertLib.属性型,
                                ByRef 項目桁数 As Integer,
                                ByRef 小数桁 As Integer,
                                ByRef 対象区分 As Boolean)

        Dim 拡張項目情報 As SEI.LIB.ExpandItemControl.I拡張項目定義型
        Dim expandItemNo As Integer

        Select Case itemNo
            Case 仕入データ型.伝票拡張項目０１ To 仕入データ型.伝票拡張項目２０
                If _myコントロール情報.仕入検収基準 = MOA機能追加定義型.その他管理区分型.行う Then
                    拡張項目情報 = _拡張項目情報_入荷伝票
                Else
                    拡張項目情報 = _拡張項目情報_仕入伝票
                End If
                expandItemNo = itemNo - 仕入データ型.伝票拡張項目０１ + 1

            Case 仕入データ型.明細拡張項目０１ To 仕入データ型.明細拡張項目２０
                If _myコントロール情報.仕入検収基準 = MOA機能追加定義型.その他管理区分型.行う Then
                    拡張項目情報 = _拡張項目情報_入荷明細
                Else
                    拡張項目情報 = _拡張項目情報_仕入明細
                End If
                expandItemNo = itemNo - 仕入データ型.明細拡張項目０１ + 1

            Case Else
                対象区分 = False
                Exit Sub
        End Select

        項目名 = 拡張項目情報.項目情報.項目(expandItemNo).項目名

        Select Case 拡張項目情報.項目情報.項目(expandItemNo).属性
            Case SEI.LIB.ExpandItemControl.項目属性型.拡張項目属性型.全角文字,
                 SEI.LIB.ExpandItemControl.項目属性型.拡張項目属性型.半角文字,
                 SEI.LIB.ExpandItemControl.項目属性型.拡張項目属性型.数字コード,
                 SEI.LIB.ExpandItemControl.項目属性型.拡張項目属性型.文字コード

                項目タイプ = ImportFileConvertLib.属性型.文字

            Case SEI.LIB.ExpandItemControl.項目属性型.拡張項目属性型.数値,
                 SEI.LIB.ExpandItemControl.項目属性型.拡張項目属性型.日付_年月日,
                 SEI.LIB.ExpandItemControl.項目属性型.拡張項目属性型.日付_年月,
                 SEI.LIB.ExpandItemControl.項目属性型.拡張項目属性型.日付_年

                項目タイプ = ImportFileConvertLib.属性型.数値

        End Select

        Select Case 拡張項目情報.項目情報.項目(expandItemNo).属性
            Case SEI.LIB.ExpandItemControl.項目属性型.拡張項目属性型.日付_年月日
                項目桁数 = 8
            Case SEI.LIB.ExpandItemControl.項目属性型.拡張項目属性型.日付_年月
                項目桁数 = 6
            Case SEI.LIB.ExpandItemControl.項目属性型.拡張項目属性型.日付_年
                項目桁数 = 4
            Case Else
                項目桁数 = 拡張項目情報.項目情報.項目(expandItemNo).桁
        End Select

        小数桁 = 拡張項目情報.項目情報.項目(expandItemNo).小数桁

        対象区分 = (拡張項目情報.項目情報.項目(expandItemNo).属性 <> [LIB].ExpandItemControl.項目属性型.拡張項目属性型.未使用)

    End Sub

    Private Sub Set取込項目情報(ByRef item As CMN.LIB.ImportFileConvert.取込項目型,
                                ByVal 項目名 As String,
                                ByVal 項目タイプ As CMN.LIB.ImportFileConvert.ImportFileConvertLib.属性型,
                                ByVal 項目桁数 As Integer,
                                ByVal 小数部桁数 As Integer,
                                ByVal 対象区分 As Boolean)

        With item
            .項目名 = 項目名
            .項目タイプ = 項目タイプ
            .項目桁数 = 項目桁数
            .小数部桁数 = 小数部桁数
            .対象区分 = 対象区分
        End With

    End Sub

#End Region

#Region "内部メソッド"      'A-2008/07/18_Ver7.30_GENKA

    Private Function Get要素タイトル() As String    'A-2008/07/18_Ver7.30_GENKA
        Dim 要素タイトル As String = _myコントロール情報.要素タイトル
        If 要素タイトル.TrimEnd = "" Then
            要素タイトル = _my項目名称.販売商品 & "分類" & StrConv(CStr(_myコントロール情報.要素使用分類種別), VbStrConv.Wide)
        End If

        Return 要素タイトル
    End Function

#End Region

#Region "商品内訳管理"  'A-2009/12/18_Ver7.40_UCHIWAKE

    Private Function Is内訳コード使用可否判定(ByVal 内訳種別 As 内訳種別型) As Boolean  'A-2009/12/18_Ver7.40_UCHIWAKE

        If _myコントロール情報.商品内訳管理 = False Then
            Return False
        End If

        If _myコントロール情報.内訳管理数 < 内訳種別 Then
            Return False
        End If

        Return True
    End Function

#End Region

#Region "ロット"    'A-2009/12/18_Ver7.40_LOT

    Private Function Is画面条件有効判定_ロットNo採番() As Boolean   'A-2009/12/18_Ver7.40_LOT

        If _myコントロール情報.ロット管理 = False Then
            Return False
        End If

        If _myコントロール情報.ロットNo採番方法 <> ロット管理定義型.ロットNo採番方法型.連番 Then
            Return False
        End If

        Return True
    End Function

#End Region

    'A-CUST20190830↓
#Region "カスタマイズ追加"

    ''' <summary>
    ''' テキストファイルの使用可能チェック
    ''' </summary>
    ''' <remarks></remarks>
    Protected Overrides Function CheckTextFileUse() As Boolean

        MyBase.CheckTextFileUse()

        Dim filePath As String = ""

        'FW
        filePath = TextFileImportLib.EditFolder(folderInput.TextValue.Trim) & fileInput.TextValue.Trim

        '************************
        '* ファイルソート
        '************************
        Dim ret As Boolean

        'ソートしたファイルでの差替えを行うため一時的にロックを解除
        Call ReleaseLockFile()

        'ファイルソートを行う
        ret = SortImportText(folderInput.TextValue, filePath, fileInput.TextValue.Trim)

        'ファイルソートに失敗した場合は終了する。
        If ret = False Then Return False

        _fileLockReader = New OSK.X1.Foundation.TextFileImport.TextFileReader
        Try
            With _fileLockReader
                .FileOpen(filePath, IKanriTableData.文字コード型.自動判別, True)
            End With

        Catch ex As IO.IOException
            _fileLockReader = Nothing
            MessageViewer.Show(Myメッセージ.CMN0027_ファイルが使用中_またはライトプロテクトされています)
            fileInput.Focus()
            Return False

        End Try

        'ロックを継続しない場合、直ぐにクローズ
        If IsTextFileLock() = False Then
            Call ReleaseLockFile()
        End If

        _変換テキスト名 = ""
        Dim OutputTXT As TextExp = New TextExp
        filePath = TextFileImportLib.EditFolder(folderInput.TextValue.Trim) & _変換テキスト名

        '出力テキストファイルが存在していたら削除する。
        If OutputTXT.FileExistsCheck(filePath) = True Then
            OutputTXT.DeleteFile(filePath)
        End If

        '取込テキストファイルから1つのテキストファイルを作成
        _変換テキスト名 = Format$(Now, "yyyyMMddHHmmss") & ".txt"
        Dim 開始位置 As Integer = 0
        If topRowTitleCheck.CheckState = CheckState.Checked Then
            開始位置 = 1
        End If
        MakeImportText(folderInput.TextValue, filePath, fileInput.TextValue.Trim, 開始位置)

        Return True
    End Function

#Region "テキストファイルソート"
    Private Function SortImportText(ByVal folderpath As String, ByVal FullPath As String, ByVal textFileName As String) As Boolean

        Dim sStep As String = "Step1：ソート開始"
        Dim sr As IO.StreamReader = Nothing
        Dim bOpenFlg As Boolean = False

        '以下でをキーにテキストファイルのソート及び集計を行う。
        '   Ａ．発注、入出庫予定(入庫)
        '　　・データ区分、連番、行№、内訳№、商品コード、ロット№
        '   Ｂ.完成品受入
        '　　・データ区分、連番、行№、内訳№、商品コード、ロット№、内職者

        Try
            'ソート対象のテーブル作成
            sStep = "Step2：ソート対象のテーブル作成"
            Dim dtbl As New DataTable()

            Dim col(9) As DataColumn
            '   Ａ．発注、入出庫予定(入庫)
            '　　・データ区分、連番、行№、内訳№、商品コード、数量、ロット№、(ダミー)=0、CSVデータイメージ
            '   Ｂ.完成品受入()
            '　　・データ区分、連番、行№、内訳№、商品コード、数量、ロット№、内職者、CSVデータイメージ
            col(0) = New DataColumn("DataKbn", Type.GetType("System.Decimal"))
            col(1) = New DataColumn("Renban", Type.GetType("System.Decimal"))
            col(2) = New DataColumn("Line", Type.GetType("System.Decimal"))
            col(3) = New DataColumn("UchNo", Type.GetType("System.Decimal"))
            col(4) = New DataColumn("SyohinCode", Type.GetType("System.String"))
            col(5) = New DataColumn("SuRyou", Type.GetType("System.String"))        '数量だがソート用Datatable上は文字扱いとする。
            col(6) = New DataColumn("LotNo", Type.GetType("System.String"))
            col(7) = New DataColumn("Location", Type.GetType("System.String"))
            col(8) = New DataColumn("Naishoku", Type.GetType("System.String"))
            col(9) = New DataColumn("Value", Type.GetType("System.String"))
            dtbl.Columns.AddRange(col)

            'ファイルパスの設定
            Dim csvPath As String = FullPath
            Dim outPath As String = folderpath & "\【ソート済み】" & textFileName
            Dim tmpPath As String = folderpath & "\【元】" & textFileName

            'CSVファイルの読込
            sStep = "Step3：CSVファイルの読込"
            sr = New IO.StreamReader(csvPath, System.Text.Encoding.GetEncoding("shift_jis"))
            bOpenFlg = True 'オープンフラグオン
            Dim GetData1 As List(Of String) = New List(Of String)
            GetData1 = Text_SetList(sr)

            'CSVファイルの読込クローズ
            sStep = "Step4：CSVファイルのクローズ"
            sr.Close()
            bOpenFlg = False 'オープンフラグオフ

            '一行しか無い場合は処理をソート処理をスキップする
            If GetData1.Count < 1 Then
                Exit Function
            End If

            '一行目はタイトル判定
            sStep = "Step5：タイトル判定"
            Dim Start As Integer = 0
            Dim TitleText As String = ""
            If Me.topRowTitleCheck.CheckState = CheckState.Checked Then
                Start = 1
                TitleText = GetData1(0)
            End If

            sStep = "Step6：ソートデータ格納開始"
            Dim textData As String()
            Dim 区切 As String = vbTab
            For i As Integer = Start To GetData1.Count - 1
                sStep = "Step7：ソートキー取得(" & i & "行目)"
                textData = Split(GetData1(i), 区切)

                'レコードに項目値が存在していない場合、そのテキストをスキップする。
                If UBound(textData) <= 0 Then
                    Continue For
                End If

                Dim row As DataRow = dtbl.NewRow()

                If UBound(textData) >= 0 Then
                    row("DataKbn") = cnvDecimal(textData(0))
                Else
                    row("DataKbn") = 0
                End If
                If UBound(textData) >= 1 Then
                    row("Renban") = cnvDecimal(textData(1))
                Else
                    row("Renban") = 0
                End If
                If UBound(textData) >= 2 Then
                    row("line") = cnvDecimal(textData(2))
                Else
                    row("line") = 0
                End If
                If UBound(textData) >= 3 Then
                    row("UchNo") = cnvDecimal(textData(3))
                Else
                    row("UchNo") = 0
                End If
                If UBound(textData) >= 4 Then
                    row("SyohinCode") = textData(4)
                Else
                    row("SyohinCode") = 0
                End If
                If UBound(textData) >= 5 Then
                    row("SuRyou") = textData(5)
                Else
                    row("SuRyou") = "0"
                End If
                If UBound(textData) >= 6 Then
                    row("LotNo") = textData(6)
                Else
                    row("LotNo") = ""
                End If
                If UBound(textData) >= 7 Then
                    row("Location") = textData(7)
                Else
                    row("Location") = ""
                End If
                If UBound(textData) >= 8 Then
                    row("Naishoku") = textData(8)
                Else
                    row("Naishoku") = ""
                End If


                sStep = "Step8：元テキスト情報取得(" & i & "行目)"
                row("Value") = GetData1(i)

                sStep = "Step9：ソート情報格納(" & i & "行目)"
                dtbl.Rows.Add(row)

            Next

            'ソート前確認
            For Each row As DataRow In dtbl.Rows
                Console.WriteLine("DataKbn:" & row("DataKbn").ToString & "  Renban:" & row("Renban").ToString & "  line:" & row("line").ToString & "  Value:" & row("Value").ToString)
            Next
            Console.WriteLine("")

            'DataTable.Select()を使いソート(第二引数にソート条件を書く)
            sStep = "Step10：ソート実行"
            'ソートキー：データ区分、連番、行№、内訳№、商品コード、ロット№、内職者 ※Ａ．Ｂ.いずれも同じキー
            Dim rows As DataRow() = dtbl.Select(Nothing, "DataKbn ASC , Renban ASC , line ASC , UchNo ASC , SyohinCode ASC , LotNo ASC , Location ASC , Naishoku ASC ")

            'ソート後の DataTable を用意
            sStep = "Step11：ソート後情報退避　準備"
            Dim dtblSrt As New DataTable()
            'ソート前テーブルの情報をクローン
            dtblSrt = dtbl.Clone()

            'ソートされてる DataRow 配列をソート後の DataTable に追加
            sStep = "Step12：ソート後情報退避　実行"
            For Each row As DataRow In rows
                dtblSrt.ImportRow(row)
            Next

            'ソート後確認
            For Each row As DataRow In dtblSrt.Rows
                Console.WriteLine("DataKbn:" & row("DataKbn").ToString & "  Renban:" & row("Renban").ToString & "  line:" & row("line").ToString & "  Value:" & row("Value").ToString)
            Next

            '集計後の DataTable を用意
            sStep = "Step12-1：集計後情報　準備"

            '数量OK分配列
            Dim dtblSumOK As New DataTable()
            Dim colsum(9) As DataColumn
            colsum(0) = New DataColumn("DataKbn", Type.GetType("System.Decimal"))
            colsum(1) = New DataColumn("Renban", Type.GetType("System.Decimal"))
            colsum(2) = New DataColumn("Line", Type.GetType("System.Decimal"))
            colsum(3) = New DataColumn("UchNo", Type.GetType("System.Decimal"))
            colsum(4) = New DataColumn("SyohinCode", Type.GetType("System.String"))
            colsum(5) = New DataColumn("SuRyou", Type.GetType("System.Decimal"))        'ここの数量はDecimal
            colsum(6) = New DataColumn("LotNo", Type.GetType("System.String"))
            colsum(7) = New DataColumn("Location", Type.GetType("System.String"))
            colsum(8) = New DataColumn("Naishoku", Type.GetType("System.String"))
            colsum(9) = New DataColumn("Value", Type.GetType("System.String"))
            dtblSumOK.Columns.AddRange(colsum)

            '結果出力テーブル
            Dim dtblResult As New DataTable()
            dtblResult = dtbl.Clone()

            For Each row As DataRow In rows

                '数量チェック
                If IsNumeric(row("SuRyou").ToString) Then
                    '数量OK分は集計用Datatableへ追加
                    dtblSumOK.ImportRow(row)
                Else
                    '数量NG分は結果出力用Datatableへ追加
                    dtblResult.ImportRow(row)
                End If
            Next

            Dim viw As New DataView(dtblSumOK)
            Dim isDistinct As Boolean = True
            Dim cols() As String = {"DataKbn", "Renban", "line", "UchNo", "SyohinCode", "LotNo", "Location", "Naishoku"}
            Dim dtFilter As DataTable = viw.ToTable(isDistinct, cols)
            dtFilter.Columns.Add("Expr", GetType(Decimal))
            For Each row As DataRow In dtFilter.Rows
                Dim expr As String = String.Format("DataKbn = '{0}' AND Renban = '{1}' AND line = '{2}' AND UchNo = '{3}' AND SyohinCode = '{4}' AND  LotNo = '{5}' AND Location = '{6}' AND Naishoku = '{7}' ",
                                                   row("DataKbn"), row("Renban"), row("line"), row("UchNo"), row("SyohinCode"), row("LotNo"), row("Location"), row("Naishoku"))
                row("Expr") = dtblSumOK.Compute("SUM(SuRyou)", expr)
            Next

            Dim AddWork As String = ""
            For Each row As DataRow In dtFilter.Rows

                Dim newrow As DataRow = dtblResult.NewRow()
                newrow("DataKbn") = row("DataKbn").ToString
                newrow("Renban") = row("Renban").ToString
                newrow("line") = row("line").ToString
                newrow("UchNo") = row("UchNo").ToString
                newrow("SyohinCode") = row("SyohinCode").ToString
                newrow("SuRyou") = row("Expr").ToString
                newrow("LotNo") = row("LotNo").ToString
                newrow("Location") = row("Location").ToString
                newrow("Naishoku") = row("Naishoku").ToString

                AddWork = ""
                AddWork = AddWork & newrow("DataKbn").ToString & vbTab
                AddWork = AddWork & newrow("Renban").ToString & vbTab
                AddWork = AddWork & newrow("line").ToString & vbTab
                AddWork = AddWork & newrow("UchNo").ToString & vbTab
                AddWork = AddWork & newrow("SyohinCode").ToString & vbTab
                AddWork = AddWork & newrow("SuRyou").ToString & vbTab
                AddWork = AddWork & newrow("LotNo").ToString & vbTab
                AddWork = AddWork & newrow("Location").ToString & vbTab
                AddWork = AddWork & newrow("Naishoku").ToString
                newrow("Value") = AddWork

                dtblResult.Rows.Add(newrow)

            Next


            '出力ファイルに転写する
            sStep = "Step13：ソート後情報ファイル書き込み　準備"
            Dim writer As New IO.StreamWriter(outPath, False, System.Text.Encoding.GetEncoding("shift_jis"))
            If Me.topRowTitleCheck.CheckState = CheckState.Checked Then
                writer.WriteLine(TitleText)
            End If
            Dim cnt As Integer = 0
            For Each row As DataRow In dtblResult.Rows
                cnt = cnt + 1
                sStep = "Step14：ソート後情報ファイル書き込み(" & cnt & "行目)"
                writer.WriteLine(row("Value").ToString)
            Next
            writer.Close()

            '元ファイルを退避ファイル名にリネーム
            sStep = "Step15：元ファイルを退避ファイル名にリネーム"
            System.IO.File.Move(csvPath, tmpPath)

            'ソート後ファイルを元ファイルにリネーム
            sStep = "Step16：ソート後ファイルを元ファイルにリネーム"
            System.IO.File.Move(outPath, csvPath)

            '退避ファイル名を削除
            sStep = "Step17：退避ファイル名を削除"
            System.IO.File.Delete(tmpPath)

        Catch ex As Exception

            MessageViewer.Show(1028, "OTS", IMessageViewer.DefaultButtonType.OK, "", vbCrLf & vbCrLf & "エラー箇所 " & sStep & vbCrLf & ex.Message)
            Return False
        Finally
            If bOpenFlg = True Then 'オープンフラグオン
                sr.Close()
            End If
        End Try

        Return True

    End Function

    Private Function cnvDecimal(ByVal Value As String) As Decimal

        cnvDecimal = 0

        If IsNumeric(Value) Then
            cnvDecimal = CDec(Value)
        End If

    End Function

#Region "テキストＲｅａｄ"

    Public Function Text_ReadLine(ByVal sr As IO.StreamReader) As String

        Return sr.ReadLine()

    End Function

    Public Function Text_SetList(ByVal sr As IO.StreamReader) As List(Of String)
        '読み込んだテキストの内容をリストに溜め込む

        Dim textData As String = ""
        Dim Getdata As List(Of String) = New List(Of String)
        Dim Titleflg As Boolean = False
        Do
            textData = Text_ReadLine(sr)
            '1件目がタイトルの場合、読み直し
            If Titleflg = True Then
                Titleflg = False
                Continue Do
            End If

            If sr.EndOfStream = True Then
                If Not textData Is Nothing AndAlso
                   textData.Trim.Length > 0 Then
                    Getdata.Add(textData)
                Else
                    Getdata.Add("")
                End If
                Exit Do
            End If

            If Not textData Is Nothing AndAlso
               textData.Trim.Length > 0 Then
                Getdata.Add(textData)
            Else
                Getdata.Add("")
            End If
        Loop

        Return Getdata
    End Function

#End Region

#End Region



    Private Sub MakeImportText(ByVal folderpath As String, ByVal folderpath出力 As String, ByVal textFileName As String, ByVal renban As Integer)

        Dim importparam As IImportParam = New ImportParam

        Dim FileName(1) As String
        Dim 文字コード(1) As String
        Dim 先頭行はタイトル As CheckState = CheckState.Unchecked

        FileName(0) = textFileName
        FileName(1) = _変換テキスト名
        文字コード(0) = TextFileImportLib.GetEncodingType(importparam.文字コード)
        Dim ファイル１文字コード As IKanriTableData.文字コード型
        ファイル１文字コード = TextFileImportLib.Get文字コード自動判定(TextFileImportLib.EditFolder(folderpath.Trim) & textFileName.Trim)
        文字コード(0) = TextFileImportLib.GetEncodingType(ファイル１文字コード)
        文字コード(1) = TextFileImportLib.GetEncodingType(ファイル１文字コード)

        _textConvert.myコントロール情報 = _myコントロール情報
        _textConvert.SettinginfoCUST = Me.SettingInfo
        先頭行はタイトル = Me.topRowTitleCheck.CheckState

        Dim dataAccess As IMasterReader = CreateDataAccessMasterReader()

        If _textConvert.File_convert(folderpath, folderpath出力, FileName, 文字コード, renban, 先頭行はタイトル, dataAccess) = False Then
        End If

    End Sub

    '元ファイル内容の退避
    Private Sub MakeImportText元ファイル内容の退避(ByVal folderpath As String, ByVal folderpath出力 As String, ByVal textFileName As String, ByVal renban As Integer, ByRef importParam As ImportParam)

        Dim FileName(1) As String
        Dim 文字コード(1) As String

        FileName(0) = textFileName
        FileName(1) = _変換テキスト名
        文字コード(0) = TextFileImportLib.GetEncodingType(importParam.文字コード)
        Dim ファイル１文字コード As IKanriTableData.文字コード型
        ファイル１文字コード = TextFileImportLib.Get文字コード自動判定(TextFileImportLib.EditFolder(folderpath.Trim) & textFileName.Trim)
        文字コード(0) = TextFileImportLib.GetEncodingType(ファイル１文字コード)
        文字コード(1) = TextFileImportLib.GetEncodingType(ファイル１文字コード)

        _textConvert.myコントロール情報 = _myコントロール情報
        _textConvert.SettinginfoCUST = Me.SettingInfo

        If _textConvert.File_convert(folderpath, folderpath出力, FileName, 文字コード, renban, CType(importParam, ImportParam)) = False Then
        End If

    End Sub

#Region "インスタンス作成処理"

    Private Function CreateDataAccessMasterReader() As IMasterReader
        Return DataAccessFactory(Of IMasterReader).CreateInstance(Me, "MasterReader")
    End Function

#End Region

#Region "■データRead"

    Private Function ReadMaster_JTB様コントロール(ByVal param As ReadParam,
                                         ByRef readData As DataTable,
                                         ByVal dataAccess As IMasterReader) As Boolean

        Dim result As Boolean
        Dim resultData As DataTable

        resultData = dataAccess.MasterRead(IMasterReader.テーブル一覧型.JTB様コントロール, param)

        If resultData.Rows.Count > 0 Then
            result = True
            readData = resultData.Copy
        Else
            result = False
        End If

        Return result

    End Function

#End Region

#End Region
    'A-CUST20190830↑

End Class
