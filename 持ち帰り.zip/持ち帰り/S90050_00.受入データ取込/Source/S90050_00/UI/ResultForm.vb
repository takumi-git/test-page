﻿''' <summary>
''' テキスト取込処理結果画面クラス
''' </summary>
''' <remarks></remarks>
Public Class ResultForm

    Private タイトル As String = "" 'A-CUST20190830

#Region "■画面起動関連■"

#Region "Setup関連"

#End Region

#Region "Start関連"

#End Region

#Region "LoadImpl関連"
    Public Overrides Sub LoadImpl(ByVal sender As Object, ByVal e As System.EventArgs)
        'Baseは必須
        MyBase.LoadImpl(sender, e)
        '処理件数編集
        ResultCountInfo.SetResult(MyBase.実行中の処理, MyBase.起動モード, MyBase.ResultImport)
    End Sub
#End Region

#End Region

#Region "■印刷／プレビュー関連処理■"


#End Region

#Region "■テキストファイル出力関連■"

    <Conditional("Debug")>
    Protected Overrides Function テキストファイル出力処理単位件数() As Integer
        If Me.システム環境情報.システム構成情報.動作モード = Foundation.動作モード型.通常 Then
            Return MyBase.テキストファイル出力処理単位件数
        End If
        Return 10
    End Function

#End Region

    Protected Overrides Sub SetReadOnlyExceptionItems(ByRef exceptionItems As List(Of System.Windows.Forms.Control))
        exceptionItems.Add(ResultCountInfo)
    End Sub

    'A-CUST20190830↓
#Region "カスタマイズ"

#Region "警告、エラーテキスト名対応"

    Protected Overrides Function GetExportFilePath(ByVal extention As String) As String

        Dim param As ImportParam = CType(ImportParam, ImportParam)
        Dim 出力ファイル移動動作 As TextFileImportLib.出力ファイル移動動作型
        出力ファイル移動動作 = MyBase.GetInitInfo(TextFileImportLib.プログラム専用_出力ファイル移動動作, TextFileImportLib.出力ファイル移動動作型.個別指定)
        Dim toFolder As String
        If 出力ファイル移動動作 = TextFileImportLib.出力ファイル移動動作型.取込ファイルパス Then
            toFolder = param.入力元フォルダ.Trim
        Else
            toFolder = MyBase.GetInitInfo(TextFileImportLib.プログラム専用_出力ファイル移動バス, "").Trim
        End If
        If toFolder = "" Then Return ""
        toFolder = TextFileImportLib.EditFolder(toFolder)

        Dim toファイル As String = ""
        toファイル = param.退避ファイル名.Trim
        Return toFolder & IO.Path.GetFileNameWithoutExtension(toファイル) & extention

    End Function

    'A-CUST20121203↓ '2013/04/03
    Friend Shared Function CreateTextExportController(ByRef insideJob As OSK.X1.Foundation.UserInterface.IInsideJob) As ITextExportController
        Dim target As ITextExportController = New TextExportController
        target.Initialize(insideJob.SettingInfo, insideJob.InitInfo, insideJob.SaveInfo)
        Return target
    End Function
    Friend Shared Function CreateTransfer(ByRef insideJob As OSK.X1.Foundation.UserInterface.IInsideJob) As ITransfer
        Dim target As ITransfer
        target = OSK.X1.Foundation.UserInterface.Factory(Of ITransfer).CreateInstance(insideJob, TextFileImportUILib.UIAssembly, "Transfer")
        Return target
    End Function

    ''' <summary>
    ''' 警告もしくはエラーテキストを出力する
    ''' </summary>
    ''' <param name="resultValue"></param>
    ''' <returns></returns>
    ''' <remarks>マルチスレッドで処理を行います</remarks>
    Protected Overrides Function ExportToTextFileImpl(ByRef resultValue As Hashtable) As Foundation.ResultType
        Dim result As Foundation.ResultType

        Dim textExportParam As ITextExportParam = New TextExportParam
        With textExportParam
            .分割コード = Me.ResultImport.ResultCheckExecute.KanriTableData.分割コード
            .取得したい件数 = テキストファイル出力処理単位件数()
            .文字コード = Me.ResultImport.ResultCheckExecute.KanriTableData.文字コード
        End With

        Dim resultTextExport As Foundation.TextFileImport.IResultTextExport = New ResultTextExport

        '警告データファイル出力
        If _警告発生区分 = True Then
            MyBase.MessageViewer.Show(Myメッセージ.CMN0031_警告データファイル出力中)
            With textExportParam
                .データ区分 = TextFileImportLib.データ区分型.警告データ
                .出力パス = worningFilePath.TextValue
            End With
            Try
                result = ExportText(textExportParam, resultTextExport)
                If result <> Foundation.ResultType.成功 Then
                    Return result
                End If

            Catch ex As IOException
                result = Foundation.ResultType.想定された失敗
                MessageViewer.Show(Myメッセージ.CMN0027_ファイルが使用中_またはライトプロテクトされています)
                Return result

            End Try
            resultValue("警告件数") = resultTextExport.データ件数
        End If

        'エラーデータファイル出力
        If _エラー発生区分 = True Then
            MyBase.MessageViewer.Show(Myメッセージ.CMN0030_エラーデータファイル出力中)
            With textExportParam
                .データ区分 = TextFileImportLib.データ区分型.エラーデータ
                .出力パス = errorFilePath.TextValue
            End With
            Try
                result = ExportText(textExportParam, resultTextExport)
                If result <> Foundation.ResultType.成功 Then
                    Return result
                End If

            Catch ex As IOException
                result = Foundation.ResultType.想定された失敗
                MessageViewer.Show(Myメッセージ.CMN0027_ファイルが使用中_またはライトプロテクトされています)
                Return result

            End Try
            resultValue("エラー件数") = resultTextExport.データ件数
        End If

        Return result

    End Function

    Public Function ExportText(ByVal textExportParam As Foundation.TextFileImport.ITextExportParam,
                               ByRef resultTextExport As Foundation.TextFileImport.IResultTextExport
                    ) As Foundation.ResultType
        Dim result As Foundation.ResultType

        Dim 開始行番号 As Integer = 1
        Dim 書込み回数 As Integer = 0
        Dim 出力件数 As Integer = 0
        Dim transfer As ITransfer = Nothing

        resultTextExport.データ件数 = 0

        Dim _myImportParam As S90050_00.ImportParam
        _myImportParam = CType(MyBase.ImportParam, S90050_00.ImportParam)
        If _myImportParam.先頭行はタイトル = True Then
            開始行番号 = 2
        End If
        Do
            textExportParam.開始行番号 = 開始行番号

            If transfer Is Nothing Then
                transfer = CreateTransfer(Me)
            End If
            resultTextExport.データ.Clear()
            result = transfer.GetExportData(textExportParam, resultTextExport)
            Select Case result
                Case Foundation.ResultType.成功
                    開始行番号 = resultTextExport.終了行番号 + 1
                    書込み回数 += 1
                    出力件数 += resultTextExport.データ.Count

                    result = WriteTextFile(textExportParam.出力パス, textExportParam.文字コード, 書込み回数, resultTextExport)

                Case Foundation.ResultType.レコード無し
                    result = Foundation.ResultType.成功
                    Exit Do

                Case Else
                    result = Foundation.ResultType.想定された失敗
                    Exit Do

            End Select

        Loop

        resultTextExport.データ件数 = 出力件数

        Return result

    End Function

    ''' <summary>
    ''' テキストファイル出力(タイトル)
    ''' </summary>
    ''' <param name="filePath"></param>
    ''' <param name="文字コード"></param>
    ''' <param name="書込み回数"></param>
    ''' <param name="resultTextExport"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function WriteTextFileTITLE(ByVal filePath As String,
                                   ByVal 文字コード As IKanriTableData.文字コード型,
                                   ByVal 書込み回数 As Integer,
                                   ByRef resultTextExport As Foundation.TextFileImport.IResultTextExport
                     ) As Foundation.ResultType
        Dim result As Foundation.ResultType

        Dim textFileWriter As ITextFileWriter = New TextFileWriter
        result = textFileWriter.FileOpen(filePath, 文字コード, 書込み回数 <> 1)

        result = textFileWriter.WriteLine(タイトル)
        If result <> Foundation.ResultType.成功 Then
            'Exit For
        End If

        result = textFileWriter.FileClose

        Return result
    End Function

    ''' <summary>
    ''' テキストファイル出力
    ''' </summary>
    ''' <param name="filePath"></param>
    ''' <param name="文字コード"></param>
    ''' <param name="書込み回数"></param>
    ''' <param name="resultTextExport"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function WriteTextFile(ByVal filePath As String,
                                   ByVal 文字コード As IKanriTableData.文字コード型,
                                   ByVal 書込み回数 As Integer,
                                   ByRef resultTextExport As Foundation.TextFileImport.IResultTextExport
                     ) As Foundation.ResultType
        Dim result As Foundation.ResultType

        Dim textFileWriter As ITextFileWriter = New TextFileWriter
        result = textFileWriter.FileOpen(filePath, 文字コード, 書込み回数 <> 1)

        Dim _myImportParam As S90050_00.ImportParam
        _myImportParam = CType(MyBase.ImportParam, S90050_00.ImportParam)
        If 書込み回数 = 1 AndAlso _myImportParam.先頭行はタイトル = True Then
            result = textFileWriter.WriteLine(タイトル)
        End If

        Dim buff As String = ""
        For i As Integer = 0 To resultTextExport.データ.Count - 1
            buff = TextFileImportLib.MyReplace(resultTextExport.データ.Item(i).ToString.TrimEnd, TextFileImportLib.TAB_STRING, vbTab)
            result = textFileWriter.WriteLine(buff)
            If result <> Foundation.ResultType.成功 Then
                Exit For
            End If
        Next

        result = textFileWriter.FileClose

        Return result
    End Function

#End Region

#End Region
    'A-CUST20190830↑

End Class