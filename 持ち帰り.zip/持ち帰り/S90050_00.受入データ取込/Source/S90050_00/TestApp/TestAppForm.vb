﻿Public Class TestAppForm

    Private Sub TestAppForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        dbList.Text = dbList.Items(0).ToString
    End Sub

    Private Sub StartButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StartButton.Click

        If dbList.Text = "" Then
            dbList.Focus()
            Exit Sub
        End If

        Dim settingInfo As IDictionary = New Hashtable()
        Dim initInfo As IDictionary = New Hashtable()
        Dim saveInfo As IDictionary = New Hashtable()

        GetSettingInfo(settingInfo, 構成形態型.スタンドアロン)

        SetInitInfo(initInfo)

        settingInfo.Add("移動先フォルダ", "\移動先フォルダ\")

        Dim paramInfo As IDictionary = New Hashtable

        Dim target As New OSK.X1.Foundation.ProgramLoad.UserInterface.Loader    'X1変換Tool-20170508
        target.Run(settingInfo, paramInfo)

    End Sub

    Private Sub GetSettingInfo(ByRef newSettingInfo As IDictionary, ByVal 構成形態 As OSK.X1.Foundation.構成形態型)    'X1変換Tool-20170508

        Dim settingInfo As SettingInfo = New SettingInfo(newSettingInfo)

        With settingInfo
            .会社情報.名称 = "ソフテック"
            .データベース情報.接続ID = "cnnSQL" 'dbList.Text
            .データベース情報.ログ接続ID = .データベース情報.接続ID 'dbList.Text
            .プログラム情報.ID = "OSK.X1.SEI.S90050_00"    'X1変換Tool-20170508
            .プログラム情報.名称 = "仕入明細取込"
            .プログラム情報.実行ID = System.Guid.NewGuid.ToString()
            .プログラム情報.オリジナルID = "OSK.X1.SEI.S90050_00"    'X1変換Tool-20170508
            .業務情報.ID = "HAN"
            .業務情報.アドオン製品ID = "SEI"
            .SetSettingInfo("業務情報.プログラム固有ID", "HAN")
            .ログオンユーザー情報.ID = System.Environment.UserName.ToUpper
            .ログオンユーザー情報.ID = "ADMINISTRATOR"
            .コンピュータ情報.名前 = System.Environment.MachineName
            .プログラム制御情報.処理状況更新間隔 = 2

            '.データベース情報.接続ID = "CNN004"
            '.データベース情報.ログ接続ID = "CNN004"
            '.ログオンユーザー情報.ID = "ADMINISTRATOR"

            '.データベース情報.接続ID = "CNN010"
            '.データベース情報.ログ接続ID = "CNN010"
            '.ログオンユーザー情報.ID = "ADMINISTRATOR"

            .システム構成情報.構成形態 = 構成形態
            If RadioButtonNormal.Checked = True Then
                .システム構成情報.動作モード = 動作モード型.通常
            Else
                .システム構成情報.動作モード = 動作モード型.デバッグ
            End If

            '.データベース情報.接続ID = "CNN001"
            '.データベース情報.ログ接続ID = "CNN001"
            '.ログオンユーザー情報.ID = "ADMINISTRATOR"

            '.データベース情報.接続ID = "CNN002"
            '.データベース情報.ログ接続ID = "CNN002"
            '.ログオンユーザー情報.ID = "ADMINISTRATOR"

            '.データベース情報.接続ID = "CNN005"
            '.データベース情報.ログ接続ID = "CNN005"
            '.ログオンユーザー情報.ID = "ADMINISTRATOR"

            '.データベース情報.接続ID = "CNN006"
            '.データベース情報.ログ接続ID = "CNN006"
            '.ログオンユーザー情報.ID = "ADMINISTRATOR"

            '.データベース情報.接続ID = "CNN009"
            '.データベース情報.ログ接続ID = "CNN009"
            '.ログオンユーザー情報.ID = "ADMINISTRATOR"

            '.データベース情報.接続ID = "CNN010"
            '.データベース情報.ログ接続ID = "CNN010"
            '.ログオンユーザー情報.ID = "ADMINISTRATOR"

            '.データベース情報.接続ID = "CNN012"
            '.データベース情報.ログ接続ID = "CNN012"
            '.ログオンユーザー情報.ID = "ADMINISTRATOR"

            '.データベース情報.接続ID = "CNN014"
            '.データベース情報.ログ接続ID = "CNN014"
            '.ログオンユーザー情報.ID = "ADMINISTRATOR"

            .プログラム制御情報.起動ログ出力 = False
            .プログラム制御情報.データ出力ログ出力 = False
            .プログラム制御情報.Escキー終了機能 = True
            .プログラム制御情報.会社名表示 = True

            .プログラム制御情報.ファンクションバーアイコン表示 = True
            .プログラム制御情報.ファンクションバーサイズ拡大 = True
            .プログラム制御情報.行ピッチ変更機能 = True

            .色情報.プログラムID = .プログラム情報.ID
            .色情報.プログラム枝番 = .プログラム情報.枝番
            .色情報.業務区分 = .業務情報.ID
            .色情報.色パターン設定区分 = True

            .SetSettingInfo("プログラム固有.テキストデータ転送単位", 10)

        End With

    End Sub

    Private Sub CommandButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CommandButton1.Click

        If dbList.Text = "" Then
            dbList.Focus()
            Exit Sub
        End If

        Dim settingInfo As IDictionary = New Hashtable()
        Dim initInfo As IDictionary = New Hashtable()
        Dim saveInfo As IDictionary = New Hashtable()

        GetSettingInfo(settingInfo, 構成形態型.分散)

        Dim brokerInfo As OSK.X1.Foundation.UserInterface.BrokerInfo = New OSK.X1.Foundation.UserInterface.BrokerInfo(settingInfo)    'X1変換Tool-20170508

        brokerInfo.サーバー接続URI = "http://localhost:8181/RemotingBrokerService"
        brokerInfo.プロキシアセンブリ名 = "OSK.X1.Broker.UserInterface"    'X1変換Tool-20170508
        brokerInfo.プロキシクラス名 = "OSK.X1.Broker.UserInterface.RemotingProxyHandler"    'X1変換Tool-20170508


        brokerInfo.サーバー接続URI = "http://20bsss-01/SMILEBSApplication/BrokerService.rem"
        brokerInfo.プロキシクラス名 = "OSK.X1.Broker.UserInterface.HttpBinaryProxyHandler"    'X1変換Tool-20170508

        Dim stateInfo As OSK.X1.Foundation.StateServerInfo = New OSK.X1.Foundation.StateServerInfo(settingInfo)    'X1変換Tool-20170508
        stateInfo.URI = "tcp://localhost:8180/RemotingStateManagerService"

        SetInitInfo(initInfo)

        settingInfo.Add("移動先フォルダ", "D:\移動先フォルダ\")

        Dim paramInfo As IDictionary = New Hashtable

        Dim target As New OSK.X1.Foundation.ProgramLoad.UserInterface.Loader    'X1変換Tool-20170508
        target.Run(settingInfo, paramInfo)

    End Sub

    Private Sub SetInitInfo(ByRef initInfo As IDictionary)

        'Dim userID As String
        'userID = InputBox("ユーザーIDを入力して下さい。", "", "herohero")

        'initInfo.Add("任意キー１", "x1890024")
        'initInfo.Add("任意キー２", "")

        'initInfo.Add("エラー出力フォルダの指定", 1) '個別に設定する
        'initInfo.Add("エラー出力フォルダの指定.出力フォルダ", "D:\警告・エラー出力フォルダ")

        'initInfo.Add("終了時の入力元ファイル", 1) '別フォルダに移動る
        'initInfo.Add("終了時の入力元ファイル.保存フォルダ", "D:\移動先フォルダ")

        'initInfo.Add("DEBUG.SLEEPTIME", 50)

    End Sub

    Private Sub CloseButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CloseButton.Click

        Me.Close()

    End Sub

End Class
