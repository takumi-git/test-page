﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class TestAppForm
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.StartButton = New OSK.X1.Foundation.SimpleControl.CommandButton
        Me.CloseButton = New OSK.X1.Foundation.SimpleControl.CommandButton
        Me.CommandButton1 = New OSK.X1.Foundation.SimpleControl.CommandButton
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.RadioButtonDebug = New System.Windows.Forms.RadioButton
        Me.RadioButtonNormal = New System.Windows.Forms.RadioButton
        Me.dbList = New System.Windows.Forms.ComboBox
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'StartButton
        '
        Me.StartButton.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.StartButton.FocusBackColor = System.Drawing.Color.Empty
        Me.StartButton.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.StartButton.Image = Nothing
        Me.StartButton.Location = New System.Drawing.Point(13, 122)
        Me.StartButton.Margin = New System.Windows.Forms.Padding(4)
        Me.StartButton.Name = "StartButton"
        Me.StartButton.NextByEnterKey = False
        Me.StartButton.RemarkString = Nothing
        Me.StartButton.Size = New System.Drawing.Size(169, 120)
        Me.StartButton.TabIndex = 0
        Me.StartButton.Text = "起動(ＳＡ)"
        Me.StartButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'CloseButton
        '
        Me.CloseButton.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.CloseButton.FocusBackColor = System.Drawing.Color.Empty
        Me.CloseButton.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.CloseButton.Image = Nothing
        Me.CloseButton.Location = New System.Drawing.Point(190, 122)
        Me.CloseButton.Margin = New System.Windows.Forms.Padding(4)
        Me.CloseButton.Name = "CloseButton"
        Me.CloseButton.NextByEnterKey = False
        Me.CloseButton.RemarkString = Nothing
        Me.CloseButton.Size = New System.Drawing.Size(169, 248)
        Me.CloseButton.TabIndex = 1
        Me.CloseButton.Text = "終了"
        Me.CloseButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'CommandButton1
        '
        Me.CommandButton1.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.CommandButton1.FocusBackColor = System.Drawing.Color.Empty
        Me.CommandButton1.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.CommandButton1.Image = Nothing
        Me.CommandButton1.Location = New System.Drawing.Point(13, 250)
        Me.CommandButton1.Margin = New System.Windows.Forms.Padding(4)
        Me.CommandButton1.Name = "CommandButton1"
        Me.CommandButton1.NextByEnterKey = False
        Me.CommandButton1.RemarkString = Nothing
        Me.CommandButton1.Size = New System.Drawing.Size(169, 120)
        Me.CommandButton1.TabIndex = 2
        Me.CommandButton1.Text = "起動(分散)"
        Me.CommandButton1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.RadioButtonDebug)
        Me.GroupBox1.Controls.Add(Me.RadioButtonNormal)
        Me.GroupBox1.Location = New System.Drawing.Point(13, 49)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(346, 57)
        Me.GroupBox1.TabIndex = 3
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "動作モード"
        '
        'RadioButtonDebug
        '
        Me.RadioButtonDebug.AutoSize = True
        Me.RadioButtonDebug.Checked = True
        Me.RadioButtonDebug.Location = New System.Drawing.Point(177, 23)
        Me.RadioButtonDebug.Name = "RadioButtonDebug"
        Me.RadioButtonDebug.Size = New System.Drawing.Size(90, 20)
        Me.RadioButtonDebug.TabIndex = 1
        Me.RadioButtonDebug.TabStop = True
        Me.RadioButtonDebug.Text = "デバッグ"
        Me.RadioButtonDebug.UseVisualStyleBackColor = True
        '
        'RadioButtonNormal
        '
        Me.RadioButtonNormal.AutoSize = True
        Me.RadioButtonNormal.Location = New System.Drawing.Point(16, 23)
        Me.RadioButtonNormal.Name = "RadioButtonNormal"
        Me.RadioButtonNormal.Size = New System.Drawing.Size(58, 20)
        Me.RadioButtonNormal.TabIndex = 0
        Me.RadioButtonNormal.Text = "通常"
        Me.RadioButtonNormal.UseVisualStyleBackColor = True
        '
        'dbList
        '
        Me.dbList.DisplayMember = "1"
        Me.dbList.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.dbList.FormattingEnabled = True
        Me.dbList.Items.AddRange(New Object() {"cnnSQL", "cnnORA", "cnnDB2"})
        Me.dbList.Location = New System.Drawing.Point(13, 12)
        Me.dbList.Name = "dbList"
        Me.dbList.Size = New System.Drawing.Size(346, 24)
        Me.dbList.TabIndex = 4
        '
        'TestAppForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(372, 382)
        Me.Controls.Add(Me.dbList)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.CommandButton1)
        Me.Controls.Add(Me.CloseButton)
        Me.Controls.Add(Me.StartButton)
        Me.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "TestAppForm"
        Me.Text = "テキストファイル取込"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents StartButton As OSK.X1.Foundation.SimpleControl.CommandButton
    Friend WithEvents CloseButton As OSK.X1.Foundation.SimpleControl.CommandButton
    Friend WithEvents CommandButton1 As OSK.X1.Foundation.SimpleControl.CommandButton
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButtonDebug As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButtonNormal As System.Windows.Forms.RadioButton
    Friend WithEvents dbList As System.Windows.Forms.ComboBox

End Class
