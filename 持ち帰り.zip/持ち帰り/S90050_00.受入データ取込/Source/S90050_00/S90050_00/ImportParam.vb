﻿''' <summary>
''' 個別プログラムのパラメータ定義
''' </summary>
''' <remarks>FWのBaseクラスを継承し、独自のプロパティを実装</remarks>
<Serializable()>
Public Class ImportParam
    Inherits ImportParamBase

#Region "列挙型"

    Public Enum 処理連番採番型
        入力処理連番を採用する = 1
        新規に採番する
    End Enum

    Public Enum 伝票番号採番型
        入力伝票番号を採用する = 1
        新規に採番する
    End Enum

    Public Enum ロットNo採番型  'A-2009/12/18_Ver7.40_LOT
        入力ロットNoを採用する = 1
        新規に採番する
    End Enum

    'A-20120315_3↓
    Public Enum 残チェック区分型
        なし = 1
        警告
        エラー
    End Enum
    'A-20120315_3↑
#End Region

#Region "■画面の情報■"

    Private _処理連番採番 As 処理連番採番型
    Property 処理連番採番() As 処理連番採番型
        Get
            Return _処理連番採番
        End Get
        Set(ByVal value As 処理連番採番型)
            _処理連番採番 = value
        End Set
    End Property

    Private _伝票番号採番 As 伝票番号採番型
    Property 伝票番号採番() As 伝票番号採番型
        Get
            Return _伝票番号採番
        End Get
        Set(ByVal value As 伝票番号採番型)
            _伝票番号採番 = value
        End Set
    End Property

    Private _ロットNo採番 As ロットNo採番型     'A-2009/12/18_Ver7.40_LOT
    Property ロットNo採番() As ロットNo採番型   'A-2009/12/18_Ver7.40_LOT
        Get
            Return _ロットNo採番
        End Get
        Set(ByVal value As ロットNo採番型)
            _ロットNo採番 = value
        End Set
    End Property

    Private _同一処理連番存在時は上書き As Boolean
    Property 同一処理連番存在時は上書き() As Boolean
        Get
            Return _同一処理連番存在時は上書き
        End Get
        Set(ByVal value As Boolean)
            _同一処理連番存在時は上書き = value
        End Set
    End Property

    'A-20120315_3↓
    Private _発注残以上のデータ取込チェック As 残チェック区分型
    Property 発注残以上のデータ取込チェック() As 残チェック区分型
        Get
            Return _発注残以上のデータ取込チェック
        End Get
        Set(ByVal value As 残チェック区分型)
            _発注残以上のデータ取込チェック = value
        End Set
    End Property

    Private _完納済みデータ取込チェック As 残チェック区分型
    Property 完納済みデータ取込チェック() As 残チェック区分型
        Get
            Return _完納済みデータ取込チェック
        End Get
        Set(ByVal value As 残チェック区分型)
            _完納済みデータ取込チェック = value
        End Set
    End Property
    'A-20120315_3↑

#End Region

#Region "■その他情報■"

    Private _myコントロール情報 As New Myコントロール情報Param
    ''' <summary>
    ''' コントロール情報
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property Myコントロール情報() As Myコントロール情報Param
        Get
            Return _myコントロール情報
        End Get
        Set(ByVal value As Myコントロール情報Param)
            _myコントロール情報 = value
        End Set
    End Property

    Private _拡張項目情報_仕入伝票_使用 As Boolean
    Public Property 拡張項目情報_仕入伝票_使用() As Boolean
        Get
            Return _拡張項目情報_仕入伝票_使用
        End Get
        Set(ByVal value As Boolean)
            _拡張項目情報_仕入伝票_使用 = value
        End Set
    End Property

    Private _拡張項目情報_仕入伝票 As SEI.LIB.ExpandItemControl.I拡張項目定義型
    Public Property 拡張項目情報_仕入伝票() As SEI.LIB.ExpandItemControl.I拡張項目定義型
        Get
            Return _拡張項目情報_仕入伝票
        End Get
        Set(ByVal value As SEI.LIB.ExpandItemControl.I拡張項目定義型)
            _拡張項目情報_仕入伝票 = value
        End Set
    End Property

    Private _拡張項目情報_仕入伝票_更新番号 As Long
    Public Property 拡張項目情報_仕入伝票_更新番号() As Long
        Get
            Return _拡張項目情報_仕入伝票_更新番号
        End Get
        Set(ByVal value As Long)
            _拡張項目情報_仕入伝票_更新番号 = value
        End Set
    End Property

    Private _拡張項目情報_仕入明細_使用 As Boolean
    Public Property 拡張項目情報_仕入明細_使用() As Boolean
        Get
            Return _拡張項目情報_仕入明細_使用
        End Get
        Set(ByVal value As Boolean)
            _拡張項目情報_仕入明細_使用 = value
        End Set
    End Property

    Private _拡張項目情報_仕入明細 As SEI.LIB.ExpandItemControl.I拡張項目定義型
    Public Property 拡張項目情報_仕入明細() As SEI.LIB.ExpandItemControl.I拡張項目定義型
        Get
            Return _拡張項目情報_仕入明細
        End Get
        Set(ByVal value As SEI.LIB.ExpandItemControl.I拡張項目定義型)
            _拡張項目情報_仕入明細 = value
        End Set
    End Property

    Private _拡張項目情報_仕入明細_更新番号 As Long
    Public Property 拡張項目情報_仕入明細_更新番号() As Long
        Get
            Return _拡張項目情報_仕入明細_更新番号
        End Get
        Set(ByVal value As Long)
            _拡張項目情報_仕入明細_更新番号 = value
        End Set
    End Property

    Private _拡張項目情報_入荷伝票_使用 As Boolean
    Public Property 拡張項目情報_入荷伝票_使用() As Boolean
        Get
            Return _拡張項目情報_入荷伝票_使用
        End Get
        Set(ByVal value As Boolean)
            _拡張項目情報_入荷伝票_使用 = value
        End Set
    End Property

    Private _拡張項目情報_入荷伝票 As SEI.LIB.ExpandItemControl.I拡張項目定義型
    Public Property 拡張項目情報_入荷伝票() As SEI.LIB.ExpandItemControl.I拡張項目定義型
        Get
            Return _拡張項目情報_入荷伝票
        End Get
        Set(ByVal value As SEI.LIB.ExpandItemControl.I拡張項目定義型)
            _拡張項目情報_入荷伝票 = value
        End Set
    End Property

    Private _拡張項目情報_入荷伝票_更新番号 As Long
    Public Property 拡張項目情報_入荷伝票_更新番号() As Long
        Get
            Return _拡張項目情報_入荷伝票_更新番号
        End Get
        Set(ByVal value As Long)
            _拡張項目情報_入荷伝票_更新番号 = value
        End Set
    End Property

    Private _拡張項目情報_入荷明細_使用 As Boolean
    Public Property 拡張項目情報_入荷明細_使用() As Boolean
        Get
            Return _拡張項目情報_入荷明細_使用
        End Get
        Set(ByVal value As Boolean)
            _拡張項目情報_入荷明細_使用 = value
        End Set
    End Property

    Private _拡張項目情報_入荷明細 As SEI.LIB.ExpandItemControl.I拡張項目定義型
    Public Property 拡張項目情報_入荷明細() As SEI.LIB.ExpandItemControl.I拡張項目定義型
        Get
            Return _拡張項目情報_入荷明細
        End Get
        Set(ByVal value As SEI.LIB.ExpandItemControl.I拡張項目定義型)
            _拡張項目情報_入荷明細 = value
        End Set
    End Property

    Private _拡張項目情報_入荷明細_更新番号 As Long
    Public Property 拡張項目情報_入荷明細_更新番号() As Long
        Get
            Return _拡張項目情報_入荷明細_更新番号
        End Get
        Set(ByVal value As Long)
            _拡張項目情報_入荷明細_更新番号 = value
        End Set
    End Property

    Private _my項目名称 As My項目名称Param型
    Public Property My項目名称() As My項目名称Param型
        Get
            Return _my項目名称
        End Get
        Set(ByVal value As My項目名称Param型)
            _my項目名称 = value
        End Set
    End Property

    Private _操作日付 As Integer
    Property 操作日付() As Integer
        Get
            Return _操作日付
        End Get
        Set(ByVal value As Integer)
            _操作日付 = value
        End Set
    End Property

#End Region


    'A-CUST20190830↓
    Private _拡張項目情報_入出庫伝票 As SEI.LIB.ExpandItemControl.I拡張項目定義型
    Public Property 拡張項目情報_入出庫伝票() As SEI.LIB.ExpandItemControl.I拡張項目定義型
        Get
            Return _拡張項目情報_入出庫伝票
        End Get
        Set(ByVal value As SEI.LIB.ExpandItemControl.I拡張項目定義型)
            _拡張項目情報_入出庫伝票 = value
        End Set
    End Property

    Private _拡張項目情報_入出庫伝票_更新番号 As Long
    Public Property 拡張項目情報_入出庫伝票_更新番号() As Long
        Get
            Return _拡張項目情報_入出庫伝票_更新番号
        End Get
        Set(ByVal value As Long)
            _拡張項目情報_入出庫伝票_更新番号 = value
        End Set
    End Property

    Private _拡張項目情報_入出庫明細 As SEI.LIB.ExpandItemControl.I拡張項目定義型
    Public Property 拡張項目情報_入出庫明細() As SEI.LIB.ExpandItemControl.I拡張項目定義型
        Get
            Return _拡張項目情報_入出庫明細
        End Get
        Set(ByVal value As SEI.LIB.ExpandItemControl.I拡張項目定義型)
            _拡張項目情報_入出庫明細 = value
        End Set
    End Property

    Private _拡張項目情報_入出庫明細_更新番号 As Long
    Public Property 拡張項目情報_入出庫明細_更新番号() As Long
        Get
            Return _拡張項目情報_入出庫明細_更新番号
        End Get
        Set(ByVal value As Long)
            _拡張項目情報_入出庫明細_更新番号 = value
        End Set
    End Property


    Private _年月度 As String
    Public Property 年月度() As String
        Get
            Return _年月度
        End Get
        Set(ByVal value As String)
            _年月度 = value
        End Set
    End Property


    Private _元ファイル内容 As String()
    Public Property 元ファイル内容() As String()
        Get
            Return _元ファイル内容
        End Get
        Set(ByVal value As String())
            _元ファイル内容 = value
        End Set
    End Property


    Private _退避フォルダ As String
    Public Property 退避フォルダ() As String
        Get
            Return _退避フォルダ
        End Get
        Set(ByVal value As String)
            _退避フォルダ = value
        End Set
    End Property

    Private _退避ファイル名 As String
    Public Property 退避ファイル名() As String
        Get
            Return _退避ファイル名
        End Get
        Set(ByVal value As String)
            _退避ファイル名 = value
        End Set
    End Property

    ''' <summary>
    ''' 入力元ファイルパス
    ''' </summary>
    ''' <value>取込を行うテキストファイルの絶対パスを返します</value>
    ''' <remarks></remarks>
    ReadOnly Property 一時ファイル入力元ファイルパス() As String
        Get
            Return TextFileImportLib.EditFolder(_退避フォルダ) & _退避ファイル名
        End Get
    End Property

    Private _移動中倉庫コード As String
    Public Property 移動中倉庫コード() As String
        Get
            Return _移動中倉庫コード
        End Get
        Set(ByVal value As String)
            _移動中倉庫コード = value
        End Set
    End Property
    'A-CUST20190830↑
End Class
