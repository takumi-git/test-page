﻿Public Class WorkTableUnitData
    Inherits OSK.X1.Foundation.TextFileImport.WorkTableUnitData    'X1変換Tool-20170508

#Region "列挙型"

    Enum DB更新区分型 As Integer
        INSERT
        UPDATE
        None
    End Enum

#End Region

#Region "プロパティ"

    'A-20111025_3↓
#Region "クリア処理"

    Public Sub テーブル情報クリア(ByVal テキスト行数 As Integer)

        ReDim _手入力製番マスタ(テキスト行数 - 1)
        ReDim _既存手入力製番マスタ(テキスト行数 - 1)

    End Sub

#End Region
    'A-20111025_3↑

#Region "受発注明細"

    Private _受注伝票更新 As Boolean
    Public Property 受注伝票更新() As Boolean
        Get
            Return _受注伝票更新
        End Get
        Set(ByVal value As Boolean)
            _受注伝票更新 = value
        End Set
    End Property

    Private _受注伝票更新件数 As Integer
    Public Property 受注伝票更新件数() As Integer
        Get
            Return _受注伝票更新件数
        End Get
        Set(ByVal value As Integer)
            _受注伝票更新件数 = value
        End Set
    End Property

    Private _受注ヘッダー As ProgramLib.受発注ヘッダー型
    Public Property 受注ヘッダー() As ProgramLib.受発注ヘッダー型
        Get
            Return _受注ヘッダー
        End Get
        Set(ByVal value As ProgramLib.受発注ヘッダー型)
            _受注ヘッダー = value
        End Set
    End Property

    Private _受注明細(0 To ProgramLib.MAX_DETAIL_COUNT - 1) As ProgramLib.受発注明細型
    Public Property 受注明細(ByVal 行番号 As Integer) As ProgramLib.受発注明細型
        Get
            Return _受注明細(行番号)
        End Get
        Set(ByVal value As ProgramLib.受発注明細型)
            _受注明細(行番号) = value
        End Set
    End Property

#End Region

#Region "取引伝票_更新時用"

    Private _取引ヘッダー As ProgramLib.仕入ヘッダー型
    Public Property 取引ヘッダー() As ProgramLib.仕入ヘッダー型
        Get
            Return _取引ヘッダー
        End Get
        Set(ByVal value As ProgramLib.仕入ヘッダー型)
            _取引ヘッダー = value
        End Set
    End Property

    Private _取引明細(0 To 999) As ProgramLib.仕入明細型
    Public Property 取引明細(ByVal 行番号 As Integer) As ProgramLib.仕入明細型
        Get
            Return _取引明細(行番号)
        End Get
        Set(ByVal value As ProgramLib.仕入明細型)
            _取引明細(行番号) = value
        End Set
    End Property

#End Region

#Region "取引伝票_仕入"

    Private _仕入伝票更新 As Boolean
    Public Property 仕入伝票更新() As Boolean
        Get
            Return _仕入伝票更新
        End Get
        Set(ByVal value As Boolean)
            _仕入伝票更新 = value
        End Set
    End Property

    Private _仕入伝票更新件数 As Integer
    Public Property 仕入伝票更新件数() As Integer
        Get
            Return _仕入伝票更新件数
        End Get
        Set(ByVal value As Integer)
            _仕入伝票更新件数 = value
        End Set
    End Property

    Private _仕入ヘッダー As ProgramLib.仕入ヘッダー型
    Public Property 仕入ヘッダー() As ProgramLib.仕入ヘッダー型
        Get
            Return _仕入ヘッダー
        End Get
        Set(ByVal value As ProgramLib.仕入ヘッダー型)
            _仕入ヘッダー = value
        End Set
    End Property

    Private _仕入明細(0 To ProgramLib.MAX_DETAIL_COUNT - 1) As ProgramLib.仕入明細型
    Public Property 仕入明細(ByVal 行番号 As Integer) As ProgramLib.仕入明細型
        Get
            Return _仕入明細(行番号)
        End Get
        Set(ByVal value As ProgramLib.仕入明細型)
            _仕入明細(行番号) = value
        End Set
    End Property

    Private _生成消費税行数 As Integer
    Public Property 生成消費税行数() As Integer
        Get
            Return _生成消費税行数
        End Get
        Set(ByVal value As Integer)
            _生成消費税行数 = value
        End Set
    End Property

    Private _既存仕入ヘッダー As ProgramLib.仕入ヘッダー型              'A-2008/07/18_Ver7.30_SAIMU
    Public Property 既存仕入ヘッダー() As ProgramLib.仕入ヘッダー型     'A-2008/07/18_Ver7.30_SAIMU
        Get
            Return _既存仕入ヘッダー
        End Get
        Set(ByVal value As ProgramLib.仕入ヘッダー型)
            _既存仕入ヘッダー = value
        End Set
    End Property

#End Region

#Region "取引伝票_入庫"

    Private _入庫伝票更新 As Boolean
    Public Property 入庫伝票更新() As Boolean
        Get
            Return _入庫伝票更新
        End Get
        Set(ByVal value As Boolean)
            _入庫伝票更新 = value
        End Set
    End Property

    Private _入庫伝票更新件数 As Integer
    Public Property 入庫伝票更新件数() As Integer
        Get
            Return _入庫伝票更新件数
        End Get
        Set(ByVal value As Integer)
            _入庫伝票更新件数 = value
        End Set
    End Property

    Private _入庫ヘッダー As ProgramLib.仕入ヘッダー型
    Public Property 入庫ヘッダー() As ProgramLib.仕入ヘッダー型
        Get
            Return _入庫ヘッダー
        End Get
        Set(ByVal value As ProgramLib.仕入ヘッダー型)
            _入庫ヘッダー = value
        End Set
    End Property

    Private _入庫明細(0 To ProgramLib.MAX_DETAIL_COUNT - 1) As ProgramLib.仕入明細型
    Public Property 入庫明細(ByVal 行番号 As Integer) As ProgramLib.仕入明細型
        Get
            Return _入庫明細(行番号)
        End Get
        Set(ByVal value As ProgramLib.仕入明細型)
            _入庫明細(行番号) = value
        End Set
    End Property

#End Region

#Region "取引伝票_仕掛入庫"

    Private _仕掛入庫伝票更新 As Boolean
    Public Property 仕掛入庫伝票更新() As Boolean
        Get
            Return _仕掛入庫伝票更新
        End Get
        Set(ByVal value As Boolean)
            _仕掛入庫伝票更新 = value
        End Set
    End Property

    Private _仕掛入庫伝票更新件数 As Integer
    Public Property 仕掛入庫伝票更新件数() As Integer
        Get
            Return _仕掛入庫伝票更新件数
        End Get
        Set(ByVal value As Integer)
            _仕掛入庫伝票更新件数 = value
        End Set
    End Property

    Private _仕掛入庫ヘッダー As ProgramLib.仕入ヘッダー型
    Public Property 仕掛入庫ヘッダー() As ProgramLib.仕入ヘッダー型
        Get
            Return _仕掛入庫ヘッダー
        End Get
        Set(ByVal value As ProgramLib.仕入ヘッダー型)
            _仕掛入庫ヘッダー = value
        End Set
    End Property

    Private _仕掛入庫明細(0 To ProgramLib.MAX_DETAIL_COUNT - 1) As ProgramLib.仕入明細型
    Public Property 仕掛入庫明細(ByVal 行番号 As Integer) As ProgramLib.仕入明細型
        Get
            Return _仕掛入庫明細(行番号)
        End Get
        Set(ByVal value As ProgramLib.仕入明細型)
            _仕掛入庫明細(行番号) = value
        End Set
    End Property

#End Region

#Region "ロット明細"

    Private _ロット明細(0 To ProgramLib.MAX_DETAIL_COUNT - 1) As ProgramLib.ロット明細型
    Public Property ロット明細(ByVal 行番号 As Integer) As ProgramLib.ロット明細型
        Get
            Return _ロット明細(行番号)
        End Get
        Set(ByVal value As ProgramLib.ロット明細型)
            _ロット明細(行番号) = value
        End Set
    End Property

#End Region

#Region "入出荷伝票"

    Private _入荷伝票更新 As Boolean
    Public Property 入荷伝票更新() As Boolean
        Get
            Return _入荷伝票更新
        End Get
        Set(ByVal value As Boolean)
            _入荷伝票更新 = value
        End Set
    End Property

    Private _入荷伝票更新件数 As Integer
    Public Property 入荷伝票更新件数() As Integer
        Get
            Return _入荷伝票更新件数
        End Get
        Set(ByVal value As Integer)
            _入荷伝票更新件数 = value
        End Set
    End Property

    Private _入荷ヘッダー As ProgramLib.入出荷ヘッダー型
    Public Property 入荷ヘッダー() As ProgramLib.入出荷ヘッダー型
        Get
            Return _入荷ヘッダー
        End Get
        Set(ByVal value As ProgramLib.入出荷ヘッダー型)
            _入荷ヘッダー = value
        End Set
    End Property

    Private _入荷明細(0 To ProgramLib.MAX_DETAIL_COUNT - 1) As ProgramLib.入出荷明細型
    Public Property 入荷明細(ByVal 行番号 As Integer) As ProgramLib.入出荷明細型
        Get
            Return _入荷明細(行番号)
        End Get
        Set(ByVal value As ProgramLib.入出荷明細型)
            _入荷明細(行番号) = value
        End Set
    End Property

#End Region

#Region "支払管理"      'A-2008/07/18_Ver7.30_SHIHARAI

    Private _支払予定(0 To ProgramLib.MAX_DETAIL_COUNT - 1) As ProgramLib.支払予定テーブル型    'A-2008/07/18_Ver7.30_SHIHARAI
    Public Property 支払予定(ByVal 行番号 As Integer) As ProgramLib.支払予定テーブル型          'A-2008/07/18_Ver7.30_SHIHARAI
        Get
            Return _支払予定(行番号)
        End Get
        Set(ByVal value As ProgramLib.支払予定テーブル型)
            _支払予定(行番号) = value
        End Set
    End Property

    Private _支払予定行数 As Integer            'A-2008/07/18_Ver7.30_SHIHARAI
    Public Property 支払予定行数() As Integer   'A-2008/07/18_Ver7.30_SHIHARAI
        Get
            Return _支払予定行数
        End Get
        Set(ByVal value As Integer)
            _支払予定行数 = value
        End Set
    End Property

    Private _支払予定更新区分 As DB更新区分型           'A-2008/07/18_Ver7.30_SHIHARAI
    Public Property 支払予定更新区分() As DB更新区分型  'A-2008/07/18_Ver7.30_SHIHARAI
        Get
            Return _支払予定更新区分
        End Get
        Set(ByVal value As DB更新区分型)
            _支払予定更新区分 = value
        End Set
    End Property

    Private _既存支払予定データあり As Boolean          'A-2008/07/18_Ver7.30_SHIHARAI
    Public Property 既存支払予定データあり() As Boolean 'A-2008/07/18_Ver7.30_SHIHARAI
        Get
            Return _既存支払予定データあり
        End Get
        Set(ByVal value As Boolean)
            _既存支払予定データあり = value
        End Set
    End Property

    Private _支払単位 As 支払管理定義型.支払管理単位型              'A-2008/07/18_Ver7.30_SHIHARAI
    Public Property 支払単位() As 支払管理定義型.支払管理単位型     'A-2008/07/18_Ver7.30_SHIHARAI
        Get
            Return _支払単位
        End Get
        Set(ByVal value As 支払管理定義型.支払管理単位型)
            _支払単位 = value
        End Set
    End Property

#End Region

#Region "コントロールテーブル"

    Private _連番管理テーブル As ProgramLib.連番管理テーブル型
    Public Property 連番管理テーブル() As ProgramLib.連番管理テーブル型
        Get
            Return _連番管理テーブル
        End Get
        Set(ByVal value As ProgramLib.連番管理テーブル型)
            _連番管理テーブル = value
        End Set
    End Property

    Private _伝票番号管理テーブル As ProgramLib.伝票番号管理テーブル型
    Public Property 伝票番号管理テーブル() As ProgramLib.伝票番号管理テーブル型
        Get
            Return _伝票番号管理テーブル
        End Get
        Set(ByVal value As ProgramLib.伝票番号管理テーブル型)
            _伝票番号管理テーブル = value
        End Set
    End Property

    Private _ロットNo連番管理テーブル As ProgramLib.ロットNo連番管理テーブル型          'A-2009/12/18_Ver7.40_LOT
    Public Property ロットNo連番管理テーブル() As ProgramLib.ロットNo連番管理テーブル型 'A-2009/12/18_Ver7.40_LOT
        Get
            Return _ロットNo連番管理テーブル
        End Get
        Set(ByVal value As ProgramLib.ロットNo連番管理テーブル型)
            _ロットNo連番管理テーブル = value
        End Set
    End Property

#End Region

#Region "仕訳作成日付管理テーブル"

    Private _仕訳作成日付_元伝票 As Integer
    Public Property 仕訳作成日付_元伝票() As Integer
        Get
            Return _仕訳作成日付_元伝票
        End Get
        Set(ByVal value As Integer)
            _仕訳作成日付_元伝票 = value
        End Set
    End Property

    Private _仕訳対象外区分_元伝票 As Integer
    Public Property 仕訳対象外区分_元伝票() As Integer
        Get
            Return _仕訳対象外区分_元伝票
        End Get
        Set(ByVal value As Integer)
            _仕訳対象外区分_元伝票 = value
        End Set
    End Property

#End Region

#Region "ストアド用"

    Private _自動生成区分 As Integer
    Public Property 自動生成区分() As Integer
        Get
            Return _自動生成区分
        End Get
        Set(ByVal value As Integer)
            _自動生成区分 = value
        End Set
    End Property

    Private _ストアドパラメータ_INSERT As ProgramLib.ストアドパラメータ_出庫
    Public Property ストアドパラメータ_INSERT() As ProgramLib.ストアドパラメータ_出庫
        Get
            Return _ストアドパラメータ_INSERT
        End Get
        Set(ByVal value As ProgramLib.ストアドパラメータ_出庫)
            _ストアドパラメータ_INSERT = value
        End Set
    End Property

    Private _ストアドパラメータ_DELETE As ProgramLib.ストアドパラメータ_出庫
    Public Property ストアドパラメータ_DELETE() As ProgramLib.ストアドパラメータ_出庫
        Get
            Return _ストアドパラメータ_DELETE
        End Get
        Set(ByVal value As ProgramLib.ストアドパラメータ_出庫)
            _ストアドパラメータ_DELETE = value
        End Set
    End Property

    Private _ストアドパラメータ_原価_入庫_INSERT As ProgramLib.ストアドパラメータ_原価
    Public Property ストアドパラメータ_原価_入庫_INSERT() As ProgramLib.ストアドパラメータ_原価
        Get
            Return _ストアドパラメータ_原価_入庫_INSERT
        End Get
        Set(ByVal value As ProgramLib.ストアドパラメータ_原価)
            _ストアドパラメータ_原価_入庫_INSERT = value
        End Set
    End Property

    Private _ストアドパラメータ_原価_入庫_DELETE As ProgramLib.ストアドパラメータ_原価
    Public Property ストアドパラメータ_原価_入庫_DELETE() As ProgramLib.ストアドパラメータ_原価
        Get
            Return _ストアドパラメータ_原価_入庫_DELETE
        End Get
        Set(ByVal value As ProgramLib.ストアドパラメータ_原価)
            _ストアドパラメータ_原価_入庫_DELETE = value
        End Set
    End Property

    Private _ストアドパラメータ_原価_出庫_INSERT As ProgramLib.ストアドパラメータ_原価
    Public Property ストアドパラメータ_原価_出庫_INSERT() As ProgramLib.ストアドパラメータ_原価
        Get
            Return _ストアドパラメータ_原価_出庫_INSERT
        End Get
        Set(ByVal value As ProgramLib.ストアドパラメータ_原価)
            _ストアドパラメータ_原価_出庫_INSERT = value
        End Set
    End Property

    Private _ストアドパラメータ_原価_出庫_DELETE As ProgramLib.ストアドパラメータ_原価
    Public Property ストアドパラメータ_原価_出庫_DELETE() As ProgramLib.ストアドパラメータ_原価
        Get
            Return _ストアドパラメータ_原価_出庫_DELETE
        End Get
        Set(ByVal value As ProgramLib.ストアドパラメータ_原価)
            _ストアドパラメータ_原価_出庫_DELETE = value
        End Set
    End Property

    Private _ストアドパラメータ_仕入_INSERT As ProgramLib.ストアドパラメータ_仕入
    Public Property ストアドパラメータ_仕入_INSERT() As ProgramLib.ストアドパラメータ_仕入
        Get
            Return _ストアドパラメータ_仕入_INSERT
        End Get
        Set(ByVal value As ProgramLib.ストアドパラメータ_仕入)
            _ストアドパラメータ_仕入_INSERT = value
        End Set
    End Property

    Private _ストアドパラメータ_仕入_DELETE As ProgramLib.ストアドパラメータ_仕入
    Public Property ストアドパラメータ_仕入_DELETE() As ProgramLib.ストアドパラメータ_仕入
        Get
            Return _ストアドパラメータ_仕入_DELETE
        End Get
        Set(ByVal value As ProgramLib.ストアドパラメータ_仕入)
            _ストアドパラメータ_仕入_DELETE = value
        End Set
    End Property

    Private _ストアドパラメータ_入庫_INSERT As ProgramLib.ストアドパラメータ_入庫
    Public Property ストアドパラメータ_入庫_INSERT() As ProgramLib.ストアドパラメータ_入庫
        Get
            Return _ストアドパラメータ_入庫_INSERT
        End Get
        Set(ByVal value As ProgramLib.ストアドパラメータ_入庫)
            _ストアドパラメータ_入庫_INSERT = value
        End Set
    End Property

    Private _ストアドパラメータ_入庫_DELETE As ProgramLib.ストアドパラメータ_入庫
    Public Property ストアドパラメータ_入庫_DELETE() As ProgramLib.ストアドパラメータ_入庫
        Get
            Return _ストアドパラメータ_入庫_DELETE
        End Get
        Set(ByVal value As ProgramLib.ストアドパラメータ_入庫)
            _ストアドパラメータ_入庫_DELETE = value
        End Set
    End Property

    Private _ストアドパラメータ_ロット明細_INSERT As ProgramLib.ストアドパラメータ_ロット明細
    Public Property ストアドパラメータ_ロット明細_INSERT() As ProgramLib.ストアドパラメータ_ロット明細
        Get
            Return _ストアドパラメータ_ロット明細_INSERT
        End Get
        Set(ByVal value As ProgramLib.ストアドパラメータ_ロット明細)
            _ストアドパラメータ_ロット明細_INSERT = value
        End Set
    End Property

    Private _ストアドパラメータ_ロット明細_DELETE As ProgramLib.ストアドパラメータ_ロット明細
    Public Property ストアドパラメータ_ロット明細_DELETE() As ProgramLib.ストアドパラメータ_ロット明細
        Get
            Return _ストアドパラメータ_ロット明細_DELETE
        End Get
        Set(ByVal value As ProgramLib.ストアドパラメータ_ロット明細)
            _ストアドパラメータ_ロット明細_DELETE = value
        End Set
    End Property

    'A-20111105_1↓
    Private _ストアドパラメータ_INSERT_出庫_移動有 As ProgramLib.ストアドパラメータ_出庫
    Public Property ストアドパラメータ_INSERT_出庫_移動有() As ProgramLib.ストアドパラメータ_出庫
        Get
            Return _ストアドパラメータ_INSERT_出庫_移動有
        End Get
        Set(ByVal value As ProgramLib.ストアドパラメータ_出庫)
            _ストアドパラメータ_INSERT_出庫_移動有 = value
        End Set
    End Property

    Private _ストアドパラメータ_INSERT_入庫_移動有 As ProgramLib.ストアドパラメータ_出庫
    Public Property ストアドパラメータ_INSERT_入庫_移動有() As ProgramLib.ストアドパラメータ_出庫
        Get
            Return _ストアドパラメータ_INSERT_入庫_移動有
        End Get
        Set(ByVal value As ProgramLib.ストアドパラメータ_出庫)
            _ストアドパラメータ_INSERT_入庫_移動有 = value
        End Set
    End Property

    'A-20111105_1↑

    'A-CUST20190830↓
    Private _ストアドパラメータ_入出庫_INSERT_自分 As ProgramLib.ストアドパラメータ_入出庫
    Public Property ストアドパラメータ_入出庫_INSERT_自分() As ProgramLib.ストアドパラメータ_入出庫
        Get
            Return _ストアドパラメータ_入出庫_INSERT_自分
        End Get
        Set(ByVal value As ProgramLib.ストアドパラメータ_入出庫)
            _ストアドパラメータ_入出庫_INSERT_自分 = value
        End Set
    End Property

    Private _ストアドパラメータ_入出庫_INSERT_相手 As ProgramLib.ストアドパラメータ_入出庫
    Public Property ストアドパラメータ_入出庫_INSERT_相手() As ProgramLib.ストアドパラメータ_入出庫
        Get
            Return _ストアドパラメータ_入出庫_INSERT_相手
        End Get
        Set(ByVal value As ProgramLib.ストアドパラメータ_入出庫)
            _ストアドパラメータ_入出庫_INSERT_相手 = value
        End Set
    End Property
    'A-CUST20190830↑

#End Region

#Region "製造実績更新"

    Private _製造実績更新 As Boolean
    Public Property 製造実績更新() As Boolean
        Get
            Return _製造実績更新
        End Get
        Set(ByVal value As Boolean)
            _製造実績更新 = value
        End Set
    End Property

    Private _製造実績更新_製造出庫 As DataTable
    Public Property 製造実績更新_製造出庫() As DataTable
        Get
            Return _製造実績更新_製造出庫
        End Get
        Set(ByVal value As DataTable)
            _製造実績更新_製造出庫 = value.Copy
        End Set
    End Property

    Private _製造実績更新_個別出庫 As DataTable
    Public Property 製造実績更新_個別出庫() As DataTable
        Get
            Return _製造実績更新_個別出庫
        End Get
        Set(ByVal value As DataTable)
            _製造実績更新_個別出庫 = value.Copy
        End Set
    End Property

    Private _製造実績更新_完成入庫 As DataTable
    Public Property 製造実績更新_完成入庫() As DataTable
        Get
            Return _製造実績更新_完成入庫
        End Get
        Set(ByVal value As DataTable)
            _製造実績更新_完成入庫 = value.Copy
        End Set
    End Property

    Private _製造実績部品関連 As ProgramLib.製造実績部品関連型
    Public Property 製造実績部品関連() As ProgramLib.製造実績部品関連型
        Get
            Return _製造実績部品関連
        End Get
        Set(ByVal value As ProgramLib.製造実績部品関連型)
            _製造実績部品関連 = value
        End Set
    End Property

#End Region

#Region "受入索引"

    Private _受入索引更新 As Boolean
    Public Property 受入索引更新() As Boolean
        Get
            Return _受入索引更新
        End Get
        Set(ByVal value As Boolean)
            _受入索引更新 = value
        End Set
    End Property

    Private _修正前受入索引連番 As Long
    Public Property 修正前受入索引連番() As Long
        Get
            Return _修正前受入索引連番
        End Get
        Set(ByVal value As Long)
            _修正前受入索引連番 = value
        End Set
    End Property

    Private _受入索引テーブル As ProgramLib.受入索引テーブル型
    Public Property 受入索引テーブル() As ProgramLib.受入索引テーブル型
        Get
            Return _受入索引テーブル
        End Get
        Set(ByVal value As ProgramLib.受入索引テーブル型)
            _受入索引テーブル = value
        End Set
    End Property

#End Region

#Region "製番マスタ"

    Private _製番マスタ更新 As Boolean
    Public Property 製番マスタ更新() As Boolean
        Get
            Return _製番マスタ更新
        End Get
        Set(ByVal value As Boolean)
            _製番マスタ更新 = value
        End Set
    End Property

    Private _製番マスタ更新件数 As Integer
    Public Property 製番マスタ更新件数() As Integer
        Get
            Return _製番マスタ更新件数
        End Get
        Set(ByVal value As Integer)
            _製番マスタ更新件数 = value
        End Set
    End Property

    Private _製番マスタ(0 To 999) As ProgramLib.製番マスター型
    Public Property 製番マスタ(ByVal index As Integer) As ProgramLib.製番マスター型
        Get
            Return _製番マスタ(index)
        End Get
        Set(ByVal value As ProgramLib.製番マスター型)
            _製番マスタ(index) = value
        End Set
    End Property

    'A-20111025_3↓
    Private _手入力製番マスタ更新 As Boolean
    Public Property 手入力製番マスタ更新() As Boolean
        Get
            Return _手入力製番マスタ更新
        End Get
        Set(ByVal value As Boolean)
            _手入力製番マスタ更新 = value
        End Set
    End Property

    Private _手入力製番マスタ更新件数 As Integer
    Public Property 手入力製番マスタ更新件数() As Integer
        Get
            Return _手入力製番マスタ更新件数
        End Get
        Set(ByVal value As Integer)
            _手入力製番マスタ更新件数 = value
        End Set
    End Property

    Private _手入力製番マスタ() As ProgramLib.製番マスター型
    Public Property 手入力製番マスタ(ByVal index As Integer) As ProgramLib.製番マスター型
        Get
            Return _手入力製番マスタ(index)
        End Get
        Set(ByVal value As ProgramLib.製番マスター型)
            _手入力製番マスタ(index) = value
        End Set
    End Property

    Private _既存手入力製番マスタ更新 As Boolean
    Public Property 既存手入力製番マスタ更新() As Boolean
        Get
            Return _既存手入力製番マスタ更新
        End Get
        Set(ByVal value As Boolean)
            _既存手入力製番マスタ更新 = value
        End Set
    End Property

    Private _既存手入力製番マスタ更新件数 As Integer
    Public Property 既存手入力製番マスタ更新件数() As Integer
        Get
            Return _既存手入力製番マスタ更新件数
        End Get
        Set(ByVal value As Integer)
            _既存手入力製番マスタ更新件数 = value
        End Set
    End Property

    Private _既存手入力製番マスタ() As ProgramLib.製番マスター型
    Public Property 既存手入力製番マスタ(ByVal index As Integer) As ProgramLib.製番マスター型
        Get
            Return _既存手入力製番マスタ(index)
        End Get
        Set(ByVal value As ProgramLib.製番マスター型)
            _既存手入力製番マスタ(index) = value
        End Set
    End Property

    Private _製番マスタ_更新用 As ProgramLib.製番マスター型
    Public Property 製番マスタ_更新用() As ProgramLib.製番マスター型
        Get
            Return _製番マスタ_更新用
        End Get
        Set(ByVal value As ProgramLib.製番マスター型)
            _製番マスタ_更新用 = value
        End Set
    End Property
    'A-20111025_3↑

#End Region

#Region "ロットNo管理"

    Private _ロット連番管理 As ProgramLib.ロット連番管理テーブル型
    Public Property ロット連番管理() As ProgramLib.ロット連番管理テーブル型
        Get
            Return _ロット連番管理
        End Get
        Set(ByVal value As ProgramLib.ロット連番管理テーブル型)
            _ロット連番管理 = value
        End Set
    End Property

#End Region

#Region "その他"

    Private _計上区分 As Integer
    Public Property 計上区分() As Integer
        Get
            Return _計上区分
        End Get
        Set(ByVal value As Integer)
            _計上区分 = value
        End Set
    End Property

    Private _更新前処理連番_仕入伝票 As Long
    Public Property 更新前処理連番_仕入伝票() As Long
        Get
            Return _更新前処理連番_仕入伝票
        End Get
        Set(ByVal value As Long)
            _更新前処理連番_仕入伝票 = value
        End Set
    End Property

    Private _更新前処理連番_入荷伝票 As Long
    Public Property 更新前処理連番_入荷伝票() As Long
        Get
            Return _更新前処理連番_入荷伝票
        End Get
        Set(ByVal value As Long)
            _更新前処理連番_入荷伝票 = value
        End Set
    End Property

    'A-20121217_Ver7.50_1↓
    Private _外貨取引先 As Boolean
    Public Property 外貨取引先() As Boolean
        Get
            Return _外貨取引先
        End Get
        Set(ByVal value As Boolean)
            _外貨取引先 = value
        End Set
    End Property
    'A-20121217_Ver7.50_1↑

#End Region

    'A-20121217_Ver7.50_2↓
#Region "受注在庫引当"

    Private _在庫引当更新対象 As Boolean
    Public Property 在庫引当更新対象() As Boolean
        Get
            Return _在庫引当更新対象
        End Get
        Set(ByVal value As Boolean)
            _在庫引当更新対象 = value
        End Set
    End Property

    Private _在庫引当解除対象 As Boolean
    Public Property 在庫引当解除対象() As Boolean
        Get
            Return _在庫引当解除対象
        End Get
        Set(ByVal value As Boolean)
            _在庫引当解除対象 = value
        End Set
    End Property

    Private _需要元受注伝票存在 As Boolean
    Public Property 需要元受注伝票存在() As Boolean
        Get
            Return _需要元受注伝票存在
        End Get
        Set(ByVal value As Boolean)
            _需要元受注伝票存在 = value
        End Set
    End Property

    Private _在庫引当更新_連番 As Long
    Public Property 在庫引当更新_連番() As Long
        Get
            Return _在庫引当更新_連番
        End Get
        Set(ByVal value As Long)
            _在庫引当更新_連番 = value
        End Set
    End Property

    Private _在庫引当更新_行 As Integer
    Public Property 在庫引当更新_行() As Integer
        Get
            Return _在庫引当更新_行
        End Get
        Set(ByVal value As Integer)
            _在庫引当更新_行 = value
        End Set
    End Property

    Private _発注区分 As Integer
    Public Property 発注区分() As Integer
        Get
            Return _発注区分
        End Get
        Set(ByVal value As Integer)
            _発注区分 = value
        End Set
    End Property

    Private _在庫引当情報 As DataTable
    Public Property 在庫引当情報() As DataTable
        Get
            Return _在庫引当情報
        End Get
        Set(ByVal value As DataTable)
            _在庫引当情報 = value.Copy
        End Set
    End Property

#End Region
    'A-20121217_Ver7.50_2↑

    'A-CUST20190830↓
#Region "カスタマイズ"
    Private _取込種別 As 伝票種別型
    Public Property 取込種別() As 伝票種別型
        Get
            Return _取込種別
        End Get
        Set(ByVal value As 伝票種別型)
            _取込種別 = value
        End Set
    End Property

    Private _入庫伝票更新_自分 As Boolean
    Public Property 入庫伝票更新_自分() As Boolean
        Get
            Return _入庫伝票更新_自分
        End Get
        Set(ByVal value As Boolean)
            _入庫伝票更新_自分 = value
        End Set
    End Property

    Private _入庫伝票更新件数_自分 As Integer
    Public Property 入庫伝票更新件数_自分() As Integer
        Get
            Return _入庫伝票更新件数_自分
        End Get
        Set(ByVal value As Integer)
            _入庫伝票更新件数_自分 = value
        End Set
    End Property

    Private _入庫ヘッダー_自分 As ProgramLib.仕入ヘッダー型
    Public Property 入庫ヘッダー_自分() As ProgramLib.仕入ヘッダー型
        Get
            Return _入庫ヘッダー_自分
        End Get
        Set(ByVal value As ProgramLib.仕入ヘッダー型)
            _入庫ヘッダー_自分 = value
        End Set
    End Property

    Private _入庫明細_自分(0 To ProgramLib.MAX_DETAIL_COUNT - 1) As ProgramLib.仕入明細型
    Public Property 入庫明細_自分(ByVal 行番号 As Integer) As ProgramLib.仕入明細型
        Get
            Return _入庫明細_自分(行番号)
        End Get
        Set(ByVal value As ProgramLib.仕入明細型)
            _入庫明細_自分(行番号) = value
        End Set
    End Property

#Region "ロット明細"

    Private _ロット明細_自分(0 To ProgramLib.MAX_DETAIL_COUNT - 1) As ProgramLib.ロット明細型
    Public Property ロット明細_自分(ByVal 行番号 As Integer) As ProgramLib.ロット明細型
        Get
            Return _ロット明細_自分(行番号)
        End Get
        Set(ByVal value As ProgramLib.ロット明細型)
            _ロット明細_自分(行番号) = value
        End Set
    End Property

#End Region


    Private _出庫伝票更新_相手 As Boolean
    Public Property 出庫伝票更新_相手() As Boolean
        Get
            Return _出庫伝票更新_相手
        End Get
        Set(ByVal value As Boolean)
            _出庫伝票更新_相手 = value
        End Set
    End Property

    Private _出庫伝票更新件数_相手 As Integer
    Public Property 出庫伝票更新件数_相手() As Integer
        Get
            Return _出庫伝票更新件数_相手
        End Get
        Set(ByVal value As Integer)
            _出庫伝票更新件数_相手 = value
        End Set
    End Property

    Private _出庫ヘッダー_相手 As ProgramLib.仕入ヘッダー型
    Public Property 出庫ヘッダー_相手() As ProgramLib.仕入ヘッダー型
        Get
            Return _出庫ヘッダー_相手
        End Get
        Set(ByVal value As ProgramLib.仕入ヘッダー型)
            _出庫ヘッダー_相手 = value
        End Set
    End Property

    Private _出庫明細_相手(0 To ProgramLib.MAX_DETAIL_COUNT - 1) As ProgramLib.仕入明細型
    Public Property 出庫明細_相手(ByVal 行番号 As Integer) As ProgramLib.仕入明細型
        Get
            Return _出庫明細_相手(行番号)
        End Get
        Set(ByVal value As ProgramLib.仕入明細型)
            _出庫明細_相手(行番号) = value
        End Set
    End Property

#Region "ロット明細"

    Private _ロット明細_相手(0 To ProgramLib.MAX_DETAIL_COUNT - 1) As ProgramLib.ロット明細型
    Public Property ロット明細_相手(ByVal 行番号 As Integer) As ProgramLib.ロット明細型
        Get
            Return _ロット明細_相手(行番号)
        End Get
        Set(ByVal value As ProgramLib.ロット明細型)
            _ロット明細_相手(行番号) = value
        End Set
    End Property

#End Region
#End Region
    'A-CUST20190830↑

#End Region

End Class
