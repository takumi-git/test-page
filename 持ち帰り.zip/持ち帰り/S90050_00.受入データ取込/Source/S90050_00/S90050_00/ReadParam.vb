﻿'A-CUST20190830↓
<Serializable>
Public Class ReadParam
    Public Enum 項目名型 As Integer
        受発注番号
        受発注行番号
        内訳NO

        CA01KEY

        入庫予定番号
        入庫予定行番号
        商品コード
    End Enum

    Public Sub New()
        _container = New Hashtable
    End Sub

    Private _container As IDictionary
    Public Property Container(ByVal key As 項目名型) As Object
        Get
            If _container.Contains(key.ToString) = True Then
                Return _container.Item(key.ToString)
            Else
                Return Nothing
            End If
        End Get
        Set(ByVal value As Object)
            If _container.Contains(key.ToString) = True Then
                _container.Item(key.ToString) = value
            Else
                _container.Add(key.ToString, value)
            End If
        End Set
    End Property

    Public Property Container(ByVal key As String) As Object
        Get
            If _container.Contains(key) = True Then
                Return _container.Item(key)
            Else
                Return Nothing
            End If
        End Get
        Set(ByVal value As Object)
            If _container.Contains(key) = True Then
                _container.Item(key) = value
            Else
                _container.Add(key, value)
            End If
        End Set
    End Property
End Class
'A-CUST20190830↑
