﻿<Serializable()> _
Public Class My項目名称Param型

#Region "販売購買"

    Private _販売営業所 As String
    Public Property 販売営業所() As String
        Get
            Return _販売営業所
        End Get
        Set(ByVal value As String)
            _販売営業所 = value
        End Set
    End Property

    Private _販売仕入先 As String
    Public Property 販売仕入先() As String
        Get
            Return _販売仕入先
        End Get
        Set(ByVal value As String)
            _販売仕入先 = value
        End Set
    End Property

    Private _販売仕入担当者_項目 As String
    Public Property 販売仕入担当者_項目() As String
        Get
            Return _販売仕入担当者_項目
        End Get
        Set(ByVal value As String)
            _販売仕入担当者_項目 = value
        End Set
    End Property

    Private _販売部門 As String
    Public Property 販売部門() As String
        Get
            Return _販売部門
        End Get
        Set(ByVal value As String)
            _販売部門 = value
        End Set
    End Property

    Private _販売倉庫 As String
    Public Property 販売倉庫() As String
        Get
            Return _販売倉庫
        End Get
        Set(ByVal value As String)
            _販売倉庫 = value
        End Set
    End Property

    Private _販売商品 As String
    Public Property 販売商品() As String
        Get
            Return _販売商品
        End Get
        Set(ByVal value As String)
            _販売商品 = value
        End Set
    End Property

    Private _販売得意先 As String               'A-2008/07/18_Ver7.30_GENKA
    Public Property 販売得意先() As String      'A-2008/07/18_Ver7.30_GENKA
        Get
            Return _販売得意先
        End Get
        Set(ByVal value As String)
            _販売得意先 = value
        End Set
    End Property

    Private _販売原価集計 As String             'A-2008/07/18_Ver7.30_GENKA
    Public Property 販売原価集計() As String    'A-2008/07/18_Ver7.30_GENKA
        Get
            Return _販売原価集計
        End Get
        Set(ByVal value As String)
            _販売原価集計 = value
        End Set
    End Property

    Private _販売原価集計メイン As String           'A-2008/07/18_Ver7.30_GENKA
    Public Property 販売原価集計メイン() As String  'A-2008/07/18_Ver7.30_GENKA
        Get
            Return _販売原価集計メイン
        End Get
        Set(ByVal value As String)
            _販売原価集計メイン = value
        End Set
    End Property

    Private _販売原価集計サブ As String             'A-2008/07/18_Ver7.30_GENKA
    Public Property 販売原価集計サブ() As String    'A-2008/07/18_Ver7.30_GENKA
        Get
            Return _販売原価集計サブ
        End Get
        Set(ByVal value As String)
            _販売原価集計サブ = value
        End Set
    End Property

    Private _要素タイトル As String             'A-2008/07/18_Ver7.30_GENKA
    Public Property 要素タイトル() As String    'A-2008/07/18_Ver7.30_GENKA
        Get
            Return _要素タイトル
        End Get
        Set(ByVal value As String)
            _要素タイトル = value
        End Set
    End Property

    Private _販売換算数量 As String             'A-2009/12/18_Ver7.40_UCHIWAKE
    Public Property 販売換算数量() As String    'A-2009/12/18_Ver7.40_UCHIWAKE
        Get
            Return _販売換算数量
        End Get
        Set(ByVal value As String)
            _販売換算数量 = value
        End Set
    End Property

    Private _販売単位換算数量 As String             'A-2009/12/18_Ver7.40_UCHIWAKE
    Public Property 販売単位換算数量() As String    'A-2009/12/18_Ver7.40_UCHIWAKE
        Get
            Return _販売単位換算数量
        End Get
        Set(ByVal value As String)
            _販売単位換算数量 = value
        End Set
    End Property

    Private _販売ロット As String               'A-2009/12/18_Ver7.40_LOT
    Public Property 販売ロット() As String      'A-2009/12/18_Ver7.40_LOT
        Get
            Return _販売ロット
        End Get
        Set(ByVal value As String)
            _販売ロット = value
        End Set
    End Property

    Private _販売ロットNo As String             'A-2009/12/18_Ver7.40_LOT
    Public Property 販売ロットNo() As String    'A-2009/12/18_Ver7.40_LOT
        Get
            Return _販売ロットNo
        End Get
        Set(ByVal value As String)
            _販売ロットNo = value
        End Set
    End Property

    Private _販売サブロットNo As String             'A-2009/12/18_Ver7.40_LOT
    Public Property 販売サブロットNo() As String    'A-2009/12/18_Ver7.40_LOT
        Get
            Return _販売サブロットNo
        End Get
        Set(ByVal value As String)
            _販売サブロットNo = value
        End Set
    End Property

    Private _販売品目名１ As String
    Public Property 販売品目名１() As String
        Get
            Return _販売品目名１
        End Get
        Set(ByVal value As String)
            _販売品目名１ = value
        End Set
    End Property

    Private _販売品目名２ As String
    Public Property 販売品目名２() As String
        Get
            Return _販売品目名２
        End Get
        Set(ByVal value As String)
            _販売品目名２ = value
        End Set
    End Property

    Private _販売品目名３ As String
    Public Property 販売品目名３() As String
        Get
            Return _販売品目名３
        End Get
        Set(ByVal value As String)
            _販売品目名３ = value
        End Set
    End Property

    Private _販売客先注番 As String
    Public Property 販売客先注番() As String
        Get
            Return _販売客先注番
        End Get
        Set(ByVal value As String)
            _販売客先注番 = value
        End Set
    End Property

    Private _販売有効期限 As String
    Public Property 販売有効期限() As String
        Get
            Return _販売有効期限
        End Get
        Set(ByVal value As String)
            _販売有効期限 = value
        End Set
    End Property

#End Region

#Region "会計"  'A-2009/12/18_Ver7.40_PRO

    Private _会計完成 As String             'A-2009/12/18_Ver7.40_PRO
    Public Property 会計完成() As String    'A-2009/12/18_Ver7.40_PRO
        Get
            Return _会計完成
        End Get
        Set(ByVal value As String)
            _会計完成 = value
        End Set
    End Property

#End Region

End Class
