﻿''' <summary>
''' 販売購買コントロール情報
''' </summary>
''' <remarks></remarks>
Public Class Myコントロール情報型

    Private _オプション区分 As OSK.X1.SEI.LIB.ControlInfoC001.オプション区分型    'X1変換Tool-20170508
    Private _機能区分 As OSK.X1.SEI.LIB.ControlInfoC001.機能区分型    'X1変換Tool-20170508
    Private _初期値 As OSK.X1.SEI.LIB.ControlInfoC001.初期値型    'X1変換Tool-20170508
    Private _仕入処理 As OSK.X1.SEI.LIB.ControlInfoC001.仕入処理型    'X1変換Tool-20170508
    Private _消費税 As OSK.X1.SEI.LIB.ControlInfoC001.消費税型    'X1変換Tool-20170508
    Private _受発注管理 As OSK.X1.SEI.LIB.ControlInfoC001.受発注管理型    'X1変換Tool-20170508
    Private _拡張項目 As OSK.X1.SEI.LIB.ControlInfoC001.拡張項目型    'X1変換Tool-20170508
    Private _ＲＥＶ As OSK.X1.SEI.LIB.ControlInfoC001.ＲＥＶ型        'A-2008/07/18_Ver7.30_GENKA    'X1変換Tool-20170508
    Private _原価管理 As OSK.X1.SEI.LIB.ControlInfoC001.原価管理型    'A-2008/07/18_Ver7.30_GENKA    'X1変換Tool-20170508
    Private _支払管理 As OSK.X1.SEI.LIB.ControlInfoC001.支払管理型    'A-2008/07/18_Ver7.30_SHIHARAI    'X1変換Tool-20170508
    Private _変更履歴 As OSK.X1.SEI.LIB.ControlInfoC001.変更履歴型      'A-2009/08/21_RIREKI    'X1変換Tool-20170508
    Private _商品管理拡張 As SEI.LIB.ControlInfoC001.商品管理拡張型     'A-2009/12/18_Ver7.40_UCHIWAKE
    Private _ロット管理 As SEI.LIB.ControlInfoC001.ロット管理型         'A-2009/12/18_Ver7.40_LOT
    Private _端数処理 As SEI.LIB.ControlInfoC001.端数処理型             'A-2009/12/18_Ver7.40_LOT
    Private _受注在庫引当 As 受注在庫引当型                           'A-20121217_Ver7.50_4
    Private _桁数拡張 As 桁数拡張型                                     'A-20170601-X1-桁数拡張

    Private _MOA追加初期値 As MOA追加初期値型
    Private _MOAオプション As MOAオプション型
    Private _MOAロット管理 As MOAロット管理型
    Private _MOA機能追加 As MOA機能追加型
    Private _MOA受入処理 As MOA受入処理型
    Private _MOAＲＥＶ As OSK.X1.SEI.LIB.ControlInfoC001.MOA_REV型    'X1変換Tool-20170508
    Private _MOA外貨 As MOA外貨型                                     'A-20121217_Ver7.50_1
    Private _MOA在庫引当 As MOA在庫引当型                             'A-20121217_Ver7.50_2

    Private _MOA品目別原価 As MOA品目別原価型                     'A-20150520_1
    Private _MOAその他 As MOAその他型                               'A-20170417_1

    Private _分類種別 As OSK.X1.SEI.LIB.ControlInfoC002.分類種別型    'A-2008/07/18_Ver7.30_GENKA    'X1変換Tool-20170508

    Private _販売財務連動 As BIS.LIB.ControlInfoC001.販売財務連動型
    Private _取引先マスタリンク区分 As BIS.LIB.ControlInfoC001.取引先マスタリンク区分型     'A-2008/07/18_Ver7.30_SAIMU
    Private _プロジェクト原価管理 As BIS.LIB.ControlInfoC001.プロジェクト原価管理型         'A-2009/12/18_Ver7.40_PRO

#Region "■コンストラクタ■"
    Public Sub New()
        _オプション区分 = New オプション区分型
        _機能区分 = New 機能区分型
        _初期値 = New 初期値型
        _仕入処理 = New 仕入処理型
        _消費税 = New 消費税型
        _受発注管理 = New 受発注管理型
        _拡張項目 = New 拡張項目型
        _ＲＥＶ = New ＲＥＶ型          'A-2008/07/18_Ver7.30_GENKA
        _原価管理 = New 原価管理型      'A-2008/07/18_Ver7.30_GENKA
        _支払管理 = New 支払管理型      'A-2008/07/18_Ver7.30_SHIHARAI
        _変更履歴 = New OSK.X1.SEI.LIB.ControlInfoC001.変更履歴型       'A-2009/08/21_RIREKI    'X1変換Tool-20170508
        _商品管理拡張 = New SEI.LIB.ControlInfoC001.商品管理拡張型      'A-2009/12/18_Ver7.40_UCHIWAKE
        _ロット管理 = New SEI.LIB.ControlInfoC001.ロット管理型          'A-2009/12/18_Ver7.40_LOT
        _端数処理 = New SEI.LIB.ControlInfoC001.端数処理型              'A-2009/12/18_Ver7.40_LOT
        _受注在庫引当 = New 受注在庫引当型                              'A-20121217_Ver7.50_4
        _桁数拡張 = New 桁数拡張型                                      'A-20170601-X1-桁数拡張

        _MOA追加初期値 = New MOA追加初期値型
        _MOAオプション = New MOAオプション型
        _MOAロット管理 = New MOAロット管理型
        _MOA機能追加 = New MOA機能追加型
        _MOA受入処理 = New MOA受入処理型
        _MOAＲＥＶ = New MOA_REV型
        _MOA外貨 = New MOA外貨型                                     'A-20121217_Ver7.50_1
        _MOA在庫引当 = New MOA在庫引当型                             'A-20121217_Ver7.50_2

        _MOA品目別原価 = New MOA品目別原価型                    'A-20150520_1
        _MOAその他 = New MOAその他型                            'A-20170417_1

        _分類種別 = New 分類種別型      'A-2008/07/18_Ver7.30_GENKA

        _販売財務連動 = New BIS.LIB.ControlInfoC001.販売財務連動型
        _取引先マスタリンク区分 = New BIS.LIB.ControlInfoC001.取引先マスタリンク区分型      'A-2008/07/18_Ver7.30_SAIMU
        _プロジェクト原価管理 = New BIS.LIB.ControlInfoC001.プロジェクト原価管理型          'A-2009/12/18_Ver7.40_PRO
    End Sub
#End Region

#Region "■プロパティ■"

#Region "ＲＥＶ"    'A-2008/07/18_Ver7.30_GENKA

    Public ReadOnly Property 強化区分() As Decimal  'A-2008/07/18_Ver7.30_GENKA
        Get
            Return _ＲＥＶ.強化区分
        End Get
    End Property

#End Region

#Region "オプション区分"

    Public ReadOnly Property 受発注管理() As OSK.X1.SEI.LIB.ControlInfoC001.オプション区分定義型.区分型    'X1変換Tool-20170508
        Get
            Return _オプション区分.受発注管理
        End Get
    End Property

    Public ReadOnly Property 部門管理() As OSK.X1.SEI.LIB.ControlInfoC001.オプション区分定義型.区分型    'X1変換Tool-20170508
        Get
            Return _オプション区分.部門管理
        End Get
    End Property

    Public ReadOnly Property 拡張項目() As OSK.X1.SEI.LIB.ControlInfoC001.オプション区分定義型.区分型    'X1変換Tool-20170508
        Get
            Return _オプション区分.拡張項目
        End Get
    End Property

    Public ReadOnly Property 原価管理() As OSK.X1.SEI.LIB.ControlInfoC001.オプション区分定義型.区分型   'A-2008/07/18_Ver7.30_GENKA    'X1変換Tool-20170508
        Get
            If 強化区分 >= 3.0 AndAlso
               _オプション区分.原価管理 = オプション区分定義型.区分型.行う Then
                Return オプション区分定義型.区分型.行う
            Else
                Return オプション区分定義型.区分型.行わない
            End If
        End Get
    End Property

    Public ReadOnly Property 支払管理() As OSK.X1.SEI.LIB.ControlInfoC001.オプション区分定義型.区分型   'A-2008/07/18_Ver7.30_SHIHARAI    'X1変換Tool-20170508
        Get
            If 強化区分 >= 3.0 AndAlso
               _オプション区分.支払管理 = オプション区分定義型.区分型.行う Then
                Return オプション区分定義型.区分型.行う
            Else
                Return オプション区分定義型.区分型.行わない
            End If
        End Get
    End Property

    Public ReadOnly Property 商品内訳管理() As Boolean   'A-2009/12/18_Ver7.40_UCHIWAKE
        Get
            If _ＲＥＶ.強化区分 >= 4.0 Then
            Else
                Return False
            End If

            If _オプション区分.商品管理拡張 = オプション区分定義型.区分型.行う Then
            Else
                Return False
            End If

            If 内訳管理数 = 0 Then
                Return False
            End If

            Return True
        End Get
    End Property

    Public ReadOnly Property ロット管理() As Boolean     'A-2009/12/18_Ver7.40_UCHIWAKE
        Get
            If _ＲＥＶ.強化区分 >= 4.0 Then
            Else
                Return False
            End If

            If _オプション区分.ロット管理 = オプション区分定義型.区分型.行う Then
            Else
                Return False
            End If

            Return True
        End Get
    End Property

#End Region

#Region "機能区分"

    Public ReadOnly Property 倉庫別在庫管理() As OSK.X1.SEI.LIB.ControlInfoC001.機能区分定義型.倉庫別在庫管理型    'X1変換Tool-20170508
        Get
            Return _機能区分.倉庫別在庫管理
        End Get
    End Property

    Public ReadOnly Property 商品コード_タイプ() As OSK.X1.SEI.LIB.ControlInfoC001.機能区分定義型.商品コード_タイプ型    'X1変換Tool-20170508
        Get
            Return _機能区分.商品コード.タイプ
        End Get
    End Property

    Public ReadOnly Property 商品コード_桁数() As OSK.X1.SEI.LIB.ControlInfoC001.機能区分定義型.商品コード_桁数型    'X1変換Tool-20170508
        Get
            Return _機能区分.商品コード.桁数
        End Get
    End Property

    Public ReadOnly Property 得意先_仕入先_コード_タイプ() As OSK.X1.SEI.LIB.ControlInfoC001.機能区分定義型.得意先_仕入先_コード_タイプ型    'X1変換Tool-20170508
        Get
            Return _機能区分.得意先_仕入先_コード.タイプ
        End Get
    End Property

    Public ReadOnly Property 得意先_仕入先_コード_桁数() As OSK.X1.SEI.LIB.ControlInfoC001.機能区分定義型.得意先_仕入先_コード_桁数型    'X1変換Tool-20170508
        Get
            Return _機能区分.得意先_仕入先_コード.桁数
        End Get
    End Property

    Public ReadOnly Property 小数以下桁数() As OSK.X1.SEI.LIB.ControlInfoC001.機能区分定義型.小数以下桁数型    'X1変換Tool-20170508
        Get
            Return _機能区分.小数以下桁数
        End Get
    End Property

    Public ReadOnly Property 明細単位処理_受発注引当() As OSK.X1.SEI.LIB.ControlInfoC001.機能区分定義型.受発注引当型    'X1変換Tool-20170508
        Get
            Return _機能区分.明細単位処理.受発注引当
        End Get
    End Property

    Public ReadOnly Property 明細単位処理_消費税計算() As OSK.X1.SEI.LIB.ControlInfoC001.機能区分定義型.消費税計算型    'X1変換Tool-20170508
        Get
            Return _機能区分.明細単位処理.消費税計算
        End Get
    End Property

    Public ReadOnly Property 明細単位処理_倉庫入力() As OSK.X1.SEI.LIB.ControlInfoC001.機能区分定義型.倉庫入力型    'X1変換Tool-20170508
        Get
            Return _機能区分.明細単位処理.倉庫入力
        End Get
    End Property

    Public ReadOnly Property 汎用受入連番区分() As OSK.X1.SEI.LIB.ControlInfoC001.機能区分定義型.汎用受入連番区分型    'X1変換Tool-20170508
        Get
            Return _機能区分.汎用受入連番区分
        End Get
    End Property

    Public ReadOnly Property 担当者コード_タイプ() As OSK.X1.SEI.LIB.ControlInfoC001.機能区分定義型.担当者コード_タイプ型    'X1変換Tool-20170508
        Get
            Return _機能区分.担当者コード.タイプ
        End Get
    End Property

    Public ReadOnly Property 担当者コード_桁数() As OSK.X1.SEI.LIB.ControlInfoC001.機能区分定義型.担当者コード_桁数型    'X1変換Tool-20170508
        Get
            Return _機能区分.担当者コード.桁数
        End Get
    End Property

    Public ReadOnly Property 入数小数桁区分() As OSK.X1.SEI.LIB.ControlInfoC001.機能区分定義型.入数小数桁区分型    'X1変換Tool-20170508
        Get
            Return _機能区分.入数小数桁区分
        End Get
    End Property

    Public ReadOnly Property 消費税改正対応区分() As OSK.X1.SEI.LIB.ControlInfoC001.機能区分定義型.消費税改正対応区分型    'X1変換Tool-20170508
        Get
            Return _機能区分.消費税改正対応区分
        End Get
    End Property

    Public ReadOnly Property 分類コード_タイプ() As OSK.X1.SEI.LIB.ControlInfoC001.機能区分定義型.分類コード_タイプ型   'A-2008/07/18_Ver7.30_GENKA    'X1変換Tool-20170508
        Get
            Return _機能区分.分類コード.タイプ
        End Get
    End Property

    Public ReadOnly Property 分類コード_桁数() As OSK.X1.SEI.LIB.ControlInfoC001.機能区分定義型.分類コード_桁数型       'A-2008/07/18_Ver7.30_GENKA    'X1変換Tool-20170508
        Get
            Return _機能区分.分類コード.桁数
        End Get
    End Property

    Public ReadOnly Property 部門コード_タイプ() As OSK.X1.SEI.LIB.ControlInfoC001.機能区分定義型.部門コード_タイプ型    'X1変換Tool-20170508
        Get
            Return _機能区分.部門コード.タイプ
        End Get
    End Property

    Public ReadOnly Property 部門コード_桁数() As OSK.X1.SEI.LIB.ControlInfoC001.機能区分定義型.部門コード_桁数型    'X1変換Tool-20170508
        Get
            Return _機能区分.部門コード.桁数
        End Get
    End Property

    Public ReadOnly Property 営業所管理() As OSK.X1.SEI.LIB.ControlInfoC001.機能区分定義型.営業所管理区分型    'X1変換Tool-20170508
        Get
            Return _機能区分.営業所管理
        End Get
    End Property

    Public ReadOnly Property 営業所コード_タイプ() As OSK.X1.SEI.LIB.ControlInfoC001.機能区分定義型.営業所コード_タイプ型    'X1変換Tool-20170508
        Get
            Return _機能区分.営業所コード.タイプ
        End Get
    End Property

    Public ReadOnly Property 営業所コード_桁数() As OSK.X1.SEI.LIB.ControlInfoC001.機能区分定義型.営業所コード_桁数型    'X1変換Tool-20170508
        Get
            Return _機能区分.営業所コード.桁数
        End Get
    End Property

    Public ReadOnly Property 注残更新区分() As OSK.X1.SEI.LIB.ControlInfoC001.機能区分定義型.注残更新区分型    'X1変換Tool-20170508
        Get
            Return _機能区分.売上_仕入_テキスト取込コード.注残更新区分
        End Get
    End Property

    Public ReadOnly Property 原価集計コード_タイプ() As OSK.X1.SEI.LIB.ControlInfoC001.機能区分定義型.原価集計コード_タイプ型   'A-2008/07/18_Ver7.30_GENKA    'X1変換Tool-20170508
        Get
            Return _機能区分.原価集計コード.タイプ
        End Get
    End Property

    Public ReadOnly Property 原価集計コード_桁数() As OSK.X1.SEI.LIB.ControlInfoC001.機能区分定義型.原価集計コード_桁数型       'A-2008/07/18_Ver7.30_GENKA    'X1変換Tool-20170508
        Get
            Return _機能区分.原価集計コード.桁数
        End Get
    End Property

    'A-20121217_Ver7.50_2↓
    Public ReadOnly Property 受注在庫引当() As 機能区分定義型.受注在庫引当型
        Get
            If _ＲＥＶ.強化区分 < 3.0 Then
                Return 機能区分定義型.受注在庫引当型.行わない
            End If
            If _MOAＲＥＶ.強化区分 < 4.0 Then
                Return 機能区分定義型.受注在庫引当型.行わない
            End If
            Return _機能区分.受注在庫引当
        End Get
    End Property
    'A-20121217_Ver7.50_2↑

    'A-20121217_Ver7.50_4↓
    Public ReadOnly Property マイナス在庫警告_未検収入荷() As 機能区分定義型.マイナス在庫警告_未検収入荷型
        Get
            If _MOAＲＥＶ.強化区分 < 4.0 Then
                Return 機能区分定義型.マイナス在庫警告_未検収入荷型.含める
            End If
            Return _機能区分.マイナス在庫警告_未検収入荷
        End Get
    End Property
    'A-20121217_Ver7.50_4↑

    'A-CUST20190830↓
    Public ReadOnly Property 在庫評価区分() As 機能区分定義型.在庫評価区分型
        Get
            Return _機能区分.在庫評価区分
        End Get
    End Property

    Public ReadOnly Property 月次移動平均単価補正区分() As 機能区分定義型.月次移動平均単価補正区分型
        Get
            Return _機能区分.月次移動平均単価補正区分
        End Get
    End Property

    Public ReadOnly Property 商品前残金額取得区分() As 機能区分定義型.商品前残金額取得区分型
        Get
            Return _機能区分.商品前残金額取得区分
        End Get
    End Property
    'A-CUST20190830↑

#End Region

#Region "初期値"

    Public ReadOnly Property 初期値_倉庫コード() As String
        Get
            Return _初期値.倉庫コード
        End Get
    End Property

    Public ReadOnly Property 初期値_部門コード_仕入() As String
        Get
            Return _初期値.部門コード.仕入
        End Get
    End Property

    Public ReadOnly Property 初期値_営業所コード() As String
        Get
            Return _初期値.デフォルト営業所CD
        End Get
    End Property

#End Region

#Region "仕入処理"

    Public ReadOnly Property 入数個数使用区分() As OSK.X1.SEI.LIB.ControlInfoC001.仕入処理定義型.入数個数使用区分型    'X1変換Tool-20170508
        Get
            Return _仕入処理.入数個数
        End Get
    End Property

    Public ReadOnly Property 上代使用区分() As OSK.X1.SEI.LIB.ControlInfoC001.仕入処理定義型.上代使用区分型    'X1変換Tool-20170508
        Get
            Return _仕入処理.上代
        End Get
    End Property

#End Region

#Region "消費税"

    Public ReadOnly Property 税抜消費税算出方法_仕入() As OSK.X1.SEI.LIB.ControlInfoC001.消費税定義型.仕入型    'X1変換Tool-20170508
        Get
            Return _消費税.税抜消費税算出方法.仕入
        End Get
    End Property

    Public ReadOnly Property 仮計上消費税使用区分() As OSK.X1.SEI.LIB.ControlInfoC001.消費税定義型.仮計上消費税使用区分型    'X1変換Tool-20170508
        Get
            Return _消費税.仮計上消費税使用区分
        End Get
    End Property

    Public ReadOnly Property 新税率使用区分() As OSK.X1.SEI.LIB.ControlInfoC001.消費税定義型.新税率区分型    'X1変換Tool-20170508
        Get
            Return _消費税.新税率区分
        End Get
    End Property

#End Region

#Region "受発注管理"

    Public ReadOnly Property 売上_仕入_完納区分表示() As OSK.X1.SEI.LIB.ControlInfoC001.受発注管理定義型.完納区分表示型    'X1変換Tool-20170508
        Get
            Return _受発注管理.売上_仕入_完納区分表示
        End Get
    End Property

#End Region

#Region "拡張項目"

    Public ReadOnly Property 拡張項目入力処理画面表示() As OSK.X1.SEI.LIB.ControlInfoC001.拡張項目設計型.利用区分型    'X1変換Tool-20170508
        Get
            Return _拡張項目.拡張項目入力処理画面表示
        End Get
    End Property

#End Region

#Region "原価管理"      'A-2008/07/18_Ver7.30_GENKA

    Public ReadOnly Property 要素使用分類種別() As Integer     'A-2008/07/18_Ver7.30_GENKA
        Get
            Return _原価管理.要素使用分類種別
        End Get
    End Property

    Public ReadOnly Property 明細単位原価集計入力_売上() As 原価管理定義型.明細単位原価集計入力型   'A-2008/07/18_Ver7.30_GENKA
        Get
            If 原価管理 = オプション区分定義型.区分型.行わない Then
                Return 原価管理定義型.明細単位原価集計入力型.行わない
            End If

            Return _原価管理.明細単位原価集計入力_売上
        End Get
    End Property

    Public ReadOnly Property 明細単位原価集計入力_仕入() As 原価管理定義型.明細単位原価集計入力型   'A-2008/07/18_Ver7.30_GENKA
        Get
            If 原価管理 = オプション区分定義型.区分型.行わない Then
                Return 原価管理定義型.明細単位原価集計入力型.行わない
            End If

            Return _原価管理.明細単位原価集計入力_仕入
        End Get
    End Property

    Public ReadOnly Property 要素タイトル() As String   'A-2008/07/18_Ver7.30_GENKA
        Get
            Return 分類種別名(分類種別定義型.データ区分型.商品, 要素使用分類種別).TrimEnd
        End Get
    End Property

#End Region

#Region "支払管理"      'A-2008/07/18_Ver7.30_SHIHARAI

    Public ReadOnly Property 支払先別支払管理単位設定() As 支払管理定義型.支払先別支払管理単位設定型    'A-2008/07/18_Ver7.30_SHIHARAI
        Get
            If 支払管理 = オプション区分定義型.区分型.行わない Then
                Return 支払管理定義型.支払先別支払管理単位設定型.行わない
            End If

            Return _支払管理.支払先別支払管理単位設定
        End Get
    End Property

    Public ReadOnly Property 支払管理単位() As 支払管理定義型.支払管理単位型    'A-2008/07/18_Ver7.30_SHIHARAI
        Get
            Return _支払管理.支払管理単位
        End Get
    End Property

    Public ReadOnly Property 支払_原価集計別管理() As 支払管理定義型.支払_原価集計別管理型      'A-2008/07/18_Ver7.30_SHIHARAI
        Get
            If 支払管理 = オプション区分定義型.区分型.行わない Then
                Return 支払管理定義型.支払_原価集計別管理型.行わない
            End If

            If 原価管理 = オプション区分定義型.区分型.行わない Then
                Return 支払管理定義型.支払_原価集計別管理型.行わない
            End If

            Return _支払管理.支払_原価集計別管理
        End Get
    End Property

#End Region

#Region "変更履歴"      'A-2009/08/21_RIREKI

    Public ReadOnly Property 変更履歴使用区分() As Boolean  'A-2009/08/21_RIREKI
        Get
            If _変更履歴.データ変更履歴取得可能区分 = 変更履歴定義型.区分型.使用する Then
                Return True
            Else
                Return False
            End If
        End Get
    End Property

    Public ReadOnly Property 変更履歴_仕入() As Boolean     'A-2009/08/21_RIREKI
        Get
            If 変更履歴使用区分 = False Then
                Return False
            End If

            If _変更履歴.仕入 = 変更履歴定義型.区分型.使用する Then
                Return True
            Else
                Return False
            End If
        End Get
    End Property

    Public ReadOnly Property 変更履歴_発注() As Boolean     'A-2009/08/21_RIREKI
        Get
            If 受発注管理 = オプション区分定義型.区分型.行わない Then
                Return False
            End If

            If 変更履歴使用区分 = False Then
                Return False
            End If

            If _変更履歴.発注 = 変更履歴定義型.区分型.使用する Then
                Return True
            Else
                Return False
            End If
        End Get
    End Property

    Public ReadOnly Property 変更履歴_内訳() As Boolean     'A-2009/12/18_Ver7.40_UCHIWAKE
        Get
            If 変更履歴使用区分 = False Then
                Return False
            End If

            If _変更履歴.内訳 = 変更履歴定義型.区分型.使用する Then
                Return True
            Else
                Return False
            End If
        End Get
    End Property

    Public ReadOnly Property 変更履歴_商品内訳() As Boolean 'A-2009/12/18_Ver7.40_UCHIWAKE
        Get
            If 変更履歴使用区分 = False Then
                Return False
            End If

            If _変更履歴.商品内訳 = 変更履歴定義型.区分型.使用する Then
                Return True
            Else
                Return False
            End If
        End Get
    End Property

    Public ReadOnly Property 変更履歴_ロット() As Boolean   'A-2009/12/18_Ver7.40_LOT
        Get
            If 変更履歴使用区分 = False Then
                Return False
            End If

            If _変更履歴.ロット = 変更履歴定義型.区分型.使用する Then
                Return True
            Else
                Return False
            End If
        End Get
    End Property

#End Region

#Region "商品内訳管理"  'A-2009/12/18_Ver7.40_UCHIWAKE

    Public ReadOnly Property 内訳管理数() As Integer    'A-2009/12/18_Ver7.40_UCHIWAKE
        Get
            Return _商品管理拡張.内訳管理数
        End Get
    End Property

    Public ReadOnly Property 内訳コードタイプ(ByVal 内訳種別 As 内訳種別型) As 商品管理拡張定義型.コードタイプ型    'A-2009/12/18_Ver7.40_UCHIWAKE
        Get
            Select Case 内訳種別
                Case 内訳種別型.内訳種別１
                    Return _商品管理拡張.内訳種別1.コードタイプ
                Case 内訳種別型.内訳種別２
                    Return _商品管理拡張.内訳種別2.コードタイプ
                Case 内訳種別型.内訳種別３
                    Return _商品管理拡張.内訳種別3.コードタイプ
            End Select
        End Get
    End Property

    Public ReadOnly Property 内訳コード桁数(ByVal 内訳種別 As 内訳種別型) As Integer    'A-2009/12/18_Ver7.40_UCHIWAKE
        Get
            Select Case 内訳種別
                Case 内訳種別型.内訳種別１
                    Return _商品管理拡張.内訳種別1.コード桁数
                Case 内訳種別型.内訳種別２
                    Return _商品管理拡張.内訳種別2.コード桁数
                Case 内訳種別型.内訳種別３
                    Return _商品管理拡張.内訳種別3.コード桁数
            End Select
        End Get
    End Property

    Public ReadOnly Property 内訳名称(ByVal 内訳種別 As 内訳種別型) As String           'A-2009/12/18_Ver7.40_UCHIWAKE
        Get
            Select Case 内訳種別
                Case 内訳種別型.内訳種別１
                    Return _商品管理拡張.内訳種別1.名称
                Case 内訳種別型.内訳種別２
                    Return _商品管理拡張.内訳種別2.名称
                Case 内訳種別型.内訳種別３
                    Return _商品管理拡張.内訳種別3.名称
                Case Else
                    Return ""
            End Select
        End Get
    End Property

    Public ReadOnly Property 内訳数値小数桁数(ByVal 内訳種別 As 内訳種別型) As Integer  'A-2009/12/18_Ver7.40_UCHIWAKE
        Get
            Select Case 内訳種別
                Case 内訳種別型.内訳種別１
                    Return _商品管理拡張.内訳種別1.小数桁数
                Case 内訳種別型.内訳種別２
                    Return _商品管理拡張.内訳種別2.小数桁数
                Case 内訳種別型.内訳種別３
                    Return _商品管理拡張.内訳種別3.小数桁数
            End Select
        End Get
    End Property

    Public ReadOnly Property 内訳マスター自動登録() As Boolean          'A-2009/12/18_Ver7.40_UCHIWAKE
        Get
            If _商品管理拡張.内訳マスター自動登録 = 商品管理拡張定義型.内訳マスター自動登録型.行う Then
                Return True
            Else
                Return False
            End If
        End Get
    End Property

    Public ReadOnly Property 売上_仕入_処理_内訳変更区分() As 商品管理拡張定義型.売上_仕入_処理_内訳変更区分型  'A-2009/12/18_Ver7.40_UCHIWAKE
        Get
            Return _商品管理拡張.売上_仕入_処理_内訳変更区分
        End Get
    End Property

    Public ReadOnly Property 内訳タイプ() As 商品管理拡張定義型.内訳タイプ型    'A-2009/12/18_Ver7.40_UCHIWAKE
        Get
            Return _商品管理拡張.内訳タイプ
        End Get
    End Property

    Public ReadOnly Property 換算数量使用区分() As Boolean      'A-2009/12/18_Ver7.40_UCHIWAKE
        Get
            If 商品内訳管理 = False Then
                Return False
            End If

            If 内訳タイプ = 商品管理拡張定義型.内訳タイプ型.マスター Then
                Return False
            End If

            If _商品管理拡張.換算数量使用区分 = 商品管理拡張定義型.換算数量使用区分型.使用する Then
                Return True
            Else
                Return False
            End If
        End Get
    End Property

#End Region

#Region "ロット管理"  'A-2009/12/18_Ver7.40_LOT

    Public ReadOnly Property 手入力ロットNo桁数() As Integer 'A-2009/12/18_Ver7.40_LOT
        Get
            Return _ロット管理.手入力時ロットNo桁数
        End Get
    End Property

    Public ReadOnly Property ロットNo採番方法() As ロット管理定義型.ロットNo採番方法型  'A-2009/12/18_Ver7.40_LOT
        Get
            Return _ロット管理.ロットNo採番方法
        End Get
    End Property

    Public ReadOnly Property 有効期限機能() As Boolean      'A-2009/12/18_Ver7.40_LOT
        Get
            If ロット管理 = False Then
                Return False
            End If

            If _ロット管理.有効期限機能 = ロット管理定義型.有効期限機能型.行う Then
                Return True
            Else
                Return False
            End If
        End Get
    End Property

#End Region

#Region "端数処理"  'A-2009/12/18_Ver7.40_LOT

    Public ReadOnly Property 単価端数処理_仕入() As 端数処理定義型.単価端数処理仕入型   'A-2009/12/18_Ver7.40_LOT
        Get
            Return _端数処理.単価端数処理.仕入
        End Get
    End Property

    'A-CUST20190830↓
    Public ReadOnly Property 金額端数処理_仕入() As 端数処理定義型.端数処理型
        Get
            Return _端数処理.金額端数処理.仕入
        End Get
    End Property
    'A-CUST20190830↑

#End Region

    'A-20121217_Ver7.50_4↓
#Region "受注在庫引当"

    Public ReadOnly Property 在庫引当警告_未検収入荷() As 受注在庫引当定義型.在庫引当警告_未検収入荷型
        Get
            If 未検収在庫機能 = MOA機能追加定義型.未検収在庫機能使用区分型.使用しない Then
                Return 受注在庫引当定義型.在庫引当警告_未検収入荷型.含める
            Else
                Return _受注在庫引当.在庫引当警告_未検収入荷
            End If
        End Get
    End Property

#End Region
    'A-20121217_Ver7.50_4↑

    '↓A-20170601-X1-桁数拡張
#Region "桁数拡張"

    Public ReadOnly Property 名称桁数() As Integer
        Get
            If _桁数拡張.取引先名桁数拡張 = 桁数拡張定義型.取引先名桁数拡張型.使用する Then
                Return 48
            End If
            Return 32
        End Get
    End Property

    Public ReadOnly Property 金額桁数() As Integer
        Get
            If _桁数拡張.金額桁数拡張 = 桁数拡張定義型.金額桁数拡張型.使用する Then
                Return 12
            End If
            Return 9
        End Get
    End Property

    Public ReadOnly Property 金額桁数_実績() As Integer
        Get
            If _桁数拡張.金額桁数拡張 = 桁数拡張定義型.金額桁数拡張型.使用する Then
                Return 13
            End If
            Return 12
        End Get
    End Property

    Public ReadOnly Property 拡張項目データリンク桁数拡張() As Boolean
        Get
            If _桁数拡張.拡張項目データリンク桁数拡張 = 桁数拡張定義型.拡張項目データリンク桁数拡張型.使用する Then
                Return True
            Else
                Return False
            End If
        End Get
    End Property

#End Region
    '↑A-20170601-X1-桁数拡張

#Region "分類種別"      'A-2008/07/18_Ver7.30_GENKA

    Public ReadOnly Property 分類種別名(ByVal データ区分 As 分類種別定義型.データ区分型, ByVal 分類種別コード As Integer) As String 'A-2008/07/18_Ver7.30_GENKA
        Get
            Return _分類種別.分類種別名(データ区分, 分類種別コード).TrimEnd
        End Get
    End Property

#End Region

#Region "販売財務連動"

    Public ReadOnly Property 販売財務連動区分() As BIS.LIB.ControlInfoC001.販売財務連動定義型.販売財務連動区分型
        Get
            Return _販売財務連動.販売財務連動区分
        End Get
    End Property

    Public ReadOnly Property 仕入データ連動区分() As BIS.LIB.ControlInfoC001.販売財務連動定義型.仕入データ連動区分型
        Get
            Return _販売財務連動.仕入データ連動区分
        End Get
    End Property

    Public ReadOnly Property 原価データ連携区分() As Boolean    'A-2009/12/18_Ver7.40_PRO
        Get
            If _プロジェクト原価管理.原価データ連携区分 = BIS.LIB.ControlInfoC001.プロジェクト原価管理定義型.連携区分型.行う Then
                Return True
            Else
                Return False
            End If
        End Get
    End Property

#End Region

#Region "会計オプション"    'A-2008/07/18_Ver7.30_SAIMU

    Private _会計債務管理 As Boolean            'A-2008/07/18_Ver7.30_SAIMU
    Public Property 会計債務管理() As Boolean   'A-2008/07/18_Ver7.30_SAIMU
        Get
            If _ＲＥＶ.強化区分 >= 3.0 Then
            Else
                Return False
            End If

            If _MOAＲＥＶ.強化区分 >= 3.0 Then
            Else
                Return False
            End If

            If 販売財務連動区分 = BIS.LIB.ControlInfoC001.販売財務連動定義型.販売財務連動区分型.行わない Then
                Return False
            End If
            If _取引先マスタリンク区分.取引先一元管理_販売＿会計 = BIS.LIB.ControlInfoC001.取引先マスタリンク区分定義型.取引先一元管理_販売＿会計型.行わない Then    'X1変換Tool-20170508
                Return False
            End If

            Select Case 仕入データ連動区分
                Case BIS.LIB.ControlInfoC001.販売財務連動定義型.仕入データ連動区分型.一括生成で作成_明細単位,
                     BIS.LIB.ControlInfoC001.販売財務連動定義型.仕入データ連動区分型.一括生成で作成_伝票単位,
                     BIS.LIB.ControlInfoC001.販売財務連動定義型.仕入データ連動区分型.一括生成で作成_取引先別日計単位
                Case Else
                    Return False
            End Select

            Return _会計債務管理
        End Get
        Set(ByVal value As Boolean)
            _会計債務管理 = value
        End Set
    End Property

    Private _会計債務残消込管理 As Boolean              'A-2008/07/18_Ver7.30_SAIMU
    Public Property 会計債務残消込管理() As Boolean     'A-2008/07/18_Ver7.30_SAIMU
        Get
            Return _会計債務残消込管理
        End Get
        Set(ByVal value As Boolean)
            _会計債務残消込管理 = value
        End Set
    End Property

    Private _会計原価振替処理 As Boolean            'A-2009/12/18_Ver7.40_PRO
    Public Property 会計原価振替処理() As Boolean   'A-2009/12/18_Ver7.40_PRO
        Get
            If _ＲＥＶ.強化区分 >= 4.0 Then
            Else
                Return False
            End If
            If 販売財務連動区分 = BIS.LIB.ControlInfoC001.販売財務連動定義型.販売財務連動区分型.行わない Then
                Return False
            End If
            Select Case 仕入データ連動区分
                Case BIS.LIB.ControlInfoC001.販売財務連動定義型.仕入データ連動区分型.一括生成で作成_明細単位,
                     BIS.LIB.ControlInfoC001.販売財務連動定義型.仕入データ連動区分型.一括生成で作成_伝票単位,
                     BIS.LIB.ControlInfoC001.販売財務連動定義型.仕入データ連動区分型.一括生成で作成_取引先別日計単位
                Case Else
                    Return False
            End Select

            If 原価管理 = オプション区分定義型.区分型.行わない Then
                Return False
            End If

            If 原価データ連携区分 = False Then
                Return False
            End If

            Return _会計原価振替処理
        End Get
        Set(ByVal value As Boolean)
            _会計原価振替処理 = value
        End Set
    End Property

#End Region

#Region "会計伝票承認"  'A-2010/09/13_Ver7.4X_ZAISHONIN
    Private _会計伝票承認機能 As Boolean            'A-2010/09/13_Ver7.4X_ZAISHONIN
    Public Property 会計伝票承認機能() As Boolean   'A-2010/09/13_Ver7.4X_ZAISHONIN
        Get
            If _ＲＥＶ.強化区分 >= 4.1 Then
            Else
                Return False
            End If

            If 販売財務連動区分 = BIS.LIB.ControlInfoC001.販売財務連動定義型.販売財務連動区分型.行わない Then
                Return False
            End If

            If _取引先マスタリンク区分.取引先一元管理_販売＿会計 = BIS.LIB.ControlInfoC001.取引先マスタリンク区分定義型.取引先一元管理_販売＿会計型.行わない Then    'X1変換Tool-20170508
                Return False
            End If

            Select Case 仕入データ連動区分
                Case BIS.LIB.ControlInfoC001.販売財務連動定義型.仕入データ連動区分型.一括生成で作成_明細単位,
                     BIS.LIB.ControlInfoC001.販売財務連動定義型.仕入データ連動区分型.一括生成で作成_伝票単位,
                     BIS.LIB.ControlInfoC001.販売財務連動定義型.仕入データ連動区分型.一括生成で作成_取引先別日計単位
                Case Else
                    Return False
            End Select

            Return _会計伝票承認機能
        End Get
        Set(ByVal value As Boolean)
            _会計伝票承認機能 = value
        End Set
    End Property
#End Region

#Region "プログラム専用"

    Private _拡張項目_仕入伝票 As Boolean
    Public Property 拡張項目_仕入伝票() As Boolean
        Get
            Return _拡張項目_仕入伝票
        End Get
        Set(ByVal value As Boolean)
            _拡張項目_仕入伝票 = value
        End Set
    End Property

    Private _拡張項目_仕入明細 As Boolean
    Public Property 拡張項目_仕入明細() As Boolean
        Get
            Return _拡張項目_仕入明細
        End Get
        Set(ByVal value As Boolean)
            _拡張項目_仕入明細 = value
        End Set
    End Property

    'A-CUST20190830↓
    Private _拡張項目_入出庫伝票 As Boolean
    Public Property 拡張項目_入出庫伝票() As Boolean
        Get
            Return _拡張項目_入出庫伝票
        End Get
        Set(ByVal value As Boolean)
            _拡張項目_入出庫伝票 = value
        End Set
    End Property

    Private _拡張項目_入出庫明細 As Boolean
    Public Property 拡張項目_入出庫明細() As Boolean
        Get
            Return _拡張項目_入出庫明細
        End Get
        Set(ByVal value As Boolean)
            _拡張項目_入出庫明細 = value
        End Set
    End Property
    'A-CUST20190830↑

#End Region


#Region "MOA初期値"

    Public ReadOnly Property ダミーロットNo() As String
        Get
            Return _MOA追加初期値.ダミーロットNo
        End Get
    End Property

    'A-20120315_3↓
    Public ReadOnly Property 残以上の取込を許可() As MOA追加初期値定義型.取込処理残チェック区分型
        Get
            Return _MOA追加初期値.残以上の取込を許可_入荷
        End Get
    End Property

    Public ReadOnly Property 完納データに対する取込を許可() As MOA追加初期値定義型.取込処理残チェック区分型
        Get
            Return _MOA追加初期値.完納データに対する取込を許可_入荷
        End Get
    End Property
    'A-20120315_3↑

    'A-20120522_1↓
    Public ReadOnly Property 需要数計算端数処理() As MOA追加初期値定義型.需要数計算端数処理型
        Get
            Return _MOA追加初期値.需要数計算端数処理
        End Get
    End Property

    Public ReadOnly Property 需要数計算端数処理_計算単位() As MOA追加初期値定義型.需要数計算端数処理_計算単位型
        Get
            Return _MOA追加初期値.需要数計算端数処理_計算単位
        End Get
    End Property
    'A-20120522_1↑
#End Region

#Region "MOAオプション"

    Public ReadOnly Property MOA品質管理() As MOAオプション定義型.その他管理区分型
        Get
            Return _MOAオプション.品質管理
        End Get
    End Property

    Public ReadOnly Property MOA原価管理() As MOAオプション定義型.その他管理区分型
        Get
            Return _MOAオプション.原価管理
        End Get
    End Property

    'A-20121217_Ver7.50_1↓
    Public ReadOnly Property MOA外貨管理() As MOAオプション定義型.その他管理区分型
        Get
            If _MOAＲＥＶ.強化区分 < 4.0 Then
                Return MOAオプション定義型.その他管理区分型.行わない
            End If
            Return _MOAオプション.外貨管理
        End Get
    End Property
    'A-20121217_Ver7.50_1↑

#End Region

#Region "MOAロット管理"

    Public ReadOnly Property 有効期限更新方法設定() As MOAロット管理定義型.有効期限更新方法設定型
        Get
            Return _MOAロット管理.有効期限更新方法設定
        End Get
    End Property

#End Region

#Region "MOA機能追加"

    Public ReadOnly Property 品目名既定値_代表品名() As MOA機能追加定義型.品目名既定値_代表品名型
        Get
            Return _MOA機能追加.品目名既定値_代表品名
        End Get
    End Property

    Public ReadOnly Property マイナス在庫チェック() As MOA機能追加定義型.マイナス在庫チェック型
        Get
            Return _MOA機能追加.マイナス在庫チェック
        End Get
    End Property

    Public ReadOnly Property 構成品自動出庫() As MOA機能追加定義型.その他管理区分型
        Get
            Return _MOA機能追加.構成品自動出庫
        End Get
    End Property

    Public ReadOnly Property 仕入検収基準() As MOA機能追加定義型.その他管理区分型
        Get
            '// 仕入検収基準( 0...入荷基準 1...検収基準 )
            Return _MOA機能追加.仕入検収基準
        End Get
    End Property

    Public ReadOnly Property ロットNo管理区分_受入() As MOA機能追加定義型.ロットNo管理区分_受入型
        Get
            Return _MOA機能追加.ロットNo管理区分_受入
        End Get
    End Property

    Public ReadOnly Property 支給管理区分() As MOA機能追加定義型.支給管理区分型
        Get
            Return _MOA機能追加.支給管理区分
        End Get
    End Property
    'A-20110912_1↓
    Public ReadOnly Property 仕掛管理区分() As MOA機能追加定義型.その他管理区分型
        Get
            Return _MOA機能追加.仕掛管理区分
        End Get
    End Property

    Public ReadOnly Property 仕掛計上区分() As MOA機能追加定義型.仕掛計上区分型
        Get
            Return _MOA機能追加.仕掛計上区分
        End Get
    End Property
    'A-20110912_1↑

    'A-20121217_Ver7.50_3↓
    Public ReadOnly Property ロケーション単位数量指定列() As MOA機能追加定義型.ロケーション単位数量指定列
        Get
            Return _MOA機能追加.ロケーション単位数量指定列
        End Get
    End Property
    'A-20121217_Ver7.50_3↑
    'A-20121217_Ver7.50_4↓
    Public ReadOnly Property 未検収在庫機能() As MOA機能追加定義型.未検収在庫機能使用区分型
        Get
            If _MOAＲＥＶ.強化区分 < 4.0 Then
                Return MOA機能追加定義型.未検収在庫機能使用区分型.使用しない
            End If

            If _MOA機能追加.仕入検収基準 = MOA機能追加定義型.その他管理区分型.行わない Then
                Return MOA機能追加定義型.未検収在庫機能使用区分型.使用しない
            End If

            Return _MOA機能追加.未検収在庫機能
        End Get
    End Property

    Public ReadOnly Property マイナス仕掛在庫警告_未検収入荷() As MOA機能追加定義型.マイナス仕掛在庫警告区分型
        Get
            If 未検収在庫機能 = MOA機能追加定義型.未検収在庫機能使用区分型.使用しない Then
                Return MOA機能追加定義型.マイナス仕掛在庫警告区分型.含む
            Else
                Return _MOA機能追加.マイナス仕掛在庫警告_未検収入荷
            End If
        End Get
    End Property
    'A-20121217_Ver7.50_4↑

    'A-20141105_1↓
    Public ReadOnly Property 標準原価積上機能() As MOA機能追加定義型.使用有無区分型
        Get
            If MOA強化区分 < 6D Then
                Return MOA機能追加定義型.使用有無区分型.使用しない
            End If
            Return _MOA機能追加.標準原価積上機能
        End Get
    End Property
    'A-20141105_1↑

    'A-20150520_1↓
    Public ReadOnly Property 品目別原価計算機能() As MOA機能追加定義型.使用有無区分型
        Get
            If Not (MOA強化区分 >= 7D) Then Return MOA機能追加定義型.使用有無区分型.使用しない
            Return _MOA機能追加.品目別原価計算機能
        End Get
    End Property

    Public ReadOnly Property 出庫時原価採用区分() As MOA品目別原価定義型.出庫時原価採用区分型
        Get
            Return _MOA品目別原価.出庫時原価採用区分
        End Get
    End Property
    'A-20150520_1↑

    'A-20160324_1↓
    Public ReadOnly Property 外貨管理明細邦貨額積上機能() As MOA機能追加定義型.使用有無区分型
        Get
            If Not (MOA強化区分 >= 7.1D) Then Return MOA機能追加定義型.使用有無区分型.使用しない
            Return _MOA機能追加.外貨管理明細邦貨額積上機能
        End Get
    End Property
    'A-20160324_1↑

    'A-20160324_2↓
    Public ReadOnly Property 製番別締機能() As MOA機能追加定義型.使用有無区分型
        Get
            Return _MOA機能追加.製番別締機能
        End Get
    End Property
    'A-20160324_2↑

    'A-20170417_1↓
    Public ReadOnly Property 見込受注得意先以外の出庫予定制御() As MOA機能追加定義型.その他管理区分型
        Get
            Return _MOA機能追加.見込受注得意先以外の出庫予定制御
        End Get
    End Property

    Public ReadOnly Property 生産計画機能() As MOA機能追加定義型.使用有無区分型
        Get
            Return _MOA機能追加.生産計画機能
        End Get
    End Property
    'A-20170417_1↑

#End Region

#Region "MOA受入処理"

    ''' <summary>
    ''' 生産革新受入処理.納期前チェック
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property 納期前チェック() As MOA受入処理定義型.その他管理区分型
        Get
            Return _MOA受入処理.納期前チェック
        End Get
    End Property

    ''' <summary>
    ''' 生産革新受入処理.仮単価チェック
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property 仮単価チェック() As MOA受入処理定義型.その他管理区分型
        Get
            Return _MOA受入処理.仮単価チェック
        End Get
    End Property

    ''' <summary>
    ''' 生産革新受入処理.前工程チェック
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property 前工程チェック() As MOA受入処理定義型.その他管理区分型
        Get
            Return _MOA受入処理.前工程チェック
        End Get
    End Property

#End Region

#Region "MOAＲＥＶ"

    Public ReadOnly Property MOA強化区分() As Decimal
        Get
            Return _MOAＲＥＶ.強化区分
        End Get
    End Property

#End Region

    'A-20121217_Ver7.50_1↓
#Region "MOA外貨"

    Public ReadOnly Property 日本円通貨コード() As String
        Get
            Return _MOA外貨.日本円通貨コード
        End Get
    End Property

    Public ReadOnly Property レート使用区分(ByVal index As Integer) As MOA外貨定義型.レート使用区分型
        Get
            Select Case index
                Case 1
                    Return _MOA外貨.レート１使用区分
                Case 2
                    Return _MOA外貨.レート２使用区分
                Case 3
                    Return _MOA外貨.レート３使用区分
                Case 4
                    Return _MOA外貨.レート４使用区分
                Case 5
                    Return _MOA外貨.レート５使用区分
                Case 6
                    Return _MOA外貨.レート６使用区分
                Case 7
                    Return _MOA外貨.レート７使用区分
                Case 8
                    Return _MOA外貨.レート８使用区分
                Case 9
                    Return _MOA外貨.レート９使用区分
                Case Else
                    Return MOA外貨定義型.レート使用区分型.使用しない
            End Select
        End Get
    End Property

    Public ReadOnly Property レート名称(ByVal index As Integer) As String
        Get
            Select Case index
                Case 1
                    Return _MOA外貨.レート１名称
                Case 2
                    Return _MOA外貨.レート２名称
                Case 3
                    Return _MOA外貨.レート３名称
                Case 4
                    Return _MOA外貨.レート４名称
                Case 5
                    Return _MOA外貨.レート５名称
                Case 6
                    Return _MOA外貨.レート６名称
                Case 7
                    Return _MOA外貨.レート７名称
                Case 8
                    Return _MOA外貨.レート８名称
                Case 9
                    Return _MOA外貨.レート９名称
                Case Else
                    Return ""
            End Select
        End Get
    End Property

    'A-20160324_1↓
    Public ReadOnly Property 外貨複数伝票消込機能() As MOA外貨定義型.制御区分型
        Get
            If Not (MOA強化区分 >= 8D) Then Return MOA外貨定義型.制御区分型.行わない
            Return _MOA外貨.外貨複数伝票消込機能
        End Get
    End Property
    'A-20160324_1↑

#End Region
    'A-20121217_Ver7.50_1↑

    'A-20121217_Ver7.50_2↓
#Region "MOA在庫引当"

    Public ReadOnly Property 引当数量算出区分_未検収入荷() As MOA在庫引当定義型.引当数量算出区分型
        Get
            If 未検収在庫機能 = MOA機能追加定義型.未検収在庫機能使用区分型.使用しない Then
                Return MOA在庫引当定義型.引当数量算出区分型.含める
            Else
                Return _MOA在庫引当.引当数量算出区分_未検収入荷
            End If
        End Get
    End Property

    Public ReadOnly Property 在庫引当_自動出庫区分() As MOA在庫引当定義型.在庫引当_自動出庫区分型
        Get
            Return _MOA在庫引当.在庫引当_自動出庫区分
        End Get
    End Property

    Public ReadOnly Property 需要数_入庫時即引当() As MOA在庫引当定義型.需要数_入庫時即引当区分型
        Get
            Return _MOA在庫引当.需要数_入庫時即引当
        End Get
    End Property

    '↓A-20180723-X1-引当
    Public ReadOnly Property 出庫まるめ引当単位区分() As MOA在庫引当定義型.出庫まるめ引当単位区分型
        Get
            Return _MOA在庫引当.出庫まるめ引当単位区分
        End Get
    End Property
    '↑A-20180723-X1-引当

#End Region
    'A-20121217_Ver7.50_2↑

    'A-20170417_1↓
#Region "MOAその他"

    Public ReadOnly Property 見込受注用得意先コード() As String
        Get
            Return _MOAその他.見込受注用得意先コード
        End Get
    End Property

#End Region
    'A-20170417_1↑

#End Region

#Region "■メソッド■"

    Public Sub InitializeC001(ByVal controlInfo As IDictionary)
        _オプション区分.Initialize(controlInfo)
        _機能区分.Initialize(controlInfo)
        _初期値.Initialize(controlInfo)
        _仕入処理.Initialize(controlInfo)
        _消費税.Initialize(controlInfo)
        _受発注管理.Initialize(controlInfo)
        _拡張項目.Initialize(controlInfo)
        _ＲＥＶ.Initialize(controlInfo)             'A-2008/07/18_Ver7.30_GENKA
        _原価管理.Initialize(controlInfo)           'A-2008/07/18_Ver7.30_GENKA
        _支払管理.Initialize(controlInfo)           'A-2008/07/18_Ver7.30_SHIHARAI
        _変更履歴.Initialize(controlInfo)           'A-2009/08/21_RIREKI
        _商品管理拡張.Initialize(controlInfo)       'A-2009/12/18_Ver7.40_UCHIWAKE
        _ロット管理.Initialize(controlInfo)         'A-2009/12/18_Ver7.40_LOT
        _端数処理.Initialize(controlInfo)           'A-2009/12/18_Ver7.40_LOT
        _受注在庫引当.Initialize(controlInfo)       'A-20121217_Ver7.50_4
        _桁数拡張.Initialize(controlInfo)       'A-20170601-X1-桁数拡張

        _MOA追加初期値.Initialize(controlInfo)
        _MOAオプション.Initialize(controlInfo)
        _MOAロット管理.Initialize(controlInfo)
        _MOA機能追加.Initialize(controlInfo)
        _MOA受入処理.Initialize(controlInfo)
        _MOAＲＥＶ.Initialize(controlInfo)
        _MOA外貨.Initialize(controlInfo)            'A-20121217_Ver7.50_1
        _MOA在庫引当.Initialize(controlInfo)        'A-20121217_Ver7.50_2

        _MOA品目別原価.Initialize(controlInfo)  'A-20150520_1
        _MOAその他.Initialize(controlInfo)      'A-20170417_1
    End Sub

    Public Sub InitializeC002(ByVal controlInfoC002 As IDictionary)     'A-2008/07/18_Ver7.30_GENKA

        _分類種別.Initialize(controlInfoC002)

    End Sub

    Public Sub InitializeBISC001(ByVal controlInfoBISC001 As IDictionary)

        _販売財務連動.Initialize(controlInfoBISC001)
        _取引先マスタリンク区分.Initialize(controlInfoBISC001)      'A-2008/07/18_Ver7.30_SAIMU
        _プロジェクト原価管理.Initialize(controlInfoBISC001)        'A-2009/12/18_Ver7.40_PRO

    End Sub

#End Region

End Class

