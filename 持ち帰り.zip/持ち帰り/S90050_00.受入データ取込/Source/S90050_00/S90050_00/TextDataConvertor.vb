﻿''' <summary>
''' テキストデータ変換クラス
''' </summary>
''' <remarks></remarks>
Public Class TextDataConvertor
    Inherits OSK.X1.Foundation.TextFileImport.TextDataConvertorBase    'X1変換Tool-20170508

#Region "■定義■"

#End Region

#Region "■プロパティ■"

    Public ReadOnly Property MyImportParam() As ImportParam
        Get
            Return CType(Me.ImportParam, S90050_00.ImportParam)
        End Get
    End Property

    Public ReadOnly Property 拡張伝票() As [LIB].ExpandItemControl.I拡張項目定義型
        Get
            If MyImportParam.Myコントロール情報.MyMOA機能追加.仕入検収基準 = MOA機能追加定義型.その他管理区分型.行う Then
                Return MyImportParam.拡張項目情報_入荷伝票
            Else
                Return MyImportParam.拡張項目情報_仕入伝票
            End If
        End Get
    End Property

    Public ReadOnly Property 拡張明細() As [LIB].ExpandItemControl.I拡張項目定義型
        Get
            If MyImportParam.Myコントロール情報.MyMOA機能追加.仕入検収基準 = MOA機能追加定義型.その他管理区分型.行う Then
                Return MyImportParam.拡張項目情報_入荷明細
            Else
                Return MyImportParam.拡張項目情報_仕入明細
            End If
        End Get
    End Property

#End Region

#Region "■メソッド■"

#Region "ITextDataConvertor"

    '取込レイアウトに従い、取込項目のインデックスを設定
    Public Overrides Sub Set項目位置情報()

        ReDim MyBase._項目位置情報(仕入データ型._項目数 - 1)
        For i As Integer = 0 To 仕入データ型._項目数 - 1
            _項目位置情報(i) = -1 ''未使用・未設定値
        Next

        Select Case MyImportParam.取込レイアウト区分
            Case IKanriTableData.取込レイアウト区分型.テキストファイル出力レイアウト
                Call SetIndexテキストファイル出力レイアウト()

            Case IKanriTableData.取込レイアウト区分型.テキストファイル取込専用レイアウト_標準
                Call SetIndexテキストファイル取込専用レイアウト_標準()

            Case IKanriTableData.取込レイアウト区分型.変換パターン使用
                Call SetIndexテキストファイル取込専用レイアウト_変換()

        End Select

        Call SetIndexテキストファイル取込専用レイアウト_標準() 'A-CUST20190830

    End Sub

#End Region

#Region "個別に実装"

    Private Sub SetIndexテキストファイル出力レイアウト()

        Dim isSet As Boolean = False
        Dim 拡張参照名なし As Boolean = False

        Dim index As Integer = -1 '先頭に0
        Dim noItemCount As Integer = 0
        Dim noItemCount_Set後加算 As Integer = 0    'A-2009/12/18_Ver7.40_UCHIWAKE
        Dim 未使用件数 As Integer = 0
        Dim iEXP As Integer = 0

        For i As Integer = 0 To テキスト出力型._項目数 - 1
            If CType(i, テキスト出力型).ToString.StartsWith("_") = False Then
                isSet = False
                拡張参照名なし = False
                noItemCount_Set後加算 = 0   'A-2009/12/18_Ver7.40_UCHIWAKE
                Select Case i
                    Case テキスト出力型.部門コード
                        If MyImportParam.Myコントロール情報.Myオプション区分.部門管理 = オプション区分定義型.区分型.行う Then
                            isSet = True
                        Else
                            noItemCount += 22
                        End If

                    Case テキスト出力型.営業所コード
                        If MyImportParam.Myコントロール情報.My機能区分.営業所管理 = 機能区分定義型.営業所管理区分型.行う Then
                            isSet = True
                        Else
                            noItemCount += 22
                        End If

                    Case テキスト出力型.倉庫コード
                        If MyImportParam.Myコントロール情報.My機能区分.倉庫別在庫管理 = 機能区分定義型.倉庫別在庫管理型.行う Then
                            isSet = True
                        Else
                            noItemCount += 2
                        End If

                    Case テキスト出力型.ロットNo
                        If MyImportParam.Myコントロール情報.MyMOAオプション.MOA品質管理 = MOAオプション定義型.その他管理区分型.行う Then
                            isSet = True
                        Else
                            noItemCount += 1
                        End If

                    Case テキスト出力型.有効期限
                        If MyImportParam.Myコントロール情報.MyMOAオプション.MOA品質管理 = MOAオプション定義型.その他管理区分型.行う Then
                            isSet = True
                        Else
                            noItemCount += 1
                        End If

                    Case テキスト出力型.入数,
                         テキスト出力型.個数,
                         テキスト出力型.個数単位
                        If MyImportParam.Myコントロール情報.My仕入処理.入数個数 = 仕入処理定義型.入数個数使用区分型.使用する Then
                            isSet = True
                        Else
                            noItemCount += 1
                        End If

                    Case テキスト出力型.上代単価
                        If MyImportParam.Myコントロール情報.My仕入処理.上代 = 仕入処理定義型.上代使用区分型.使用する Then
                            isSet = True
                        Else
                            noItemCount += 1
                        End If

                    Case テキスト出力型.上代課税区分
                        If MyImportParam.Myコントロール情報.My仕入処理.上代 = 仕入処理定義型.上代使用区分型.使用する AndAlso
                           MyImportParam.Myコントロール情報.My機能区分.消費税改正対応区分 = 機能区分定義型.消費税改正対応区分型.行う Then
                            isSet = True
                        Else
                            noItemCount += 2
                        End If

                    Case テキスト出力型.明細消費税等
                        If MyImportParam.Myコントロール情報.My機能区分.明細単位処理_消費税計算 = 機能区分定義型.消費税計算型.行う Then
                            isSet = True
                        Else
                            noItemCount += 1
                        End If

                    Case テキスト出力型.発注番号
                        If MyImportParam.Myコントロール情報.Myオプション区分.受発注管理 = オプション区分定義型.区分型.行う Then
                            isSet = True
                        Else
                            noItemCount += 1
                        End If

                        'Case テキスト出力型.発注行番号
                        '    If MyImportParam.Myコントロール情報.Myオプション区分.受発注管理 = オプション区分定義型.区分型.行う Then
                        '        isSet = True
                        '    Else
                        '        noItemCount += 2
                        '    End If

                    Case テキスト出力型.消費税仮計上区分
                        If MyImportParam.Myコントロール情報.My消費税.仮計上消費税使用区分 = 消費税定義型.仮計上消費税使用区分型.行う Then
                            isSet = True
                        Else
                            noItemCount += 1
                        End If

                    Case テキスト出力型.明細消費税計算区分
                        If MyImportParam.Myコントロール情報.My機能区分.明細単位処理_消費税計算 = 機能区分定義型.消費税計算型.行う Then
                            isSet = True
                        Else
                            noItemCount += 2
                        End If

                    Case テキスト出力型.拡張項目入力パターン番号
                        If MyImportParam.Myコントロール情報.Myオプション区分.拡張項目 = オプション区分定義型.区分型.行う AndAlso
                           MyImportParam.Myコントロール情報.My拡張項目.拡張項目入力処理画面表示 = 拡張項目設計型.利用区分型.行う Then
                            isSet = True
                        Else
                            noItemCount += 2
                        End If

                    Case テキスト出力型.伝票拡張項目０１ To テキスト出力型.伝票拡張項目２０
                        If i = テキスト出力型.伝票拡張項目０１ Then
                            iEXP = 0
                        End If
                        If MyImportParam.Myコントロール情報.Myオプション区分.拡張項目_仕入伝票 = True Then
                            iEXP += 1
                            Select Case 拡張伝票.項目情報.項目(iEXP).属性
                                Case [LIB].ExpandItemControl.項目属性型.拡張項目属性型.未使用
                                    noItemCount += 2
                                Case [LIB].ExpandItemControl.項目属性型.拡張項目属性型.数字コード,
                                     [LIB].ExpandItemControl.項目属性型.拡張項目属性型.文字コード
                                    isSet = True
                                Case Else
                                    isSet = True
                                    拡張参照名なし = True
                            End Select
                        Else
                            noItemCount += 2
                        End If

                    Case テキスト出力型.伝票拡張項目付箋色番号
                        If MyImportParam.Myコントロール情報.Myオプション区分.拡張項目_仕入伝票 = True AndAlso
                           拡張伝票.付箋情報.使用区分 = [LIB].ExpandItemControl.付箋情報型.使用区分型.使用する Then
                            isSet = True
                        Else
                            noItemCount += 2
                        End If

                    Case テキスト出力型.明細拡張項目０１ To テキスト出力型.明細拡張項目２０
                        If i = テキスト出力型.明細拡張項目０１ Then
                            iEXP = 0
                        End If
                        If MyImportParam.Myコントロール情報.Myオプション区分.拡張項目_仕入明細 = True Then
                            iEXP += 1
                            Select Case 拡張明細.項目情報.項目(iEXP).属性
                                Case [LIB].ExpandItemControl.項目属性型.拡張項目属性型.未使用
                                    noItemCount += 2
                                Case [LIB].ExpandItemControl.項目属性型.拡張項目属性型.数字コード,
                                     [LIB].ExpandItemControl.項目属性型.拡張項目属性型.文字コード
                                    isSet = True
                                Case Else
                                    isSet = True
                                    拡張参照名なし = True
                            End Select
                        Else
                            noItemCount += 2
                        End If

                    Case テキスト出力型.明細拡張項目付箋色番号
                        If MyImportParam.Myコントロール情報.Myオプション区分.拡張項目_仕入明細 = True AndAlso
                           拡張明細.付箋情報.使用区分 = [LIB].ExpandItemControl.付箋情報型.使用区分型.使用する Then
                            isSet = True
                        Else
                            noItemCount += 2
                        End If

                    Case テキスト出力型.計上区分
                        If MyImportParam.Myコントロール情報.MyMOA機能追加.仕入検収基準 = MOA機能追加定義型.その他管理区分型.行う Then
                            isSet = True
                        Else
                            noItemCount += 2
                        End If

                    Case テキスト出力型.費目コード
                        If MyImportParam.Myコントロール情報.MyMOAオプション.MOA原価管理 = MOAオプション定義型.その他管理区分型.行う Then
                            isSet = True
                        Else
                            noItemCount += 4
                        End If

                    Case テキスト出力型.内訳_ロットNo
                        If MyImportParam.Myコントロール情報.MyMOAオプション.MOA品質管理 = MOAオプション定義型.その他管理区分型.行う Then
                            isSet = True
                        Else
                            noItemCount += 1
                        End If

                    Case テキスト出力型.内訳_ロット別数量
                        If MyImportParam.Myコントロール情報.MyMOAオプション.MOA品質管理 = MOAオプション定義型.その他管理区分型.行う Then
                            isSet = True
                            'A-20121217_Ver7.50_3↓
                        ElseIf MyImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 4D AndAlso
                               MyImportParam.Myコントロール情報.MyMOA機能追加.ロケーション単位数量指定列 = MOA機能追加定義型.ロケーション単位数量指定列.数量列_ロケ＿ロット別 Then    'X1変換Tool-20170508
                            '複数ロケーション対応
                            isSet = True
                            'A-20121217_Ver7.50_3↑
                        Else
                            noItemCount += 1
                        End If

                        'A-20120315_1↓
                    Case テキスト出力型.構成品_完納区分
                        If MyImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 3.2D Then
                            isSet = True
                        Else
                            noItemCount += 2
                        End If
                        'A-20120315_1↑

                        'A-20121217_Ver7.50_1↓
                    Case テキスト出力型.レート
                        If MyImportParam.Myコントロール情報.MyMOAオプション.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う Then
                            isSet = True
                        Else
                            noItemCount += 1
                        End If

                    Case テキスト出力型.レート種類
                        If MyImportParam.Myコントロール情報.MyMOAオプション.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う Then
                            isSet = True
                        Else
                            noItemCount += 2
                        End If

                    Case テキスト出力型.換算基準
                        If MyImportParam.Myコントロール情報.MyMOAオプション.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う Then
                            isSet = True
                        Else
                            noItemCount += 2
                        End If

                    Case テキスト出力型.諸掛管理No
                        If MyImportParam.Myコントロール情報.MyMOAオプション.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う Then
                            isSet = True
                        Else
                            noItemCount += 1
                        End If

                    Case テキスト出力型.按分対象
                        If MyImportParam.Myコントロール情報.MyMOAオプション.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う Then
                            isSet = True
                        Else
                            noItemCount += 2
                        End If

                    Case テキスト出力型.按分基準
                        If MyImportParam.Myコントロール情報.MyMOAオプション.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う Then
                            isSet = True
                        Else
                            noItemCount += 2
                        End If

                    Case テキスト出力型.INVOICENo
                        If MyImportParam.Myコントロール情報.MyMOAオプション.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う Then
                            isSet = True
                        Else
                            noItemCount += 1
                        End If
                        'A-20121217_Ver7.50_1↑
                        'A-20160324_1↓
                    Case テキスト出力型.レート固定区分
                        If MyImportParam.Myコントロール情報.使用条件(Myコントロール情報Param.条件型.外貨複数伝票消込機能, 8D) = True Then
                            isSet = True
                        Else
                            noItemCount += 2
                        End If
                        'A-20160324_1↑
                        'A-20160324_2↓
                    Case テキスト出力型.原価計上手配番号
                        If MyImportParam.Myコントロール情報.使用条件(Myコントロール情報Param.条件型.品目別原価計算機能, 8D) = True Then
                            isSet = True
                        Else
                            noItemCount += 1
                        End If
                        'A-20160324_2↑

                        '    '↓A-2008/07/18_Ver7.30_GENKA
                        'Case テキスト出力型.原価集計メインコード
                        '    If MyImportParam.Myコントロール情報.Myオプション区分.原価管理 = オプション区分定義型.区分型.行う Then
                        '        isSet = True
                        '    Else
                        '        noItemCount += 1
                        '    End If

                        'Case テキスト出力型.原価集計サブコード
                        '    If MyImportParam.Myコントロール情報.Myオプション区分.原価管理 = オプション区分定義型.区分型.行う Then
                        '        isSet = True
                        '    Else
                        '        noItemCount += 23
                        '    End If

                        'Case テキスト出力型.要素コード
                        '    If MyImportParam.Myコントロール情報.Myオプション区分.原価管理 = オプション区分定義型.区分型.行う Then
                        '        isSet = True
                        '    Else
                        '        noItemCount += 3
                        '    End If
                        '    '↑A-2008/07/18_Ver7.30_GENKA

                        '    '↓A-2009/12/18_Ver7.40_UCHIWAKE
                        'Case テキスト出力型.内訳コード１, _
                        '     テキスト出力型.内訳コード２, _
                        '     テキスト出力型.内訳コード３
                        '    Dim 内訳種別 As 内訳種別型
                        '    Select Case i
                        '        Case テキスト出力型.内訳コード１ : 内訳種別 = 内訳種別型.内訳種別１
                        '        Case テキスト出力型.内訳コード２ : 内訳種別 = 内訳種別型.内訳種別２
                        '        Case テキスト出力型.内訳コード３ : 内訳種別 = 内訳種別型.内訳種別３
                        '    End Select
                        '    If Is内訳コード使用可否判定(内訳種別) = True Then
                        '        isSet = True
                        '        '内訳名 or 内訳単位のどちらかのみの出力となる為、noItemCountを固定で+1 (※項目位置情報セット後に反映)
                        '        noItemCount_Set後加算 += 1
                        '    Else
                        '        noItemCount += 3
                        '    End If

                        'Case テキスト出力型.換算数量
                        '    If MyImportParam.Myコントロール情報.My商品内訳管理.換算数量使用区分 = True Then
                        '        isSet = True
                        '    Else
                        '        noItemCount += 2
                        '    End If

                        'Case テキスト出力型.金額算出モード
                        '    If MyImportParam.Myコントロール情報.My商品内訳管理.換算数量使用区分 = True Then
                        '        isSet = True
                        '    Else
                        '        noItemCount += 2
                        '    End If
                        '    '↑A-2009/12/18_Ver7.40_UCHIWAKE

                        '    '↓A-2009/12/18_Ver7.40_LOT
                        'Case テキスト出力型.ロットNo, _
                        '     テキスト出力型.サブロットNo
                        '    If MyImportParam.Myコントロール情報.Myオプション区分.ロット管理 = True Then
                        '        isSet = True
                        '    Else
                        '        noItemCount += 1
                        '    End If
                        'Case テキスト出力型.有効期限
                        '    If MyImportParam.Myコントロール情報.Myロット管理.有効期限機能 = True Then
                        '        isSet = True
                        '    Else
                        '        noItemCount += 1
                        '    End If
                        '    '↑A-2009/12/18_Ver7.40_LOT

                    Case Else
                        isSet = True
                End Select

                If isSet = True Then
                    _項目位置情報(AutoCount(index)) = i - noItemCount

                    If 拡張参照名なし = True Then
                        noItemCount += 1
                    End If
                    noItemCount += noItemCount_Set後加算    'A-2009/12/18_Ver7.40_UCHIWAKE
                Else
                    AutoCount(index)
                End If
            Else
                '取込対象外項目で、コントロールの設定により省略される項目(取込外項目のみで判別するパターンがあるため)
                Select Case i
                    Case テキスト出力型._ロット管理区分
                        If MyImportParam.Myコントロール情報.MyMOAオプション.MOA品質管理 = MOAオプション定義型.その他管理区分型.行う Then
                            isSet = True
                        Else
                            noItemCount += 2
                        End If

                    Case テキスト出力型._構成品_ロット管理区分
                        If MyImportParam.Myコントロール情報.MyMOAオプション.MOA品質管理 = MOAオプション定義型.その他管理区分型.行う Then
                            isSet = True
                        Else
                            noItemCount += 2
                        End If

                    Case テキスト出力型._内訳_ロット明細連番
                        If MyImportParam.Myコントロール情報.MyMOAオプション.MOA品質管理 = MOAオプション定義型.その他管理区分型.行う Then
                            isSet = True
                        Else
                            noItemCount += 1
                        End If

                    Case テキスト出力型._内訳_有効期限
                        If MyImportParam.Myコントロール情報.MyMOAオプション.MOA品質管理 = MOAオプション定義型.その他管理区分型.行う Then
                            isSet = True
                        Else
                            noItemCount += 1
                        End If

                        'A-20121217_Ver7.50_1↓
                    Case テキスト出力型._通貨コード
                        If MyImportParam.Myコントロール情報.MyMOAオプション.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う Then
                            isSet = True
                        Else
                            noItemCount += 2
                        End If

                    Case テキスト出力型._入荷単価_換算額, テキスト出力型._入荷金額_換算額, テキスト出力型._検収残金額_換算額
                        If MyImportParam.Myコントロール情報.MyMOAオプション.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う Then
                            isSet = True
                        Else
                            noItemCount += 1
                        End If
                        'A-20121217_Ver7.50_1↑

                End Select
            End If
        Next

    End Sub

    Private Sub SetIndexテキストファイル取込専用レイアウト_標準()

        For i As Integer = 0 To 仕入データ型._項目数 - 1
            _項目位置情報(i) = i
        Next

    End Sub

    Private Sub SetIndexテキストファイル取込専用レイアウト_変換()
        Dim isSet As Boolean = False
        Dim index As Integer = -1 '先頭に0
        Dim noItemCount As Integer = 0
        Dim iEXP As Integer = 0

        For i As Integer = 0 To 仕入データ型._項目数 - 1
            isSet = False
            Select Case i
                Case 仕入データ型.部門コード
                    If MyImportParam.Myコントロール情報.Myオプション区分.部門管理 = オプション区分定義型.区分型.行う Then
                        isSet = True
                    Else
                        noItemCount += 1
                    End If

                Case 仕入データ型.営業所コード
                    If MyImportParam.Myコントロール情報.My機能区分.営業所管理 = 機能区分定義型.営業所管理区分型.行う Then
                        isSet = True
                    Else
                        noItemCount += 1
                    End If

                Case 仕入データ型.倉庫コード
                    If MyImportParam.Myコントロール情報.My機能区分.倉庫別在庫管理 = 機能区分定義型.倉庫別在庫管理型.行う Then
                        isSet = True
                    Else
                        noItemCount += 1
                    End If

                Case 仕入データ型.ロット_Ｎｏ, 仕入データ型.有効期限
                    If MyImportParam.Myコントロール情報.MyMOAオプション.MOA品質管理 = MOAオプション定義型.その他管理区分型.行う Then
                        isSet = True
                    Else
                        noItemCount += 1
                    End If

                Case 仕入データ型.入数,
                     仕入データ型.個数,
                     仕入データ型.個数単位
                    If MyImportParam.Myコントロール情報.My仕入処理.入数個数 = 仕入処理定義型.入数個数使用区分型.使用する Then
                        isSet = True
                    Else
                        noItemCount += 1
                    End If

                Case 仕入データ型.上代単価
                    If MyImportParam.Myコントロール情報.My仕入処理.上代 = 仕入処理定義型.上代使用区分型.使用する Then
                        isSet = True
                    Else
                        noItemCount += 1
                    End If

                Case 仕入データ型.上代課税区分
                    If MyImportParam.Myコントロール情報.My仕入処理.上代 = 仕入処理定義型.上代使用区分型.使用する AndAlso
                       MyImportParam.Myコントロール情報.My機能区分.消費税改正対応区分 = 機能区分定義型.消費税改正対応区分型.行う Then
                        isSet = True
                    Else
                        noItemCount += 1
                    End If

                Case 仕入データ型.明細消費税等
                    If MyImportParam.Myコントロール情報.My機能区分.明細単位処理_消費税計算 = 機能区分定義型.消費税計算型.行う Then
                        isSet = True
                    Else
                        noItemCount += 1
                    End If

                Case 仕入データ型.発注番号 '仕入データ型.発注行番号
                    If MyImportParam.Myコントロール情報.Myオプション区分.受発注管理 = オプション区分定義型.区分型.行う Then
                        isSet = True
                    Else
                        noItemCount += 1
                    End If

                Case 仕入データ型.消費税仮計上区分
                    If MyImportParam.Myコントロール情報.My消費税.仮計上消費税使用区分 = 消費税定義型.仮計上消費税使用区分型.行う Then
                        isSet = True
                    Else
                        noItemCount += 1
                    End If

                Case 仕入データ型.明細消費税計算区分
                    If MyImportParam.Myコントロール情報.My機能区分.明細単位処理_消費税計算 = 機能区分定義型.消費税計算型.行う Then
                        isSet = True
                    Else
                        noItemCount += 1
                    End If

                Case 仕入データ型.拡張項目入力パターン番号
                    If MyImportParam.Myコントロール情報.Myオプション区分.拡張項目 = オプション区分定義型.区分型.行う AndAlso
                       MyImportParam.Myコントロール情報.My拡張項目.拡張項目入力処理画面表示 = 拡張項目設計型.利用区分型.行う Then
                        isSet = True
                    Else
                        noItemCount += 1
                    End If

                Case 仕入データ型.伝票拡張項目０１ To 仕入データ型.伝票拡張項目２０
                    If i = 仕入データ型.伝票拡張項目０１ Then
                        iEXP = 0
                    End If
                    If MyImportParam.Myコントロール情報.Myオプション区分.拡張項目_仕入伝票 = True Then
                        iEXP += 1
                        If 拡張伝票.項目情報.項目(iEXP).属性 <> [LIB].ExpandItemControl.項目属性型.拡張項目属性型.未使用 Then
                            isSet = True
                        Else
                            noItemCount += 1
                        End If
                    Else
                        noItemCount += 1
                    End If

                Case 仕入データ型.伝票拡張項目付箋色番号
                    If MyImportParam.Myコントロール情報.Myオプション区分.拡張項目_仕入伝票 = True AndAlso
                       拡張伝票.付箋情報.使用区分 = [LIB].ExpandItemControl.付箋情報型.使用区分型.使用する Then
                        isSet = True
                    Else
                        noItemCount += 1
                    End If

                Case 仕入データ型.明細拡張項目０１ To 仕入データ型.明細拡張項目２０
                    If i = 仕入データ型.明細拡張項目０１ Then
                        iEXP = 0
                    End If
                    If MyImportParam.Myコントロール情報.Myオプション区分.拡張項目_仕入明細 = True Then
                        iEXP += 1
                        If 拡張明細.項目情報.項目(iEXP).属性 <> [LIB].ExpandItemControl.項目属性型.拡張項目属性型.未使用 Then
                            isSet = True
                        Else
                            noItemCount += 1
                        End If
                    Else
                        noItemCount += 1
                    End If

                Case 仕入データ型.明細拡張項目付箋色番号
                    If MyImportParam.Myコントロール情報.Myオプション区分.拡張項目_仕入明細 = True AndAlso
                       拡張明細.付箋情報.使用区分 = [LIB].ExpandItemControl.付箋情報型.使用区分型.使用する Then
                        isSet = True
                    Else
                        noItemCount += 1
                    End If

                Case 仕入データ型.計上区分
                    If MyImportParam.Myコントロール情報.MyMOA機能追加.仕入検収基準 = MOA機能追加定義型.その他管理区分型.行う Then
                        isSet = True
                    Else
                        noItemCount += 1
                    End If

                Case 仕入データ型.費目コード
                    If MyImportParam.Myコントロール情報.MyMOAオプション.MOA原価管理 = MOAオプション定義型.その他管理区分型.行う Then
                        isSet = True
                    Else
                        noItemCount += 1
                    End If

                    'Case 仕入データ型.内訳_ロット_Ｎｏ, 仕入データ型.内訳_ロット別数量    'D-20121217_Ver7.50_3
                Case 仕入データ型.内訳_ロット_Ｎｏ, 仕入データ型.内訳_ロット別数量         'A-20121217_Ver7.50_3
                    If MyImportParam.Myコントロール情報.MyMOAオプション.MOA品質管理 = MOAオプション定義型.その他管理区分型.行う Then
                        isSet = True
                    Else
                        noItemCount += 1
                    End If

                    'A-20121217_Ver7.50_3↓
                Case テキスト出力型.内訳_ロット別数量
                    If MyImportParam.Myコントロール情報.MyMOAオプション.MOA品質管理 = MOAオプション定義型.その他管理区分型.行う Then
                        isSet = True
                    ElseIf MyImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 4D AndAlso
                           MyImportParam.Myコントロール情報.MyMOA機能追加.ロケーション単位数量指定列 = MOA機能追加定義型.ロケーション単位数量指定列.数量列_ロケ＿ロット別 Then    'X1変換Tool-20170508
                        '複数ロケーション対応
                        isSet = True
                    Else
                        noItemCount += 1
                    End If
                    'A-20121217_Ver7.50_3↑

                    'A-20120315_1↓
                Case 仕入データ型.構成品_完納区分
                    If MyImportParam.Myコントロール情報.MyMOAＲＥＶ.MOA強化区分 >= 3.2D Then
                        isSet = True
                    Else
                        noItemCount += 1
                    End If
                    'A-20120315_1↑

                    'A-20121217_Ver7.50_1↓
                Case 仕入データ型.レート, 仕入データ型.レート種類, 仕入データ型.換算基準, 仕入データ型.諸掛管理_Ｎｏ,
                     仕入データ型.按分対象, 仕入データ型.按分基準, 仕入データ型.INVOICE_Ｎｏ
                    If MyImportParam.Myコントロール情報.MyMOAオプション.MOA外貨管理 = MOAオプション定義型.その他管理区分型.行う Then
                        isSet = True
                    Else
                        noItemCount += 1
                    End If
                    'A-20121217_Ver7.50_1↑

                    'A-20160324_1↓
                Case 仕入データ型.レート固定区分
                    If MyImportParam.Myコントロール情報.使用条件(Myコントロール情報Param.条件型.外貨複数伝票消込機能, 8D) = True Then
                        isSet = True
                    Else
                        noItemCount += 1
                    End If
                    'A-20160324_1↑
                    'A-20160324_2↓
                Case 仕入データ型.原価計上手配番号
                    If MyImportParam.Myコントロール情報.使用条件(Myコントロール情報Param.条件型.品目別原価計算機能, 8D) = True Then
                        isSet = True
                    Else
                        noItemCount += 1
                    End If
                    'A-20160324_2↑

                    '    '↓A-2008/07/18_Ver7.30_GENKA
                    'Case 仕入データ型.原価集計メインコード, _
                    '     仕入データ型.原価集計サブコード, _
                    '     仕入データ型.要素コード
                    '    If MyImportParam.Myコントロール情報.Myオプション区分.原価管理 = オプション区分定義型.区分型.行う Then
                    '        isSet = True
                    '    Else
                    '        noItemCount += 1
                    '    End If
                    '    '↑A-2008/07/18_Ver7.30_GENKA

                    '    '↓A-2009/12/18_Ver7.40_UCHIWAKE
                    'Case 仕入データ型.内訳コード１, _
                    '     仕入データ型.内訳コード２, _
                    '     仕入データ型.内訳コード３
                    '    Dim 内訳種別 As 内訳種別型
                    '    Select Case i
                    '        Case 仕入データ型.内訳コード１ : 内訳種別 = 内訳種別型.内訳種別１
                    '        Case 仕入データ型.内訳コード２ : 内訳種別 = 内訳種別型.内訳種別２
                    '        Case 仕入データ型.内訳コード３ : 内訳種別 = 内訳種別型.内訳種別３
                    '    End Select
                    '    If Is内訳コード使用可否判定(内訳種別) = True Then
                    '        isSet = True
                    '    Else
                    '        noItemCount += 1
                    '    End If

                    'Case 仕入データ型.換算数量
                    '    If MyImportParam.Myコントロール情報.My商品内訳管理.換算数量使用区分 = True Then
                    '        isSet = True
                    '    Else
                    '        noItemCount += 1
                    '    End If

                    'Case 仕入データ型.金額算出モード
                    '    If MyImportParam.Myコントロール情報.My商品内訳管理.換算数量使用区分 = True Then
                    '        isSet = True
                    '    Else
                    '        noItemCount += 1
                    '    End If
                    '    '↑A-2009/12/18_Ver7.40_UCHIWAKE

                    '    '↓A-2009/12/18_Ver7.40_LOT
                    'Case 仕入データ型.ロットNo, _
                    '     仕入データ型.サブロットNo
                    '    If MyImportParam.Myコントロール情報.Myオプション区分.ロット管理 = True Then
                    '        isSet = True
                    '    Else
                    '        noItemCount += 1
                    '    End If

                    'Case 仕入データ型.有効期限
                    '    If MyImportParam.Myコントロール情報.Myロット管理.有効期限機能 = True Then
                    '        isSet = True
                    '    Else
                    '        noItemCount += 1
                    '    End If
                    '    '↑A-2009/12/18_Ver7.40_LOT

                Case Else
                    isSet = True
            End Select

            If isSet = True Then
                _項目位置情報(AutoCount(index)) = i - noItemCount
            Else
                AutoCount(index)
            End If

        Next

    End Sub

    Protected Overrides Function ConvertDataImpl(ByRef textItems() As String) As String()
        Dim resultItems(仕入データ型._項目数 - 1) As String
        For i As Integer = 0 To 仕入データ型._項目数 - 1
            resultItems(i) = ""
            If _項目位置情報(i) <> -1 Then '-1 は未使用もしくは未設定項目
                If textItems.Length - 1 >= _項目位置情報(i) Then
                    resultItems(i) = textItems(_項目位置情報(i))
                End If
            End If
        Next

        'オプション未使用時の初期値
        If MyImportParam.Myコントロール情報.Myオプション区分.部門管理 = オプション区分定義型.区分型.行わない Then
            resultItems(仕入データ型.部門コード) = ""
        End If

        'D-CUST20190830↓
        'If MyImportParam.Myコントロール情報.My機能区分.営業所管理 = 機能区分定義型.営業所管理区分型.行わない Then
        '    resultItems(仕入データ型.営業所コード) = ""
        'End If
        'D-CUST20190830↑

        If MyImportParam.Myコントロール情報.My機能区分.倉庫別在庫管理 = 機能区分定義型.倉庫別在庫管理型.行わない Then
            resultItems(仕入データ型.倉庫コード) = "000000"
        End If

        If MyImportParam.Myコントロール情報.My仕入処理.入数個数 = 仕入処理定義型.入数個数使用区分型.使用しない Then
            resultItems(仕入データ型.入数) = "0"
            resultItems(仕入データ型.個数) = "0"
            resultItems(仕入データ型.個数単位) = ""
        End If

        If MyImportParam.Myコントロール情報.My仕入処理.上代 = 仕入処理定義型.上代使用区分型.使用しない Then
            resultItems(仕入データ型.上代単価) = "0"
        End If

        If MyImportParam.Myコントロール情報.My仕入処理.上代 = 仕入処理定義型.上代使用区分型.使用しない OrElse
           MyImportParam.Myコントロール情報.My機能区分.消費税改正対応区分 = 機能区分定義型.消費税改正対応区分型.行わない Then
            resultItems(仕入データ型.上代課税区分) = "0"
        End If

        If MyImportParam.Myコントロール情報.My機能区分.明細単位処理_消費税計算 = 機能区分定義型.消費税計算型.行わない Then
            resultItems(仕入データ型.明細消費税等) = "0"
            'resultItems(仕入データ型.明細消費税計算区分) = "0"     'D-2009/08/18_2
            resultItems(仕入データ型.明細消費税計算区分) = ""       'A-2009/08/18_2
        End If

        If MyImportParam.Myコントロール情報.Myオプション区分.受発注管理 = オプション区分定義型.区分型.行わない Then
            resultItems(仕入データ型.発注番号) = "0"
            'resultItems(仕入データ型.発注行番号) = "0"
        End If

        If MyImportParam.Myコントロール情報.My消費税.仮計上消費税使用区分 = 消費税定義型.仮計上消費税使用区分型.行わない Then
            resultItems(仕入データ型.消費税仮計上区分) = "0"
        End If

        If MyImportParam.Myコントロール情報.Myオプション区分.拡張項目 = オプション区分定義型.区分型.行わない OrElse
           MyImportParam.Myコントロール情報.My拡張項目.拡張項目入力処理画面表示 = 拡張項目設計型.利用区分型.行わない Then
            resultItems(仕入データ型.拡張項目入力パターン番号) = "0000"
        End If

        Dim iEXP As Integer = 0
        For i As Integer = 仕入データ型.伝票拡張項目０１ To 仕入データ型.伝票拡張項目２０
            iEXP += 1
            If MyImportParam.Myコントロール情報.Myオプション区分.拡張項目_仕入伝票 = False OrElse
               拡張伝票.項目情報.項目(iEXP).属性 = [LIB].ExpandItemControl.項目属性型.拡張項目属性型.未使用 Then
                resultItems(i) = ""
            End If
        Next

        If MyImportParam.Myコントロール情報.Myオプション区分.拡張項目_仕入伝票 = False OrElse
           拡張伝票.付箋情報.使用区分 = [LIB].ExpandItemControl.付箋情報型.使用区分型.使用しない Then
            resultItems(仕入データ型.伝票拡張項目付箋色番号) = "0"
        End If

        iEXP = 0
        For i As Integer = 仕入データ型.明細拡張項目０１ To 仕入データ型.明細拡張項目２０
            iEXP += 1
            If MyImportParam.Myコントロール情報.Myオプション区分.拡張項目_仕入明細 = False OrElse
               拡張明細.項目情報.項目(iEXP).属性 = [LIB].ExpandItemControl.項目属性型.拡張項目属性型.未使用 Then
                resultItems(i) = ""
            End If
        Next

        If MyImportParam.Myコントロール情報.Myオプション区分.拡張項目_仕入明細 = False OrElse
           拡張明細.付箋情報.使用区分 = [LIB].ExpandItemControl.付箋情報型.使用区分型.使用しない Then
            resultItems(仕入データ型.明細拡張項目付箋色番号) = "0"
        End If

        ''↓A-2008/07/18_Ver7.30_GENKA
        'If MyImportParam.Myコントロール情報.Myオプション区分.原価管理 = オプション区分定義型.区分型.行わない Then
        '    resultItems(仕入データ型.原価集計メインコード) = ""
        '    resultItems(仕入データ型.原価集計サブコード) = ""
        '    resultItems(仕入データ型.要素コード) = ""
        'End If
        ''↑A-2008/07/18_Ver7.30_GENKA

        ''↓A-2009/12/18_Ver7.40_UCHIWAKE
        'If Is内訳コード使用可否判定(内訳種別型.内訳種別１) = False Then
        '    resultItems(仕入データ型.内訳コード１) = ""
        'End If
        'If Is内訳コード使用可否判定(内訳種別型.内訳種別２) = False Then
        '    resultItems(仕入データ型.内訳コード２) = ""
        'End If
        'If Is内訳コード使用可否判定(内訳種別型.内訳種別３) = False Then
        '    resultItems(仕入データ型.内訳コード３) = ""
        'End If
        'If MyImportParam.Myコントロール情報.My商品内訳管理.換算数量使用区分 = False Then
        '    resultItems(仕入データ型.換算数量) = "0"
        '    resultItems(仕入データ型.金額算出モード) = "0"
        'End If
        ''↑A-2009/12/18_Ver7.40_UCHIWAKE

        ''↓A-2009/12/18_Ver7.40_LOT
        'If MyImportParam.Myコントロール情報.Myオプション区分.ロット管理 = False Then
        '    resultItems(仕入データ型.ロットNo) = ""
        '    resultItems(仕入データ型.サブロットNo) = ""
        'End If

        'If MyImportParam.Myコントロール情報.Myロット管理.有効期限機能 = False Then
        '    resultItems(仕入データ型.有効期限) = "0"
        'End If
        ''↑A-2009/12/18_Ver7.40_LOT

        Return resultItems
    End Function

    Private Function AutoCount(ByRef value As Integer) As Integer
        value += 1
        Return value
    End Function

#End Region

#Region "商品内訳管理"  'A-2009/12/18_Ver7.40_UCHIWAKE

    Private Function Is内訳コード使用可否判定(ByVal 内訳種別 As 内訳種別型) As Boolean  'A-2009/12/18_Ver7.40_UCHIWAKE

        If MyImportParam.Myコントロール情報.Myオプション区分.商品内訳管理 = False Then
            Return False
        End If

        If MyImportParam.Myコントロール情報.My商品内訳管理.内訳管理数 < 内訳種別 Then
            Return False
        End If

        Return True
    End Function

#End Region

#End Region

End Class
