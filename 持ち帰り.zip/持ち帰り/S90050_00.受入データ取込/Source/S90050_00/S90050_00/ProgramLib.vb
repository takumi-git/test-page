﻿''' <summary>
''' 業務プログラム固有の定義
''' </summary>
''' <remarks></remarks>
Public Class ProgramLib

#Region "定数"

    'Public Const 帳票タイトル As String = "SEI入荷データ取込エラーリスト" 'D-CUST20190830
    Public Const 帳票タイトル As String = "SEI受入データ取込エラーリスト"  'A-CUST20190830
    Public Const プログラム専用_仕入伝票拡張項目有無 As String = "プログラム専用.仕入伝票拡張項目有無"
    Public Const プログラム専用_仕入明細拡張項目有無 As String = "プログラム専用.仕入明細拡張項目有無"
    Public Const プログラム専用_仕入伝票拡張更新番号 As String = "プログラム専用.仕入伝票拡張更新番号"
    Public Const プログラム専用_仕入明細拡張更新番号 As String = "プログラム専用.仕入明細拡張更新番号"

    Public Const プログラム専用_発注伝票拡張項目有無 As String = "プログラム専用.発注伝票拡張項目有無"
    Public Const プログラム専用_発注明細拡張項目有無 As String = "プログラム専用.発注明細拡張項目有無"
    Public Const プログラム専用_発注伝票拡張更新番号 As String = "プログラム専用.発注伝票拡張更新番号"
    Public Const プログラム専用_発注明細拡張更新番号 As String = "プログラム専用.発注明細拡張更新番号"

    Public Const プログラム専用_入荷伝票拡張項目有無 As String = "プログラム専用.入荷伝票拡張項目有無"
    Public Const プログラム専用_入荷明細拡張項目有無 As String = "プログラム専用.入荷明細拡張項目有無"
    Public Const プログラム専用_入荷伝票拡張更新番号 As String = "プログラム専用.入荷伝票拡張更新番号"
    Public Const プログラム専用_入荷明細拡張更新番号 As String = "プログラム専用.入荷明細拡張更新番号"

    'A-CUST20190830↓
    Public Const プログラム専用_入出庫伝票拡張項目有無 As String = "プログラム専用.入出庫伝票拡張項目有無"
    Public Const プログラム専用_入出庫明細拡張項目有無 As String = "プログラム専用.入出庫明細拡張項目有無"
    Public Const プログラム専用_入出庫伝票拡張更新番号 As String = "プログラム専用.入出庫伝票拡張更新番号"
    Public Const プログラム専用_入出庫明細拡張更新番号 As String = "プログラム専用.入出庫明細拡張更新番号"
    'A-CUST20190830↑

    Public Const MAX_DETAIL_COUNT As Integer = 999
    Public Const MAX_EXPANDITEM_COUNT As Integer = 20

#End Region

#Region "構造体"

    Public Structure 連番管理テーブル型
        Dim C021002 As Long         '処理連番
    End Structure

    Public Structure 伝票番号管理テーブル型
        Dim C022004 As Integer      '仕入伝票番号
        Dim C022006 As Integer      '入出庫伝票番号
        Dim C022009 As Integer      '入出荷伝票番号
        Dim C022A002 As Integer     '製造出庫伝票番号
        Dim C022A005 As Integer     '仕掛入出庫伝票番号
    End Structure

    Public Structure ロットNo連番管理テーブル型 'A-2009/12/18_Ver7.40_LOT
        Dim C023002 As Decimal      'ロット№(連番)
        Dim 更新対象 As Boolean     '更新を行う時(採番を行った時)True
    End Structure

    Public Structure ロット連番管理テーブル型
        Dim C056001 As Integer
        Dim C056002 As String
        Dim C056003 As String
        Dim 更新区分 As 更新区分型
    End Structure

#Region "マスター"

    Public Structure 仕入先マスター型
        Dim M002001 As String           '支払先コード
        Dim M002041 As Integer          '端数処理区分 単価 
        Dim M002042 As Integer          '端数処理単位 単価 
        Dim M002043 As Integer          '端数処理区分 金額
        'A-CUST20190830↓
        Dim M002044 As Integer
        Dim M002045 As Integer
        'A-CUST20190830↑
        Dim M002046 As Integer          '端数処理区分 消費税分解
        Dim M002050 As Integer          '消費税通知区分
        '↓A-2008/07/18_Ver7.30_SHIHARAI
        Dim M002027SHIHARAI As Integer  '締日１
        Dim M002028SHIHARAI As Integer  '締日２
        Dim M002029SHIHARAI As Integer  '締日３
        Dim M002030SHIHARAI As Integer  '支払日１
        Dim M002031SHIHARAI As Integer  '支払日２
        Dim M002032SHIHARAI As Integer  '支払日３
        Dim M002033SHIHARAI As Integer  '支払サイクル１
        Dim M002034SHIHARAI As Integer  '支払サイクル２
        Dim M002035SHIHARAI As Integer  '支払サイクル３
        Dim M002090SHIHARAI As Integer  '支払管理区分
        Dim M002091SHIHARAI As Integer  '支払管理単位
        '↑A-2008/07/18_Ver7.30_SHIHARAI
        Dim M002989SHIHARAI As Integer  '締日付
        Dim M035011 As Integer          '支払処理連番(締処理グループマスター)

        'A-20121217_Ver7.50_1↓
        Dim M002S004 As Integer         '海外取引先区分         
        Dim M002S005 As String          '通貨コード             
        Dim M002S008 As Integer         '単価区分（外貨）       
        Dim M002S009 As Integer         '金額区分（外貨）       
        Dim M002S010 As Integer         '支払予定日             

        Dim M013001 As String           '通貨コード
        Dim M013006 As Integer          'レート桁数
        Dim M013007 As Integer          '通貨単位
        Dim M013S002 As Integer         '入力桁数(金額)(仕入)
        Dim M013S003 As Integer         '入力桁数(単価)(仕入)
        'A-20121217_Ver7.50_1↑
    End Structure

    Public Structure 商品マスター型
        Dim M003002 As String       '商品名
        Dim M003004 As String       '個数単位
        Dim M003007 As Integer      'セット品区分
        Dim M003008 As Integer      '在庫管理区分
        Dim M003039 As Integer      '単価変更日付
        Dim M003042 As Integer      '非課税区分
        Dim M003045 As Integer      '消費税率区分
        Dim M003051 As Integer      '内訳管理区分 種別１    'A-2009/12/18_Ver7.40_UCHIWAKE
        Dim M003052 As Integer      '内訳管理区分 種別２    'A-2009/12/18_Ver7.40_UCHIWAKE
        Dim M003053 As Integer      '内訳管理区分 種別３    'A-2009/12/18_Ver7.40_UCHIWAKE
        Dim M003054 As Integer      '在庫引当対象区分       'A-20121217_Ver7.50_2
        Dim M003086 As Integer      '換算数量使用区分       'A-2009/12/18_Ver7.40_UCHIWAKE
        Dim M003092 As Integer      'ロット管理区分         'A-2009/12/18_Ver7.40_UCHIWAKE
        Dim M003093 As Integer      '在庫評価算出単位       'A-2009/12/18_Ver7.40_LOT
        Dim M003094 As Integer      '有効日数               'A-2009/12/18_Ver7.40_LOT

        Dim M003A005 As Integer     '手配方式
        Dim M003A010 As String      '基準倉庫コード         'A-20141105_2
        Dim M003A014 As String      '品目名１
        Dim M003A015 As String      '品目名２
        Dim M003A016 As String      '品目名３
        Dim M003A017 As Integer     '在庫引当区分
        Dim M003A019 As Integer     '検査方法
        Dim M003A024 As Integer     'ロット管理区分
        Dim M003A026 As Decimal     '発注単位変換係数

        Dim M003A027 As String      '基準ロケーション       'A-20141105_2
        Dim M003A028 As Integer     '品目区分
        Dim M003A029 As Integer     '使用禁止日
        Dim M003A030 As Decimal     '
        Dim M003A031 As Decimal     '
        Dim M003A032 As Decimal     '
        Dim M003S015 As Decimal     '出庫まるめ数           'A-20130304_1
        Dim M003S030 As Decimal     '経費                   'A-20141105_1

        Dim 標準売上単価 As Decimal
        Dim 標準仕入単価 As Decimal
    End Structure

    Public Structure 倉庫マスター型
        Dim M006002 As String       '倉庫名
        Dim M006A001 As Integer     '倉庫区分
        Dim M006A002 As Integer     '所要量計算区分
        Dim マスタ存在 As Boolean
    End Structure

    Public Structure 商品内訳マスター型     'A-2009/12/18_Ver7.40_UCHIWAKE 
        Dim M023001 As String       '商品コード
        Dim M023002 As String       '内訳コード１
        Dim M023003 As String       '内訳コード２
        Dim M023004 As String       '内訳コード３
        Dim M023006 As Decimal      '単位換算数量
        Sub 初期化()
            M023001 = ""
            M023002 = ""
            M023003 = ""
            M023004 = ""
            M023006 = 0
        End Sub
    End Structure

    Public Structure ロットマスター型       'A-2009/12/18_Ver7.40_LOT
        Dim M045001 As String       '商品コード
        Dim M045002 As String       '内訳コード１
        Dim M045003 As String       '内訳コード２
        Dim M045004 As String       '内訳コード３
        Dim M045005 As String       'ロットNo
        Dim M045010 As Integer      '完了区分
        Sub 初期化()
            M045001 = ""
            M045002 = ""
            M045003 = ""
            M045004 = ""
            M045005 = ""
            M045010 = 0
        End Sub
    End Structure

    Public Structure 製番マスター型
        Dim M050001 As String           '製番 
        Dim M050002 As Integer          '種別                   'A-20111025_1
        Dim M050003 As Integer          '状態区分
        Dim M050004 As String           '品目コード             'A-20111025_3
        Dim M050005 As String           '品目名称               'A-20111025_3
        Dim M050006 As String           '品目名１               'A-20111025_3
        Dim M050007 As String           '品目名２               'A-20111025_3
        Dim M050008 As String           '品目名３               'A-20111025_3
        Dim M050011 As Long             '手配管理/発注番号
        Dim M050015 As Integer          '手配データ区分
        Dim M050016 As Integer          '製番区分               'A-20111025_1
        Dim M050019 As Long             '受注番号
        Dim M050020 As Integer          '受注行番号
        Dim M050021 As Integer          '受注形態
        Dim M050022 As Integer          '受注区分
        Dim M050038 As Integer          '完了日
        Dim M050039 As Integer          '原価振替済区分
        Dim 客先注番 As String          '受発注明細.ｵｰﾀﾞｰ
        Dim M050046 As Integer          '完了区分               'A-20150520_2
    End Structure

#End Region

#Region "取引伝票"

    Public Structure 仕入ヘッダー型
        ''' <summary>取引先区分</summary>
        Dim R001001 As Integer
        ''' <summary>取引先コード</summary>
        Dim R001002 As String
        ''' <summary>伝票日付</summary>
        Dim R001003 As Integer
        ''' <summary>伝票区分</summary>
        Dim R001004 As Integer
        ''' <summary>伝票番号</summary>
        Dim R001005 As Integer
        ''' <summary>処理連番</summary>
        Dim R001006 As Long
        ''' <summary>操作日付</summary>
        Dim R001007 As Integer
        ''' <summary>ログインＩＤ</summary>
        Dim R001008 As String
        ''' <summary>チェックマーク区分</summary>
        Dim R001009 As Integer
        ''' <summary>取引区分</summary>
        Dim R001010 As Integer
        ''' <summary>担当者コード</summary>
        Dim R001011 As String
        ''' <summary>納品先コード</summary>
        Dim R001012 As String
        ''' <summary>倉庫コード</summary>
        Dim R001013 As String
        ''' <summary>部門コード</summary>
        Dim R001014 As String
        ''' <summary>受発注番号</summary>
        Dim R001015 As Long
        ''' <summary>見積処理連番</summary>
        Dim R001016 As Long
        ''' <summary>相手処理連番</summary>
        Dim R001017 As Long
        ''' <summary>買掛区分</summary>
        Dim R001018 As Integer
        ''' <summary>支払区分</summary>
        Dim R001019 As Integer
        ''' <summary>台帳用支払区分</summary>
        Dim R001020 As Integer
        ''' <summary>支払処理連番</summary>
        Dim R001021 As Integer
        ''' <summary>消費税計算区分</summary>
        Dim R001022 As Integer
        ''' <summary>消費税率</summary>
        Dim R001023 As Decimal
        ''' <summary>自動生成データ区分</summary>
        Dim R001024 As Integer
        ''' <summary>伝票行数</summary>
        Dim R001025 As Integer
        ''' <summary>備考コード</summary>
        Dim R001026 As String
        ''' <summary>備考</summary>
        Dim R001027 As String
        ''' <summary>税込 仕入額</summary>
        Dim R001028 As Decimal
        ''' <summary>税込 返品額</summary>
        Dim R001029 As Decimal
        ''' <summary>税込 値引額</summary>
        Dim R001030 As Decimal
        ''' <summary>内消費税 仕入額</summary>
        Dim R001031 As Decimal
        ''' <summary>内消費税 返品額</summary>
        Dim R001032 As Decimal
        ''' <summary>内消費税 値引額</summary>
        Dim R001033 As Decimal
        ''' <summary>税抜 仕入額</summary>
        Dim R001034 As Decimal
        ''' <summary>税抜 返品額</summary>
        Dim R001035 As Decimal
        ''' <summary>税抜 値引額</summary>
        Dim R001036 As Decimal
        ''' <summary>外税 仕入額</summary>
        Dim R001037 As Decimal
        ''' <summary>外税 返品額</summary>
        Dim R001038 As Decimal
        ''' <summary>外税 値引額</summary>
        Dim R001039 As Decimal
        ''' <summary>非課税 仕入額</summary>
        Dim R001040 As Decimal
        ''' <summary>非課税 返品額</summary>
        Dim R001041 As Decimal
        ''' <summary>非課税 値引額</summary>
        Dim R001042 As Decimal
        ''' <summary> F </summary>
        Dim R001043 As Decimal
        ''' <summary> F </summary>
        Dim R001044 As Decimal
        ''' <summary> F </summary>
        Dim R001045 As Decimal
        ''' <summary>入金 現金</summary>
        Dim R001046 As Decimal
        ''' <summary>入金 振込</summary>
        Dim R001047 As Decimal
        ''' <summary>入金 相殺</summary>
        Dim R001048 As Decimal
        ''' <summary>入金 手形</summary>
        Dim R001049 As Decimal
        ''' <summary>入金 値引</summary>
        Dim R001050 As Decimal
        ''' <summary>入金 調整</summary>
        Dim R001051 As Decimal
        ''' <summary>粗利額</summary>
        Dim R001052 As Decimal
        ''' <summary>手入力仕入先名１</summary>
        Dim R001053 As String
        ''' <summary>手入力仕入先名２</summary>
        Dim R001054 As String
        ''' <summary>手入力納品先名</summary>
        Dim R001055 As String
        ''' <summary>通貨コード</summary>
        Dim R001056 As String
        ''' <summary>ピッキング計上区分</summary>
        Dim R001057 As Integer
        ''' <summary>ＥＢ連番</summary>
        Dim R001058 As Long
        ''' <summary>財務連結区分</summary>
        Dim R001059 As Integer
        ''' <summary>財務処理連番</summary>
        Dim R001060 As Long
        ''' <summary>データ発生区分</summary>
        Dim R001061 As Integer
        ''' <summary>仮計上消費税 計上区分</summary>
        Dim R001062 As Integer
        ''' <summary>仮計上消費税 計算区分</summary>
        Dim R001063 As Integer
        ''' <summary>仕訳変更区分</summary>
        Dim R001064 As Integer
        ''' <summary>仕訳対象外区分</summary>
        Dim R001065 As Integer
        ''' <summary>支払締日付</summary>
        Dim R001066 As Integer
        ''' <summary>支払予定日</summary>
        Dim R001067 As Integer
        ''' <summary>入荷処理連番</summary>
        Dim R001068 As Long
        ''' <summary>計上区分</summary>
        Dim R001069 As Integer
        ''' <summary>対外帳票対象外区分</summary>
        Dim R001070 As Integer
        ''' <summary>オーダーコード</summary>
        Dim R001071 As String
        ''' <summary>伝票出力対象外行数</summary>
        Dim R001072 As Integer
        ''' <summary>営業所コード</summary>
        Dim R001073 As String
        ''' <summary>入出庫区分</summary>
        Dim R001074 As Integer
        ''' <summary>支払書番号</summary>
        Dim R001075 As Integer
        ''' <summary>締処理グループ</summary>
        Dim R001076 As String
        ''' <summary>更新番号</summary>
        Dim R001999 As Long
        '↓A-2008/07/18_Ver7.30_GENKA
        ''' <summary>原価集計コード</summary>
        Dim R001077 As String
        ''' <summary>原価集計サブコード</summary>
        Dim R001078 As String
        '↑A-2008/07/18_Ver7.30_GENKA
        '↓A-2009/08/21_RIREKI
        ''' <summary>履歴№</summary>
        Dim R001911 As Integer
        ''' <summary>最終更新操作日付</summary>
        Dim R001914 As Integer
        ''' <summary>最終更新操作時刻</summary>
        Dim R001915 As Integer
        ''' <summary>最終更新ログインID</summary>
        Dim R001916 As String
        ''' <summary>操作プログラムID</summary>
        Dim R001917 As String
        ''' <summary>操作プログラムID枝番</summary>
        Dim R001918 As Integer
        ''' <summary>操作コンピュータ名</summary>
        Dim R001919 As String
        '↑A-2009/08/21_RIREKI

        ''' <summary>製番</summary>
        Dim R001A001 As String
        ''' <summary>製番 メイン</summary>
        Dim R001A002 As String
        ''' <summary>製番 枝番</summary>
        Dim R001A003 As String
        ''' <summary>発生区分</summary>
        Dim R001A004 As Integer
        ''' <summary>発生元相手連番</summary>
        Dim R001A005 As Long
        ''' <summary>受入区分</summary>
        Dim R001A006 As Integer
        ''' <summary>発注区分</summary>
        Dim R001A007 As Integer
        ''' <summary>相手連番</summary>
        Dim R001A008 As Long
        ''' <summary>完成品区分</summary>
        Dim R001A009 As Integer
        ''' <summary>返品区分</summary>
        Dim R001A010 As Integer
        ''' <summary>元入出荷処理連番</summary>
        Dim R001A011 As Long
        ''' <summary>プロジェクトメインコード</summary>
        Dim R001A012 As String
        ''' <summary>プロジェクトサブコード</summary>
        Dim R001A013 As String
        ''' <summary>売上データ生成区分</summary>
        Dim R001A014 As Integer
        ''' <summary>構成品出庫生成区分</summary>
        Dim R001A015 As Integer
        ''' <summary>入出荷伝票番号</summary>
        Dim R001A016 As Integer

        'A-20111124_11↓
        ''' <summary>仕掛生成区分</summary>
        Dim R001S002 As Integer
        'A-20111124_11↑

        'A-20121217_Ver7.50_1↓
        ''' <summary>入力通貨区分</summary>
        Dim R001087 As Integer
        ''' <summary>レート種類</summary>
        Dim R001088 As Integer
        ''' <summary>レート</summary>
        Dim R001089 As Decimal
        'A-20160324_1↓
        ''' <summary>外貨管理 レート固定区分</summary>
        Dim R001095 As Integer
        ''' <summary>外貨管理 外貨 売上額</summary>
        Dim R001096 As Decimal
        ''' <summary>外貨管理 外貨 返品額</summary>
        Dim R001097 As Decimal
        ''' <summary>外貨管理 外貨 値引額</summary>
        Dim R001098 As Decimal
        ''' <summary>外貨管理 外貨入金 現金</summary>
        Dim R001099 As Decimal
        ''' <summary>外貨管理 外貨入金 振込</summary>
        Dim R001100 As Decimal
        ''' <summary>外貨管理 外貨入金 相殺</summary>
        Dim R001101 As Decimal
        ''' <summary>外貨管理 外貨入金 手形</summary>
        Dim R001102 As Decimal
        ''' <summary>外貨管理 外貨入金 値引</summary>
        Dim R001103 As Decimal
        ''' <summary>外貨管理 外貨入金 調整</summary>
        Dim R001104 As Decimal
        ''' <summary>外貨管理 外貨 粗利額</summary>
        Dim R001105 As Decimal
        'A-20160324_1↑
        ''' <summary>レート換算基準区分</summary>
        Dim R001S003 As Integer
        ''' <summary>非課税売上 売上額(外貨)</summary>
        Dim R001S004 As Decimal
        ''' <summary>非課税売上 返品額(外貨)</summary>
        Dim R001S005 As Decimal
        ''' <summary>非課税売上 値引額(外貨)</summary>
        Dim R001S006 As Decimal
        ''' <summary>入金現金(外貨)</summary>
        Dim R001S007 As Decimal
        ''' <summary>入金振込(外貨)</summary>
        Dim R001S008 As Decimal
        ''' <summary>入金相殺(外貨)</summary>
        Dim R001S009 As Decimal
        ''' <summary>入金手形(外貨)</summary>
        Dim R001S010 As Decimal
        ''' <summary>入金値引(外貨)</summary>
        Dim R001S011 As Decimal
        ''' <summary>入金調整(外貨)</summary>
        Dim R001S012 As Decimal
        ''' <summary>粗利額(外貨)</summary>
        Dim R001S013 As Decimal
        ''' <summary>INVOICE№</summary>
        Dim R001S014 As String
        'A-20121217_Ver7.50_1↑
        'A-20160324_1↓
        ''' <summary>邦貨手入力区分</summary>
        Dim R001S015 As Integer
        'A-20160324_1↑

        ''' <summary>拡張項目</summary>
        Dim 拡張項目入力情報 As I拡張項目入力情報型
    End Structure

    Public Structure 仕入明細型
        ''' <summary>伝票日付</summary>
        Dim R002001 As Integer
        ''' <summary>伝票区分</summary>
        Dim R002002 As Integer
        ''' <summary>伝票番号</summary>
        Dim R002003 As Integer
        ''' <summary>処理連番</summary>
        Dim R002004 As Long
        ''' <summary>明細区分</summary>
        Dim R002005 As Integer
        ''' <summary>行番号</summary>
        Dim R002006 As Integer
        ''' <summary>取引先区分</summary>
        Dim R002007 As Integer
        ''' <summary>取引先コード</summary>
        Dim R002008 As String
        ''' <summary>担当者コード</summary>
        Dim R002009 As String
        ''' <summary>取引区分</summary>
        Dim R002010 As Integer
        ''' <summary>受発注番号</summary>
        Dim R002011 As Long
        ''' <summary>受発注行番号</summary>
        Dim R002012 As Integer
        ''' <summary>見積処理連番</summary>
        Dim R002013 As Long
        ''' <summary>見積行番号</summary>
        Dim R002014 As Integer
        ''' <summary>相手処理連番</summary>
        Dim R002015 As Long
        ''' <summary>相手行番号</summary>
        Dim R002016 As Integer
        ''' <summary>部門コード</summary>
        Dim R002017 As String
        ''' <summary>倉庫コード</summary>
        Dim R002018 As String
        ''' <summary>商品コード</summary>
        Dim R002019 As String
        ''' <summary>商品名</summary>
        Dim R002020 As String
        ''' <summary>数量単位</summary>
        Dim R002021 As String
        ''' <summary>入数</summary>
        Dim R002022 As Decimal
        ''' <summary>個数</summary>
        Dim R002023 As Decimal
        ''' <summary>個数単位</summary>
        Dim R002024 As String
        ''' <summary>数量</summary>
        Dim R002025 As Decimal
        ''' <summary>単価</summary>
        Dim R002026 As Decimal
        ''' <summary>金額</summary>
        Dim R002027 As Decimal
        ''' <summary>原単価</summary>
        Dim R002028 As Decimal
        ''' <summary>単価計算方法</summary>
        Dim R002029 As Integer
        ''' <summary>単価掛率</summary>
        Dim R002030 As Decimal
        ''' <summary>標準売上単価</summary>
        Dim R002031 As Decimal
        ''' <summary>標準仕入単価</summary>
        Dim R002032 As Decimal
        ''' <summary>上代単価</summary>
        Dim R002033 As Decimal
        ''' <summary>粗利額</summary>
        Dim R002034 As Decimal
        ''' <summary>数量内訳 仕入</summary>
        Dim R002035 As Decimal
        ''' <summary>数量内訳 返品</summary>
        Dim R002036 As Decimal
        ''' <summary>数量内訳 見本</summary>
        Dim R002037 As Decimal
        ''' <summary>数量内訳 入庫</summary>
        Dim R002038 As Decimal
        ''' <summary>数量内訳 出庫</summary>
        Dim R002039 As Decimal
        ''' <summary>金額内訳 仕入</summary>
        Dim R002040 As Decimal
        ''' <summary>金額内訳 返品</summary>
        Dim R002041 As Decimal
        ''' <summary>金額内訳 値引</summary>
        Dim R002042 As Decimal
        ''' <summary>金額内訳 入庫</summary>
        Dim R002043 As Decimal
        ''' <summary> F </summary>
        Dim R002044 As Decimal
        ''' <summary> F </summary>
        Dim R002045 As Decimal
        ''' <summary> F </summary>
        Dim R002046 As Decimal
        ''' <summary>課税区分</summary>
        Dim R002047 As Integer
        ''' <summary>消費税率</summary>
        Dim R002048 As Decimal
        ''' <summary>内消費税額</summary>
        Dim R002049 As Decimal
        ''' <summary>外税額(明細消費税用)</summary>
        Dim R002050 As Decimal
        ''' <summary>消費税計算区分</summary>
        Dim R002051 As Integer
        ''' <summary>完納区分</summary>
        Dim R002052 As Integer
        ''' <summary>行摘要コード</summary>
        Dim R002053 As String
        ''' <summary>行摘要１</summary>
        Dim R002054 As String
        ''' <summary>行摘要２</summary>
        Dim R002055 As String
        ''' <summary>手形決済予定日</summary>
        Dim R002056 As Integer
        ''' <summary>取引区分属性</summary>
        Dim R002057 As Integer
        ''' <summary>入出庫区分</summary>
        Dim R002058 As Integer
        ''' <summary>通貨コード</summary>
        Dim R002059 As String
        ''' <summary>セット品入出庫伝票処理連番</summary>
        Dim R002060 As Long
        ''' <summary>財務連結区分</summary>
        Dim R002061 As Integer
        ''' <summary>財務処理連番</summary>
        Dim R002062 As Long
        ''' <summary>財務 仕訳行№</summary>
        Dim R002063 As Integer
        ''' <summary>連結 貸借区分</summary>
        Dim R002064 As Integer
        ''' <summary>データ発生区分</summary>
        Dim R002065 As Integer
        ''' <summary>内訳コード１</summary>
        Dim R002066 As String
        ''' <summary>内訳コード２</summary>
        Dim R002067 As String
        ''' <summary>内訳コード３</summary>
        Dim R002068 As String
        ''' <summary>上代課税区分</summary>
        Dim R002069 As Integer
        ''' <summary>入出荷処理連番</summary>
        Dim R002070 As Long
        ''' <summary>入出荷行番号</summary>
        Dim R002071 As Integer
        ''' <summary>対外帳票対象外区分</summary>
        Dim R002072 As Integer
        ''' <summary>オーダーコード</summary>
        Dim R002073 As String
        ''' <summary>売掛区分</summary>
        Dim R002074 As Integer
        ''' <summary>原価金額</summary>
        Dim R002075 As Decimal
        ''' <summary>営業所コード</summary>
        Dim R002076 As String
        ''' <summary>拡張項目入力パターン№</summary>
        Dim R002077 As String
        ''' <summary>更新番号</summary>
        Dim R002999 As Long
        '↓A-2008/07/18_Ver7.30_GENKA
        ''' <summary>原価集計コード</summary>
        Dim R002078 As String
        ''' <summary>原価集計サブコード</summary>
        Dim R002079 As String
        ''' <summary>要素コード</summary>
        Dim R002080 As String
        '↑A-2008/07/18_Ver7.30_GENKA
        '↓A-2009/12/18_Ver7.40_UCHIWAKE
        ''' <summary>換算数量</summary>
        Dim R002083 As Decimal
        ''' <summary>金額算出モード</summary>
        Dim R002084 As Integer
        '↑A-2009/12/18_Ver7.40_UCHIWAKE
        ''' <summary>ロットNo</summary>             'A-2009/12/18_Ver7.40_LOT
        Dim R002086 As String                       'A-2009/12/18_Ver7.40_LOT

        ''' <summary>品目名１</summary>
        Dim R002A001 As String
        ''' <summary>品目名２</summary>
        Dim R002A002 As String
        ''' <summary>品目名３</summary>
        Dim R002A003 As String
        ''' <summary>発生区分</summary>
        Dim R002A004 As Integer
        ''' <summary>発生元相手連番</summary>
        Dim R002A005 As Long
        ''' <summary>製番</summary>
        Dim R002A006 As String
        ''' <summary>製番 メイン</summary>
        Dim R002A007 As String
        ''' <summary>製番 枝番</summary>
        Dim R002A008 As String
        ''' <summary>ロット管理区分</summary>
        Dim R002A009 As Integer
        ''' <summary>ロット№</summary>
        Dim R002A010 As String
        ''' <summary>有効期限</summary>
        Dim R002A011 As Integer
        ''' <summary>ロケーション</summary>
        Dim R002A012 As String
        ''' <summary>仮単価区分</summary>
        Dim R002A013 As Integer
        ''' <summary>受入数量(在庫単位)</summary>
        Dim R002A014 As Decimal
        ''' <summary>受入単位(在庫単位)</summary>
        Dim R002A015 As String
        ''' <summary>発注単位変換係数</summary>
        Dim R002A016 As Decimal
        ''' <summary>不良数量(在庫単位)</summary>
        Dim R002A017 As Decimal
        ''' <summary>不良数量(発注単位)</summary>
        Dim R002A018 As Decimal
        ''' <summary>受入区分</summary>
        Dim R002A019 As Integer
        ''' <summary>発注区分</summary>
        Dim R002A020 As Integer
        ''' <summary>子部品引当区分</summary>
        Dim R002A021 As Integer
        ''' <summary>工程コード</summary>
        Dim R002A022 As String
        ''' <summary>相手連番</summary>
        Dim R002A023 As Long
        ''' <summary>完成品区分</summary>
        Dim R002A024 As Integer
        ''' <summary>発注確定区分</summary>
        Dim R002A025 As Integer
        ''' <summary>手配番号</summary>
        Dim R002A026 As Long
        ''' <summary>手配管理番号</summary>
        Dim R002A027 As Long
        ''' <summary>個別発注連番</summary>
        Dim R002A028 As Long
        ''' <summary>展開順序番号</summary>
        Dim R002A029 As Decimal
        ''' <summary>費目コード</summary>
        Dim R002A030 As String
        ''' <summary>出庫単価</summary>
        Dim R002A031 As Decimal
        ''' <summary>出庫金額</summary>
        Dim R002A032 As Decimal
        ''' <summary>費目区分</summary>
        Dim R002A033 As Integer
        ''' <summary>元入出荷連番</summary>
        Dim R002A034 As Long
        ''' <summary>元入出荷行番号</summary>
        Dim R002A035 As Integer
        ''' <summary>入出荷伝票番号</summary>
        Dim R002A036 As Integer
        ''' <summary>費目コード・材料費</summary>
        Dim R002A037 As String
        ''' <summary>費目コード・労務費</summary>
        Dim R002A038 As String
        ''' <summary>費目コード・外注費</summary>
        Dim R002A039 As String
        ''' <summary>出庫金額・材料費</summary>
        Dim R002A040 As Decimal
        ''' <summary>出庫金額・労務費</summary>
        Dim R002A041 As Decimal
        ''' <summary>出庫金額外注費</summary>
        Dim R002A042 As Decimal

        'A-20121217_Ver7.50_1↓
        ''' <summary>入力通貨区分</summary>
        Dim R002101 As Integer
        ''' <summary>レート種類</summary>
        Dim R002102 As Integer
        ''' <summary>レート</summary>
        Dim R002103 As Decimal
        ''' <summary>外貨金額</summary>
        Dim R002104 As Decimal
        ''' <summary>決算時評価替区分</summary>
        Dim R002105 As Integer
        ''' <summary>売上(仕入)円貨金額</summary>
        Dim R002106 As Decimal
        ''' <summary>売上(仕入)レート</summary>
        Dim R002107 As Decimal
        'A-20160324_1↓
        ''' <summary>外貨管理 単価</summary>
        Dim R002108 As Decimal
        ''' <summary>外貨管理 原単価</summary>
        Dim R002109 As Decimal
        ''' <summary>外貨管理 原価金額</summary>
        Dim R002110 As Decimal
        ''' <summary>外貨管理 粗利額</summary>
        Dim R002112 As Decimal
        ''' <summary>外貨管理 売上(仕入)金額</summary>
        Dim R002113 As Decimal
        ''' <summary>外貨管理 返品金額</summary>
        Dim R002114 As Decimal
        ''' <summary>外貨管理 値引金額</summary>
        Dim R002115 As Decimal
        'A-20160324_1↑
        ''' <summary>単価(外貨)</summary>
        Dim R002S001 As Decimal
        ''' <summary>税抜売上 売上額(外貨)</summary>
        Dim R002S002 As Decimal
        ''' <summary>税抜売上 返品額(外貨)</summary>
        Dim R002S003 As Decimal
        ''' <summary>税抜売上 値引額(外貨)</summary>
        Dim R002S004 As Decimal
        ''' <summary>原単価(外貨)</summary>
        Dim R002S005 As Decimal
        ''' <summary>原価金額(外貨)</summary>
        Dim R002S006 As Decimal
        ''' <summary>粗利額(外貨)</summary>
        Dim R002S007 As Decimal
        ''' <summary>外国語品目名１</summary>
        Dim R002S008 As String
        ''' <summary>外国語品目名２</summary>
        Dim R002S009 As String
        ''' <summary>外国語品目名３</summary>
        Dim R002S010 As String
        ''' <summary>外国語単位</summary>
        Dim R002S011 As String
        ''' <summary>外国語個数単位</summary>
        Dim R002S012 As String
        ''' <summary>諸掛管理№</summary>
        Dim R002S013 As String
        ''' <summary>按分対象区分</summary>
        Dim R002S014 As Integer
        ''' <summary>按分区分</summary>
        Dim R002S015 As Integer
        ''' <summary>按分済区分</summary>
        Dim R002S016 As Integer
        'A-20121217_Ver7.50_1↑
        'A-20141105_1↓
        ''' <summary>費目コード・経費</summary>
        Dim R002S017 As String
        ''' <summary>出庫金額・経費</summary>
        Dim R002S018 As Decimal
        'A-20141105_1↑
        'A-20160324_2↓
        ''' <summary>原価計上手配番号</summary>
        Dim R002S020 As Long
        'A-20160324_2↑

        ''' <summary>拡張項目</summary>
        Dim 拡張項目入力情報 As I拡張項目入力情報型
        ''' <summary>内訳更新情報</summary>         'A-2009/12/18_Ver7.40_UCHIWAKE
        Dim 内訳更新情報 As 内訳更新情報型          'A-2009/12/18_Ver7.40_UCHIWAKE
        ''' <summary>ロット更新情報</summary>       'A-2009/12/18_Ver7.40_LOT
        Dim ロット更新情報 As ロット更新情報型      'A-2009/12/18_Ver7.40_LOT
    End Structure

#End Region

#Region "入出荷"

    Public Structure 入出荷ヘッダー型
        Dim R010001 As Integer
        Dim R010002 As String
        Dim R010003 As Integer
        Dim R010004 As Integer
        Dim R010005 As Long
        Dim R010006 As Integer
        Dim R010007 As Integer
        Dim R010008 As Integer
        Dim R010009 As String
        Dim R010010 As Integer
        Dim R010011 As String
        Dim R010012 As String
        Dim R010013 As String
        Dim R010014 As String
        Dim R010015 As String
        Dim R010016 As Long
        Dim R010017 As Integer
        Dim R010018 As Integer
        Dim R010019 As Integer
        Dim R010020 As Decimal
        Dim R010021 As Integer
        Dim R010022 As String
        Dim R010023 As String
        Dim R010024 As String
        Dim R010025 As String
        Dim R010026 As String
        Dim R010027 As String
        Dim R010028 As Integer
        Dim R010029 As Integer
        Dim R010030 As Integer
        Dim R010031 As Integer
        Dim R010032 As String
        Dim R010033 As Integer
        Dim R010034 As Integer
        Dim R010035 As String
        Dim R010036 As String
        Dim R010037 As String
        Dim R010038 As String
        Dim R010039 As String
        Dim R010040 As Integer
        Dim R010041 As Integer
        Dim R010042 As Integer
        Dim R010043 As Integer
        Dim R010044 As Integer
        Dim R010045 As Integer
        Dim R010046 As Long
        Dim R010047 As Decimal
        Dim R010048 As Decimal
        Dim R010049 As Decimal
        Dim R010050 As Decimal
        Dim R010051 As Decimal
        Dim R010052 As Decimal
        Dim R010053 As Decimal
        Dim R010054 As Decimal
        Dim R010055 As Decimal
        Dim R010056 As Decimal
        Dim R010057 As Decimal
        Dim R010058 As Decimal
        Dim R010059 As Decimal
        Dim R010060 As Decimal
        Dim R010061 As Decimal
        Dim R010062 As Decimal
        Dim R010999 As Long
        'A-20121217_Ver7.50_1↓
        Dim R010063 As Decimal
        Dim R010064 As Integer
        Dim R010065 As Integer
        Dim R010066 As Decimal
        Dim R010067 As Decimal
        Dim R010068 As Decimal
        Dim R010069 As Decimal
        Dim R010070 As String
        'A-20121217_Ver7.50_1↑
        Dim R010071 As Integer      'A-20160324_1
        Dim R010072 As Integer      'A-20160324_1

        Dim 拡張項目入力情報 As I拡張項目入力情報型
    End Structure

    Public Structure 入出荷明細型
        Dim R011001 As Integer
        Dim R011002 As Integer
        Dim R011003 As Long
        Dim R011004 As Integer
        Dim R011005 As Integer
        Dim R011006 As Integer
        Dim R011007 As Integer
        Dim R011008 As Integer
        Dim R011009 As String
        Dim R011010 As String
        Dim R011011 As Integer
        Dim R011012 As Long
        Dim R011013 As Integer
        Dim R011014 As String
        Dim R011015 As String
        Dim R011016 As String
        Dim R011017 As String
        Dim R011018 As String
        Dim R011019 As Decimal
        Dim R011020 As Decimal
        Dim R011021 As String
        Dim R011022 As Decimal
        Dim R011023 As Decimal
        Dim R011024 As Decimal
        Dim R011025 As Decimal
        Dim R011026 As Integer
        Dim R011027 As Decimal
        Dim R011028 As Decimal
        Dim R011029 As Decimal
        Dim R011030 As Decimal
        Dim R011031 As Decimal
        Dim R011032 As Decimal
        Dim R011033 As Decimal
        Dim R011034 As Integer
        Dim R011035 As Decimal
        Dim R011036 As Decimal
        Dim R011037 As Integer
        Dim R011038 As String
        Dim R011039 As String
        Dim R011040 As String
        Dim R011041 As Decimal
        Dim R011042 As Decimal
        Dim R011043 As Decimal
        Dim R011044 As Decimal
        Dim R011045 As Decimal
        Dim R011046 As Integer
        Dim R011047 As Integer
        Dim R011048 As Integer
        Dim R011049 As Integer
        Dim R011050 As String
        Dim R011051 As Integer
        Dim R011052 As Integer
        Dim R011053 As Integer
        Dim R011054 As Integer
        Dim R011055 As Integer
        Dim R011056 As Integer
        Dim R011057 As Decimal
        Dim R011058 As String
        Dim R011059 As String
        Dim R011060 As String
        Dim R011061 As String
        Dim R011062 As String
        Dim R011063 As String
        Dim R011064 As String
        Dim R011065 As String
        Dim R011066 As String
        Dim R011067 As Integer
        Dim R011068 As Integer
        Dim R011069 As Integer
        Dim R011070 As String
        Dim R011071 As Decimal
        Dim R011072 As String
        Dim R011073 As Decimal
        Dim R011074 As Integer
        Dim R011075 As Long
        Dim R011076 As Long
        Dim R011077 As Integer
        Dim R011078 As Integer
        Dim R011079 As Long
        Dim R011080 As Decimal
        Dim R011081 As String
        Dim R011082 As Integer
        Dim R011083 As String
        Dim R011084 As String
        Dim R011085 As Decimal
        Dim R011086 As Decimal
        Dim R011087 As Integer
        Dim R011088 As Integer
        Dim R011089 As Decimal
        Dim R011090 As Long
        Dim R011091 As Integer
        Dim R011092 As Long
        Dim R011093 As Integer
        Dim R011094 As Decimal
        Dim R011095 As Decimal
        Dim R011096 As Long
        Dim R011097 As Integer
        Dim R011098 As Integer
        Dim R011099 As Integer
        Dim R011999 As Long
        'A-20121217_Ver7.50_1↓
        Dim R011100 As Decimal
        Dim R011101 As Decimal
        Dim R011102 As Decimal
        Dim R011103 As Decimal
        Dim R011104 As Decimal
        Dim R011105 As Decimal
        Dim R011106 As Decimal
        Dim R011107 As Decimal
        Dim R011108 As Decimal
        Dim R011109 As Decimal
        Dim R011110 As Decimal
        Dim R011111 As Decimal
        Dim R011112 As String
        Dim R011113 As Integer
        Dim R011114 As Integer
        Dim R011115 As Integer
        Dim R011116 As String
        Dim R011117 As String
        Dim R011118 As String
        Dim R011119 As String
        Dim R011120 As String
        'A-20121217_Ver7.50_1↑
        Dim R011121 As Long     'A-20160324_2

        Dim 拡張項目入力情報 As I拡張項目入力情報型
    End Structure

#End Region

#Region "ロット明細"

    Public Structure ロット明細型
        ''' <summary>伝票区分</summary>
        Dim R008001 As Integer
        ''' <summary>処理連番</summary>
        Dim R008002 As Long
        ''' <summary>行番号</summary>
        Dim R008003 As Integer
        ''' <summary>ロット明細連番</summary>
        Dim R008004 As Integer
        ''' <summary>入出庫日</summary>
        Dim R008005 As Integer
        ''' <summary>伝票明細区分</summary>
        Dim R008006 As Integer
        ''' <summary>倉庫コード</summary>
        Dim R008007 As String
        ''' <summary>倉庫名</summary>
        Dim R008008 As String
        ''' <summary>ロケーションコード</summary>
        Dim R008009 As String
        ''' <summary>商品コード</summary>
        Dim R008010 As String
        ''' <summary>品目名１</summary>
        Dim R008011 As String
        ''' <summary>品目名２</summary>
        Dim R008012 As String
        ''' <summary>品目名３</summary>
        Dim R008013 As String
        ''' <summary>ロット№</summary>
        Dim R008014 As String
        ''' <summary>入出庫区分</summary>
        Dim R008015 As Integer
        ''' <summary>入庫数量</summary>
        Dim R008016 As Decimal
        ''' <summary>出庫数量</summary>
        Dim R008017 As Decimal
        ''' <summary>単位</summary>
        Dim R008018 As String
        ''' <summary>製番</summary>
        Dim R008019 As String
        ''' <summary>製　番（メイン）</summary>
        Dim R008020 As String
        ''' <summary>製　番（枝番）</summary>
        Dim R008021 As String
        ''' <summary>出庫先（元）コード</summary>
        Dim R008022 As String
        ''' <summary>出庫先名１</summary>
        Dim R008023 As String
        ''' <summary>出庫先名２</summary>
        Dim R008024 As String
        ''' <summary>受注番号</summary>
        Dim R008025 As Long
        ''' <summary>受注行番号</summary>
        Dim R008026 As Integer
        ''' <summary>受注日</summary>
        Dim R008027 As Integer
        ''' <summary>製番品目コード</summary>
        Dim R008028 As String
        ''' <summary>製番品目名１</summary>
        Dim R008029 As String
        ''' <summary>製番品目名２</summary>
        Dim R008030 As String
        ''' <summary>製番品目名３</summary>
        Dim R008031 As String
        ''' <summary>客先注番</summary>
        Dim R008032 As String
        ''' <summary>得意先コード</summary>
        Dim R008033 As String
        ''' <summary>得意先名１</summary>
        Dim R008034 As String
        ''' <summary>得意先名２</summary>
        Dim R008035 As String
        ''' <summary>手配（発注）番号</summary>
        Dim R008036 As Long
        ''' <summary>手配日</summary>
        Dim R008037 As Integer
        ''' <summary>内外区分（手配先）</summary>
        Dim R008038 As Integer
        ''' <summary>手配先コード</summary>
        Dim R008039 As String
        ''' <summary>手配先名１</summary>
        Dim R008040 As String
        ''' <summary>手配先名２</summary>
        Dim R008041 As String
        ''' <summary>手配管理番号</summary>
        Dim R008042 As Long
        'A-20121217_Ver7.50_4↓
        ''' <summary>計上区分</summary>
        Dim R008043 As Integer
        'A-20121217_Ver7.50_4↑
        ''' <summary>更新番号</summary>
        Dim R008999 As Long
    End Structure

#End Region

#Region "受発注"

    Public Structure 受発注ヘッダー型
        Dim R004001 As Integer
        Dim R004002 As String
        Dim R004003 As Integer
        Dim R004004 As Integer
        Dim R004005 As Long
        Dim R004006 As Integer
        Dim R004007 As Integer
        Dim R004008 As String
        Dim R004009 As Integer
        Dim R004010 As String
        Dim R004011 As String
        Dim R004012 As String
        Dim R004013 As String
        Dim R004014 As String
        Dim R004015 As Integer
        Dim R004016 As Long
        Dim R004017 As Long
        Dim R004018 As Integer
        Dim R004019 As Integer
        Dim R004020 As Decimal
        Dim R004021 As Integer
        Dim R004022 As String
        Dim R004023 As String
        Dim R004024 As Decimal
        Dim R004025 As Decimal
        Dim R004026 As Decimal
        Dim R004027 As Decimal
        Dim R004028 As Decimal
        Dim R004029 As Decimal
        Dim R004030 As Decimal
        Dim R004031 As Decimal
        Dim R004032 As Decimal
        Dim R004033 As Decimal
        Dim R004034 As Decimal
        Dim R004035 As String
        Dim R004036 As String
        Dim R004037 As String
        Dim R004038 As Integer
        Dim R004039 As Integer
        Dim R004040 As String
        Dim R004041 As Integer
        Dim R004042 As Integer
        Dim R004043 As Integer
        Dim R004044 As Integer
        Dim R004045 As Integer
        Dim R004046 As Decimal
        Dim R004047 As Decimal
        Dim R004048 As String
        Dim R004999 As Decimal
        '
        Dim R004A001 As Integer
        Dim R004A002 As Integer
        Dim R004A003 As Integer
        Dim R004A004 As String
        Dim R004A005 As String
        Dim R004A006 As Integer
        Dim R004A007 As String
        Dim R004A008 As String
        Dim R004A009 As String
        Dim R004A010 As Integer
        Dim R004A011 As Integer
        Dim R004A012 As Integer
        Dim R004A013 As Integer
        Dim R004A014 As Integer
        Dim R004A015 As Long
        Dim R004A016 As Integer
        Dim R004A017 As Integer
        Dim R004A018 As Integer
        Dim R004A019 As Integer
        Dim R004A020 As Integer
        Dim R004A021 As Integer
        Dim R004S001 As String
        Dim R004S002 As String
    End Structure

    Public Structure 受発注明細型
        Dim R005001 As Integer
        Dim R005002 As Integer
        Dim R005003 As Long
        Dim R005004 As Integer
        Dim R005005 As Integer
        Dim R005006 As String
        Dim R005007 As String
        Dim R005008 As Integer
        Dim R005009 As Integer
        Dim R005010 As Integer
        Dim R005011 As Long
        Dim R005012 As Integer
        Dim R005013 As Long
        Dim R005014 As Long
        Dim R005015 As String
        Dim R005016 As String
        Dim R005017 As String
        Dim R005018 As String
        Dim R005019 As String
        Dim R005020 As Decimal
        Dim R005021 As Decimal
        Dim R005022 As String
        Dim R005023 As Decimal
        Dim R005024 As Decimal
        Dim R005025 As Decimal
        Dim R005026 As Decimal
        Dim R005027 As Decimal
        Dim R005028 As Decimal
        Dim R005029 As Decimal
        Dim R005030 As Decimal
        Dim R005031 As Decimal
        Dim R005032 As Decimal
        Dim R005033 As Decimal
        Dim R005034 As Decimal
        Dim R005035 As Decimal
        Dim R005036 As Decimal
        Dim R005037 As Decimal
        Dim R005038 As Integer
        Dim R005039 As String
        Dim R005040 As String
        Dim R005041 As String
        Dim R005042 As Decimal
        Dim R005043 As Decimal
        Dim R005044 As Decimal
        Dim R005045 As Decimal
        Dim R005046 As Decimal
        Dim R005047 As Decimal
        Dim R005048 As Integer
        Dim R005049 As Integer
        Dim R005050 As Integer
        Dim R005051 As String
        Dim R005052 As Integer
        Dim R005053 As Integer
        Dim R005054 As Long
        Dim R005055 As Integer
        Dim R005056 As Integer
        Dim R005057 As Integer
        Dim R005058 As String
        Dim R005059 As String
        Dim R005060 As String
        Dim R005061 As Decimal
        Dim R005062 As Decimal
        Dim R005063 As Integer
        Dim R005064 As Decimal
        Dim R005065 As Decimal
        Dim R005066 As Decimal
        Dim R005067 As Decimal
        Dim R005068 As Decimal
        Dim R005069 As Decimal
        Dim R005070 As Integer
        Dim R005071 As Integer
        Dim R005072 As Integer
        Dim R005073 As Integer
        Dim R005074 As Integer
        Dim R005075 As Decimal
        Dim R005076 As String
        Dim R005077 As String
        Dim R005078 As Decimal
        Dim R005079 As Decimal
        Dim R005080 As Decimal
        Dim R005081 As Decimal
        Dim R005082 As Decimal
        Dim R005083 As Decimal
        Dim R005084 As Decimal
        Dim R005085 As Decimal
        Dim R005999 As Decimal
        '
        Dim R005A001 As String
        Dim R005A002 As String
        Dim R005A003 As String
        Dim R005A004 As String
        Dim R005A005 As String
        Dim R005A006 As String
        Dim R005A007 As Integer
        Dim R005A008 As Integer
        Dim R005A009 As Integer
        Dim R005A010 As Long
        Dim R005A011 As String
        Dim R005A012 As Integer
        Dim R005A013 As Integer
        Dim R005A014 As Decimal
        Dim R005A015 As Integer
        Dim R005A016 As Integer
        Dim R005A017 As String
        Dim R005A018 As Integer
        Dim R005A019 As Integer
        Dim R005A020 As Integer
        Dim R005A021 As Integer
        Dim R005A022 As String
        Dim R005A023 As Decimal
        Dim R005A024 As String
        Dim R005A025 As Decimal
        Dim R005A026 As Integer
        Dim R005A027 As Long
        Dim R005A028 As Long
        Dim R005A029 As Integer
        Dim R005A030 As Integer
        Dim R005A031 As Integer
        Dim R005A032 As Integer
        Dim R005A033 As Long
        Dim R005A034 As Decimal
        Dim R005A035 As Decimal
        Dim R005A036 As String
        Dim R005A037 As Integer
        Dim R005A038 As String
    End Structure

#End Region

#Region "品目別ロット"

    Public Structure 品目別ロット型
        Dim R009001 As String      '品目コード
        Dim R009002 As String      'ロット№
        Dim R009003 As Integer     '有効期限
    End Structure

#End Region

#Region "手配テーブル"

    Public Structure 手配テーブル型
        ''' <summary>手配伝票区分</summary>
        Dim R055001 As Integer
        ''' <summary>手配番号</summary>
        Dim R055002 As Long
        ''' <summary>手配日付</summary>
        Dim R055003 As Integer
        ''' <summary>操作日付</summary>
        Dim R055004 As Integer
        ''' <summary>ログインID</summary>
        Dim R055005 As String
        ''' <summary>チェックマーク区分</summary>
        Dim R055006 As Integer
        ''' <summary>担当者コード</summary>
        Dim R055007 As String
        ''' <summary>部門コード</summary>
        Dim R055008 As String
        ''' <summary>倉庫コード</summary>
        Dim R055009 As String
        ''' <summary>製番</summary>
        Dim R055010 As String
        ''' <summary>製番（メイン）</summary>
        Dim R055011 As String
        ''' <summary>製番（枝番）</summary>
        Dim R055012 As String
        ''' <summary>品目コード</summary>
        Dim R055013 As String
        ''' <summary>品目名</summary>
        Dim R055014 As String
        ''' <summary>品目名１</summary>
        Dim R055015 As String
        ''' <summary>品目名２</summary>
        Dim R055016 As String
        ''' <summary>品目名３</summary>
        Dim R055017 As String
        ''' <summary>手順№</summary>
        Dim R055018 As Integer
        ''' <summary>工程コード</summary>
        Dim R055019 As String
        ''' <summary>データ生成区分</summary>
        Dim R055020 As Integer
        ''' <summary>手配先コード</summary>
        Dim R055021 As String
        ''' <summary>手入力仕入先名１</summary>
        Dim R055022 As String
        ''' <summary>手入力仕入先名２</summary>
        Dim R055023 As String
        ''' <summary>手配数量</summary>
        Dim R055024 As Decimal
        ''' <summary>数量単位</summary>
        Dim R055025 As String
        ''' <summary>手配単価</summary>
        Dim R055026 As Decimal
        ''' <summary>手配金額</summary>
        Dim R055027 As Decimal
        ''' <summary>単価計算方法</summary>
        Dim R055028 As Integer
        ''' <summary>単価掛率</summary>
        Dim R055029 As Decimal
        ''' <summary>標準売上単価</summary>
        Dim R055030 As Decimal
        ''' <summary>標準仕入単価</summary>
        Dim R055031 As Decimal
        ''' <summary>上代単価</summary>
        Dim R055032 As Decimal
        ''' <summary>課税区分</summary>
        Dim R055033 As Integer
        ''' <summary>消費税率</summary>
        Dim R055034 As Decimal
        ''' <summary>内消費税額</summary>
        Dim R055035 As Decimal
        ''' <summary>手配リードタイム</summary>
        Dim R055036 As Decimal
        ''' <summary>手配予定日</summary>
        Dim R055037 As Integer
        ''' <summary>手配納期</summary>
        Dim R055038 As Integer
        ''' <summary>検査方法</summary>
        Dim R055039 As Integer
        ''' <summary>行摘要コード</summary>
        Dim R055040 As String
        ''' <summary>行摘要１</summary>
        Dim R055041 As String
        ''' <summary>行摘要２</summary>
        Dim R055042 As String
        ''' <summary>備考コード１</summary>
        Dim R055043 As String
        ''' <summary>備考名１</summary>
        Dim R055044 As String
        ''' <summary>報告済数量</summary>
        Dim R055045 As Decimal
        ''' <summary>報告回数</summary>
        Dim R055046 As Integer
        ''' <summary>最終報告日</summary>
        Dim R055047 As Integer
        ''' <summary>関連報告伝票枚数</summary>
        Dim R055048 As Integer
        ''' <summary>手配残区分</summary>
        Dim R055049 As Integer
        ''' <summary>手配強制完納区分</summary>
        Dim R055050 As Integer
        ''' <summary>通貨コード</summary>
        Dim R055051 As String
        ''' <summary>管理コード</summary>
        Dim R055052 As String
        ''' <summary>要素コード</summary>
        Dim R055053 As String
        ''' <summary>仕入済数量</summary>
        Dim R055054 As Decimal
        ''' <summary>仕入済金額</summary>
        Dim R055055 As Decimal
        ''' <summary>仕入済内消費税額</summary>
        Dim R055056 As Decimal
        ''' <summary>仕入済金額内訳　売上</summary>
        Dim R055057 As Decimal
        ''' <summary>仕入済金額内訳　値引</summary>
        Dim R055058 As Decimal
        ''' <summary>仕入回数</summary>
        Dim R055059 As Integer
        ''' <summary>最終仕入日</summary>
        Dim R055060 As Integer
        ''' <summary>関連仕入伝票行数</summary>
        Dim R055061 As Integer
        ''' <summary>発注残区分</summary>
        Dim R055062 As Integer
        ''' <summary>発注強制完納区分</summary>
        Dim R055063 As Integer
        ''' <summary>手配書発行済区分</summary>
        Dim R055064 As Integer
        ''' <summary>子部品登録区分</summary>
        Dim R055065 As Integer
        ''' <summary>子部品出庫予定日</summary>
        Dim R055066 As Integer
        ''' <summary>最終工程区分</summary>
        Dim R055067 As Integer
        ''' <summary>手配管理番号</summary>
        Dim R055068 As Long
        ''' <summary>支給出庫残区分</summary>
        Dim R055069 As Integer
        ''' <summary>データ発生区分</summary>
        Dim R055070 As Integer
        ''' <summary>受注形態</summary>
        Dim R055071 As Integer
        ''' <summary>手配確定区分</summary>
        Dim R055072 As Integer
        ''' <summary>直送区分</summary>
        Dim R055073 As Integer
        ''' <summary>発注番号</summary>
        Dim R055074 As Long
        ''' <summary>差数発行済区分</summary>
        Dim R055075 As Integer
        ''' <summary>指図書発行済区分</summary>
        Dim R055076 As Integer
        ''' <summary>予定作業時間</summary>
        Dim R055077 As Integer
        ''' <summary>予定段取時間</summary>
        Dim R055078 As Integer
        ''' <summary>個別発注連番</summary>
        Dim R055079 As Long
        ''' <summary>費目コード</summary>
        Dim R055080 As String
        ''' <summary>仮単価区分</summary>
        Dim R055081 As Integer
        ''' <summary>不良数量</summary>
        Dim R055082 As Decimal
        ''' <summary>当初納期日</summary>
        Dim R055083 As Integer
        ''' <summary>費目区分</summary>
        Dim R055084 As Integer
        ''' <summary>手配数量（在庫単位）</summary>
        Dim R055085 As Decimal
        ''' <summary>不良数量（在庫単位）</summary>
        Dim R055086 As Decimal
        ''' <summary>発注単位変換係数</summary>
        Dim R055087 As Decimal
        ''' <summary>品目連番</summary>
        Dim R055088 As String
        ''' <summary>数量単位（在庫単位）</summary>
        Dim R055089 As String
        ''' <summary>報告済数量（在庫単位）</summary>
        Dim R055090 As Decimal
        ''' <summary>計上区分</summary>
        Dim R055091 As Integer
        ''' <summary>更新番号</summary>
        Dim R055999 As Long
        ''' <summary>備考コード２</summary>
        Dim R055092 As String
        ''' <summary>備考２</summary>
        Dim R055093 As String
    End Structure

#End Region

#Region "従属需要"

    Public Structure 従属需要型
        ''' <summary>手配伝票区分</summary>
        Dim R056001 As Integer
        ''' <summary>手配番号</summary>
        Dim R056002 As Long
        ''' <summary>展開順序番号</summary>
        Dim R056003 As Integer
        ''' <summary>部番</summary>
        Dim R056004 As Integer
        ''' <summary>操作日付</summary>
        Dim R056005 As Integer
        ''' <summary>ログインID</summary>
        Dim R056006 As String
        ''' <summary>品目コード</summary>
        Dim R056007 As String
        ''' <summary>品目名</summary>
        Dim R056008 As String
        ''' <summary>品目名１</summary>
        Dim R056009 As String
        ''' <summary>品目名２</summary>
        Dim R056010 As String
        ''' <summary>品目名３</summary>
        Dim R056011 As String
        ''' <summary>子部品出庫予定日</summary>
        Dim R056012 As Integer
        ''' <summary>倉庫コード</summary>
        Dim R056013 As String
        ''' <summary>ロケーション</summary>
        Dim R056014 As String
        ''' <summary>製番</summary>
        Dim R056015 As String
        ''' <summary>製番（メイン）</summary>
        Dim R056016 As String
        ''' <summary>製番（枝番）</summary>
        Dim R056017 As String
        ''' <summary>品目コード（親品目）</summary>
        Dim R056018 As String
        ''' <summary>手順№</summary>
        Dim R056019 As Integer
        ''' <summary>工程コード</summary>
        Dim R056020 As String
        ''' <summary>手配先コード</summary>
        Dim R056021 As String
        ''' <summary>支給/出庫予定数量</summary>
        Dim R056022 As Decimal
        ''' <summary>数量単位</summary>
        Dim R056023 As String
        ''' <summary>予定単価計算区分</summary>
        Dim R056024 As Decimal
        ''' <summary>支給予定単価</summary>
        Dim R056025 As Decimal
        ''' <summary>支給予定金額</summary>
        Dim R056026 As Decimal
        ''' <summary>引落数量</summary>
        Dim R056027 As Decimal
        ''' <summary>支給（出庫）済数量</summary>
        Dim R056028 As Decimal
        ''' <summary>有償支給数量</summary>
        Dim R056029 As Decimal
        ''' <summary>無償支給数量</summary>
        Dim R056030 As Decimal
        ''' <summary>支給済金額</summary>
        Dim R056031 As Decimal
        ''' <summary>出庫累計回数</summary>
        Dim R056032 As Integer
        ''' <summary>出庫残区分</summary>
        Dim R056033 As Integer
        ''' <summary>原単位区分</summary>
        Dim R056034 As Integer
        ''' <summary>取数（分子）</summary>
        Dim R056035 As Decimal
        ''' <summary>取数（分母）</summary>
        Dim R056036 As Decimal
        ''' <summary>支給区分</summary>
        Dim R056037 As Integer
        ''' <summary>不良率</summary>
        Dim R056038 As Decimal
        ''' <summary>使用工程コード</summary>
        Dim R056039 As String
        ''' <summary>単価計算方法</summary>
        Dim R056040 As Integer
        ''' <summary>単価掛率</summary>
        Dim R056041 As Decimal
        ''' <summary>標準売上単価</summary>
        Dim R056042 As Decimal
        ''' <summary>標準仕入単価</summary>
        Dim R056043 As Decimal
        ''' <summary>標準支給単価</summary>
        Dim R056044 As Decimal
        ''' <summary>強制完納区分（出庫）</summary>
        Dim R056045 As Integer
        ''' <summary>オーダー製番</summary>
        Dim R056046 As String
        ''' <summary>課税区分</summary>
        Dim R056047 As Integer
        ''' <summary>費目コード</summary>
        Dim R056048 As String
        ''' <summary>費目区分</summary>
        Dim R056049 As Integer
        ''' <summary>発注番号</summary>
        Dim R056050 As Long
        ''' <summary>品目連番</summary>
        Dim R056051 As String
        ''' <summary>手配管理番号</summary>
        Dim R056052 As Long
        ''' <summary>支給累計回数</summary>
        Dim R056053 As Integer
        ''' <summary>支給残区分</summary>
        Dim R056054 As Integer
        ''' <summary>強制完納区分（支給）</summary>
        Dim R056055 As Integer
        ''' <summary>更新番号</summary>
        Dim R055999 As Long
    End Structure

#End Region

#Region "工程明細"

    Public Structure 工程明細型
        ''' <summary>伝票日付</summary>
        Dim R057001 As Integer
        ''' <summary>伝票区分</summary>
        Dim R057002 As Integer
        ''' <summary>伝票番号</summary>
        Dim R057003 As Integer
        ''' <summary>報告連番</summary>
        Dim R057004 As Long
        ''' <summary>操作日付</summary>
        Dim R057005 As Integer
        ''' <summary>ログインID</summary>
        Dim R057006 As String
        ''' <summary>チェックマーク区分</summary>
        Dim R057007 As Integer
        ''' <summary>担当者コード</summary>
        Dim R057008 As String
        ''' <summary>取引区分</summary>
        Dim R057009 As Integer
        ''' <summary>部門コード</summary>
        Dim R057010 As String
        ''' <summary>倉庫コード</summary>
        Dim R057011 As String
        ''' <summary>手配番号</summary>
        Dim R057012 As Long
        ''' <summary>製番</summary>
        Dim R057013 As String
        ''' <summary>製番（メイン）</summary>
        Dim R057014 As String
        ''' <summary>製番（枝番）</summary>
        Dim R057015 As String
        ''' <summary>品目コード</summary>
        Dim R057016 As String
        ''' <summary>品目名</summary>
        Dim R057017 As String
        ''' <summary>品目名１</summary>
        Dim R057018 As String
        ''' <summary>品目名２</summary>
        Dim R057019 As String
        ''' <summary>品目名３</summary>
        Dim R057020 As String
        ''' <summary>手順№</summary>
        Dim R057021 As Integer
        ''' <summary>工程コード</summary>
        Dim R057022 As String
        ''' <summary>内外区分</summary>
        Dim R057023 As Integer
        ''' <summary>手配先コード</summary>
        Dim R057024 As String
        ''' <summary>手入力仕入先名１</summary>
        Dim R057025 As String
        ''' <summary>手入力仕入先名２</summary>
        Dim R057026 As String
        ''' <summary>報告数量</summary>
        Dim R057027 As Decimal
        ''' <summary>内不良数量</summary>
        Dim R057028 As Decimal
        ''' <summary>数量単位</summary>
        Dim R057029 As String
        ''' <summary>手配単価</summary>
        Dim R057030 As Decimal
        ''' <summary>手配金額</summary>
        Dim R057031 As Decimal
        ''' <summary>単価計算方法</summary>
        Dim R057032 As Integer
        ''' <summary>課税区分</summary>
        Dim R057033 As Integer
        ''' <summary>消費税率</summary>
        Dim R057034 As Decimal
        ''' <summary>単価掛率</summary>
        Dim R057035 As Decimal
        ''' <summary>標準売上単価</summary>
        Dim R057036 As Decimal
        ''' <summary>標準仕入単価</summary>
        Dim R057037 As Decimal
        ''' <summary>行摘要コード</summary>
        Dim R057038 As String
        ''' <summary>行摘要１</summary>
        Dim R057039 As String
        ''' <summary>行摘要２</summary>
        Dim R057040 As String
        ''' <summary>備考コード</summary>
        Dim R057041 As String
        ''' <summary>備考</summary>
        Dim R057042 As String
        ''' <summary>通貨コード</summary>
        Dim R057043 As String
        ''' <summary>管理コード</summary>
        Dim R057044 As String
        ''' <summary>要素コード</summary>
        Dim R057045 As String
        ''' <summary>データ発生区分</summary>
        Dim R057046 As Integer
        ''' <summary>相手処理連番</summary>
        Dim R057047 As Long
        ''' <summary>相手処理連番</summary>
        Dim R057048 As Long
        ''' <summary>子部品登録区分</summary>
        Dim R057049 As Integer
        ''' <summary>手配管理番号</summary>
        Dim R057050 As Long
        ''' <summary>ロケーション</summary>
        Dim R057051 As String
        ''' <summary>ロット№</summary>
        Dim R057052 As String
        ''' <summary>有効期限</summary>
        Dim R057053 As Integer
        ''' <summary>人数</summary>
        Dim R057054 As Integer
        ''' <summary>作業時間</summary>
        Dim R057055 As Decimal
        ''' <summary>費目コード</summary>
        Dim R057056 As String
        ''' <summary>仮単価区分</summary>
        Dim R057057 As Integer
        ''' <summary>報告数量（在庫単位）</summary>
        Dim R057058 As Decimal
        ''' <summary>内不良数量（在庫単位）</summary>
        Dim R057059 As Decimal
        ''' <summary>発注単位変換係数</summary>
        Dim R057060 As Decimal
        ''' <summary>構成品出庫生成区分</summary>
        Dim R057061 As Integer
        ''' <summary>数量単位（在庫単位）</summary>
        Dim R057062 As String
        ''' <summary>更新番号</summary>
        Dim R057999 As Long
        ''' <summary>出庫用費目コード</summary>
        Dim R057063 As String
    End Structure

#End Region

#Region "受入索引"

    Public Structure 受入索引テーブル型
        Dim R114001 As Integer
        Dim R114002 As Integer
        Dim R114003 As Long
        Dim R114004 As Integer
        Dim R114999 As Long
    End Structure

#End Region

#Region "ストアド項目"

    Public Structure ストアドパラメータ_原価
        Dim 更新判断 As Boolean

        Dim 出庫日 As Integer
        Dim 発生区分 As Integer
        Dim 入出庫区分 As Integer
        Dim 処理連番 As Long
        Dim 対象年月度 As Integer
    End Structure

    Public Structure ストアドパラメータ_仕入
        Dim 処理連番 As Long
        Dim 年月 As Integer
        Dim 端数処理区分_金額 As String
        Dim 端数処理区分_消費税分解 As String
        Dim 計上区分 As Integer
        'A-20121217_Ver7.50_1↓
        Dim 通貨区分 As Integer
        Dim 端数処理区分_金額_外貨 As Integer
        Dim 小数以下桁数_金額_外貨 As Integer
        Dim 通貨単位 As Integer
        'A-20121217_Ver7.50_1↑
    End Structure

    Public Structure ストアドパラメータ_出庫
        Dim 更新判断 As Boolean

        Dim 処理連番 As Long
        Dim 対象年月度 As Integer
        Dim 入出庫区分 As Integer

    End Structure

    Public Structure ストアドパラメータ_入庫
        Dim 更新判断 As Boolean

        Dim 処理連番 As Long
        Dim 対象年月度 As Integer
    End Structure

    Public Structure ストアドパラメータ_ロット明細
        Dim 更新判断 As Boolean

        Dim 処理連番 As Long
        Dim 対象年月度 As Integer
        Dim 伝票区分 As Integer
        Dim 当期期首年月 As Integer     'A-20121217_Ver7.50
    End Structure

    'A-CUST20190830↓
    Public Structure ストアドパラメータ_入出庫
        Dim 処理連番 As Long
        Dim 年月 As Integer
    End Structure
    'A-CUST20190830↑
#End Region

#Region "製造実績部品関連"

    Public Structure 製造実績部品関連型
        ''' <summary>処理連番</summary>
        Dim 処理連番 As Long
        ''' <summary>手配番号</summary>
        Dim 手配番号 As Long
        ''' <summary>使用可能処理連番</summary>
        Dim 使用可能処理連番 As Long
        ''' <summary>構成品出庫区分</summary>
        Dim 構成品出庫区分 As Integer
        'A-20121217_Ver7.50_3↓
        ''' <summary>製造出庫連番</summary>
        Dim 製造出庫連番 As Long
        'A-20121217_Ver7.50_3↑
    End Structure

#End Region

    Public Structure 受注明細型
        Dim R005003 As Long         '発注番号               'A-2008/07/18_Ver7.30_GENKA
        Dim R005004 As Integer      '発注行番号             'A-2008/07/18_Ver7.30_GENKA
        Dim R005008 As Integer      '納期
        Dim R005017 As String       '商品コード
        Dim R005019 As String       '数量単位
        Dim R005038 As Integer      '完納区分
        Dim R005050 As Integer      '発注残区分             'A-20120315_3
        Dim R005052 As Integer      '取引区分属性
        Dim R005058 As String       '内訳コード１           'A-2009/12/18_Ver7.40_UCHIWAKE
        Dim R005059 As String       '内訳コード２           'A-2009/12/18_Ver7.40_UCHIWAKE
        Dim R005060 As String       '内訳コード３           'A-2009/12/18_Ver7.40_UCHIWAKE
        Dim R005073 As Integer      '計上区分
        Dim R005086 As String       '原価集計コード         'A-2008/07/18_Ver7.30_GENKA
        Dim R005087 As String       '原価集計サブコード     'A-2008/07/18_Ver7.30_GENKA
        Dim R005003JCH As Long      '受注番号               'A-2008/07/18_Ver7.30_GENKA
        Dim R005006JCH As String    '受注得意先コード       'A-2008/07/18_Ver7.30_GENKA
        Dim R005A004 As String      '製番
        Dim R005A019 As Integer     '検査方法
        Dim R005A020 As Integer     '発注区分
        Dim R005A021 As Integer     '子部品引当区分
        Dim R005A022 As String      '工程コード
        Dim R005A023 As Decimal     '発注数量(発注単位)     'A-20120315_3
        Dim R005A025 As Decimal     '発注単位変換係数
        Dim R005A026 As Integer     '発注確定区分
        Dim R005A027 As Long        '手配番号
        Dim R005A028 As Long        '手配管理番号
        Dim R005A031 As Integer     '受注形態               'A-20130304_3
        Dim R005A033 As Long        '個別発注連番
        Dim R005A034 As Decimal     '受入数量
        Dim R005A037 As Integer     '費目区分
        Dim R005S027 As Long        '原価計上手配番号       'A-20160324_2

        Dim R004002 As String       '取引先コード
        Dim R004003 As Integer      '受発注日付
        Dim R004013 As String       '倉庫コード             'A-20141105_2
        Dim R004035 As String       '手入力得意先名１
        Dim R004036 As String       '手入力得意先名２
        Dim R004A004 As String      'プロジェクトメインコード
        Dim R004A005 As String      'プロジェクトサブコード
        Dim R004A010 As Integer     '発注区分
        Dim R004A012 As Integer     '完成品区分

        Dim M002004 As String       '仕入先名１
        Dim M002005 As String       '仕入先名２

        '関連受注項目
        Dim JCH_R004002 As String   '取引先コード
        Dim JCH_R004003 As Integer  '受発注日付
        Dim JCH_R004035 As String   '手入力得意先名１
        Dim JCH_R004036 As String   '手入力得意先名２

        Dim JCH_R005003 As Long     '発注番号
        Dim JCH_R005004 As Integer  '発注行番号
        Dim JCH_R005017 As String   '商品コード
        Dim JCH_R005A001 As String  '品目名１
        Dim JCH_R005A002 As String  '品目名２
        Dim JCH_R005A003 As String  '品目名３
        Dim JCH_R005A011 As String  '客先注番
    End Structure

    Public Structure 支払予定テーブル型     'A-2008/07/18_Ver7.30_SHIHARAI
        Dim R031001 As Integer      '回収支払管理区分
        Dim R031002 As Integer      '支払処理連番
        Dim R031003 As Long         '伝票処理連番
        Dim R031004 As Integer      '伝票番号
        Dim R031005 As Integer      '明細区分
        Dim R031006 As Integer      '行番号
        Dim R031007 As String       '支払先コード
        Dim R031008 As Integer      '支払予定日
        Dim R031009 As Integer      '支払日付
        Dim R031010 As Integer      '仕入日付
        Dim R031011 As Integer      'データ区分
        Dim R031012 As Decimal      '支払(仕入)金額
        Dim R031013 As Decimal      '過支払額
        Dim R031014 As Decimal      '支払額
        Dim R031015 As String       '仕入担当者コード
        Dim R031016 As Integer      '支払予定区分
        Dim R031017 As Integer      '支払済区分
        Dim R031018 As Integer      '消費税区分
        Dim R031019 As String       '営業所コード
        Dim R031020 As String       '支払グループコード
        Dim R031021 As Integer      '支払書番号
        Dim R031022 As String       '原価集計コード
        Dim R031023 As String       '原価集計サブコード
        Dim R031024 As Decimal      '外貨額 支払(仕入)金額  'A-20160324_1
        Dim R031025 As Decimal      '外貨額 過支払額        'A-20160324_1
        Dim R031026 As Decimal      '外貨額 支払額          'A-20160324_1
        Dim R031027 As Integer      '外貨 レート種類        'A-20160324_1
        Dim R031028 As Decimal      '外貨 レート            'A-20160324_1
        Dim R031029 As Integer      '外貨 レート固定区分    'A-20160324_1
        Dim R031999 As Long         '更新番号
        'A-20121217_Ver7.50_1↓
        Dim R031S001 As String      '通貨コード
        Dim R031S002 As Decimal     '支払(仕入)金額(外貨)
        Dim R031S003 As Decimal     '支払額(外貨)
        Dim R031S004 As Decimal     'レート
        'A-20121217_Ver7.50_1↑
    End Structure

    Public Structure 仕入先月別実績テーブル型
        Dim S002004 As Decimal      '税抜仕入 仕入
        Dim S002005 As Decimal      '         返品
        Dim S002006 As Decimal      '         値引
        Dim S002007 As Decimal      '消費税   仕入
        Dim S002008 As Decimal      '         返品
        Dim S002009 As Decimal      '         値引
        Dim S002010 As Decimal      '支払     現金
    End Structure

    Public Structure 内訳更新情報型     'A-2009/12/18_Ver7.40_UCHIWAKE
        Dim 当期期首年月度 As Integer
        Dim 単位換算数量 As Decimal
        Dim 商品Ｍ_内訳管理区分１ As Integer
        Dim 商品Ｍ_内訳管理区分２ As Integer
        Dim 商品Ｍ_内訳管理区分３ As Integer
        Dim 商品Ｍ_ロット管理区分 As Integer
        Sub 初期化()
            当期期首年月度 = 0
            単位換算数量 = 0
            商品Ｍ_内訳管理区分１ = 0
            商品Ｍ_内訳管理区分２ = 0
            商品Ｍ_内訳管理区分３ = 0
            商品Ｍ_ロット管理区分 = 0
        End Sub
    End Structure

    Public Structure ロット更新情報型     'A-2009/12/18_Ver7.40_LOT
        '--判定情報
        Dim 新規ロット As Boolean
        Dim 強制諸口ロット As Boolean
        '--更新情報(部品に渡すパラメータ)
        Dim 当期期首年月度 As Integer
        Dim 商品Ｍ_内訳管理区分１ As Integer
        Dim 商品Ｍ_内訳管理区分２ As Integer
        Dim 商品Ｍ_内訳管理区分３ As Integer
        Dim サブロットNo As String
        Dim 有効期限 As Integer
        Dim 単価 As Decimal
        Sub 初期化()
            新規ロット = False
            強制諸口ロット = False
            '
            当期期首年月度 = 0
            商品Ｍ_内訳管理区分１ = 0
            商品Ｍ_内訳管理区分２ = 0
            商品Ｍ_内訳管理区分３ = 0
            サブロットNo = ""
            有効期限 = 0
            単価 = 0
        End Sub
    End Structure
#End Region

#Region "メソッド"

    ''' <summary>
    ''' エラー・警告メッセージ取得(ヘッダー)
    ''' </summary>
    ''' <param name="エラー＿警告番号"></param>    'X1変換Tool-20170508
    ''' <returns></returns>
    ''' <remarks>エラー・警告番号に該当するメッセージを返します</remarks>
    Public Shared Function GetErrorWorningStringヘッダー(ByVal エラー＿警告番号 As Integer,
                                                         ByRef my項目名称 As My項目名称Param型
                           ) As String    'X1変換Tool-20170508
        Dim result As String = ""

        result = CType(エラー＿警告番号, エラー＿警告一覧_ヘッダー).ToString    'X1変換Tool-20170508

        'Enum定義できないエラーの文字は、ここで編集する()
        result = result.Replace("_警告", "(警告)")
        result = result.Replace("_Ｎｏ", "№")
        result = result.Replace("_ＳＰ", Space(1))
        result = result.Replace("_外貨", "(外貨)")                'A-20121217_Ver7.50_1
        result = result.Replace("_換算後", "(換算後)")            'A-20121217_Ver7.50_1
        result = result.Replace("_未検収", "(未検収分除く)")      'A-20121217_Ver7.50_4
        result = result.Replace("＿中黒", "・")                   'A-20170601-X1-項目名不正

        result = TextFileImportLib.MyReplace(result, "営業所", my項目名称.販売営業所)
        result = TextFileImportLib.MyReplace(result, "仕入先", my項目名称.販売仕入先)
        result = TextFileImportLib.MyReplace(result, "担当者", my項目名称.販売仕入担当者_項目)
        result = TextFileImportLib.MyReplace(result, "部門", my項目名称.販売部門)
        result = TextFileImportLib.MyReplace(result, "倉庫", my項目名称.販売倉庫)
        result = TextFileImportLib.MyReplace(result, "商品", my項目名称.販売商品)

        '↓A-2009/12/18_Ver7.40_LOT
        Select Case エラー＿警告番号    'X1変換Tool-20170508
            Case エラー＿警告一覧_ヘッダー.完了ロットが存在    'X1変換Tool-20170508
                result = TextFileImportLib.MyReplace(result, "ロット", my項目名称.販売ロット)

                '↓A-2009/12/18_Ver7.40_PRO
            Case エラー＿警告一覧_ヘッダー.完成原価振替済み    'X1変換Tool-20170508
                result = TextFileImportLib.MyReplace(result, "完成", my項目名称.会計完成)
                '↑A-2009/12/18_Ver7.40_PRO

        End Select
        '↑A-2009/12/18_Ver7.40_LOT

        Return result

    End Function

    '''' <summary>
    '''' エラー・警告メッセージ取得(明細) ※コントロール情報あり
    '''' </summary>
    '''' <param name="エラー＿警告番号"></param>    'X1変換Tool-20170508
    '''' <returns></returns>
    '''' <remarks>エラー・警告番号に該当するメッセージを返します</remarks>
    'Public Shared Function GetErrorWorningString明細(ByVal dataIndex As Integer, _
    '                                                 ByVal エラー・警告番号 As Integer, _
    '                                                 ByRef my項目名称 As My項目名称Param型, _
    '                                                 ByRef myコントロール情報 As Myコントロール情報Param _
    '                       ) As String  'A-2009/12/18_Ver7.40_UCHIWAKE
    '    Dim result As String = ""

    '    '■従前のメソッドを実行(※コントロール情報を使用しない分)
    '    result = GetErrorWorningString明細(dataIndex, エラー・警告番号, my項目名称)

    '    '■コントロール情報が必要なメッセージ変換は以下で設定
    '    'Select Case エラー・警告番号
    '    '    Case エラー・警告一覧_明細.内訳ｺｰﾄﾞ１不正 To _
    '    '         エラー・警告一覧_明細.内訳ｺｰﾄﾞ３ﾏｽﾀｰなし
    '    '        If myコントロール情報.My商品内訳管理.内訳タイプ = 商品管理拡張定義型.内訳タイプ型.数値 Then
    '    '            '内訳タイプ：数値 の時は、「コード」をカットする
    '    '            result = result.Replace("内訳ｺｰﾄﾞ", "内訳")
    '    '        End If

    '    'End Select

    '    Return result
    'End Function

    ''' <summary>
    ''' エラー・警告メッセージ取得(明細) ※コントロール情報あり
    ''' </summary>
    ''' <param name="エラー＿警告番号"></param>    'X1変換Tool-20170508
    ''' <returns></returns>
    ''' <remarks>エラー・警告番号に該当するメッセージを返します</remarks>
    Public Shared Function GetErrorWorningString明細(ByVal dataIndex As Integer,
                                                     ByVal エラー＿警告番号 As Integer,
                                                     ByRef my項目名称 As My項目名称Param型,
                                                     ByRef myコントロール情報 As Myコントロール情報Param,
                                                     ByRef my拡張定義 As [LIB].ExpandItemControl.I拡張項目定義型,
                                                     ByRef エラー内容項目変更(,) As String
                           ) As String  'A-CUST20190830
        'D-CUST20190830↓
        'Public Shared Function GetErrorWorningString明細(ByVal dataIndex As Integer,
        '                                                 ByVal エラー＿警告番号 As Integer,
        '                                                 ByRef my項目名称 As My項目名称Param型,
        '                                                 ByRef myコントロール情報 As Myコントロール情報Param,
        '                                                 ByRef エラー内容項目変更(,) As String
        '                       ) As String    'X1変換Tool-20170508
        'D-CUST20190830↑
        Dim result As String = ""

        '■従前のメソッドを実行(※コントロール情報を使用しない分)
        'result = GetErrorWorningString明細(dataIndex, エラー＿警告番号, my項目名称)    'X1変換Tool-20170508    'D-CUST20190830
        result = GetErrorWorningString明細(dataIndex, エラー＿警告番号, my項目名称, my拡張定義)                 'A-CUST20190830

        '一部エラー項目について、エラー内容の書換えを行う
        If Not エラー内容項目変更(0, エラー＿警告番号) Is Nothing AndAlso エラー内容項目変更(0, エラー＿警告番号).TrimEnd <> "" Then    'X1変換Tool-20170508
            result = エラー内容項目変更(0, エラー＿警告番号).TrimEnd    'X1変換Tool-20170508
        End If

        Return result
    End Function

    ''' <summary>
    ''' エラー・警告メッセージ取得(明細)
    ''' </summary>
    ''' <param name="エラー＿警告番号"></param>    'X1変換Tool-20170508
    ''' <returns></returns>
    ''' <remarks>エラー・警告番号に該当するメッセージを返します</remarks>
    Public Shared Function GetErrorWorningString明細(ByVal dataIndex As Integer,
                                                     ByVal エラー＿警告番号 As Integer,
                                                     ByRef my項目名称 As My項目名称Param型,
                                                     ByRef my拡張定義 As [LIB].ExpandItemControl.I拡張項目定義型
                           ) As String  'A-CUST20190830
        'D-CUST20190830↓
        'Public Shared Function GetErrorWorningString明細(ByVal dataIndex As Integer,
        '                                                 ByVal エラー＿警告番号 As Integer,
        '                                                 ByRef my項目名称 As My項目名称Param型
        '                       ) As String    'X1変換Tool-20170508
        'D-CUST20190830↑
        Dim result As String = ""

        result = CType(エラー＿警告番号, エラー＿警告一覧_明細).ToString    'X1変換Tool-20170508

        'Enum定義できないエラーの文字は、ここで編集する()
        result = result.Replace("_警告", "(警告)")
        result = result.Replace("_Ｎｏ", "№")
        result = result.Replace("_削除済", "(削除済)")      'A-2008/07/18_Ver7.30_GENKA
        result = result.Replace("_換算後", "(換算後)")      'A-20121217_Ver7.50_1
        result = result.Replace("_未検収", "(未検収分除く)")        'A-20130610_2
        result = result.Replace("＿中黒", "・")                     'A-20170601-X1-項目名不正

        result = result.Replace("_v1", "＜")
        result = result.Replace("_v2", "＞")

        result = result.Replace("構成品_", "")
        result = result.Replace("内訳_", "")

        result = TextFileImportLib.MyReplace(result, "営業所", my項目名称.販売営業所)
        result = TextFileImportLib.MyReplace(result, "仕入先", my項目名称.販売仕入先)
        result = TextFileImportLib.MyReplace(result, "担当者", my項目名称.販売仕入担当者_項目)
        result = TextFileImportLib.MyReplace(result, "部門", my項目名称.販売部門)
        result = TextFileImportLib.MyReplace(result, "倉庫", my項目名称.販売倉庫)
        result = TextFileImportLib.MyReplace(result, "商品", my項目名称.販売商品)
        result = TextFileImportLib.MyReplace(result, "得意先", my項目名称.販売得意先)       'A-2008/07/18_Ver7.30_GENKA
        result = TextFileImportLib.MyReplace(result, "原価集計ﾒｲﾝ", my項目名称.販売原価集計 & my項目名称.販売原価集計メイン)    'A-2008/07/18_Ver7.30_GENKA
        result = TextFileImportLib.MyReplace(result, "原価集計ｻﾌﾞ", my項目名称.販売原価集計 & my項目名称.販売原価集計サブ)      'A-2008/07/18_Ver7.30_GENKA
        result = TextFileImportLib.MyReplace(result, "原価集計", my項目名称.販売原価集計)   'A-2008/07/18_Ver7.30_GENKA
        result = TextFileImportLib.MyReplace(result, "要素", my項目名称.要素タイトル)       'A-2008/07/18_Ver7.30_GENKA

        result = TextFileImportLib.MyReplace(result, "品名１", my項目名称.販売品目名１)
        result = TextFileImportLib.MyReplace(result, "品名２", my項目名称.販売品目名２)
        result = TextFileImportLib.MyReplace(result, "品名３", my項目名称.販売品目名３)
        result = TextFileImportLib.MyReplace(result, "客先注番", my項目名称.販売客先注番)
        result = TextFileImportLib.MyReplace(result, "有効期限", my項目名称.販売有効期限)

        'A-CUST20190830↓
        For i As Integer = 1 To 20
            If i <= 9 Then
                result = TextFileImportLib.MyReplace(result, "明細拡張項目" & StrConv(CStr(i), VbStrConv.Wide), my拡張定義.項目情報.項目(i).項目名)
            Else
                result = TextFileImportLib.MyReplace(result, "明細拡張項目" & i, my拡張定義.項目情報.項目(i).項目名)
            End If
        Next
        'A-CUST20190830↑

        ''↓A-2009/12/18_Ver7.40_UCHIWAKE
        'Select Case エラー・警告番号
        '    Case エラー・警告一覧_明細.単位換算数量計算不正_警告
        '        result = TextFileImportLib.MyReplace(result, "単位換算数量", my項目名称.販売単位換算数量)

        '    Case エラー・警告一覧_明細.換算数量不正, _
        '         エラー・警告一覧_明細.換算数量指定不可
        '        result = TextFileImportLib.MyReplace(result, "換算数量", my項目名称.販売換算数量)

        '        '↓A-2009/12/18_Ver7.40_LOT
        '    Case エラー・警告一覧_明細.ロットNo不正, _
        '         エラー・警告一覧_明細.ロットNo指定不可, _
        '         エラー・警告一覧_明細.新規ロットNo重複
        '        result = TextFileImportLib.MyReplace(result, "ロットNo", my項目名称.販売ロットNo)

        '    Case エラー・警告一覧_明細.ロットﾏｽﾀｰなし, _
        '         エラー・警告一覧_明細.完了ロット指定不可, _
        '         エラー・警告一覧_明細.諸口ロットを採用_警告
        '        result = TextFileImportLib.MyReplace(result, "ロット", my項目名称.販売ロット)

        '    Case エラー・警告一覧_明細.サブロットNo不正
        '        result = TextFileImportLib.MyReplace(result, "サブロットNo", my項目名称.販売サブロットNo)
        '        '↑A-2009/12/18_Ver7.40_LOT

        'End Select
        ''↑A-2009/12/18_Ver7.40_UCHIWAKE

        Return result

    End Function

#End Region

    Public Enum Myメッセージ As Integer
        HAN3005_拡張項目の定義が変更されています_拡張項目内容を確認して下さい = 3005
    End Enum

End Class

#Region "列挙型"

Public Enum 更新区分型
    NONE
    INSERT
    UPDATE
End Enum

Public Enum 伝票区分型 As Integer   'A-2009/08/21_RIREKI
    仕入 = 1
    入出庫 = 5
    'A-CUST20190830↓
    入出庫_自分 = 51
    入出庫_相手 = 52
    'A-CUST20190830↑
    購買入庫 = 8
    仕掛入庫 = 9
End Enum

Public Enum 受発注区分型 As Integer 'A-2009/08/21_RIREKI
    発注 = 1
End Enum

Public Enum 入出庫区分型 As Integer
    入庫 = 1
    出庫 = 2
End Enum

Public Enum 残区分型 As Integer
    残あり = 0
    残なし = 1
End Enum

Public Enum 内訳種別型 As Integer   'A-2009/12/18_Ver7.40_UCHIWAKE
    内訳種別１ = 1
    内訳種別２
    内訳種別３
End Enum

'A-20130402_2↓
Public Enum readDataType As Integer
    ロット明細_構成品 = 0

End Enum
'A-20130402_2↑

Public Enum 仕入データ型 As Integer
    伝票日付 = 0
    入荷番号
    受入番号
    処理連番
    明細区分
    行番号
    製番
    仕入先コード
    仕入先名１
    仕入先名２
    担当者コード
    部門コード
    営業所コード
    支払区分
    買掛区分
    取引区分
    取引区分属性
    倉庫コード
    ロケーション
    ロット_Ｎｏ
    有効期限
    商品コード
    商品名
    品名１
    品名２
    品名３
    工程コード
    完成品区分
    入数
    個数
    個数単位
    数量
    数量単位
    単価
    金額
    上代単価
    単価掛率
    課税区分
    上代課税区分
    消費税率
    内消費税等
    明細消費税等
    不良数量
    完納区分
    行摘要コード
    行摘要１
    行摘要２
    備考コード
    備考
    発注区分
    発注番号
    '発注行番号
    自動生成区分
    消費税仮計上区分
    伝票消費税計算区分
    明細消費税計算区分
    データ発生区分
    '相手処理連番
    拡張項目入力パターン番号
    伝票拡張項目０１
    伝票拡張項目０２
    伝票拡張項目０３
    伝票拡張項目０４
    伝票拡張項目０５
    伝票拡張項目０６
    伝票拡張項目０７
    伝票拡張項目０８
    伝票拡張項目０９
    伝票拡張項目１０
    伝票拡張項目１１
    伝票拡張項目１２
    伝票拡張項目１３
    伝票拡張項目１４
    伝票拡張項目１５
    伝票拡張項目１６
    伝票拡張項目１７
    伝票拡張項目１８
    伝票拡張項目１９
    伝票拡張項目２０
    伝票拡張項目付箋色番号
    明細拡張項目０１
    明細拡張項目０２
    明細拡張項目０３
    明細拡張項目０４
    明細拡張項目０５
    明細拡張項目０６
    明細拡張項目０７
    明細拡張項目０８
    明細拡張項目０９
    明細拡張項目１０
    明細拡張項目１１
    明細拡張項目１２
    明細拡張項目１３
    明細拡張項目１４
    明細拡張項目１５
    明細拡張項目１６
    明細拡張項目１７
    明細拡張項目１８
    明細拡張項目１９
    明細拡張項目２０
    明細拡張項目付箋色番号

    計上区分
    仮単価区分
    費目コード
    レート                      'A-20121217_Ver7.50_1
    レート種類                  'A-20121217_Ver7.50_1
    換算基準                    'A-20121217_Ver7.50_1
    諸掛管理_Ｎｏ               'A-20121217_Ver7.50_1
    按分対象                    'A-20121217_Ver7.50_1
    按分基準                    'A-20121217_Ver7.50_1
    INVOICE_Ｎｏ                'A-20121217_Ver7.50_1
    レート固定区分              'A-20160324_1
    原価計上手配番号            'A-20160324_2
    構成品出庫生成区分
    出庫日 '構成品_伝票日付

    構成品_行
    構成品_展開順序番号
    構成品_取引区分
    構成品_倉庫コード
    構成品_ロケーション
    構成品_商品コード
    構成品_商品名
    構成品_品名１
    構成品_品名２
    構成品_品名３
    構成品_出庫数量
    構成品_出庫単位
    構成品_行摘要コード
    構成品_行摘要１
    構成品_行摘要２
    内訳_ロット_Ｎｏ
    内訳_ロット別数量
    構成品_完納区分             'A-20120315_1

    ''↓A-2008/07/18_Ver7.30_GENKA
    '原価集計メインコード
    '原価集計サブコード
    '要素コード
    ''↑A-2008/07/18_Ver7.30_GENKA
    '内訳コード１            'A-2009/12/18_Ver7.40_UCHIWAKE
    '内訳コード２            'A-2009/12/18_Ver7.40_UCHIWAKE
    '内訳コード３            'A-2009/12/18_Ver7.40_UCHIWAKE
    '換算数量                'A-2009/12/18_Ver7.40_UCHIWAKE
    '金額算出モード          'A-2009/12/18_Ver7.40_UCHIWAKE
    'ロットNo                'A-2009/12/18_Ver7.40_LOT
    'サブロットNo            'A-2009/12/18_Ver7.40_LOT
    '有効期限                'A-2009/12/18_Ver7.40_LOT

    'A-CUST20190830↓
    入出庫予定No
    入出庫予定行No
    データ区分
    伝票種別
    'A-CUST20190830↑

    _項目数
End Enum

''' <summary>
''' 取込データテキスト出力形式
''' </summary>
''' <remarks>先頭がアンダーバー(_)は参照項目</remarks>
Public Enum テキスト出力型 As Integer
    伝票日付 = 0
    _年月度
    入荷番号
    受入番号
    処理連番
    明細区分
    _明細区分名
    行番号
    _返品区分
    _元入荷連番
    製番
    _製番分類コード0
    _製番分類名0
    _製番分類コード1
    _製番分類名1
    _製番分類コード2
    _製番分類名2
    _製番分類コード3
    _製番分類名3
    _製番分類コード4
    _製番分類名4
    _製番分類コード5
    _製番分類名5
    _製番分類コード6
    _製番分類名6
    _製番分類コード7
    _製番分類名7
    _製番分類コード8
    _製番分類名8
    _製番分類コード9
    _製番分類名9
    _客先注番
    仕入先コード
    仕入先名１
    仕入先名２
    _仕入先名略称
    _仕入先分類コード０
    _仕入先分類名０
    _仕入先分類コード１
    _仕入先分類名１
    _仕入先分類コード２
    _仕入先分類名２
    _仕入先分類コード３
    _仕入先分類名３
    _仕入先分類コード４
    _仕入先分類名４
    _仕入先分類コード５
    _仕入先分類名５
    _仕入先分類コード６
    _仕入先分類名６
    _仕入先分類コード７
    _仕入先分類名７
    _仕入先分類コード８
    _仕入先分類名８
    _仕入先分類コード９
    _仕入先分類名９
    '_支払先コード
    '_支払先名
    '_支払先分類コード０
    '_支払先分類名０
    '_支払先分類コード１
    '_支払先分類名１
    '_支払先分類コード２
    '_支払先分類名２
    '_支払先分類コード３
    '_支払先分類名３
    '_支払先分類コード４
    '_支払先分類名４
    '_支払先分類コード５
    '_支払先分類名５
    '_支払先分類コード６
    '_支払先分類名６
    '_支払先分類コード７
    '_支払先分類名７
    '_支払先分類コード８
    '_支払先分類名８
    '_支払先分類コード９
    '_支払先分類名９
    担当者コード
    _担当者名
    _担当者分類コード０
    _担当者分類名０
    _担当者分類コード１
    _担当者分類名１
    _担当者分類コード２
    _担当者分類名２
    _担当者分類コード３
    _担当者分類名３
    _担当者分類コード４
    _担当者分類名４
    _担当者分類コード５
    _担当者分類名５
    _担当者分類コード６
    _担当者分類名６
    _担当者分類コード７
    _担当者分類名７
    _担当者分類コード８
    _担当者分類名８
    _担当者分類コード９
    _担当者分類名９
    部門コード
    _部門名
    _部門分類コード０
    _部門分類名０
    _部門分類コード１
    _部門分類名１
    _部門分類コード２
    _部門分類名２
    _部門分類コード３
    _部門分類名３
    _部門分類コード４
    _部門分類名４
    _部門分類コード５
    _部門分類名５
    _部門分類コード６
    _部門分類名６
    _部門分類コード７
    _部門分類名７
    _部門分類コード８
    _部門分類名８
    _部門分類コード９
    _部門分類名９
    営業所コード
    _営業所名
    _営業所分類コード０
    _営業所分類名０
    _営業所分類コード１
    _営業所分類名１
    _営業所分類コード２
    _営業所分類名２
    _営業所分類コード３
    _営業所分類名３
    _営業所分類コード４
    _営業所分類名４
    _営業所分類コード５
    _営業所分類名５
    _営業所分類コード６
    _営業所分類名６
    _営業所分類コード７
    _営業所分類名７
    _営業所分類コード８
    _営業所分類名８
    _営業所分類コード９
    _営業所分類名９
    支払区分
    _支払区分名
    買掛区分
    _買掛区分名
    取引区分
    _取引区分名
    取引区分属性
    _取引区分属性名
    倉庫コード
    _倉庫名
    ロケーション
    _ロット管理区分
    _ロット管理区分名
    ロットNo
    有効期限
    商品コード
    商品名
    品名１
    品名２
    品名３
    _商品分類コード０
    _商品分類名０
    _商品分類コード１
    _商品分類名１
    _商品分類コード２
    _商品分類名２
    _商品分類コード３
    _商品分類名３
    _商品分類コード４
    _商品分類名４
    _商品分類コード５
    _商品分類名５
    _商品分類コード６
    _商品分類名６
    _商品分類コード７
    _商品分類名７
    _商品分類コード８
    _商品分類名８
    _商品分類コード９
    _商品分類名９
    工程コード
    _工程名
    _工程分類コード0
    _工程分類名0
    _工程分類コード1
    _工程分類名1
    _工程分類コード2
    _工程分類名2
    _工程分類コード3
    _工程分類名3
    _工程分類コード4
    _工程分類名4
    _工程分類コード5
    _工程分類名5
    _工程分類コード6
    _工程分類名6
    _工程分類コード7
    _工程分類名7
    _工程分類コード8
    _工程分類名8
    _工程分類コード9
    _工程分類名9
    完成品区分
    _完成品区分名
    _子部品引当区分
    _子部品引当区分名
    入数
    個数
    個数単位
    数量
    数量単位
    単価
    金額
    上代単価
    _原単価
    _原価金額
    _粗利
    単価掛率
    課税区分
    _課税区分名
    上代課税区分
    _上代課税区分名
    消費税率
    内消費税等
    明細消費税等
    _在庫単位数量
    _在庫単位
    _発注単位変換係数
    不良数量
    _在庫単位数量_不良
    完納区分
    _完納区分名
    行摘要コード
    行摘要１
    行摘要２
    備考コード
    備考
    発注区分
    _発注区分名
    _発注確定区分
    _発注確定区分名
    _手配管理番号
    _手配番号
    _個別発注連番
    _ログインＩＤ
    _ログイン名
    _操作日付
    発注番号
    '発注行番号
    '_オーダーコード
    自動生成区分
    _自動生成区分名
    消費税仮計上区分
    伝票消費税計算区分
    _伝票消費税計算区分名
    明細消費税計算区分
    _明細消費税計算区分名
    データ発生区分
    _相手仕入処理連番
    _相手仕入行番号
    _相手入庫処理連番
    _相手入庫行番号
    _検収残区分
    _検収残金額
    拡張項目入力パターン番号
    _拡張項目入力パターン名
    伝票拡張項目０１
    _伝票拡張項目参照０１
    伝票拡張項目０２
    _伝票拡張項目参照０２
    伝票拡張項目０３
    _伝票拡張項目参照０３
    伝票拡張項目０４
    _伝票拡張項目参照０４
    伝票拡張項目０５
    _伝票拡張項目参照０５
    伝票拡張項目０６
    _伝票拡張項目参照０６
    伝票拡張項目０７
    _伝票拡張項目参照０７
    伝票拡張項目０８
    _伝票拡張項目参照０８
    伝票拡張項目０９
    _伝票拡張項目参照０９
    伝票拡張項目１０
    _伝票拡張項目参照１０
    伝票拡張項目１１
    _伝票拡張項目参照１１
    伝票拡張項目１２
    _伝票拡張項目参照１２
    伝票拡張項目１３
    _伝票拡張項目参照１３
    伝票拡張項目１４
    _伝票拡張項目参照１４
    伝票拡張項目１５
    _伝票拡張項目参照１５
    伝票拡張項目１６
    _伝票拡張項目参照１６
    伝票拡張項目１７
    _伝票拡張項目参照１７
    伝票拡張項目１８
    _伝票拡張項目参照１８
    伝票拡張項目１９
    _伝票拡張項目参照１９
    伝票拡張項目２０
    _伝票拡張項目参照２０
    伝票拡張項目付箋色番号
    _伝票拡張項目付箋色文字
    明細拡張項目０１
    _明細拡張項目参照０１
    明細拡張項目０２
    _明細拡張項目参照０２
    明細拡張項目０３
    _明細拡張項目参照０３
    明細拡張項目０４
    _明細拡張項目参照０４
    明細拡張項目０５
    _明細拡張項目参照０５
    明細拡張項目０６
    _明細拡張項目参照０６
    明細拡張項目０７
    _明細拡張項目参照０７
    明細拡張項目０８
    _明細拡張項目参照０８
    明細拡張項目０９
    _明細拡張項目参照０９
    明細拡張項目１０
    _明細拡張項目参照１０
    明細拡張項目１１
    _明細拡張項目参照１１
    明細拡張項目１２
    _明細拡張項目参照１２
    明細拡張項目１３
    _明細拡張項目参照１３
    明細拡張項目１４
    _明細拡張項目参照１４
    明細拡張項目１５
    _明細拡張項目参照１５
    明細拡張項目１６
    _明細拡張項目参照１６
    明細拡張項目１７
    _明細拡張項目参照１７
    明細拡張項目１８
    _明細拡張項目参照１８
    明細拡張項目１９
    _明細拡張項目参照１９
    明細拡張項目２０
    _明細拡張項目参照２０
    明細拡張項目付箋色番号
    _明細拡張項目付箋色文字
    計上区分
    _計上区分名
    仮単価区分
    _仮単価区分名
    費目コード
    _費目名
    _費目区分
    _費目区分名
    _通貨コード              'A-20121217_Ver7.50_1
    _通貨名称                'A-20121217_Ver7.50_1
    レート                   'A-20121217_Ver7.50_1
    レート種類               'A-20121217_Ver7.50_1
    _レート種類名            'A-20121217_Ver7.50_1
    換算基準                 'A-20121217_Ver7.50_1
    _換算基準名              'A-20121217_Ver7.50_1
    _入荷単価_換算額         'A-20121217_Ver7.50_1
    _入荷金額_換算額         'A-20121217_Ver7.50_1
    _検収残金額_換算額       'A-20121217_Ver7.50_1
    諸掛管理No               'A-20121217_Ver7.50_1
    按分対象                 'A-20121217_Ver7.50_1
    _按分対象名              'A-20121217_Ver7.50_1
    按分基準                 'A-20121217_Ver7.50_1
    _按分基準名              'A-20121217_Ver7.50_1
    INVOICENo                'A-20121217_Ver7.50_1
    レート固定区分           'A-20160324_1
    _レート固定区分名        'A-20160324_1
    原価計上手配番号         'A-20160324_2
    構成品出庫生成区分
    _構成品出庫生成区分名
    構成品_伝票日付
    _構成品_年月度
    _構成品_伝票番号
    _構成品_処理連番
    構成品_行
    構成品_展開順序番号
    _構成品_入出庫区分
    _構成品_入出庫区分名
    構成品_取引区分
    _構成品_取引区分名
    _構成品_取引区分属性
    _構成品_取引区分属性名
    構成品_倉庫コード
    _構成品_倉庫名
    構成品_ロケーション
    構成品_商品コード
    構成品_品目名
    構成品_品目名１
    構成品_品目名２
    構成品_品目名３
    _構成品_商品分類コード0
    _構成品_商品分類名0
    _構成品_商品分類コード1
    _構成品_商品分類名1
    _構成品_商品分類コード2
    _構成品_商品分類名2
    _構成品_商品分類コード3
    _構成品_商品分類名3
    _構成品_商品分類コード4
    _構成品_商品分類名4
    _構成品_商品分類コード5
    _構成品_商品分類名5
    _構成品_商品分類コード6
    _構成品_商品分類名6
    _構成品_商品分類コード7
    _構成品_商品分類名7
    _構成品_商品分類コード8
    _構成品_商品分類名8
    _構成品_商品分類コード9
    _構成品_商品分類名9
    _構成品_ロット管理区分
    _構成品_ロット管理区分名
    構成品_出庫数量
    構成品_出庫単位
    構成品_行摘要コード
    構成品_行摘要１
    構成品_行摘要２
    _内訳_ロット明細連番
    内訳_ロットNo
    内訳_ロット別数量
    _内訳_有効期限
    構成品_完納区分          'A-20120315_1
    _構成品_完納区分名       'A-20120315_1

    ''↓A-2008/07/18_Ver7.30_GENKA
    '原価集計メインコード
    '原価集計サブコード
    '_原価集計メイン名
    '_原価集計サブ名
    '_原価集計分類コード０
    '_原価集計分類名０
    '_原価集計分類コード１
    '_原価集計分類名１
    '_原価集計分類コード２
    '_原価集計分類名２
    '_原価集計分類コード３
    '_原価集計分類名３
    '_原価集計分類コード４
    '_原価集計分類名４
    '_原価集計分類コード５
    '_原価集計分類名５
    '_原価集計分類コード６
    '_原価集計分類名６
    '_原価集計分類コード７
    '_原価集計分類名７
    '_原価集計分類コード８
    '_原価集計分類名８
    '_原価集計分類コード９
    '_原価集計分類名９
    '要素コード
    '_要素名
    '_完了日
    ''↑A-2008/07/18_Ver7.30_GENKA
    ''↓A-2009/12/18_Ver7.40_UCHIWAKE
    '内訳コード１
    '_内訳名１
    '_内訳１単位
    '内訳コード２
    '_内訳名２
    '_内訳２単位
    '内訳コード３
    '_内訳名３
    '_内訳３単位
    '換算数量
    '_換算数量単位
    '金額算出モード
    '_金額算出モード名
    ''↑A-2009/12/18_Ver7.40_UCHIWAKE
    ''↓A-2009/12/18_Ver7.40_LOT
    'ロットNo
    'サブロットNo
    '有効期限
    ''↑A-2009/12/18_Ver7.40_LOT
    _項目数
End Enum


''' <summary>
''' エラー・警告一覧(ヘッダー)
''' </summary>
''' <remarks></remarks>
Public Enum エラー＿警告一覧_ヘッダー As Integer    'X1変換Tool-20170508
    テキスト内に同一データ存在
    伝票日付不正
    締日更新中
    '入荷伝票番号不正        'D-20170601-X1-項目名統一　※「入荷_Ｎｏ不正」に名称変更
    入荷_Ｎｏ不正            'A-20170601-X1-項目名統一　※「名前の変更」で修正した為、ソース内に修正コメントは付加してません
    '入荷伝票番号指定不可    'D-20170601-X1-項目名統一　※「入荷_Ｎｏ指定不可」に名称変更
    入荷_Ｎｏ指定不可        'A-20170601-X1-項目名統一　※「名前の変更」で修正した為、ソース内に修正コメントは付加してません
    '入荷伝票番号変更不可    'D-20170601-X1-項目名統一　※「入荷_Ｎｏ変更不可」に名称変更
    入荷_Ｎｏ変更不可        'A-20170601-X1-項目名統一　※「名前の変更」で修正した為、ソース内に修正コメントは付加してません
    '受入伝票番号不正        'D-20170601-X1-項目名統一　※「受入_Ｎｏ不正」に名称変更
    受入_Ｎｏ不正            'A-20170601-X1-項目名統一　※「名前の変更」で修正した為、ソース内に修正コメントは付加してません
    '受入伝票番号指定不可    'D-20170601-X1-項目名統一　※「受入_Ｎｏ指定不可」に名称変更
    受入_Ｎｏ指定不可        'A-20170601-X1-項目名統一　※「名前の変更」で修正した為、ソース内に修正コメントは付加してません
    処理連番不正
    締日更新済_警告
    伝票が存在します
    伝票が存在しません
    他の伝票が存在します
    伝票修正不可
    受入引用返品伝票指定不可
    返品伝票存在
    製番不正
    製番ﾏｽﾀｰなし
    製番変更不可
    計上区分不正
    計上区分変更不可
    行番号不一致
    仕入先ｺｰﾄﾞ不正
    仕入先ｺｰﾄﾞﾏｽﾀｰなし
    仕入先ｺｰﾄﾞ変更不可
    仕入先名１不正
    仕入先名２不正
    担当者ｺｰﾄﾞ不正
    担当者ｺｰﾄﾞﾏｽﾀｰなし
    部門ｺｰﾄﾞ不正
    部門ｺｰﾄﾞﾏｽﾀｰなし
    営業所ｺｰﾄﾞ不正
    営業所ｺｰﾄﾞﾏｽﾀｰなし
    支払区分不正
    買掛区分不正
    備考ｺｰﾄﾞ不正
    備考ｺｰﾄﾞﾏｽﾀｰなし_警告
    備考名不正
    自動生成区分不正
    自動生成区分不一致
    消費税仮計上区分不正
    消費税仮計上区分指定不可
    伝票消費税計算区分不正
    ﾃﾞｰﾀ発生区分不正
    相手処理連番不正
    相手処理連番指定不可
    伝票拡張項目１不正
    伝票拡張項目１拡張参照ﾏｽﾀｰなし_警告
    伝票拡張項目２不正
    伝票拡張項目２拡張参照ﾏｽﾀｰなし_警告
    伝票拡張項目３不正
    伝票拡張項目３拡張参照ﾏｽﾀｰなし_警告
    伝票拡張項目４不正
    伝票拡張項目４拡張参照ﾏｽﾀｰなし_警告
    伝票拡張項目５不正
    伝票拡張項目５拡張参照ﾏｽﾀｰなし_警告
    伝票拡張項目６不正
    伝票拡張項目６拡張参照ﾏｽﾀｰなし_警告
    伝票拡張項目７不正
    伝票拡張項目７拡張参照ﾏｽﾀｰなし_警告
    伝票拡張項目８不正
    伝票拡張項目８拡張参照ﾏｽﾀｰなし_警告
    伝票拡張項目９不正
    伝票拡張項目９拡張参照ﾏｽﾀｰなし_警告
    伝票拡張項目10不正
    伝票拡張項目10拡張参照ﾏｽﾀｰなし_警告
    伝票拡張項目11不正
    伝票拡張項目11拡張参照ﾏｽﾀｰなし_警告
    伝票拡張項目12不正
    伝票拡張項目12拡張参照ﾏｽﾀｰなし_警告
    伝票拡張項目13不正
    伝票拡張項目13拡張参照ﾏｽﾀｰなし_警告
    伝票拡張項目14不正
    伝票拡張項目14拡張参照ﾏｽﾀｰなし_警告
    伝票拡張項目15不正
    伝票拡張項目15拡張参照ﾏｽﾀｰなし_警告
    伝票拡張項目16不正
    伝票拡張項目16拡張参照ﾏｽﾀｰなし_警告
    伝票拡張項目17不正
    伝票拡張項目17拡張参照ﾏｽﾀｰなし_警告
    伝票拡張項目18不正
    伝票拡張項目18拡張参照ﾏｽﾀｰなし_警告
    伝票拡張項目19不正
    伝票拡張項目19拡張参照ﾏｽﾀｰなし_警告
    伝票拡張項目20不正
    伝票拡張項目20拡張参照ﾏｽﾀｰなし_警告
    伝票拡張項目付箋色番号不正
    合計金額ｵｰﾊﾞｰ
    合計金額ｵｰﾊﾞｰ_換算後            'A-20121217_Ver7.50_1
    '明細＿消費税行_ＳＰ税額不一致    'X1変換Tool-20170508  'D-20170601-X1-項目名不正　※「明細＿中黒消費税行_ＳＰ税額不一致」に名称変更
    明細＿中黒消費税行_ＳＰ税額不一致                       'A-20170601-X1-項目名不正　※「名前の変更」で修正した為、ソース内に修正コメントは付加してません   
    仕入先月別ｵｰﾊﾞｰ
    仕入先月別ｵｰﾊﾞｰ_外貨            'A-20121217_Ver7.50_1
    支払予定消込済み        'A-2008/07/18_Ver7.30_SHIHARAI
    支払処理中あるいは支払済み      'A-2008/07/18_Ver7.30_SAIMU
    支払予定入力で消込済み          'A-2008/07/18_Ver7.30_SAIMU
    会計連結伝票変更あり_警告       'A-2008/07/18_Ver7.30_1
    完了ロットが存在                'A-2009/12/18_Ver7.40_LOT
    完成原価振替済み                'A-2009/12/18_Ver7.40_PRO
    消費税伝票指定不可
    受入処理連番使用済み
    構成品出庫生成区分不正
    出庫伝票削除_警告
    個別出庫伝票削除_警告
    行数オーバー
    仕入先基準倉庫未設定            'A-20111124_6
    製番完了済み                    'A-20150520_2
    レート固定区分不正              'A-20160324_1
    邦貨手入力伝票取込不可          'A-20160324_1
    '原価計上手配番号不正            'A-20160324_2  'D-20170601-X1-項目名統一  ※「原価計上手配_Ｎｏ不正」に名称変更
    原価計上手配_Ｎｏ不正                           'A-20170601-X1-項目名統一  ※「名前の変更」で修正した為、ソース内に修正コメントは付加してません
    '原価計上手配番号指定不可        'A-20160324_2  'D-20170601-X1-項目名統一  ※「原価計上手配_Ｎｏ指定不可」に名称変更
    原価計上手配_Ｎｏ指定不可                       'A-20170601-X1-項目名統一  ※「名前の変更」で修正した為、ソース内に修正コメントは付加してません
    '原価計上手配番号ﾌｧｲﾙなし        'A-20160324_2  'D-20170601-X1-項目名統一  ※「原価計上手配_Ｎｏﾌｧｲﾙなし」に名称変更
    原価計上手配_Ｎｏﾌｧｲﾙなし                       'A-20170601-X1-項目名統一  ※「名前の変更」で修正した為、ソース内に修正コメントは付加してません
    '原価計上手配番号変更不可        'A-20160324_2  'D-20170601-X1-項目名統一  ※「原価計上手配_Ｎｏ変更不可」に名称変更
    原価計上手配_Ｎｏ変更不可                       'A-20170601-X1-項目名統一  ※「名前の変更」で修正した為、ソース内に修正コメントは付加してません
    '原価計上手配番号不一致          'A-20160324_2  'D-20170601-X1-項目名統一  ※「原価計上手配_Ｎｏ不一致」に名称変更
    原価計上手配_Ｎｏ不一致                         'A-20170601-X1-項目名統一  ※「名前の変更」で修正した為、ソース内に修正コメントは付加してません

    'A-CUST20190830↓
    データ区分不正
    連番不正
    内職者コード不正
    'A-CUST20190830↑

    _項目数
End Enum

''' <summary>
''' エラー・警告一覧(明細)
''' </summary>
''' <remarks></remarks>
Public Enum エラー＿警告一覧_明細 As Integer    'X1変換Tool-20170508
    項目変換エラー
    項目変換エラー_計算式
    明細区分不正
    消費税明細指定不可        'A-20121217_Ver7.50_1
    行番号不正
    行番号重複
    取引区分不正
    取引区分変更不可
    取引区分属性不正
    取引区分属性不一致
    取引区分属性変更不可
    倉庫ｺｰﾄﾞ不正
    倉庫ｺｰﾄﾞﾏｽﾀｰなし
    倉庫ｺｰﾄﾞ不一致
    倉庫ｺｰﾄﾞ変更不可
    ロケーション不正
    ロケーション省略不可
    ロケーション変更不可
    商品ｺｰﾄﾞ不正
    商品ｺｰﾄﾞﾏｽﾀｰなし
    商品ｺｰﾄﾞ指定不可
    商品ｺｰﾄﾞ変更不可
    ﾀﾞﾐｰ商品
    商品使用禁止日ｴﾗｰ
    商品名不正
    品名１不正
    品名２不正
    品名３不正
    工程ｺｰﾄﾞ不正
    工程ｺｰﾄﾞ省略不可
    工程ｺｰﾄﾞ指定不可
    工程ｺｰﾄﾞﾏｽﾀｰなし
    完成品区分不正
    発注区分不正
    商品税率不一致_警告
    入数不正
    個数不正
    個数指定なし
    個数指定不可
    個数単位不正
    数量不正
    数量省略不可
    検収済数量未満
    数量単位不正
    規定桁数ｵｰﾊﾞｰ
    単価不正
    単価不正_換算後     'A-20121217_Ver7.50_1
    単価指定不可
    金額不正
    金額不正_換算後     'A-20121217_Ver7.50_1
    金額指定不可
    上代単価不正
    単価掛率不正
    課税区分不正
    上代課税区分不正
    上代課税区分指定不可
    消費税率不正
    消費税率不一致
    消費税行番号不連続
    '税率＿属性が昇順ではない    'X1変換Tool-20170508 'D-20170601-X1-項目名不正　※「税率＿中黒属性が昇順ではない」に名称変更
    税率＿中黒属性が昇順ではない                      'A-20170601-X1-項目名不正　※「名前の変更」で修正した為、ソース内に修正コメントは付加してません   
    課税対象額発生なし
    内消費税額不正
    内消費税額指定不可
    明細消費税等不正
    明細消費税等指定不可
    不良数量不正
    不良数量符号不正
    受入済数合計マイナス
    不良数合計が受入済数合計オーバー
    入庫数合計が受入済数合計オーバー
    行摘要ｺｰﾄﾞ不正
    行摘要ｺｰﾄﾞﾏｽﾀｰなし_警告
    行摘要１不正
    行摘要２不正
    '発注番号不正         'D-20170601-X1-項目名統一　※「発注_Ｎｏ不正」に名称変更
    発注_Ｎｏ不正         'A-20170601-X1-項目名統一　※「名前の変更」で修正した為、ソース内に修正コメントは付加してません
    '発注番号変更不可     'D-20170601-X1-項目名統一　※「発注_Ｎｏ変更不可」に名称変更
    発注_Ｎｏ変更不可     'A-20170601-X1-項目名統一　※「名前の変更」で修正した為、ソース内に修正コメントは付加してません
    '発注番号ﾌｧｲﾙなし_警告
    '発注番号ﾌｧｲﾙなし     'D-20170601-X1-項目名統一　※「発注_Ｎｏﾌｧｲﾙなし」に名称変更
    発注_Ｎｏﾌｧｲﾙなし     'A-20170601-X1-項目名統一　※「名前の変更」で修正した為、ソース内に修正コメントは付加してません
    '発注番号不一致       'D-20170601-X1-項目名統一　※「発注_Ｎｏ不一致」に名称変更
    発注_Ｎｏ不一致       'A-20170601-X1-項目名統一　※「名前の変更」で修正した為、ソース内に修正コメントは付加してません
    発注仕入先不一致
    発注行番号不正
    発注行番号指定不可
    発注行番号指定なし
    '発注行番号ﾌｧｲﾙなし_警告
    発注行番号ﾌｧｲﾙなし
    伝票日付_v1発注納期
    伝票日付_v1発注納期_警告
    発注商品不一致
    発注行番号重複
    発注明細取消済み
    発注取引区分不一致
    明細消費税計算区分不正
    明細消費税計算指定不可
    入力ﾊﾟﾀｰﾝ_Ｎｏ不正
    入力ﾊﾟﾀｰﾝ_Ｎｏなし_警告
    明細拡張項目１不正
    明細拡張項目１拡張参照ﾏｽﾀｰなし_警告
    明細拡張項目２不正
    明細拡張項目２拡張参照ﾏｽﾀｰなし_警告
    明細拡張項目３不正
    明細拡張項目３拡張参照ﾏｽﾀｰなし_警告
    明細拡張項目４不正
    明細拡張項目４拡張参照ﾏｽﾀｰなし_警告
    明細拡張項目５不正
    明細拡張項目５拡張参照ﾏｽﾀｰなし_警告
    明細拡張項目６不正
    明細拡張項目６拡張参照ﾏｽﾀｰなし_警告
    明細拡張項目７不正
    明細拡張項目７拡張参照ﾏｽﾀｰなし_警告
    明細拡張項目８不正
    明細拡張項目８拡張参照ﾏｽﾀｰなし_警告
    明細拡張項目９不正
    明細拡張項目９拡張参照ﾏｽﾀｰなし_警告
    明細拡張項目10不正
    明細拡張項目10拡張参照ﾏｽﾀｰなし_警告
    明細拡張項目11不正
    明細拡張項目11拡張参照ﾏｽﾀｰなし_警告
    明細拡張項目12不正
    明細拡張項目12拡張参照ﾏｽﾀｰなし_警告
    明細拡張項目13不正
    明細拡張項目13拡張参照ﾏｽﾀｰなし_警告
    明細拡張項目14不正
    明細拡張項目14拡張参照ﾏｽﾀｰなし_警告
    明細拡張項目15不正
    明細拡張項目15拡張参照ﾏｽﾀｰなし_警告
    明細拡張項目16不正
    明細拡張項目16拡張参照ﾏｽﾀｰなし_警告
    明細拡張項目17不正
    明細拡張項目17拡張参照ﾏｽﾀｰなし_警告
    明細拡張項目18不正
    明細拡張項目18拡張参照ﾏｽﾀｰなし_警告
    明細拡張項目19不正
    明細拡張項目19拡張参照ﾏｽﾀｰなし_警告
    明細拡張項目20不正
    明細拡張項目20拡張参照ﾏｽﾀｰなし_警告
    明細拡張項目付箋色番号不正
    ''↓A-2008/07/18_Ver7.30_GENKA
    '原価集計ﾒｲﾝｺｰﾄﾞ不正
    '原価集計ｻﾌﾞｺｰﾄﾞ不正
    '原価集計ｺｰﾄﾞﾏｽﾀｰなし
    '原価集計ｺｰﾄﾞ不正_削除済
    '発注原価集計不一致
    '受注得意先不一致
    '要素ｺｰﾄﾞ不正
    '要素ｺｰﾄﾞﾏｽﾀｰなし
    '要素ｺｰﾄﾞ指定不可
    '原価集計ﾒｲﾝｺｰﾄﾞ不一致
    '原価集計ﾒｲﾝｺｰﾄﾞ省略不可
    '原価集計ｻﾌﾞｺｰﾄﾞ不一致
    '原価集計ｻﾌﾞｺｰﾄﾞ省略不可
    ''↑A-2008/07/18_Ver7.30_GENKA
    ''↓A-2009/12/18_Ver7.40_UCHIWAKE
    '発注内訳不一致
    '内訳ｺｰﾄﾞ１不正
    '内訳ｺｰﾄﾞ１指定不可
    '内訳ｺｰﾄﾞ１ﾏｽﾀｰなし
    '内訳ｺｰﾄﾞ２不正
    '内訳ｺｰﾄﾞ２指定不可
    '内訳ｺｰﾄﾞ２ﾏｽﾀｰなし
    '内訳ｺｰﾄﾞ３不正
    '内訳ｺｰﾄﾞ３指定不可
    '内訳ｺｰﾄﾞ３ﾏｽﾀｰなし
    '単位換算数量計算不正_警告
    '換算数量不正
    '換算数量指定不可
    '金額算出ﾓｰﾄﾞ不正
    '金額算出ﾓｰﾄﾞ指定不可
    ''↑A-2009/12/18_Ver7.40_UCHIWAKE
    ''↓A-2009/12/18_Ver7.40_LOT
    'ロットNo不正
    'ロットNo指定不可
    'ロットﾏｽﾀｰなし
    '完了ロット指定不可
    '新規ロットNo重複
    '諸口ロットを採用_警告
    'サブロットNo不正
    '有効期限不正
    ''↑A-2009/12/18_Ver7.40_LOT
    発注計上区分不一致
    発注製番不一致
    ロット_Ｎｏ不正
    ロット_Ｎｏ指定不可
    ロット_Ｎｏ省略不可
    ロット_Ｎｏ変更不可
    ロット_Ｎｏなし
    有効期限不正
    有効期限指定不可
    有効期限変更不可
    完納区分不正
    完納区分指定不可
    仮単価区分不正
    仮単価区分指定不可
    仮単価指定不可
    仮単価指定不可_警告
    費目ｺｰﾄﾞ不正
    費目ｺｰﾄﾞ省略不可
    費目ｺｰﾄﾞﾏｽﾀｰなし
    費目ｺｰﾄﾞ変更不可
    出庫日不正
    出庫行番号不正
    出庫行番号重複
    出庫取引区分不正
    '展開順序番号不正    'D-20170601-X1-項目名統一　※「展開順序_Ｎｏ不正」に名称変更
    展開順序_Ｎｏ不正    'A-20170601-X1-項目名統一　※「名前の変更」で修正した為、ソース内に修正コメントは付加してません
    '展開順序番号重複    'D-20170601-X1-項目名統一　※「展開順序_Ｎｏ重複」に名称変更
    展開順序_Ｎｏ重複    'A-20170601-X1-項目名統一　※「名前の変更」で修正した為、ソース内に修正コメントは付加してません
    従属需要なし
    出庫倉庫ｺｰﾄﾞ不正
    出庫倉庫ｺｰﾄﾞﾏｽﾀｰなし
    出庫ロケーション不正
    出庫ロケーション省略不可
    出庫ロケーション重複不可   'A-20130425_2
    出庫商品ｺｰﾄﾞ不正
    出庫商品ｺｰﾄﾞﾏｽﾀｰなし
    従属需要商品不一致
    出庫ﾀﾞﾐｰ商品
    出庫商品使用禁止日ｴﾗｰ
    出庫商品名不正
    出庫品名１不正
    出庫品名２不正
    出庫品名３不正
    出庫数量不正
    出庫数量単位不正
    出庫数量符号不正
    出庫行摘要ｺｰﾄﾞ不正
    出庫行摘要ｺｰﾄﾞﾏｽﾀｰなし_警告
    出庫行摘要１不正
    出庫行摘要２不正
    出庫ロット_Ｎｏ不正
    ロット別数量不正
    有効在庫取得エラー
    ロット重複不可
    入庫数マイナス在庫
    入庫数マイナス在庫_警告
    入庫数マイナス在庫_未検収_警告        'A-20121217_Ver7.50_1
    出庫情報_xマイナス在庫
    出庫情報_xマイナス在庫_警告
    出庫情報_xマイナス在庫_未検収_警告    'A-20121217_Ver7.50_1
    出庫情報_xみなし出庫数量不正
    出庫情報_x出庫数合計マイナス
    出庫情報_xみなし出庫数量符号不正
    前工程実績_x
    前工程実績_x_警告
    後工程実績_x
    後工程実績_x_警告
    前工程未確定        'A-20111025_4
    前工程未確定_警告   'A-20111025_4
    後工程未確定        'A-20111025_4
    前工程仕掛在庫_x            'A-20120125_1
    前工程仕掛在庫_x_警告       'A-20120125_1
    前工程仕掛在庫_x_未検収_警告          'A-20121217_Ver7.50_1
    入庫数マイナス仕掛在庫      'A-20120125_1
    入庫数マイナス仕掛在庫_警告 'A-20120125_1
    入庫数マイナス仕掛在庫_未検収_警告    'A-20121217_Ver7.50_1
    出庫完納区分不正            'A-20120315_1

    発注残なし                  'A-20120315_3
    発注残なし_警告             'A-20120315_3

    発注残オーバー              'A-20120315_3
    発注残オーバー_警告         'A-20120315_3

    レート不正                  'A-20121217_Ver7.50_1
    レート指定不可              'A-20121217_Ver7.50_1
    レート変更不可              'A-20121217_Ver7.50_1
    レート種類不正              'A-20121217_Ver7.50_1
    レート種類指定不可          'A-20121217_Ver7.50_1
    レート種類変更不可          'A-20121217_Ver7.50_1
    換算基準不正                'A-20121217_Ver7.50_1
    換算基準指定不可            'A-20121217_Ver7.50_1
    換算基準変更不可            'A-20121217_Ver7.50_1
    諸掛管理_Ｎｏ不正           'A-20121217_Ver7.50_1
    按分対象区分不正            'A-20121217_Ver7.50_1
    按分基準不正                'A-20121217_Ver7.50_1
    按分済伝票                  'A-20121217_Ver7.50_1
    按分済伝票_警告             'A-20121217_Ver7.50_1
    按分済諸掛管理_Ｎｏ_警告    'A-20121217_Ver7.50_1
    INVOICE_Ｎｏ不正            'A-20121217_Ver7.50_1
    INVOICE_Ｎｏ指定不可        'A-20121217_Ver7.50_1
    INVOICE_Ｎｏ変更不可        'A-20121217_Ver7.50_1

    入庫数マイナス引当可能数               'A-20121217_Ver7.50_2
    入庫数マイナス引当可能数_未検収_警告   'A-20121217_Ver7.50_2
    出庫数マイナス引当可能数               'A-20121217_Ver7.50_3
    出庫数マイナス引当可能数_未検収_警告   'A-20121217_Ver7.50_3
    数量変更不可                           'A-20121217_Ver7.50_4
    数量マイナス不可                       'A-20121217_Ver7.50_4

    指定倉庫ｺｰﾄﾞ不正            'A-20130304_1
    指定ロケーション不正        'A-20130304_1
    指定ロット_Ｎｏ不正         'A-20130304_1

    報告回数オーバー            'A-20150713_1

    'A-CUST20190830↓
    行_Ｎｏ不正
    入出庫予定_Ｎｏ不正
    内訳_Ｎｏ不正
    入荷済み
    強制完納済み
    明細拡張項目18拡張参照ﾏｽﾀｰなし
    入庫予定数オーバー_警告
    'A-CUST20190830↑

    _項目数
End Enum

'A-CUST20190830↓
Public Enum チェック対象型 As Integer
    受発注番号 = 0
    受発注行番号
    内訳番号
End Enum
'A-CUST20190830↑

#End Region

#Region "製造実績関連"

Public Enum 構成品出庫区分型 As Integer
    自動 = 0
    する
    しない
End Enum

Public Enum 出庫取引区分型 As Integer
    製造出庫 = 5
    個別出庫 = 9
End Enum

Public Enum 出庫伝票種類型 As Integer
    製造出庫 = 14
    個別出庫
End Enum

Public Enum 支給区分型 As Integer
    無償支給 = 0
    有償支給 = 1
    自己調達 = 2
    支給なし = 9
End Enum

#End Region

'A-CUST20190830↓
#Region "カスタマイズ"

''' <summary>
''' 出力位置
''' </summary>
''' <remarks></remarks>
Public Enum 出力位置型 As Integer
    _001 = 0
    _002
    _003
    _004
    _005
    _006
    _007
    _008
    _009

    _項目数

End Enum

''' <summary>
''' 伝票種別
''' </summary>
''' <remarks></remarks>
Public Enum 伝票種別型 As Integer
    _想定外 = -1
    _発注_購買 = 1
    _発注_手配 = 2
    _予定入庫_預入庫 = 3
    _予定入庫_移動 = 4

End Enum

#End Region
'A-CUST20190830↑
