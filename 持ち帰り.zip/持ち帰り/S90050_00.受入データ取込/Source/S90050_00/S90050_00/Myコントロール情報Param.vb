﻿<Serializable()>
Public Class Myコントロール情報Param

#Region "■定義■"

    <Serializable()>
    Public Structure Myオプション区分型
        Dim 受発注管理 As オプション区分定義型.区分型
        Dim 部門管理 As オプション区分定義型.区分型
        Dim 拡張項目 As オプション区分定義型.区分型
        Dim 拡張項目_仕入伝票 As Boolean
        Dim 拡張項目_仕入明細 As Boolean
        Dim 原価管理 As オプション区分定義型.区分型     'A-2008/07/18_Ver7.30_GENKA
        Dim 支払管理 As オプション区分定義型.区分型     'A-2008/07/18_Ver7.30_SHIHARAI
        Dim 商品内訳管理 As Boolean                     'A-2009/12/18_Ver7.40_UCHIWAKE
        Dim ロット管理 As Boolean                       'A-2009/12/18_Ver7.40_UCHIWAKE
        'A-CUST20190830↓
        Dim 拡張項目_入出庫伝票 As Boolean
        Dim 拡張項目_入出庫明細 As Boolean
        'A-CUST20190830↑
    End Structure

    <Serializable()>
    Public Structure My機能区分型
        Dim 倉庫別在庫管理 As 機能区分定義型.倉庫別在庫管理型
        Dim 商品コード_タイプ As 機能区分定義型.商品コード_タイプ型
        Dim 商品コード_桁数 As 機能区分定義型.商品コード_桁数型
        Dim 得意先_仕入先_コード_タイプ As 機能区分定義型.得意先_仕入先_コード_タイプ型
        Dim 得意先_仕入先_コード_桁数 As 機能区分定義型.得意先_仕入先_コード_桁数型
        Dim 小数以下桁数_数量 As 機能区分定義型.数量型
        Dim 小数以下桁数_仕入単価 As 機能区分定義型.仕入単価型
        Dim 明細単位処理_受発注引当 As 機能区分定義型.受発注引当型
        Dim 明細単位処理_消費税計算 As 機能区分定義型.消費税計算型
        Dim 明細単位処理_倉庫入力 As 機能区分定義型.倉庫入力型
        Dim 汎用受入連番区分 As 機能区分定義型.汎用受入連番区分型
        Dim 担当者コード_タイプ As 機能区分定義型.担当者コード_タイプ型
        Dim 担当者コード_桁数 As 機能区分定義型.担当者コード_桁数型
        Dim 入数小数桁区分 As 機能区分定義型.入数小数桁区分型
        Dim 消費税改正対応区分 As 機能区分定義型.消費税改正対応区分型
        Dim 分類コード_タイプ As 機能区分定義型.分類コード_タイプ型             'A-2008/07/18_Ver7.30_GENKA
        Dim 分類コード_桁数 As 機能区分定義型.分類コード_桁数型                 'A-2008/07/18_Ver7.30_GENKA
        Dim 部門コード_タイプ As 機能区分定義型.部門コード_タイプ型
        Dim 部門コード_桁数 As 機能区分定義型.部門コード_桁数型
        Dim 営業所管理 As 機能区分定義型.営業所管理区分型
        Dim 営業所コード_タイプ As 機能区分定義型.営業所コード_タイプ型
        Dim 営業所コード_桁数 As 機能区分定義型.営業所コード_桁数型
        Dim 注残更新区分 As 機能区分定義型.注残更新区分型
        Dim 原価集計コード_タイプ As 機能区分定義型.原価集計コード_タイプ型     'A-2008/07/18_Ver7.30_GENKA
        Dim 原価集計コード_桁数 As 機能区分定義型.原価集計コード_桁数型         'A-2008/07/18_Ver7.30_GENKA
        Dim 小数以下桁数_換算数量 As 機能区分定義型.換算数量型                  'A-2009/12/18_Ver7.40_UCHIWAKE
        Dim 受注在庫引当 As 機能区分定義型.受注在庫引当型                                    'A-20121217_Ver7.50_2
        Dim マイナス在庫警告_未検収入荷 As 機能区分定義型.マイナス在庫警告_未検収入荷型      'A-20121217_Ver7.50_4
        Dim 在庫評価区分 As 機能区分定義型.在庫評価区分型   'A-CUST20190830
    End Structure

    <Serializable()>
    Public Structure My初期値型
        Dim 倉庫コード As String
        Dim 部門コード_仕入 As String
        Dim 営業所コード As String
    End Structure

    <Serializable()>
    Public Structure My仕入処理型
        Dim 入数個数 As 仕入処理定義型.入数個数使用区分型
        Dim 上代 As 仕入処理定義型.上代使用区分型
    End Structure

    <Serializable()>
    Public Structure My消費税型
        Dim 税抜消費税算出方法_仕入 As 消費税定義型.仕入型
        Dim 仮計上消費税使用区分 As 消費税定義型.仮計上消費税使用区分型
        Dim 新税率区分 As 消費税定義型.新税率区分型
    End Structure

    <Serializable()>
    Public Structure My受発注管理型
        Dim 売上_仕入_完納区分表示 As 受発注管理定義型.完納区分表示型
    End Structure

    'A-20121217_Ver7.50_4↓
    <Serializable()>
    Public Structure My受注在庫引当型
        Dim 在庫引当警告_未検収入荷 As 受注在庫引当定義型.在庫引当警告_未検収入荷型
    End Structure
    'A-20121217_Ver7.50_4↑

    <Serializable()>
    Public Structure My拡張項目型
        Dim 拡張項目入力処理画面表示 As 拡張項目設計型.利用区分型
    End Structure

    <Serializable()>
    Public Structure MyＲＥＶ型     'A-2008/07/18_Ver7.30_GENKA
        Dim 強化区分 As Decimal
    End Structure

    <Serializable()>
    Public Structure My原価管理型  'A-2008/07/18_Ver7.30_GENKA
        Dim 要素使用分類種別 As Integer
        Dim 明細単位原価集計入力_売上 As 原価管理定義型.明細単位原価集計入力型
        Dim 明細単位原価集計入力_仕入 As 原価管理定義型.明細単位原価集計入力型
    End Structure

    <Serializable()>
    Public Structure My支払管理型  'A-2008/07/18_Ver7.30_SHIHARAI
        Dim 支払先別支払管理単位設定 As 支払管理定義型.支払先別支払管理単位設定型
        Dim 支払管理単位 As 支払管理定義型.支払管理単位型
        Dim 支払_原価集計別管理 As 支払管理定義型.支払_原価集計別管理型
    End Structure

    <Serializable()>
    Public Structure My変更履歴型   'A-2009/08/21_RIREKI
        Dim 変更履歴使用区分 As Boolean
        Dim 変更履歴_仕入 As Boolean
        Dim 変更履歴_発注 As Boolean
        Dim 変更履歴_内訳 As Boolean        'A-2009/12/18_Ver7.40_UCHIWAKE
        Dim 変更履歴_商品内訳 As Boolean    'A-2009/12/18_Ver7.40_UCHIWAKE
        Dim 変更履歴_ロット As Boolean      'A-2009/12/18_Ver7.40_LOT
    End Structure

    <Serializable()>
    Public Structure My商品内訳管理型   'A-2009/12/18_Ver7.40_UCHIWAKE
        Dim 内訳管理数 As Integer
        Dim 内訳コードタイプ() As 商品管理拡張定義型.コードタイプ型
        Dim 内訳コード桁数() As Integer
        Dim 内訳数値小数桁数() As Integer
        Dim 内訳マスター自動登録 As Boolean
        Dim 売上_仕入_処理_内訳変更区分 As 商品管理拡張定義型.売上_仕入_処理_内訳変更区分型
        Dim 内訳タイプ As 商品管理拡張定義型.内訳タイプ型
        Dim 換算数量使用区分 As Boolean
    End Structure

    <Serializable()>
    Public Structure Myロット管理型     'A-2009/12/18_Ver7.40_LOT
        Dim 手入力ロットNo桁数 As Integer
        Dim ロットNo採番方法 As ロット管理定義型.ロットNo採番方法型
        Dim 有効期限機能 As Boolean
    End Structure

    <Serializable()>
    Public Structure My端数処理型   'A-2009/12/18_Ver7.40_LOT
        Dim 単価端数処理_仕入_処理区分 As 端数処理定義型.端数処理型
        Dim 単価端数処理_仕入_単位 As Integer
    End Structure

    '↓A-20170601-X1-桁数拡張
    <Serializable()>
    Public Structure My桁数拡張型
        Dim 名称桁数 As Integer
        Dim 金額桁数 As Integer
        Dim 金額桁数_実績 As Integer
        Dim 拡張項目データリンク桁数拡張 As Boolean
    End Structure
    '↑A-20170601-X1-桁数拡張

    <Serializable()>
    Public Structure My販売財務連動型
        Dim 販売財務連動区分 As OSK.X1.BIS.LIB.ControlInfoC001.販売財務連動定義型.販売財務連動区分型    'X1変換Tool-20170508
        Dim 仕入データ連動区分 As OSK.X1.BIS.LIB.ControlInfoC001.販売財務連動定義型.仕入データ連動区分型    'X1変換Tool-20170508
    End Structure

    <Serializable()>
    Public Structure My会計オプション型 'A-2008/07/18_Ver7.30_SAIMU
        Dim 会計債務管理 As Boolean
        Dim 会計債務残消込管理 As Boolean
        Dim 会計原価振替処理 As Boolean         'A-2009/12/18_Ver7.40_PRO
    End Structure

    <Serializable()>
    Public Structure My会計伝票承認型   'A-2010/09/13_Ver7.4X_ZAISHONIN
        Dim 会計伝票承認機能 As Boolean
    End Structure

    <Serializable()>
    Public Structure MyMOA初期値型
        Dim ダミーロットNo As String
        'A-20120315_3↓
        Dim 残以上の取込を許可 As MOA追加初期値定義型.取込処理残チェック区分型
        Dim 完納データに対する取込を許可 As MOA追加初期値定義型.取込処理残チェック区分型
        'A-20120315_3↑

        'A-20120522_1↓
        Dim 需要数計算端数処理 As MOA追加初期値定義型.需要数計算端数処理型
        Dim 需要数計算端数処理_計算単位 As MOA追加初期値定義型.需要数計算端数処理_計算単位型
        'A-20120522_1↑
    End Structure

    <Serializable()>
    Public Structure MyMOAオプション型
        Dim MOA品質管理 As MOAオプション定義型.その他管理区分型
        Dim MOA原価管理 As MOAオプション定義型.その他管理区分型
        Dim MOA外貨管理 As MOAオプション定義型.その他管理区分型      'A-20121217_Ver7.50_1
    End Structure

    <Serializable()>
    Public Structure MyMOAロット管理型
        Dim 有効期限更新方法設定 As MOAロット管理定義型.有効期限更新方法設定型
    End Structure

    <Serializable()>
    Public Structure MyMOA機能追加型
        Dim 品目名既定値_代表品名 As MOA機能追加定義型.品目名既定値_代表品名型
        Dim マイナス在庫チェック As MOA機能追加定義型.マイナス在庫チェック型
        Dim 構成品自動出庫 As MOA機能追加定義型.その他管理区分型
        Dim 仕入検収基準 As MOA機能追加定義型.その他管理区分型
        Dim ロットNo管理区分_受入 As MOA機能追加定義型.ロットNo管理区分_受入型
        Dim 支給管理区分 As MOA機能追加定義型.支給管理区分型
        Dim 仕掛管理区分 As MOA機能追加定義型.その他管理区分型      'A-20110912_1
        Dim 仕掛計上区分 As MOA機能追加定義型.仕掛計上区分型        'A-20110912_1
        Dim ロケーション単位数量指定列 As MOA機能追加定義型.ロケーション単位数量指定列       'A-20121217_Ver7.50_3
        Dim 未検収在庫機能 As MOA機能追加定義型.未検収在庫機能使用区分型                     'A-20121217_Ver7.50_4
        Dim マイナス仕掛在庫警告_未検収入荷 As MOA機能追加定義型.マイナス仕掛在庫警告区分型  'A-20121217_Ver7.50_4
        Dim 標準原価積上機能 As MOA機能追加定義型.使用有無区分型    'A-20141105_1
        Dim 品目別原価計算機能 As MOA機能追加定義型.使用有無区分型  'A-20150520_2
        Dim 外貨管理明細邦貨額積上機能 As MOA機能追加定義型.使用有無区分型  'A-20160324_1
        Dim 製番別締機能 As MOA機能追加定義型.使用有無区分型                'A-20160324_2
        'A-20170417_1↓
        Dim 見込受注得意先以外の出庫予定制御 As MOA機能追加定義型.その他管理区分型
        Dim 生産計画機能 As MOA機能追加定義型.使用有無区分型
        'A-20170417_1↑
    End Structure

    <Serializable()>
    Public Structure MyMOA受入処理型
        Dim 納期前チェック As MOA受入処理定義型.その他管理区分型
        Dim 仮単価チェック As MOA受入処理定義型.その他管理区分型
        Dim 前工程チェック As MOA受入処理定義型.その他管理区分型
    End Structure
    'A-20110912_1↓
    <Serializable()>
    Public Structure MyMOAＲＥＶ型
        Dim MOA強化区分 As Decimal
    End Structure
    'A-20110912_1↑

    'A-20121217_Ver7.50_1↓
    <Serializable()>
    Public Structure MyMOA外貨管理型
        Dim 日本円通貨コード As String
        Dim レート使用区分() As MOA外貨定義型.レート使用区分型
        Dim レート名称() As String
        Dim 外貨複数伝票消込機能 As MOA外貨定義型.制御区分型    'A-20160324_1
    End Structure
    'A-20121217_Ver7.50_1↑

    'A-20121217_Ver7.50_2↓
    <Serializable()>
    Public Structure MyMOA在庫引当型
        Dim 引当数量算出区分_未検収入荷 As MOA在庫引当定義型.引当数量算出区分型
        Dim 在庫引当_自動出庫区分 As MOA在庫引当定義型.在庫引当_自動出庫区分型
        Dim 需要数_入庫時即引当 As MOA在庫引当定義型.需要数_入庫時即引当区分型
        Dim 出庫まるめ引当単位区分 As MOA在庫引当定義型.出庫まるめ引当単位区分型    'A-20180723-X1-引当
    End Structure
    'A-20121217_Ver7.50_2↑

    'A-20150520_2↓
    <Serializable()>
    Public Structure MyMOA品目別原価型
        Dim 出庫時原価採用区分 As MOA品目別原価定義型.出庫時原価採用区分型
    End Structure
    'A-20150520_2↑

    'A-20170417_1↓
    <Serializable()>
    Public Structure MyMOAその他型
        Dim 見込受注用得意先コード As String
    End Structure
    'A-20170417_1↑

#End Region

#Region "■プロパティ■"

    Private _myオプション区分 As Myオプション区分型
    ''' <summary>
    ''' オプション区分
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property Myオプション区分() As Myオプション区分型
        Get
            Return _myオプション区分
        End Get
        Set(ByVal value As Myオプション区分型)
            _myオプション区分 = value
        End Set
    End Property

    Private _my機能区分 As My機能区分型
    ''' <summary>
    ''' 機能区分
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property My機能区分() As My機能区分型
        Get
            Return _my機能区分
        End Get
        Set(ByVal value As My機能区分型)
            _my機能区分 = value
        End Set
    End Property

    Private _my初期値 As My初期値型
    ''' <summary>
    ''' 初期値
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property My初期値() As My初期値型
        Get
            Return _my初期値
        End Get
        Set(ByVal value As My初期値型)
            _my初期値 = value
        End Set
    End Property

    Private _my仕入処理 As My仕入処理型
    ''' <summary>
    ''' 仕入処理
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property My仕入処理() As My仕入処理型
        Get
            Return _my仕入処理
        End Get
        Set(ByVal value As My仕入処理型)
            _my仕入処理 = value
        End Set
    End Property

    Private _my消費税 As My消費税型
    ''' <summary>
    ''' 消費税
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property My消費税() As My消費税型
        Get
            Return _my消費税
        End Get
        Set(ByVal value As My消費税型)
            _my消費税 = value
        End Set
    End Property

    Private _my受発注管理 As My受発注管理型
    ''' <summary>
    ''' 受発注管理
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property My受発注管理() As My受発注管理型
        Get
            Return _my受発注管理
        End Get
        Set(ByVal value As My受発注管理型)
            _my受発注管理 = value
        End Set
    End Property

    Private _my拡張項目 As My拡張項目型
    ''' <summary>
    ''' 拡張項目
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property My拡張項目() As My拡張項目型
        Get
            Return _my拡張項目
        End Get
        Set(ByVal value As My拡張項目型)
            _my拡張項目 = value
        End Set
    End Property

    Private _myＲＥＶ As MyＲＥＶ型             'A-2008/07/18_Ver7.30_GENKA
    ''' <summary>
    ''' ＲＥＶ
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property MyＲＥＶ() As MyＲＥＶ型    'A-2008/07/18_Ver7.30_GENKA
        Get
            Return _myＲＥＶ
        End Get
        Set(ByVal value As MyＲＥＶ型)
            _myＲＥＶ = value
        End Set
    End Property

    Private _my原価管理 As My原価管理型             'A-2008/07/18_Ver7.30_GENKA
    ''' <summary>
    ''' 原価管理
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property My原価管理() As My原価管理型    'A-2008/07/18_Ver7.30_GENKA
        Get
            Return _my原価管理
        End Get
        Set(ByVal value As My原価管理型)
            _my原価管理 = value
        End Set
    End Property

    Private _my支払管理 As My支払管理型             'A-2008/07/18_Ver7.30_SHIHARAI
    ''' <summary>
    ''' 支払管理
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property My支払管理() As My支払管理型    'A-2008/07/18_Ver7.30_SHIHARAI
        Get
            Return _my支払管理
        End Get
        Set(ByVal value As My支払管理型)
            _my支払管理 = value
        End Set
    End Property

    Private _my変更履歴 As My変更履歴型             'A-2009/08/21_RIREKI
    ''' <summary>
    ''' 変更履歴
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property My変更履歴() As My変更履歴型    'A-2009/08/21_RIREKI
        Get
            Return _my変更履歴
        End Get
        Set(ByVal value As My変更履歴型)
            _my変更履歴 = value
        End Set
    End Property

    Private _my商品内訳管理 As My商品内訳管理型             'A-2009/12/18_Ver7.40_UCHIWAKE
    ''' <summary>
    ''' 商品管理拡張
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property My商品内訳管理() As My商品内訳管理型    'A-2009/12/18_Ver7.40_UCHIWAKE
        Get
            Return _my商品内訳管理
        End Get
        Set(ByVal value As My商品内訳管理型)
            _my商品内訳管理 = value
        End Set
    End Property

    Private _myロット管理 As Myロット管理型             'A-2009/12/18_Ver7.40_LOT
    ''' <summary>
    ''' ロット
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property Myロット管理() As Myロット管理型    'A-2009/12/18_Ver7.40_LOT
        Get
            Return _myロット管理
        End Get
        Set(ByVal value As Myロット管理型)
            _myロット管理 = value
        End Set
    End Property

    Private _my端数処理 As My端数処理型             'A-2009/12/18_Ver7.40_LOT
    ''' <summary>
    ''' 端数処理
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property My端数処理() As My端数処理型    'A-2009/12/18_Ver7.40_LOT
        Get
            Return _my端数処理
        End Get
        Set(ByVal value As My端数処理型)
            _my端数処理 = value
        End Set
    End Property

    'A-20121217_Ver7.50_4↓
    Private _my受注在庫引当 As My受注在庫引当型
    ''' <summary>
    ''' 受注在庫引当
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property My受注在庫引当() As My受注在庫引当型
        Get
            Return _my受注在庫引当
        End Get
        Set(ByVal value As My受注在庫引当型)
            _my受注在庫引当 = value
        End Set
    End Property
    'A-20121217_Ver7.50_4↑


    '↓A-20170601-X1-桁数拡張
    Private _my桁数拡張 As My桁数拡張型
    ''' <summary>
    ''' 桁数拡張
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property My桁数拡張() As My桁数拡張型
        Get
            Return _my桁数拡張
        End Get
        Set(ByVal value As My桁数拡張型)
            _my桁数拡張 = value
        End Set
    End Property
    '↑A-20170601-X1-桁数拡張

    Private _my販売財務連動 As My販売財務連動型
    ''' <summary>
    ''' 販売財務連動
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property My販売財務連動() As My販売財務連動型
        Get
            Return _my販売財務連動
        End Get
        Set(ByVal value As My販売財務連動型)
            _my販売財務連動 = value
        End Set
    End Property

    Private _my会計オプション As My会計オプション型             'A-2008/07/18_Ver7.30_SAIMU
    ''' <summary>
    ''' 会計オプション
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property My会計オプション() As My会計オプション型    'A-2008/07/18_Ver7.30_SAIMU
        Get
            Return _my会計オプション
        End Get
        Set(ByVal value As My会計オプション型)
            _my会計オプション = value
        End Set
    End Property

    Private _my会計伝票承認 As My会計伝票承認型             'A-2010/09/13_Ver7.4X_ZAISHONIN
    ''' <summary>
    ''' 会計伝票承認
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property My会計伝票承認() As My会計伝票承認型    'A-2010/09/13_Ver7.4X_ZAISHONIN
        Get
            Return _my会計伝票承認
        End Get
        Set(ByVal value As My会計伝票承認型)
            _my会計伝票承認 = value
        End Set
    End Property

    Private _myMOA初期値 As MyMOA初期値型
    ''' <summary>
    ''' MOA初期値
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property MyMOA初期値() As MyMOA初期値型
        Get
            Return _myMOA初期値
        End Get
        Set(ByVal value As MyMOA初期値型)
            _myMOA初期値 = value
        End Set
    End Property

    Private _myMOAオプション As MyMOAオプション型
    ''' <summary>
    ''' MOAオプション
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property MyMOAオプション() As MyMOAオプション型
        Get
            Return _myMOAオプション
        End Get
        Set(ByVal value As MyMOAオプション型)
            _myMOAオプション = value
        End Set
    End Property

    Private _myMOAロット管理 As MyMOAロット管理型
    ''' <summary>
    ''' MOAロット管理
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property MyMOAロット管理() As MyMOAロット管理型
        Get
            Return _myMOAロット管理
        End Get
        Set(ByVal value As MyMOAロット管理型)
            _myMOAロット管理 = value
        End Set
    End Property

    Private _myMOA機能追加 As MyMOA機能追加型
    ''' <summary>
    ''' MOA機能追加
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property MyMOA機能追加() As MyMOA機能追加型
        Get
            Return _myMOA機能追加
        End Get
        Set(ByVal value As MyMOA機能追加型)
            _myMOA機能追加 = value
        End Set
    End Property

    Private _myMOA受入処理 As MyMOA受入処理型
    ''' <summary>
    ''' MOA受入処理
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property MyMOA受入処理() As MyMOA受入処理型
        Get
            Return _myMOA受入処理
        End Get
        Set(ByVal value As MyMOA受入処理型)
            _myMOA受入処理 = value
        End Set
    End Property
    'A-20110912_1↓
    Private _myMOAＲＥＶ As MyMOAＲＥＶ型
    ''' <summary>
    ''' ＲＥＶ
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property MyMOAＲＥＶ() As MyMOAＲＥＶ型
        Get
            Return _myMOAＲＥＶ
        End Get
        Set(ByVal value As MyMOAＲＥＶ型)
            _myMOAＲＥＶ = value
        End Set
    End Property
    'A-20110912_1↑

    'A-20121217_Ver7.50_1↓
    Private _myMOA外貨管理 As MyMOA外貨管理型
    ''' <summary>
    ''' ＲＥＶ
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property MyMOA外貨管理() As MyMOA外貨管理型
        Get
            Return _myMOA外貨管理
        End Get
        Set(ByVal value As MyMOA外貨管理型)
            _myMOA外貨管理 = value
        End Set
    End Property
    'A-20121217_Ver7.50_1↑

    'A-20121217_Ver7.50_2↓
    Private _myMOA在庫引当 As MyMOA在庫引当型
    ''' <summary>
    ''' ＲＥＶ
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property MyMOA在庫引当() As MyMOA在庫引当型
        Get
            Return _myMOA在庫引当
        End Get
        Set(ByVal value As MyMOA在庫引当型)
            _myMOA在庫引当 = value
        End Set
    End Property
    'A-20121217_Ver7.50_2↑

    'A-20150520_2↓
    Private _myMOA品目別原価 As MyMOA品目別原価型
    ''' <summary>
    ''' MOA機能追加
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property MyMOA品目別原価() As MyMOA品目別原価型
        Get
            Return _myMOA品目別原価
        End Get
        Set(ByVal value As MyMOA品目別原価型)
            _myMOA品目別原価 = value
        End Set
    End Property
    'A-20150520_2↑

    'A-20170417_1↓
    Private _myMOAその他 As MyMOAその他型
    Public Property MyMOAその他() As MyMOAその他型
        Get
            Return _myMOAその他
        End Get
        Set(ByVal value As MyMOAその他型)
            _myMOAその他 = value
        End Set
    End Property
    'A-20170417_1↑

#End Region

    'A-20150520_2↓
#Region "コントロール複合条件"
    Public Enum 条件型 As Integer
        原価管理 = 0
        出庫時原価採用区分
        外貨管理                    'A-20160324_1
        外貨複数伝票消込機能        'A-20160324_1
        外貨管理明細邦貨額積上機能  'A-20160324_1
        品目別原価計算機能          'A-20160324_2
    End Enum

    ''' <summary>
    ''' コントロール情報の複合条件
    ''' </summary>
    ''' <param name="条件">複合条件</param>
    ''' <param name="version">生産強化区分</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function 使用条件(ByVal 条件 As 条件型, Optional ByVal version As Decimal = 0D) As Boolean
        If version <> 0 AndAlso
           Not (_myMOAＲＥＶ.MOA強化区分 >= version) Then
            '生産強化区分が引渡Versionを満たさない場合はFalse
            Return False
        End If

        Select Case 条件
            Case 条件型.原価管理
                If _myMOAオプション.MOA原価管理 = MOAオプション定義型.その他管理区分型.行う Then
                    Return True
                End If
            Case 条件型.出庫時原価採用区分
                If 使用条件(条件型.原価管理) = True AndAlso
                    MyMOA機能追加.品目別原価計算機能 = MOA機能追加定義型.使用有無区分型.使用する AndAlso
                     MyMOA品目別原価.出庫時原価採用区分 = MOA品目別原価定義型.出庫時原価採用区分型.品目別原価を採用する Then
                    Return True
                End If
                'A-20160324_1↓
            Case 条件型.外貨管理
                If MyMOAＲＥＶ.MOA強化区分 >= 4D AndAlso
                   MyMOAオプション.MOA外貨管理 = MOA外貨定義型.制御区分型.行う Then
                    Return True
                End If
            Case 条件型.外貨複数伝票消込機能
                If 使用条件(条件型.外貨管理) = True AndAlso
                   MyMOA外貨管理.外貨複数伝票消込機能 = MOA外貨定義型.制御区分型.行う Then
                    Return True
                End If
            Case 条件型.外貨管理明細邦貨額積上機能
                If 使用条件(条件型.外貨管理) = True AndAlso
                   MyMOA機能追加.外貨管理明細邦貨額積上機能 = MOA機能追加定義型.使用有無区分型.使用する Then
                    Return True
                End If
                'A-20160324_1↑
                'A-20160324_2↓
            Case 条件型.品目別原価計算機能
                If 使用条件(条件型.原価管理) = True AndAlso
                   MyMOA機能追加.品目別原価計算機能 = MOA機能追加定義型.使用有無区分型.使用する Then
                    Return True
                End If
                'A-20160324_2↑
        End Select

        Return False
    End Function
#End Region
    'A-20150520_2↑

End Class
