﻿'A-CUST20190830↓
Public Interface IMasterReader
    Inherits OSK.X1.Foundation.IBase

    Enum テーブル一覧型 As Integer
        発注情報
        入出庫予定情報
        JTB様コントロール
        商品マスター
    End Enum

    Function MasterRead(ByVal targetMaster As テーブル一覧型, ByVal param As ReadParam) As DataTable

End Interface

'A-CUST20190830↑