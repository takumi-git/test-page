﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' アセンブリに関する一般情報は以下の属性セットをとおして制御されます。 
' アセンブリに関連付けられている情報を変更するには、
' これらの属性値を変更してください。

' アセンブリ属性の値を確認します。

<Assembly: AssemblyTitle("受入データ取込")>
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyCompany("株式会社OSK")>
<Assembly: AssemblyProduct("")>
<Assembly: AssemblyCopyright("")>
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)> 

'このプロジェクトが COM に公開される場合、次の GUID がタイプ ライブラリの ID になります。
<Assembly: Guid("47be03b7-0da1-4776-80bc-988516b9772f")> 

' アセンブリのバージョン情報は、以下の 4 つの値で構成されています:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' すべての値を指定するか、下のように '*' を使ってビルドおよびリビジョン番号を 
' 既定値にすることができます:

<Assembly: AssemblyVersion("2.0.0.0")>
<Assembly: AssemblyInformationalVersion("2.0.0.0")>
<Assembly: AssemblyFileVersion("92.0.7523.34174")>
