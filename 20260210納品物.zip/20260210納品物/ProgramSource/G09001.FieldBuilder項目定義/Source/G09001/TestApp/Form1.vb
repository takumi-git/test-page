﻿Public Class Form1

    Private Enum 動作モード
        通常 = 1
        デバッグ
    End Enum

    Private Sub CommandButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CommandButton1.Click

        Dim settingInfo As IDictionary = New Hashtable
        Dim loader As New Loader
        Dim paramInfo As IDictionary = New Hashtable()

        GetSettingInfo(settingInfo, 構成形態型.スタンドアロン)

        loader.Run(settingInfo, paramInfo)

    End Sub

    ''' <summary>
    ''' SettingInfoセット
    ''' </summary>
    ''' <param name="newSettingInfo"></param>
    ''' <param name="構成形態"></param>
    ''' <remarks></remarks>
    Private Sub GetSettingInfo(ByRef newSettingInfo As IDictionary, ByVal 構成形態 As OSK.X1.Foundation.構成形態型)    'X1変換Tool-20160427
        Dim info As SettingInfo = New SettingInfo(newSettingInfo)
        With info
            .会社情報.名称 = "練習会社"
            .データベース情報.接続ID = "CNNORA012"
            .データベース情報.ログ接続ID = .データベース情報.接続ID
            .ログオンユーザー情報.ID = System.Environment.UserName.ToUpper
            .ログオンユーザー情報.ID = "ADMINISTRATOR"
            .コンピュータ情報.名前 = System.Environment.MachineName.ToUpper
            .プログラム情報.ID = "OSK.X1.HAN.G09000"    'X1変換Tool-20160427
            .プログラム情報.実行ID = System.Guid.NewGuid.ToString()
            .プログラム情報.名称 = "拡張項目定義"
            .業務情報.ID = "HAN"
            .業務情報.プログラム固有ID = "HAN"

            .システム構成情報.構成形態 = 構成形態
            .システム構成情報.動作モード = 動作モード型.デバッグ
            .プログラム制御情報.Escキー終了機能 = True
            .プログラム制御情報.処理状況更新間隔 = 1
            .プログラム制御情報.起動ログ出力 = True
            .プログラム制御情報.データ出力ログ出力 = False
            .プログラム制御情報.Escキー終了機能 = True
            .プログラム制御情報.ウィンドウサイズ保存機能 = False
            .プログラム制御情報.索引フリガナ等カナ自動セット = カナ自動セットモード型.機能有効
            .プログラム制御情報.フォント変更 = False
            .プログラム制御情報.会社名表示 = True
        End With

    End Sub

    Private Sub CommandButton2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CommandButton2.Click
        Dim settingInfo As IDictionary = New Hashtable
        Dim initInfo As IDictionary = New Hashtable
        Dim saveInfo As IDictionary = New Hashtable

        GetSettingInfo(settingInfo, 構成形態型.分散)

        Dim brokerInfo As OSK.X1.Foundation.UserInterface.BrokerInfo = New OSK.X1.Foundation.UserInterface.BrokerInfo(settingInfo)    'X1変換Tool-20160427
        brokerInfo.サーバー接続URI = "http://localhost:8181/RemotingBrokerService"
        brokerInfo.プロキシアセンブリ名 = "OSK.X1.Broker.UserInterface"    'X1変換Tool-20160427
        brokerInfo.プロキシクラス名 = "OSK.X1.Broker.UserInterface.RemotingProxyHandler"    'X1変換Tool-20160427

        Dim stateInfo As OSK.X1.Foundation.StateServerInfo = New OSK.X1.Foundation.StateServerInfo(settingInfo)    'X1変換Tool-20160427
        stateInfo.URI = "tcp://localhost:8180/RemotingStateManagerService"

        Dim paramInfo As IDictionary = New Hashtable()

        Dim startupLoader As New OSK.X1.Foundation.ProgramLoad.UserInterface.Loader    'X1変換Tool-20160427
        startupLoader.Run(settingInfo, paramInfo)
    End Sub
End Class
