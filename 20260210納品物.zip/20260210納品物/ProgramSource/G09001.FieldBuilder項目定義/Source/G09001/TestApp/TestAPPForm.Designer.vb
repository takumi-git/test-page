﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class TestAppForm
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cmdSA = New OSK.X1.Foundation.SimpleControl.CommandButton
        Me.cmdRemote = New OSK.X1.Foundation.SimpleControl.CommandButton
        Me.x動作モードGroupBox = New System.Windows.Forms.GroupBox
        Me.x動作モードデバッグ = New System.Windows.Forms.RadioButton
        Me.x動作モード通常 = New System.Windows.Forms.RadioButton
        Me.dbList = New System.Windows.Forms.ComboBox
        Me.cmd終了 = New OSK.X1.Foundation.SimpleControl.CommandButton
        Me.x動作モードGroupBox.SuspendLayout()
        Me.SuspendLayout()
        '
        'cmdSA
        '
        Me.cmdSA.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.cmdSA.FocusBackColor = System.Drawing.Color.Empty
        Me.cmdSA.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.cmdSA.Image = Nothing
        Me.cmdSA.Location = New System.Drawing.Point(17, 119)
        Me.cmdSA.Margin = New System.Windows.Forms.Padding(4)
        Me.cmdSA.Name = "cmdSA"
        Me.cmdSA.NextByEnterKey = False
        Me.cmdSA.RemarkString = Nothing
        Me.cmdSA.Size = New System.Drawing.Size(200, 114)
        Me.cmdSA.TabIndex = 0
        Me.cmdSA.Text = "スタンドアロン"
        Me.cmdSA.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cmdRemote
        '
        Me.cmdRemote.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.cmdRemote.FocusBackColor = System.Drawing.Color.Empty
        Me.cmdRemote.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.cmdRemote.Image = Nothing
        Me.cmdRemote.Location = New System.Drawing.Point(225, 119)
        Me.cmdRemote.Margin = New System.Windows.Forms.Padding(4)
        Me.cmdRemote.Name = "cmdRemote"
        Me.cmdRemote.NextByEnterKey = False
        Me.cmdRemote.RemarkString = Nothing
        Me.cmdRemote.Size = New System.Drawing.Size(200, 114)
        Me.cmdRemote.TabIndex = 1
        Me.cmdRemote.Text = "リモート"
        Me.cmdRemote.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'x動作モードGroupBox
        '
        Me.x動作モードGroupBox.Controls.Add(Me.x動作モードデバッグ)
        Me.x動作モードGroupBox.Controls.Add(Me.x動作モード通常)
        Me.x動作モードGroupBox.Location = New System.Drawing.Point(17, 49)
        Me.x動作モードGroupBox.Margin = New System.Windows.Forms.Padding(4)
        Me.x動作モードGroupBox.Name = "x動作モードGroupBox"
        Me.x動作モードGroupBox.Padding = New System.Windows.Forms.Padding(4)
        Me.x動作モードGroupBox.Size = New System.Drawing.Size(408, 62)
        Me.x動作モードGroupBox.TabIndex = 5
        Me.x動作モードGroupBox.TabStop = False
        Me.x動作モードGroupBox.Text = "動作モード"
        '
        'x動作モードデバッグ
        '
        Me.x動作モードデバッグ.AutoSize = True
        Me.x動作モードデバッグ.Checked = True
        Me.x動作モードデバッグ.Location = New System.Drawing.Point(135, 27)
        Me.x動作モードデバッグ.Margin = New System.Windows.Forms.Padding(4)
        Me.x動作モードデバッグ.Name = "x動作モードデバッグ"
        Me.x動作モードデバッグ.Size = New System.Drawing.Size(90, 20)
        Me.x動作モードデバッグ.TabIndex = 1
        Me.x動作モードデバッグ.TabStop = True
        Me.x動作モードデバッグ.Text = "デバッグ"
        Me.x動作モードデバッグ.UseVisualStyleBackColor = True
        '
        'x動作モード通常
        '
        Me.x動作モード通常.AutoSize = True
        Me.x動作モード通常.Location = New System.Drawing.Point(22, 27)
        Me.x動作モード通常.Margin = New System.Windows.Forms.Padding(4)
        Me.x動作モード通常.Name = "x動作モード通常"
        Me.x動作モード通常.Size = New System.Drawing.Size(58, 20)
        Me.x動作モード通常.TabIndex = 0
        Me.x動作モード通常.Text = "通常"
        Me.x動作モード通常.UseVisualStyleBackColor = True
        '
        'dbList
        '
        Me.dbList.FormattingEnabled = True
        Me.dbList.Location = New System.Drawing.Point(17, 17)
        Me.dbList.Margin = New System.Windows.Forms.Padding(4)
        Me.dbList.Name = "dbList"
        Me.dbList.Size = New System.Drawing.Size(408, 24)
        Me.dbList.TabIndex = 6
        '
        'cmd終了
        '
        Me.cmd終了.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.cmd終了.FocusBackColor = System.Drawing.Color.Empty
        Me.cmd終了.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.cmd終了.Image = Nothing
        Me.cmd終了.Location = New System.Drawing.Point(17, 241)
        Me.cmd終了.Margin = New System.Windows.Forms.Padding(4)
        Me.cmd終了.Name = "cmd終了"
        Me.cmd終了.NextByEnterKey = False
        Me.cmd終了.RemarkString = Nothing
        Me.cmd終了.Size = New System.Drawing.Size(408, 114)
        Me.cmd終了.TabIndex = 7
        Me.cmd終了.Text = "終了"
        Me.cmd終了.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TestAppForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(444, 371)
        Me.Controls.Add(Me.cmd終了)
        Me.Controls.Add(Me.dbList)
        Me.Controls.Add(Me.x動作モードGroupBox)
        Me.Controls.Add(Me.cmdRemote)
        Me.Controls.Add(Me.cmdSA)
        Me.Font = New System.Drawing.Font("ＭＳ ゴシック", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "TestAppForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "TestAppForm"
        Me.x動作モードGroupBox.ResumeLayout(False)
        Me.x動作モードGroupBox.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents cmdSA As OSK.X1.Foundation.SimpleControl.CommandButton
    Friend WithEvents cmdRemote As OSK.X1.Foundation.SimpleControl.CommandButton
    Friend WithEvents x動作モードGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents x動作モードデバッグ As System.Windows.Forms.RadioButton
    Friend WithEvents x動作モード通常 As System.Windows.Forms.RadioButton
    Friend WithEvents dbList As System.Windows.Forms.ComboBox
    Friend WithEvents cmd終了 As OSK.X1.Foundation.SimpleControl.CommandButton
End Class
