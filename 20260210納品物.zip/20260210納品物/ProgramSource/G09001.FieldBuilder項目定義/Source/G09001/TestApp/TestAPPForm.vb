﻿Public Class TestAppForm

#Region "起動時処理"

    Private Sub TestAppForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call SetupDBInfoList(dbList)
        Dim i As Integer = dbList.Items.IndexOf(("dbinfo." & GetAppSetting("DefaultDBInfo") & ".xml"))
        If i = -1 Then i = 0
        dbList.SelectedIndex = i
    End Sub

    Private Sub SetupDBInfoList(ByRef target As ComboBox)
        Dim list As New List(Of String)
        Dim folders As New IO.DirectoryInfo(GetAppSetting("アプリケーション設定データパス"))
        Try
            For Each fileInfo As IO.FileInfo In folders.GetFiles
                If fileInfo.Name.ToUpper Like "DBINFO.*.XML" Then
                    Select Case True
                        Case fileInfo.Name.ToUpper = "DBINFO.SYSTEM.XML"
                        Case fileInfo.Name.ToUpper Like "*SAMPLE*"
                        Case Else
                            list.Add(fileInfo.Name)
                    End Select
                End If
            Next
        Catch ex As Exception
            MessageBox.Show(ex.Message)
            Return
        End Try
        If list.Count = 0 Then Return
        target.Items.Clear()
        list.Sort()
        For i As Integer = 0 To list.Count - 1
            target.Items.Add(list(i))
        Next
        target.SelectedIndex = 0
    End Sub

#End Region

#Region "スタンドアロン実行"

    Private Sub cmdSA_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdSA.Click
        If dbList.Text = "" Then
            dbList.Focus()
            Exit Sub
        End If

        Dim settingInfo As IDictionary = New Hashtable()
        Call SetupSettingInfo(settingInfo, 構成形態型.スタンドアロン)

        Dim target As New OSK.X1.Foundation.ProgramLoad.UserInterface.Loader    'X1変換Tool-20160518
        Dim paramInfo As IDictionary = New Hashtable
        target.Run(settingInfo, paramInfo)
    End Sub

#End Region

#Region "分散実行"

    Private Sub cmdRemote_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRemote.Click
        If dbList.Text = "" Then
            dbList.Focus()
            Exit Sub
        End If

        Dim settingInfo As IDictionary = New Hashtable()
        Call SetupSettingInfo(settingInfo, 構成形態型.分散)

        Dim brokerInfo As OSK.X1.Foundation.UserInterface.BrokerInfo = New OSK.X1.Foundation.UserInterface.BrokerInfo(settingInfo)    'X1変換Tool-20160518
        brokerInfo.サーバー接続URI = "http://localhost:8181/RemotingBrokerService"
        brokerInfo.プロキシアセンブリ名 = "OSK.X1.Broker.UserInterface"    'X1変換Tool-20160518
        brokerInfo.プロキシクラス名 = "OSK.X1.Broker.UserInterface.RemotingProxyHandler"    'X1変換Tool-20160518

        Dim stateInfo As OSK.X1.Foundation.StateServerInfo = New OSK.X1.Foundation.StateServerInfo(settingInfo)    'X1変換Tool-20160518
        stateInfo.URI = "tcp://localhost:8180/RemotingStateManagerService"

        Dim target As New OSK.X1.Foundation.ProgramLoad.UserInterface.Loader    'X1変換Tool-20160518
        Dim paramInfo As IDictionary = New Hashtable
        target.Run(settingInfo, paramInfo)
    End Sub

#End Region

#Region "終了"

    Private Sub cmd終了_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmd終了.Click
        Me.Close()
    End Sub

#End Region

#Region "helper method"

    Private Sub SetupSettingInfo(ByRef newSettingInfo As IDictionary, ByVal 構成形態 As OSK.X1.Foundation.構成形態型)    'X1変換Tool-20160518
        Dim settingInfo As SettingInfo = New SettingInfo(newSettingInfo)
        With settingInfo
            .システム構成情報.構成形態 = 構成形態
            If x動作モード通常.Checked = True Then
                .システム構成情報.動作モード = 動作モード型.通常
            Else
                .システム構成情報.動作モード = 動作モード型.デバッグ
            End If
            .会社情報.名称 = GetAppSetting("会社情報.名称")
            .データベース情報.接続ID = GetDBInfo()
            .データベース情報.ログ接続ID = GetDBInfo()
            .業務情報.ID = GetAppSetting("業務情報.ID")
            .業務情報.プログラム固有ID = GetAppSetting("業務情報.プログラム固有ID")
            If .業務情報.プログラム固有ID.Length = 0 Then
                .業務情報.プログラム固有ID = .業務情報.ID
            End If
            .プログラム情報.実行ID = GetAppSetting("プログラム情報.実行ID")
            .プログラム情報.オリジナルID = "OSK.X1." & .プログラム情報.実行ID       '色情報はこの情報を使用して取得する    'X1変換Tool-20160518
            .プログラム情報.オリジナル名称 = GetAppSetting("プログラム情報.名称")
            .プログラム情報.ID = .プログラム情報.オリジナルID
            .プログラム情報.枝番 = CType(Val(GetAppSetting("プログラム情報.枝番")), Integer)
            .プログラム情報.名称 = .プログラム情報.オリジナル名称
            .コンピュータ情報.名前 = My.Computer.Name
            '.ログオンユーザー情報.ID = My.User.Name.Replace(My.Computer.Name & "\", "").ToUpper
            '.コンピュータ情報.名前 = System.Environment.MachineName.ToUpper
            '.ログオンユーザー情報.ID = System.Environment.UserName.ToUpper
            .ログオンユーザー情報.ID = "ADMINISTRATOR"
            .ログオンユーザー情報.フルネーム = .プログラム情報.名称 & ".TestApp"
            .プログラム制御情報.Escキー終了機能 = CType(GetAppSetting("プログラム制御情報.Escキー終了機能"), Boolean)
            .プログラム制御情報.会社名表示 = CType(GetAppSetting("プログラム制御情報.会社名表示"), Boolean)
            .プログラム制御情報.起動ログ出力 = CType(GetAppSetting("プログラム制御情報.起動ログ出力"), Boolean)
            .プログラム制御情報.データ出力ログ出力 = CType(GetAppSetting("プログラム制御情報.データ出力ログ出力"), Boolean)
            .プログラム制御情報.処理状況更新間隔 = CType(Val(GetAppSetting("プログラム制御情報.処理状況更新間隔")), Integer)
        End With
    End Sub

    ''' <summary>
    ''' app.config から appSetting を取得
    ''' </summary>
    ''' <param name="key"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetAppSetting(ByVal key As String) As String
        Dim result As String = CType(System.Configuration.ConfigurationManager.AppSettings(key), String)
        If result Is Nothing Then
            result = ""
        End If
        Return result
    End Function

    Private Function GetDBInfo() As String
        Dim dbinfo As String = dbList.Text
        dbinfo = dbinfo.Replace("dbinfo.", "")
        dbinfo = dbinfo.Replace(".xml", "")
        Return dbinfo
    End Function

#End Region

End Class
