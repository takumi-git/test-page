﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.CommandButton1 = New OSK.X1.Foundation.SimpleControl.CommandButton
        Me.CommandButton2 = New OSK.X1.Foundation.SimpleControl.CommandButton
        Me.SuspendLayout()
        '
        'CommandButton1
        '
        Me.CommandButton1.BackColor = System.Drawing.Color.Transparent
        Me.CommandButton1.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.CommandButton1.FocusBackColor = System.Drawing.Color.Empty
        Me.CommandButton1.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.CommandButton1.Image = Nothing
        Me.CommandButton1.Location = New System.Drawing.Point(12, 12)
        Me.CommandButton1.Name = "CommandButton1"
        Me.CommandButton1.NextByEnterKey = False
        Me.CommandButton1.RemarkString = Nothing
        Me.CommandButton1.Size = New System.Drawing.Size(194, 72)
        Me.CommandButton1.TabIndex = 0
        Me.CommandButton1.Text = "拡張項目定義(SA)"
        Me.CommandButton1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'CommandButton2
        '
        Me.CommandButton2.BackColor = System.Drawing.Color.Transparent
        Me.CommandButton2.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.CommandButton2.FocusBackColor = System.Drawing.Color.Empty
        Me.CommandButton2.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.CommandButton2.Image = Nothing
        Me.CommandButton2.Location = New System.Drawing.Point(12, 90)
        Me.CommandButton2.Name = "CommandButton2"
        Me.CommandButton2.NextByEnterKey = False
        Me.CommandButton2.RemarkString = Nothing
        Me.CommandButton2.Size = New System.Drawing.Size(194, 61)
        Me.CommandButton2.TabIndex = 0
        Me.CommandButton2.Text = "拡張項目定義(分散)"
        Me.CommandButton2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(219, 176)
        Me.Controls.Add(Me.CommandButton2)
        Me.Controls.Add(Me.CommandButton1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents CommandButton1 As OSK.X1.Foundation.SimpleControl.CommandButton
    Friend WithEvents CommandButton2 As OSK.X1.Foundation.SimpleControl.CommandButton

End Class
