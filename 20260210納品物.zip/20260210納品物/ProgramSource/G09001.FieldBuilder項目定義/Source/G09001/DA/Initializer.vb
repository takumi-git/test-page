﻿Public Class Initializer
    Inherits InitializerBase

    ''' <summary>
    ''' 初期処理を行なう
    ''' </summary>
    ''' <param name="connection">接続文字列</param>
    ''' <param name="initInfo">UI個別情報</param>
    ''' <param name="resultMessage">結果メッセージ</param>
    ''' <param name="checkInfo">排他情報</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Overrides Function Startup(ByVal connection As System.Data.Common.DbConnection, ByRef initInfo As System.Collections.IDictionary, ByRef resultMessage As String, ByRef checkInfo As X1.Foundation.ExecuteCheck.IExecuteCheckInfo) As X1.Foundation.Startup.IStarter.AccessResultType    'X1変換Tool-20160427

        '排他制御部品起動時チェック
        Dim chkExecuteControl As IExecuteControlerForStartup
        chkExecuteControl = CommonFactory.CreateInstance(Of IExecuteControlerForStartup)(Me, GetType(ExecuteControlerForStartup))
        chkExecuteControl.Initialize(Me)
        'If chkExecuteControl.CheckExecution(checkInfo, CheckCondition.異常終了チェック無し) = ExecuteCheckResult.排他エラー Then   'D-20080416_1
        If chkExecuteControl.CheckExecution(checkInfo, CheckCondition.通常チェック) = ExecuteCheckResult.排他エラー Then            'A-20080416_1
            Return IStarter.AccessResultType.同時実行不可
        End If

        '<<コントロール情報の取得>>
        Dim controlInfo As IHANControlReader
        controlInfo = CommonFactory.CreateInstance(Of IHANControlReader)(Me, GetType(HANControlReader))
        controlInfo.Initialize(Me)
        controlInfo.GetControlInfo(connection, initInfo, IHANControlReader.コントロール型.HANコントロールテーブル)

        'A-20101014_1{
        '<<基準コントロール情報の取得>>
        Dim BIScontrolInfo As IBISControlReader
        BIScontrolInfo = CommonFactory.CreateInstance(Of IBISControlReader)(Me, GetType(BISControlReader))
        BIScontrolInfo.Initialize(Me)
        BIScontrolInfo.GetControlInfo(connection, initInfo, IBISControlReader.コントロール型.BISコントロールテーブル)

        Dim myコントロール情報_基準 As New Myコントロール情報型_基準
        myコントロール情報_基準.Initialize(initInfo, Me)

        If myコントロール情報_基準.販売財務連動区分 = BIS.LIB.ControlInfoC001.販売財務連動定義型.販売財務連動区分型.行う Then
            StartupExtracted(connection, initInfo)
        End If
        'A-20101014_1}

        '個別情報取得の初期処理
        Dim result As Boolean
        Dim eachSettingsReader As IEachReader
        eachSettingsReader = CommonFactory.CreateInstance(Of IEachReader)(Me, GetType(EachReader))
        eachSettingsReader.Initialize(Me)
        result = eachSettingsReader.ReadEnterキー移動方向(connection, initInfo)
        result = eachSettingsReader.Readマスター保守左右矢印(connection, initInfo)

        '<<項目名情報>>
        Dim itemNameinfoReader As IItemNameReader
        itemNameinfoReader = CommonFactory.CreateInstance(Of IItemNameReader)(Me, GetType(ItemNameReader))
        itemNameinfoReader.Initialize(Me)
        itemNameinfoReader.GetItemNameInfo(connection, initInfo)

        '<<空のデータテーブル情報取得>>
        initInfo.Add("プログラム専用.属性情報のデータテーブル", GetZokuseiDataTableSchema)

        Return IStarter.AccessResultType.成功
    End Function

#Region "内部メソッド"

    ''' <summary>
    ''' InputManager用空のデータテーブル情報取得(下のグリッドにある属性情報)
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetZokuseiDataTableSchema() As DataTable
        Dim readParam As IReadParam = Nothing
        readParam = New ReadParam
        readParam.取得区分 = IReadParam.取得区分型.属性情報テーブル取得
        readParam.データ種類 = 99
        readParam.明細区分 = 0

        Dim readParamInfo As IDictionary(Of IReadParam.取得区分型, IReadParam) = New Dictionary(Of IReadParam.取得区分型, IReadParam)
        readParamInfo.Add(IReadParam.取得区分型.属性情報テーブル取得, readParam)

        Dim DataAccess As IDataReader
        Dim exDA As Exception = Nothing
        DataAccess = New DataReader
        DataAccess.Initialize(SettingInfo)
        Dim table As IDictionary(Of IReadParam.取得区分型, DataTable) = New Dictionary(Of IReadParam.取得区分型, DataTable)
        table = DataAccess.GetData(SettingInfo, readParamInfo, exDA)
        Return table(IReadParam.取得区分型.属性情報テーブル取得)
    End Function

#End Region

    'A-20101014_1{
#Region "財務コントロール情報取得"
    Private Sub StartupExtracted(ByVal connection As System.Data.Common.DbConnection, ByRef initInfo As System.Collections.IDictionary)
        '<<財務コントロール情報の取得>>
        Dim rendoInitializer As IRendoInitializer

        rendoInitializer = OSK.X1.Foundation.GeneralFactory(Of IRendoInitializer).CreateInstance(Me, "OSK.X1.OTS.G09001.SUB1.DA", "RendoInitializer")    'X1変換Tool-20160427
        rendoInitializer.Initialize(Me)
        rendoInitializer.Startup(connection, initInfo)
    End Sub
#End Region
    'A-20101014_1}
End Class

