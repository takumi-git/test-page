﻿Public Class MasterSelector
    Inherits DataHandlerBase
    Implements IMasterSelector

#Region "列挙型"
    Enum パラメータ型 As Integer
        参照定義コード = 0
        データ種類
        明細区分
    End Enum
#End Region

#Region "公開メソッド"

    ''' <summary>
    ''' マスター名称取得
    ''' </summary>
    ''' <param name="getDataValue">取得名称</param>
    ''' <param name="targetMaster">対象マスター</param>
    ''' <param name="コード">対象コード</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetName(ByVal settingInfo As IDictionary, ByRef getDataValue() As String, ByVal targetMaster As IMasterSelector.マスター区分型, _
                            ByVal ParamArray コード() As String) As Boolean Implements IMasterSelector.GetName

        SetUpDAC()

        getDataValue = Nothing

        Dim hasrow As Boolean = False

        Using connection As DbConnection = OpenConnection()

            Dim SQL As String = ""
            Dim parameter As ParamInfoList = New ParamInfoList
            Dim dataReader As DbDataReader
            Dim command As DbCommand = Nothing

            MakeSQL(targetMaster, コード, SQL, parameter)

            dataReader = DataAccess.GetDataReader(connection, SQL, parameter, hasrow, command)

            If hasrow = True Then
                getDataValue = New String(dataReader.FieldCount - 1) {}
                For i As Integer = 0 To dataReader.FieldCount - 1
                    getDataValue(i) = dataReader.Item(i).ToString
                Next
            End If

            DataAccess.CancelCommand(command)
            DataAccess.CloseReader(dataReader)
            CloseConnection(connection)
        End Using
        Return hasrow
    End Function

    ''' <summary>
    ''' 拡張項目画面設定のデータを取得
    ''' </summary>
    ''' <remarks></remarks>
    Public Function GetSetteiList(ByVal settingInfo As IDictionary, ByRef getDataValue As DataTable, ByVal targetMaster As IMasterSelector.マスター区分型,
                            ByVal ParamArray コード() As String) As Boolean Implements IMasterSelector.GetSetteiList

        SetUpDAC()
        getDataValue = Nothing

        Using connection As DbConnection = OpenConnection()
            Try
                Dim SQL As String = ""
                Dim parameter As ParamInfoList = New ParamInfoList

                MakeSQL(targetMaster, コード, SQL, parameter)

                getDataValue = DataAccess.GetDataTable(connection, SQL, parameter)

            Catch ex As Exception
                Throw
            Finally
                CloseConnection(connection)
            End Try
        End Using

        If getDataValue Is Nothing OrElse getDataValue.Rows.Count = 0 Then Return False

        Return True
    End Function

    ''' <summary>
    ''' 拡張項目画面設定のデータを取得
    ''' </summary>
    ''' <remarks></remarks>
    Public Function GetDatatype(ByVal settingInfo As IDictionary, ByRef getDataValue As DataTable, ByVal targetMaster As IMasterSelector.マスター区分型) As Boolean Implements IMasterSelector.GetDatatype

        SetUpDAC()
        getDataValue = Nothing

        Using connection As DbConnection = OpenConnection()
            Try
                Dim SQL As String = ""
                Dim parameter As ParamInfoList = New ParamInfoList
                Dim コード() As String = {"", "", ""}
                MakeSQL(targetMaster, コード, SQL, parameter)

                getDataValue = DataAccess.GetDataTable(connection, SQL, parameter)

            Catch ex As Exception
                Throw
            Finally
                CloseConnection(connection)
            End Try
        End Using

        If getDataValue Is Nothing OrElse getDataValue.Rows.Count = 0 Then Return False

        Return True
    End Function
#End Region

#Region "内部メソッド"

#Region "SQL作成"

    Private Sub MakeSQL(ByVal targetMaster As IMasterSelector.マスター区分型, ByVal targetValue() As String, _
                        ByRef SQL As String, ByRef paramInfo As ParamInfoList)
        Select Case targetMaster
            Case IMasterSelector.マスター区分型.参照定義
                MakeSQL_参照定義(targetValue, SQL, paramInfo)
            Case IMasterSelector.マスター区分型.画面設定
                MakeSQL_画面設定(targetValue, SQL, paramInfo)
            Case IMasterSelector.マスター区分型.データ種類
                MakeSQL_データ種類(SQL, paramInfo)
        End Select
    End Sub

    Private Sub MakeSQL_参照定義(ByVal targetValue() As String, ByRef SQL As String, ByRef paramInfo As ParamInfoList)
        SQL = ""
        SQL &= " SELECT "
        SQL &= " HANZ032003, HANZ032004, HANZ032002, HANZ032999 "
        SQL &= " FROM " & Me.ExchangeTableName("HAN10Z032SANSHOT") & QueryWrapper.AddNoLock()    'X1変換Tool-20160427
        SQL &= " WHERE HANZ032001 = " & AddParameter(パラメータ型.参照定義コード, targetValue, paramInfo)
        SQL &= QueryWrapper.AddUR
    End Sub

    Private Sub MakeSQL_画面設定(ByVal targetValue() As String, ByRef SQL As String, ByRef paramInfo As ParamInfoList)

        SQL = ""
        SQL &= " SELECT "
        SQL &= QueryWrapper.AddIsNull
        SQL &= "(HANZ033005, 0) HANZ033005,"         '配置項目(売上)
        SQL &= QueryWrapper.AddIsNull
        SQL &= "(HANZ033006, 0) HANZ033006 "         '配置項目(仕入)
        SQL &= " FROM " & Me.ExchangeTableName("HAN10Z033GAMENSET") & " " & Me.QueryWrapper.AddNoLock    'X1変換Tool-20160427
        SQL &= " WHERE HANZ033002  = " & AddParameter(パラメータ型.明細区分, targetValue, paramInfo)
        If Val(targetValue(0).ToString) = 1 Then
            SQL &= "   AND HANZ033001  = " & AddParameter(パラメータ型.データ種類, targetValue, paramInfo)
        End If
        SQL &= " ORDER BY HANZ033003, HANZ033004 "
        SQL &= QueryWrapper.AddUR()
    End Sub

    Private Sub MakeSQL_データ種類(ByRef SQL As String, ByRef paramInfo As ParamInfoList)

        SQL = ""
        SQL &= " SELECT "
        SQL &= QueryWrapper.AddIsNull
        SQL &= "(CUSCE03002, '') CUSCE03002,"         '区分
        SQL &= QueryWrapper.AddIsNull
        SQL &= "(CUSCE03003, '') CUSCE03003, "         '区分名
        SQL &= QueryWrapper.AddIsNull
        SQL &= "(CUSCE03004,'') CUSCE03004 "          '区分略称
        SQL &= " FROM " & Me.ExchangeTableName("CUS98CE03KUBUN") & " " & Me.QueryWrapper.AddNoLock
        SQL &= " INNER JOIN " & Me.ExchangeTableName("CUS98CE02KUBUNSHUBETSU") & " " & Me.QueryWrapper.AddNoLock
        SQL &= " ON CUSCE03001 = CUSCE02001 "
        SQL &= " WHERE CUSCE03001  = '0001' " 'TODO 区分種別のマスターによるのでQAだしする。

        SQL &= " ORDER BY CUSCE03002"
        SQL &= QueryWrapper.AddUR()
    End Sub

#End Region

#Region "パラメータ"
    Private Const _parameterMaker As String = " ? "

    Private Function AddParameter(ByVal paramType As パラメータ型, _
                                  ByVal targetValue() As String, _
                                  ByRef parameter As ParamInfoList) As String

        Dim newParam As ParamInfo = New ParamInfo
        Select Case paramType
            Case パラメータ型.参照定義コード
                With newParam
                    .Name = "HANM032001"
                    .Type = DbType.AnsiStringFixedLength
                    .Size = 4
                    .Value = targetValue(0)
                End With
            Case パラメータ型.データ種類
                With newParam
                    .Name = "HANZ033001"
                    .Type = DbType.Decimal
                    .Precision = 2
                    .Scale = 0
                    .Value = "1"
                End With
            Case パラメータ型.明細区分
                With newParam
                    .Name = "HANZ033002"
                    .Type = DbType.Decimal
                    .Precision = 1
                    .Scale = 0
                    .Value = targetValue(1)
                End With
        End Select
        parameter.Add(newParam)

        Return _parameterMaker
    End Function

#End Region

#End Region

End Class
