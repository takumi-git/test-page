﻿''' <summary>
''' 基準コントロール情報取得クラス(DA)
''' </summary>
''' <remarks>※20101014_1で追加※</remarks>
Public Class Myコントロール情報型_基準

    Private _販売財務連動区分型 As BIS.LIB.ControlInfoC001.販売財務連動型



#Region "コンストラクタ"

    Sub New()
        _販売財務連動区分型 = New BIS.LIB.ControlInfoC001.販売財務連動型

    End Sub

#End Region

#Region "メソッド"

    Public Sub Initialize(ByVal initInfo As IDictionary, ByVal creater As IBase)

        Dim BIScontrolGetter As BIS.LIB.ControlInfo.DataAccess.IBISControlInfoGetter
        BIScontrolGetter = CommonFactory.CreateInstance(Of BIS.LIB.ControlInfo.DataAccess.IBISControlInfoGetter)(creater, GetType(BIS.LIB.ControlInfo.DataAccess.BISControlInfoGetter))
        Dim BIScontrolInfoC001 As IDictionary
        BIScontrolInfoC001 = BIScontrolGetter.GetControlInfo(initInfo, BIS.LIB.ControlInfo.DataAccess.IBISControlInfoGetter.コントロール型.BISコントロールテーブル)

        _販売財務連動区分型.Initialize(BIScontrolInfoC001)

    End Sub

#End Region

#Region "プロパティ"

    Public ReadOnly Property 販売財務連動区分() As BIS.LIB.ControlInfoC001.販売財務連動定義型.販売財務連動区分型
        Get
            Return _販売財務連動区分型.販売財務連動区分
        End Get
    End Property

#End Region

End Class
