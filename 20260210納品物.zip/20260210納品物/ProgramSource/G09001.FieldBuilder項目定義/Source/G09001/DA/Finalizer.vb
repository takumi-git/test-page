﻿Public Class Finalizer
    Inherits FinalizerBase

    Private 設定名() As String = {"左右矢印", "Enterキー移動方向"}

    Public Overrides Sub Shutdown(ByVal connection As DbConnection, ByVal transaction As DbTransaction, ByRef saveInfo As IDictionary)

        Dim eachSettingUpdater As OSK.X1.CMN.LIB.EachSettings.IUpdater    'X1変換Tool-20160427
        eachSettingUpdater = CommonFactory.CreateInstance(Of IUpdater)(Me, GetType(Updater))
        eachSettingUpdater.Initialize(Me)

        eachSettingUpdater.分類名 = "マスター保守"

        eachSettingUpdater.業務区分 = Me.システム環境情報.業務情報.ID
        eachSettingUpdater.プログラムID = Me.システム環境情報.プログラム情報.ID
        eachSettingUpdater.プログラムID枝番 = Me.システム環境情報.プログラム情報.枝番
        eachSettingUpdater.ログインID = Me.システム環境情報.ログオンユーザー情報.ID
        eachSettingUpdater.コンピュータ名 = ""
        eachSettingUpdater.内容値 = ""

        Try
            For i As Integer = 0 To 設定名.Length - 1
                If saveInfo.Contains(設定名(i)) = True Then
                    eachSettingUpdater.設定名 = 設定名(i)
                    eachSettingUpdater.内容値 = CType(saveInfo.Item(設定名(i)), String)
                    eachSettingUpdater.UpdateData(transaction)
                End If
            Next
        Catch ex As Exception
            Throw
        End Try

    End Sub

End Class
