﻿Imports System.Xml
Imports System.Text
Imports System.IO
Imports System.Collections.Generic
Imports System.Text.RegularExpressions

Public Class XmlFileWriter

    '拡張項目情報：XMLに出す5項目＋ファイル名用（データ種類／明細区分）
    Public Structure ExtItemInfo
        Public タイトル As String
        Public 属性 As String
        Public 列名 As String
        Public 桁数 As String
        Public 小数 As String
        Public データ種類 As Integer
        Public データ種類略称 As String
        Public 明細区分 As Integer ' 1:ヘッダー, 2:明細
    End Structure

    '属性=7 のときに追加するサンプル定義（現状は固定値）
    Private Const SAMPLE_CODE_SEARCH_ID As String = "OSK.X1.CUS.X10070"
    Private Const SAMPLE_CODE_SEARCH_EDA As String = "98340005"
    Private Const SAMPLE_CODE_SEARCH_UKETORI_KEY As String = "汎用名称コード"



    Private Const SAMPLE_MASTER_SQL As String =
        "SELECT" & vbCrLf &
        "ISNULL(CUSME34003,N' ') CUSME34003 " & vbCrLf &
        "FROM CUS98ME34GENERICNAME WITH(NOLOCK)" & vbCrLf &
        "WHERE CUSME34001 = '0001' " & vbCrLf &
        "AND CUSME34002 = @K1 " & vbCrLf

    Private Const SAMPLE_MASTER_HANEI As String = "@K1"

    '<取得データ> / <反映先> のテキスト整形用（開閉タグのインデント：10スペース）
    Private Const SAMPLE_BLOCK_TAG_INDENT As String = "          "

    '計算式サンプル（先頭2枠が計算式、3枠目が出力）
    Private Const SAMPLE_CALC_EXPR As String = "RTRIM(@K3) + RTRIM(@K4)"
    Private Const SAMPLE_CALC_TARGET As String = "@K5"

    ''' <summary>
    ''' 拡張項目情報を「データ種類×明細区分」ごとに1ファイルへ出力／更新します。
    ''' ・既存ファイルがあれば該当要素だけ部分更新（ユーザー手入力属性は保持）
    ''' ・XML宣言：UTF-8（BOMあり）／CRLF
    ''' ・拡張設定の「項目数」は既定：実在件数
    ''' ・属性3～6の項目は PARM1 デフォルト='0' を必ず更新（存在しなければ追加）
    ''' ・それ以外の属性の項目は PARM1 を更新しない（存在しなければ '' で追加）
    ''' ・属性の並びは「タイトル→属性→列名→桁数→小数→その他」に統一
    ''' ・属性=7 のとき、親要素サンプル属性＋サンプル子要素（コード検索/保守/マスター取得）を新規作成時のみ追加
    ''' ・新規作成時のみ、属性=0（未使用）の先頭3枠に「計算式サンプル（2枠＋出力1枠）」を投入
    ''' </summary>
    Public Sub WriteOrUpdateGrouped(ByVal folderPath As String,
                                   ByVal items() As ExtItemInfo,
                                   Optional ByVal patternWidth As String = "740")

        ' 入力チェック
        If String.IsNullOrEmpty(folderPath) Then Throw New ArgumentException("folderPath が空です。")
        If Not Directory.Exists(folderPath) Then Throw New DirectoryNotFoundException("指定フォルダが存在しません: " & folderPath)
        If items Is Nothing OrElse items.Length = 0 Then Throw New ArgumentException("items が空です。")

        ' XML Writer 設定（宣言は手書きで UTF-8 を大文字にする）
        Dim settings As XmlWriterSettings = New XmlWriterSettings()
        settings.Encoding = New UTF8Encoding(True) ' BOMあり
        settings.Indent = True
        settings.IndentChars = "  " ' 2スペース
        settings.NewLineChars = vbCrLf ' CRLF
        settings.OmitXmlDeclaration = True ' 宣言は自前で書く

        ' 1) 空項目を除外（5項目がすべて空ならスキップ）
        Dim valid As New List(Of ExtItemInfo)()
        Dim i As Integer
        For i = 0 To items.Length - 1
            Dim d As ExtItemInfo = items(i)
            If Not IsEmptyExtItem(d) Then valid.Add(d)
        Next
        If valid.Count = 0 Then Exit Sub

        ' 2) データ種類×明細区分でグループ化
        Dim groups As New Dictionary(Of String, List(Of ExtItemInfo))()
        For i = 0 To valid.Count - 1
            Dim d As ExtItemInfo = valid(i)
            Dim key As String = d.データ種類.ToString() & "_" & d.明細区分.ToString()
            If Not groups.ContainsKey(key) Then groups(key) = New List(Of ExtItemInfo)()
            groups(key).Add(d)
        Next

        ' 3) 各グループを1ファイルへ（既存があれば部分更新）
        For Each kv As KeyValuePair(Of String, List(Of ExtItemInfo)) In groups
            Dim list As List(Of ExtItemInfo) = kv.Value
            If list.Count = 0 Then Continue For

            Dim filename As String = BuildFileName(list(0))
            Dim path As String = System.IO.Path.Combine(folderPath, filename)

            Dim isNewFile As Boolean = Not File.Exists(path)

            ' ドキュメント準備：既存があれば読み込み、なければ骨組み作成
            Dim doc As XmlDocument = New XmlDocument()
            doc.PreserveWhitespace = False ' 整形出力（CRLF＋インデント）

            If Not isNewFile Then
                Using fs As New FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read)
                    doc.Load(fs)
                End Using
            Else
                Dim decl As XmlDeclaration = doc.CreateXmlDeclaration("1.0", "UTF-8", Nothing)
                doc.AppendChild(decl)

                Dim root As XmlElement = doc.CreateElement("汎用サブ画面")
                doc.AppendChild(root)

                Dim prog As XmlElement = doc.CreateElement("プログラム情報")
                Dim pname As XmlElement = doc.CreateElement("プログラム名")
                pname.InnerText = BuildProgramName(list(0))
                prog.AppendChild(pname)
                root.AppendChild(prog)

                Dim pat As XmlElement = doc.CreateElement("パターン情報")
                pat.SetAttribute("横幅", patternWidth)
                root.AppendChild(pat)

                Dim ext As XmlElement = doc.CreateElement("設定")
                ext.SetAttribute("項目数", "0")
                pat.AppendChild(ext)
            End If

            ' 必須ノードの補完（既存を壊さず追加のみ）
            Dim rootNode As XmlElement = TryCast(doc.SelectSingleNode("/汎用サブ画面"), XmlElement)
            If rootNode Is Nothing Then
                rootNode = doc.CreateElement("汎用サブ画面")
                doc.AppendChild(rootNode)
            End If

            Dim patNode As XmlElement = TryCast(doc.SelectSingleNode("/汎用サブ画面/パターン情報"), XmlElement)
            If patNode Is Nothing Then
                patNode = doc.CreateElement("パターン情報")
                patNode.SetAttribute("横幅", patternWidth)
                rootNode.AppendChild(patNode)
            Else
                If String.IsNullOrEmpty(patNode.GetAttribute("横幅")) Then
                    patNode.SetAttribute("横幅", patternWidth)
                End If
            End If

            Dim extNode As XmlElement = TryCast(doc.SelectSingleNode("/汎用サブ画面/パターン情報/設定"), XmlElement)
            If extNode Is Nothing Then
                extNode = doc.CreateElement("設定")
                extNode.SetAttribute("項目数", "0")
                patNode.AppendChild(extNode)
            End If

            ' グループ内の全項目をアップサート（既存は部分更新、未存在は追加）
            Dim j As Integer
            For j = 0 To list.Count - 1
                UpsertExtItem(doc, extNode, list(j))
            Next

            '新規作成時のみ：属性=0 の先頭3枠へ計算式サンプル（2枠＋出力1枠）を投入
            EnsureSampleCalcFormulaSet(doc, extNode, isNewFile)

            '' 項目数の設定
            Dim countNodes As XmlNodeList = extNode.SelectNodes("項目")
            extNode.SetAttribute("項目数", countNodes.Count.ToString())

            ' 保存
            Using sw As New StreamWriter(path, False, New UTF8Encoding(True))
                sw.WriteLine("<?xml version=""1.0"" encoding=""UTF-8""?>")
                Using xw As XmlWriter = XmlWriter.Create(sw, settings)
                    Dim node As XmlNode = doc.SelectSingleNode("/汎用サブ画面")
                    If node IsNot Nothing Then
                        node.WriteTo(xw)
                    End If
                End Using
            End Using

            ' 仕上げ：PARM1 の属性をダブルクォート→シングルクォートへ、"/>" 前スペース除去
            FixParm1Quotes(path)
        Next

    End Sub

    Private Sub UpsertExtItem(ByVal doc As XmlDocument,
                             ByVal extNode As XmlElement,
                             ByVal d As ExtItemInfo)

        ' キーは「列名」で判定（例：K001）
        Dim target As XmlElement = TryCast(extNode.SelectSingleNode("項目[@列名='" & d.列名 & "']"), XmlElement)

        ' 属性の数値判定
        Dim attrNum As Integer = 0
        Dim ok As Boolean = Integer.TryParse(d.属性, attrNum)
        Dim isNumericOrDate As Boolean = ok AndAlso attrNum >= 3 AndAlso attrNum <= 6

        If target Is Nothing Then
            ' --- 新規追加（既知の5属性だけ付与） ---
            target = doc.CreateElement("項目")
            If Not String.IsNullOrEmpty(d.タイトル) Then target.SetAttribute("タイトル", d.タイトル)
            If Not String.IsNullOrEmpty(d.属性) Then target.SetAttribute("属性", d.属性)
            If Not String.IsNullOrEmpty(d.列名) Then target.SetAttribute("列名", d.列名)
            If Not String.IsNullOrEmpty(d.桁数) Then target.SetAttribute("桁数", d.桁数)
            If Not String.IsNullOrEmpty(d.小数) Then target.SetAttribute("小数", d.小数)


            '属性4～6(年月日～年度）までには、区切り文字の属性を追加
            'デフォルトは1：スラッシュにしておく
            If ok AndAlso (attrNum >= 4 AndAlso attrNum <= 6) Then
                target.SetAttribute("区切り文字", "1")
            End If

            ' 属性7の際は親要素側のサンプル属性を付与（新規作成時のみ）
            If ok AndAlso attrNum = 7 Then
                target.SetAttribute("入力チェック", "1")
                target.SetAttribute("マスター検索", "1")
                target.SetAttribute("タイプ", "0")
                target.SetAttribute("大文字変換", "1")
                target.SetAttribute("マスター取得", "1")
                target.SetAttribute("項目変数", "@K1")
            End If

            '属性8～13(画像～メールアドレス)の際はボタン使用は有効化
            If ok AndAlso (attrNum >= 8 AndAlso attrNum <= 13) Then
                target.SetAttribute("ボタン使用", "1")
            End If


            ' PARM1（新規時のみ追加）
            Dim parm As XmlElement = doc.CreateElement("PARM1")
            parm.SetAttribute("デフォルト", If(isNumericOrDate, "0", ""))
            target.AppendChild(parm)


            ' サンプル子要素は新規作成時のみ追加（既存項目は触らない）
            If ok AndAlso attrNum = 7 Then
                EnsureSampleNodesForAttr7(doc, target)
            End If

            extNode.AppendChild(target)

        Else
            ' --- 既存あり：渡された5項目のみ部分更新（空文字は未変更） ---
            If Not String.IsNullOrEmpty(d.タイトル) Then target.SetAttribute("タイトル", d.タイトル)
            If Not String.IsNullOrEmpty(d.属性) Then target.SetAttribute("属性", d.属性)
            If Not String.IsNullOrEmpty(d.列名) Then target.SetAttribute("列名", d.列名)
            If Not String.IsNullOrEmpty(d.桁数) Then target.SetAttribute("桁数", d.桁数)
            If Not String.IsNullOrEmpty(d.小数) Then target.SetAttribute("小数", d.小数)

            ' PARM1：
            Dim parmExisting As XmlElement = TryCast(target.SelectSingleNode("PARM1"), XmlElement)
            If isNumericOrDate Then
                If parmExisting Is Nothing Then
                    Dim parmNew As XmlElement = doc.CreateElement("PARM1")
                    parmNew.SetAttribute("デフォルト", "0")
                    target.AppendChild(parmNew)
                Else
                    parmExisting.SetAttribute("デフォルト", "0")
                End If
            Else
                If parmExisting Is Nothing Then
                    Dim parmNew As XmlElement = doc.CreateElement("PARM1")
                    parmNew.SetAttribute("デフォルト", "")
                    target.AppendChild(parmNew)
                End If
            End If

        End If

        ' 属性並び順を統一
        NormalizeExtItemAttributeOrder(doc, extNode, target)

    End Sub

    ' ---- 属性=7 用：コード検索／コード保守／マスター取得を追加（サンプル用途） ----
    ' ※新規作成時にのみ呼ばれる前提
    Private Sub EnsureSampleNodesForAttr7(ByVal doc As XmlDocument, ByVal target As XmlElement)

        Dim codeSearch As XmlElement = TryCast(target.SelectSingleNode("コード検索"), XmlElement)
        If codeSearch Is Nothing Then
            codeSearch = doc.CreateElement("コード検索")
            codeSearch.SetAttribute("ID", SAMPLE_CODE_SEARCH_ID)
            codeSearch.SetAttribute("枝番", SAMPLE_CODE_SEARCH_EDA)

            Dim uketori As XmlElement = doc.CreateElement("受取")
            uketori.SetAttribute("KeyName", SAMPLE_CODE_SEARCH_UKETORI_KEY)
            codeSearch.AppendChild(uketori)

            InsertAfterParm1OrAppend(target, codeSearch)
        End If

        'Dim codeMaint As XmlElement = TryCast(target.SelectSingleNode("コード保守"), XmlElement)
        'If codeMaint Is Nothing Then
        '    codeMaint = doc.CreateElement("コード保守")
        '    codeMaint.SetAttribute("ID", SAMPLE_CODE_MAINT_ID)
        '    codeMaint.SetAttribute("枝番", SAMPLE_CODE_MAINT_EDA)

        '    Dim uketori2 As XmlElement = doc.CreateElement("受取")
        '    uketori2.SetAttribute("KeyName", SAMPLE_CODE_MAINT_UKETORI_KEY)
        '    codeMaint.AppendChild(uketori2)

        '    Dim hikisu As XmlElement = doc.CreateElement("引数")
        '    hikisu.SetAttribute("KeyName", SAMPLE_CODE_MAINT_HIKISU_KEY)
        '    codeMaint.AppendChild(hikisu)

        '    InsertAfterParm1OrAppend(target, codeMaint)
        'End If

        Dim masterGet As XmlElement = TryCast(target.SelectSingleNode("マスター取得"), XmlElement)
        If masterGet Is Nothing Then
            masterGet = doc.CreateElement("マスター取得")

            Dim getData As XmlElement = doc.CreateElement("取得データ")
            getData.InnerText = BuildIndentedBlockText(SAMPLE_MASTER_SQL, SAMPLE_BLOCK_TAG_INDENT)
            masterGet.AppendChild(getData)

            Dim hanei As XmlElement = doc.CreateElement("反映先")
            hanei.InnerText = BuildIndentedBlockText(SAMPLE_MASTER_HANEI, SAMPLE_BLOCK_TAG_INDENT)
            masterGet.AppendChild(hanei)

            InsertAfterParm1OrAppend(target, masterGet)
        End If

        'サンプルXMLであるためのコメントの追加
        Try
            Dim node As XmlNode = target.SelectSingleNode("comment()[normalize-space(.)='サンプル提供：参照定義コード']")
            Dim sampleComment As XmlComment = TryCast(node, XmlComment)
            If sampleComment Is Nothing Then
                sampleComment = doc.CreateComment("サンプル提供：参照定義コード")
                InsertAfterParm1OrAppendComment(target, sampleComment)
            End If
        Catch ex As Exception
        End Try

    End Sub

    ' ----新規作成時のみ：属性=0 の先頭3枠を計算式サンプルにする ----
    Private Sub EnsureSampleCalcFormulaSet(ByVal doc As XmlDocument, ByVal extNode As XmlElement, ByVal isNewFile As Boolean)

        If Not isNewFile Then Exit Sub
        If extNode Is Nothing Then Exit Sub

        ' 属性=0 の候補を列名番号順に並べる
        Dim nodes As XmlNodeList = extNode.SelectNodes("項目[@属性='0']")
        If nodes Is Nothing OrElse nodes.Count < 3 Then Exit Sub

        Dim candidates As New List(Of XmlElement)()
        Dim n As XmlNode
        For Each n In nodes
            Dim el As XmlElement = TryCast(n, XmlElement)
            If el IsNot Nothing Then candidates.Add(el)
        Next

        candidates.Sort(AddressOf CompareByColNameNumber)


        ' 先頭候補の直前に固定文言コメント
        EnsureSiblingCommentBeforeElement(extNode, candidates(0), "サンプル提供：計算式サンプル")


        ' 先頭3つを対象（最初の2つ：計算式、3つ目：出力）
        ApplyCalcSampleToSlot(doc, extNode, candidates(0), 1)
        ApplyCalcSampleToSlot(doc, extNode, candidates(1), 2)
        ApplyCalcSampleToSlot(doc, extNode, candidates(2), 3)

    End Sub

    Private Function CompareByColNameNumber(ByVal a As XmlElement, ByVal b As XmlElement) As Integer
        Dim na As Integer = ParseColNumber(a.GetAttribute("列名"))
        Dim nb As Integer = ParseColNumber(b.GetAttribute("列名"))
        Return na.CompareTo(nb)
    End Function

    Private Function ParseColNumber(ByVal col As String) As Integer
        If String.IsNullOrEmpty(col) Then Return Integer.MaxValue
        If col.Length < 2 Then Return Integer.MaxValue

        Dim digits As String = col.Trim()
        If digits.StartsWith("K", StringComparison.OrdinalIgnoreCase) Then
            digits = digits.Substring(1)
        End If

        Dim n As Integer = 0
        If Integer.TryParse(digits, n) Then
            Return n
        End If

        Return Integer.MaxValue
    End Function

    ' 計算式項目の設定 1、2=計算式枠、3=出力枠
    Private Sub ApplyCalcSampleToSlot(ByVal doc As XmlDocument, ByVal parent As XmlElement, ByVal target As XmlElement, ByVal slotNo As Integer)

        If doc Is Nothing OrElse parent Is Nothing OrElse target Is Nothing Then Exit Sub

        ' 既存の列名は維持。未使用枠（属性=0）をサンプルとして実装。
        target.SetAttribute("属性", "1")

        Dim colNo As Integer = ParseColNumber(target.GetAttribute("列名"))
        If colNo <> Integer.MaxValue Then
            target.SetAttribute("タイトル", "拡張項目" & colNo.ToString("00"))
        End If

        target.SetAttribute("桁数", "10")
        target.SetAttribute("入力チェック", "0")
        target.SetAttribute("計算式", "1")

        Select Case slotNo
            Case 1
                target.SetAttribute("項目変数", "@K3")
            Case 2
                target.SetAttribute("項目変数", "@K4")
            Case Else
                target.SetAttribute("入力可否", "0")
                target.SetAttribute("項目変数", "@K5")
        End Select

        ' PARM1 が無ければ追加（既にあるならそのまま）
        Dim parmExisting As XmlElement = TryCast(target.SelectSingleNode("PARM1"), XmlElement)
        If parmExisting Is Nothing Then
            Dim parmNew As XmlElement = doc.CreateElement("PARM1")
            parmNew.SetAttribute("デフォルト", "")
            target.AppendChild(parmNew)
        End If

        ' 計算式子要素：1、2 のみ付与。 3（出力）は付与しない。
        Dim calcExisting As XmlElement = TryCast(target.SelectSingleNode("計算式"), XmlElement)
        If calcExisting IsNot Nothing Then
            target.RemoveChild(calcExisting)
        End If

        If slotNo = 1 OrElse slotNo = 2 Then

            Dim calc As XmlElement = doc.CreateElement("計算式")

            Dim getData As XmlElement = doc.CreateElement("取得データ")
            getData.InnerText = BuildIndentedBlockText(SAMPLE_CALC_EXPR, SAMPLE_BLOCK_TAG_INDENT)
            calc.AppendChild(getData)

            Dim hanei As XmlElement = doc.CreateElement("反映先")
            hanei.InnerText = BuildIndentedBlockText(SAMPLE_CALC_TARGET, SAMPLE_BLOCK_TAG_INDENT)
            calc.AppendChild(hanei)

            ' PARM1 の直後に配置
            InsertAfterParm1OrAppend(target, calc)
        End If

        ' 属性並び順を統一
        NormalizeExtItemAttributeOrder(doc, parent, target)

    End Sub

    '<取得データ> 等のテキストを「改行＋インデント」で整形する
    Private Function BuildIndentedBlockText(ByVal src As String, ByVal tagIndent As String) As String

        Dim normalized As String = src
        normalized = normalized.Replace(vbCrLf, vbLf)
        normalized = normalized.Replace(vbCr, vbLf)

        Dim lines() As String = normalized.Split(New String() {vbLf}, StringSplitOptions.None)

        ' 中身は開始タグより 1スペース深くする（見た目調整）
        Dim innerIndent As String = tagIndent & " "

        Dim sb As New StringBuilder()
        sb.Append(vbCrLf)

        Dim i As Integer
        For i = 0 To lines.Length - 1
            If lines(i) IsNot Nothing AndAlso lines(i).Length > 0 Then
                sb.Append(innerIndent)
                sb.Append(lines(i))
            End If
            sb.Append(vbCrLf)
        Next

        ' 終了タグの前に、開始タグと同じインデントを入れて揃える
        sb.Append(tagIndent)

        Return sb.ToString()

    End Function

    ' PARM1 の直後に挿入できれば挿入、なければ末尾に追加
    Private Sub InsertAfterParm1OrAppend(ByVal target As XmlElement, ByVal nodeToInsert As XmlElement)
        Dim parm As XmlNode = target.SelectSingleNode("PARM1")
        If parm Is Nothing Then
            target.AppendChild(nodeToInsert)
        Else
            Dim inserted As XmlNode = target.InsertAfter(nodeToInsert, parm)
        End If
    End Sub

    ' PARM1 の直後に挿入できれば挿入、なければ末尾に追加（コメント版）
    Private Sub InsertAfterParm1OrAppendComment(ByVal target As XmlElement, ByVal nodeToInsert As XmlComment)
        Dim parm As XmlNode = target.SelectSingleNode("PARM1")
        If parm Is Nothing Then
            target.AppendChild(nodeToInsert)
        Else
            Dim inserted As XmlNode = target.InsertAfter(nodeToInsert, parm)
        End If
    End Sub

    ' 対象拡張項目の直前にコメントを1回だけ追加
    Private Sub EnsureSiblingCommentBeforeElement(ByVal parent As XmlElement, ByVal target As XmlElement, ByVal commentText As String)
        If parent Is Nothing OrElse target Is Nothing Then Exit Sub
        ' 直前に既に同等のコメントがあるかチェック
        Dim prev As XmlNode = target.PreviousSibling
        Do While prev IsNot Nothing AndAlso prev.NodeType = XmlNodeType.Whitespace
            prev = prev.PreviousSibling
        Loop
        Dim exists As Boolean = False
        If prev IsNot Nothing Then
            Dim c As XmlComment = TryCast(prev, XmlComment)
            If c IsNot Nothing Then
                Dim data As String = If(c.Data, String.Empty)
                If data.Contains(commentText) Then exists = True
            End If
        End If
        If Not exists Then
            Dim c As XmlComment = parent.OwnerDocument.CreateComment(commentText)
            parent.InsertBefore(c, target)
        End If
    End Sub
    ' ---- 属性並び順の統一：新要素を作って置換する（既存の子ノードは保持） ----
    Private Sub NormalizeExtItemAttributeOrder(ByVal doc As XmlDocument,
                                              ByVal parent As XmlElement,
                                              ByVal target As XmlElement)

        Dim desired() As String = {"タイトル", "属性", "列名", "桁数", "小数"}

        Dim existing As New List(Of XmlAttribute)()
        Dim idx As Integer
        For idx = 0 To target.Attributes.Count - 1
            existing.Add(CType(target.Attributes.Item(idx), XmlAttribute))
        Next

        Dim newEl As XmlElement = doc.CreateElement("項目")
        Dim added As New HashSet(Of String)()

        Dim name As String
        For Each name In desired
            If target.HasAttribute(name) Then
                newEl.SetAttribute(name, target.GetAttribute(name))
                added.Add(name)
            End If
        Next

        Dim attr As XmlAttribute
        For Each attr In existing
            If Not added.Contains(attr.Name) Then
                newEl.SetAttribute(attr.Name, attr.Value)
            End If
        Next

        Dim child As XmlNode
        For Each child In target.ChildNodes
            newEl.AppendChild(child.CloneNode(True))
        Next

        parent.ReplaceChild(newEl, target)

    End Sub

    Private Function IsEmptyExtItem(ByRef d As ExtItemInfo) As Boolean
        Return String.IsNullOrEmpty(d.タイトル) AndAlso
               String.IsNullOrEmpty(d.属性) AndAlso
               String.IsNullOrEmpty(d.列名) AndAlso
               String.IsNullOrEmpty(d.桁数) AndAlso
               String.IsNullOrEmpty(d.小数)
    End Function

    Private Function BuildFileName(ByRef d As ExtItemInfo) As String
        Dim sb As New StringBuilder("EO汎用_FieldBuilder_")
        'Select Case d.データ種類
        '    Case 1 : sb.Append("売上")
        '    Case 2 : sb.Append("入金")
        '    Case 3 : sb.Append("仕入")
        '    Case 4 : sb.Append("支払")
        '    Case 5 : sb.Append("入出庫")
        '    Case Else : sb.Append("未定義")
        'End Select
        sb.Append(d.データ種類略称)
        Select Case d.明細区分
            Case 1 : sb.Append("ヘッダー")
            Case 2 : sb.Append("明細")
            Case Else : sb.Append("未定義区分")
        End Select
        sb.Append(".xml")
        Return sb.ToString()
    End Function

    Private Function BuildProgramName(ByRef d As ExtItemInfo) As String
        Dim sb As New StringBuilder()
        'Select Case d.データ種類
        '    Case 1 : sb.Append("売上")
        '    Case 2 : sb.Append("入金")
        '    Case 3 : sb.Append("仕入")
        '    Case 4 : sb.Append("支払")
        '    Case 5 : sb.Append("入出庫")
        '    Case Else : sb.Append("未定義")
        'End Select
        sb.Append(d.データ種類略称)
        Select Case d.明細区分
            Case 1 : sb.Append("ヘッダー")
            Case 2 : sb.Append("明細")
            Case Else : sb.Append("未定義区分")
        End Select
        sb.Append("FieldBuilder")
        Return sb.ToString()
    End Function

    Private Sub FixParm1Quotes(ByVal path As String)
        Dim xml As String = File.ReadAllText(path, Encoding.UTF8)
        xml = Regex.Replace(xml, "(<PARM1\s+デフォルト=)""([^""]*)""", "$1'$2'")
        xml = Regex.Replace(xml, "<PARM1([^>]*)\s+/>", "<PARM1$1/>")
        File.WriteAllText(path, xml, New UTF8Encoding(True))
    End Sub

End Class
