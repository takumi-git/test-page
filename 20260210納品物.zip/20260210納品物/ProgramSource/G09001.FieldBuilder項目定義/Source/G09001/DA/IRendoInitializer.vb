﻿''' <summary>
''' インターフェース
''' </summary>
''' <remarks>※20101014_1で追加※</remarks>
Public Interface IRendoInitializer
    Inherits IInsideDataHandler

    ''' <summary>
    ''' 初期処理
    ''' </summary>
    ''' <param name="connection">接続情報</param>
    ''' <param name="initInfo">取得結果</param>
    ''' <remarks></remarks>
    Sub Startup(ByVal connection As System.Data.Common.DbConnection, ByRef initInfo As System.Collections.IDictionary)

End Interface
