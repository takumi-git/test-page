﻿Public Class BrokerHostApp

    Public Shared Sub Main()

        Dim clientSinkProvider As New SoapClientFormatterSinkProvider
        Dim serverSinkProvider As New SoapServerFormatterSinkProvider

        Console.WriteLine("BrokerHostApp RemotingHost")

        Dim props As IDictionary
        props = New Hashtable
        props.Item("port") = 8181

        Dim channel As HttpChannel
        channel = New HttpChannel(props, clientSinkProvider, serverSinkProvider)

        ChannelServices.RegisterChannel(channel, False)

        RemotingConfiguration.RegisterWellKnownServiceType(GetType(OSK.X1.Broker.DataAccess.RealBroker), _
                                                           "RemotingBrokerService", _
                                                           WellKnownObjectMode.SingleCall)    'X1変換Tool-20160427

        Pause()

    End Sub

    Private Shared Sub Pause()
        Console.WriteLine("Pause Push Any Key !")
        Console.ReadLine()
    End Sub
End Class
