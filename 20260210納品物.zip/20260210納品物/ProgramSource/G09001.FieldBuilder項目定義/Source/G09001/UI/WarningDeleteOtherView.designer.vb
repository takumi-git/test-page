﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class WarningDeleteOtherView
    Inherits OSK.X1.Foundation.UIDesign.UserInterface.DesignFormBase

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.ok = New OSK.X1.Foundation.SimpleControl.CommandButton
        Me.cancel = New OSK.X1.Foundation.SimpleControl.CommandButton
        Me.Panel1 = New OSK.X1.Foundation.SimpleControl.Panel(Me.components)
        Me.Label1 = New OSK.X1.Foundation.SimpleControl.Label
        Me.cautionMessage8 = New OSK.X1.Foundation.SimpleControl.Label
        Me.cautionMessage7 = New OSK.X1.Foundation.SimpleControl.Label
        Me.cautionMessage3 = New OSK.X1.Foundation.SimpleControl.Label
        Me.cautionMessage4 = New OSK.X1.Foundation.SimpleControl.Label
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ok
        '
        Me.ok.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.ok.FocusBackColor = System.Drawing.Color.Empty
        Me.ok.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.ok.Image = Nothing
        Me.ok.Location = New System.Drawing.Point(246, 150)
        Me.ok.Name = "ok"
        Me.ok.NextByDownKey = False
        Me.ok.NextByEnterKey = False
        Me.ok.NextByRightKey = True
        Me.ok.PrevByShiftTabKey = False
        Me.ok.PrevByUpKey = False
        Me.ok.RemarkString = Nothing
        Me.ok.Size = New System.Drawing.Size(80, 24)
        Me.ok.TabIndex = 1
        Me.ok.Text = "強制実行"
        Me.ok.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cancel
        '
        Me.cancel.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.cancel.FocusBackColor = System.Drawing.Color.Empty
        Me.cancel.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.cancel.Image = Nothing
        Me.cancel.Location = New System.Drawing.Point(357, 150)
        Me.cancel.Name = "cancel"
        Me.cancel.NextByDownKey = False
        Me.cancel.NextByEnterKey = False
        Me.cancel.NextByTabKey = False
        Me.cancel.PrevByLeftKey = True
        Me.cancel.PrevByUpKey = False
        Me.cancel.RemarkString = Nothing
        Me.cancel.Size = New System.Drawing.Size(80, 24)
        Me.cancel.TabIndex = 2
        Me.cancel.Text = "キャンセル"
        Me.cancel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.Control
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.cautionMessage8)
        Me.Panel1.Controls.Add(Me.cautionMessage7)
        Me.Panel1.Controls.Add(Me.cautionMessage3)
        Me.Panel1.Controls.Add(Me.cautionMessage4)
        Me.Panel1.Location = New System.Drawing.Point(9, 12)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(428, 132)
        Me.Panel1.TabIndex = 0
        Me.Panel1.Text = "Panel1"
        Me.Panel1.Title = ""
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.BorderColor = System.Drawing.SystemColors.WindowFrame
        Me.Label1.BorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.None
        Me.Label1.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label1.Location = New System.Drawing.Point(3, 107)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(223, 20)
        Me.Label1.TabIndex = 6
        Me.Label1.Tag = "@Form@"
        Me.Label1.Text = "登録済み拡張データがクリアされます。"
        '
        'cautionMessage8
        '
        Me.cautionMessage8.BackColor = System.Drawing.Color.Transparent
        Me.cautionMessage8.BorderColor = System.Drawing.SystemColors.WindowFrame
        Me.cautionMessage8.BorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.None
        Me.cautionMessage8.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.cautionMessage8.Location = New System.Drawing.Point(3, 85)
        Me.cautionMessage8.Name = "cautionMessage8"
        Me.cautionMessage8.Size = New System.Drawing.Size(395, 20)
        Me.cautionMessage8.TabIndex = 6
        Me.cautionMessage8.Tag = "@Form@"
        Me.cautionMessage8.Text = "※強制実行した場合は、定義変更により属性や桁数が一致しない"
        '
        'cautionMessage7
        '
        Me.cautionMessage7.BackColor = System.Drawing.Color.Transparent
        Me.cautionMessage7.BorderColor = System.Drawing.SystemColors.WindowFrame
        Me.cautionMessage7.BorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.None
        Me.cautionMessage7.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.cautionMessage7.Location = New System.Drawing.Point(3, 55)
        Me.cautionMessage7.Name = "cautionMessage7"
        Me.cautionMessage7.Size = New System.Drawing.Size(176, 20)
        Me.cautionMessage7.TabIndex = 5
        Me.cautionMessage7.Tag = "@Form@"
        Me.cautionMessage7.Text = "定義の変更を中止しますか？"
        '
        'cautionMessage3
        '
        Me.cautionMessage3.BackColor = System.Drawing.Color.Transparent
        Me.cautionMessage3.BorderColor = System.Drawing.SystemColors.WindowFrame
        Me.cautionMessage3.BorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.None
        Me.cautionMessage3.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.cautionMessage3.Location = New System.Drawing.Point(3, 9)
        Me.cautionMessage3.Name = "cautionMessage3"
        Me.cautionMessage3.Size = New System.Drawing.Size(422, 20)
        Me.cautionMessage3.TabIndex = 3
        Me.cautionMessage3.Tag = "@Form@"
        Me.cautionMessage3.Text = "今回の定義変更により内容が正しく出力されなくなる登録済み拡張データ"
        '
        'cautionMessage4
        '
        Me.cautionMessage4.BackColor = System.Drawing.Color.Transparent
        Me.cautionMessage4.BorderColor = System.Drawing.SystemColors.WindowFrame
        Me.cautionMessage4.BorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.None
        Me.cautionMessage4.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.cautionMessage4.Location = New System.Drawing.Point(3, 29)
        Me.cautionMessage4.Name = "cautionMessage4"
        Me.cautionMessage4.Size = New System.Drawing.Size(88, 20)
        Me.cautionMessage4.TabIndex = 0
        Me.cautionMessage4.Tag = "@Form@"
        Me.cautionMessage4.Text = "が存在します。"
        '
        'WarningDeleteOtherView
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(447, 184)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.cancel)
        Me.Controls.Add(Me.ok)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "WarningDeleteOtherView"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "警告"
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ok As OSK.X1.Foundation.SimpleControl.CommandButton
    Friend WithEvents cancel As OSK.X1.Foundation.SimpleControl.CommandButton
    Friend WithEvents Panel1 As OSK.X1.Foundation.SimpleControl.Panel
    Friend WithEvents cautionMessage8 As OSK.X1.Foundation.SimpleControl.Label
    Friend WithEvents cautionMessage7 As OSK.X1.Foundation.SimpleControl.Label
    Friend WithEvents cautionMessage3 As OSK.X1.Foundation.SimpleControl.Label
    Friend WithEvents cautionMessage4 As OSK.X1.Foundation.SimpleControl.Label
    Friend WithEvents Label1 As OSK.X1.Foundation.SimpleControl.Label
End Class
