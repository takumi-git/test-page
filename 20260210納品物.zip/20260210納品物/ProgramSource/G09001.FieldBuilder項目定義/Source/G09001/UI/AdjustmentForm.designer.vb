﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AdjustmentForm
    Inherits OSK.X1.Foundation.UIDesign.UserInterface.DesignFormBase

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim Item1 As OSK.X1.Foundation.Controls.GroupOptionImpl.Item = New OSK.X1.Foundation.Controls.GroupOptionImpl.Item
        Dim Item2 As OSK.X1.Foundation.Controls.GroupOptionImpl.Item = New OSK.X1.Foundation.Controls.GroupOptionImpl.Item
        Dim Item3 As OSK.X1.Foundation.Controls.GroupOptionImpl.Item = New OSK.X1.Foundation.Controls.GroupOptionImpl.Item
        Dim Item4 As OSK.X1.Foundation.Controls.GroupOptionImpl.Item = New OSK.X1.Foundation.Controls.GroupOptionImpl.Item
        Dim FunctionControlList1 As OSK.X1.Foundation.SmartControl.FunctionBar.FunctionControlList = New OSK.X1.Foundation.SmartControl.FunctionBar.FunctionControlList
        Me.ok = New OSK.X1.Foundation.SimpleControl.CommandButton
        Me.cancel = New OSK.X1.Foundation.SimpleControl.CommandButton
        Me.Panel1 = New OSK.X1.Foundation.SimpleControl.Panel(Me.components)
        Me.cautionMessage7 = New OSK.X1.Foundation.SimpleControl.Label
        Me.cautionMessage3 = New OSK.X1.Foundation.SimpleControl.Label
        Me.cautionMessage4 = New OSK.X1.Foundation.SimpleControl.Label
        Me.BunruiPanel = New OSK.X1.Foundation.SimpleControl.Panel(Me.components)
        Me.husenkubunPanel = New OSK.X1.Foundation.SimpleControl.Panel(Me.components)
        Me.checkKubunNyuusyukka = New OSK.X1.Foundation.SimpleControl.CheckBox
        Me.checkKubunKeihi = New OSK.X1.Foundation.SimpleControl.CheckBox
        Me.checkKubunMitumori = New OSK.X1.Foundation.SimpleControl.CheckBox
        Me.checkKubunJutyuu = New OSK.X1.Foundation.SimpleControl.CheckBox
        Me.checkKubunUriage = New OSK.X1.Foundation.SimpleControl.CheckBox
        Me.meisaiKubun = New OSK.X1.Foundation.SimpleControl.GroupOption
        Me.dataShubetu = New OSK.X1.Foundation.SimpleControl.GroupOption
        Me.meisaiKubunMei = New OSK.X1.Foundation.SimpleControl.Label
        Me.detaShubetuMei = New OSK.X1.Foundation.SimpleControl.Label
        Me.dataShurui = New OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemNameAndInputName
        Me.StatusBar = New OSK.X1.Foundation.SmartControl.StatusBar.StatusBar(Me.components)
        Me.FunctionBar = New OSK.X1.Foundation.SmartControl.FunctionBar.FunctionBar
        Me.Panel1.SuspendLayout()
        Me.BunruiPanel.SuspendLayout()
        Me.husenkubunPanel.SuspendLayout()
        Me.SuspendLayout()
        '
        'ok
        '
        Me.ok.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.ok.FocusBackColor = System.Drawing.Color.Empty
        Me.ok.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.ok.Image = Nothing
        Me.ok.Location = New System.Drawing.Point(222, 235)
        Me.ok.Name = "ok"
        Me.ok.NextByEnterKey = False
        Me.ok.NextByRightKey = True
        Me.ok.RemarkString = Nothing
        Me.ok.Size = New System.Drawing.Size(80, 24)
        Me.ok.TabIndex = 1
        Me.ok.Text = "実行"
        Me.ok.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'cancel
        '
        Me.cancel.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.cancel.FocusBackColor = System.Drawing.Color.Empty
        Me.cancel.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.cancel.Image = Nothing
        Me.cancel.Location = New System.Drawing.Point(324, 235)
        Me.cancel.Name = "cancel"
        Me.cancel.NextByDownKey = False
        Me.cancel.NextByEnterKey = False
        Me.cancel.NextByTabKey = False
        Me.cancel.PrevByLeftKey = True
        Me.cancel.RemarkString = Nothing
        Me.cancel.Size = New System.Drawing.Size(80, 24)
        Me.cancel.TabIndex = 2
        Me.cancel.Text = "キャンセル"
        Me.cancel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.Control
        Me.Panel1.Controls.Add(Me.cautionMessage7)
        Me.Panel1.Controls.Add(Me.cautionMessage3)
        Me.Panel1.Controls.Add(Me.cautionMessage4)
        Me.Panel1.Location = New System.Drawing.Point(9, 12)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(395, 93)
        Me.Panel1.TabIndex = 7
        Me.Panel1.Text = "Panel1"
        '
        'cautionMessage7
        '
        Me.cautionMessage7.BackColor = System.Drawing.Color.Transparent
        Me.cautionMessage7.BorderColor = System.Drawing.SystemColors.WindowFrame
        Me.cautionMessage7.BorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.None
        Me.cautionMessage7.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.cautionMessage7.Location = New System.Drawing.Point(3, 68)
        Me.cautionMessage7.Name = "cautionMessage7"
        Me.cautionMessage7.Size = New System.Drawing.Size(284, 20)
        Me.cautionMessage7.TabIndex = 5
        Me.cautionMessage7.Tag = "@Form@"
        Me.cautionMessage7.Text = "整合処理を実行したいデータを選択してください。"
        '
        'cautionMessage3
        '
        Me.cautionMessage3.BackColor = System.Drawing.Color.Transparent
        Me.cautionMessage3.BorderColor = System.Drawing.SystemColors.WindowFrame
        Me.cautionMessage3.BorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.None
        Me.cautionMessage3.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.cautionMessage3.Location = New System.Drawing.Point(3, 9)
        Me.cautionMessage3.Name = "cautionMessage3"
        Me.cautionMessage3.Size = New System.Drawing.Size(369, 20)
        Me.cautionMessage3.TabIndex = 3
        Me.cautionMessage3.Tag = "@Form@"
        Me.cautionMessage3.Text = "入力済み拡張データの内容を確認し、現在の拡張項目定義と"
        '
        'cautionMessage4
        '
        Me.cautionMessage4.BackColor = System.Drawing.Color.Transparent
        Me.cautionMessage4.BorderColor = System.Drawing.SystemColors.WindowFrame
        Me.cautionMessage4.BorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.None
        Me.cautionMessage4.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.cautionMessage4.Location = New System.Drawing.Point(3, 29)
        Me.cautionMessage4.Name = "cautionMessage4"
        Me.cautionMessage4.Size = New System.Drawing.Size(345, 20)
        Me.cautionMessage4.TabIndex = 0
        Me.cautionMessage4.Tag = "@Form@"
        Me.cautionMessage4.Text = "属性や桁数が一致しない拡張データの内容をクリアします。"
        '
        'BunruiPanel
        '
        Me.BunruiPanel.BackColor = System.Drawing.SystemColors.Control
        Me.BunruiPanel.Controls.Add(Me.husenkubunPanel)
        Me.BunruiPanel.Controls.Add(Me.meisaiKubun)
        Me.BunruiPanel.Controls.Add(Me.dataShubetu)
        Me.BunruiPanel.Controls.Add(Me.meisaiKubunMei)
        Me.BunruiPanel.Controls.Add(Me.detaShubetuMei)
        Me.BunruiPanel.Controls.Add(Me.dataShurui)
        Me.BunruiPanel.Location = New System.Drawing.Point(9, 111)
        Me.BunruiPanel.Name = "BunruiPanel"
        Me.BunruiPanel.Size = New System.Drawing.Size(395, 118)
        Me.BunruiPanel.TabIndex = 0
        Me.BunruiPanel.Text = "Panel1"
        '
        'husenkubunPanel
        '
        Me.husenkubunPanel.BackColor = System.Drawing.SystemColors.Control
        Me.husenkubunPanel.Controls.Add(Me.checkKubunNyuusyukka)
        Me.husenkubunPanel.Controls.Add(Me.checkKubunKeihi)
        Me.husenkubunPanel.Controls.Add(Me.checkKubunMitumori)
        Me.husenkubunPanel.Controls.Add(Me.checkKubunJutyuu)
        Me.husenkubunPanel.Controls.Add(Me.checkKubunUriage)
        Me.husenkubunPanel.Location = New System.Drawing.Point(112, 84)
        Me.husenkubunPanel.Name = "husenkubunPanel"
        Me.husenkubunPanel.Size = New System.Drawing.Size(230, 25)
        Me.husenkubunPanel.TabIndex = 4
        Me.husenkubunPanel.Text = "Panel3"
        '
        'checkKubunNyuusyukka
        '
        Me.checkKubunNyuusyukka.CheckState = System.Windows.Forms.CheckState.Unchecked
        Me.checkKubunNyuusyukka.DependCheckState = False
        Me.checkKubunNyuusyukka.DrawFocusFrame = True
        Me.checkKubunNyuusyukka.FocusBackColor = System.Drawing.Color.Empty
        Me.checkKubunNyuusyukka.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.checkKubunNyuusyukka.GroupNo = 1
        Me.checkKubunNyuusyukka.IndeterminateText = ""
        Me.checkKubunNyuusyukka.Location = New System.Drawing.Point(60, 3)
        Me.checkKubunNyuusyukka.Name = "checkKubunNyuusyukka"
        Me.checkKubunNyuusyukka.RemarkString = Nothing
        Me.checkKubunNyuusyukka.Size = New System.Drawing.Size(53, 19)
        Me.checkKubunNyuusyukka.TabIndex = 1
        Me.checkKubunNyuusyukka.Text = "出荷"
        Me.checkKubunNyuusyukka.UncheckedText = ""
        '
        'checkKubunKeihi
        '
        Me.checkKubunKeihi.CheckState = System.Windows.Forms.CheckState.Unchecked
        Me.checkKubunKeihi.DependCheckState = False
        Me.checkKubunKeihi.DrawFocusFrame = True
        Me.checkKubunKeihi.FocusBackColor = System.Drawing.Color.Empty
        Me.checkKubunKeihi.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.checkKubunKeihi.GroupNo = 1
        Me.checkKubunKeihi.IndeterminateText = ""
        Me.checkKubunKeihi.Location = New System.Drawing.Point(175, 3)
        Me.checkKubunKeihi.Name = "checkKubunKeihi"
        Me.checkKubunKeihi.RemarkString = Nothing
        Me.checkKubunKeihi.Size = New System.Drawing.Size(53, 19)
        Me.checkKubunKeihi.TabIndex = 4
        Me.checkKubunKeihi.Text = "経費"
        Me.checkKubunKeihi.UncheckedText = ""
        '
        'checkKubunMitumori
        '
        Me.checkKubunMitumori.CheckState = System.Windows.Forms.CheckState.Unchecked
        Me.checkKubunMitumori.DependCheckState = False
        Me.checkKubunMitumori.DrawFocusFrame = True
        Me.checkKubunMitumori.FocusBackColor = System.Drawing.Color.Empty
        Me.checkKubunMitumori.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.checkKubunMitumori.GroupNo = 1
        Me.checkKubunMitumori.IndeterminateText = ""
        Me.checkKubunMitumori.Location = New System.Drawing.Point(117, 3)
        Me.checkKubunMitumori.Name = "checkKubunMitumori"
        Me.checkKubunMitumori.RemarkString = Nothing
        Me.checkKubunMitumori.Size = New System.Drawing.Size(53, 19)
        Me.checkKubunMitumori.TabIndex = 3
        Me.checkKubunMitumori.Text = "見積"
        Me.checkKubunMitumori.UncheckedText = ""
        '
        'checkKubunJutyuu
        '
        Me.checkKubunJutyuu.CheckState = System.Windows.Forms.CheckState.Unchecked
        Me.checkKubunJutyuu.DependCheckState = False
        Me.checkKubunJutyuu.DrawFocusFrame = True
        Me.checkKubunJutyuu.FocusBackColor = System.Drawing.Color.Empty
        Me.checkKubunJutyuu.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.checkKubunJutyuu.GroupNo = 1
        Me.checkKubunJutyuu.IndeterminateText = ""
        Me.checkKubunJutyuu.Location = New System.Drawing.Point(117, 3)
        Me.checkKubunJutyuu.Name = "checkKubunJutyuu"
        Me.checkKubunJutyuu.RemarkString = Nothing
        Me.checkKubunJutyuu.Size = New System.Drawing.Size(53, 19)
        Me.checkKubunJutyuu.TabIndex = 2
        Me.checkKubunJutyuu.Text = "受注"
        Me.checkKubunJutyuu.UncheckedText = ""
        '
        'checkKubunUriage
        '
        Me.checkKubunUriage.CheckState = System.Windows.Forms.CheckState.Unchecked
        Me.checkKubunUriage.DependCheckState = False
        Me.checkKubunUriage.DrawFocusFrame = True
        Me.checkKubunUriage.FocusBackColor = System.Drawing.Color.Empty
        Me.checkKubunUriage.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.checkKubunUriage.GroupNo = 1
        Me.checkKubunUriage.IndeterminateText = ""
        Me.checkKubunUriage.Location = New System.Drawing.Point(3, 3)
        Me.checkKubunUriage.Name = "checkKubunUriage"
        Me.checkKubunUriage.RemarkString = Nothing
        Me.checkKubunUriage.Size = New System.Drawing.Size(53, 19)
        Me.checkKubunUriage.TabIndex = 0
        Me.checkKubunUriage.Text = "売上"
        Me.checkKubunUriage.UncheckedText = ""
        '
        'meisaiKubun
        '
        Me.meisaiKubun.FocusBackColor = System.Drawing.Color.Empty
        Me.meisaiKubun.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.meisaiKubun.ItemCount = 2
        Item1.Enabled = True
        Item1.Text = "伝票"
        Item1.Visible = True
        Item2.Enabled = True
        Item2.Text = "明細"
        Item2.Visible = True
        Me.meisaiKubun.Items = New OSK.X1.Foundation.Controls.GroupOptionImpl.Item() {Item1, Item2}
        Me.meisaiKubun.Location = New System.Drawing.Point(112, 59)
        Me.meisaiKubun.Name = "meisaiKubun"
        Me.meisaiKubun.RemarkString = Nothing
        Me.meisaiKubun.Size = New System.Drawing.Size(232, 19)
        Me.meisaiKubun.TabIndex = 2
        Me.meisaiKubun.Title = ""
        Me.meisaiKubun.TitleVisible = False
        Me.meisaiKubun.Value = 1
        '
        'dataShubetu
        '
        Me.dataShubetu.FocusBackColor = System.Drawing.Color.Empty
        Me.dataShubetu.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.dataShubetu.ItemCount = 2
        Item3.Enabled = True
        Item3.Text = "マスター"
        Item3.Visible = True
        Item4.Enabled = True
        Item4.Text = "取引データ"
        Item4.Visible = True
        Me.dataShubetu.Items = New OSK.X1.Foundation.Controls.GroupOptionImpl.Item() {Item3, Item4}
        Me.dataShubetu.Location = New System.Drawing.Point(112, 9)
        Me.dataShubetu.Name = "dataShubetu"
        Me.dataShubetu.PrevByShiftTabKey = False
        Me.dataShubetu.PrevByUpKey = False
        Me.dataShubetu.RemarkString = Nothing
        Me.dataShubetu.Size = New System.Drawing.Size(232, 19)
        Me.dataShubetu.TabIndex = 0
        Me.dataShubetu.Title = ""
        Me.dataShubetu.TitleVisible = False
        Me.dataShubetu.Value = 1
        '
        'meisaiKubunMei
        '
        Me.meisaiKubunMei.BorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.meisaiKubunMei.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.meisaiKubunMei.Location = New System.Drawing.Point(9, 59)
        Me.meisaiKubunMei.Name = "meisaiKubunMei"
        Me.meisaiKubunMei.ReadOnly = True
        Me.meisaiKubunMei.Size = New System.Drawing.Size(100, 19)
        Me.meisaiKubunMei.TabIndex = 9
        Me.meisaiKubunMei.Tag = ""
        Me.meisaiKubunMei.Text = "明細区分"
        Me.meisaiKubunMei.TextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Equal
        '
        'detaShubetuMei
        '
        Me.detaShubetuMei.BorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.detaShubetuMei.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.detaShubetuMei.Location = New System.Drawing.Point(9, 9)
        Me.detaShubetuMei.Name = "detaShubetuMei"
        Me.detaShubetuMei.ReadOnly = True
        Me.detaShubetuMei.Size = New System.Drawing.Size(100, 19)
        Me.detaShubetuMei.TabIndex = 6
        Me.detaShubetuMei.Tag = ""
        Me.detaShubetuMei.Text = "データ種別"
        Me.detaShubetuMei.TextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Equal
        '
        'dataShurui
        '
        Me.dataShurui.AllowBottomPosition = True
        Me.dataShurui.AutoResizeDispName = True
        Me.dataShurui.AutoResizeInputControl = True
        Me.dataShurui.BackColor = System.Drawing.Color.Transparent
        Me.dataShurui.DispNameAreaHeight = 19
        Me.dataShurui.DispNameAreaWidth = 205
        Me.dataShurui.DispNameBorderColor = System.Drawing.SystemColors.Window
        Me.dataShurui.DispNameBorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.dataShurui.DispNameSpace = 3
        Me.dataShurui.DispNameText = ""
        Me.dataShurui.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.dataShurui.GroupNo = 0
        Me.dataShurui.Indent = 0
        Me.dataShurui.InnerSpace = 3
        Me.dataShurui.InputAreaFont = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.dataShurui.InputControlReadOnly = False
        Me.dataShurui.InputControlSize = New System.Drawing.Size(23, 19)
        Me.dataShurui.InputTextImeMode = OSK.X1.Foundation.Controls.InputText.ImeModeType.NoControl
        Me.dataShurui.InputType = OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemNameAndInputName.InputModeType.数値のみ
        Me.dataShurui.ItemName = "データ種類"
        Me.dataShurui.ItemNameAreaHeight = 19
        Me.dataShurui.ItemNameAreaWidth = 100
        Me.dataShurui.ItemNameBorderColor = System.Drawing.SystemColors.Window
        Me.dataShurui.ItemNameBorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.dataShurui.ItemNameFont = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.dataShurui.ItemNameTextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Equal
        Me.dataShurui.Location = New System.Drawing.Point(9, 34)
        Me.dataShurui.Margin = New System.Windows.Forms.Padding(0)
        Me.dataShurui.MaxLength = 2
        Me.dataShurui.MaxLengthMode = OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CharCount
        Me.dataShurui.Name = "dataShurui"
        Me.dataShurui.RemarkString = Nothing
        Me.dataShurui.Size = New System.Drawing.Size(334, 19)
        Me.dataShurui.SubGroupNo = 0
        Me.dataShurui.TabIndex = 1
        Me.dataShurui.TextValue = ""
        Me.dataShurui.ZeroFill = True
        Me.dataShurui.ZeroFillAlways = False
        '
        'StatusBar
        '
        Me.StatusBar.AutoGuideMessageClearFlag = False
        Me.StatusBar.Location = New System.Drawing.Point(0, 292)
        Me.StatusBar.MarqueeAnimationSpeed = 100
        Me.StatusBar.Name = "StatusBar"
        Me.StatusBar.ProgressStep = 5
        Me.StatusBar.ProgressStyle = System.Windows.Forms.ProgressBarStyle.Blocks
        Me.StatusBar.Size = New System.Drawing.Size(415, 22)
        Me.StatusBar.SizingGrip = False
        Me.StatusBar.StatusContainer = Nothing
        Me.StatusBar.TabIndex = 44
        Me.StatusBar.Tag = "@Exception@"
        '
        'FunctionBar
        '
        Me.FunctionBar.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.FunctionBar.F1でヘルプ = OSK.X1.Foundation.SmartControl.FunctionBar.FunctionBar.ヘルプタイプ.実行する
        Me.FunctionBar.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.FunctionBar.GroupNo = 0
        Me.FunctionBar.Items = FunctionControlList1
        Me.FunctionBar.Location = New System.Drawing.Point(0, 267)
        Me.FunctionBar.Name = "FunctionBar"
        Me.FunctionBar.ShowItemToolTips = False
        Me.FunctionBar.Size = New System.Drawing.Size(415, 25)
        Me.FunctionBar.Stretch = True
        Me.FunctionBar.SubGroupNo = 0
        Me.FunctionBar.TabIndex = 45
        Me.FunctionBar.Text = "FunctionBar1"
        '
        'AdjustmentForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(415, 314)
        Me.Controls.Add(Me.FunctionBar)
        Me.Controls.Add(Me.StatusBar)
        Me.Controls.Add(Me.BunruiPanel)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.cancel)
        Me.Controls.Add(Me.ok)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "AdjustmentForm"
        Me.ScaleFactor = New System.Drawing.SizeF(1.0!, 1.0!)
        Me.ShowInTaskbar = False
        Me.Text = "警告"
        Me.Panel1.ResumeLayout(False)
        Me.BunruiPanel.ResumeLayout(False)
        Me.husenkubunPanel.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ok As OSK.X1.Foundation.SimpleControl.CommandButton
    Friend WithEvents cancel As OSK.X1.Foundation.SimpleControl.CommandButton
    Friend WithEvents Panel1 As OSK.X1.Foundation.SimpleControl.Panel
    Friend WithEvents cautionMessage7 As OSK.X1.Foundation.SimpleControl.Label
    Friend WithEvents cautionMessage3 As OSK.X1.Foundation.SimpleControl.Label
    Friend WithEvents cautionMessage4 As OSK.X1.Foundation.SimpleControl.Label
    Friend WithEvents BunruiPanel As OSK.X1.Foundation.SimpleControl.Panel
    Friend WithEvents meisaiKubun As OSK.X1.Foundation.SimpleControl.GroupOption
    Friend WithEvents dataShubetu As OSK.X1.Foundation.SimpleControl.GroupOption
    Friend WithEvents meisaiKubunMei As OSK.X1.Foundation.SimpleControl.Label
    Friend WithEvents detaShubetuMei As OSK.X1.Foundation.SimpleControl.Label
    Friend WithEvents dataShurui As OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemNameAndInputName
    Friend WithEvents husenkubunPanel As OSK.X1.Foundation.SimpleControl.Panel
    Friend WithEvents checkKubunMitumori As OSK.X1.Foundation.SimpleControl.CheckBox
    Friend WithEvents checkKubunJutyuu As OSK.X1.Foundation.SimpleControl.CheckBox
    Friend WithEvents checkKubunUriage As OSK.X1.Foundation.SimpleControl.CheckBox
    Friend WithEvents StatusBar As OSK.X1.Foundation.SmartControl.StatusBar.StatusBar
    Friend WithEvents FunctionBar As OSK.X1.Foundation.SmartControl.FunctionBar.FunctionBar
    Friend WithEvents checkKubunKeihi As OSK.X1.Foundation.SimpleControl.CheckBox
    Friend WithEvents checkKubunNyuusyukka As OSK.X1.Foundation.SimpleControl.CheckBox
End Class
