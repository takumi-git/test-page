﻿Public Class My項目名称型
    Inherits 項目名称型Base

    Public ReadOnly Property 販売得意先() As String
        Get
            Return GetItemName("販売得意先")
        End Get
    End Property

    Public ReadOnly Property 販売仕入先() As String
        Get
            Return GetItemName("販売仕入先")
        End Get
    End Property

    Public ReadOnly Property 販売商品() As String
        Get
            Return GetItemName("販売商品")
        End Get
    End Property

    Public ReadOnly Property 販売担当者_処理() As String
        Get
            Return GetItemName("販売担当者_処理")
        End Get
    End Property

    Public ReadOnly Property 販売仕入担当者_処理() As String
        Get
            Return GetItemName("販売仕入担当者_処理")
        End Get
    End Property

    Public ReadOnly Property 販売部門() As String
        Get
            Return GetItemName("販売部門")
        End Get
    End Property

    Public ReadOnly Property 販売納品先() As String
        Get
            Return GetItemName("販売納品先")
        End Get
    End Property

    Public ReadOnly Property 販売倉庫() As String
        Get
            Return GetItemName("販売倉庫")
        End Get
    End Property

    Public ReadOnly Property 販売営業所() As String
        Get
            Return GetItemName("販売営業所")
        End Get
    End Property

    Public ReadOnly Property 販売原価集計() As String       'A-20080709_2
        Get
            Return GetItemName("販売原価集計")
        End Get
    End Property

    Public ReadOnly Property 販売ロット() As String         'A-20091125_1
        Get
            Return GetItemName("販売ロット")
        End Get
    End Property
End Class
