﻿Public Class DataTableHelper

#Region "コンストラクタ"

    Sub New()
        _gridTable = New DataTable

        _rowState = New List(Of DataRowState)
        _rowState.Clear()

        _deletedRow = New List(Of DeletedRow)
        _deletedRow.Clear()

        SetupRowState()
        SetupEventHandler()
    End Sub

    Sub New(ByVal gridTable As DataTable)
        _gridTable = gridTable

        _rowState = New List(Of DataRowState)
        _rowState.Clear()

        _deletedRow = New List(Of DeletedRow)
        _deletedRow.Clear()

        SetupRowState()
        SetupEventHandler()
    End Sub

#End Region

#Region "プロパティ"

    Private WithEvents _gridTable As DataTable
    ''' <summary>
    ''' グリッドが持っているDataTable
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property GridTable() As DataTable
        Get
            Return _gridTable
        End Get
        Set(ByVal value As DataTable)
            _gridTable = value
        End Set
    End Property

    Private _rowState As List(Of DataRowState)
    ''' <summary>
    ''' 行の状態
    ''' </summary>
    ''' <param name="rowIndex">行番号</param>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property RowState(ByVal rowIndex As Integer) As DataRowState
        Get
            Return _rowState(rowIndex)
        End Get
    End Property

    Public ReadOnly Property RowState() As List(Of DataRowState)
        Get
            Return _rowState
        End Get
    End Property

    Private _deletedRow As List(Of DeletedRow)
    ''' <summary>
    ''' 保存した行
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property DeletedRow() As List(Of DeletedRow)
        Get
            Return _deletedRow
        End Get
    End Property

#End Region

#Region "メソッド"

    ''' <summary>
    ''' 削除された行を取得する
    ''' </summary>
    ''' <param name="tableRowIndex">DataTableの行番号</param>
    ''' <returns>対象行</returns>
    ''' <remarks></remarks>
    Public Function GetDeletedRow(ByVal tableRowIndex As Integer) As DataRow

        If DeletedRow.Count < 1 Then Return Nothing

        Dim targetRow As DataRow = Nothing
        For i As Integer = 0 To DeletedRow.Count - 1
            If DeletedRow(i).Index = tableRowIndex Then
                targetRow = DeletedRow(i).Item
                Exit For
            End If
        Next
        Return targetRow
    End Function

#End Region

#Region "イベント"
    Public Event ItemChanged(ByVal e As System.Data.DataRowChangeEventArgs)
#End Region

    Private _prevRowIndex As Integer
    Private _prevRowState As DataRowState

#Region "DataTableのイベント"

    ''' <summary>
    ''' データテーブルの行の変更しようとしている状態を通知
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub GridTable_RowChanging(ByVal sender As Object, ByVal e As System.Data.DataRowChangeEventArgs)
        _prevRowIndex = e.Row.Table.Rows.IndexOf(e.Row)
        If _prevRowIndex >= 0 Then
            _prevRowState = e.Row.RowState
        End If
    End Sub

    ''' <summary>
    ''' データテーブルの行の変更確定を通知
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub GridTable_RowChanged(ByVal sender As Object, ByVal e As System.Data.DataRowChangeEventArgs)
        Dim nowRowIndex As Integer = e.Row.Table.Rows.IndexOf(e.Row)

        If nowRowIndex < 0 AndAlso e.Row.RowState = DataRowState.Detached Then
            '行をReMoveしたとき。
            _rowState.RemoveAt(_prevRowIndex)

            Dim deletedRowIndex As Integer = SearchIndex(_prevRowIndex)
            If deletedRowIndex > 0 Then
                _deletedRow.RemoveAt(deletedRowIndex)
                CountDownRowIndex(_prevRowIndex)
            End If

            _prevRowState = DataRowState.Unchanged
            _prevRowIndex = -1
            Exit Sub
        End If

        If _rowState(e.Row.Table.Rows.Count - 1) = DataRowState.Detached Then
            '行追加したとき。
            Dim state As New List(Of DataRowState)
            For i As Integer = 0 To nowRowIndex - 1
                state.Add(_rowState.Item(i))
            Next
            state.Add(DataRowState.Added)
            For i As Integer = nowRowIndex To _rowState.Count - 2
                state.Add(_rowState.Item(i))
            Next
            _rowState = state

            CountUpRowIndex(nowRowIndex)
        End If

        If _prevRowState = DataRowState.Deleted Then
            Dim deletedRowIndex As Integer = SearchIndex(nowRowIndex)

            Select Case _rowState(nowRowIndex)
                Case DataRowState.Modified
                    For i As Integer = 0 To e.Row.Table.Columns.Count - 1
                        GridTable.Rows(GridTable.Rows.IndexOf(e.Row)).Item(i) = _deletedRow(deletedRowIndex).Item(i)
                    Next
                    _deletedRow.RemoveAt(deletedRowIndex)
                Case DataRowState.Added
                Case Else
                    _deletedRow.RemoveAt(deletedRowIndex)
            End Select
        End If

        _rowState(nowRowIndex) = e.Row.RowState
        _prevRowState = e.Row.RowState
    End Sub

    ''' <summary>
    ''' データテーブルの行を削除しようとしている状態を通知
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub GridTable_RowDeleting(ByVal sender As Object, ByVal e As System.Data.DataRowChangeEventArgs)
        _prevRowIndex = e.Row.Table.Rows.IndexOf(e.Row)

        If e.Row.Table.Rows.IndexOf(e.Row) >= 0 Then
            _rowState(e.Row.Table.Rows.IndexOf(e.Row)) = e.Row.RowState
        End If

        If e.Row.RowState <> DataRowState.Added Then
            '登録は削除行を保存しない
            Dim newRow As DataRow = e.Row.Table.NewRow
            _rowState.RemoveAt(_rowState.Count - 1)

            Dim savingRow As New DeletedRow
            savingRow.Index = _prevRowIndex
            savingRow.Item = newRow
            For i As Integer = 0 To e.Row.ItemArray.Length - 1
                savingRow.Item.Item(i) = e.Row(i)
            Next
            _deletedRow.Add(savingRow)
        End If
    End Sub

    ''' <summary>
    ''' データテーブルの行の削除確定を通知
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub GridTable_RowDeleted(ByVal sender As Object, ByVal e As System.Data.DataRowChangeEventArgs)
        If e.Row.Table.Rows.IndexOf(e.Row) < 0 AndAlso e.Row.RowState = DataRowState.Detached Then
            _rowState.RemoveAt(_prevRowIndex)

            '新規行(RowState=Added)の削除により、行数を変更する
            CountDownRowIndex(_prevRowIndex)

            _prevRowIndex = -1
        End If
    End Sub

    ''' <summary>
    ''' データテーブルの行の挿入を通知
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub GridTable_TableNewRow(ByVal sender As Object, ByVal e As System.Data.DataTableNewRowEventArgs)
        _rowState.Add(e.Row.RowState)
    End Sub

    ''' <summary>
    ''' テーブルがクリアされたのを通知
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub GridTable_TableCleared(ByVal sender As Object, ByVal e As System.Data.DataTableClearEventArgs)
        _rowState.Clear()
        _deletedRow.Clear()

        _prevRowIndex = -1
        _prevRowState = DataRowState.Unchanged
    End Sub

#End Region

#Region "内部メソッド"

    ''' <summary>
    '''　データテーブルの行状態をリストに追加
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetupRowState()

        For i As Integer = 0 To GridTable.Rows.Count - 1
            _rowState.Add(GridTable.Rows(i).RowState)
        Next

    End Sub

    ''' <summary>
    ''' データテーブルの主要イベントのハンドル設定
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetupEventHandler()
        AddHandler GridTable.RowChanging, AddressOf GridTable_RowChanging
        AddHandler GridTable.RowChanged, AddressOf GridTable_RowChanged
        AddHandler GridTable.RowDeleting, AddressOf GridTable_RowDeleting
        AddHandler GridTable.RowDeleted, AddressOf GridTable_RowDeleted
        AddHandler GridTable.TableNewRow, AddressOf GridTable_TableNewRow
        AddHandler GridTable.TableCleared, AddressOf GridTable_TableCleared
    End Sub

    ''' <summary>
    ''' 削除済み行のリストから対象行のインデックスを取得する
    ''' </summary>
    ''' <param name="dataRowIndex"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function SearchIndex(ByVal dataRowIndex As Integer) As Integer
        Dim index As Integer = -1
        For i As Integer = 0 To _deletedRow.Count - 1
            If dataRowIndex = _deletedRow(i).Index Then
                index = i
                Exit For
            End If
        Next
        Return index
    End Function

    ''' <summary>
    ''' 削除済み行リストのカウントを増やす
    ''' </summary>
    ''' <param name="dataRowIndex"></param>
    ''' <remarks></remarks>
    Private Sub CountUpRowIndex(ByVal dataRowIndex As Integer)
        For i As Integer = 0 To _deletedRow.Count - 1
            If _deletedRow(i).Index >= dataRowIndex Then
                _deletedRow(i).Index += 1   '１行増える。
            End If
        Next
    End Sub

    ''' <summary>
    ''' 削除済み行リストのカウントを減らす
    ''' </summary>
    ''' <param name="dataRowIndex"></param>
    ''' <remarks></remarks>
    Private Sub CountDownRowIndex(ByVal dataRowIndex As Integer)
        For i As Integer = 0 To _deletedRow.Count - 1
            If _deletedRow(i).Index > dataRowIndex Then
                _deletedRow(i).Index -= 1   '１行減る。
            End If
        Next
    End Sub

#End Region



End Class
