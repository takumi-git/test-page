﻿Public Class SettingInputText

#Region "コンストラクタ"

    Sub New(ByVal maxLength As Integer, ByVal maxLengthMode As OSK.X1.Foundation.Controls.InputText.MaxLengthModeType, _
            ByVal imeMode As OSK.X1.Foundation.Controls.InputText.ImeModeType, ByVal insert As Boolean, ByVal zeroFill As Boolean, _
            ByVal allCharacters As Boolean, ByVal inputDoubleByte As Boolean, _
            ByVal inputUpper As Boolean, ByVal inputLower As Boolean, _
            ByVal inputKana As Boolean, ByVal inputNumber As Boolean, ByVal inputCodeChar As Boolean, _
            ByVal inputSpace As Boolean, ByVal inputSymbol As Boolean)    'X1変換Tool-20160427

        _maxLength = maxLength
        _maxLengthMode = maxLengthMode
        _imeMode = imeMode
        _insert = insert
        _zeroFill = zeroFill
        _allCharacters = allCharacters
        _inputDoubleByte = inputDoubleByte
        _inputUpper = inputUpper
        _inputLower = inputLower
        _inputKana = inputKana
        _inputNumber = inputNumber
        _inputCodeChar = inputCodeChar
        _inputSpace = inputSpace
        _inputSymbol = inputSymbol
    End Sub

#End Region

#Region "プロパティ"

    Private _maxLengthMode As OSK.X1.Foundation.Controls.InputText.MaxLengthModeType    'X1変換Tool-20160427
    ''' <summary>
    ''' 文字最大長の利用モード
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property MaxLengthMode() As OSK.X1.Foundation.Controls.InputText.MaxLengthModeType    'X1変換Tool-20160427
        Get
            Return _maxLengthMode
        End Get
        Set(ByVal value As OSK.X1.Foundation.Controls.InputText.MaxLengthModeType)    'X1変換Tool-20160427
            _maxLengthMode = value
        End Set
    End Property

    Private _insert As Boolean
    ''' <summary>
    ''' 挿入モード
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property Insert() As Boolean
        Get
            Return _insert
        End Get
        Set(ByVal value As Boolean)
            _insert = value
        End Set
    End Property

    Private _allCharacters As Boolean
    ''' <summary>
    ''' 全文字入力モード
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property AllCharacters() As Boolean
        Get
            Return _allCharacters
        End Get
        Set(ByVal value As Boolean)
            _allCharacters = value
        End Set
    End Property

    Private _inputCodeChar As Boolean
    ''' <summary>
    ''' 半角符号文字入力可否
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property InputCodeChar() As Boolean
        Get
            Return _inputCodeChar
        End Get
        Set(ByVal value As Boolean)
            _inputCodeChar = value
        End Set
    End Property

    Private _inputDoubleByte As Boolean
    ''' <summary>
    ''' 全角文字入力可否
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property InputDoubleByte() As Boolean
        Get
            Return _inputDoubleByte
        End Get
        Set(ByVal value As Boolean)
            _inputDoubleByte = value
        End Set
    End Property

    Private _inputKana As Boolean
    ''' <summary>
    ''' 半角カナ入力可否
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property InputKana() As Boolean
        Get
            Return _inputKana
        End Get
        Set(ByVal value As Boolean)
            _inputKana = value
        End Set
    End Property

    Private _inputLower As Boolean
    ''' <summary>
    ''' 半角英語小文字入力可否
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property InputLower() As Boolean
        Get
            Return _inputLower
        End Get
        Set(ByVal value As Boolean)
            _inputLower = value
        End Set
    End Property

    Private _inputNumber As Boolean
    ''' <summary>
    ''' 半角数値入力可否
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property InputNumber() As Boolean
        Get
            Return _inputNumber
        End Get
        Set(ByVal value As Boolean)
            _inputNumber = value
        End Set
    End Property

    Private _inputSpace As Boolean
    ''' <summary>
    ''' スペース入力可否
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property InputSpace() As Boolean
        Get
            Return _inputSpace
        End Get
        Set(ByVal value As Boolean)
            _inputSpace = value
        End Set
    End Property

    Private _inputSymbol As Boolean
    ''' <summary>
    ''' 半角記号文字入力可否
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property InputSymbol() As Boolean
        Get
            Return _inputSymbol
        End Get
        Set(ByVal value As Boolean)
            _inputSymbol = value
        End Set
    End Property

    Private _inputUpper As Boolean
    ''' <summary>
    ''' 半角英大文字入力可否
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property InputUpper() As Boolean
        Get
            Return _inputUpper
        End Get
        Set(ByVal value As Boolean)
            _inputUpper = value
        End Set
    End Property

    Private _zeroFill As Boolean
    ''' <summary>
    ''' ゼロ埋め
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property ZeroFill() As Boolean
        Get
            Return _zeroFill
        End Get
        Set(ByVal value As Boolean)
            _zeroFill = value
        End Set
    End Property

    Private _maxLength As Integer
    ''' <summary>
    ''' 最大入力桁数
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property MaxLength() As Integer
        Get
            Return _maxLength
        End Get
        Set(ByVal value As Integer)
            _maxLength = value
        End Set
    End Property

    Private _imeMode As OSK.X1.Foundation.Controls.InputText.ImeModeType    'X1変換Tool-20160427
    ''' <summary>
    ''' IMEモード
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property ImeMode() As OSK.X1.Foundation.Controls.InputText.ImeModeType    'X1変換Tool-20160427
        Get
            Return _imeMode
        End Get
        Set(ByVal value As OSK.X1.Foundation.Controls.InputText.ImeModeType)    'X1変換Tool-20160427
            _imeMode = value
        End Set
    End Property

#End Region

End Class
