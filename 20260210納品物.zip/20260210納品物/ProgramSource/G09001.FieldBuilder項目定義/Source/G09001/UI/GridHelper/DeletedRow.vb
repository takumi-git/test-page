﻿''' <summary>
''' 削除行を保存するクラス
''' </summary>
''' <remarks></remarks>
Public Class DeletedRow

#Region "コンストラクタ"

    Sub New()
        _index = -1
        _item = Nothing
    End Sub

#End Region

#Region "プロパティ"

    Private _index As Integer
    ''' <summary>
    ''' 削除された行番号
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property Index() As Integer
        Get
            Return _index
        End Get
        Set(ByVal value As Integer)
            _index = value
        End Set
    End Property

    Private _item As DataRow
    ''' <summary>
    ''' 削除された行項目
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property Item() As DataRow
        Get
            Return _item
        End Get
        Set(ByVal value As DataRow)
            _item = value
        End Set
    End Property

#End Region

End Class
