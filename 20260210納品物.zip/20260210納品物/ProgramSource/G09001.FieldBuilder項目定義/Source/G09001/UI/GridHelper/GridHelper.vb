﻿''' <summary>
''' GridEditコントロール編集補助部品(一覧型マスター保守専用)
''' </summary>
''' <remarks></remarks>
Public Class GridHelper
    Implements IGridHelper

#Region "変数"

    'グリッド編集補助部品
    Private WithEvents _editEntry As EditManager
    'データテーブル編集補助部品
    Private WithEvents _dataTableHelper As DataTableHelper

#End Region

#Region "コンストラクタ"

    Sub New(ByVal gridEdit As SimpleControl.GridEdit, ByVal itemInfoList As ColumnInfoListBase, ByVal maxRowCount As Integer)
        Dim newTable As DataTable = New DataTable
        InitializeGridHelper(gridEdit, itemInfoList, maxRowCount, newTable)
        SetupDefaultForeColor()
    End Sub

    Sub New(ByVal gridEdit As SimpleControl.GridEdit, ByVal itemInfoList As ColumnInfoListBase, ByVal maxRowCount As Integer, ByVal myform As DesignFormBase)
        Dim newTable As DataTable = New DataTable
        InitializeGridHelper(gridEdit, itemInfoList, maxRowCount, newTable)
        SetupDefaultForeColor(myform)
    End Sub

    Sub New(ByVal gridEdit As SimpleControl.GridEdit, ByVal itemInfoList As ColumnInfoListBase, ByVal maxRowCount As Integer, ByVal newTable As DataTable)

        InitializeGridHelper(gridEdit, itemInfoList, maxRowCount, newTable)
        SetupDefaultForeColor()
    End Sub

    Sub New(ByVal gridEdit As SimpleControl.GridEdit, ByVal itemInfoList As ColumnInfoListBase, ByVal maxRowCount As Integer, ByVal newTable As DataTable, ByVal myform As DesignFormBase)

        InitializeGridHelper(gridEdit, itemInfoList, maxRowCount, newTable)
        SetupDefaultForeColor(myform)
    End Sub

    Private Sub InitializeGridHelper(ByVal gridEdit As SimpleControl.GridEdit, ByVal itemInfoList As ColumnInfoListBase, ByVal maxRowCount As Integer, ByVal newTable As DataTable)

        _editEntry = New EditManager(GridEdit)
        _editEntry.ItemInfoList = itemInfoList
        _editEntry.GridEdit.DataTable = newTable
        _limitRowCount = maxRowCount

        _dataTableHelper = New DataTableHelper(_editEntry.GridEdit.DataTable)
        'グリッドの最初の列。通常の一覧はRowState があるので "1" になっている。
        _firstColIndex = 0

    End Sub
#End Region

#Region "プロパティ"

    Private _limitRowCount As Integer
    ''' <summary>
    ''' 入力制限行カウント
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks>グリッドに追加できる行数の限界値</remarks>
    Public Property LimitRowCount() As Integer Implements IGridHelper.LimitRowCount
        Get
            Return _limitRowCount
        End Get
        Set(ByVal value As Integer)
            _limitRowCount = value
        End Set
    End Property

    Private _foreColorLink As Boolean
    ''' <summary>
    ''' 前景色の変更をヘルパー連動する判定
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property ForeColorLink() As Boolean Implements IGridHelper.ForeColorLink
        Get
            Return _foreColorLink
        End Get
        Set(ByVal value As Boolean)
            _foreColorLink = value
        End Set
    End Property

    Private _foreColorDeletedRow As System.Drawing.Color
    ''' <summary>
    ''' 削除対象行の前景色
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property ForeColorDeletedRow() As System.Drawing.Color Implements IGridHelper.ForeColorDeletedRow
        Get
            Return _foreColorDeletedRow
        End Get
        Set(ByVal value As System.Drawing.Color)
            _foreColorDeletedRow = value
        End Set
    End Property

    Private _foreColorModified As System.Drawing.Color
    ''' <summary>
    ''' 修正されたセルの前景色
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property ForeColorModified() As System.Drawing.Color Implements IGridHelper.ForeColorModified
        Get
            Return _foreColorModified
        End Get
        Set(ByVal value As System.Drawing.Color)
            _foreColorModified = value
        End Set
    End Property

    Private _foreColorUnchanged As System.Drawing.Color
    ''' <summary>
    ''' 変更なしのセルの前景色
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property ForeColorUnchanged() As System.Drawing.Color Implements IGridHelper.ForeColorUnchanged
        Get
            Return _foreColorUnchanged
        End Get
        Set(ByVal value As System.Drawing.Color)
            _foreColorUnchanged = value
        End Set
    End Property

    Private _foreColorFixedCol As System.Drawing.Color
    ''' <summary>
    ''' 固定列セルの前景色
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property ForeColorFixedCol() As System.Drawing.Color Implements IGridHelper.ForeColorFixedCol
        Get
            Return _foreColorFixedCol
        End Get
        Set(ByVal value As System.Drawing.Color)
            _foreColorFixedCol = value
        End Set
    End Property

    Private _UseCurrentCellColor As Boolean
    ''' <summary>
    ''' 現在編集中セルに色設定を行うか
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property UseCurrentCellColor() As Boolean
        Get
            Return _UseCurrentCellColor
        End Get
        Set(ByVal value As Boolean)
            _UseCurrentCellColor = value
        End Set
    End Property

    Private _backColorCurrentRow As System.Drawing.Color
    ''' <summary>
    ''' 現在行背景色
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property BackColorCurrentRow() As System.Drawing.Color
        Get
            Return _backColorCurrentRow
        End Get
        Set(ByVal value As System.Drawing.Color)
            _backColorCurrentRow = value
        End Set
    End Property

    ''' <summary>
    ''' [読取専用]行状態リスト
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property RowStateList() As List(Of DataRowState) Implements IGridHelper.RowStateList
        Get
            Return _dataTableHelper.RowState
        End Get
    End Property

    ''' <summary>
    ''' [読取専用]削除対象行リスト
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property DeletedRows() As List(Of DeletedRow) Implements IGridHelper.DeletedRows
        Get
            Return _dataTableHelper.DeletedRow
        End Get
    End Property

    Private _firstColIndex As Integer
    ''' <summary>
    ''' 最初のカラムインデックス
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property FirstColIndex() As Integer
        Get
            Return _firstColIndex
        End Get
        Set(ByVal value As Integer)
            _firstColIndex = value
        End Set
    End Property

#End Region

#Region "メソッド"

    ''' <summary>
    ''' グリッドヘルパーを初期設定する
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub SetupGridHelper() Implements IGridHelper.SetupGridHelper

        _editEntry.SetupEdit()

    End Sub

    ''' <summary>
    ''' 行の編集をキャンセルする
    ''' </summary>
    ''' <param name="rowIndex">行番号</param>
    ''' <remarks>初期表示状態に戻す</remarks>
    Public Sub CancelEditRow(ByVal rowIndex As Integer) Implements IGridHelper.CancelEditRow

        Select Case _editEntry.GetDataRowState(rowIndex)
            Case DataRowState.Deleted
                '削除する前が修正行の場合は修正行に戻すため、２回取消を行なう
                _editEntry.RejectChangeRow(rowIndex)
                _editEntry.RejectChangeRow(rowIndex)
            Case DataRowState.Modified, DataRowState.Unchanged
                _editEntry.RejectChangeRow(rowIndex)
            Case DataRowState.Added
                '登録の場合は行を削除する
                _editEntry.RejectChangeRow(rowIndex)
            Case Else
        End Select

        'EditCellも上書きする
        _editEntry.GridEdit.CurrentEditValue = _editEntry.GetData(_editEntry.GridEdit.EditRowIndex, _editEntry.GridEdit.EditColIndex)

        ChangeRowForeColorDefault(rowIndex)
    End Sub

    ''' <summary>
    ''' 行を削除する
    ''' </summary>
    ''' <param name="rowIndex">行番号</param>
    ''' <remarks>行の状態が登録の場合、DataTableからレコードを削除する</remarks>
    Public Sub Delete(ByVal rowIndex As Integer) Implements IGridHelper.Delete

        Dim oldRowState As DataRowState = _editEntry.GridEdit.GetDataRowState(rowIndex)

        _editEntry.RemoveRow(rowIndex)

        If ForeColorLink = False OrElse oldRowState = DataRowState.Added Then Exit Sub

        ChangeRowForeColor(rowIndex, ForeColorDeletedRow)

        _editEntry.GridEdit.Update()

    End Sub

    ''' <summary>
    ''' 削除状態を取り消す
    ''' </summary>
    ''' <param name="rowIndex">行番号</param>
    ''' <remarks></remarks>
    Public Sub RevokeDelete(ByVal rowIndex As Integer) Implements IGridHelper.RevokeDelete

        If _editEntry.GetDataRowState(rowIndex) = DataRowState.Deleted Then

            _editEntry.RejectChangeRow(rowIndex)

            If ForeColorLink = False Then Exit Sub

            Dim itemCount As Integer = -1

            Dim noChangeFlag As Boolean = True

            For i As Integer = FirstColIndex To _editEntry.GridEdit.ColumnCount - 1
                Dim changeForeColor As System.Drawing.Color
                If IsColumnTypeData(i, itemCount) = True Then
                    Dim colName As String = _editEntry.GridEdit.DataTable.Columns(itemCount).ColumnName
                    Dim dtrowIndex As Integer = _editEntry.GetDataRowIndex(rowIndex)

                    If _editEntry.GridEdit.DataTable.Rows(dtrowIndex).Item(colName, DataRowVersion.Original) _
                                .Equals(_editEntry.GridEdit.DataTable.Rows(dtrowIndex).Item(colName, DataRowVersion.Current)) Then
                        If GetColnIndexFromColName(colName) <= _editEntry.GridEdit.ColsFixed - 1 Then
                            changeForeColor = GetFixdColColor()
                        Else
                            changeForeColor = ForeColorUnchanged()
                        End If
                    Else
                        changeForeColor = ForeColorModified
                        noChangeFlag = False
                    End If

                    ChangeCellForeColor(rowIndex, GetColnIndexFromColName(colName), changeForeColor)

                End If
            Next

            If noChangeFlag = True Then
                If _editEntry.GetDataRowState(rowIndex) = DataRowState.Modified Then
                    _editEntry.AcceptChangeRow(rowIndex)
                End If
            End If

            _editEntry.GridEdit.Update()
        End If
    End Sub

    ''' <summary>
    ''' 行を挿入する
    ''' </summary>
    ''' <param name="rowIndex">行番号</param>
    ''' <returns>挿入可能判定</returns>
    ''' <remarks>最大表示行数を超える場合、Falseを返す</remarks>
    Public Function Insert(ByVal rowIndex As Integer) As Boolean Implements IGridHelper.Insert
        Dim isInsertSuccess As Boolean

        If _editEntry.GridEdit.RowCount >= LimitRowCount Then
            isInsertSuccess = False
        Else
            Dim newRow As DataRow = _editEntry.GridEdit.DataTable.NewRow
            _editEntry.CreateDefaultRow(newRow)
            Insert(rowIndex, newRow)
        End If

        Return isInsertSuccess
    End Function

    ''' <summary>
    ''' 行を挿入する(デフォルト値セット用)
    ''' </summary>
    ''' <param name="rowIndex">行番号</param>
    ''' <param name="row">行データ</param>
    ''' <returns>挿入可能判定</returns>
    ''' <remarks>最大表示行数を超える場合、Falseを返す</remarks>
    Public Function Insert(ByVal rowIndex As Integer, ByVal row As System.Data.DataRow) As Boolean Implements IGridHelper.Insert
        Dim isInsertSuccess As Boolean

        If _editEntry.GridEdit.RowCount >= LimitRowCount Then
            isInsertSuccess = False
        Else
            _editEntry.AddRow(rowIndex)
            If rowIndex = -1 Then rowIndex = _editEntry.GridEdit.RowCount - 1

            _editEntry.GridEdit.SetTableData(_editEntry.GridEdit.GetDataRowIndex(rowIndex), row)

            ChangeRowForeColorAdded(rowIndex, ForeColorModified)
        End If

        Return isInsertSuccess
    End Function

    ''' <summary>
    ''' 同一の値が存在するかのチェック
    ''' </summary>
    ''' <param name="targetValue">対象の値</param>
    ''' <param name="columnName">列名</param>
    ''' <returns>存在判定</returns>
    ''' <remarks></remarks>
    Public Function IsSameValue(ByVal targetValue As Object, ByVal columnName As String) As Boolean Implements IGridHelper.IsSameValue

        Dim isExist As Boolean = False
        Dim targetColIndex As Integer = GetColnIndexFromColName(columnName)
        Dim nowRowIndex As Integer = _editEntry.GridEdit.EditRowIndex

        If targetColIndex = -1 OrElse nowRowIndex = -1 Then Exit Function

        Dim sameValueRowIndex As Integer

        sameValueRowIndex = _editEntry.GridEdit.SearchRow(0, targetColIndex, 0, targetValue, Grid.SearchConditionType.Equal, False)

        If sameValueRowIndex < 0  Then
            isExist = False
        ElseIf sameValueRowIndex <> nowRowIndex Then
            isExist = True
        ElseIf sameValueRowIndex = nowRowIndex AndAlso _
               sameValueRowIndex < _editEntry.GridEdit.RowCount - 1 Then

            sameValueRowIndex = _editEntry.GridEdit.SearchRow(sameValueRowIndex + 1, targetColIndex, 0, targetValue, Grid.SearchConditionType.Equal, False)

            If sameValueRowIndex < 0 Then
                isExist = False
            Else
                isExist = True
            End If
        End If

        Return isExist
    End Function

    ''' <summary>
    ''' 同一キーが存在するかのチェック
    ''' </summary>
    ''' <param name="targetKey">キー項目</param>
    ''' <returns>存在判定</returns>
    ''' <remarks></remarks>
    Public Function IsSameKey(ByVal ParamArray targetKey() As String) As Boolean Implements IGridHelper.IsSameKey
        Dim isExist As Boolean = False
        isExist = SearchSameKey(targetKey)
        Return isExist
    End Function

    ''' <summary>
    ''' 前行項目値コピー
    ''' </summary>
    ''' <param name="currentRowIndex">行番号</param>
    ''' <param name="currentColIndex">列番号</param>
    ''' <remarks></remarks>
    Public Sub CopyPrevRowItem(ByVal currentRowIndex As Integer, ByVal currentColIndex As Integer) Implements IGridHelper.CopyPrevRowItem

        CopyItem(currentRowIndex, currentColIndex)

        CurrentEditUpdate()
    End Sub

    ''' <summary>
    ''' 前行項目値コピー
    ''' </summary>
    ''' <param name="currentRowIndex">行番号</param>
    ''' <param name="currentColName">列名</param>
    ''' <remarks></remarks>
    Public Sub CopyPrevRowItem(ByVal currentRowIndex As Integer, ByVal currentColName As String) Implements IGridHelper.CopyPrevRowItem

        CopyItem(currentRowIndex, currentColName)

        CurrentEditUpdate()
    End Sub

    ''' <summary>
    ''' 前行項目値コピー
    ''' </summary>
    ''' <param name="currentRowIndex">行番号</param>
    ''' <param name="addCopyItemIndex">追加コピー列番号()</param>
    ''' <remarks></remarks>
    Public Sub CopyPrevRowItem(ByVal currentRowIndex As Integer, ByVal ParamArray addCopyItemIndex() As Integer) Implements IGridHelper.CopyPrevRowItem

        Dim i As Integer
        For Each i In addCopyItemIndex
            CopyItem(currentRowIndex, i)
        Next
        CurrentEditUpdate()
    End Sub

    ''' <summary>
    ''' 前行項目値コピー
    ''' </summary>
    ''' <param name="currentRowIndex">行番号</param>
    ''' <param name="addCopyItemName">追加コピー列名()</param>
    ''' <remarks></remarks>
    Public Sub CopyPrevRowItem(ByVal currentRowIndex As Integer, ByVal ParamArray addCopyItemName() As String) Implements IGridHelper.CopyPrevRowItem


        Dim i As String = Nothing
        For Each i In addCopyItemName
            CopyItem(currentRowIndex, i)
        Next

        CurrentEditUpdate()
    End Sub

    ''' <summary>
    ''' 前行項目値コピー(範囲指定)
    ''' </summary>
    ''' <param name="startRowIndex">開始行番号</param>
    ''' <param name="endRowIndex">終了行番号</param>
    ''' <param name="currentColIndex">列番号</param>
    ''' <remarks></remarks>
    Public Sub RangeCopyPrevRowItem(ByVal startRowIndex As Integer, ByVal endRowIndex As Integer, ByVal currentColIndex As Integer) Implements IGridHelper.RangeCopyPrevRowItem
        If startRowIndex < 1 OrElse endRowIndex < 1 Then Exit Sub
        If startRowIndex > endRowIndex Then Exit Sub

        Dim copiedItem As Object = Nothing
        For i As Integer = startRowIndex To endRowIndex
            CopyItem(i, currentColIndex, copiedItem)
        Next
        CurrentEditUpdate()
    End Sub

    ''' <summary>
    ''' 前行項目値コピー(範囲指定)
    ''' </summary>
    ''' <param name="startRowIndex">開始行番号</param>
    ''' <param name="endRowIndex">終了行番号</param>
    ''' <param name="currentColName">列名</param>
    ''' <remarks></remarks>
    Public Sub RangeCopyPrevRowItem(ByVal startRowIndex As Integer, ByVal endRowIndex As Integer, ByVal currentColName As String) Implements IGridHelper.RangeCopyPrevRowItem
        If startRowIndex < 1 OrElse endRowIndex < 1 Then Exit Sub
        If startRowIndex > endRowIndex Then Exit Sub

        Dim copiedItem As Object = Nothing
        For i As Integer = startRowIndex To endRowIndex
            CopyItem(i, currentColName, copiedItem)
        Next
        CurrentEditUpdate()
    End Sub

    ''' <summary>
    ''' 前行項目値コピー(範囲指定)
    ''' </summary>
    ''' <param name="startRowIndex">開始行番号</param>
    ''' <param name="endRowIndex">終了行番号</param>
    ''' <param name="addCopyItemIndex">コピー列インデックス()</param>
    ''' <remarks></remarks>
    Public Sub RangeCopyPrevRowItem(ByVal startRowIndex As Integer, ByVal endRowIndex As Integer, ByVal ParamArray addCopyItemIndex() As Integer) Implements IGridHelper.RangeCopyPrevRowItem
        If startRowIndex < 1 OrElse endRowIndex < 1 Then Exit Sub
        If startRowIndex > endRowIndex Then Exit Sub

        Dim col As Integer
        For Each col In addCopyItemIndex
            Dim copiedItem As Object = Nothing
            For i As Integer = startRowIndex To endRowIndex
                CopyItem(i, col, copiedItem)
            Next
        Next
        CurrentEditUpdate()
    End Sub

    ''' <summary>
    ''' 前行項目値コピー(範囲指定)
    ''' </summary>
    ''' <param name="startRowIndex">開始行番号</param>
    ''' <param name="endRowIndex">終了行番号</param>
    ''' <param name="addCopyItemName">コピー列名()</param>
    ''' <remarks></remarks>
    Public Sub RangeCopyPrevRowItem(ByVal startRowIndex As Integer, ByVal endRowIndex As Integer, ByVal ParamArray addCopyItemName() As String) Implements IGridHelper.RangeCopyPrevRowItem
        If startRowIndex < 1 OrElse endRowIndex < 1 Then Exit Sub
        If startRowIndex > endRowIndex Then Exit Sub

        Dim col As String
        For Each col In addCopyItemName
            Dim copiedItem As Object = Nothing
            For i As Integer = startRowIndex To endRowIndex
                CopyItem(i, col, copiedItem)
            Next
        Next
        CurrentEditUpdate()
    End Sub

    ''' <summary>
    ''' セルの前景色を変更する
    ''' </summary>
    ''' <param name="rowIndex"></param>
    ''' <param name="colName"></param>
    ''' <param name="color"></param>
    ''' <remarks></remarks>
    Public Sub ChangeCellForeColor(ByVal rowIndex As Integer, ByVal colName As String, ByVal color As System.Drawing.Color) Implements IGridHelper.ChangeCellForeColor

        Dim colindex As Integer = -1
        For i As Integer = FirstColIndex To _editEntry.GridEdit.ColumnCount - 1
            If _editEntry.GridEdit.Columns(i).Name.Equals(colName) Then
                colindex = i
            End If
        Next
        If colindex = -1 Then Exit Sub
        _editEntry.GetDisplayCellInfo(rowIndex, colIndex).ForeColor = color
    End Sub

    ''' <summary>
    ''' セルの前景色を変更する
    ''' </summary>
    ''' <param name="rowIndex"></param>
    ''' <param name="colIndex"></param>
    ''' <param name="color"></param>
    ''' <remarks></remarks>
    Public Sub ChangeCellForeColor(ByVal rowIndex As Integer, ByVal colIndex As Integer, ByVal color As System.Drawing.Color) Implements IGridHelper.ChangeCellForeColor
        _editEntry.GetDisplayCellInfo(rowIndex, colIndex).ForeColor = color
    End Sub

    ''' <summary>
    ''' 行の前景色を変更する
    ''' </summary>
    ''' <param name="rowIndex"></param>
    ''' <param name="color"></param>
    ''' <remarks></remarks>
    Public Sub ChangeRowForeColor(ByVal rowIndex As Integer, ByVal color As System.Drawing.Color) Implements IGridHelper.ChangeRowForeColor
        For i As Integer = FirstColIndex To _editEntry.GridEdit.ColumnCount - 1
            ChangeCellForeColor(rowIndex, i, color)
        Next
    End Sub

    ''' <summary>
    ''' 行の前景色を初期値に戻す
    ''' </summary>
    ''' <param name="rowIndex"></param>
    ''' <remarks></remarks>
    Public Sub ChangeRowForeColorDefault(ByVal rowIndex As Integer)
        For i As Integer = FirstColIndex To _editEntry.GridEdit.ColumnCount - 1
            If _editEntry.GridEdit.Columns(i).ColumnType = GridColumnType.Data AndAlso _
               i <= _editEntry.GridEdit.ColsFixed - 1 Then
                ChangeCellForeColor(rowIndex, i, ForeColorFixedCol)
            Else
                ChangeCellForeColor(rowIndex, i, ForeColorUnchanged)
            End If
        Next
    End Sub

    ''' <summary>
    ''' データテーブルをセットする
    ''' </summary>
    ''' <param name="dataTable">データテーブル</param>
    ''' <remarks></remarks>
    Public Sub SetDataTable(ByVal dataTable As System.Data.DataTable) Implements IGridHelper.SetDataTable
        _editEntry.GridEdit.DataTable = dataTable
        _dataTableHelper = Nothing
        _dataTableHelper = New DataTableHelper(_editEntry.GridEdit.DataTable)

    End Sub

    ''' <summary>
    ''' 行の編集をキャンセルする
    ''' </summary>
    ''' <param name="rowIndex">行番号</param>
    ''' <remarks>初期表示状態に戻す</remarks>
    Public Sub ChangeRowStateAdded(ByVal rowIndex As Integer) Implements IGridHelper.ChangeRowStateAdded

        Select Case _editEntry.GetDataRowState(rowIndex)
            Case DataRowState.Deleted
                _editEntry.RejectChangeRow(rowIndex)
                _editEntry.SetAddedRow(rowIndex)

            Case DataRowState.Modified
                _editEntry.AcceptChangeRow(rowIndex)
                _editEntry.SetAddedRow(rowIndex)

            Case DataRowState.Unchanged
                _editEntry.SetAddedRow(rowIndex)
            Case DataRowState.Added
                'なにもしない
                Return
            Case Else
        End Select
        ChangeRowForeColor(rowIndex, ForeColorModified)
    End Sub

#End Region

#Region "内部メソッド"

    ''' <summary>
    ''' デフォルトの色情報を設定する。
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetupDefaultForeColor(Optional ByVal myform As DesignFormBase = Nothing)
        _foreColorLink = True
        _editEntry.GridEdit.UseCurrentRowColor = True

        'Defaultセット
        _foreColorFixedCol = _editEntry.GridEdit.ForeColorFixed
        _foreColorUnchanged = _editEntry.GridEdit.ForeColor
        _foreColorModified = Drawing.Color.Blue
        _foreColorDeletedRow = Drawing.Color.DarkGray

        If Not myform Is Nothing Then
            Dim 背景色 As Integer = 0
            Dim 文字色 As Integer = 0
            Dim 境界線色 As Integer = 0

            If myform.GetBySetteiNam("入力域", 背景色, 文字色, 境界線色) = True Then
                If Not 文字色 = -1 Then
                    _foreColorUnchanged = ExchangeToSystemDrawingColor(文字色)
                End If
            End If

            If myform.GetBySetteiNam("項目見出し", 背景色, 文字色, 境界線色) = True Then
                If Not 文字色 = -1 Then
                    _foreColorFixedCol = ExchangeToSystemDrawingColor(文字色)
                End If
            End If
        End If
    End Sub

    ''' <summary>
    ''' 表示上の列インデックスからデータの列インデックスを取得し、カラムのデータタイプを判定する
    ''' </summary>
    ''' <param name="gridColIndex">カラム</param>
    ''' <param name="dataColIndex"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function IsColumnTypeData(ByVal gridColIndex As Integer, ByRef dataColIndex As Integer) As Boolean
        Dim isTypeData As Boolean
        If _editEntry.GridEdit.Columns(gridColIndex).ColumnType = GridColumnType.Data Then
            dataColIndex = GetDBColumnIndex(gridColIndex)
            isTypeData = True
        Else
            isTypeData = False
        End If
        Return isTypeData
    End Function

    ''' <summary>
    ''' 新規行の文字色を設定する。
    ''' </summary>
    ''' <param name="rowIndex"></param>
    ''' <param name="color"></param>
    ''' <remarks></remarks>
    Private Sub ChangeRowForeColorAdded(ByVal rowIndex As Integer, ByVal color As System.Drawing.Color)
        For i As Integer = 0 To _editEntry.GridEdit.ColumnCount - 1
            If _editEntry.GridEdit.Columns(i).ColumnType = GridColumnType.Data Then
                ChangeCellForeColor(rowIndex, i, color)
            End If
        Next
    End Sub

    ''' <summary>
    ''' グリッドのカラム名からカラムインデックスを取得する。
    ''' </summary>
    ''' <param name="targetColName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetColnIndexFromColName(ByVal targetColName As String) As Integer

        For i As Integer = 0 To _editEntry.GridEdit.ColumnCount - 1
            If targetColName = _editEntry.GridEdit.Columns(i).Name Then
                Return i
            End If
        Next

        Return -1
    End Function

    ''' <summary>
    ''' グリッドの列インデックスからデータテーブルの列インデックスを取得する。
    ''' </summary>
    ''' <param name="targetColIndex"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetDBColumnIndex(ByVal targetColIndex As Integer) As Integer
        Dim colName As String = ""
        colName = _editEntry.GridEdit.Columns(targetColIndex).Name

        If _editEntry.GridEdit.DataTable.Columns.Contains(colName) = True Then
            Return _editEntry.GridEdit.DataTable.Columns.IndexOf(colName)
        End If

        Return -1
    End Function

    ''' <summary>
    ''' 前項目をコピーする
    ''' </summary>
    ''' <param name="currentRowIndex">行番号</param>
    ''' <param name="currentColIndex">列番号</param>
    ''' <param name="copiedItem">コピーするオブジェクト</param>
    ''' <remarks></remarks>
    Private Sub CopyItem(ByVal currentRowIndex As Integer, ByVal currentColIndex As Integer, Optional ByRef copiedItem As Object = Nothing)
        If currentRowIndex < 1 Then Exit Sub

        If _editEntry.GetDataRowState(currentRowIndex) = DataRowState.Deleted Then
            Exit Sub
        End If

        If _editEntry.GetDataRowState(currentRowIndex - 1) = DataRowState.Deleted Then
            Dim targetRow As DataRow = _dataTableHelper.GetDeletedRow(_editEntry.GetDataRowIndex(currentRowIndex - 1))
            If targetRow Is Nothing Then Exit Sub

            Dim colName As String = _editEntry.GridEdit.Columns(currentColIndex).Name
            Dim copingItem As Object = targetRow.Item(colName)
            If _editEntry.GetDataRowState(currentRowIndex) = DataRowState.Deleted Then
                If copiedItem IsNot Nothing Then
                    Exit Sub
                Else
                    copiedItem = copingItem
                    Exit Sub
                End If
            Else
                If copiedItem Is Nothing Then
                    copiedItem = copingItem
                End If
                _editEntry.SetData(currentRowIndex, currentColIndex, copiedItem)
                ChangeCellForeColor(currentRowIndex, currentColIndex, ForeColorModified)
                Exit Sub
            End If
        Else
            Dim copingItem As Object = _editEntry.GetData(currentRowIndex - 1, currentColIndex)
            If _editEntry.GetDataRowState(currentRowIndex) = DataRowState.Deleted Then
                If copiedItem IsNot Nothing Then
                    Exit Sub
                Else
                    copiedItem = copingItem
                    Exit Sub
                End If
            Else
                If copiedItem Is Nothing Then
                    copiedItem = copingItem
                End If
                _editEntry.SetData(currentRowIndex, currentColIndex, copiedItem)
                ChangeCellForeColor(currentRowIndex, currentColIndex, ForeColorModified)
                _editEntry.GridEdit.Update()
                Exit Sub
            End If
        End If
    End Sub


    ''' <summary>
    ''' 前項目をコピーする
    ''' </summary>
    ''' <param name="currentRowIndex">行番号</param>
    ''' <param name="currentColName">列名</param>
    ''' <param name="copiedItem">コピーするオブジェクト</param>
    ''' <remarks></remarks>
    Private Sub CopyItem(ByVal currentRowIndex As Integer, ByVal currentColName As String, Optional ByRef copiedItem As Object = Nothing)
        If currentRowIndex < 1 Then Exit Sub

        If _editEntry.GetDataRowState(currentRowIndex) = DataRowState.Deleted Then
            Exit Sub
        End If

        If _editEntry.GetDataRowState(currentRowIndex - 1) = DataRowState.Deleted Then
            Dim targetRow As DataRow = _dataTableHelper.GetDeletedRow(_editEntry.GetDataRowIndex(currentRowIndex - 1))
            If targetRow Is Nothing Then Exit Sub

            Dim copingItem As Object = targetRow.Item(currentColName)
            If _editEntry.GetDataRowState(currentRowIndex) = DataRowState.Deleted Then
                If copiedItem IsNot Nothing Then
                    Exit Sub
                Else
                    copiedItem = copingItem
                    Exit Sub
                End If
            Else
                If copiedItem Is Nothing Then
                    copiedItem = copingItem
                End If
                _editEntry.SetData(currentRowIndex, currentColName, copiedItem)
                ChangeCellForeColor(currentRowIndex, currentColName, ForeColorModified)
                Exit Sub
            End If
        Else
            Dim copingItem As Object = _editEntry.GetData(currentRowIndex - 1, currentColName)
            If _editEntry.GetDataRowState(currentRowIndex) = DataRowState.Deleted Then
                If copiedItem IsNot Nothing Then
                    Exit Sub
                Else
                    copiedItem = copingItem
                    Exit Sub
                End If
            Else
                If copiedItem Is Nothing Then
                    copiedItem = copingItem
                End If
                _editEntry.SetData(currentRowIndex, currentColName, copiedItem)
                ChangeCellForeColor(currentRowIndex, currentColName, ForeColorModified)
                Exit Sub
            End If
        End If
    End Sub

    ''' <summary>
    ''' 現在値をDataTable値で上書き[前行項目コピー専用]
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub CurrentEditUpdate()
        _editEntry.GridEdit.CurrentEditValue = _editEntry.GetData(_editEntry.GridEdit.EditRowIndex, _editEntry.GridEdit.EditColIndex)
    End Sub

    ''' <summary>
    ''' Long型の値をRGB値(System.Drawing.Color)に変換する
    ''' </summary>
    ''' <param name="colorCode">10進コード</param>
    ''' <returns>色</returns>
    ''' <remarks></remarks>
    Private Function ExchangeToSystemDrawingColor(ByVal colorCode As Long) As System.Drawing.Color

        Dim red As Integer
        Dim green As Integer
        Dim blue As Integer

        red = CInt((colorCode And &HFF&))
        green = CInt((colorCode And &HFF00&) / &H100&)
        blue = CInt((colorCode And &HFF0000) / &H10000)

        Return System.Drawing.Color.FromArgb(red, green, blue)

    End Function

    ''' <summary>
    ''' 同一のKEYが存在するかのチェック
    ''' </summary>
    ''' <param name="targetValue">対象の値</param>
    ''' <returns>存在判定</returns>
    ''' <remarks></remarks>
    Private Function SearchSameKey(ByVal targetValue() As String) As Boolean

        Dim isExist As Boolean = False
        Dim nowRowIndex As Integer = _editEntry.GridEdit.EditRowIndex

        Dim keyList() As IColumnInfo = _editEntry.ItemInfoList.GetKeyItemInfoList
        If keyList.Length = 0 Then Return False
        If keyList.Length <> targetValue.Length Then Return False

        If nowRowIndex = -1 Then Exit Function

        Dim serchCondition(keyList.Length - 1) As OSK.X1.Foundation.Controls.Grid.Common.SearchCondition    'X1変換Tool-20160427

        For i As Integer = 0 To keyList.Length - 1
            Dim jyoken As New OSK.X1.Foundation.Controls.Grid.Common.SearchCondition    'X1変換Tool-20160427
            jyoken.ColIndex = GetColnIndexFromColName(keyList(i).Name)
            jyoken.Data = targetValue(i)
            jyoken.Relation = Grid.SearchConditionType.Equal
            serchCondition(i) = jyoken
        Next

        Dim sameValueRowIndex As Integer

        sameValueRowIndex = _editEntry.GridEdit.SearchRowMulti(0, serchCondition, 0, False)

        If sameValueRowIndex < 0 Then
            isExist = False
        ElseIf sameValueRowIndex <> nowRowIndex Then
            isExist = True
        ElseIf sameValueRowIndex = nowRowIndex AndAlso _
               sameValueRowIndex < _editEntry.GridEdit.RowCount - 1 Then

            sameValueRowIndex = _editEntry.GridEdit.SearchRowMulti(sameValueRowIndex + 1, serchCondition, 0, False)

            If sameValueRowIndex < 0 Then
                isExist = False
            Else
                isExist = True
            End If
        End If

        Return isExist
    End Function

    ''' <summary>
    ''' ReadOnlyをセット
    ''' </summary>
    ''' <param name="rowIndex">行番号</param>
    ''' <param name="colIndex">列番号</param>
    ''' <param name="isReadOnly">読取状態設定</param>
    ''' <param name="dataColIndex"></param>
    ''' <remarks></remarks>
    Private Sub SetReadOnly(ByVal rowIndex As Integer, ByVal colIndex As Integer, ByVal isReadOnly As OSK.X1.Foundation.Controls.Grid.Common.Boolean, ByRef dataColIndex As Integer)    'X1変換Tool-20160427

        If IsColumnTypeData(colIndex, dataColIndex) = True Then
            Dim colName As String = _editEntry.GridEdit.DataTable.Columns(dataColIndex).ColumnName
            Dim colInfo As IColumnInfo = _editEntry.ItemInfoList.GetItemInfo(colName)

            'チェックボックス表示用データ対応
            If colInfo Is Nothing Then Exit Sub

            If colInfo.IsKey = True Then
                _editEntry.GetDisplayCellInfo(rowIndex, colIndex).ReadOnly = isReadOnly
            End If
        End If
    End Sub

    Private Function GetFixdColColor() As System.Drawing.Color
        If ForeColorFixedCol = Nothing Then
            Return _editEntry.GridEdit.ForeColorFixed
        End If
    End Function

#End Region

    ''' <summary>
    ''' 削除行を表示する
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks>DataTableでは削除する前の行の値を表示できないため</remarks>
    Private Sub _editEntry_RaiseEventDisplayDeleteCell(ByVal sender As Object, ByVal e As Grid.Common.DisplayDeleteCellEventArgs) Handles _editEntry.RaiseEventDisplayDeleteCell
        For i As Integer = 0 To _dataTableHelper.DeletedRow.Count - 1
            If _dataTableHelper.DeletedRow(i).Index = e.RowIndex Then
                e.Data = _dataTableHelper.DeletedRow(i).Item.Item(e.ColIndex)
                Exit For
            End If
        Next
    End Sub

End Class
