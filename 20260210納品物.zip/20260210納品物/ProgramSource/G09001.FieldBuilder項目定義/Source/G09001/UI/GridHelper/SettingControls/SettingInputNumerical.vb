﻿Public Class SettingInputNumerical

#Region "コンストラクタ"

    Sub New(ByVal commaDisplay As Boolean, ByVal integerDigits As Integer, ByVal decimalDigits As Integer)
        _commaDisplay = commaDisplay
        _decimalDigits = decimalDigits
        _integerDigits = integerDigits
    End Sub

#End Region

#Region "プロパティ"

    Private _commaDisplay As Boolean
    ''' <summary>
    ''' カンマ表示判定
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property CommaDisplay() As Boolean
        Get
            Return _commaDisplay
        End Get
        Set(ByVal value As Boolean)
            _commaDisplay = value
        End Set
    End Property

    Private _decimalDigits As Integer
    ''' <summary>
    ''' 小数部桁数
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property DecimalDigits() As Integer
        Get
            Return _decimalDigits
        End Get
        Set(ByVal value As Integer)
            _decimalDigits = value
        End Set
    End Property

    Private _integerDigits As Integer
    ''' <summary>
    ''' 整数部桁数
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property IntegerDigits() As Integer
        Get
            Return _integerDigits
        End Get
        Set(ByVal value As Integer)
            _integerDigits = value
        End Set
    End Property

    ''' <summary>
    ''' Null値入力許可
    ''' </summary>
    ''' <remarks></remarks>
    Private _permitNull As Boolean
    Public Property PermitNull() As Boolean
        Get
            Return _permitNull
        End Get
        Set(ByVal value As Boolean)
            _permitNull = value
        End Set
    End Property

#End Region

End Class
