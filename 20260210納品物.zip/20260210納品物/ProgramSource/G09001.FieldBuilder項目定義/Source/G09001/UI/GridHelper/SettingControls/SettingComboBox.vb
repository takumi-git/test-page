﻿''' <summary>
''' コンボボックス設定
''' </summary>
''' <remarks></remarks>
Public Class SettingComboBox

    Sub New(ByVal displayRowCount As Integer, ByVal style As OSK.X1.Foundation.Controls.ComboBox.StyleType, ByVal listData As String())    'X1変換Tool-20160427
        _displayRowCount = displayRowCount
        _style = style
        _ListData = listData
    End Sub

#Region "プロパティ"
    Private _displayRowCount As Integer
    ''' <summary>
    ''' 表示行数
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property DisplayRowCount() As Integer
        Get
            Return _displayRowCount
        End Get
        Set(ByVal value As Integer)
            _displayRowCount = value
        End Set
    End Property

    Private _style As OSK.X1.Foundation.Controls.ComboBox.StyleType    'X1変換Tool-20160427
    ''' <summary>
    ''' スタイル(DropDown/DropDownList)
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property Style() As OSK.X1.Foundation.Controls.ComboBox.StyleType    'X1変換Tool-20160427
        Get
            Return _style
        End Get
        Set(ByVal value As OSK.X1.Foundation.Controls.ComboBox.StyleType)    'X1変換Tool-20160427
            _style = value
        End Set
    End Property

    Private _ListData As String()
    Public Property ListData() As String()
        Get
            Return _ListData
        End Get
        Set(ByVal value As String())
            _ListData = value
        End Set
    End Property


#End Region

End Class
