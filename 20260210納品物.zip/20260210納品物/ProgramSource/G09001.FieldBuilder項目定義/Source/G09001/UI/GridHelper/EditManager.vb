﻿''' <summary>
''' グリッド編集補助
''' </summary>
''' <remarks></remarks>
Public Class EditManager

    Private WithEvents _gridEdit As SimpleControl.GridEdit

#Region "コンストラクタ"

    Sub New(ByVal gridEdit As SimpleControl.GridEdit)
        _gridEdit = gridEdit
    End Sub

#End Region

#Region "プロパティ"

    ''' <summary>
    ''' グリッドエディット
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property GridEdit() As SimpleControl.GridEdit
        Get
            Return _gridEdit
        End Get
        Set(ByVal value As SimpleControl.GridEdit)
            _gridEdit = value
        End Set
    End Property

    Private _itemInfoList As ColumnInfoListBase
    ''' <summary>
    ''' 項目情報一覧
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property ItemInfoList() As ColumnInfoListBase
        Get
            Return _itemInfoList
        End Get
        Set(ByVal value As ColumnInfoListBase)
            _itemInfoList = value
        End Set
    End Property

#End Region

#Region "メソッド"

    ''' <summary>
    ''' グリッドエディットを初期設定する
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub SetupEdit()

        InitEdit()

    End Sub

    ''' <summary>
    ''' 拡大する
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub ZoomUp()
        _gridEdit.ZoomUp()
    End Sub

    ''' <summary>
    ''' 縮小する
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub ZoomDown()
        _gridEdit.ZoomDown()
    End Sub

    ''' <summary>
    ''' 空のDataRowを作成する。
    ''' </summary>
    ''' <param name="defaultRow">行情報</param>
    ''' <remarks></remarks>
    Public Sub CreateDefaultRow(ByRef defaultRow As DataRow)

        If defaultRow Is Nothing Then Exit Sub

        Dim item() As IColumnInfo = ItemInfoList.GetItemInfoList
        Dim targetItem As IColumnInfo = Nothing
        Dim itemCount As Integer = -1

        For i As Integer = 0 To item.Length - 1
            If Not item(i).ControlKind = ControlKindType.状態 Then
                itemCount += 1
                targetItem = ItemInfoList.GetItemInfo(defaultRow.Table.Columns(itemCount).ColumnName)
                defaultRow.Item(itemCount) = targetItem.DefaultValue
            End If
        Next

    End Sub

    ''' <summary>
    ''' 行挿入
    ''' </summary>
    ''' <param name="targetRow">行番号</param>
    ''' <remarks></remarks>
    Public Sub AddRow(ByVal targetRow As Integer)
        _gridEdit.AddRow(targetRow, 1)
    End Sub

    ''' <summary>
    ''' 行削除
    ''' </summary>
    ''' <param name="targetRow">行番号</param>
    ''' <remarks></remarks>
    Public Sub RemoveRow(ByVal targetRow As Integer)
        _gridEdit.RemoveRow(targetRow)
    End Sub

    ''' <summary>
    ''' 行の編集状態を取得
    ''' </summary>
    ''' <param name="targetRow">行番号</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetDataRowState(ByVal targetRow As Integer) As System.Data.DataRowState
        Return _gridEdit.GetDataRowState(targetRow)
    End Function

    ''' <summary>
    ''' セルのデータを取得する
    ''' </summary>
    ''' <param name="targetRow">行番号</param>
    ''' <param name="targetCol">列番号</param>
    ''' <returns>対象セルのデータ(Object)</returns>
    ''' <remarks></remarks>
    Public Function GetData(ByVal targetRow As Integer, ByVal targetCol As Integer) As Object
        Return _gridEdit.GetData(targetRow, targetCol)
    End Function

    ''' <summary>
    ''' セルのデータを取得する
    ''' </summary>
    ''' <param name="targetRow">行番号</param>
    ''' <param name="targetColName">列名</param>
    ''' <returns>対象セルのデータ(Object)</returns>
    Public Function GetData(ByVal targetRow As Integer, ByVal targetColName As String) As Object
        Return _gridEdit.GetData(targetRow, targetColName)
    End Function

    ''' <summary>
    ''' セルにデータをセットする。
    ''' </summary>
    ''' <param name="targetRow">行番号</param>
    ''' <param name="targetCol">列番号</param>
    ''' <param name="data">セルのデータ(Object)</param>
    ''' <remarks></remarks>
    Public Sub SetData(ByVal targetRow As Integer, ByVal targetCol As Integer, ByVal data As Object)
        _gridEdit.SetData(targetRow, targetCol, data)
    End Sub

    ''' <summary>
    ''' セルにデータをセットする。
    ''' </summary>
    ''' <param name="targetRow">行番号</param>
    ''' <param name="targetColName">列名</param>
    ''' <param name="data">セルのデータ(Object)</param>
    ''' <remarks></remarks>
    Public Sub SetData(ByVal targetRow As Integer, ByVal targetColName As String, ByVal data As Object)
        _gridEdit.SetData(targetRow, targetColName, data)
    End Sub

    ''' <summary>
    ''' 行の編集をロールバックする。
    ''' </summary>
    ''' <param name="targetRow">行番号</param>
    ''' <remarks></remarks>
    Public Sub RejectChangeRow(ByVal targetRow As Integer)
        _gridEdit.RejectChangeRow(targetRow)
    End Sub

    ''' <summary>
    ''' 行の編集をコミットする。
    ''' </summary>
    ''' <param name="targetRow">行番号</param>
    ''' <remarks></remarks>
    Public Sub AcceptChangeRow(ByVal targetRow As Integer)
        _gridEdit.AcceptChangeRow(targetRow)
    End Sub

    ''' <summary>
    ''' 行のインデックスからデータテーブルのインデックスを取得する
    ''' </summary>
    ''' <param name="targetRow">行番号</param>
    ''' <returns></returns>
    ''' <remarks>ソートを行った場合、グリッドとデータテーブルのインデックスがずれる為</remarks>
    Public Function GetDataRowIndex(ByVal targetRow As Integer) As Integer
        Return _gridEdit.GetDataRowIndex(targetRow)
    End Function

    ''' <summary>
    ''' グリッドセル情報の取得
    ''' </summary>
    ''' <param name="targetRow"></param>
    ''' <param name="targetCol"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetDisplayCellInfo(ByVal targetRow As Integer, ByVal targetCol As Integer) As OSK.X1.Foundation.Controls.Grid.Common.CellAttributeInfo    'X1変換Tool-20160427
        Return _gridEdit.GetDisplayCellInfo(targetRow, targetCol)
    End Function

    Public Sub SetAddedRow(ByVal targetRow As Integer)
        _gridEdit.SetAddedRow(targetRow)
    End Sub
    Public Sub SetModifiedRow(ByVal targetRow As Integer)
        _gridEdit.SetModifiedRow(targetRow)
    End Sub
#End Region

#Region "内部メソッド"

    ''' <summary>
    ''' グリッドの初期化
    ''' </summary>
    ''' <remarks>カラムリストからカラムを生成</remarks>
    Private Sub InitEdit()

        Dim list() As IColumnInfo
        Dim count As Integer

        list = ItemInfoList.GetItemInfoList
        count = list.Length
        GridEdit.ColumnCount = count

        For i As Integer = 0 To count - 1

            With GridEdit.Columns(i)

                .Alignment = list(i).ItemAlign
                .AlignmentHeader = list(i).TitleAlign
                .DspName = list(i).TitleName
                .Hide = list(i).Hide
                .Name = list(i).Name
                .Width = list(i).ColumnWidth

                SetupControlAttribute(list(i), GridEdit.Columns(i))

            End With

        Next

    End Sub

    ''' <summary>
    ''' 各カラムのコントロール情報を設定する。
    ''' </summary>
    ''' <param name="itemInfo">カラム情報</param>
    ''' <param name="columnAttribute">カラムのコントロール情報</param>
    ''' <remarks></remarks>
    Private Sub SetupControlAttribute(ByVal itemInfo As IColumnInfo, ByRef columnAttribute As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo)    'X1変換Tool-20160427

        Select Case itemInfo.ControlKind
            Case ControlKindType.状態
                SetupState(itemInfo, columnAttribute)

            Case ControlKindType.ラベル
                SetupLabelAttribute(itemInfo, columnAttribute)

            Case ControlKindType.テキスト
                SetupTextAttribute(itemInfo, columnAttribute)

            Case ControlKindType.数値
                SetupNumericalAttribute(itemInfo, columnAttribute)

            Case ControlKindType.コード
                SetupCodeAttribute(itemInfo, columnAttribute)

            Case ControlKindType.コンボボックス
                SetupComboBoxAttribute(itemInfo, columnAttribute)

            Case ControlKindType.チェックボックス
                SetupCheckBoxAttribute(itemInfo, columnAttribute)

            Case ControlKindType.コマンドボタン
                SetupCommandButtonAttribute(itemInfo, columnAttribute)

            Case ControlKindType.時間
                SetupInputTimeAttribute(itemInfo, columnAttribute)

            Case ControlKindType.設定なし
                SetupNothingAttribute(itemInfo, columnAttribute)

            Case ControlKindType.特殊日付
                SetupSpecificDateAttribute(itemInfo, columnAttribute)

            Case ControlKindType.日付
                SetupInputDateAttribute(itemInfo, columnAttribute)

        End Select

    End Sub

    ''' <summary>
    ''' テキスト列の設定を行なう
    ''' </summary>
    ''' <param name="itemInfo">カラム情報</param>
    ''' <param name="columnAttribute">カラムコントロール情報</param>
    ''' <remarks></remarks>
    Private Sub SetupTextAttribute(ByVal itemInfo As IColumnInfo, ByRef columnAttribute As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo)    'X1変換Tool-20160427

        Dim settingText As SettingInputText = Nothing
        itemInfo.GetSetting(settingText)

        Dim textAttribute As New TextControlAttribute

        With textAttribute
            .Insert = settingText.Insert
            .MaxLength = settingText.MaxLength
            .MaxLengthMode = settingText.MaxLengthMode
            .ZeroFill = settingText.ZeroFill
            .ImeMode = settingText.ImeMode
            .AllCharacters = settingText.AllCharacters
            If .AllCharacters = True Then
                .InputCodeChar = True
                .InputDoubleByte = True
                .InputKana = True
                .InputUpper = True
                .InputLower = True
                .InputNumber = True
                .InputSpace = True
                .InputSymbol = True
            Else
                .InputCodeChar = settingText.InputCodeChar
                .InputDoubleByte = settingText.InputDoubleByte
                .InputKana = settingText.InputKana
                .InputUpper = settingText.InputUpper
                .InputLower = settingText.InputLower
                .InputNumber = settingText.InputNumber
                .InputSpace = settingText.InputSpace
                .InputSymbol = settingText.InputSymbol
            End If
        End With

        columnAttribute.EditType = GridEditType.InputText
        columnAttribute.ColumnType = GridColumnType.Data
        columnAttribute.SortMode = itemInfo.SortMode
        columnAttribute.ControlAttribute = textAttribute

    End Sub

    ''' <summary>
    ''' コード列の設定を行なう
    ''' </summary>
    ''' <param name="itemInfo">カラム情報</param>
    ''' <param name="columnAttribute">カラムコントロール情報</param>
    ''' <remarks></remarks>
    Private Sub SetupCodeAttribute(ByVal itemInfo As IColumnInfo, ByRef columnAttribute As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo)    'X1変換Tool-20160427

        Dim settingCode As SettingCode = Nothing
        itemInfo.GetSetting(settingCode)

        Dim textAttribute As New TextControlAttribute

        With textAttribute
            .MaxLength = settingCode.MaxLength
            .Insert = False
            .MaxLengthMode = OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CustomLength    'X1変換Tool-20160427
            .ImeMode = settingCode.Imemode

            Select Case settingCode.InputType
                Case settingCode.InputItemType.数値_ゼロフィルあり
                    .ZeroFill = True
                    .AllCharacters = False
                    .InputCodeChar = False
                    .InputDoubleByte = False
                    .InputKana = False
                    .InputLower = False
                    .InputNumber = True
                    .InputSpace = False
                    .InputSymbol = False
                    .InputUpper = False

                Case settingCode.InputItemType.数値_ゼロフィルなし
                    .AllCharacters = False
                    .InputDoubleByte = False
                    .InputKana = False
                    .InputLower = False
                    .InputNumber = True
                    .InputCodeChar = False
                    .InputSpace = False
                    .InputSymbol = False
                    .InputUpper = False
                    .ZeroFill = False

                Case settingCode.InputItemType.半角英数のみ
                    .AllCharacters = False
                    .InputDoubleByte = False
                    .InputKana = False
                    .InputLower = True
                    .InputNumber = True
                    .InputCodeChar = True
                    .InputSpace = False
                    .InputSymbol = True
                    .InputUpper = True
                    .ZeroFill = False

                Case settingCode.InputItemType.すべての半角
                    .AllCharacters = False
                    .InputDoubleByte = False
                    .InputKana = True
                    .InputLower = True
                    .InputNumber = True
                    .InputCodeChar = True
                    .InputSpace = True
                    .InputSymbol = True
                    .InputUpper = True
                    .ZeroFill = False

            End Select

        End With

        columnAttribute.EditType = GridEditType.InputText
        columnAttribute.ColumnType = GridColumnType.Data
        columnAttribute.SortMode = itemInfo.SortMode
        columnAttribute.ControlAttribute = textAttribute

    End Sub

    ''' <summary>
    ''' 数値列の設定を行なう
    ''' </summary>
    ''' <param name="itemInfo">カラム情報</param>
    ''' <param name="columnAttribute">カラムコントロール情報</param>
    ''' <remarks></remarks>
    Private Sub SetupNumericalAttribute(ByVal itemInfo As IColumnInfo, ByRef columnAttribute As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo)    'X1変換Tool-20160427

        Dim settingNumerical As SettingInputNumerical = Nothing
        itemInfo.GetSetting(settingNumerical)

        Dim numericalAttribute As New NumericalControlAttribute

        With numericalAttribute
            .CommaDisplay = settingNumerical.CommaDisplay
            .DecimalDigits = settingNumerical.DecimalDigits
            .IntegerDigits = settingNumerical.IntegerDigits
            .PermitNull = settingNumerical.PermitNull
            .AcceptMinusKey = False                         '整数/小数桁数しかないのでマイナスキーはFalseとする。
        End With

        columnAttribute.EditType = GridEditType.InputNumeric
        columnAttribute.ColumnType = GridColumnType.Data
        columnAttribute.SortMode = itemInfo.SortMode
        columnAttribute.ControlAttribute = numericalAttribute
    End Sub

    ''' <summary>
    ''' チェックボックス列の設定を行なう
    ''' </summary>
    ''' <param name="itemInfo">カラム情報</param>
    ''' <param name="columnAttribute">カラムコントロール情報</param>
    ''' <remarks></remarks>
    Private Sub SetupCheckBoxAttribute(ByVal itemInfo As IColumnInfo, ByRef columnAttribute As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo)    'X1変換Tool-20160427
        Dim settingCheck As SettingCheckBox = Nothing
        itemInfo.GetSetting(settingCheck)

        Dim checkAttribute As New CheckControlAttribute

        With checkAttribute
            .DisplayName = settingCheck.DisplayName
        End With
        columnAttribute.EditType = GridEditType.CheckBox
        columnAttribute.ColumnType = GridColumnType.Data
        columnAttribute.SortMode = itemInfo.SortMode
        columnAttribute.ControlAttribute = checkAttribute
    End Sub

    ''' <summary>
    ''' コマンドボタン列の設定を行なう
    ''' </summary>
    ''' <param name="itemInfo"></param>
    ''' <remarks></remarks>
    Private Sub SetupCommandButtonAttribute(ByVal itemInfo As IColumnInfo, ByRef columnAttribute As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo)    'X1変換Tool-20160427
        columnAttribute.EditType = GridEditType.CommandButton
        columnAttribute.ColumnType = GridColumnType.Data
        columnAttribute.SortMode = itemInfo.SortMode

    End Sub

    ''' <summary>
    ''' 日付の設定を行なう
    ''' </summary>
    ''' <param name="itemInfo">カラム情報</param>
    ''' <param name="columnAttribute">カラムコントロール情報</param>
    ''' <remarks></remarks>
    Private Sub SetupInputDateAttribute(ByVal itemInfo As IColumnInfo, ByRef columnAttribute As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo)    'X1変換Tool-20160427

        Dim settingDate As SettingDate = Nothing
        itemInfo.GetSetting(settingDate)

        Dim dateAttribute As New DateControlAttribute

        With dateAttribute
            .DisplayFormat = settingDate.DisplayFormat
            .DisplayItems = settingDate.DisplayItems
            .DispSpinButton = settingDate.DispSpinButton
            .Separator = settingDate.Separator
            .ZeroFill = settingDate.Zerofill
            .RemainColor = Me.GridEdit.BackColor
        End With

        columnAttribute.EditType = GridEditType.InputDate
        columnAttribute.ColumnType = GridColumnType.Data
        columnAttribute.SortMode = itemInfo.SortMode
        columnAttribute.ControlAttribute = dateAttribute

    End Sub

    ''' <summary>
    ''' 特定日付の設定を行なう
    ''' </summary>
    ''' <param name="itemInfo">カラム情報</param>
    ''' <param name="columnAttribute">カラムコントロール情報</param>
    ''' <remarks></remarks>
    Private Sub SetupSpecificDateAttribute(ByVal itemInfo As IColumnInfo, ByRef columnAttribute As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo)    'X1変換Tool-20160427
        columnAttribute.EditType = GridEditType.SpecificDate
        columnAttribute.ColumnType = GridColumnType.Data
        columnAttribute.SortMode = itemInfo.SortMode
    End Sub

    ''' <summary>
    ''' 時刻の設定を行なう
    ''' </summary>
    ''' <param name="itemInfo">カラム情報</param>
    ''' <param name="columnAttribute">カラムコントロール情報</param>
    ''' <remarks></remarks>
    Private Sub SetupInputTimeAttribute(ByVal itemInfo As IColumnInfo, ByRef columnAttribute As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo)    'X1変換Tool-20160427

        Dim settingTime As SettingTime = Nothing
        itemInfo.GetSetting(settingTime)

        Dim timeAttribute As New TimeControlAttribute

        With timeAttribute
            .DisplayItems = settingTime.DisplayItems
            .DispSpinButton = settingTime.DisplaySpinButton
            .Separator = settingTime.Separator
            .ZeroFill = settingTime.Zerofill
            .RemainColor = Me.GridEdit.BackColor
        End With

        columnAttribute.EditType = GridEditType.InputTime
        columnAttribute.ColumnType = GridColumnType.Data
        columnAttribute.SortMode = itemInfo.SortMode
        columnAttribute.ControlAttribute = timeAttribute

    End Sub

    ''' <summary>
    ''' コンボボックスの設定を行なう
    ''' </summary>
    ''' <param name="itemInfo">カラム情報</param>
    ''' <param name="columnAttribute">カラムコントロール情報</param>
    ''' <remarks></remarks>
    Private Sub SetupComboBoxAttribute(ByVal itemInfo As IColumnInfo, ByRef columnAttribute As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo)    'X1変換Tool-20160427

        Dim settingComboBox As SettingComboBox = Nothing
        itemInfo.GetSetting(settingComboBox)

        Dim ComboBoxAttribute As New ComboControlAttribute
        With ComboBoxAttribute
            .Style = settingComboBox.Style
            .DisplayRowCount = settingComboBox.DisplayRowCount
        End With
        If settingComboBox.ListData.Length > 0 Then
            columnAttribute.ListData = settingComboBox.ListData
        End If

        columnAttribute.EditType = GridEditType.ComboBox
        columnAttribute.ColumnType = GridColumnType.Data
        columnAttribute.SortMode = itemInfo.SortMode
        columnAttribute.ControlAttribute = ComboBoxAttribute

    End Sub

    ''' <summary>
    ''' ラベル列の設定を行なう
    ''' </summary>
    ''' <param name="itemInfo">カラム情報</param>
    ''' <param name="columnAttribute">カラムコントロール情報</param>
    ''' <remarks></remarks>
    Private Sub SetupLabelAttribute(ByVal itemInfo As IColumnInfo, ByRef columnAttribute As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo)    'X1変換Tool-20160427
        columnAttribute.EditType = GridEditType.Empty
        columnAttribute.ColumnType = GridColumnType.Data
        columnAttribute.SortMode = itemInfo.SortMode
    End Sub

    ''' <summary>
    ''' Nothing列の設定を行なう
    ''' </summary>
    ''' <param name="itemInfo">カラム情報</param>
    ''' <param name="columnAttribute">カラムコントロール情報</param>
    ''' <remarks></remarks>
    Private Sub SetupNothingAttribute(ByVal itemInfo As IColumnInfo, ByRef columnAttribute As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo)    'X1変換Tool-20160427
        columnAttribute.EditType = GridEditType.Nothing
        columnAttribute.ColumnType = GridColumnType.Data
        columnAttribute.SortMode = itemInfo.SortMode
    End Sub

    ''' <summary>
    ''' 状態列の設定を行なう
    ''' </summary>
    ''' <param name="itemInfo">カラム情報</param>
    ''' <param name="columnAttribute">カラムコントロール情報</param>
    ''' <remarks></remarks>
    Private Sub SetupState(ByVal itemInfo As IColumnInfo, ByRef columnAttribute As OSK.X1.Foundation.Controls.Grid.Common.ColumnAttributeInfo)    'X1変換Tool-20160427
        columnAttribute.EditType = GridEditType.Empty
        columnAttribute.ColumnType = GridColumnType.RowState
        columnAttribute.SortMode = itemInfo.SortMode
    End Sub

#End Region

#Region "イベント"

    Public Event RaiseEventDisplayDeleteCell(ByVal sender As Object, ByVal e As Grid.Common.DisplayDeleteCellEventArgs)
    ''' <summary>
    ''' 削除行を表示する
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks>DataTableでは削除する前の行の値を表示できないため</remarks>
    Private Sub _gridEdit_DisplayDeleteCell(ByVal sender As Object, ByVal e As Grid.Common.DisplayDeleteCellEventArgs) Handles _gridEdit.DisplayDeleteCell
        RaiseEvent RaiseEventDisplayDeleteCell(sender, e)
    End Sub

#End Region

End Class
