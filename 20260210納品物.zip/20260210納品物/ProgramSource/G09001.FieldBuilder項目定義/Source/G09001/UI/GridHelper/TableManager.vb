﻿Public Class TableManager

    Private _dataTable As DataTable

#Region "コンストラクタ"

    Sub New(ByVal dataTable As DataTable)
        _dataTable = dataTable
    End Sub

    Sub New()
        _dataTable = New DataTable
    End Sub

#End Region

#Region "プロパティ"

    ''' <summary>
    ''' データテーブル
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property DataTable() As DataTable
        Get
            Return _dataTable
        End Get
        Set(ByVal value As DataTable)
            _dataTable = value
        End Set
    End Property

#End Region

#Region "メソッド"

    ''' <summary>
    ''' 行挿入
    ''' </summary>
    ''' <param name="rowIndex">行番号</param>
    ''' <remarks></remarks>
    Sub Insert(ByVal rowIndex As Integer)
        Dim row As DataRow = _dataTable.NewRow
        _dataTable.Rows.InsertAt(row, rowIndex)
    End Sub

    ''' <summary>
    ''' 行挿入(デフォルト値ありの挿入)
    ''' </summary>
    ''' <param name="row">デフォルト値</param>
    ''' <param name="rowIndex">行番号</param>
    ''' <remarks></remarks>
    Sub InsertNewRow(ByVal row As DataRow, ByVal rowIndex As Integer)
        _dataTable.Rows.InsertAt(row, rowIndex)
    End Sub

    ''' <summary>
    ''' 行初期値
    ''' </summary>
    ''' <param name="rowIndex">行番号</param>
    ''' <remarks></remarks>
    Sub RejectChanges(ByVal rowIndex As Integer)
        _dataTable.Rows(rowIndex).RejectChanges()
    End Sub

    ''' <summary>
    ''' 行削除
    ''' </summary>
    ''' <param name="rowIndex">行番号</param>
    ''' <remarks></remarks>
    Sub Delete(ByVal rowIndex As Integer)
        _dataTable.Rows(rowIndex).Delete()
    End Sub

#End Region


End Class
