﻿''' <summary>
''' 特殊日付設定
''' </summary>
''' <remarks></remarks>
Public Class SettingSpecificDate
    '#Region "コンストラクタ"
    '    Sub New(ByVal displayFormat As OSK.X1.Foundation.Controls.InputDate.DisplayFormatType, _    'X1変換Tool-20160427
    '            ByVal displayItems As OSK.X1.Foundation.Controls.InputDate.DisplayItemsType, _    'X1変換Tool-20160427
    '            ByVal displaySpinButton As Boolean, _
    '            ByVal separator As OSK.X1.Foundation.Controls.InputSpecificDate.SeparatorType, _    'X1変換Tool-20160427
    '            ByVal zerofill As Boolean)

    '        _displayItems = displayItems
    '        _displaySpinButton = displaySpinButton
    '        _separator = separator
    '    End Sub
    '#End Region

    '#Region "プロパティ"

    '    Private _displayFormat As OSK.X1.Foundation.Controls.InputDate.DisplayFormatType    'X1変換Tool-20160427
    '    ''' <summary>
    '    ''' 日付表示形式
    '    ''' </summary>
    '    ''' <value></value>
    '    ''' <returns></returns>
    '    ''' <remarks></remarks>
    '    Public Property DisplayFormat() As OSK.X1.Foundation.Controls.InputDate.DisplayFormatType    'X1変換Tool-20160427
    '        Get
    '            Return _displayFormat
    '        End Get
    '        Set(ByVal value As OSK.X1.Foundation.Controls.InputDate.DisplayFormatType)    'X1変換Tool-20160427
    '            _displayFormat = value
    '        End Set
    '    End Property

    '    Private _displayItems As OSK.X1.Foundation.Controls.InputDate.DisplayItemsType    'X1変換Tool-20160427
    '    ''' <summary>
    '    ''' 表示形式
    '    ''' </summary>
    '    ''' <value></value>
    '    ''' <returns></returns>
    '    ''' <remarks></remarks>
    '    Public Property DisplayItems() As OSK.X1.Foundation.Controls.InputDate.DisplayItemsType    'X1変換Tool-20160427
    '        Get
    '            Return _displayItems
    '        End Get
    '        Set(ByVal value As OSK.X1.Foundation.Controls.InputDate.DisplayItemsType)    'X1変換Tool-20160427
    '            _displayItems = value
    '        End Set
    '    End Property

    '    Private _displaySpinButton As Boolean
    '    ''' <summary>
    '    ''' スピンボタン表示
    '    ''' </summary>
    '    ''' <value></value>
    '    ''' <returns></returns>
    '    ''' <remarks></remarks>
    '    Public Property DisplaySpinButton() As Boolean
    '        Get
    '            Return _displaySpinButton
    '        End Get
    '        Set(ByVal value As Boolean)
    '            _displaySpinButton = value
    '        End Set
    '    End Property


    '    Private _separator As OSK.X1.Foundation.Controls.InputDate.SeparatorType    'X1変換Tool-20160427
    '    ''' <summary>
    '    ''' セパレーター
    '    ''' </summary>
    '    ''' <value></value>
    '    ''' <returns></returns>
    '    ''' <remarks></remarks>
    '    Public Property Separator() As OSK.X1.Foundation.Controls.InputDate.SeparatorType    'X1変換Tool-20160427
    '        Get
    '            Return _separator
    '        End Get
    '        Set(ByVal value As OSK.X1.Foundation.Controls.InputDate.SeparatorType)    'X1変換Tool-20160427
    '            _separator = value
    '        End Set
    '    End Property

    '    Private _zerofill As Boolean
    '    ''' <summary>
    '    ''' ゼロフィル
    '    ''' </summary>
    '    ''' <value></value>
    '    ''' <returns></returns>
    '    ''' <remarks></remarks>
    '    Public Property Zerofill() As Boolean
    '        Get
    '            Return _zerofill
    '        End Get
    '        Set(ByVal value As Boolean)
    '            _zerofill = value
    '        End Set
    '    End Property

    '#End Region

End Class
