﻿''' <summary>
''' 日付設定
''' </summary>
''' <remarks></remarks>
Public Class SettingDate

#Region "コンストラクタ"
    Sub New(ByVal displayFormat As OSK.X1.Foundation.Controls.InputDate.DisplayFormatType, _
            ByVal displayItems As OSK.X1.Foundation.Controls.InputDate.DisplayItemsType, _
            ByVal displaySpinButton As Boolean, _
            ByVal separator As OSK.X1.Foundation.Controls.InputDate.SeparatorType, _
            ByVal zerofill As Boolean)    'X1変換Tool-20160427

        _displayFormat = displayFormat
        _displayItems = displayItems
        _dispSpinButton = displaySpinButton
        _separator = separator
        _zerofill = zerofill
    End Sub
#End Region

#Region "プロパティ"

    Private _displayFormat As OSK.X1.Foundation.Controls.InputDate.DisplayFormatType    'X1変換Tool-20160427
    ''' <summary>
    ''' 日付表示形式
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property DisplayFormat() As OSK.X1.Foundation.Controls.InputDate.DisplayFormatType    'X1変換Tool-20160427
        Get
            Return _displayFormat
        End Get
        Set(ByVal value As OSK.X1.Foundation.Controls.InputDate.DisplayFormatType)    'X1変換Tool-20160427
            _displayFormat = value
        End Set
    End Property

    Private _displayItems As OSK.X1.Foundation.Controls.InputDate.DisplayItemsType    'X1変換Tool-20160427
    ''' <summary>
    ''' 表示形式
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property DisplayItems() As OSK.X1.Foundation.Controls.InputDate.DisplayItemsType    'X1変換Tool-20160427
        Get
            Return _displayItems
        End Get
        Set(ByVal value As OSK.X1.Foundation.Controls.InputDate.DisplayItemsType)    'X1変換Tool-20160427
            _displayItems = value
        End Set
    End Property

    Private _dispSpinButton As Boolean
    ''' <summary>
    ''' スピンボタン表示
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property DispSpinButton() As Boolean
        Get
            Return _dispSpinButton
        End Get
        Set(ByVal value As Boolean)
            _dispSpinButton = value
        End Set
    End Property


    Private _separator As OSK.X1.Foundation.Controls.InputDate.SeparatorType    'X1変換Tool-20160427
    ''' <summary>
    ''' セパレーター
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property Separator() As OSK.X1.Foundation.Controls.InputDate.SeparatorType    'X1変換Tool-20160427
        Get
            Return _separator
        End Get
        Set(ByVal value As OSK.X1.Foundation.Controls.InputDate.SeparatorType)    'X1変換Tool-20160427
            _separator = value
        End Set
    End Property

    Private _zerofill As Boolean
    ''' <summary>
    ''' ゼロフィル
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property Zerofill() As Boolean
        Get
            Return _zerofill
        End Get
        Set(ByVal value As Boolean)
            _zerofill = value
        End Set
    End Property

#End Region

End Class
