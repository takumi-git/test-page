﻿''' <summary>
''' 項目情報用インターフェース
''' </summary>
''' <remarks></remarks>
Public Interface IColumnInfo

    '''' <summary>
    '''' 入力項目のタイプ
    '''' </summary>
    '''' <remarks></remarks>
    'Enum InputItemType As Integer
    '    数値型
    '    文字型
    '    数値コード型
    'End Enum

#Region "プロパティ"

    ''' <summary>
    ''' 項目名称
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property Name() As String

    ''' <summary>
    ''' タイトル名称
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property TitleName() As String

    '''' <summary>
    '''' 入力タイプ
    '''' </summary>
    '''' <value></value>
    '''' <returns></returns>
    '''' <remarks></remarks>
    'Property InputType() As InputItemType

    ''' <summary>
    ''' コントロールの種類
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    ReadOnly Property ControlKind() As ControlKindType

    ''' <summary>
    ''' 最大桁数
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property MaxLength() As Integer

    ''' <summary>
    ''' グリッドのカラム幅
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property ColumnWidth() As Single

    ''' <summary>
    ''' 非表示判定
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property Hide() As Boolean

    '''' <summary>
    '''' 入力判定
    '''' </summary>
    '''' <value></value>
    '''' <returns></returns>
    '''' <remarks></remarks>
    'Property Enable() As Boolean

    ''' <summary>
    ''' グループ番号
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property GroupNo() As Integer

    ''' <summary>
    ''' キー項目判定
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property IsKey() As Boolean

    ''' <summary>
    ''' 初期値
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property DefaultValue() As String

    ''' <summary>
    ''' 項目の位置
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property ItemAlign() As OSK.X1.Foundation.Controls.Grid.Common.HorzAlign    'X1変換Tool-20160427

    ''' <summary>
    ''' タイトルの位置
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property TitleAlign() As OSK.X1.Foundation.Controls.Grid.Common.HorzAlign    'X1変換Tool-20160427

    '''' <summary>
    '''' データタイプ
    '''' </summary>
    '''' <value></value>
    '''' <returns></returns>
    '''' <remarks></remarks>
    'Property DataType() As OSK.X1.Foundation.Controls.Grid.Common.GridColumnType    'X1変換Tool-20160427

    '''' <summary>
    '''' コントロール別設定
    '''' </summary>
    '''' <value></value>
    '''' <returns></returns>
    '''' <remarks></remarks>
    'Property IndividualSetting() As SettingInputText

    ''' <summary>
    ''' ソートモード
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property SortMode() As OSK.X1.Foundation.Controls.Grid.Common.GridSortMode    'X1変換Tool-20160427

#End Region

#Region "メソッド"

    ''' <summary>
    ''' コントロール別設定を渡す
    ''' </summary>
    ''' <typeparam name="T"></typeparam>
    ''' <param name="individualSetting"></param>
    ''' <remarks></remarks>
    Sub GetSetting(Of T)(ByRef individualSetting As T)

    ''' <summary>
    ''' コントロール別設定を設定する
    ''' </summary>
    ''' <typeparam name="T"></typeparam>
    ''' <param name="settingValue"></param>
    ''' <remarks></remarks>
    Sub SetSetting(Of T)(ByVal settingValue As T)

#End Region

End Interface
