﻿''' <summary>
''' グリッドヘルパー
''' </summary>
''' <remarks></remarks>
Public Interface IGridHelper

#Region "プロパティ"

    ''' <summary>
    ''' 入力制限行カウント
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks>グリッドに追加できる行数の限界値</remarks>
    Property LimitRowCount() As Integer

    ''' <summary>
    ''' 前景色の変更をヘルパー連動する判定
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property ForeColorLink() As Boolean

    ''' <summary>
    ''' 変更なしのセルの前景色
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property ForeColorUnchanged() As System.Drawing.Color

    ''' <summary>
    ''' 修正されたセルの前景色
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property ForeColorModified() As System.Drawing.Color

    ''' <summary>
    ''' 削除対象行の前景色
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property ForeColorDeletedRow() As System.Drawing.Color

    ''' <summary>
    ''' 固定列の色
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property ForeColorFixedCol() As System.Drawing.Color

    ''' <summary>
    ''' [読取専用]行状態リスト
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    ReadOnly Property RowStateList() As List(Of DataRowState)

    ''' <summary>
    ''' [読取専用]削除対象行リスト
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    ReadOnly Property DeletedRows() As List(Of DeletedRow)

#End Region

#Region "メソッド"

    ''' <summary>
    ''' グリッドヘルパーを初期設定する
    ''' </summary>
    ''' <remarks></remarks>
    Sub SetupGridHelper()

    ''' <summary>
    ''' 行を挿入する
    ''' </summary>
    ''' <param name="rowIndex">行番号</param>
    ''' <returns>挿入可能判定</returns>
    ''' <remarks>最大表示行数を超えてる挿入の場合、Falseを返す</remarks>
    Function Insert(ByVal rowIndex As Integer) As Boolean

    ''' <summary>
    ''' 行を挿入する
    ''' </summary>
    ''' <param name="rowIndex">行番号</param>
    ''' <param name="row">行データ</param>
    ''' <returns>挿入可能判定</returns>
    ''' <remarks>最大表示行数を超えてる挿入の場合、Falseを返す</remarks>
    Function Insert(ByVal rowIndex As Integer, ByVal row As DataRow) As Boolean

    ''' <summary>
    ''' 行を削除する
    ''' </summary>
    ''' <param name="rowIndex">行番号</param>
    ''' <remarks>行の状態が登録の場合、DataTableからレコードを削除する</remarks>
    Sub Delete(ByVal rowIndex As Integer)

    ''' <summary>
    ''' 行の編集をキャンセルする
    ''' </summary>
    ''' <param name="rowIndex">行番号</param>
    ''' <remarks>初期表示状態に戻す</remarks>
    Sub CancelEditRow(ByVal rowIndex As Integer)

    ''' <summary>
    ''' 削除状態を取り消す
    ''' </summary>
    ''' <param name="rowIndex">行番号</param>
    ''' <remarks></remarks>
    Sub RevokeDelete(ByVal rowIndex As Integer)

    ''' <summary>
    ''' 同一の値が存在するかのチェック
    ''' </summary>
    ''' <param name="targetValue">対象の値</param>
    ''' <param name="columnName">列名</param>
    ''' <returns>存在判定</returns>
    ''' <remarks></remarks>
    Function IsSameValue(ByVal targetValue As Object, ByVal columnName As String) As Boolean

    ''' <summary>
    ''' 同一の値が存在するかのチェック
    ''' </summary>
    ''' <param name="targetKey">対象の値</param>
    ''' <returns>存在判定</returns>
    ''' <remarks></remarks>
    Function IsSameKey(ByVal ParamArray targetKey() As String) As Boolean

    ''' <summary>
    ''' 前行項目値コピー
    ''' </summary>
    ''' <param name="currentRowIndex">行番号</param>
    ''' <param name="currentColIndex">列番号</param>
    ''' <remarks></remarks>
    Sub CopyPrevRowItem(ByVal currentRowIndex As Integer, ByVal currentColIndex As Integer)

    ''' <summary>
    ''' 前行項目値コピー
    ''' </summary>
    ''' <param name="currentRowIndex">行番号</param>
    ''' <param name="currentColName">列名</param>
    ''' <remarks></remarks>
    Sub CopyPrevRowItem(ByVal currentRowIndex As Integer, ByVal currentColName As String)

    ''' <summary>
    ''' 前行項目値コピー
    ''' </summary>
    ''' <param name="currentRowIndex">行番号</param>
    ''' <param name="addCopyItemIndex">コピー列番号()</param>
    ''' <remarks></remarks>
    Sub CopyPrevRowItem(ByVal currentRowIndex As Integer, ByVal ParamArray addCopyItemIndex() As Integer)

    ''' <summary>
    ''' 前行項目値コピー
    ''' </summary>
    ''' <param name="currentRowIndex">行番号</param>
    ''' <param name="addCopyItemName">コピー列名()</param>
    ''' <remarks></remarks>
    Sub CopyPrevRowItem(ByVal currentRowIndex As Integer, ByVal ParamArray addCopyItemName() As String)

    ''' <summary>
    ''' 前行項目値コピー(範囲指定)
    ''' </summary>
    ''' <param name="startRowIndex">開始行番号</param>
    ''' <param name="endRowIndex">終了行番号</param>
    ''' <param name="currentColIndex">列番号</param>
    ''' <remarks></remarks>
    Sub RangeCopyPrevRowItem(ByVal startRowIndex As Integer, ByVal endRowIndex As Integer, ByVal currentColIndex As Integer)

    ''' <summary>
    ''' 前行項目値コピー(範囲指定)
    ''' </summary>
    ''' <param name="startRowIndex">開始行番号</param>
    ''' <param name="endRowIndex">終了行番号</param>
    ''' <param name="currentColName">列名</param>
    ''' <remarks></remarks>
    Sub RangeCopyPrevRowItem(ByVal startRowIndex As Integer, ByVal endRowIndex As Integer, ByVal currentColName As String)

    ''' <summary>
    ''' 前行項目値コピー(範囲指定)
    ''' </summary>
    ''' <param name="startRowIndex">開始行番号</param>
    ''' <param name="endRowIndex">終了行番号</param>
    ''' <param name="addCopyItemIndex">コピー列番号()</param>
    ''' <remarks></remarks>
    Sub RangeCopyPrevRowItem(ByVal startRowIndex As Integer, ByVal endRowIndex As Integer, ByVal ParamArray addCopyItemIndex() As Integer)

    ''' <summary>
    ''' 前行項目値コピー(範囲指定)
    ''' </summary>
    ''' <param name="startRowIndex">開始行番号</param>
    ''' <param name="endRowIndex">終了行番号</param>
    ''' <param name="addCopyItemName">コピー列名()</param>
    ''' <remarks></remarks>
    Sub RangeCopyPrevRowItem(ByVal startRowIndex As Integer, ByVal endRowIndex As Integer, ByVal ParamArray addCopyItemName() As String)

    ''' <summary>
    ''' セルの前景色を変更する
    ''' </summary>
    ''' <param name="rowIndex"></param>
    ''' <param name="colIndex"></param>
    ''' <param name="color"></param>
    ''' <remarks></remarks>
    Sub ChangeCellForeColor(ByVal rowIndex As Integer, ByVal colIndex As Integer, ByVal color As System.Drawing.Color)

    ''' <summary>
    ''' セルの前景色を変更する
    ''' </summary>
    ''' <param name="rowIndex"></param>
    ''' <param name="colName"></param>
    ''' <param name="color"></param>
    ''' <remarks></remarks>
    Sub ChangeCellForeColor(ByVal rowIndex As Integer, ByVal colName As String, ByVal color As System.Drawing.Color)

    ''' <summary>
    ''' 行の前景色を変更する
    ''' </summary>
    ''' <param name="rowIndex"></param>
    ''' <param name="color"></param>
    ''' <remarks></remarks>
    Sub ChangeRowForeColor(ByVal rowIndex As Integer, ByVal color As System.Drawing.Color)

    ''' <summary>
    ''' データテーブルをセットする
    ''' </summary>
    ''' <param name="dataTable">データテーブル</param>
    ''' <remarks></remarks>
    Sub SetDataTable(ByVal dataTable As DataTable)

    '''''' <summary>
    '''''' キー読取専用を一括設定する
    '''''' </summary>
    '''''' <param name="isReadOnly">読取専用判定</param>
    '''''' <remarks>キー項目に対してのみReadOnlyを設定・解除する。登録行はReadOnlyを解除</remarks>
    ' ''Sub SetKeyItemReadOnly(ByVal isReadOnly As Boolean)

    '''''' <summary>
    '''''' キー項目の読取専用を設定する
    '''''' </summary>
    '''''' <param name="isReadOnly">読取専用判定</param>
    '''''' <param name="rowIndex">行番号</param>
    '''''' <remarks>キー項目に対してのみReadOnlyを設定・解除する。登録行はReadOnlyを解除</remarks>
    ' ''Sub SetKeyItemReadOnly(ByVal isReadOnly As Boolean, ByVal rowIndex As Integer)

    ''' <summary>
    ''' 編集状態を修正⇒新規へ変更する。
    ''' </summary>
    ''' <param name="rowIndex"></param>
    ''' <remarks></remarks>
    Sub ChangeRowStateAdded(ByVal rowIndex As Integer)

#End Region

End Interface
