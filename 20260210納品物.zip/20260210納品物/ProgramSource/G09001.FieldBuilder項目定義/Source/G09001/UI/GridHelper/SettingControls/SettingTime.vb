﻿''' <summary>
''' 時間設定
''' </summary>
''' <remarks></remarks>
Public Class SettingTime


#Region "コンストラクタ"
    Sub New(ByVal displayItems As OSK.X1.Foundation.Controls.InputTime.DisplayItemsType, _
            ByVal displaySpinButton As Boolean, _
            ByVal separator As OSK.X1.Foundation.Controls.InputTime.SeparatorType, ByVal zerofill As Boolean)    'X1変換Tool-20160427
        _displayItems = displayItems
        _displaySpinButton = displaySpinButton
        _separator = separator
    End Sub
#End Region

#Region "プロパティ"

    Private _displayItems As OSK.X1.Foundation.Controls.InputTime.DisplayItemsType    'X1変換Tool-20160427
    ''' <summary>
    ''' 表示形式
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property DisplayItems() As OSK.X1.Foundation.Controls.InputTime.DisplayItemsType    'X1変換Tool-20160427
        Get
            Return _displayItems
        End Get
        Set(ByVal value As OSK.X1.Foundation.Controls.InputTime.DisplayItemsType)    'X1変換Tool-20160427
            _displayItems = value
        End Set
    End Property

    Private _displaySpinButton As Boolean
    ''' <summary>
    ''' スピンボタン表示
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property DisplaySpinButton() As Boolean
        Get
            Return _displaySpinButton
        End Get
        Set(ByVal value As Boolean)
            _displaySpinButton = value
        End Set
    End Property


    Private _separator As OSK.X1.Foundation.Controls.InputTime.SeparatorType    'X1変換Tool-20160427
    ''' <summary>
    ''' セパレーター
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property Separator() As OSK.X1.Foundation.Controls.InputTime.SeparatorType    'X1変換Tool-20160427
        Get
            Return _separator
        End Get
        Set(ByVal value As OSK.X1.Foundation.Controls.InputTime.SeparatorType)    'X1変換Tool-20160427
            _separator = value
        End Set
    End Property

    Private _zerofill As Boolean
    ''' <summary>
    ''' ゼロフィル
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property Zerofill() As Boolean
        Get
            Return _zerofill
        End Get
        Set(ByVal value As Boolean)
            _zerofill = value
        End Set
    End Property

#End Region

End Class
