﻿Public Class SettingCode

    Public Enum InputItemType As Integer
        数値_ゼロフィルあり
        数値_ゼロフィルなし
        半角英数のみ
        すべての半角
    End Enum

#Region "コンストラクタ"

    Sub New(ByVal inputType As InputItemType, ByVal maxLength As Integer, ByVal imeMode As OSK.X1.Foundation.Controls.InputText.ImeModeType)    'X1変換Tool-20160427
        _inputType = inputType
        _maxLength = maxLength
        _imemode = imeMode
    End Sub

#End Region

#Region "プロパティ"

    Private _maxLength As Integer
    ''' <summary>
    ''' 最大入力桁数
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property MaxLength() As Integer
        Get
            Return _maxLength
        End Get
        Set(ByVal value As Integer)
            _maxLength = value
        End Set
    End Property

    Private _inputType As InputItemType
    ''' <summary>
    ''' 入力タイプ
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property InputType() As InputItemType
        Get
            Return _inputType
        End Get
        Set(ByVal value As InputItemType)
            _inputType = value
        End Set
    End Property

    Private _imemode As OSK.X1.Foundation.Controls.InputText.ImeModeType    'X1変換Tool-20160427
    Public Property Imemode() As OSK.X1.Foundation.Controls.InputText.ImeModeType    'X1変換Tool-20160427
        Get
            Return _imemode
        End Get
        Set(ByVal value As OSK.X1.Foundation.Controls.InputText.ImeModeType)    'X1変換Tool-20160427
            _imemode = value
        End Set
    End Property

#End Region

End Class
