﻿''' <summary>
''' データアクセス処理の終了をチェックするクラス
''' </summary>
''' <remarks>メイン処理でデータアクセス側の処理を呼ぶ際、
''' プログレスバーを動作させるための処理を実装。</remarks>
Public MustInherit Class DataAccessorBase
    Inherits InsideJobBase

#Region "プロパティ"

    Private _endFlag As Boolean
    ''' <summary>
    ''' 終了フラグ
    ''' </summary>
    ''' <value></value>
    ''' <returns>True=終了,False=実行中</returns>
    ''' <remarks></remarks>
    Protected Property EndFlag() As Boolean
        Get
            Return _endFlag
        End Get
        Set(ByVal value As Boolean)
            _endFlag = value
        End Set
    End Property

#End Region

#Region "メソッド"

    ''' <summary>
    ''' 処理終了のフラグを取得する
    ''' </summary>
    ''' <param name="accessor">DAにアクセス依頼を行なったインスタンス</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetEndFlag(ByVal accessor As DataAccessorBase) As Boolean
        If accessor Is Nothing Then Return True

        Return _endFlag
    End Function

    ''' <summary>
    ''' 処理終了のフラグを初期化する
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub InitializeEndFlag()
        _endFlag = False
    End Sub

    ''' <summary>
    ''' データアクセスのインスタンスを設定する
    ''' </summary>
    ''' <typeparam name="T">想定しているのは、IReader型もしくはIUpdater型</typeparam>
    ''' <param name="dataAccessor">データアクセス</param>
    ''' <remarks></remarks>
    Public MustOverride Sub SetupDataAccessor(Of T)(ByVal dataAccessor As T)


#End Region

End Class
