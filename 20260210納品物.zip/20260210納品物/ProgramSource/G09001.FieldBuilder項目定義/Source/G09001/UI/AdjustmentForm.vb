﻿'''' <summary>
'''' 詳細条件画面
'''' </summary>
'''' <remarks></remarks>
'Public Class AdjustmentForm

'#Region "変数"

'    Private _contextMenu As SmartControl.ContextMenu.ContextMenu
'    Private _focusSwitcher As IFocusSwitcher

'    Private _targetMaster As IDivisionSelecter
'    Private _targetTorihiki As IDivisionSelecter
'    Private _oldDataShurui As String = ""
'    Private _personalMessageViewer As PersonalMessageViewer

'#End Region

'#Region "コンストラクタ"
'    Sub New()
'        ' この呼び出しは、Windows フォーム デザイナで必要です。
'        InitializeComponent()
'    End Sub


'#End Region

'#Region "プロパティ"

'    Private _データ種別 As Integer
'    Public Property データ種別() As Integer
'        Get
'            Return _データ種別
'        End Get
'        Set(ByVal value As Integer)
'            _データ種別 = value
'        End Set
'    End Property

'    Private _データ種類 As String
'    Public Property データ種類() As String
'        Get
'            Return _データ種類
'        End Get
'        Set(ByVal value As String)
'            _データ種類 = value
'        End Set
'    End Property

'    Private _明細区分 As Integer
'    Public Property 明細区分() As Integer
'        Get
'            Return _明細区分
'        End Get
'        Set(ByVal value As Integer)
'            _明細区分 = value
'        End Set
'    End Property

'    Private _強制実行 As Integer
'    Public ReadOnly Property 強制実行() As Integer
'        Get
'            Return _強制実行
'        End Get
'    End Property

'    Private _整合処理チェック区分_売上_仕入 As Integer
'    Public Property 整合処理チェック区分_売上_仕入() As Integer
'        Get
'            Return _整合処理チェック区分_売上_仕入
'        End Get
'        Set(ByVal value As Integer)
'            _整合処理チェック区分_売上_仕入 = value
'        End Set
'    End Property

'    Private _整合処理チェック区分_受注_発注 As Integer
'    Public Property 整合処理チェック区分_受注_発注() As Integer
'        Get
'            Return _整合処理チェック区分_受注_発注
'        End Get
'        Set(ByVal value As Integer)
'            _整合処理チェック区分_受注_発注 = value
'        End Set
'    End Property

'    Private _整合処理チェック区分_見積 As Integer
'    Public Property 整合処理チェック区分_見積() As Integer
'        Get
'            Return _整合処理チェック区分_見積
'        End Get
'        Set(ByVal value As Integer)
'            _整合処理チェック区分_見積 = value
'        End Set
'    End Property

'    Private _整合処理チェック区分_経費 As Integer                               'A-20080709_2
'    Public Property 整合処理チェック区分_経費() As Integer                      'A-20080709_2
'        Get
'            Return _整合処理チェック区分_経費
'        End Get
'        Set(ByVal value As Integer)
'            _整合処理チェック区分_経費 = value
'        End Set
'    End Property

'    'A-20101213_2{
'    Private _整合処理チェック区分_出荷_入荷 As Integer
'    Public Property 整合処理チェック区分_出荷_入荷() As Integer
'        Get
'            Return _整合処理チェック区分_出荷_入荷
'        End Get
'        Set(ByVal value As Integer)
'            _整合処理チェック区分_出荷_入荷 = value
'        End Set
'    End Property
'    'A-20101213_2}

'    Private _受注管理 As Integer
'    Public Property 受注管理() As Integer
'        Get
'            Return _受注管理
'        End Get
'        Set(ByVal value As Integer)
'            _受注管理 = value
'        End Set
'    End Property

'    Private _見積管理 As Integer
'    Public Property 見積管理() As Integer
'        Get
'            Return _見積管理
'        End Get
'        Set(ByVal value As Integer)
'            _見積管理 = value
'        End Set
'    End Property

'    Private _強化区分 As Decimal                                                'A-20080709_2 & A-20080709_3 & A-20080709_4 
'    Public Property 強化区分() As Decimal                                       'A-20080709_2 & A-20080709_3 & A-20080709_4 
'        Get
'            Return _強化区分
'        End Get
'        Set(ByVal value As Decimal)
'            _強化区分 = value
'        End Set
'    End Property

'    Private _原価管理 As Integer                                                'A-20080709_2
'    Public Property 原価管理() As Integer                                       'A-20080709_2
'        Get
'            Return _原価管理
'        End Get
'        Set(ByVal value As Integer)
'            _原価管理 = value
'        End Set
'    End Property

'    Private _ロット管理 As Integer                                              'A-20091125_1
'    Public Property ロット管理() As Integer                                     'A-20091125_1
'        Get
'            Return _ロット管理
'        End Get
'        Set(ByVal value As Integer)
'            _ロット管理 = value
'        End Set
'    End Property

'    Private _データ種類_取引 As List(Of String)
'    Public Property データ種類_取引() As List(Of String)
'        Get
'            Return _データ種類_取引
'        End Get
'        Set(ByVal value As List(Of String))
'            _データ種類_取引 = value
'        End Set
'    End Property

'    Private _データ種類_取引名称 As IDictionary
'    Public Property データ種類_取引名称() As IDictionary
'        Get
'            Return _データ種類_取引名称
'        End Get
'        Set(ByVal value As IDictionary)
'            _データ種類_取引名称 = value
'        End Set
'    End Property

'    Private _データ種類_マスター As List(Of String)
'    Public Property データ種類_マスター() As List(Of String)
'        Get
'            Return _データ種類_マスター
'        End Get
'        Set(ByVal value As List(Of String))
'            _データ種類_マスター = value
'        End Set
'    End Property

'    Private _データ種類_マスター名称 As IDictionary
'    Public Property データ種類_マスター名称() As IDictionary
'        Get
'            Return _データ種類_マスター名称
'        End Get
'        Set(ByVal value As IDictionary)
'            _データ種類_マスター名称 = value
'        End Set
'    End Property

'    'A-20101213_2{
'    Private _Is検収基準_出荷 As Boolean
'    Public Property Is検収基準_出荷() As Boolean
'        Get
'            Return _Is検収基準_出荷
'        End Get
'        Set(ByVal value As Boolean)
'            _Is検収基準_出荷 = value
'        End Set
'    End Property

'    Private _Is検収基準_入荷 As Boolean
'    Public Property Is検収基準_入荷() As Boolean
'        Get
'            Return _Is検収基準_入荷
'        End Get
'        Set(ByVal value As Boolean)
'            _Is検収基準_入荷 = value
'        End Set
'    End Property
'    'A-20101213_2}

'    'A-20121120_1{
'    Private _Is予定在庫区分_入出庫 As Boolean
'    Public Property Is予定在庫区分_入出庫() As Boolean
'        Get
'            Return _Is予定在庫区分_入出庫
'        End Get
'        Set(ByVal value As Boolean)
'            _Is予定在庫区分_入出庫 = value
'        End Set
'    End Property
'    'A-20121120_1}

'#End Region

'#Region "メソッド"

'    Public Sub InitializeAdjustmentForm(ByVal creater As Batch.UserInterface.CommandViewBase)
'        Initialize(creater)
'        SetupFocusSwitch()
'        InitalizeForm()
'        SetupDivisionSelecter()
'        InitalizeFuction()
'    End Sub

'#End Region

'    Private Sub InitalizeForm()
'        _強制実行 = 0
'        dataShubetu.Value = 1
'        dataShurui.TextValue = ""
'        meisaiKubun.Value = 1
'        meisaiKubun.Enabled = False

'        checkKubunUriage.CheckState = CheckState.Checked
'        checkKubunJutyuu.CheckState = CheckState.Unchecked
'        checkKubunMitumori.CheckState = CheckState.Unchecked
'        checkKubunKeihi.CheckState = CheckState.Unchecked           'A-20080709_2
'        checkKubunNyuusyukka.CheckState = CheckState.Unchecked      'A-20101213_2

'        husenkubunPanel.Visible = False
'        husenkubunPanel.TabStop = False
'        If _受注管理 = 0 Then
'            checkKubunJutyuu.Visible = False
'            checkKubunMitumori.Left = 67
'        End If
'        If _見積管理 = 0 Then
'            checkKubunMitumori.Visible = False
'        End If
'        If _強化区分 < 3 OrElse _
'           _原価管理 = オプション区分定義型.区分型.行わない Then    'A-20080709_2
'            checkKubunKeihi.Visible = False                         'A-20080709_2
'        End If                                                      'A-20080709_2
'        checkKubunKeihi.Left = checkKubunMitumori.Left              'A-20080709_2

'        'D-20101213_2{
'        ''付箋使用区分のパネルサイズ変更
'        'Dim useCount As Integer = 0
'        'If _受注管理 = オプション区分定義型.区分型.行う Then useCount += 1
'        ''If _見積管理 = オプション区分定義型.区分型.行う Then useCount += 1                             'D-20080709_2
'        'If _見積管理 = オプション区分定義型.区分型.行う OrElse _
'        '   (_強化区分 >= 3 AndAlso _原価管理 = オプション区分定義型.区分型.行う) Then useCount += 1 '   'A-20080709_2

'        'If useCount = 0 Then husenkubunPanel.Width = 64
'        'If useCount <> 0 Then husenkubunPanel.Width = 64 + useCount * 64
'        'D-20101213_2}

'        _personalMessageViewer = New PersonalMessageViewer(SettingInfo, StatusBar)
'        MyBase.MessageViewer.StatusLabelControl = StatusBar.StatusLabelControl
'        dataShubetu.Focus()
'    End Sub

'    Private Sub InitalizeFuction()
'        _ContextMenu = New SmartControl.ContextMenu.ContextMenu
'        _ContextMenu.FunctionBar = FunctionBar

'        FunctionBar.Items.SetControls(FunctionControl.KeyType.F3, "コード検索", AddressOf RequestCodeSerch, dataShurui.InputTextControl)
'        FunctionBar.SetUpFunctionEvent(Me)
'    End Sub

'#Region "フォーカス制御"

'    ''' <summary>
'    ''' 入力制御の初期化を行う。(フォーカススイッチの初期化)
'    ''' </summary>
'    ''' <remarks></remarks>
'    Private Sub SetupFocusSwitch()
'        _focusSwitcher = New Foundation.FocusSwitch.FocusSwitcher
'        _focusSwitcher.SetForm(Me)

'        dataShubetu.GroupNo = 0
'        dataShubetu.SubGroupNo = 0
'        dataShubetu.RemarkString = "HANZ030001"
'        _focusSwitcher.AddControl(dataShubetu)

'        dataShurui.InputTextControl.GroupNo = 0
'        dataShurui.InputTextControl.SubGroupNo = 0
'        dataShurui.InputTextControl.RemarkString = "HANZ030002"
'        _focusSwitcher.AddControl(dataShurui.InputTextControl)

'        meisaiKubun.GroupNo = 0
'        meisaiKubun.SubGroupNo = 0
'        meisaiKubun.RemarkString = "HANZ030003"
'        _focusSwitcher.AddControl(meisaiKubun)

'        meisaiKubun.GroupNo = 1
'        meisaiKubun.SubGroupNo = 0
'        meisaiKubun.RemarkString = checkKubunUriage.Name
'        _focusSwitcher.AddControl(checkKubunUriage)

'        meisaiKubun.GroupNo = 1
'        meisaiKubun.SubGroupNo = 0
'        meisaiKubun.RemarkString = checkKubunJutyuu.Name
'        _focusSwitcher.AddControl(checkKubunJutyuu)

'        meisaiKubun.GroupNo = 1
'        meisaiKubun.SubGroupNo = 0
'        meisaiKubun.RemarkString = checkKubunMitumori.Name
'        _focusSwitcher.AddControl(checkKubunMitumori)

'        meisaiKubun.GroupNo = 1                                     'A-20080709_2
'        meisaiKubun.SubGroupNo = 0                                  'A-20080709_2
'        meisaiKubun.RemarkString = checkKubunKeihi.Name             'A-20080709_2
'        _focusSwitcher.AddControl(checkKubunKeihi)                  'A-20080709_2

'        'A-20101213_2{
'        meisaiKubun.GroupNo = 1
'        meisaiKubun.SubGroupNo = 0
'        meisaiKubun.RemarkString = checkKubunNyuusyukka.Name
'        _focusSwitcher.AddControl(checkKubunNyuusyukka)
'        'A-20101213_2}

'        ok.GroupNo = 1
'        ok.SubGroupNo = 0
'        ok.RemarkString = ok.Name
'        _focusSwitcher.AddControl(ok)

'        cancel.GroupNo = 2
'        cancel.SubGroupNo = 0
'        cancel.RemarkString = cancel.Name
'        _focusSwitcher.AddControl(cancel)

'        _focusSwitcher.AddCheckMethod(dataShurui.InputTextControl, FocusSwitch.CheckModeType.移動元チェック, AddressOf CheckMethodMoveOther_DataShurui)
'        _focusSwitcher.AddCheckMethod(meisaiKubun, FocusSwitch.CheckModeType.移動先チェック, AddressOf CheckMethodMoveIn_MeisaiKubun)
'        _focusSwitcher.AddGroupCheckMethod(0, FocusSwitch.CheckModeType.移動元チェック, AddressOf CheckMethodMoveOther_Group0)
'        _focusSwitcher.AddCheckMethod(checkKubunUriage, FocusSwitch.CheckModeType.移動先チェック, AddressOf CheckMethodMoveIn_HusenKubun)
'        _focusSwitcher.AddCheckMethod(checkKubunJutyuu, FocusSwitch.CheckModeType.移動先チェック, AddressOf CheckMethodMoveIn_HusenKubun)
'        _focusSwitcher.AddCheckMethod(checkKubunMitumori, FocusSwitch.CheckModeType.移動先チェック, AddressOf CheckMethodMoveIn_HusenKubun)
'        _focusSwitcher.AddCheckMethod(checkKubunKeihi, FocusSwitch.CheckModeType.移動先チェック, AddressOf CheckMethodMoveIn_HusenKubun)        'A-20080709_2
'        _focusSwitcher.AddCheckMethod(checkKubunNyuusyukka, FocusSwitch.CheckModeType.移動先チェック, AddressOf CheckMethodMoveIn_HusenKubun)   'A-20101213_2
'    End Sub

'    Public Function CheckMethodMoveOther_DataShurui(ByVal args As CheckMethodArgs) As Boolean
'        StatusBar.StatusLabelControl.Text = ""
'        If args.移動先グループ番号 = 2 Then Return True
'        If CheckDataShurui() = True Then
'            GetDataShuruiDisplayName()
'            CheckBoxEnable()
'        Else
'            If args.移動方向 = CheckMethodArgs.移動方向型.後へ Then
'                If dataShurui.TextValue.TrimEnd = "" Then
'                    MyBase.MessageViewer.Show(72)        ' この項目は省略できません。
'                Else
'                    _personalMessageViewer.Show(6, PersonalMessageViewer.MessageType.StatusBar)
'                End If
'                dataShurui.InputTextControl.SelectAll()
'                dataShurui.InputTextControl.UpdateCaretPos(0)
'                Return False
'            Else
'                dataShurui.TextValue = _oldDataShurui
'            End If
'        End If
'        Return True
'    End Function

'    Public Function CheckMethodMoveIn_MeisaiKubun(ByVal args As CheckMethodArgs) As Boolean
'        If dataShurui.TextValue.TrimEnd = "" OrElse CheckDataShurui() = False Then
'            dataShurui.InputTextControl.Focus()
'        Else
'            GetDataShuruiDisplayName()
'            CheckBoxEnable()
'        End If
'        Return True
'    End Function

'    Public Function CheckMethodMoveIn_HusenKubun(ByVal args As CheckMethodArgs) As Boolean
'        'If dataShubetu.Value = 1 OrElse (dataShubetu.Value = 2 AndAlso (Val(dataShurui.TextValue) = 2 OrElse _
'        '   Val(dataShurui.TextValue) = 4 OrElse Val(dataShurui.TextValue) = 5)) OrElse _
'        '   (dataShubetu.Value = 2 AndAlso Val(dataShurui.TextValue) = 3 AndAlso _受注管理 = 0) OrElse _
'        '   (dataShubetu.Value = 2 AndAlso Val(dataShurui.TextValue) = 1 AndAlso _受注管理 = 0 AndAlso _見積管理 = 0) Then          'D-20080709_2
'        'D-20101213_2{
'        'If dataShubetu.Value = 1 OrElse (dataShubetu.Value = 2 AndAlso (Val(dataShurui.TextValue) = 2 OrElse _
'        '   Val(dataShurui.TextValue) = 4 OrElse Val(dataShurui.TextValue) = 5)) OrElse _
'        '   (dataShubetu.Value = 2 AndAlso Val(dataShurui.TextValue) = 3 AndAlso _受注管理 = 0 AndAlso _原価管理 = 0) OrElse _
'        '   (dataShubetu.Value = 2 AndAlso Val(dataShurui.TextValue) = 1 AndAlso _受注管理 = 0 AndAlso _見積管理 = 0) Then           'A-20080709_2
'        '    Return False
'        'End If
'        'D-20101213_2}
'        'D-20121120_1{
'        ''A-20101213_2{
'        'If dataShubetu.Value = 1 OrElse (dataShubetu.Value = 2 AndAlso (Val(dataShurui.TextValue) = 2 OrElse _
'        '   Val(dataShurui.TextValue) = 4 OrElse Val(dataShurui.TextValue) = 5)) OrElse _
'        '   (dataShubetu.Value = 2 AndAlso Val(dataShurui.TextValue) = 3 AndAlso _受注管理 = 0 AndAlso _原価管理 = 0 AndAlso _Is検収基準_入荷 = False) OrElse _
'        '   (dataShubetu.Value = 2 AndAlso Val(dataShurui.TextValue) = 1 AndAlso _受注管理 = 0 AndAlso _見積管理 = 0 AndAlso _Is検収基準_出荷 = False) Then
'        '    Return False
'        'End If
'        ''A-20101213_2}
'        'D-20121120_1}
'        'A-20121120_1{
'        If dataShubetu.Value = 1 OrElse _
'           (dataShubetu.Value = 2 AndAlso (Val(dataShurui.TextValue) = 2 OrElse Val(dataShurui.TextValue) = 4)) OrElse _
'           (dataShubetu.Value = 2 AndAlso Val(dataShurui.TextValue) = 3 AndAlso _受注管理 = 0 AndAlso _原価管理 = 0 AndAlso _Is検収基準_入荷 = False) OrElse _
'           (dataShubetu.Value = 2 AndAlso Val(dataShurui.TextValue) = 1 AndAlso _受注管理 = 0 AndAlso _見積管理 = 0 AndAlso _Is検収基準_出荷 = False) OrElse _
'           (dataShubetu.Value = 2 AndAlso Val(dataShurui.TextValue) = 5 AndAlso _Is予定在庫区分_入出庫 = False) Then
'            Return False
'        End If
'        'A-20121120_1}
'        If dataShurui.TextValue.TrimEnd = "" OrElse CheckDataShurui() = False Then
'            dataShurui.InputTextControl.Focus()
'        Else
'            GetDataShuruiDisplayName()
'        End If

'        Return True
'    End Function

'    Public Function CheckMethodMoveOther_Group0(ByVal args As CheckMethodArgs) As Boolean
'        If args.移動先グループ番号 = 2 Then Return True
'        If (args.移動元グループ番号 < args.移動先グループ番号) Then
'            If dataShurui.TextValue.TrimEnd = "" OrElse CheckDataShurui() = False Then
'                dataShurui.InputTextControl.Focus()
'                MyBase.MessageViewer.Show(72)        ' この項目は省略できません。
'            Else
'                GetDataShuruiDisplayName()
'                CheckBoxEnable()
'            End If
'        End If
'        Return True
'    End Function
'    Private Function CheckDataShurui() As Boolean
'        If dataShubetu.Value - 1 = 0 Then
'            If _データ種類_マスター.Contains(dataShurui.TextValue) = True Then Return True
'        Else
'            If _データ種類_取引.Contains(dataShurui.TextValue) = True Then Return True
'        End If
'        Return False
'    End Function

'    Private Sub GetDataShuruiDisplayName()
'        If dataShubetu.Value - 1 = 0 Then
'            dataShurui.DispNameText = _データ種類_マスター名称(dataShurui.TextValue).ToString
'            _oldDataShurui = dataShurui.TextValue
'        Else
'            dataShurui.DispNameText = _データ種類_取引名称(dataShurui.TextValue).ToString
'            _oldDataShurui = dataShurui.TextValue
'        End If
'    End Sub

'#End Region

'    Private Sub RequestCodeSerch(ByVal sender As Control)
'        Dim selectedIndex As Integer
'        Dim result As Boolean
'        If dataShubetu.Value - 1 = 0 Then
'            For i As Integer = 0 To _データ種類_マスター.Count - 1
'                If _データ種類_マスター(i) = String.Format("{0:00}", dataShurui.TextValue) Then
'                    selectedIndex = i
'                    Exit For
'                End If
'            Next
'            result = _targetMaster.SelectDivision(selectedIndex, selectedIndex)
'        Else
'            For i As Integer = 0 To _データ種類_取引.Count - 1
'                If _データ種類_取引(i) = String.Format("{0:00}", dataShurui.TextValue) Then
'                    selectedIndex = i
'                    Exit For
'                End If
'            Next
'            result = _targetTorihiki.SelectDivision(selectedIndex, selectedIndex)
'        End If

'        If result = True Then
'            If dataShubetu.Value - 1 = 0 Then
'                dataShurui.TextValue = _データ種類_マスター(selectedIndex)
'            Else
'                dataShurui.TextValue = _データ種類_取引(selectedIndex)
'            End If
'            _focusSwitcher.GetNextControl(sender).Focus()
'        End If
'    End Sub

'    ''' <summary>
'    ''' 区分選択のリスト作成
'    ''' </summary>
'    ''' <remarks></remarks>
'    Private Sub SetupDivisionSelecter()
'        _targetMaster = CommonFactory.CreateInstance(Of IDivisionSelecter)(Me, GetType(DivisionSelecter))
'        _targetMaster.Initialize(SettingInfo, InitInfo, SaveInfo)
'        _targetTorihiki = CommonFactory.CreateInstance(Of IDivisionSelecter)(Me, GetType(DivisionSelecter))
'        _targetTorihiki.Initialize(SettingInfo, InitInfo, SaveInfo)
'        'マスター用リスト作成*****************************************************************************************
'        Dim masterList As New List(Of String)
'        Dim i As Integer
'        For i = 0 To _データ種類_マスター.Count - 1
'            masterList.Add("  " & _データ種類_マスター(i).ToString & "  " & _データ種類_マスター名称(_データ種類_マスター(i)).ToString)
'        Next
'        '取引データ用リスト作成***************************************************************************************
'        Dim torihikiList As New List(Of String)
'        For i = 0 To _データ種類_取引.Count - 1
'            torihikiList.Add("  " & _データ種類_取引(i).ToString & "  " & _データ種類_取引名称(_データ種類_取引(i)).ToString)
'        Next
'        _targetMaster.SetupSelectForm("データ種類", masterList.ToArray)
'        _targetTorihiki.SetupSelectForm("データ種類", torihikiList.ToArray)
'    End Sub

'#Region "コントロールイベント"

'    Private Sub SaveCondition()
'        _データ種別 = dataShubetu.Value
'        _データ種類 = dataShurui.TextValue
'        _明細区分 = meisaiKubun.Value
'        _整合処理チェック区分_売上_仕入 = checkKubunUriage.CheckState
'        _整合処理チェック区分_受注_発注 = checkKubunJutyuu.CheckState
'        _整合処理チェック区分_見積 = checkKubunMitumori.CheckState
'        _整合処理チェック区分_経費 = checkKubunKeihi.CheckState                 'A-20080709_2
'        _整合処理チェック区分_出荷_入荷 = checkKubunNyuusyukka.CheckState       'A-20101213_2
'    End Sub

'    Private Function FinalVaridationCheck() As Boolean
'        If dataShubetu.Value - 1 = 0 Then
'            If _データ種類_マスター.Contains(dataShurui.TextValue) = True Then Return True
'        Else
'            If _データ種類_取引.Contains(dataShurui.TextValue) = True Then Return True
'        End If

'        Return False
'    End Function

'    Private Sub dataShubetu_SelChange(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles dataShubetu.SelChange
'        If dataShubetu.Value = 1 Then
'            meisaiKubun.Enabled = False
'            meisaiKubun.TabStop = False
'            husenkubunPanel.Visible = False
'            husenkubunPanel.TabStop = False
'            checkKubunUriage.CheckState = CheckState.Checked
'            checkKubunJutyuu.CheckState = CheckState.Unchecked
'            checkKubunMitumori.CheckState = CheckState.Unchecked
'            checkKubunKeihi.CheckState = CheckState.Unchecked                   'A-20080709_2
'            checkKubunNyuusyukka.CheckState = CheckState.Unchecked               'A-20101213_2
'        Else
'            meisaiKubun.Enabled = True
'            meisaiKubun.TabStop = True
'        End If
'    End Sub

'    Private Sub CheckBoxEnable()
'        If dataShubetu.Value = 1 Then
'            husenkubunPanel.Visible = False
'            husenkubunPanel.TabStop = False
'            checkKubunUriage.CheckState = CheckState.Checked
'            checkKubunJutyuu.CheckState = CheckState.Unchecked
'            checkKubunMitumori.CheckState = CheckState.Unchecked
'            checkKubunKeihi.CheckState = CheckState.Unchecked                   'A-20080709_2
'            checkKubunNyuusyukka.CheckState = CheckState.Unchecked               'A-20101213_2
'        Else
'            'A-20101213_2{
'            Dim チェックボックス配置(2) As Integer
'            チェックボックス配置(0) = checkKubunUriage.Left + (checkKubunNyuusyukka.Left - checkKubunUriage.Left)
'            チェックボックス配置(1) = チェックボックス配置(0) + (checkKubunNyuusyukka.Left - checkKubunUriage.Left)
'            チェックボックス配置(2) = チェックボックス配置(1) + (checkKubunNyuusyukka.Left - checkKubunUriage.Left)
'            'A-20101213_2}
'            'A-20121120_1{
'            If _Is予定在庫区分_入出庫 = True Then
'                If Val(dataShurui.TextValue) <> 5 Then
'                    checkKubunUriage.Width = 53
'                    checkKubunJutyuu.Width = 53
'                    checkKubunJutyuu.Left = チェックボックス配置(0)
'                    If _受注管理 = 0 Then
'                        checkKubunJutyuu.Visible = False
'                        checkKubunJutyuu.CheckState = CheckState.Unchecked
'                    End If
'                End If
'            End If
'            'A-20121120_1}
'            Select Case Val(dataShurui.TextValue)
'                Case 1
'                    'If _受注管理 = 0 AndAlso _見積管理 = 0 Then             'D-20101213_2
'                    If _受注管理 = 0 AndAlso _見積管理 = 0 AndAlso _Is検収基準_出荷 = False Then                 'A-20101213_2
'                        husenkubunPanel.Visible = False
'                        husenkubunPanel.TabStop = False
'                        checkKubunUriage.CheckState = CheckState.Checked
'                        checkKubunJutyuu.CheckState = CheckState.Unchecked
'                        checkKubunMitumori.CheckState = CheckState.Unchecked
'                        checkKubunNyuusyukka.CheckState = CheckState.Unchecked       'A-20101213_2
'                    Else
'                        husenkubunPanel.Visible = True
'                        husenkubunPanel.TabStop = True
'                        checkKubunUriage.Text = "売上"
'                        checkKubunJutyuu.Text = "受注"
'                        checkKubunNyuusyukka.Text = "出荷"                      'A-20101213_2
'                        If _見積管理 = 1 Then
'                            checkKubunMitumori.Visible = True
'                        End If
'                    End If
'                    checkKubunKeihi.Visible = False                             'A-20080709_2
'                    checkKubunKeihi.CheckState = CheckState.Unchecked           'A-20080709_2
'                    'A-20101213_2{
'                    'チェックボックスの配置
'                    If _Is検収基準_出荷 = True Then
'                        checkKubunNyuusyukka.Visible = True
'                        checkKubunNyuusyukka.Left = チェックボックス配置(0)
'                        If _受注管理 = 1 Then
'                            checkKubunJutyuu.Left = チェックボックス配置(1)
'                            If _見積管理 = 1 Then
'                                checkKubunMitumori.Left = チェックボックス配置(2)
'                            End If
'                        Else
'                            If _見積管理 = 1 Then
'                                checkKubunMitumori.Left = チェックボックス配置(1)
'                            End If
'                        End If
'                    Else
'                        checkKubunNyuusyukka.Visible = False
'                        If _受注管理 = 1 Then
'                            checkKubunJutyuu.Left = チェックボックス配置(0)
'                            If _見積管理 = 1 Then
'                                checkKubunMitumori.Left = チェックボックス配置(1)
'                            End If
'                        Else
'                            If _見積管理 = 1 Then
'                                checkKubunMitumori.Left = チェックボックス配置(0)
'                            End If
'                        End If
'                    End If
'                    'A-20101213_2}
'                Case 3
'                    'If _受注管理 = 1 Then                                      'D-20080709_2
'                    '    husenkubunPanel.Visible = True                         'D-20080709_2
'                    '    husenkubunPanel.TabStop = True                         'D-20080709_2
'                    '    checkKubunUriage.Text = "仕入"                         'D-20080709_2
'                    '    checkKubunJutyuu.Text = "発注"                         'D-20080709_2
'                    'Else                                                       'D-20080709_2
'                    '    husenkubunPanel.Visible = False                        'D-20080709_2
'                    '    husenkubunPanel.TabStop = False                        'D-20080709_2
'                    '    checkKubunUriage.CheckState = CheckState.Checked       'D-20080709_2
'                    '    checkKubunJutyuu.CheckState = CheckState.Unchecked     'D-20080709_2
'                    '    checkKubunMitumori.CheckState = CheckState.Unchecked   'D-20080709_2
'                    'End If                                                     'D-20080709_2
'                    'checkKubunMitumori.Visible = False                         'D-20080709_2
'                    'D-20101213_2{
'                    ''If _受注管理 = 0 AndAlso _
'                    '(_強化区分 < 3 OrElse _原価管理 = 0) Then                'A-20080709_2
'                    'D-20101213_2}
'                    'A-20101213_2{
'                    If _受注管理 = 0 AndAlso _
'                       (_強化区分 < 3 OrElse _原価管理 = 0) AndAlso _
'                       _Is検収基準_入荷 = False Then
'                        'A-20101213_2}
'                        husenkubunPanel.Visible = False                         'A-20080709_2
'                        husenkubunPanel.TabStop = False                         'A-20080709_2
'                        checkKubunUriage.CheckState = CheckState.Checked        'A-20080709_2
'                        checkKubunJutyuu.CheckState = CheckState.Unchecked      'A-20080709_2
'                        checkKubunMitumori.CheckState = CheckState.Unchecked    'A-20080709_2
'                        checkKubunKeihi.CheckState = CheckState.Unchecked       'A-20080709_2
'                    Else                                                        'A-20080709_2
'                        husenkubunPanel.Visible = True                          'A-20080709_2
'                        husenkubunPanel.TabStop = True                          'A-20080709_2
'                        checkKubunUriage.Text = "仕入"                          'A-20080709_2
'                        checkKubunJutyuu.Text = "発注"                          'A-20080709_2
'                        checkKubunNyuusyukka.Text = "入荷"                      'A-20101213_2
'                        If (_強化区分 >= 3 AndAlso _原価管理 = 1) Then          'A-20080709_2
'                            checkKubunKeihi.Visible = True                      'A-20080709_2
'                        End If                                                  'A-20080709_2
'                    End If                                                      'A-20080709_2
'                    checkKubunMitumori.Visible = False                          'A-20080709_2
'                    checkKubunMitumori.CheckState = CheckState.Unchecked        'A-20080709_2
'                    'A-20101213_2{
'                    'チェックボックスの配置
'                    If _Is検収基準_入荷 = True Then
'                        checkKubunNyuusyukka.Visible = True
'                        checkKubunNyuusyukka.Left = チェックボックス配置(0)
'                        If _受注管理 = 1 Then
'                            checkKubunJutyuu.Left = チェックボックス配置(1)
'                            If (_強化区分 >= 3 AndAlso _原価管理 = 1) Then
'                                checkKubunKeihi.Left = チェックボックス配置(2)
'                            End If
'                        Else
'                            If (_強化区分 >= 3 AndAlso _原価管理 = 1) Then
'                                checkKubunKeihi.Left = チェックボックス配置(1)
'                            End If
'                        End If
'                    Else
'                        checkKubunNyuusyukka.Visible = False
'                        If _受注管理 = 1 Then
'                            checkKubunJutyuu.Left = チェックボックス配置(0)
'                            If (_強化区分 >= 3 AndAlso _原価管理 = 1) Then
'                                checkKubunKeihi.Left = チェックボックス配置(1)
'                            End If
'                        Else
'                            If (_強化区分 >= 3 AndAlso _原価管理 = 1) Then
'                                checkKubunKeihi.Left = チェックボックス配置(0)
'                            End If
'                        End If
'                    End If
'                    'A-20101213_2}
'                    'A-20121120_1{
'                Case 5
'                    If _Is予定在庫区分_入出庫 = False Then
'                        husenkubunPanel.Visible = False
'                        husenkubunPanel.TabStop = False
'                        checkKubunUriage.CheckState = CheckState.Checked
'                        checkKubunJutyuu.CheckState = CheckState.Unchecked
'                        checkKubunMitumori.CheckState = CheckState.Unchecked
'                        checkKubunKeihi.CheckState = CheckState.Unchecked
'                        checkKubunNyuusyukka.CheckState = CheckState.Unchecked
'                    Else
'                        checkKubunJutyuu.Visible = True
'                        husenkubunPanel.Visible = True
'                        husenkubunPanel.TabStop = True
'                        checkKubunUriage.Text = "入出庫"
'                        checkKubunJutyuu.Text = "入出庫予定"
'                        checkKubunUriage.Width = 65
'                        checkKubunJutyuu.Width = 95
'                        checkKubunJutyuu.Left = チェックボックス配置(0) + 12

'                        checkKubunMitumori.Visible = False
'                        checkKubunMitumori.CheckState = CheckState.Unchecked
'                        checkKubunKeihi.Visible = False
'                        checkKubunKeihi.CheckState = CheckState.Unchecked
'                        checkKubunNyuusyukka.Visible = False
'                        checkKubunNyuusyukka.CheckState = CheckState.Unchecked
'                    End If
'                    'A-20121120_1}

'                    'Case 2, 4, 5   'D-20121120_1
'                Case 2, 4           'A-20121120_1
'                    husenkubunPanel.Visible = False
'                    husenkubunPanel.TabStop = False
'                    checkKubunUriage.CheckState = CheckState.Checked
'                    checkKubunJutyuu.CheckState = CheckState.Unchecked
'                    checkKubunMitumori.CheckState = CheckState.Unchecked
'                    checkKubunKeihi.CheckState = CheckState.Unchecked           'A-20080709_2
'                    checkKubunNyuusyukka.CheckState = CheckState.Unchecked      'A-20101213_2
'            End Select
'        End If
'    End Sub

'    Private Sub DetailConditionForm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
'        If e.KeyCode = Keys.Escape Then
'            Me.Close()
'        End If
'    End Sub

'    Private Sub OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ok.Click
'        If dataShurui.TextValue = "" OrElse CheckDataShurui() = False Then
'            dataShurui.InputTextControl.Focus()
'            MyBase.MessageViewer.Show(72)        ' この項目は省略できません。
'            Exit Sub
'        Else
'            GetDataShuruiDisplayName()
'            'CheckBoxEnable()
'        End If

'        'If dataShubetu.Value = 2 AndAlso checkKubunUriage.CheckState = CheckState.Unchecked AndAlso _
'        'checkKubunJutyuu.CheckState = CheckState.Unchecked AndAlso checkKubunMitumori.CheckState = CheckState.Unchecked Then       'D-20080709_2
'        'D-20101213_2{
'        'If dataShubetu.Value = 2 AndAlso _
'        '   checkKubunUriage.CheckState = CheckState.Unchecked AndAlso _
'        '   checkKubunJutyuu.CheckState = CheckState.Unchecked AndAlso _
'        '   checkKubunMitumori.CheckState = CheckState.Unchecked AndAlso _
'        '   checkKubunKeihi.CheckState = CheckState.Unchecked Then                                                                   'A-20080709_2
'        'D-20101213_2}
'        'A-20101213_2{
'        If dataShubetu.Value = 2 AndAlso _
'           checkKubunUriage.CheckState = CheckState.Unchecked AndAlso _
'           checkKubunNyuusyukka.CheckState = CheckState.Unchecked AndAlso _
'           checkKubunJutyuu.CheckState = CheckState.Unchecked AndAlso _
'           checkKubunMitumori.CheckState = CheckState.Unchecked AndAlso _
'           checkKubunKeihi.CheckState = CheckState.Unchecked Then
'            'A-20101213_2}
'            _personalMessageViewer.Show(11, PersonalMessageViewer.MessageType.MessageBox, IMessageViewer.DefaultButtonType.OK, , , IMessageViewer.IconType.Exclamation)
'            checkKubunUriage.Focus()
'            Exit Sub
'        End If

'        If _personalMessageViewer.Show(0, PersonalMessageViewer.MessageType.MessageBox, IMessageViewer.DefaultButtonType.No, , , IMessageViewer.IconType.Question) = IMessageViewer.ShowResultType.No Then
'            Exit Sub
'        End If
'        If FinalVaridationCheck() = False Then
'            Exit Sub
'        End If
'        SaveCondition()
'        _強制実行 = 1
'        Me.Close()
'    End Sub

'    Private Sub Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cancel.Click
'        _強制実行 = 0
'        Me.Close()
'    End Sub

'#End Region

'End Class
