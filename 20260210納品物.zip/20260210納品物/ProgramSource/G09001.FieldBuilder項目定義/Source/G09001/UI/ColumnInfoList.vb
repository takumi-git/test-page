﻿''' <summary>
''' グリッドのカラム定義情報(グリッドヘルパーで使用)
''' </summary>
''' <remarks></remarks>
Public Class ColumnInfoList
    Inherits ColumnInfoListBase

    Private _myコントロール情報 As New Myコントロール情報型
    Private _MyForm As OSK.X1.Foundation.UIDesign.UserInterface.DesignFormBase    'X1変換Tool-20160427
    Private _gridEntry As OSK.X1.Foundation.SimpleControl.GridEdit    'X1変換Tool-20160427

    Sub New(ByVal initInfo As IDictionary, ByVal settingInfo As IDictionary, ByVal myForm As OSK.X1.Foundation.UIDesign.UserInterface.DesignFormBase)    'X1変換Tool-20160427
        MyBase.New(initInfo, settingInfo)
        _MyForm = myForm
    End Sub

    Sub SetGridEntry(ByVal gridEntry As OSK.X1.Foundation.SimpleControl.GridEdit)    'X1変換Tool-20160427
        _gridEntry = gridEntry
        SetUpItemInfo()
    End Sub

    Private Sub SetUpItemInfo()
        _myコントロール情報.Initialize(SettingInfo)
        _myコントロール情報.InitializeMyControlInfo(InitInfo)

        Dim ComboListCount As Integer = 8                                                                                                                   'A-20080709_3
        Dim ComboCellWidth As Integer = 16                                                                                                                  'A-20080709_3
        ComboCellWidth = 19                                                                                                                                 'A-20080806_1
        Dim zokuseiList() As String = {"0:未使用", "1:全角文字", "2:半角文字", "3:数値", "4:日付(年月日)", "5:日付(年月)", "6:日付(年)", "9:参照定義ｺｰﾄﾞ"}
        zokuseiList = New String() {"0:未使用", "1:全角文字", "2:半角文字", "3:数値", "4:日付(年月日)", "5:日付(年月)", "6:日付(年)", "9:参照定義コード"}   'A-20080806_1
        If _myコントロール情報.強化区分 >= 3 AndAlso
           _myコントロール情報.拡張項目データリンク機能 = 機能区分定義型.拡張項目データリンク機能型.行う Then                                               'A-20080709_3
            Dim zokuseilist_wk() As String = {"0:未使用", "1:全角文字", "2:半角文字", "3:数値", "4:日付(年月日)", "5:日付(年月)", "6:日付(年)", "7:参照定義ｺｰﾄﾞ" _
                                            , "8:画像", "9:実行ファイル", "10:ファイル", "11:フォルダ", "12:URL", "13:メールアドレス"}                    'A-20080709_3
            zokuseilist_wk = New String() {"0:未使用", "1:全角文字", "2:半角文字", "3:数値", "4:日付(年月日)", "5:日付(年月)", "6:日付(年)", "7:参照定義コード" _
                                         , "8:画像", "9:実行ファイル", "10:ファイル", "11:フォルダ", "12:URL", "13:メールアドレス"}                       'A-20080806_1
            zokuseiList = zokuseilist_wk                                                                                                                    'A-20080709_3
            ComboListCount = 14                                                                                                                             'A-20080709_3
            ComboCellWidth = 19                                                                                                                             'A-20080709_3
        End If                                                                                                                                              'A-20080709_3


        '↓A-20180314-X1-新元号
        If _myコントロール情報.年属性_年月属性表現方法 = 拡張項目設計型.年属性_年月属性表現方法型.年度＿年月度 Then
            For i As Integer = 0 To zokuseiList.Length - 1
                If zokuseiList(i).Contains("5:日付(年月)") = True Then
                    zokuseiList(i) = zokuseiList(i).Replace("5:日付(年月)", "5:日付(年月度)")
                End If
                If zokuseiList(i).Contains("6:日付(年)") = True Then
                    zokuseiList(i) = zokuseiList(i).Replace("6:日付(年)", "6:日付(年度)")
                End If
            Next
        End If
        'D-20080709_3
        AddItemInfo(New ColumnInfo("CUSZE01004", GetColSize(ComboCellWidth), "属性", 0, False, "0", False,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Left,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    OSK.X1.Foundation.Controls.Grid.Common.GridSortMode.NotSort,
                    New SettingComboBox(ComboListCount, Combo.Common.Control.StyleType.DropDown, zokuseiList)))

        Dim maxLength_Size As Integer = 2
        If _myコントロール情報.拡張項目データリンク桁数拡張 = True Then
            maxLength_Size = 3
        End If
        AddItemInfo(New ColumnInfo("CUSZE01005", GetColSize(5), "桁数", 0, False, "0", False,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Right,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    OSK.X1.Foundation.Controls.Grid.Common.GridSortMode.Number,
                    New SettingInputNumerical(True, maxLength_Size, 0)))
        '↑A-20160817-X1-桁数拡張
        AddItemInfo(New ColumnInfo("CUSZE01006", GetColSize(5), "小数", 0, False, "0", False,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Right,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    OSK.X1.Foundation.Controls.Grid.Common.GridSortMode.Number,
                    New SettingInputNumerical(True, 1, 0)))    'X1変換Tool-20160427



        AddItemInfo(New ColumnInfo("CUSZE01007", GetColSize(30), "項目名称", 0, False, "", False,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Left,
                    OSK.X1.Foundation.Controls.Grid.Common.HorzAlign.Center,
                    OSK.X1.Foundation.Controls.Grid.Common.GridSortMode.Character,
                    New SettingInputText(20, OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CustomLength,
                                         OSK.X1.Foundation.Controls.InputText.ImeModeType.Hiragana, False, False, True, True, True, True, True, True, True, True, True)))

    End Sub

    Private Function GetColSize(ByVal maxlength As Integer) As Integer
        Dim utilitty As OSK.X1.Foundation.Utility.UserInterface.WidthCalculator    'X1変換Tool-20160427
        utilitty = New OSK.X1.Foundation.Utility.UserInterface.WidthCalculator    'X1変換Tool-20160427
        Return utilitty.GetSize(_MyForm.ScaleFactor, _gridEntry, maxlength, 5, 0).Width
    End Function

    Private Function GetshohinCodeCollength(ByVal maxlength As Integer) As Boolean
        If maxlength < 20 Then
            Return False
        End If
        Return True
    End Function

End Class


