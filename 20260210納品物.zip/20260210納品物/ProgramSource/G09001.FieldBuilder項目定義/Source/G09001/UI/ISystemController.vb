﻿''' <summary>
''' 個別設定用コントローラー
''' </summary>
''' <remarks></remarks>
<CLSCompliant(True)> _
Public Interface ISystemController
    Inherits IInsideJob

#Region "列挙型"

    ''' <summary>
    ''' 左右矢印用
    ''' </summary>
    ''' <remarks></remarks>
    Enum 左右矢印型 As Integer
        項目間 = 0
        項目内
    End Enum

    ''' <summary>
    ''' Enterキー移動方向用
    ''' </summary>
    ''' <remarks></remarks>
    Enum Enterキー移動方向型 As Integer
        右 = 0
        下
    End Enum

    ''' <summary>
    ''' ESCキー動作用
    ''' </summary>
    ''' <remarks></remarks>
    Enum ESCキー動作型 As Integer
        終了 = 0
        終了しない
    End Enum

#End Region

#Region "プロパティ"

    ''' <summary>
    ''' 左右矢印キー
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property 左右矢印キー() As 左右矢印型

    ''' <summary>
    ''' ESCキー動作
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property ESCキー動作() As ESCキー動作型


    ''' <summary>
    ''' Enterキー移動方向
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property Enterキー移動方向() As Enterキー移動方向型

#End Region

#Region "メソッド"

    ''' <summary>
    ''' SaveInfoを返す
    ''' </summary>
    ''' <param name="saveInfo">更新情報</param>
    ''' <remarks></remarks>
    Sub GetSaveInfo(ByRef saveInfo As IDictionary)

    ''' <summary>
    ''' InitInfoの反映
    ''' </summary>
    ''' <remarks></remarks>
    Sub SetUpSystemController()
#End Region

End Interface
