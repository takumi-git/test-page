﻿''' <summary>
''' データアクセス読込クラス
''' </summary>
''' <remarks></remarks>
Public Class DataAccessorReader
    Inherits DataAccessorBase

    Private _reader As IDataReader

    ''' <summary>
    ''' データアクセスのインスタンスを設定する
    ''' </summary>
    ''' <param name="dataAccessor">データアクセス</param>
    ''' <remarks></remarks>
    Public Overrides Sub SetupDataAccessor(Of T)(ByVal dataAccessor As T)
        _reader = CType(dataAccessor, IDataReader)
    End Sub

    ''' <summary>
    ''' データを取得する
    ''' </summary>
    ''' <param name="readParamInfo">読込パラメータ</param>
    ''' <returns>取得データ</returns>
    ''' <remarks></remarks>
    Public Function GetData(ByRef readParamInfo As IDictionary(Of IReadParam.取得区分型, IReadParam)) As IDictionary(Of IReadParam.取得区分型, DataTable)
        Dim method As New DataAccessorReader.GetDataMethod(AddressOf GetData)
        Dim exDA As Exception = Nothing         '●別スレッド側の例外格納用
        Dim resultData As IDictionary(Of IReadParam.取得区分型, DataTable) = New Dictionary(Of IReadParam.取得区分型, DataTable)

        Dim asyncResult As IAsyncResult = method.BeginInvoke(readParamInfo, exDA, Nothing, Nothing)
        'System.Windows.Forms.Application.DoEvents()        'D-20130404_1

        'WaitAccessorProcess(Me)                            'D-20130404_1

        CallWaitProcess(Me)                                 'A-20130404_1

        resultData = method.EndInvoke(readParamInfo, exDA, asyncResult)

        If exDA IsNot Nothing Then  '別スレッド側の例外はメインスレッド側で処理する。
            Throw exDA
        End If

        Return resultData
    End Function

    ''' <summary>
    ''' データを取得する
    ''' </summary>
    ''' <param name="readParamInfo">読込パラメータ</param>
    ''' <returns>取得データ</returns>
    ''' <remarks></remarks>
    Private Delegate Function GetDataMethod(ByRef readParamInfo As IDictionary(Of IReadParam.取得区分型, IReadParam), ByRef exDA As Exception) As IDictionary(Of IReadParam.取得区分型, DataTable)

    Private Function GetData(ByRef readParamInfo As IDictionary(Of IReadParam.取得区分型, IReadParam), ByRef exDA As Exception) As IDictionary(Of IReadParam.取得区分型, DataTable)
        Dim dataTable As IDictionary(Of IReadParam.取得区分型, DataTable) = New Dictionary(Of IReadParam.取得区分型, DataTable)
        dataTable = _reader.GetData(SettingInfo, readParamInfo, exDA)
        EndFlag = True
        Return dataTable
    End Function

    'A-20130404_1{
    Private _waitProcessMethod As WaitProcessMethod = Nothing
    Public Delegate Sub WaitProcessMethod(ByVal accessorBase As DataAccessorBase)

    Public Sub SetupWaitProcessMethod(ByVal waitProcessMethod As WaitProcessMethod)
        _waitProcessMethod = waitProcessMethod
    End Sub

    Private Sub CallWaitProcess(ByVal accessorBase As DataAccessorBase)
        If _waitProcessMethod Is Nothing = True Then
            Return
        End If

        _waitProcessMethod.Invoke(accessorBase)
    End Sub
    'A-20130404_1}

End Class
