﻿''' <summary>
''' グリッドのセル移動制御用
''' </summary>
''' <remarks></remarks>
Public Class GridMoveCellManager
    Implements IGridMoveCellManager

#Region "変数"
    Private _gridEntry As OSK.X1.Foundation.SimpleControl.GridEdit    'X1変換Tool-20160427
    Private _先頭列INDEX As Integer
    Private _キー属性 As IGridMoveCellManager.キー属性型
#End Region

#Region "公開メソッド"

    ''' <summary>
    ''' 初期化
    ''' </summary>
    ''' <param name="gridEntry">グリッド</param>
    ''' <param name="先頭列INDEX">先頭列INDEX(キー項目)</param>
    ''' <param name="キー属性"></param>
    ''' <remarks></remarks>
    Public Sub Initialize(ByVal gridEntry As OSK.X1.Foundation.SimpleControl.GridEdit, ByVal 先頭列INDEX As Integer, ByVal キー属性 As IGridMoveCellManager.キー属性型) Implements IGridMoveCellManager.Initialize    'X1変換Tool-20160427
        _gridEntry = gridEntry
        _先頭列INDEX = 先頭列INDEX
        _キー属性 = キー属性
    End Sub

    ''' <summary>
    ''' 移動先がフォーカス可能かを調べる、不可の場合、一番近い移動可能セルの位置情報を返す。
    ''' </summary>
    ''' <param name="args">GridCheckMethodArgs</param>
    ''' <returns>True：移動先あり、False：移動先なし</returns>
    ''' <remarks>GridCheckMethodArgsから判断</remarks>
    Public Function GetCanMoveNextCell(ByVal args As GridCheckMethodArgs) As Boolean Implements IGridMoveCellManager.GetCanMoveNextCell

        If GetCanMoveNextCell(args.GridEventArgs.FromRowIndex, args.GridEventArgs.FromColIndex, _
                              args.GridEventArgs.ToRowIndex, args.GridEventArgs.ToColIndex) = False Then
            Return False
        End If

        Return True
    End Function

    ''' <summary>
    ''' 移動先がフォーカス可能かを調べる、不可の場合、一番近い移動可能セルの位置情報を返す。
    ''' </summary>
    ''' <param name="args">ValidatingCellEventArgs</param>
    ''' <returns>True：移動先あり、False：移動先なし</returns>
    ''' <remarks>ValidatingCellEventArgsから判断</remarks>
    Public Function GetCanMoveNextCell(ByVal args As OSK.X1.Foundation.Controls.Grid.Common.ValidatingCellEventArgs) As Boolean Implements IGridMoveCellManager.GetCanMoveNextCell    'X1変換Tool-20160427

        If GetCanMoveNextCell(args.FromRowIndex, args.FromColIndex, _
                              args.ToRowIndex, args.ToColIndex) = False Then
            Return False
        End If

        Return True
    End Function

    ''' <summary>
    ''' 移動先がフォーカス可能かを調べる、不可の場合、一番近い移動可能セルの位置情報を返す。
    ''' </summary>
    ''' <param name="prvRowIndex">移動元行番号</param>
    ''' <param name="prvColIndex">移動元列番号</param>
    ''' <param name="newRowIndex">移動先行番号</param>
    ''' <param name="newColIndex">移動先列番号</param>
    ''' <returns>True：移動先あり False：移動先なし</returns>
    ''' <remarks>元・先インデックスより判断</remarks>
    Public Function GetCanMoveNextCell(ByRef prvRowIndex As Integer, ByRef prvColIndex As Integer, _
                                       ByRef newRowIndex As Integer, ByRef newColIndex As Integer) As Boolean Implements IGridMoveCellManager.GetCanMoveNextCell

        Dim direction As IGridMoveCellManager.キーセル移動方向型

        '移動先が移動可能かを調べる
        If CanMoveTargetCell(prvRowIndex, prvColIndex, newRowIndex, newColIndex) = True Then
            Return True
        End If

        '移動方向を判定
        If GetCellMoveDirection(prvRowIndex, prvColIndex, newRowIndex, newColIndex, direction) = False Then
            Return False
        End If

        Dim indexStart As Integer
        Dim indexEnd As Integer
        Dim steps As Integer

        If direction = IGridMoveCellManager.キーセル移動方向型.上 OrElse _
           direction = IGridMoveCellManager.キーセル移動方向型.下 Then
            indexStart = CInt(IIf(direction = IGridMoveCellManager.キーセル移動方向型.下, newRowIndex + 1, newRowIndex - 1))
            indexEnd = CInt(IIf(direction = IGridMoveCellManager.キーセル移動方向型.下, _gridEntry.RowCount - 1, 0))
            steps = CInt(IIf(direction = IGridMoveCellManager.キーセル移動方向型.下, 1, -1))

            For i As Integer = indexStart To indexEnd Step steps
                If CanMoveTargetCell(prvRowIndex, prvColIndex, i, newColIndex) = True Then
                    newRowIndex = i
                    newColIndex = newColIndex
                    Return True
                End If
            Next

        ElseIf direction = IGridMoveCellManager.キーセル移動方向型.右 OrElse _
               direction = IGridMoveCellManager.キーセル移動方向型.左 Then

            indexStart = CInt(IIf(direction = IGridMoveCellManager.キーセル移動方向型.右, newColIndex + 1, newColIndex - 1))
            indexEnd = CInt(IIf(direction = IGridMoveCellManager.キーセル移動方向型.右, _gridEntry.ColumnCount - 1, 0))
            steps = CInt(IIf(direction = IGridMoveCellManager.キーセル移動方向型.右, 1, -1))
            For i As Integer = indexStart To indexEnd Step steps
                If CanMoveTargetCell(prvRowIndex, prvColIndex, newRowIndex, i) = True Then
                    newColIndex = i
                    newRowIndex = newRowIndex
                    Return True
                End If
            Next
            '同一行にない場合
            If newRowIndex + steps >= 0 AndAlso _
               newRowIndex + steps <= _gridEntry.RowCount - 1 Then
                newColIndex = _先頭列INDEX
                newRowIndex = newRowIndex + steps
                Return True
            End If
        ElseIf direction = IGridMoveCellManager.キーセル移動方向型.前行最終項目 Then

            indexStart = newColIndex - 1
            indexEnd = 0
            steps = -1
            For i As Integer = indexStart To indexEnd Step steps
                If CanMoveTargetCell(prvRowIndex, prvColIndex, newRowIndex, i) = True Then
                    newColIndex = i
                    newRowIndex = newRowIndex
                    Return True
                End If
            Next
            '同一行にない場合
            If newRowIndex + steps >= 0 AndAlso _
               newRowIndex + steps <= _gridEntry.RowCount - 1 Then
                newColIndex = _先頭列INDEX
                newRowIndex = newRowIndex + steps
                Return True
            End If
        End If

        Return False
    End Function

    ''' <summary>
    ''' グリッドの次の移動先セル情報を取得(前行項目コピー用)
    ''' </summary>
    ''' <param name="prevrowIndex">行番号</param>
    ''' <param name="PrevColIndex">列番号</param>
    ''' <returns>True：移動先あり、False：移動先なし</returns>
    ''' <remarks></remarks>
    Public Function GetCanMoveNextCell(ByRef prevrowIndex As Integer, ByRef PrevColIndex As Integer) As Boolean Implements IGridMoveCellManager.GetCanMoveNextCell

        Dim newRowIndex As Integer = prevrowIndex, newColindex As Integer = PrevColIndex

        If _gridEntry.MoveDirectionOnEnterKey = OSK.X1.Foundation.Controls.Grid.Edit.MoveDirectionOnEnter.Right Then    'X1変換Tool-20160427
            newColindex += 1
        Else
            newRowIndex += 1
            If newRowIndex > _gridEntry.RowCount - 1 Then
                Return False
            End If
        End If

        If GetCanMoveNextCell(prevrowIndex, PrevColIndex, newRowIndex, newColindex) = True Then
            prevrowIndex = newRowIndex
            PrevColIndex = newColindex
        Else
            Return False
        End If

        Return True
    End Function

    ''' <summary>
    ''' グリッドからの移動方向を調べる
    ''' </summary>
    ''' <param name="args">GridCheckMethodArgs</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function MoveDirectionFromGrid(ByVal args As GridCheckMethodArgs) As Integer Implements IGridMoveCellManager.MoveDirectionFromGrid

        If args.操作種類 = GridCheckMethodArgs.操作種類型.前方向マウス操作 OrElse _
           (args.操作種類 = GridCheckMethodArgs.操作種類型.キー入力操作 AndAlso _
            args.移動元KeyDownCode = System.Windows.Forms.Keys.Enter AndAlso args.移動元KeyDownShift = True) OrElse _
           (args.操作種類 = GridCheckMethodArgs.操作種類型.キー入力操作 AndAlso _
            args.移動元KeyDownCode = System.Windows.Forms.Keys.Tab AndAlso args.移動元KeyDownShift = True) Then
            '前方向移動
            Return 0
        Else
            '後方向移動
            Return 1
        End If

    End Function

#End Region

#Region "内部メソッド"

    ''' <summary>
    ''' 移動方向の検査(上下・左右)
    ''' </summary>
    ''' <param name="prvRowIndex">移動元行番号</param>
    ''' <param name="prvColIndex">移動元列番号</param>
    ''' <param name="newRowIndex">移動先行番号</param>
    ''' <param name="newColIndex">移動先列番号</param>
    ''' <param name="direction"></param>
    ''' <returns>True：移動先あり False：移動先なし</returns>
    ''' <remarks></remarks>
    Private Function GetCellMoveDirection(ByVal prvRowIndex As Integer, ByVal prvColIndex As Integer, _
                                              ByVal newRowIndex As Integer, ByVal newColIndex As Integer, _
                                              ByRef direction As IGridMoveCellManager.キーセル移動方向型) As Boolean

        'If Math.Abs(newRowIndex - prvRowIndex) + _
        '   Math.Abs(newColIndex - prvColIndex) > 1 Then
        '    '移動誤差が1セル以上の場合、クリックなので移動しない。
        '    Return False
        'End If

        If newRowIndex = prvRowIndex Then
            '左右どちらか
            If prvColIndex = newColIndex Then
                direction = IGridMoveCellManager.キーセル移動方向型.同
                Return False
            ElseIf prvColIndex < newColIndex Then
                direction = IGridMoveCellManager.キーセル移動方向型.右
                Return True
            ElseIf prvColIndex > newColIndex Then
                direction = IGridMoveCellManager.キーセル移動方向型.左
                Return True
            End If

        ElseIf newColIndex = prvColIndex Then
            '上下どちらか
            If prvRowIndex = newRowIndex Then
                direction = IGridMoveCellManager.キーセル移動方向型.同
                Return False
            ElseIf prvRowIndex < newRowIndex Then
                direction = IGridMoveCellManager.キーセル移動方向型.下
                Return True
            ElseIf prvRowIndex > newRowIndex Then
                direction = IGridMoveCellManager.キーセル移動方向型.上
                Return True
            End If

        ElseIf newRowIndex = prvRowIndex - 1 AndAlso _
               prvColIndex = _先頭列INDEX Then

            '先頭項目からのShift+Enter,行の最終項目がReadOnlyを考慮
            Dim lastCol As Integer
            For i As Integer = _gridEntry.ColumnCount - 1 To 0 Step -1
                If _gridEntry.Columns(i).Hide = False Then

                    If Not (_gridEntry.GetDisplayCellInfo(newRowIndex, i).EditType = OSK.X1.Foundation.Controls.Grid.Common.GridEditType.Empty OrElse _
                            _gridEntry.GetDisplayCellInfo(newRowIndex, i).EditType = OSK.X1.Foundation.Controls.Grid.Common.GridEditType.Nothing) Then    'X1変換Tool-20160427
                        lastCol = i
                        Exit For
                    ElseIf Not (_gridEntry.Columns(i).EditType = OSK.X1.Foundation.Controls.Grid.Common.GridEditType.Empty OrElse _
                                _gridEntry.Columns(i).EditType = OSK.X1.Foundation.Controls.Grid.Common.GridEditType.Nothing) Then    'X1変換Tool-20160427
                        lastCol = i
                        Exit For
                    End If
                End If
            Next
            If newColIndex = lastCol Then
                direction = IGridMoveCellManager.キーセル移動方向型.前行最終項目
                Return True
            Else
                Return False
            End If
        Else
            '確実にクリックの場合
            Return False
        End If

        Return True
    End Function

    ''' <summary>
    ''' キーの未入力チェック
    ''' </summary>
    ''' <param name="rowIndex">対象行番号</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function IsKeyCodeNull(ByVal rowIndex As Integer) As Boolean

        If _gridEntry.GetData(rowIndex, _先頭列INDEX) Is DBNull.Value Then
            Return True
        End If

        If _キー属性 = IGridMoveCellManager.キー属性型.数値 Then
            If Val(_gridEntry.GetData(rowIndex, _先頭列INDEX)) = 0 Then
                Return True
            End If
        Else
            If _gridEntry.GetData(rowIndex, _先頭列INDEX).ToString.TrimEnd = "" Then
                Return True
            End If
        End If
        Return False
    End Function

    ''' <summary>
    '''　指定したセルがフォーカス可能かを調べる
    ''' </summary>
    ''' <param name="prvRowIndex">移動元行番号</param>
    ''' <param name="prvColIndex">移動元列番号</param>
    ''' <param name="newRowIndex">移動先行番号</param>
    ''' <param name="newColIndex">移動先列番号</param>
    ''' <returns>True：移動先あり False：移動先なし</returns>
    ''' <remarks></remarks>
    Private Function CanMoveTargetCell(ByVal prvRowIndex As Integer, ByVal prvColIndex As Integer, _
                                      ByRef newRowIndex As Integer, ByRef newColIndex As Integer) As Boolean
        'KEY部なら無条件でＯＫ
        If newColIndex = _先頭列INDEX Then
            Return True
        Else
            '未確定行のコード項目以外は不可(自行以外)
            If _gridEntry.GetDataRowState(newRowIndex) = DataRowState.Added AndAlso _
               Not prvRowIndex = newRowIndex AndAlso _
               IsKeyCodeNull(newRowIndex) = True Then
                newColIndex = _先頭列INDEX
                Return True
            End If
            'KEY部以外の削除行は不可
            If Not _gridEntry.GetDataRowState(newRowIndex) = DataRowState.Deleted AndAlso _
               IsEnableCell(newRowIndex, newColIndex) = True Then
                Return True
            End If
        End If
    End Function
    ''' <summary>
    ''' セルの活性チェック(ReadOnly Or EditType=Nothing)
    ''' </summary>
    ''' <param name="targetRowIndex">行番号</param>
    ''' <param name="targetColIndex">列番号</param>
    ''' <returns>True：活性 False：非活性</returns>
    ''' <remarks></remarks>
    Private Function IsEnableCell(ByVal targetRowIndex As Integer, ByVal targetColIndex As Integer) As Boolean


        '対象セルが存在するか？
        If targetRowIndex = -1 OrElse _
           targetColIndex = -1 Then
            Return False
        End If
        If targetRowIndex > _gridEntry.RowCount - 1 OrElse _
           targetColIndex > _gridEntry.ColumnCount - 1 Then
            Return False
        End If

        'Hideでチェック
        If _gridEntry.Columns(targetColIndex).Hide = True Then
            Return False
        End If

        '編集タイプでチェック
        If _gridEntry.GetDisplayCellInfo(targetRowIndex, targetColIndex).EditType = OSK.X1.Foundation.Controls.Grid.Common.GridEditType.Nothing OrElse _
           _gridEntry.GetDisplayCellInfo(targetRowIndex, targetColIndex).EditType = OSK.X1.Foundation.Controls.Grid.Common.GridEditType.Empty Then    'X1変換Tool-20160427

            If _gridEntry.Columns(targetColIndex).EditType = OSK.X1.Foundation.Controls.Grid.Common.GridEditType.Nothing OrElse _
               _gridEntry.Columns(targetColIndex).EditType = OSK.X1.Foundation.Controls.Grid.Common.GridEditType.Empty Then    'X1変換Tool-20160427
                Return False
            End If
        End If

        'ReadOnlyでチェック
        If Not (_gridEntry.GetDisplayCellInfo(targetRowIndex, targetColIndex).ReadOnly = OSK.X1.Foundation.Controls.Grid.Common.Boolean.Null) Then    'X1変換Tool-20160427
            If _gridEntry.GetDisplayCellInfo(targetRowIndex, targetColIndex).ReadOnly = OSK.X1.Foundation.Controls.Grid.Common.Boolean.True Then    'X1変換Tool-20160427
                Return False
            End If
        End If

        If Not (_gridEntry.Columns(targetColIndex).ReadOnly = OSK.X1.Foundation.Controls.Grid.Common.Boolean.Null) Then    'X1変換Tool-20160427
            If _gridEntry.Columns(targetColIndex).ReadOnly = OSK.X1.Foundation.Controls.Grid.Common.Boolean.True Then    'X1変換Tool-20160427
                Return False
            End If
        End If

        Return True
    End Function

#End Region

End Class
