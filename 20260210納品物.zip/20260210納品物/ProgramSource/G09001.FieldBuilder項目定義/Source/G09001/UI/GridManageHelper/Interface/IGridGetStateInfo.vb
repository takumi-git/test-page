﻿Public Interface IGridGetStateInfo
    Inherits IGridSubCommonHelper
#Region "公開メソッド"

    ''' <summary>
    ''' 初期化
    ''' </summary>
    ''' <param name="_gridEntry">グリッド</param>
    ''' <param name="先頭列INDEX">先頭列INDEX(KEY)</param>
    ''' <param name="キー属性">属性</param>
    ''' <remarks></remarks>
    Sub Initialize(ByVal _gridEntry As OSK.X1.Foundation.SimpleControl.GridEdit, ByVal 先頭列INDEX As Integer, ByVal キー属性 As IGridMoveCellManager.キー属性型)    'X1変換Tool-20160427

    ''' <summary>
    ''' 現在のEditセル情報を変数に抑える
    ''' </summary>
    ''' <param name="prevRowIndex">行番号</param>
    ''' <param name="prevColIndex">列番号</param>
    ''' <param name="prevColName">列名</param>
    ''' <remarks></remarks>
    Sub SaveCurrentEditIndex(ByRef prevRowIndex As Integer, ByRef prevColIndex As Integer, ByRef prevColName As String)

    ''' <summary>
    ''' 指定セルがカレントのセルかを判断
    ''' </summary>
    ''' <param name="targetRowIndex">行番号</param>
    ''' <param name="targetColIndex">列番号</param>
    ''' <returns>True：同一、False：異なる</returns>
    ''' <remarks></remarks>
    Function IsCurrentEditCell(ByVal targetRowIndex As Integer, ByVal targetColIndex As Integer) As Boolean

    ''' <summary>
    ''' 移動先が同一かを判断する。
    ''' </summary>
    ''' <param name="e">VaridatingCellのEventArgs</param>
    ''' <returns></returns>
    ''' <remarks>True：同一 False：異なる</remarks>
    Function IsMovingSameCell(ByVal e As OSK.X1.Foundation.Controls.Grid.Common.ValidatingCellEventArgs) As Boolean    'X1変換Tool-20160427

    ''' <summary>
    ''' Editセルが-1でないかを判断する。
    ''' </summary>
    ''' <returns>True:編集が対象外 False：編集対応</returns>
    ''' <remarks></remarks>
    Function IsNothingEditCell() As Boolean

    ''' <summary>
    ''' 指定したセルが編集中のセルかどうかを判断する。
    ''' </summary>
    ''' <param name="targetRowIndex">行番号</param>
    ''' <param name="targetColIndex">列番号</param>
    ''' <returns>True：編集セル False:編集セルでない</returns>
    ''' <remarks></remarks>
    Function IsEditingCell(ByVal targetRowIndex As Integer, ByVal targetColIndex As Integer) As Boolean

    ''' <summary>
    ''' グリッドがフォーカス可能な状態になるまで待つ
    ''' </summary>
    ''' <remarks></remarks>
    Sub WaitGridIsStateOK()

#End Region

#Region "Overridableメソッド"

    ''' <summary>
    ''' キーは未入力判断
    ''' </summary>
    ''' <param name="rowindex"></param>
    ''' <returns>True：未入力、False：入力済み</returns>
    ''' <remarks></remarks>
    Function IsKeyInvailed(ByVal rowindex As Integer) As Boolean

    ''' <summary>
    ''' 現在行のキー未入力を判断
    ''' </summary>
    ''' <param name="rowindex">行番号</param>
    ''' <returns>True：未入力、False：入力済み</returns>
    ''' <remarks></remarks>
    Function IsKeyInputNull(ByVal rowindex As Integer) As Boolean

    '''' <summary>
    '''' キー部のデータテーブルの値の未設定を判断
    '''' </summary>
    '''' <param name="rowindex">行番号</param>
    '''' <returns>True：未設定、False：設定済み</returns>
    '''' <remarks></remarks>
    'Function IsNullDecideKey(ByVal rowindex As Integer) As Boolean

    ''' <summary>
    ''' エディットとデータテーブル値の比較
    ''' </summary>
    ''' <param name="rowindex">行番号</param>
    ''' <returns>True：異なる、False：同一</returns>
    ''' <remarks></remarks>
    Function IsKeyChanged(ByVal rowindex As Integer) As Boolean

    ''' <summary>
    ''' チェック対象のセルか？
    ''' </summary>
    ''' <param name="targetRowIndex">行番号</param>
    ''' <param name="targetColIndex">列番号</param>
    ''' <returns>True：対象、False：非対象</returns>
    ''' <remarks></remarks>
    Function IsCheckTargetCell(ByVal targetRowIndex As Integer, ByVal targetColIndex As Integer) As Boolean

    ''' <summary>
    ''' セルの活性チェック(ReadOnly Or EditType=Nothing)
    ''' </summary>
    ''' <param name="targetRowIndex">行番号</param>
    ''' <param name="targetColIndex">列番号</param>
    ''' <returns>True：活性 False：非活性</returns>
    ''' <remarks></remarks>
    Function IsEnableCell(ByVal targetRowIndex As Integer, ByVal targetColIndex As Integer) As Boolean


    ''' <summary>
    ''' 他のコントロールへの移動かを判断する
    ''' </summary>
    ''' <param name="e">VaridatingCellのEventArgs</param>
    ''' <returns>True:異なるコントロールへ移動 Fasle:グリッド内移動</returns>
    ''' <remarks></remarks>
    Function IsMovingOtherControl(ByVal e As OSK.X1.Foundation.Controls.Grid.Common.ValidatingCellEventArgs) As Boolean    'X1変換Tool-20160427

    ''' <summary>
    ''' コード項目の未入力を判断(ＫＥＹ以外)
    ''' </summary>
    ''' <param name="rowindex">行番号</param>
    ''' <returns>True：未入力、False：入力済み</returns>
    ''' <remarks></remarks>
    Function IsCodeCellInputNull(ByVal rowindex As Integer, ByVal typeSwitch As Integer) As Boolean

    ''' <summary>
    ''' コード項目のデータテーブルの値の未設定を判断(キー以外)
    ''' </summary>
    ''' <param name="rowindex">行番号</param>
    ''' <param name="colIndex">列番号</param>
    ''' <returns>True：未設定、False：設定済み</returns>
    ''' <remarks></remarks>
    Function IsCodeCellNullDecideKey(ByVal rowindex As Integer, ByVal colIndex As Integer, ByVal typeSwitch As Integer) As Boolean

    ''' <summary>
    ''' エディットとデータテーブル値の比較
    ''' </summary>
    ''' <param name="rowindex">行番号</param>
    ''' <param name="colIndex">列番号</param>
    ''' <param name="typeSwitch">属性(0:数値、1:文字)</param>
    ''' <returns>True：異なる、False：同一</returns>
    ''' <remarks></remarks>
    Function IsCodeCellChanged(ByVal rowindex As Integer, ByVal colIndex As Integer, ByVal typeSwitch As Integer) As Boolean

#End Region

End Interface
