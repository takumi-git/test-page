﻿Public Interface IGridMoveCellManager
    Inherits IGridSubCommonHelper

#Region "公開メソッド"

    ''' <summary>
    ''' 初期化
    ''' </summary>
    ''' <param name="gridEntry">グリッド</param>
    ''' <param name="先頭列INDEX">先頭列INDEX(キー項目)</param>
    ''' <param name="キー属性"></param>
    ''' <remarks></remarks>
    Sub Initialize(ByVal gridEntry As OSK.X1.Foundation.SimpleControl.GridEdit, ByVal 先頭列INDEX As Integer, ByVal キー属性 As キー属性型)    'X1変換Tool-20160427

    ''' <summary>
    ''' 移動先がフォーカス可能かを調べる、不可の場合、一番近い移動可能セルの位置情報を返す。
    ''' </summary>
    ''' <param name="args">GridCheckMethodArgs</param>
    ''' <returns>True：移動先あり、False：移動先なし</returns>
    ''' <remarks>GridCheckMethodArgsから判断</remarks>
    Function GetCanMoveNextCell(ByVal args As GridCheckMethodArgs) As Boolean

    ''' <summary>
    ''' 移動先がフォーカス可能かを調べる、不可の場合、一番近い移動可能セルの位置情報を返す。
    ''' </summary>
    ''' <param name="args">ValidatingCellEventArgs</param>
    ''' <returns>True：移動先あり、False：移動先なし</returns>
    ''' <remarks>ValidatingCellEventArgsから判断</remarks>
    Function GetCanMoveNextCell(ByVal args As OSK.X1.Foundation.Controls.Grid.Common.ValidatingCellEventArgs) As Boolean    'X1変換Tool-20160427

    ''' <summary>
    ''' 移動先がフォーカス可能かを調べる、不可の場合、一番近い移動可能セルの位置情報を返す。
    ''' </summary>
    ''' <param name="prvRowIndex">移動元行番号</param>
    ''' <param name="prvColIndex">移動元列番号</param>
    ''' <param name="newRowIndex">移動先行番号</param>
    ''' <param name="newColIndex">移動先列番号</param>
    ''' <returns>True：移動先あり False：移動先なし</returns>
    ''' <remarks>元・先インデックスより判断</remarks>
    Function GetCanMoveNextCell(ByRef prvRowIndex As Integer, ByRef prvColIndex As Integer, _
                                       ByRef newRowIndex As Integer, ByRef newColIndex As Integer) As Boolean

    ''' <summary>
    ''' グリッドの次の移動先セル情報を取得(前行項目コピー用)
    ''' </summary>
    ''' <param name="prevrowIndex">行番号</param>
    ''' <param name="PrevColIndex">列番号</param>
    ''' <returns>True：移動先あり、False：移動先なし</returns>
    ''' <remarks></remarks>
    Function GetCanMoveNextCell(ByRef prevrowIndex As Integer, ByRef PrevColIndex As Integer) As Boolean


    ''' <summary>
    ''' グリッドからの移動方向を調べる
    ''' </summary>
    ''' <param name="args">GridCheckMethodArgs</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Function MoveDirectionFromGrid(ByVal args As GridCheckMethodArgs) As Integer


#End Region



End Interface
