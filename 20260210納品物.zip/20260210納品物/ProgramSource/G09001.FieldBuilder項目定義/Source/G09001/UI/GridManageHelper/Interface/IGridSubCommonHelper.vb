﻿Public Interface IGridSubCommonHelper

#Region "列挙型"

    Enum キー属性型
        数値 = 0
        文字
    End Enum

    Enum キーセル移動方向型 As Integer
        同 = 0
        上
        下
        右
        左
        前行最終項目
    End Enum

#End Region

End Interface
