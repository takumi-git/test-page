﻿''' <summary>
''' グリッドの状態を取得する。
''' </summary>
''' <remarks></remarks>
Public Class GridGetStateInfo
    Implements IGridGetStateInfo

#Region "プロパティ"

    Private _gridEntry As OSK.X1.Foundation.SimpleControl.GridEdit    'X1変換Tool-20160427

    Protected ReadOnly Property GridEntry() As OSK.X1.Foundation.SimpleControl.GridEdit    'X1変換Tool-20160427
        Get
            Return _gridEntry
        End Get
    End Property
    Private _先頭列INDEX As Integer

    Protected ReadOnly Property 先頭列INDEX() As Integer
        Get
            Return _先頭列INDEX
        End Get
    End Property
    Private _キー属性 As IGridGetStateInfo.キー属性型
    Protected ReadOnly Property キー属性() As IGridGetStateInfo.キー属性型
        Get
            Return _キー属性
        End Get
    End Property

#End Region

#Region "公開メソッド"

    ''' <summary>
    ''' 初期化
    ''' </summary>
    ''' <param name="gridEntry">グリッド</param>
    ''' <param name="先頭列INDEX">先頭列INDEX(KEY)</param>
    ''' <param name="キー属性">属性</param>
    ''' <remarks></remarks>
    Public Sub Initialize(ByVal gridEntry As OSK.X1.Foundation.SimpleControl.GridEdit, ByVal 先頭列INDEX As Integer, ByVal キー属性 As IGridMoveCellManager.キー属性型) Implements IGridGetStateInfo.Initialize    'X1変換Tool-20160427
        _gridEntry = gridEntry
        _先頭列INDEX = 先頭列INDEX
        _キー属性 = キー属性
    End Sub

    ''' <summary>
    ''' 現在のEditセル情報を変数に抑える
    ''' </summary>
    ''' <param name="prevRowIndex">行番号</param>
    ''' <param name="prevColIndex">列番号</param>
    ''' <param name="prevColName">列名</param>
    ''' <remarks></remarks>
    Public Sub SaveCurrentEditIndex(ByRef prevRowIndex As Integer, ByRef prevColIndex As Integer, ByRef prevColName As String) Implements IGridGetStateInfo.SaveCurrentEditIndex
        prevRowIndex = GridEntry.EditRowIndex
        prevColName = GridEntry.EditColName
        prevColIndex = GridEntry.EditColIndex
    End Sub

    ''' <summary>
    ''' 指定セルがカレントのセルかを判断
    ''' </summary>
    ''' <param name="targetRowIndex">行番号</param>
    ''' <param name="targetColIndex">列番号</param>
    ''' <returns>True：同一、False：異なる</returns>
    ''' <remarks></remarks>
    Public Function IsCurrentEditCell(ByVal targetRowIndex As Integer, ByVal targetColIndex As Integer) As Boolean Implements IGridGetStateInfo.IsCurrentEditCell
        If GridEntry.EditRowIndex = targetRowIndex AndAlso _
           GridEntry.EditColIndex = targetColIndex Then
            Return True
        End If
        Return False
    End Function

    ''' <summary>
    ''' 移動先が同一かを判断する。
    ''' </summary>
    ''' <param name="e">VaridatingCellのEventArgs</param>
    ''' <returns></returns>
    ''' <remarks>True：同一 False：異なる</remarks>
    Public Function IsMovingSameCell(ByVal e As OSK.X1.Foundation.Controls.Grid.Common.ValidatingCellEventArgs) As Boolean Implements IGridGetStateInfo.IsMovingSameCell    'X1変換Tool-20160427
        If e.FromColIndex = e.ToColIndex AndAlso _
           e.FromRowIndex = e.ToRowIndex Then
            Return True
        End If
        Return False
    End Function

    ''' <summary>
    ''' Editセルが-1でないかを判断する。
    ''' </summary>
    ''' <returns>True:編集が対象外 False：編集対応</returns>
    ''' <remarks></remarks>
    Public Overridable Function IsNothingEditCell() As Boolean Implements IGridGetStateInfo.IsNothingEditCell
        If GridEntry.EditColIndex = -1 OrElse _
           GridEntry.EditRowIndex = -1 Then
            Return True
        End If
        Return False
    End Function

    ''' <summary>
    ''' 指定したセルが編集中のセルかどうかを判断する。
    ''' </summary>
    ''' <param name="targetRowIndex">行番号</param>
    ''' <param name="targetColIndex">列番号</param>
    ''' <returns>True：編集セル False:編集セルでない</returns>
    ''' <remarks></remarks>
    Public Overridable Function IsEditingCell(ByVal targetRowIndex As Integer, ByVal targetColIndex As Integer) As Boolean Implements IGridGetStateInfo.IsEditingCell
        If GridEntry.EditRowIndex = targetRowIndex AndAlso _
           GridEntry.EditColIndex = targetColIndex Then
            Return True
        End If
        Return False
    End Function

    ''' <summary>
    ''' グリッドがフォーカス可能な状態になるまで待つ
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub WaitGridIsStateOK() Implements IGridGetStateInfo.WaitGridIsStateOK
        Do Until GridEntry.ReadOnly = False
            System.Windows.Forms.Application.DoEvents()
        Loop
        Do Until GridEntry.Enabled = True
            System.Windows.Forms.Application.DoEvents()
        Loop
        Do Until GridEntry.CanFocus = True
            System.Windows.Forms.Application.DoEvents()
        Loop

    End Sub

#End Region

#Region "Overridableメソッド"

    ''' <summary>
    ''' キーは未入力判断
    ''' </summary>
    ''' <param name="rowindex"></param>
    ''' <returns>True：未入力、False：入力済み</returns>
    ''' <remarks></remarks>
    Public Overridable Function IsKeyInvailed(ByVal rowindex As Integer) As Boolean Implements IGridGetStateInfo.IsKeyInvailed

        If IsKeyInputNull(rowindex) = True Then
            Return True
        End If

        If IsKeyChanged(rowindex) = True Then
            Return True
        End If
        Return False

    End Function

    ''' <summary>
    ''' 現在行のキー未入力を判断
    ''' </summary>
    ''' <param name="rowindex">行番号</param>
    ''' <returns>True：未入力、False：入力済み</returns>
    ''' <remarks></remarks>
    Public Overridable Function IsKeyInputNull(ByVal rowindex As Integer) As Boolean Implements IGridGetStateInfo.IsKeyInputNull
        '現在行以外はなにもしない
        If GridEntry.EditRowIndex <> rowindex Then Return False

        If キー属性 = IGridSubCommonHelper.キー属性型.数値 Then
            If Val(GridEntry.CurrentEditValue.ToString) = 0 Then
                Return True
            End If
        Else
            If GridEntry.CurrentEditValue.ToString.TrimEnd = "" Then
                Return True
            End If
        End If
        Return False
    End Function

    ''' <summary>
    ''' エディットとデータテーブル値の比較
    ''' </summary>
    ''' <param name="rowindex">行番号</param>
    ''' <returns>True：異なる、False：同一</returns>
    ''' <remarks></remarks>
    Public Overridable Function IsKeyChanged(ByVal rowindex As Integer) As Boolean Implements IGridGetStateInfo.IsKeyChanged
        If GridEntry.GetData(GridEntry.EditRowIndex, 先頭列INDEX).Equals(GridEntry.CurrentEditValue.ToString) = False Then
            Return True
        End If
        Return False
    End Function

    ''' <summary>
    ''' チェック対象のセルか？
    ''' </summary>
    ''' <param name="targetRowIndex">行番号</param>
    ''' <param name="targetColIndex">列番号</param>
    ''' <returns>True：対象、False：非対象</returns>
    ''' <remarks></remarks>
    Public Overridable Function IsCheckTargetCell(ByVal targetRowIndex As Integer, ByVal targetColIndex As Integer) As Boolean Implements IGridGetStateInfo.IsCheckTargetCell
        '対象セルかのチェック
        If IsEnableCell(targetRowIndex, targetColIndex) = False Then
            Return False
        End If
        Return True
    End Function

    ''' <summary>
    ''' セルの活性チェック(ReadOnly Or EditType=Nothing)
    ''' </summary>
    ''' <param name="targetRowIndex">行番号</param>
    ''' <param name="targetColIndex">列番号</param>
    ''' <returns>True：活性 False：非活性</returns>
    ''' <remarks></remarks>
    Public Overridable Function IsEnableCell(ByVal targetRowIndex As Integer, ByVal targetColIndex As Integer) As Boolean Implements IGridGetStateInfo.IsEnableCell
        '対象セルが存在するか？
        If targetRowIndex = -1 OrElse _
           targetColIndex = -1 Then
            Return False
        End If
        If targetRowIndex > GridEntry.RowCount - 1 OrElse _
           targetColIndex > GridEntry.ColumnCount - 1 Then
            Return False
        End If
        'Hideでチェック
        If GridEntry.Columns(targetColIndex).Hide = True Then
            Return False
        End If
        '編集タイプでチェック
        If GridEntry.GetDisplayCellInfo(targetRowIndex, targetColIndex).EditType = OSK.X1.Foundation.Controls.Grid.Common.GridEditType.Nothing OrElse _
           GridEntry.GetDisplayCellInfo(targetRowIndex, targetColIndex).EditType = OSK.X1.Foundation.Controls.Grid.Common.GridEditType.Empty Then    'X1変換Tool-20160427

            If GridEntry.Columns(targetColIndex).EditType = OSK.X1.Foundation.Controls.Grid.Common.GridEditType.Nothing OrElse _
               GridEntry.Columns(targetColIndex).EditType = OSK.X1.Foundation.Controls.Grid.Common.GridEditType.Empty Then    'X1変換Tool-20160427
                Return False
            End If
        End If
        'ReadOnlyでチェック
        If Not (GridEntry.GetDisplayCellInfo(targetRowIndex, targetColIndex).ReadOnly = OSK.X1.Foundation.Controls.Grid.Common.Boolean.Null) Then    'X1変換Tool-20160427
            If GridEntry.GetDisplayCellInfo(targetRowIndex, targetColIndex).ReadOnly = OSK.X1.Foundation.Controls.Grid.Common.Boolean.True Then    'X1変換Tool-20160427
                Return False
            End If
        End If

        If Not (GridEntry.Columns(targetColIndex).ReadOnly = OSK.X1.Foundation.Controls.Grid.Common.Boolean.Null) Then    'X1変換Tool-20160427
            If GridEntry.Columns(targetColIndex).ReadOnly = OSK.X1.Foundation.Controls.Grid.Common.Boolean.True Then    'X1変換Tool-20160427
                Return False
            End If
        End If

        Return True
    End Function

    ''' <summary>
    ''' 他のコントロールへの移動かを判断する
    ''' </summary>
    ''' <param name="e">VaridatingCellのEventArgs</param>
    ''' <returns>True:異なるコントロールへ移動 Fasle:グリッド内移動</returns>
    ''' <remarks></remarks>
    Public Overridable Function IsMovingOtherControl(ByVal e As OSK.X1.Foundation.Controls.Grid.Common.ValidatingCellEventArgs) As Boolean Implements IGridGetStateInfo.IsMovingOtherControl    'X1変換Tool-20160427
        If e.ToColIndex = -1 OrElse _
           e.ToRowIndex = -1 Then
            Return True
        End If
        Return False
    End Function

    ''' <summary>
    ''' コード項目の未入力を判断(ＫＥＹ以外)
    ''' </summary>
    ''' <param name="rowindex">行番号</param>
    ''' <returns>True：未入力、False：入力済み</returns>
    ''' <remarks></remarks>
    Public Overridable Function IsCodeCellInputNull(ByVal rowindex As Integer, ByVal typeSwitch As Integer) As Boolean Implements IGridGetStateInfo.IsCodeCellInputNull
        '現在行以外はなにもしない
        If GridEntry.EditRowIndex <> rowindex Then Return False

        If typeSwitch = IGridSubCommonHelper.キー属性型.数値 Then
            If Val(GridEntry.CurrentEditValue.ToString) = 0 Then
                Return True
            End If
        Else
            If GridEntry.CurrentEditValue.ToString.TrimEnd = "" Then
                Return True
            End If
        End If
        Return False
    End Function

    ''' <summary>
    ''' コード項目のデータテーブルの値の未設定を判断(キー以外)
    ''' </summary>
    ''' <param name="rowindex">行番号</param>
    ''' <param name="colIndex">列番号</param>
    ''' <returns>True：未設定、False：設定済み</returns>
    ''' <remarks></remarks>
    Public Overridable Function IsCodeCellNullDecideKey(ByVal rowindex As Integer, ByVal colIndex As Integer, ByVal typeSwitch As Integer) As Boolean Implements IGridGetStateInfo.IsCodeCellNullDecideKey

        If GridEntry.GetData(rowindex, colIndex) Is DBNull.Value Then
            Return True
        End If

        If typeSwitch = IGridSubCommonHelper.キー属性型.数値 Then
            If Val(GridEntry.GetData(rowindex, colIndex).ToString) = 0 Then
                Return True
            End If
        Else
            If GridEntry.GetData(rowindex, colIndex).ToString.TrimEnd = "" Then
                Return True
            End If
        End If

        Return False
    End Function

    ''' <summary>
    ''' エディットとデータテーブル値の比較
    ''' </summary>
    ''' <param name="rowindex">行番号</param>
    ''' <param name="colIndex">列番号</param>
    ''' <param name="typeSwitch">属性(0:数値、1:文字)</param>
    ''' <returns>True：異なる、False：同一</returns>
    ''' <remarks></remarks>
    Public Overridable Function IsCodeCellChanged(ByVal rowindex As Integer, ByVal colIndex As Integer, ByVal typeSwitch As Integer) As Boolean Implements IGridGetStateInfo.IsCodeCellChanged

        If GridEntry.GetData(GridEntry.EditRowIndex, colIndex).Equals(GridEntry.CurrentEditValue.ToString) = False Then
            Return True
        End If
        Return False
    End Function

#End Region

End Class
