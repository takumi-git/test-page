﻿''' <summary>
''' インターフェース
''' </summary>
''' <remarks>※20101014_1で追加※</remarks>
Public Interface IRendoHelper
    Inherits IBase

#Region "メソッド"
    ''' <summary>
    ''' 初期処理
    ''' </summary>
    ''' <param name="initInfo">初期処理取得情報</param>
    ''' <remarks></remarks>
    Sub SetInitInfo(ByVal initInfo As System.Collections.IDictionary)
#End Region

#Region "プロパティ"

    ''' <summary>
    ''' 伝票承認機能使用する
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    ReadOnly Property 伝票承認機能使用する() As Boolean

    '↓A-20220408-X1.A-入力データ取込機能
    ''' <summary>
    ''' 自動入力データ取込機能使用する
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    ReadOnly Property 自動入力データ取込機能使用する() As Boolean

    ''' <summary>
    ''' 仕訳データ自動入力機能使用する
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    ReadOnly Property 仕訳データ自動入力機能使用する() As Boolean

    '↑A-20220408-X1.A-入力データ取込機能

#End Region

End Interface
