﻿''' <summary>
''' 詳細条件画面
''' </summary>
''' <remarks></remarks>
Public Class WarningDeleteView

#Region "コンストラクタ"
    Sub New()
        ' この呼び出しは、Windows フォーム デザイナで必要です。
        InitializeComponent()

    End Sub

#End Region

#Region "プロパティ"

    Private _強制実行 As Integer
    Public ReadOnly Property 強制実行() As Integer
        Get
            Return _強制実行
        End Get
    End Property

#End Region

    Public Sub InitialiseWarningDeleteOtherView(ByVal creater As OSK.X1.Foundation.Batch.UserInterface.CommandViewBase)    'X1変換Tool-20160427
        Initialize(creater)
    End Sub

    Private Sub OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ok.Click
        _強制実行 = 1
        Me.Close()
    End Sub

    Private Sub Cancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cancel.Click
        _強制実行 = 0
        Me.Close()
    End Sub

    Private Sub WarningDeleteView_Shown(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Shown
        cancel.Focus()
    End Sub
End Class
