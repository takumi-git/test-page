﻿''' <summary>
''' 個別設定コントローラー
''' </summary>
''' <remarks></remarks>
<CLSCompliant(True)> _
Public Class SystemController
    Inherits InsideJobBase
    Implements ISystemController

#Region "初期値を退避"
    Private _初期値Enterキー移動方向 As ISystemController.Enterキー移動方向型
    Private _初期値左右矢印キー As ISystemController.左右矢印型
#End Region

#Region "コンストラクタ"

    Sub New()
        _Enterキー移動方向 = G09001.UI.ISystemController.Enterキー移動方向型.右
        _ESCキー動作 = G09001.UI.ISystemController.ESCキー動作型.終了
        _左右矢印キー = G09001.UI.ISystemController.左右矢印型.項目間

        'デフォルト値をセット
        _初期値Enterキー移動方向 = G09001.UI.ISystemController.Enterキー移動方向型.右
        _初期値左右矢印キー = G09001.UI.ISystemController.左右矢印型.項目間

    End Sub

#End Region

#Region "プロパティ"
    Private _Enterキー移動方向 As ISystemController.Enterキー移動方向型
    ''' <summary>
    '''  Enterキー移動方向
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property Enterキー移動方向() As ISystemController.Enterキー移動方向型 Implements ISystemController.Enterキー移動方向
        Get
            Return _Enterキー移動方向
        End Get
        Set(ByVal value As ISystemController.Enterキー移動方向型)
            _Enterキー移動方向 = value
        End Set
    End Property

    Private _ESCキー動作 As ISystemController.ESCキー動作型
    ''' <summary>
    ''' ESCキー動作 
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property ESCキー動作() As ISystemController.ESCキー動作型 Implements ISystemController.ESCキー動作
        Get
            Return _ESCキー動作
        End Get
        Set(ByVal value As ISystemController.ESCキー動作型)
            _ESCキー動作 = value
        End Set
    End Property

    Private _左右矢印キー As ISystemController.左右矢印型
    ''' <summary>
    ''' 左右矢印キー
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property 左右矢印キー() As ISystemController.左右矢印型 Implements ISystemController.左右矢印キー
        Get
            Return _左右矢印キー
        End Get
        Set(ByVal value As ISystemController.左右矢印型)
            _左右矢印キー = value
        End Set
    End Property

#End Region

#Region "メソッド"

    ''' <summary>
    ''' SaveInfoをセットする。
    ''' </summary>
    ''' <param name="saveInfo">更新情報</param>
    ''' <remarks></remarks>
    Public Sub GetSaveInfo(ByRef saveInfo As System.Collections.IDictionary) Implements ISystemController.GetSaveInfo
        Dim プログラム制御情報 As SaveInfo
        プログラム制御情報 = New SaveInfo(saveInfo)

        Dim 個別終了処理モード As 個別終了処理モード型 = 個別終了処理モード型.無し

        プログラム制御情報.終了処理情報.個別終了処理 = 個別終了処理モード型.有り

        If Not _初期値左右矢印キー = 左右矢印キー Then
            saveInfo.Add("左右矢印", CInt(左右矢印キー))
            個別終了処理モード = 個別終了処理モード型.有り
        End If

        If Not _初期値Enterキー移動方向 = _Enterキー移動方向 Then
            saveInfo.Add("Enterキー移動方向", CInt(Enterキー移動方向))
            個別終了処理モード = 個別終了処理モード型.有り
        End If

        プログラム制御情報.終了処理情報.個別終了処理 = 個別終了処理モード

    End Sub

    ''' <summary>
    ''' 個別設定情報を設定する
    ''' </summary>
    ''' <remarks></remarks>
    Public Overloads Sub SetUpSystemController() Implements ISystemController.SetUpSystemController

        ESCキー動作 = GetInintInfo("操作.ESCキー動作", ISystemController.ESCキー動作型.終了しない)
        左右矢印キー = GetInintInfo("マスター保守.左右矢印", ISystemController.左右矢印型.項目間)
        Enterキー移動方向 = GetInintInfo("マスター保守.Enterキー移動方向", ISystemController.Enterキー移動方向型.右)

        'デフォルト値を退避
        _初期値Enterキー移動方向 = GetInintInfo("マスター保守.Enterキー移動方向", ISystemController.Enterキー移動方向型.右)
        _初期値左右矢印キー = GetInintInfo("マスター保守.左右矢印", ISystemController.左右矢印型.項目間)

    End Sub

    Private Function GetInintInfo(Of T)(ByVal key As String, ByVal defaultValue As T) As T
        If InitInfo.Contains(key) = True Then
            Return CType(InitInfo.Item(key), T)
        Else
            Return defaultValue
        End If

    End Function

#End Region

End Class
