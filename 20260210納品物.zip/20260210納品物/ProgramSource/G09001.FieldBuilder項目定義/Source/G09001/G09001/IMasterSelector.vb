﻿<CLSCompliant(True)> _
Public Interface IMasterSelector
    Inherits IBase

#Region "列挙型"
    Enum マスター区分型 As Integer
        参照定義 = 0
        画面設定
        データ種類
    End Enum
#End Region

#Region "メソッド"
    Function GetName(ByVal settingInfo As IDictionary, ByRef getDataValue() As String, ByVal targetMaster As マスター区分型, _
                     ByVal ParamArray コード As String()) As Boolean

    Function GetSetteiList(ByVal settingInfo As IDictionary, ByRef getDataValue As DataTable, ByVal targetMaster As マスター区分型, _
                           ByVal ParamArray コード As String()) As Boolean

    Function GetDatatype(ByVal settingInfo As IDictionary, ByRef detDataType As DataTable, ByVal targetMaster As マスター区分型) As Boolean
#End Region

End Interface
