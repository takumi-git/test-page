﻿'''' <summary>
'''' 読込パラメータ
'''' </summary>
'''' <remarks></remarks>
'<Serializable()> _
'Public Class ReadParam

'    Private _項目IDStart As String
'    Public Property 項目IDStart() As String
'        Get
'            Return _項目IDStart
'        End Get
'        Set(ByVal value As String)
'            _項目IDStart = value
'        End Set
'    End Property

'    Private _項目IDEnd As String
'    Public Property 項目IDEnd() As String
'        Get
'            Return _項目IDEnd
'        End Get
'        Set(ByVal value As String)
'            _項目IDEnd = value
'        End Set
'    End Property

'    Private _項目ID範囲 As RangeAllType
'    Public Property 項目ID範囲() As RangeAllType
'        Get
'            Return _項目ID範囲
'        End Get
'        Set(ByVal value As RangeAllType)
'            _項目ID範囲 = value
'        End Set
'    End Property

'End Class
