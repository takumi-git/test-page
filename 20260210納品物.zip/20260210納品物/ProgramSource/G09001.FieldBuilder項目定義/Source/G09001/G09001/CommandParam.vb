﻿''' <summary>
''' キー項目クラス
''' </summary>
''' <remarks></remarks>
<Serializable()> _
Public Class CommandParam
    Implements ICommandParam

#Region "列挙型"

    Public Enum チェック状態型 As Integer
        なし = 0
        あり
    End Enum

#End Region

#Region "プロパティ"

    Private _処理モード As Integer
    ''' <summary>
    ''' データ種別を返す
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property 処理モード() As Integer
        Get
            Return _処理モード
        End Get
        Set(ByVal value As Integer)
            _処理モード = value
        End Set
    End Property

    Private _データ種別 As Integer
    ''' <summary>
    ''' データ種別を返す
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property データ種別() As Integer
        Get
            Return _データ種別
        End Get
        Set(ByVal value As Integer)
            _データ種別 = value
        End Set
    End Property

    Private _データ種別名 As String
    ''' <summary>
    ''' データ種別を返す
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property データ種別名() As String
        Get
            Return _データ種別名
        End Get
        Set(ByVal value As String)
            _データ種別名 = value
        End Set
    End Property

    Private _データ種類 As Integer
    ''' <summary>
    ''' データ種類を返す
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property データ種類() As Integer
        Get
            Return _データ種類
        End Get
        Set(ByVal value As Integer)
            _データ種類 = value
        End Set
    End Property

    Private _データ種類名 As String
    ''' <summary>
    ''' データ種類を返す
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property データ種類名() As String
        Get
            Return _データ種類名
        End Get
        Set(ByVal value As String)
            _データ種類名 = value
        End Set
    End Property

    Private _明細区分 As Integer
    ''' <summary>
    ''' 明細区分区分を返す
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property 明細区分() As Integer
        Get
            Return _明細区分
        End Get
        Set(ByVal value As Integer)
            _明細区分 = value
        End Set
    End Property

    Private _共有区分 As Integer
    ''' <summary>
    ''' データ種別を返す
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property 共有区分() As Integer
        Get
            Return _共有区分
        End Get
        Set(ByVal value As Integer)
            _共有区分 = value
        End Set
    End Property

    Private _定義処理更新回数 As Integer
    ''' <summary>
    ''' 定義処理更新回数を返す
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property 定義処理更新回数() As Integer
        Get
            Return _定義処理更新回数
        End Get
        Set(ByVal value As Integer)
            _定義処理更新回数 = value
        End Set
    End Property

    Private _更新再実行フラグ As Boolean
    ''' <summary>
    ''' 強制実行での再更新処理判断用
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property 更新再実行フラグ() As Boolean
        Get
            Return _更新再実行フラグ
        End Get
        Set(ByVal value As Boolean)
            _更新再実行フラグ = value
        End Set
    End Property

    Private _実行ID枝番 As Integer
    ''' <summary>
    ''' 再更新処理時に使用する前回の実行ID枝番
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property 実行ID枝番() As Integer
        Get
            Return _実行ID枝番
        End Get
        Set(ByVal value As Integer)
            _実行ID枝番 = value
        End Set
    End Property

    ''' <summary>
    ''' データ区分略称を返す
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property データ種類略称() As String
        Get
            Return _データ種類略称
        End Get
        Set(ByVal value As String)
            _データ種類略称 = value
        End Set
    End Property
    Private _データ種類略称 As String
#End Region

#Region "各管理の使用区分"
    Private _強化区分 As Decimal                                        'A-20080709_2 & A-20080709_3 & A-20080709_4
    ''' <summary>
    ''' 強化区分
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property 強化区分() As Decimal                               'A-20080709_2 & A-20080709_3 & A-20080709_4 
        Get
            Return _強化区分
        End Get
        Set(ByVal value As Decimal)
            _強化区分 = value
        End Set
    End Property

    Private _定期取引作成 As Integer                                    'A-20080709_4
    ''' <summary>
    ''' 定期取引作成機能を返す(0:行わない 1:行う)
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property 定期取引作成() As Integer                           'A-20080709_4
        Get
            Return _定期取引作成
        End Get
        Set(ByVal value As Integer)
            _定期取引作成 = value
        End Set
    End Property

    Private _売上受発注区分 As Integer
    ''' <summary>
    ''' 受発注管理を返す(0:受発注管理なし 1:売上かつ受注 2:仕入かつ発注)
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property 売上受発注区分() As Integer
        Get
            Return _売上受発注区分
        End Get
        Set(ByVal value As Integer)
            _売上受発注区分 = value
        End Set
    End Property

    'A-20101213_2{
    Private _入出荷区分 As Integer
    ''' <summary>
    ''' 検収基準を返す(0:検収基準なし 1:売上かつ出荷 2:仕入かつ入荷)
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property 入出荷区分() As Integer
        Get
            Return _入出荷区分
        End Get
        Set(ByVal value As Integer)
            _入出荷区分 = value
        End Set
    End Property
    'A-20101213_2}

    Private _売上見積区分 As Integer
    ''' <summary>
    ''' 見積管理を返す(0:見積管理なし　1:見積管理あり)
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property 売上見積区分() As Integer
        Get
            Return _売上見積区分
        End Get
        Set(ByVal value As Integer)
            _売上見積区分 = value
        End Set
    End Property

    Private _仕入経費区分 As Integer                                    'A-20080709_2
    ''' <summary>
    ''' 原価管理を返す(0:原価管理なし　1:原価管理あり)
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property 仕入経費区分() As Integer                           'A-20080709_2
        Get
            Return _仕入経費区分
        End Get
        Set(ByVal value As Integer)
            _仕入経費区分 = value
        End Set
    End Property

    Private _実行状態フラグ As Integer
    ''' <summary>
    ''' 実行状態を返す(0:通常実行　1:整合処理なしで強制実行)
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property 実行状態フラグ() As Integer
        Get
            Return _実行状態フラグ
        End Get
        Set(ByVal value As Integer)
            _実行状態フラグ = value
        End Set
    End Property

    Private _属性変更フラグ As Integer
    ''' <summary>
    ''' 属性が変更されたかを返す(0:変更なし　1:変更あり)
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property 属性変更フラグ() As Integer
        Get
            Return _属性変更フラグ
        End Get
        Set(ByVal value As Integer)
            _属性変更フラグ = value
        End Set
    End Property

    Private _付箋売上使用区分 As Integer
    ''' <summary>
    ''' 付箋売上使用区分を返す
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property 付箋売上使用区分() As Integer
        Get
            Return _付箋売上使用区分
        End Get
        Set(ByVal value As Integer)
            _付箋売上使用区分 = value
        End Set
    End Property

    'A-20101213_2{
    Private _付箋入出荷使用区分 As Integer
    ''' <summary>
    ''' 付箋入出荷使用区分を返す
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property 付箋入出荷使用区分() As Integer
        Get
            Return _付箋入出荷使用区分
        End Get
        Set(ByVal value As Integer)
            _付箋入出荷使用区分 = value
        End Set
    End Property
    'A-20101213_2}

    Private _付箋受注使用区分 As Integer
    ''' <summary>
    ''' 付箋受注使用区分を返す
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property 付箋受注使用区分() As Integer
        Get
            Return _付箋受注使用区分
        End Get
        Set(ByVal value As Integer)
            _付箋受注使用区分 = value
        End Set
    End Property

    Private _付箋見積使用区分 As Integer
    ''' <summary>
    ''' 付箋見積使用区分を返す
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property 付箋見積使用区分() As Integer
        Get
            Return _付箋見積使用区分
        End Get
        Set(ByVal value As Integer)
            _付箋見積使用区分 = value
        End Set
    End Property

    Private _付箋経費使用区分 As Integer                                'A-20080709_2
    ''' <summary>
    ''' 付箋経費使用区分を返す
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property 付箋経費使用区分() As Integer                       'A-20080709_2
        Get
            Return _付箋経費使用区分
        End Get
        Set(ByVal value As Integer)
            _付箋経費使用区分 = value
        End Set
    End Property

    Private _消費税明細使用区分 As Integer
    ''' <summary>
    ''' 消費税明細使用区分を返す
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property 消費税明細使用区分() As Integer
        Get
            Return _消費税明細使用区分
        End Get
        Set(ByVal value As Integer)
            _消費税明細使用区分 = value
        End Set
    End Property

    Private _整合処理チェック区分_売上_仕入 As Integer
    ''' <summary>
    ''' 整合処理チェック区分(売上/仕入)を返す
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property 整合処理チェック区分_売上_仕入() As Integer
        Get
            Return _整合処理チェック区分_売上_仕入
        End Get
        Set(ByVal value As Integer)
            _整合処理チェック区分_売上_仕入 = value
        End Set
    End Property

    'A-20101213_2{
    Private _整合処理チェック区分_出荷_入荷 As Integer
    ''' <summary>
    ''' 整合処理チェック区分(出荷/入荷)を返す
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property 整合処理チェック区分_出荷_入荷() As Integer
        Get
            Return _整合処理チェック区分_出荷_入荷
        End Get
        Set(ByVal value As Integer)
            _整合処理チェック区分_出荷_入荷 = value
        End Set
    End Property
    'A-20101213_2}

    Private _整合処理チェック区分_受注_発注 As Integer
    ''' <summary>
    ''' 整合処理チェック区分(受注/発注)を返す
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property 整合処理チェック区分_受注_発注() As Integer
        Get
            Return _整合処理チェック区分_受注_発注
        End Get
        Set(ByVal value As Integer)
            _整合処理チェック区分_受注_発注 = value
        End Set
    End Property

    Private _整合処理チェック区分_見積 As Integer
    ''' <summary>
    ''' 整合処理チェック区分(見積)を返す
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property 整合処理チェック区分_見積() As Integer
        Get
            Return _整合処理チェック区分_見積
        End Get
        Set(ByVal value As Integer)
            _整合処理チェック区分_見積 = value
        End Set
    End Property

    Private _整合処理チェック区分_経費 As Integer                       'A-20080709_2
    ''' <summary>
    ''' 整合処理チェック区分(経費)を返す
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property 整合処理チェック区分_経費() As Integer              'A-20080709_2
        Get
            Return _整合処理チェック区分_経費
        End Get
        Set(ByVal value As Integer)
            _整合処理チェック区分_経費 = value
        End Set
    End Property

    'A-20110408_1{
    Private _メニューバー整合処理より実行 As Boolean
    ''' <summary>
    ''' 整合処理の呼出元を返す
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property メニューバー整合処理より実行() As Boolean
        Get
            Return _メニューバー整合処理より実行
        End Get
        Set(ByVal value As Boolean)
            _メニューバー整合処理より実行 = value
        End Set
    End Property
    'A-20110408_1}

    'A-20151116_1{
    Private _Is受発注消費税あり As Boolean
    ''' <summary>
    ''' 受発注消費税ありかを返す
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property Is受発注消費税あり() As Boolean
        Get
            Return _Is受発注消費税あり
        End Get
        Set(ByVal value As Boolean)
            _Is受発注消費税あり = value
        End Set
    End Property
    'A-20151116_1}

    'A-20101014_1{
#Region "伝票申請承認機能"

    Private _伝票申請承認機能_整合性チェック As 整合性チェック型
    Public Property 伝票申請承認機能_整合性チェック() As 整合性チェック型
        Get
            Return _伝票申請承認機能_整合性チェック
        End Get
        Set(ByVal value As 整合性チェック型)
            _伝票申請承認機能_整合性チェック = value
        End Set
    End Property

#End Region
    'A-20101014_1}

    'A-20101213_1{
#Region "販売 伝票申請承認機能"
    Private _販売_伝票申請承認機能_見積整合性チェック As 整合性チェック型
    Public Property 販売_伝票申請承認機能_見積整合性チェック() As 整合性チェック型
        Get
            Return _販売_伝票申請承認機能_見積整合性チェック
        End Get
        Set(ByVal value As 整合性チェック型)
            _販売_伝票申請承認機能_見積整合性チェック = value
        End Set
    End Property

    Private _販売_伝票申請承認機能_受発注整合性チェック As 整合性チェック型
    Public Property 販売_伝票申請承認機能_受発注整合性チェック() As 整合性チェック型
        Get
            Return _販売_伝票申請承認機能_受発注整合性チェック
        End Get
        Set(ByVal value As 整合性チェック型)
            _販売_伝票申請承認機能_受発注整合性チェック = value
        End Set
    End Property
#End Region
    'A-20101213_1}

    '↓A-20180919-X1-マスター申請承認機能
#Region "マスター申請承認機能対応"
    Public Property Is得意先マスター申請承認機能あり() As Boolean
    Public Property Is仕入先マスター申請承認機能あり() As Boolean
    Public Property Is商品マスター申請承認機能あり() As Boolean
    Public Property Is原価集計マスター申請承認機能あり() As Boolean
#End Region
    '↑A-20180919-X1-マスター申請承認機能

    '↓A-20191213-X1-スマートサーチ機能
#Region "スマートサーチ機能対応"
    Public Property Isスマートサーチ機能あり() As Boolean
    Public Property Is検収＿着荷基準仕入あり() As Boolean
    Public Property Is検収＿着荷基準売上あり() As Boolean
    Public Property Is予定在庫区分_入出庫() As Boolean
#End Region
    '↑A-20191213-X1-スマートサーチ機能

    '↓A-20220408-X1.A-入力データ取込機能
#Region "入力データ取込機能対応"
    Public Property Is入力データ取込機能あり() As Boolean
    Public Property Is入力データ取込機能_会計あり() As Boolean
#End Region
    '↑A-20220408-X1.A-入力データ取込機能

    '↓A-20220926-X1-仕入データ自動入力
#Region "仕入データ自動入力対応"
    Public Property Is仕入データ自動入力機能あり() As Boolean
#End Region
    '↑A-20220926-X1-仕入データ自動入力

#End Region

#Region "列挙型"

    Private _項目属性LIST As List(Of 項目属性)
    ''' <summary>
    ''' データ種別を返す
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property 項目属性LIST() As List(Of 項目属性)
        Get
            Return _項目属性LIST
        End Get
        Set(ByVal value As List(Of 項目属性))
            _項目属性LIST = value
        End Set
    End Property

    Private _項目付箋LIST As List(Of 項目付箋)
    ''' <summary>
    ''' データ種別を返す
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property 項目付箋LIST() As List(Of 項目付箋)
        Get
            Return _項目付箋LIST
        End Get
        Set(ByVal value As List(Of 項目付箋))
            _項目付箋LIST = value
        End Set
    End Property

    <Serializable()> _
    Public Structure 項目付箋
        Dim 色１ As Integer
        Dim 色２ As Integer
        Dim 色３ As Integer
        Dim 色４ As Integer
        Dim 色５ As Integer
        Dim 色６ As Integer
        Dim 色７ As Integer
        Dim 色８ As Integer
        Dim 色９ As Integer
        Dim 文字列１ As String
        Dim 文字列２ As String
        Dim 文字列３ As String
        Dim 文字列４ As String
        Dim 文字列５ As String
        Dim 文字列６ As String
        Dim 文字列７ As String
        Dim 文字列８ As String
        Dim 文字列９ As String
    End Structure

    <Serializable()> _
    Public Structure 項目属性
        Dim 属性 As Integer
        Dim 属性２ As Integer                                           'A-20080709_3
        Dim 参照定義コード As String
        Dim 整数部桁数 As Integer
        Dim 小数部桁数 As Integer
        Dim カンマ編集 As Integer
        Dim 項目名 As String
        Dim 項目使用区分売上 As Integer
        Dim 項目使用区分入出荷 As Integer                               'A-20101213_2
        Dim 項目使用区分受注 As Integer
        Dim 項目使用区分見積 As Integer
        Dim 項目使用区分経費 As Integer                                 'A-20080709_2
        Dim コード属性 As Integer
        Dim 参照定義更新番号 As Integer
        Dim 項目更新番号 As Integer
    End Structure
    'A-20101014_1{
    Enum 整合性チェック型 As Integer
        行わない = 0
        行う
    End Enum
    'A-20101014_1}
#End Region

End Class

