﻿''' <summary>
''' 処理区分を管理する
''' </summary>
''' <remarks></remarks>
<Serializable()> _
Public Class ShoriMode
    Implements IShoriMode

#Region "インターフェイス IShoriMode"

    Private _shoriMode As IShoriMode.処理モード区分
    ''' <summary>
    ''' 処理区分を渡す
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetShoriMode() As IShoriMode.処理モード区分 Implements IShoriMode.GetShoriMode
        Return _shoriMode
    End Function

    ''' <summary>
    ''' 処理区分を設定する
    ''' </summary>
    ''' <param name="mode">処理区分</param>
    ''' <remarks></remarks>
    Public Sub SetShoriMode(ByVal mode As IShoriMode.処理モード区分) Implements IShoriMode.SetShoriMode
        _shoriMode = mode
    End Sub

#End Region

End Class
