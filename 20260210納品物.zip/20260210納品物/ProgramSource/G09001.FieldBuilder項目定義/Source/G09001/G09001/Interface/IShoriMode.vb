﻿''' <summary>
''' 処理区分用
''' </summary>
''' <remarks></remarks>
<CLSCompliant(True)> _
Public Interface IShoriMode

#Region "列挙"

    ''' <summary>
    ''' 処理区分一覧
    ''' </summary>
    ''' <remarks></remarks>
    Enum 処理モード区分
        登録 = 0
        修正
        削除
        登録＿修正    'X1変換Tool-20160427
    End Enum

#End Region


#Region "メソッド"

    ''' <summary>
    ''' 処理区分を渡す
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Function GetShoriMode() As 処理モード区分

    ''' <summary>
    ''' 処理区分を設定する
    ''' </summary>
    ''' <param name="mode">処理区分</param>
    ''' <remarks></remarks>
    Sub SetShoriMode(ByVal mode As 処理モード区分)

#End Region

End Interface
