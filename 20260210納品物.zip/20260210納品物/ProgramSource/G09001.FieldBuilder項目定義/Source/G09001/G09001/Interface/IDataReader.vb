﻿''' <summary>
''' 読込用インターフェイス 
''' </summary>
''' <remarks></remarks>
<CLSCompliant(True)> _
Public Interface IDataReader
    Inherits IBase

    ''' <summary>
    ''' データを取得する
    ''' </summary>
    ''' <param name="settingInfo">システム共通設定情報</param>
    ''' <param name="readParamInfo">読込パラメータ</param>
    ''' <param name="exDA">例外情報</param>
    ''' <returns>取得データ</returns>
    ''' <remarks>exDAは非同期呼び出しのときに、データアクセス側での例外をハンドルするために必要です。</remarks>
    Function GetData(ByVal settingInfo As IDictionary, ByRef readParamInfo As IDictionary(Of IReadParam.取得区分型, IReadParam), ByRef exDA As Exception) As IDictionary(Of IReadParam.取得区分型, DataTable)

End Interface
