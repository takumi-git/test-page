﻿Public Class EntryForm
    Inherits DesignFormBase
    Implements IEntryForm

#Region "マスター保守用変数"
#End Region

#Region "マスター検索用変数"
    Private Const CAB検索 As String = "OSK.X1.CUS.X10070"
    Private _loaderX10070(CabNo) As ProgramLoad.UserInterface.ILocalLoader
    'A-CUST20210125↓
    Private Const 汎用伝票検索 As String = "OSK.X1.OTS.G00600"
    Private _loaderG00600(HANYONo) As ProgramLoad.UserInterface.ILocalLoader
    'A-CUST20210125↑

    'A-CUST20241219↓
    Private 単価履歴検索 As OSK.X1.OTS.LIB.HanyoSubForm.UI.ISubForm
    Private サブ明細入力 As OSK.X1.OTS.LIB.HanyoSubForm.UI.ISubForm
    'A-CUST20241219↑

#End Region

#Region "参照ウィンドウ用変数_※プログラムSUBや別クラスを参照"
    '自クラス－子画面
    Private _伝票発行 As PrintForm
#End Region

#Region "機能制御情報"

    Private _印刷クリップボードコピー区分 As Boolean = True

#End Region

#Region "列挙型"

    Private Enum ファンクション名型 As Integer
        選択
        次伝票
        前伝票
        最終伝票
        伝票検索
        参照検索
        入力期間
        自動連番
        マスター保守
        マスター検索
        選択一覧
        手入力
        クリア
        入力行クリア
        行挿入
        行削除
        行終了
        以下省略
        'A-CUST20241219↓
        単価履歴
        サブ明細
        'A-CUST20241219↑
        サブ明細クリア     'A-CUST20241219 '20250220_2
        FieldBuilder 　　　　　'A-CUST20251104
    End Enum

    Private Enum クリア型 As Integer
        起動時のみ
        全て
        ヘッダー保持
        明細のみ
        明細以降
        フッター以降
    End Enum

    Private Enum コード判定対象型
        取引先コード
        担当者コード
        部門コード
        倉庫コード
        商品コード
        区分
        納品先コード   'A-CUST20201013
    End Enum

    Private Enum 省略判定結果型
        入力
        省略
    End Enum

    Private Enum 等式判定結果型
        等しい
        異なる
    End Enum

    Private Enum CheckType
        DoCheckControl
        DoCheckGroup
    End Enum

    Private Enum 検索種類型 As Integer
        伝票検索 = 0
    End Enum

    '項目追加時、定数CabNoの値を変更
    Private Enum CabNo型 As Integer
        得意先 = 8010
        商品 = 8030
        担当者 = 8040
        部門 = 8050
        倉庫 = 8060
        行区分 = 80801
        消費税区分 = 80802
        課税区分 = 80803
        伝票検索 = 1150
        納品先 = 1610    'A-CUST20201013
    End Enum

    'A-CUST20210125↓
    Private Enum HanyoNo型 As Integer
        見積伝票検索 = 2001
    End Enum
    'A-CUST20210125↑

    Enum 明細種類型 As Integer
        表示部
        入力部
    End Enum

    'A-CUST20251104↓
    Private Enum 属性 As Integer
        未使用 = 0
        全角文字
        半角文字
        数値
        日付
        日付_年月
        日付_年度
        参照定義コード
        画像
        実行ファイル
        ファイル
        フォルダ
        URL
        メールアドレス
    End Enum

    Private Enum 処理モード As Integer
        初回起動 = 0
        入力
        参照
    End Enum
    'A-CUST20251104↑

#End Region

#Region "プロパティ"

    Private _paramInfo As System.Collections.IDictionary
    ''' <summary>
    ''' パラメータ情報（他処理より呼ばれる場合は必要になる）
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property ParamInfo() As System.Collections.IDictionary Implements IEntryForm.ParamInfo
        Get
            Return _paramInfo
        End Get
        Set(ByVal value As System.Collections.IDictionary)
            _paramInfo = value
        End Set
    End Property

    ''' <summary>
    ''' CAB検索のローダー取得／設定
    ''' </summary>
    ''' <param name="targetName"></param>
    ''' <returns></returns>
    Private Property LoaderCABSearch(targetName As CabNo型) As ProgramLoad.UserInterface.ILocalLoader
        Get
            Select Case targetName
                Case CabNo型.得意先
                    Return _loaderX10070(0)

                Case CabNo型.商品
                    Return _loaderX10070(1)

                Case CabNo型.担当者
                    Return _loaderX10070(2)

                Case CabNo型.部門
                    Return _loaderX10070(3)

                Case CabNo型.倉庫
                    Return _loaderX10070(4)

                Case CabNo型.行区分
                    Return _loaderX10070(5)

                Case CabNo型.消費税区分
                    Return _loaderX10070(6)

                Case CabNo型.課税区分
                    Return _loaderX10070(7)

                Case CabNo型.伝票検索
                    Return _loaderX10070(8)

                    'A-CUST20201013↓
                Case CabNo型.納品先
                    Return _loaderX10070(9)
                    'A-CUST20201013↑
                Case Else
                    Return Nothing
            End Select
        End Get
        Set(value As ProgramLoad.UserInterface.ILocalLoader)
            Select Case targetName
                Case CabNo型.得意先
                    _loaderX10070(0) = value

                Case CabNo型.商品
                    _loaderX10070(1) = value

                Case CabNo型.担当者
                    _loaderX10070(2) = value

                Case CabNo型.部門
                    _loaderX10070(3) = value

                Case CabNo型.倉庫
                    _loaderX10070(4) = value

                Case CabNo型.行区分
                    _loaderX10070(5) = value

                Case CabNo型.消費税区分
                    _loaderX10070(6) = value

                Case CabNo型.課税区分
                    _loaderX10070(7) = value

                Case CabNo型.伝票検索
                    _loaderX10070(8) = value

                    'A-CUST20201013↓
                Case CabNo型.納品先
                    _loaderX10070(9) = value
                    'A-CUST20201013↑
            End Select
        End Set
    End Property

    Private _AutoCnt As Integer
    Public Property AutoCnt() As Integer
        Get
            _AutoCnt += 1
            Return _AutoCnt
        End Get
        Set(ByVal value As Integer)
            _AutoCnt = value
        End Set
    End Property

    'A-CUST20210125↓
    ''' <summary>
    ''' 汎用伝票検索のローダー取得／設定
    ''' </summary>
    ''' <param name="targetName"></param>
    ''' <returns></returns>
    Private Property LoaderHanyoSearch(targetName As HanyoNo型) As ProgramLoad.UserInterface.ILocalLoader
        Get
            Select Case targetName

                Case HanyoNo型.見積伝票検索
                    Return _loaderG00600(0)

                Case Else
                    Return Nothing
            End Select
        End Get
        Set(value As ProgramLoad.UserInterface.ILocalLoader)
            Select Case targetName

                Case HanyoNo型.見積伝票検索
                    _loaderG00600(0) = value

            End Select
        End Set
    End Property
    'A-CUST20210125↑ 

#End Region

#Region "構造体"

    Private Structure CellInfoType
        Dim RowIndex As Integer
        Dim ColIndex As Integer
        Dim ColName As String
        Dim TabIndex As Integer
        Sub Initialize()
            RowIndex = -1
            ColIndex = -1
            ColName = ""
            TabIndex = 0
        End Sub
    End Structure

    Private Structure 更新後番号型
        Dim 伝票番号 As Long
        Sub Initialize()
            伝票番号 = 0
        End Sub
    End Structure

#End Region

#Region "Const変数"
    'Private Const KINGAKU_MAXVALUE As Decimal = 999999999                  'D-CUST20211110_01
    Private Const KINGAKU_MAXVALUE As Decimal = 9999999999                  'A-CUST20211110_01
    Private Const GOKEIKINGAKU_MAXVALUE As Decimal = 9999999999999          'A-CUST20211110_01
    Private Const DETAIL_MAXIMUM_ROW As Integer = 300
    'Private Const CabNo As Integer = 8         'CabNo型の個数と同値    　　'D-CUST20201013
    Private Const CabNo As Integer = 9         'CabNo型の個数と同値       'A-CUST20201013
    Private Const HANYONo As Integer = 2        'A-CUST20210125
    Private Const EXPANDITEMCOUNT As Integer = 30 'FieldBuilderの数  'A-CUST20251104
#End Region

#Region "Private変数"

    Private _myコントロール情報 As Myコントロール情報型
    Private _定義情報 As 定義情報型
    Private _日付チェック As IDateCheck

    Private _ControlsList As New List(Of System.Windows.Forms.Control)
    Private _focusSwitcher As IFocusSwitcher
    Private _detailColumnInfoList As ColumnInfoList
    Private _detailColTabIndexList As New SortedDictionary(Of Integer, String)
    Private _contextMenu As SmartControl.ContextMenu.ContextMenu
    Private _gridKeyDownCode As System.Windows.Forms.Keys

    'グリッド制御関連（明細）
    Private _gridHelper As GridHelper
    Private _gridCheckCansel As Integer
    Private _fromCell As CellInfoType
    Private _toCell As CellInfoType
    Private _changeCell As CellInfoType
    Private _強制Redraw As Boolean

    '画面制御関連
    Private _keyReturn As Boolean
    Private _zeroEnd As Boolean
    Private _checkDenpyou As Boolean
    Private _checkMode As checkType
    Private _focusPosition As InputDate.FocusPositionType
    Private _移動先グループ番号 As Integer
    Private _移動先TabIndex As Integer
    Private _gridKeyTab As Boolean
    Private _getGenZaikoLine As Long        '現在庫取得行

    '明細行数制御関連
    Private _defaultMaxRow As Integer
    Private _limitMaxRow As Integer
    Private _maxRowCount As Integer

    '入力値制御関連
    Private _退避情報 As 退避情報型
    Private _現在入力行 As Integer   '0スタート

    '伝票番号退避
    Private _saveRenban As Long

    '更新処理関連
    Private _更新後番号 As 更新後番号型

    '伝票検索関連
    Private _kensakuRenban As Long
    Private _検索自動表示 As Boolean
    Private _検索種類 As Integer
    Private _検索後イベント As Boolean
    Private _検索データ選択 As Boolean

    'ドリルダウン関連
    Private _ドリルダウン As Boolean
    Private _isInitialize As Boolean

    'メッセージ表示関連
    Private _全行一括チェック中 As Boolean = False
    Private _確定押下時チェック中 As Boolean = False

    '消費税
    Private _消費税率 As 消費税率型

    'A-CUST20211001↓
    '単価
    Private _単価取得 As IUnitPriceGetter
    'A-CUST20211001↑

    'A-CUST20251104↓
    Private _expandHeaderCheck As Dictionary(Of String, Integer)    '入力チェック → 0/1/2
    Private _expandHeaderLabel As Dictionary(Of String, String)     '表示名
    Private _expandHeaderZokusei As Dictionary(Of String, Integer)  '属性
    Private _expandMeisaiCheck As Dictionary(Of String, Integer)    '入力チェック → 0/1/2
    Private _expandMeisaiLabel As Dictionary(Of String, String)     '表示名
    Private _expandMeisaiZokusei As Dictionary(Of String, Integer)  '属性
    'A-CUST20251104↑

#End Region

#Region "コンストラクタ"

    Public Sub New()

        ' この呼び出しは、Windows フォーム デザイナで必要です。
        InitializeComponent()

        _focusSwitcher = New FocusSwitch
        _contextMenu = New SmartControl.ContextMenu.ContextMenu
        _退避情報 = New 退避情報型
        _退避情報.Initialize(Me)

        _isInitialize = True

        Me.サイズ保存 = True

    End Sub

#End Region

    ''' <summary>
    ''' フォーカススイッチにチェックメソッドを登録
    ''' </summary>
    ''' <param name="ctrl"></param>
    ''' <remarks></remarks>
    Private Sub AddCheckMethod(ByVal ctrl As System.Windows.Forms.Control)

        With _focusSwitcher
            Select Case ctrl.Name
                '*** ヘッダー
                Case shori.Name
                    .AddCheckMethod(ctrl, CheckModeType.移動元チェック, AddressOf DoCheckControlMoveOut_処理モード)

                Case shoriRenban.Name
                    .AddCheckMethod(ctrl, CheckModeType.移動元チェック, AddressOf DoCheckControlMoveOut_処理連番)
                    .AddCheckMethod(ctrl, CheckModeType.移動先チェック, AddressOf DoCheckControlMoveIn_処理連番)

                Case denpyouDate.Name
                    .AddCheckMethod(ctrl, CheckModeType.移動元チェック, AddressOf DoCheckControlMoveOut_伝票日付)
                    .AddCheckMethod(ctrl, CheckModeType.移動先チェック, AddressOf DoCheckControlMoveIn_伝票日付)

                Case taxRate.Name
                    .AddCheckMethod(ctrl, CheckModeType.移動元チェック, AddressOf DoCheckControlMoveOut_税率)
                    .AddCheckMethod(ctrl, CheckModeType.移動先チェック, AddressOf DoCheckControlMoveIn_税率)

                Case TokuisakiCode.Name
                    .AddCheckMethod(ctrl, CheckModeType.移動元チェック, AddressOf DoCheckControlMoveOut_得意先コード)
                    .AddCheckMethod(ctrl, CheckModeType.移動先チェック, AddressOf DoCheckControlMoveIn_得意先コード)     'A-CUST20200311 '-20200616-001

                Case tantousha.Name
                    .AddCheckMethod(ctrl, CheckModeType.移動元チェック, AddressOf DoCheckControlMoveOut_担当者コード)

                Case bumon.Name
                    .AddCheckMethod(ctrl, CheckModeType.移動元チェック, AddressOf DoCheckControlMoveOut_部門コード)

                    'A-CUST20201013↓
                Case nohinsaki.Name
                    .AddCheckMethod(ctrl, CheckModeType.移動元チェック, AddressOf DoCheckControlMoveOut_納品先コード)
                    .AddCheckMethod(ctrl, CheckModeType.移動先チェック, AddressOf DoCheckControlMoveIn_納品先コード)
                    'A-CUST20201013↑

                Case youken.Name
                    .AddCheckMethod(ctrl, CheckModeType.移動元チェック, AddressOf DoCheckControlMoveOut_要件)

                Case nouki.Name
                    .AddCheckMethod(ctrl, CheckModeType.移動元チェック, AddressOf DoCheckControlMoveOut_納期)

                Case shiharaiHoho.Name
                    .AddCheckMethod(ctrl, CheckModeType.移動元チェック, AddressOf DoCheckControlMoveOut_支払方法)

                Case yuukoukigen.Name
                    .AddCheckMethod(ctrl, CheckModeType.移動元チェック, AddressOf DoCheckControlMoveOut_有効期限)

                Case ShouhizeiCode.Name
                    .AddCheckMethod(ctrl, CheckModeType.移動元チェック, AddressOf DoCheckControlMoveOut_消費税コード)

                Case DetailGridView.Name
                    .AddCheckMethod(ctrl, CheckModeType.移動先チェック, AddressOf DoCheckControlMoveIn_GridView)

                    '*** 明細
                Case DetailGridEdit.Name
                    .AddGridCheckMethod(DetailGridEdit, AddressOf Grid_DoCheck)

                    '*** フッター
                Case biko.Name
                    .AddCheckMethod(ctrl, CheckModeType.移動元チェック, AddressOf DoCheckControlMoveOut_備考名)

            End Select
        End With

    End Sub

    ''' <summary>
    ''' 売上金額の算出
    ''' </summary>
    ''' <param name="数量"></param>
    ''' <param name="単価"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function Detail_売上金額取得(ByVal rowIndex As Integer,
                                         ByVal 数量 As Decimal,
                                         ByVal 単価 As Decimal,
                                         ByVal 明細種類 As 明細種類型) As Boolean

        If 数量 = 0 OrElse 単価 = 0 Then
            Return True
        End If

        Dim 金額 As Decimal = 0
        Dim result As Boolean = False

        result = GetKingaku(数量, 単価, _myコントロール情報.小数桁_数量, _myコントロール情報.小数桁_売上単価, 金額)

        If result = False Then
            Return False
        End If

        Select Case 明細種類
            Case 明細種類型.表示部
                _退避情報.明細表示部項目(rowIndex, 退避情報型.明細項目型.金額) = 金額
                DetailGridView.SetData(rowIndex, 退避情報型.明細項目型.金額.ToString, _退避情報.明細表示部項目(rowIndex, 退避情報型.明細項目型.金額))
            Case 明細種類型.入力部
                _退避情報.明細入力部項目(退避情報型.明細項目型.金額) = 金額
                DetailGridEdit.SetData(0, 退避情報型.明細項目型.金額.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.金額))
        End Select

        Return True

    End Function

    ''' <summary>
    ''' 原価金額の算出
    ''' </summary>
    ''' <param name="数量"></param>
    ''' <param name="原単価"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function Detail_原価金額取得(
                                    ByVal rowIndex As Integer,
                                    ByVal 数量 As Decimal,
                                    ByVal 原単価 As Decimal,
                                    ByVal 明細種類 As 明細種類型) As Boolean

        If 数量 = 0 OrElse 原単価 = 0 Then
            Return True
        End If

        Dim 金額 As Decimal = 0
        If GetGenkaKingaku(数量, 原単価, _myコントロール情報.小数桁_数量, _myコントロール情報.小数桁_仕入単価, 金額) = False Then
            Return False
        End If

        Select Case 明細種類
            Case 明細種類型.表示部
                _退避情報.明細表示部項目(rowIndex, 退避情報型.明細項目型.原価金額) = 金額
                DetailGridView.SetData(rowIndex, 退避情報型.明細項目型.原価金額.ToString, _退避情報.明細表示部項目(rowIndex, 退避情報型.明細項目型.原価金額))
            Case 明細種類型.入力部
                _退避情報.明細入力部項目(退避情報型.明細項目型.原価金額) = 金額
                DetailGridEdit.SetData(0, 退避情報型.明細項目型.原価金額.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.原価金額))
        End Select

        Return True

    End Function

    ''' <summary>
    ''' 各金額計算及び、集計処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Function Detail_各金額集計(ByVal rowindex As Integer, ByVal 明細種類 As 明細種類型) As Boolean

        Dim 消費税額表示 As Boolean = True

        Dim 税抜金額 As Decimal = 0
        Dim 税率 As Decimal = CDec(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.税率))
        Dim 金額 As Decimal
        Dim 端数単位 As Integer = 1
        Dim 消費税額 As Decimal = 0
        Dim 課税区分 As String = ""
        Dim 端数区分 As IMoneyCalculate.端数処理区分
        Dim 原価金額 As Decimal = 0

        If Is消費税計算() = 消費税計算区分型.請求単位 Then
            消費税額表示 = False
        End If

        端数区分 = Is得意先端数処理区分()

        Select Case 明細種類
            Case 明細種類型.表示部
                税抜金額 = CDec(_退避情報.明細表示部項目(rowindex, 退避情報型.明細項目型.金額))
                課税区分 = CStr(_退避情報.明細表示部項目(rowindex, 退避情報型.明細項目型.課税区分))
                金額 = CDec(_退避情報.明細表示部項目(rowindex, 退避情報型.明細項目型.金額))
                原価金額 = CDec(_退避情報.明細表示部項目(rowindex, 退避情報型.明細項目型.原価金額))
            Case 明細種類型.入力部
                税抜金額 = CDec(_退避情報.明細入力部項目(退避情報型.明細項目型.金額))
                課税区分 = CStr(_退避情報.明細入力部項目(退避情報型.明細項目型.課税区分))
                金額 = CDec(_退避情報.明細入力部項目(退避情報型.明細項目型.金額))
                原価金額 = CDec(_退避情報.明細入力部項目(退避情報型.明細項目型.原価金額))
        End Select

        '税抜金額
        GetBunkaiKingaku(課税区分, 金額, 税率, 端数区分, 端数単位, 消費税額, 税抜金額)

        If Is課税区分(課税区分) = 課税区分型.税込 Or
           Is課税区分(課税区分) = 課税区分型.税抜 Then
            _退避情報.フッター部項目(退避情報型.フッター項目型.対象金額) = 税抜金額 + CDec(_退避情報.フッター部項目(退避情報型.フッター項目型.対象金額))
        End If

        If 消費税額表示 = True Then
            _退避情報.フッター部項目(退避情報型.フッター項目型.合計金額) = CDec(_退避情報.フッター部項目(退避情報型.フッター項目型.合計金額)) + 税抜金額
        Else
            _退避情報.フッター部項目(退避情報型.フッター項目型.合計金額) = CDec(_退避情報.フッター部項目(退避情報型.フッター項目型.合計金額)) + 金額
        End If

        '内消費税を退避 
        Dim 内消費税 As Decimal = 0
        If Is課税区分(課税区分) = 課税区分型.税込 Then
            内消費税 = 消費税額
        End If

        Select Case 明細種類
            Case 明細種類型.表示部
                _退避情報.明細表示部項目(rowindex, 退避情報型.明細項目型.内消費税額) = 内消費税
            Case 明細種類型.入力部
                _退避情報.明細入力部項目(退避情報型.明細項目型.内消費税額) = 内消費税
        End Select

        '消費税計算用に保持
        If Is課税区分(課税区分) = 課税区分型.税込 Then
            _退避情報.フッター部項目(退避情報型.フッター項目型.消費税用_税込_分解消費税計) = CDec(_退避情報.フッター部項目(退避情報型.フッター項目型.消費税用_税込_分解消費税計)) + 消費税額
        ElseIf Is課税区分(課税区分) = 課税区分型.税抜 Then
            _退避情報.フッター部項目(退避情報型.フッター項目型.消費税用_税抜_金額合計) = CDec(_退避情報.フッター部項目(退避情報型.フッター項目型.消費税用_税抜_金額合計)) + 税抜金額
        End If

        '粗利額合計/粗利率
        _退避情報.フッター部項目(退避情報型.フッター項目型.粗利額合計) = CDec(_退避情報.フッター部項目(退避情報型.フッター項目型.粗利額合計)) + 税抜金額 - 原価金額

        _退避情報.フッター部項目(退避情報型.フッター項目型.粗利用_税抜_金額合計) = CDec(_退避情報.フッター部項目(退避情報型.フッター項目型.粗利用_税抜_金額合計)) + 税抜金額

        _退避情報.フッター部項目(退避情報型.フッター項目型.粗利率) = GetArariRitu(CDec(_退避情報.フッター部項目(退避情報型.フッター項目型.粗利額合計)),
                                                                                  CDec(_退避情報.フッター部項目(退避情報型.フッター項目型.粗利用_税抜_金額合計)))

        '更新用に保持
        If Is課税区分(課税区分) = 課税区分型.非課税 Then
            _退避情報.フッター部項目(退避情報型.フッター項目型.更新用_非課税額) = CDec(_退避情報.フッター部項目(退避情報型.フッター項目型.更新用_非課税額)) + 金額
        End If

        Return True

    End Function

    ''' <summary>
    ''' 消費税計算
    ''' </summary>
    ''' <remarks></remarks>
    Private Function Detail_消費税計算() As Boolean

        Dim 消費税額表示 As Boolean = True
        Dim 税抜金額 As Decimal = 0
        Dim 税率 As Decimal = CDec(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.税率))
        Dim 金額 As Decimal
        Dim 端数単位 As Integer = 1
        Dim 税抜_消費税額 As Decimal = 0
        Dim 税込_消費税額 As Decimal = 0
        Dim 消費税額 As Decimal = 0
        Dim 課税区分 As String = "00"
        Dim 端数区分 As IMoneyCalculate.端数処理区分

        If Is消費税計算() = 消費税計算区分型.請求単位 Then
            消費税額表示 = False
        End If

        '税抜
        金額 = CDec(_退避情報.フッター部項目(退避情報型.フッター項目型.消費税用_税抜_金額合計))
        If 金額 <> 0 Then
            端数区分 = Is得意先端数処理区分()
            課税区分 = "01"
            GetBunkaiKingaku(課税区分, 金額, 税率, 端数区分, 端数単位, 税抜_消費税額, 税抜金額)
        End If
        If 消費税額表示 = False Then
            税抜_消費税額 = 0
        End If

        '税込
        税込_消費税額 = CDec(_退避情報.フッター部項目(退避情報型.フッター項目型.消費税用_税込_分解消費税計))

        消費税額 = 税抜_消費税額 + 税込_消費税額

        '合計金額桁オーバーチェック(13桁)
        Dim 合計 As Decimal
        合計 = CDec(_退避情報.フッター部項目(退避情報型.フッター項目型.合計金額)) + 消費税額
        'If System.Math.Abs(合計) > KINGAKU_MAXVALUE Then         'D-CUST20211110_01
        If System.Math.Abs(合計) > GOKEIKINGAKU_MAXVALUE Then     'A-CUST20211110_01
            MessageViewer.Show(76)
            Return False
        End If

        _退避情報.フッター部項目(退避情報型.フッター項目型.消費税額) = 消費税額

        If 消費税額表示 = True Then
            _退避情報.フッター部項目(退避情報型.フッター項目型.合計金額) = CDec(_退避情報.フッター部項目(退避情報型.フッター項目型.消費税額)) +
                                                                           CDec(_退避情報.フッター部項目(退避情報型.フッター項目型.合計金額))
        End If

        Return True

    End Function

    ''' <summary>
    ''' 現在庫情報を取得/表示処理
    ''' </summary>
    ''' <param name="rowIndex"></param>
    ''' <param name="colName"></param>
    ''' <remarks></remarks>
    Private Sub Detail_現在庫取得(ByVal rowIndex As Integer, ByVal colName As String)

        If Is現在庫取得判定(rowIndex, colName) = False Then
            GoTo Detail_現在庫取得_End
        End If

        '現在庫情報Read
        Dim param As New ReadParam
        param.Container(ReadParam.項目名型.倉庫コード_ストアド) = _退避情報.明細入力部項目(退避情報型.明細項目型.倉庫コード)
        param.Container(ReadParam.項目名型.商品コード_ストアド) = _退避情報.明細入力部項目(退避情報型.明細項目型.商品コード)
        param.Container(ReadParam.項目名型.期首年月_ストアド) = _myコントロール情報.期首年月
        param.Container(ReadParam.項目名型.指定年月_ストアド) = 0
        param.Container(ReadParam.項目名型.指定年月日_ストアド) = _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.伝票日付)
        param.Container(ReadParam.項目名型.自社締日付_ストアド) = _myコントロール情報.自社締日
        param.Container(ReadParam.項目名型.数量小数点以下桁数_ストアド) = _myコントロール情報.小数桁_数量
        param.Container(ReadParam.項目名型.端数単位処理方法_ストアド) = _myコントロール情報.金額端数処理

        Dim Genzaiko As Decimal
        ReadMaster_現在庫情報(param, Genzaiko)

        '全社在庫
        Dim ZensyaZaiko As Decimal
        param.Container(ReadParam.項目名型.倉庫コード_ストアド) = ""
        ReadMaster_現在庫情報(param, ZensyaZaiko)

        _getGenZaikoLine = rowIndex

        _退避情報.フッター部項目(退避情報型.フッター項目型.全社現在庫) = ZensyaZaiko
        _退避情報.フッター部項目(退避情報型.フッター項目型.倉庫別現在庫) = Genzaiko

Detail_現在庫取得_End:
        Detail_現在庫表示(rowIndex, colName)
    End Sub

    ''' <summary>
    ''' 現在庫情報の表示
    ''' </summary>
    ''' <param name="rowIndex"></param>
    ''' <param name="colName"></param>
    ''' <remarks></remarks>
    Private Sub Detail_現在庫表示(ByVal rowIndex As Integer, ByVal colName As String)

        Dim 全社現在庫表示 As Boolean = True
        Dim 倉庫現在庫表示 As Boolean = True

        If rowIndex = -1 Then
            倉庫現在庫表示 = False
            全社現在庫表示 = False
            GoTo Phase_Disp
        End If

        Select Case colName
            Case 退避情報型.明細項目型.区分.ToString,
                 退避情報型.明細項目型.行.ToString,
                 退避情報型.明細項目型.商品コード.ToString
                倉庫現在庫表示 = False
                全社現在庫表示 = False
                GoTo Phase_Disp
        End Select

        If Is省略判定(コード判定対象型.商品コード, _退避情報.明細入力部項目(退避情報型.明細項目型.商品コード).ToString) = 省略判定結果型.省略 Then
            倉庫現在庫表示 = False
            全社現在庫表示 = False
            GoTo Phase_Disp '表示制御へ
        Else
            Dim 商品情報 As DataTable = CType(_退避情報.明細入力部項目(退避情報型.明細項目型.商品マスター情報), DataTable)
            If 商品情報.Rows(0).Item("CUSME03016").ToString <> "01" Then
                '在庫管理を行わない商品は表示なし
                全社現在庫表示 = False
                倉庫現在庫表示 = False
                GoTo Phase_Disp '表示制御へ
            End If
        End If

        If Is省略判定(コード判定対象型.倉庫コード, _退避情報.明細入力部項目(退避情報型.明細項目型.倉庫コード).ToString) = 省略判定結果型.省略 Then
            倉庫現在庫表示 = False
            全社現在庫表示 = False
        End If

Phase_Disp:

        '倉庫現在庫表示／非表示
        If 倉庫現在庫表示 = False Then
            SokoGenzaiko.Value = 0
            SokoGenzaiko.ZeroDisplay = False
        Else
            SokoGenzaiko.Value = CDec(_退避情報.フッター部項目(退避情報型.フッター項目型.倉庫別現在庫))
            SokoGenzaiko.ZeroDisplay = True
        End If

        '全社現在庫表示／非表示
        If 全社現在庫表示 = False Then
            ZensyaGenzaiko.Value = 0
            ZensyaGenzaiko.ZeroDisplay = False
        Else
            ZensyaGenzaiko.Value = CDec(_退避情報.フッター部項目(退避情報型.フッター項目型.全社現在庫))
            ZensyaGenzaiko.ZeroDisplay = True
        End If

    End Sub

    ''' <summary>
    ''' 返品値引時のマイナス符号初期表示
    ''' </summary>
    ''' <param name="rowIndex"></param>
    ''' <param name="colName"></param>
    ''' <remarks></remarks>
    Private Sub Detail_返品値引マイナス符号初期表示(ByVal rowIndex As Integer, ByVal colName As String)

        'Dim 取引区分属性 As Integer = CInt(Val(_退避情報.明細入力部項目(退避情報型.明細項目型.区分)))       'D-CUST20200311 '-20200527-001
        'A-CUST20200311↓ '-20200527-001
        _退避情報.行区分 = CType(_退避情報.明細入力部項目(退避情報型.明細項目型.行区分マスター情報), DataTable)
        Dim 取引区分属性 As Integer = CInt(Val(_退避情報.行区分項目("CUSCE03005")))
        'A-CUST20200311↑ '-20200527-001
        Dim マイナス符号 As Boolean = False
        Select Case colName
            Case 退避情報型.明細項目型.数量.ToString
                If 取引区分属性 = 取引区分属性型.返品 Then
                    マイナス符号 = True
                End If

            Case 退避情報型.明細項目型.原単価.ToString,
                 退避情報型.明細項目型.単価.ToString
                If 取引区分属性 = 取引区分属性型.値引 Then
                    マイナス符号 = True
                End If

            Case 退避情報型.明細項目型.原価金額.ToString,
                 退避情報型.明細項目型.金額.ToString
                If 取引区分属性 = 取引区分属性型.返品 OrElse
                   取引区分属性 = 取引区分属性型.値引 Then
                    マイナス符号 = True
                End If

        End Select

        If マイナス符号 = False Then
            Exit Sub
        End If

        Dim 画面値 As Decimal = CDec(DetailGridEdit.GetData(rowIndex, colName))
        If 画面値 = 0 Then
            Dim nowControl As InputNumerical
            nowControl = TryCast(DetailGridEdit.GetActiveControl, InputNumerical)
            If nowControl IsNot Nothing Then
                nowControl.ToNegative()
                nowControl.ClearSelection()
            End If
        End If

    End Sub

    ''' <summary>
    ''' クリア処理
    ''' </summary>
    ''' <param name="クリア対象"></param>
    ''' <remarks></remarks>
    Private Sub Clear(ByVal クリア対象 As クリア型)

        _focusSwitcher.EnableEvent(False)

        If クリア対象 = クリア型.明細以降 Then GoTo clear_Detail
        If クリア対象 = クリア型.フッター以降 Then GoTo clear_Foot
        If クリア対象 = クリア型.明細のみ Then GoTo clear_Detail

clear_Head1:
        '-------------------------
        '   ヘッダー部①
        '-------------------------
        If クリア対象 = クリア型.起動時のみ Or
           CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード)) = 処理区分型.修正 Or
           CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード)) = 処理区分型.削除 Then
            shoriRenban.Value = 0
            denpyouDate.Date = _退避情報.操作日付
            _退避情報.ClearDataTableヘッダー部(退避情報型.グループ型.No１)

            SetUpComboBoxTaxRate(taxRate.ComboBoxControl, denpyouDate)
            Dim 対象日付 As Integer = denpyouDate.Date
            Dim rateIndex As Integer = taxRate.表示項目番号
            Dim rateValue As Decimal = CDec(taxRate.ComboBoxControl.Items(taxRate.表示項目番号))
            _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.税率) = rateValue
            _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.税率番号) = rateIndex
        End If


        _退避情報.グループ状態(退避情報型.グループ型.No１) = 退避情報型.状態.エラー

clear_Head2:
        '-------------------------
        '   ヘッダー部②
        '-------------------------
        If クリア対象 <> クリア型.ヘッダー保持 Then
            _退避情報.ClearDataTableヘッダー部(退避情報型.グループ型.No２)
        End If
        _退避情報.グループ状態(退避情報型.グループ型.No２) = 退避情報型.状態.エラー

clear_Head3:
        '-------------------------
        '   ヘッダー部③
        '-------------------------
        If クリア対象 = クリア型.ヘッダー保持 Then
        Else
            TokuisakiCode.TextValue = ""
            TokuisakiName1.Text = ""
            TokuisakiName2.Text = ""
            tantousha.TextValue = ""
            tantousha.DispNameText = ""
            bumon.TextValue = ""
            bumon.DispNameText = ""
            'A-CUST20201013↓
            nohinsaki.TextValue = ""
            nohinsaki.DispNameText = ""
            'A-CUST20201013↑
            youken.Text = ""
            nouki.Text = ""
            shiharaiHoho.Text = ""
            yuukoukigen.Text = ""

            ShouhizeiCode.TextValue = ""
            ShouhizeiCode.DispNameText = ""

            _退避情報.ClearDataTableヘッダー部(退避情報型.グループ型.No３)
            _退避情報.ClearDataTable得意先()
            _退避情報.ClearDataTable担当者()
            _退避情報.ClearDataTable部門()
            _退避情報.ClearDataTable納品先()       'A-CUST20201013
            _退避情報.ClearDataTable消費税()
            _退避情報.ClearDataTableFieldBuilderヘッダー()  'A-CUST20251104

            _退避情報.グループ状態(退避情報型.グループ型.No３) = 退避情報型.状態.エラー
        End If

clear_Detail:
        '-------------------------
        '   明細部
        '-------------------------
        DetailGridEdit.Redraw = False
        DetailGridView.Redraw = False
        DetailGridEdit.RowCount = 0
        DetailGridView.RowCount = 0

        _gridHelper.Insert(_退避情報.CreateNewRow明細(True))
        _退避情報.明細入力部.Clear()
        _退避情報.明細入力部.Rows.Add(_退避情報.CreateNewRow明細(True))
        _退避情報.明細表示部.Clear()
        _退避情報.明細表示部.Rows.Add(_退避情報.CreateNewRow明細(False))
        SettInitialvalue_Meisai()
        DetailGridEdit.DataTable = _退避情報.明細入力部.Copy
        DetailGridView.DataTable = _退避情報.明細表示部.Copy
        DetailGridEdit.Redraw = True
        DetailGridView.Redraw = True

        _現在入力行 = 0
        SetRowStateLabel(True)

        _退避情報.ClearDataTable商品()
        _退避情報.ClearDataTable倉庫()
        _退避情報.ClearDataTable課税区分()
        _退避情報.ClearDataTableFieldBuilder明細()    'A-CUST20251104
        _退避情報.グループ状態(退避情報型.グループ型.No４) = 退避情報型.状態.エラー

        _maxRowCount = 0
        If クリア対象 <> クリア型.ヘッダー保持 Then
            _limitMaxRow = _defaultMaxRow
        End If

        '明細のみクリア時はここで終了
        If クリア対象 = クリア型.明細のみ Then GoTo clear_End

clear_Foot:
        '-------------------------
        '   フッター部
        '-------------------------
        biko.Text = ""
        SokoGenzaiko.Value = 0
        ZensyaGenzaiko.Value = 0
        TotalArari.Value = 0
        ArariRitu.Value = 0
        ZensyaGenzaiko.Value = 0
        TaisyoKingaku.Value = 0
        Syouhizeigaku.Value = 0
        totalKingaku.Value = 0

        _退避情報.ClearDataTableフッター部()

        _退避情報.グループ状態(退避情報型.グループ型.No５) = 退避情報型.状態.エラー
        _退避情報.グループ状態(退避情報型.グループ型.No６) = 退避情報型.状態.エラー

clear_End:
        _gridCheckCansel = 0
        _getGenZaikoLine = -1
        _focusSwitcher.EnableEvent(True)

    End Sub

    ''' <summary>
    ''' 初期値をセットする
    ''' </summary>
    Private Sub SettInitialvalue_Meisai()

        '行区分
        Grid_DoCheckCell_区分(CStr(_退避情報.明細入力部項目(退避情報型.明細項目型.区分)), False)

    End Sub

    ''' <summary>
    ''' 画面コントロールのコレクション
    ''' </summary>
    ''' <param name="top"></param>
    ''' <returns></returns>
    ''' <remarks>子コントロールも対象にする為、回帰的処理される。</remarks>
    Private Function CollectionFormControls(ByVal top As Control) As List(Of System.Windows.Forms.Control)
        Dim ctrlList As New List(Of System.Windows.Forms.Control)

        For Each ctrl As Control In top.Controls
            If Is管理対象コントロール判定(ctrl) = True Then
                ctrlList.Add(ctrl)
            End If
            ctrlList.AddRange(CollectionFormControls(ctrl))
        Next

        Return ctrlList

    End Function

    ''' <summary>
    ''' グリッドの列をTabIndex順に配列化
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CollectionGridTabIndexOrder(ByVal gridEdit As OSK.X1.Foundation.SimpleControl.GridEdit) As SortedDictionary(Of Integer, String)

        Dim tabIndexOrder As New SortedDictionary(Of Integer, String)

        For index As Integer = 0 To gridEdit.ColumnCount - 1
            Dim tabIndex As Integer = gridEdit.Columns(index).TabIndex
            Dim name As String = gridEdit.Columns(index).Name
            If tabIndex <> -1 Then
                tabIndexOrder.Add(tabIndex, name)
            End If
        Next

        Return tabIndexOrder

    End Function

    ''' <summary>
    ''' 日付コントロールフォーカス位置の退避／設定
    ''' </summary>
    ''' <param name="control"></param>
    ''' <param name="action"></param>
    ''' <remarks></remarks>
    Private Sub DateControlFocusPosition(
                                    ByVal control As System.Windows.Forms.Control,
                                    ByVal action As String)

        Dim dateControl As InputDate

        dateControl = TryCast(control, InputDate)

        If dateControl Is Nothing Then
            Exit Sub
        End If

        Select Case action.ToUpper
            Case "GET"
                _focusPosition = dateControl.FocusPosition

            Case "SET"
                If _focusPosition = InputDate.FocusPositionType.None Then
                    Exit Sub
                End If

                dateControl.SetFocusPosition(_focusPosition)
                _focusPosition = InputDate.FocusPositionType.None
        End Select

    End Sub

#Region "移動元チェック 個別コントロール"

    Private Function DoCheckControlMoveOut_処理モード(ByVal args As CheckMethodArgs) As Boolean

        Select Case shori.Value
            Case 処理区分型.登録
                'ヘッダー部以降の項目へ移動は不可
                If args.移動先グループ番号 > 退避情報型.グループ型.No３ Then
                    Return False
                End If

            Case 処理区分型.修正, 処理区分型.削除
                '処理連番以外の項目へ移動は不可
                If args.移動先コントロール.Name <> shoriRenban.InputNumericalControl.Name Then
                    Return False
                End If
        End Select

        '確定
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード) = shori.Value


        _検索データ選択 = False
        _検索自動表示 = False

        If CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード)) = 処理区分型.登録 Then
            Clear(クリア型.全て)

            '連番管理テーブルRead
            If ReadControl_連番管理() = False Then
                Return False
            End If

            '番号採番
            _退避情報.連番管理項目("CUSCE21008") = CLng(_退避情報.連番管理項目("CUSCE21008")) + 1
            If CLng(_退避情報.連番管理項目("CUSCE21008")) > 9999999999 Then
                _退避情報.連番管理項目("CUSCE21008") = 1
            End If

            _退避情報.グループ状態(退避情報型.グループ型.No２) = 退避情報型.状態.正常
        End If

        Return True

    End Function

    Private Function DoCheckControlMoveOut_処理連番(ByVal args As CheckMethodArgs) As Boolean

        Dim Save検索後イベントflg As Boolean = _検索後イベント

        If _検索後イベント = False Then
            If CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード)) = 処理区分型.登録 Then
                Return True
            End If

            If args.移動先コントロール IsNot Nothing Then
                If shoriRenban.Value = 0 Then
                    MessageViewer.Show(72)
                    Return False
                End If
                If CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード)) = 処理区分型.削除 Then
                    If Is伝票読込コントロール判断(args.移動先コントロール) = False AndAlso
                       args.移動先コントロール.Name <> execute.Name Then
                        Return False
                    End If
                End If
                If shoriRenban.Value = CLng(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理連番)) Then
                    GoTo Phase_Check
                End If
                If Is伝票読込コントロール判断(args.移動先コントロール) = False AndAlso
                   args.移動先コントロール.Name <> execute.Name Then
                    Return False
                End If
            End If
        End If

        '伝票Read
        Dim param As New ReadParam
        Select Case args.移動元KeyDownCode
            Case Keys.F6
                param.Container(ReadParam.項目名型.読込種別) = ReadParam.読込種別型.次伝票
                param.Container(ReadParam.項目名型.伝票番号) = _saveRenban
            Case Keys.F7
                param.Container(ReadParam.項目名型.読込種別) = ReadParam.読込種別型.前伝票
                param.Container(ReadParam.項目名型.伝票番号) = _saveRenban
            Case Keys.F8
                param.Container(ReadParam.項目名型.読込種別) = ReadParam.読込種別型.最終伝票
                param.Container(ReadParam.項目名型.伝票番号) = _saveRenban
            Case Else
                param.Container(ReadParam.項目名型.読込種別) = ReadParam.読込種別型.一伝票
                If _検索後イベント = True Then
                    param.Container(ReadParam.項目名型.伝票番号) = _kensakuRenban
                Else
                    param.Container(ReadParam.項目名型.伝票番号) = shoriRenban.Value
                End If
        End Select
        '空のマスター情報
        param.Container(ReadParam.項目名型.商品マスター情報) = _退避情報.商品.Clone

        If _検索後イベント = False Then
            _検索データ選択 = False
            _検索自動表示 = False
        End If
        _検索後イベント = False
        _kensakuRenban = 0

        If ReadDenpyou_伝票(param) = False Then
            'MessageViewer.Show(1002, "OTS")      'D-CUST20230315
            MessageViewer.Show(999000001, "OTS")  'A-CUST20230315
            _ドリルダウン = False
            Return False
        End If

        If CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード)) <> 処理区分型.登録 Then
            '表示できないデータの読み飛ばしを行わないためここで伝票番号のみ表示
            shoriRenban.Value = CLng(_退避情報.見積ヘッダー項目("CUSRE11001"))
        End If
        _saveRenban = CLng(shoriRenban.Value)

        '----------------------------------------
        '   データセキュリティチェック
        '----------------------------------------
        Dim セキュリティエラー As Boolean = False
        Dim セキュリティエラーメッセージ As Integer = -1
        Select Case Check伝票_データセキュリティ(args.移動元KeyDownCode, セキュリティエラーメッセージ)
            Case 0  '正常
            Case -1 'エラー（伝票表示不可）
                Return False
            Case -2 'エラー（伝票表示可）
                セキュリティエラー = True
        End Select

        '----------------------------------------
        '   伝票内容表示前チェック
        '----------------------------------------
        Select Case args.移動元KeyDownCode
            Case Keys.F6, Keys.F7, Keys.F8
            Case Else
                If Check伝票_表示前チェック() = False Then
                    Return False
                End If
        End Select

        '----------------------------------------
        '   確定
        '----------------------------------------
        If CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード)) <> 処理区分型.登録 Then
            shoriRenban.Value = CLng(_退避情報.見積ヘッダー項目("CUSRE11001"))
            _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理連番) = shoriRenban.Value
        End If
        _checkDenpyou = False

        '----------------------------------------
        '   入力画面ワーク編集
        '----------------------------------------
        EditForm_見積()

        '----------------------------------------
        '   画面表示
        '----------------------------------------
        DisplayForm()

        If _ドリルダウン = True AndAlso
           ParamInfo.Contains("GYONO") = True Then
            SetGridAnyRow(CInt(ParamInfo.Item("GYONO")) - 1)
            If CInt(ParamInfo.Item("GYONO")) > 0 Then
                _現在入力行 = CInt(ParamInfo.Item("GYONO")) - 1
            End If
        End If

Phase_Check:
        '----------------------------------------
        '   表示伝票のチェック
        '----------------------------------------
        'データセキュリティエラーの場合、確定値をクリア
        If セキュリティエラー = True Then
            _ドリルダウン = False
            _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理連番) = 0

            If _退避情報.起動モード <> 起動モード型.詳細モード And
               Save検索後イベントflg = False Then
                MessageViewer.Show(セキュリティエラーメッセージ, "OTS")
            End If

            If Save検索後イベントflg = True Then
                _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.部門コード) = ""
            End If
            Return False
        End If

        '次／前／最終伝票表示時はチェックしない
        Select Case args.移動元KeyDownCode
            Case Keys.F6, Keys.F7, Keys.F8
                GoTo Phase_End
        End Select

        'チェック済（処理連番変更なし）はチェックしない
        If _checkDenpyou = True Then
            GoTo Phase_End
        End If

        If Check伝票() = False Then
            Return False
        End If

        _checkDenpyou = True

Phase_End:
        Return True

    End Function

    Private Function DoCheckControlMoveOut_伝票日付(ByVal args As CheckMethodArgs) As Boolean

        If CBool(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.伝票日付チェックフラグ)) = True AndAlso
           denpyouDate.Date = CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.伝票日付)) Then
            Return True
        End If

        '日付省略(ゼロ)はエラー
        If Val(denpyouDate.Date) = 0 Then
            GoTo Check_Error
        End If

        '入力可能日付チェック
        Dim check As Integer = 0

        _日付チェック.CheckDate(_myコントロール情報.期首年月日, _myコントロール情報.入力可能期間, denpyouDate.Date, check)

        If check = 1 Then
            'MessageViewer.Show(1001, "OTS")      'D-CUST20230315
            MessageViewer.Show(999000000, "OTS")  'A-CUST20230315
            GoTo Check_Error
        End If

Check_OK:

        '確定
        Dim 変更前_伝票日付 As Integer = CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.伝票日付))
        Dim 変更後_伝票日付 As Integer = denpyouDate.Date
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.伝票日付) = denpyouDate.Date
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.伝票日付チェックフラグ) = True

        If CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード)) = 処理区分型.登録 Then
            SetUpComboBoxTaxRate(taxRate.ComboBoxControl, denpyouDate)
            If taxRate.表示項目番号 <> CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.税率番号)) Then
                _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.税率) = CDec(taxRate.ComboBoxControl.Items(taxRate.表示項目番号))
                _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.税率番号) = taxRate.表示項目番号
                If Footer_初期処理() = False Then
                    Return False
                End If
                DisplayForm_合計部()
            End If
        End If

        _getGenZaikoLine = -1

        Return True

Check_Error:
        If args.移動元グループ番号 <> 退避情報型.グループ型.No３ AndAlso
           Is伝票読込コントロール判断(args.移動先コントロール) = True Then
            Return False
        End If

        Return False

    End Function

    Private Function DoCheckControlMoveOut_税率(ByVal args As CheckMethodArgs) As Boolean

        If taxRate.表示項目番号 = -1 Then
            MessageViewer.Show(72)
            Return False
        End If

        If taxRate.表示項目番号 = CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.税率番号)) Then
            Return True
        End If

        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.税率番号) = taxRate.表示項目番号
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.税率) = CDec(taxRate.ComboBoxControl.Items(taxRate.表示項目番号))

        If Footer_初期処理() = False Then
            Return False
        End If
        DisplayForm_合計部()

        Return True

    End Function

    Private Function DoCheckControlMoveOut_得意先コード(ByVal args As CheckMethodArgs) As Boolean

        Dim 旧課税区分 As String = CStr(_退避情報.得意先項目("CUSME01019"))
        Dim 変更前得意先コード As String = CStr(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.得意先コード))    'A-CUST20200311 '-20200609-002


        If Is省略判定(コード判定対象型.取引先コード, TokuisakiCode.TextValue) = 省略判定結果型.省略 Then
            MessageViewer.Show(72)
            Return False
        End If

        If Is等式判定(コード判定対象型.取引先コード,
                      TokuisakiCode.TextValue.TrimEnd,
                      CStr(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.得意先コード))) = 等式判定結果型.等しい Then
            Return True
        End If

        '得意先マスターRead
        Dim param As New ReadParam
        param.Container(ReadParam.項目名型.得意先コード) = TokuisakiCode.TextValue

        If ReadMaster_得意先(param) = False Then
            MessageViewer.Show(41)
            Return False
        End If

        '-------------
        '  確定処理
        '-------------
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.得意先コード) = TokuisakiCode.TextValue

        TokuisakiName1.Text = CStr(_退避情報.得意先項目("CUSME01002"))
        TokuisakiName2.Text = CStr(_退避情報.得意先項目("CUSME01003"))
        tantousha.TextValue = CStr(_退避情報.得意先項目("CUSME01016"))
        tantousha.DispNameText = CStr(_退避情報.担当者項目("CUSME04002"))
        bumon.TextValue = CStr(_退避情報.担当者項目("CUSME04005"))
        bumon.DispNameText = CStr(_退避情報.部門項目("CUSME05002"))
        ShouhizeiCode.TextValue = CStr(_退避情報.得意先項目("CUSME01017"))
        ShouhizeiCode.DispNameText = CStr(_退避情報.消費税項目("CUSCE03003"))

        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.得意先名１) = TokuisakiName1.Text
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.得意先名２) = TokuisakiName2.Text
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.担当者コード) = tantousha.TextValue
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.担当者名) = tantousha.DispNameText
        'A-CUST20201013↓
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.納品先コード) = "000000"
        'A-CUST20201013↑
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.消費税コード) = ShouhizeiCode.TextValue
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.消費税名) = ShouhizeiCode.DispNameText
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.得意先マスター情報) = _退避情報.得意先.Copy
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.担当者マスター情報) = _退避情報.担当者.Copy
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.消費税マスター情報) = _退避情報.消費税.Copy
        '部門についてはセキュリティがあるため保持しない

        '課税区分が対象外となる場合、明細部をすべて非課税へ変更
        If Is省略判定(コード判定対象型.取引先コード, 変更前得意先コード) = 省略判定結果型.入力 Then    'A-CUST20200311 '-20200609-002
            If Is得意先課税対象() = False And
               CStr(_退避情報.得意先項目("CUSME01019")) <> 旧課税区分 Then
                Change明細課税区分()
            End If
        End If                                                                                         'A-CUST20200311 '-20200609-002

        'フッター部の再計算
        If Footer_初期処理() = False Then
            Return False
        End If
        DisplayForm_合計部()

        Return True

    End Function

    Private Function DoCheckControlMoveOut_担当者コード(ByVal args As CheckMethodArgs) As Boolean

        If Is省略判定(コード判定対象型.担当者コード, tantousha.TextValue) = 省略判定結果型.省略 Then
            MessageViewer.Show(72)
            Return False
        End If

        If Is等式判定(コード判定対象型.担当者コード,
                      tantousha.TextValue,
                      CStr(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.担当者コード))) = 等式判定結果型.等しい Then
            Return True
        End If

        '担当者マスターRead
        Dim param As New ReadParam
        param.Container(ReadParam.項目名型.担当者コード) = tantousha.TextValue

        If ReadMaster_担当者(param) = False Then
            MessageViewer.Show(41)
            Return False
        End If

        '-------------
        '  確定処理
        '-------------
        Dim returnValue As Boolean = True

        tantousha.DispNameText = CStr(_退避情報.担当者項目("CUSME04002"))
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.担当者コード) = tantousha.TextValue
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.担当者名) = tantousha.DispNameText
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.担当者マスター情報) = _退避情報.担当者.Copy

        bumon.TextValue = CStr(_退避情報.担当者項目("CUSME04005"))
        bumon.DispNameText = CStr(_退避情報.部門項目("CUSME05002"))
        '部門についてはセキュリティがあるため保持しない

        Return returnValue

    End Function

    Private Function DoCheckControlMoveOut_部門コード(ByVal args As CheckMethodArgs) As Boolean

        If Is省略判定(コード判定対象型.部門コード, bumon.TextValue) = 省略判定結果型.省略 Then
            MessageViewer.Show(72)
            Return False
        End If

        If Is等式判定(コード判定対象型.部門コード,
                      bumon.TextValue,
                      CStr(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.部門コード))) = 等式判定結果型.等しい Then
            Return True
        End If

        '部門マスターRead
        Dim param As New ReadParam
        param.Container(ReadParam.項目名型.部門コード) = bumon.TextValue

        If ReadMaster_部門(param) = False Then
            MessageViewer.Show(41)
            Return False
        End If

        '部門セキュリティチェック
        param.Container(ReadParam.項目名型.セキュリティ種別) = 0
        param.Container(ReadParam.項目名型.部門コード) = bumon.TextValue
        param.Container(ReadParam.項目名型.ログインID) = Me.システム環境情報.ログオンユーザー情報.ID

        If Check_セキュリティ(param) = False Then
            'MessageViewer.Show(1005, "OTS")        'D-CUST20240514 '-20240820
            MessageViewer.Show(999000004, "OTS")    'A-CUST20240514 '-20240820
            Return False
        End If

        '-------------
        '  確定処理
        '-------------
        Dim returnValue As Boolean = True

        bumon.DispNameText = CStr(_退避情報.部門項目("CUSME05002"))
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.部門コード) = bumon.TextValue
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.部門名) = bumon.DispNameText
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.部門マスター情報) = _退避情報.部門.Copy

        Return returnValue

    End Function

    'A-CUST20201013↓
    Private Function DoCheckControlMoveOut_納品先コード(ByVal args As CheckMethodArgs) As Boolean

        If Is省略判定(コード判定対象型.納品先コード, nohinsaki.TextValue) = 省略判定結果型.省略 Then
            nohinsaki.TextValue = ""
            nohinsaki.DispNameText = ""
            _退避情報.ClearDataTable納品先()
            _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.納品先コード) = "000000"
            _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.納品先名) = nohinsaki.DispNameText

            Return True
        End If

        If Is等式判定(コード判定対象型.納品先コード,
                      nohinsaki.TextValue,
                      CStr(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.納品先コード))) = 等式判定結果型.等しい Then
            Return True
        End If

        '納品先マスターRead
        Dim param As New ReadParam
        param.Container(ReadParam.項目名型.得意先コード) = TokuisakiCode.TextValue
        param.Container(ReadParam.項目名型.納品先コード) = nohinsaki.TextValue

        If ReadMaster_納品先(param) = False Then
            MessageViewer.Show(41)
            Return False
        End If

        '-------------
        '  確定処理
        '-------------
        Dim returnValue As Boolean = True

        Me.nohinsaki.DispNameText = CStr(_退避情報.納品先項目("CUSME37003"))
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.納品先コード) = Me.nohinsaki.TextValue
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.納品先名) = Me.nohinsaki.DispNameText
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.納品先マスター情報) = _退避情報.納品先.Copy
        Return returnValue

    End Function
    'A-CUST20201013↑

    Private Function DoCheckControlMoveOut_要件(ByVal args As CheckMethodArgs) As Boolean

        Dim returnValue As Boolean = True

        '-------------
        '  確定処理
        '-------------
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.要件) = youken.Text

        Return returnValue

    End Function

    Private Function DoCheckControlMoveOut_納期(ByVal args As CheckMethodArgs) As Boolean

        Dim returnValue As Boolean = True

        '-------------
        '  確定処理
        '-------------
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.納期) = nouki.Text

        Return returnValue

    End Function

    Private Function DoCheckControlMoveOut_支払方法(ByVal args As CheckMethodArgs) As Boolean

        Dim returnValue As Boolean = True

        '-------------
        '  確定処理
        '-------------
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.支払方法) = shiharaiHoho.Text

        Return returnValue

    End Function

    Private Function DoCheckControlMoveOut_有効期限(ByVal args As CheckMethodArgs) As Boolean

        Dim returnValue As Boolean = True

        '-------------
        '  確定処理
        '-------------
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.有効期限) = yuukoukigen.Text

        Return returnValue

    End Function

    Private Function DoCheckControlMoveOut_消費税コード(ByVal args As CheckMethodArgs) As Boolean

        Dim Shouhizei As String = Me.ShouhizeiCode.TextValue

        If Val(Shouhizei) = 0 Then
            MessageViewer.Show(72)
            Return False
        End If

        If Shouhizei = CStr(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.消費税コード)) Then
            Return True
        End If

        If DoCheck_消費税コード(Shouhizei, True) = False Then
            Return False
        End If

        If Footer_初期処理() = False Then
            Return False
        End If
        DisplayForm_合計部()

        Return True

    End Function

    Private Function DoCheck_消費税コード(ByVal Shouhizei As String, ByVal message As Boolean) As Boolean

        '区分マスターRead
        Dim param As New ReadParam
        param.Container(ReadParam.項目名型.種別) = Get区分マスター種別値(区分マスター型.消費税区分)
        param.Container(ReadParam.項目名型.区分コード) = Shouhizei

        If ReadMaster_区分マスター(param) = False Then
            If message = True Then
                MessageViewer.Show(41)
            End If
            Return False
        End If

        '-------------
        '  確定処理
        '-------------
        Me.ShouhizeiCode.DispNameText = CStr(_退避情報.消費税項目("CUSCE03003"))
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.消費税コード) = Me.ShouhizeiCode.TextValue
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.消費税名) = Me.ShouhizeiCode.DispNameText
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.消費税マスター情報) = _退避情報.消費税.Copy

        Return True
    End Function

    Private Function DoCheckControlMoveOut_備考名(ByVal args As CheckMethodArgs) As Boolean

        _退避情報.フッター部項目(退避情報型.フッター項目型.備考名) = biko.Text

        Return True

    End Function

#End Region

#Region "移動先チェック 個別コントロール"

    Private Function DoCheckControlMoveIn_処理連番(ByVal args As CheckMethodArgs) As Boolean

        If shori.Value = 処理区分型.登録 Then
            If args.移動元KeyDownCode = Keys.None Then
                Return False
            End If
            If args.移動方向 = CheckMethodArgs.移動方向型.後へ Then
                Return DoCheckControlMoveIn_ErrorFocusMove(args, denpyouDate)
            Else
                Return DoCheckControlMoveIn_ErrorFocusMove(args, shori)
            End If
        Else
            If _検索自動表示 = True Then
                DoCheck確定処理(args)
                If _検索種類 = 検索種類型.伝票検索 Then
                    伝票検索表示処理(shoriRenban.InputNumericalControl)
                End If
                If Is検索データ選択() = True Then

                    _検索後イベント = True
                    shoriRenban.Value = _kensakuRenban

                    Dim dummyArgs As CheckMethodArgs

                    dummyArgs = New CheckMethodArgs(shoriRenban.InputNumericalControl,
                                                    denpyouDate,
                                                    CheckMethodArgs.移動方向型.後へ,
                                                    Keys.Return, False, -1)
                    DoCheckControlMoveIn_ErrorFocusMove(args, dummyArgs)
                    If args.失敗時動作 = CheckMethodArgs.失敗時動作型.移動する Then
                        Return False
                    End If
                End If
            End If
        End If

        Return True

    End Function

    Private Function DoCheckControlMoveIn_伝票日付(ByVal args As CheckMethodArgs) As Boolean

        If CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード)) = 処理区分型.削除 Then
            execute.Enabled = True
            Return DoCheckControlMoveIn_ErrorFocusMove(args, execute, denpyouDate)
        End If

        If Jump指定行(args) = True Then
            Return False
        End If

        Return True

    End Function

    Private Function DoCheckControlMoveIn_税率(ByVal args As CheckMethodArgs) As Boolean

        If args.移動元KeyDownCode = Keys.None AndAlso _keyReturn = False Then
            'マウスクリック時は何もしない
            Return True

        End If

        If args.移動元TabKeyDown = False Then
            Dim nextControl As System.Windows.Forms.Control = Nothing
            Select Case args.移動元コントロール.Name
                Case _focusSwitcher.GetPrevControl(taxRate.ComboBoxControl).Name
                    '税率の直前コントロールから来た場合
                    nextControl = _focusSwitcher.GetNextControl(taxRate.ComboBoxControl)
                Case _focusSwitcher.GetNextControl(taxRate.ComboBoxControl).Name
                    '税率の直後コントロールから来た場合
                    nextControl = _focusSwitcher.GetPrevControl(taxRate.ComboBoxControl)
                Case Else
                    '以外のコントロールから来た場合は何もしない
                    Return True
            End Select
            Return DoCheckControlMoveIn_ErrorFocusMove(args, nextControl)
        End If

        Return True

    End Function

    'A-CUST20200311↓ '-20200616-001
    Private Function DoCheckControlMoveIn_得意先コード(ByVal args As CheckMethodArgs) As Boolean

        '受注（売上）計上済の場合入力不可
        If Is計上済() Then

            If args.移動元KeyDownCode = Keys.None AndAlso _keyReturn = False Then
                Return False
            End If

            Dim nextControl As System.Windows.Forms.Control = Nothing
            Select Case args.移動元コントロール.Name
                Case _focusSwitcher.GetPrevControl(TokuisakiCode.InputTextControl).Name,
                     _focusSwitcher.GetPrevControl(taxRate.ComboBoxControl).Name
                    '直前コントロールから来た場合
                    nextControl = tantousha.InputTextControl
                Case _focusSwitcher.GetNextControl(TokuisakiCode.InputTextControl).Name
                    '直後コントロールから来た場合
                    If args.移動元TabKeyDown = True Then
                        nextControl = taxRate.ComboBoxControl
                    Else
                        nextControl = _focusSwitcher.GetPrevControl(taxRate.ComboBoxControl)
                    End If
                Case Else
                    '以外のコントロールから来た場合は何もしない
                    Return False
            End Select
            Return DoCheckControlMoveIn_ErrorFocusMove(args, nextControl)

        End If

        Return True

    End Function
    'A-CUST20200311↑ '-20200616-001

    Private Function DoCheckControlMoveIn_GridView(ByVal args As CheckMethodArgs) As Boolean

        If args.移動元KeyDownCode = Keys.None AndAlso _keyReturn = False Then
            'マウスクリック時は何もしない
            Return True
        End If

        If CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード)) = 処理区分型.登録 Then
            Return DoCheckControlMoveIn_ErrorFocusMove(args, DetailGridEdit)
        End If

        DetailGridView.ChangeSelectedState(DetailGridView.ListIndex)

        Return True

    End Function

    'A-CUST20201013↓
    Private Function DoCheckControlMoveIn_納品先コード(ByVal args As CheckMethodArgs) As Boolean

        '得意先コード未入力又、画面値と退避値が違う場合は入力不可
        Dim 得意先コード As String = _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.得意先コード).ToString

        If Is省略判定(コード判定対象型.取引先コード, 得意先コード) = 省略判定結果型.省略 Then
            Return False
        End If

        If Is等式判定(コード判定対象型.取引先コード, TokuisakiCode.TextValue.TrimEnd, 得意先コード) = 等式判定結果型.異なる Then
            Return False
        End If

        Return True

    End Function
    'A-CUST20201013↑

#End Region

    Private Sub InitializeDataTableワーク(ByRef ワーク As DataTable)

        With ワーク.Columns
            .Clear()
            .Add(New DataColumn(UpdateParam.ワークテーブル項目型.CUSWE01001.ToString, GetType(String)))
            .Add(New DataColumn(UpdateParam.ワークテーブル項目型.CUSWE01002.ToString, GetType(Decimal)))
            .Add(New DataColumn(UpdateParam.ワークテーブル項目型.CUSWE01003.ToString, GetType(Decimal)))
            .Add(New DataColumn(UpdateParam.ワークテーブル項目型.CUSWE01004.ToString, GetType(Decimal)))
            .Add(New DataColumn(UpdateParam.ワークテーブル項目型.CUSWE01005.ToString, GetType(Decimal)))
            .Add(New DataColumn(UpdateParam.ワークテーブル項目型.CUSWE01006.ToString, GetType(String)))
            .Add(New DataColumn(UpdateParam.ワークテーブル項目型.CUSWE01007.ToString, GetType(Decimal)))
            .Add(New DataColumn(UpdateParam.ワークテーブル項目型.CUSWE01008.ToString, GetType(Decimal)))
            .Add(New DataColumn(UpdateParam.ワークテーブル項目型.CUSWE01009.ToString, GetType(Decimal)))
            .Add(New DataColumn(UpdateParam.ワークテーブル項目型.CUSWE01010.ToString, GetType(Decimal)))
            .Add(New DataColumn(UpdateParam.ワークテーブル項目型.CUSWE01993.ToString, GetType(String)))
            .Add(New DataColumn(UpdateParam.ワークテーブル項目型.CUSWE01994.ToString, GetType(String)))
            .Add(New DataColumn(UpdateParam.ワークテーブル項目型.CUSWE01995.ToString, GetType(Decimal)))
            .Add(New DataColumn(UpdateParam.ワークテーブル項目型.CUSWE01996.ToString, GetType(String)))
            'D-CUST20220425↓
            '.Add(New DataColumn(UpdateParam.ワークテーブル項目型.CUSWE01997.ToString, GetType(String)))
            '.Add(New DataColumn(UpdateParam.ワークテーブル項目型.CUSWE01998.ToString, GetType(Decimal)))
            'D-CUST20220425↑
            'A-CUST20220425↓
            .Add(New DataColumn(UpdateParam.ワークテーブル項目型.CUSWE01991.ToString, GetType(String)))
            .Add(New DataColumn(UpdateParam.ワークテーブル項目型.CUSWE01992.ToString, GetType(Decimal)))
            .Add(New DataColumn(UpdateParam.ワークテーブル項目型.CUSWE01INS.ToString, GetType(Decimal)))
            .Add(New DataColumn(UpdateParam.ワークテーブル項目型.CUSWE01UPD.ToString, GetType(Decimal)))      'A-CUST20241219
            'A-CUST20220425↑
            .Add(New DataColumn(UpdateParam.ワークテーブル項目型.CUSWE01999.ToString, GetType(Decimal)))


            'チェック用
            .Add(New DataColumn("CHECK001", GetType(String)))
            .Add(New DataColumn("CHECK002", GetType(String)))
            .Add(New DataColumn("CHECK003", GetType(String)))
            .Add(New DataColumn("CHECK004", GetType(String)))
            .Add(New DataColumn("CHECK005", GetType(String)))
        End With

    End Sub

    ''' <summary>
    ''' ドリルダウン 指定行ジャンプ処理
    ''' </summary>
    ''' <param name="args"></param>
    ''' <returns></returns>
    ''' <remarks>False：ジャンプ無／True：ジャンプ有</remarks>
    Private Function Jump指定行(ByVal args As CheckMethodArgs) As Boolean

        If _ドリルダウン = False Then
            Return False
        End If

        _ドリルダウン = False

        '受け取りパラメータに「行番号」が存在しない場合は、ジャンプしない
        If ParamInfo.Contains("GYONO") = False Then
            Return False
        End If

        '受け取りパラメータ「行番号=0」は、ジャンプしない
        If CInt(ParamInfo.Item("GYONO")) = 0 Then
            Return False
        End If

        '表示行の指定がある場合、指定行へ移動する
        DoCheckControlMoveIn_ErrorFocusMove(args, DetailGridEdit, args.移動先コントロール)

        Dim rowIndex As Integer = Get表示行From行ＤＢ値(CInt(ParamInfo.Item("GYONO")))
        Dim colName As String = 退避情報型.明細項目型.区分.ToString
        DetailGridEdit.SetCellEdit(rowIndex, colName)
        RepairFunctionBar(DetailGridEdit, colName)      'A-CUST20210906_10
        If rowIndex <> 0 Then
            DetailGridView.TopIndex = rowIndex - 1
        Else
            DetailGridView.TopIndex = rowIndex
        End If
        DetailGridView.ChangeSelectedState(rowIndex)
        Return True

    End Function

    Private Overloads Function DoCheckControlMoveIn_ErrorFocusMove(ByVal args As CheckMethodArgs,
                                                                   ByVal dummyArgs As CheckMethodArgs) As Boolean

        Dim nextControl As System.Windows.Forms.Control = Nothing
        Dim previousControl As System.Windows.Forms.Control = Nothing

        args.失敗時動作 = CheckMethodArgs.失敗時動作型.移動しない

        nextControl = dummyArgs.移動先コントロール
        If nextControl Is Nothing Then
            previousControl = args.移動先コントロール
        End If

        previousControl = dummyArgs.移動元コントロール
        If previousControl Is Nothing Then
            previousControl = args.移動元コントロール
        End If

        '移動先のチェック処理を実行させる
        Dim cloneArgs As CheckMethodArgs = New CheckMethodArgs(
                                                            previousControl,
                                                            nextControl,
                                                            dummyArgs.移動方向,
                                                            dummyArgs.移動元KeyDownCode,
                                                            dummyArgs.移動元KeyDownShift,
                                                            dummyArgs.移動先枝番)
        If CType(_focusSwitcher, FocusSwitch).DoFocusMove(cloneArgs) = False Then
            Return False
        End If
        args.失敗時動作 = cloneArgs.失敗時動作

        If nextControl.Name <> cloneArgs.移動先コントロール.Name Then
            args.移動先コントロール = cloneArgs.移動先コントロール
            If args.失敗時動作 = CheckMethodArgs.失敗時動作型.移動する Then
                Return False
            End If
            Return True
        End If

        If args.失敗時動作 = CheckMethodArgs.失敗時動作型.移動しない Then
            args.失敗時動作 = CheckMethodArgs.失敗時動作型.移動する
            args.移動先コントロール = nextControl
        End If

        Return False

    End Function

    Private Overloads Function DoCheckControlMoveIn_ErrorFocusMove(ByVal args As CheckMethodArgs,
                                        Optional ByVal nextControl As System.Windows.Forms.Control = Nothing,
                                        Optional ByVal previousControl As System.Windows.Forms.Control = Nothing) As Boolean

        args.失敗時動作 = CheckMethodArgs.失敗時動作型.移動しない

        If nextControl Is Nothing Then
            Return False
        End If

        If previousControl Is Nothing Then
            previousControl = args.移動元コントロール
        End If

        '移動先のチェック処理を実行させる
        Dim cloneArgs As CheckMethodArgs = New CheckMethodArgs(
                                                            previousControl,
                                                            nextControl,
                                                            args.移動方向,
                                                            args.移動元KeyDownCode,
                                                            args.移動元KeyDownShift,
                                                            args.移動元TabKeyDown,
                                                            args.移動先枝番)
        If CType(_focusSwitcher, FocusSwitch).DoFocusMove(cloneArgs) = False Then
            Return False
        End If
        args.失敗時動作 = cloneArgs.失敗時動作

        If nextControl.Name <> cloneArgs.移動先コントロール.Name Then
            args.移動先コントロール = cloneArgs.移動先コントロール
            If args.失敗時動作 = CheckMethodArgs.失敗時動作型.移動する Then
                Return False
            End If
            Return True
        End If

        If args.失敗時動作 = CheckMethodArgs.失敗時動作型.移動しない Then
            args.失敗時動作 = CheckMethodArgs.失敗時動作型.移動する
            args.移動先コントロール = nextControl
        End If

        Return False

    End Function

#Region "移動元チェック サブグループ"

    Private Function DoCheckSubGroupMoveOut_Group3(ByVal args As CheckMethodArgs) As Boolean

        Dim nextControl As System.Windows.Forms.Control = args.移動先コントロール

        If DoCheckControlMoveOut_伝票日付(args) = False Then
            args.移動先コントロール = denpyouDate
            GoTo Check_Err
        End If

        If DoCheckControlMoveOut_税率(args) = False Then
            args.移動先コントロール = denpyouDate
            GoTo Check_Err
        End If

        If DoCheckControlMoveOut_得意先コード(args) = False Then
            args.移動先コントロール = TokuisakiCode.InputTextControl
            GoTo Check_Err
        End If

        If DoCheckControlMoveOut_担当者コード(args) = False Then
            args.移動先コントロール = tantousha.InputTextControl
            GoTo Check_Err
        End If

        If DoCheckControlMoveOut_部門コード(args) = False Then
            args.移動先コントロール = bumon.InputTextControl
            GoTo Check_Err
        End If

        'A-CUST20201013↓
        If DoCheckControlMoveOut_納品先コード(args) = False Then
            args.移動先コントロール = nohinsaki.InputTextControl
            GoTo Check_Err
        End If
        'A-CUST20201013↑

        If DoCheckControlMoveOut_要件(args) = False Then
            args.移動先コントロール = youken
            GoTo Check_Err
        End If

        If DoCheckControlMoveOut_納期(args) = False Then
            args.移動先コントロール = nouki
            GoTo Check_Err
        End If

        If DoCheckControlMoveOut_支払方法(args) = False Then
            args.移動先コントロール = shiharaiHoho
            GoTo Check_Err
        End If

        If DoCheckControlMoveOut_有効期限(args) = False Then
            args.移動先コントロール = yuukoukigen
            GoTo Check_Err
        End If

        If DoCheckControlMoveOut_消費税コード(args) = False Then
            args.移動先コントロール = ShouhizeiCode.InputTextControl
            GoTo Check_Err
        End If

        Return True

Check_Err:

        If nextControl IsNot args.移動先コントロール Then
            args.失敗時動作 = CheckMethodArgs.失敗時動作型.移動する
        End If

        Return False

    End Function

#End Region

#Region "移動元チェック グループ"

    Private Function DoCheckGroupMoveOut_Group1(ByVal args As CheckMethodArgs) As Boolean

        _checkMode = CheckType.DoCheckGroup

        _退避情報.グループ状態(退避情報型.グループ型.No１) = 退避情報型.状態.正常

        Return True

    End Function

    Private Function DoCheckGroupMoveOut_Group2(ByVal args As CheckMethodArgs) As Boolean

        _checkMode = CheckType.DoCheckGroup

        _退避情報.グループ状態(退避情報型.グループ型.No２) = 退避情報型.状態.正常

        If args.移動先グループ番号 > 退避情報型.グループ型.No３ Then
            If DoCheckGroupMoveOut_Group3(args) = False Then
                Return False
            End If
        End If

        Return True

    End Function

    Private Function DoCheckGroupMoveOut_Group3(ByVal args As CheckMethodArgs) As Boolean

        Dim nextControl As System.Windows.Forms.Control = args.移動先コントロール

        _checkMode = CheckType.DoCheckGroup

        _退避情報.グループ状態(退避情報型.グループ型.No３) = 退避情報型.状態.エラー

        If DoCheckSubGroupMoveOut_Group3(args) = False Then
            GoTo Check_Err
        End If

Check_OK:
        _退避情報.グループ状態(退避情報型.グループ型.No３) = 退避情報型.状態.正常
        Return True

Check_Err:
        If nextControl IsNot args.移動先コントロール Then
            RepairFunctionBar(args.移動先コントロール)
            args.失敗時動作 = CheckMethodArgs.失敗時動作型.移動する
        End If

        _退避情報.グループ状態(退避情報型.グループ型.No３) = 退避情報型.状態.エラー
        Return False

    End Function

    Private Function DoCheckGroupMoveOut_Group4(ByVal args As CheckMethodArgs) As Boolean

        _checkMode = CheckType.DoCheckGroup

        _退避情報.グループ状態(退避情報型.グループ型.No４) = 退避情報型.状態.エラー

        _退避情報.グループ状態(退避情報型.グループ型.No４) = 退避情報型.状態.正常

        Return True

    End Function

    Private Function DoCheckGroupMoveOut_Group5(ByVal args As CheckMethodArgs) As Boolean

        Dim nextControl As System.Windows.Forms.Control = args.移動先コントロール

        _checkMode = CheckType.DoCheckGroup

        If DoCheckControlMoveOut_備考名(args) = False Then
            args.移動先コントロール = biko
            GoTo Check_Err
        End If

Check_OK:
        _退避情報.グループ状態(退避情報型.グループ型.No５) = 退避情報型.状態.正常
        Return True

Check_Err:
        If nextControl IsNot args.移動先コントロール Then
            RepairFunctionBar(args.移動先コントロール)
            args.失敗時動作 = CheckMethodArgs.失敗時動作型.移動する
        End If

        _退避情報.グループ状態(退避情報型.グループ型.No５) = 退避情報型.状態.エラー
        Return False

    End Function

    Private Function DoCheckGroupMoveOut_Group6(ByVal args As CheckMethodArgs) As Boolean

        _checkMode = CheckType.DoCheckGroup

        _退避情報.グループ状態(退避情報型.グループ型.No６) = 退避情報型.状態.正常

        Return True

    End Function

#End Region

#Region "移動先チェック グループ"

    Private Function DoCheckGroupMoveIn_Group1(ByVal args As CheckMethodArgs) As Boolean

        If TokuisakiCode.TextValue.TrimEnd <> "" Then
            If MessageViewer.Show(48, IMessageViewer.DefaultButtonType.No) = IMessageViewer.ShowResultType.No Then
                Return False
            End If
        End If

        Clear(クリア型.起動時のみ)

        Return True

    End Function

    Private Function DoCheckGroupMoveIn_Group2(ByVal args As CheckMethodArgs) As Boolean

        Return True

    End Function

    Private Function DoCheckGroupMoveIn_Group3(ByVal args As CheckMethodArgs) As Boolean
        If CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード)) = 処理区分型.削除 Then
            If Is伝票読込コントロール判断(args.移動先コントロール) = False Then
                Return False
            End If
        End If

        If _退避情報.グループ状態(退避情報型.グループ型.No１) = 退避情報型.状態.エラー Then
            Return False
        End If

        If _退避情報.グループ状態(退避情報型.グループ型.No２) = 退避情報型.状態.エラー Then
            Return False
        End If

        '登録時の初期表示（伝票検索画面から選択されたときは対象外）
        If Is検索データ選択() = False Then
            If CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード)) = 処理区分型.登録 Then
                If args.移動元コントロール.Name = shori.Name Then
                    If Header_初期表示(args, False) = False Then
                        Return False
                    End If
                End If
            End If
        End If

        Return True

    End Function

    Private Function DoCheckGroupMoveIn_Group4(ByVal args As CheckMethodArgs) As Boolean

        If _退避情報.グループ状態(退避情報型.グループ型.No１) = 退避情報型.状態.エラー Then
            Return False
        End If

        If _退避情報.グループ状態(退避情報型.グループ型.No２) = 退避情報型.状態.エラー Then
            Return False
        End If

        If _退避情報.グループ状態(退避情報型.グループ型.No３) = 退避情報型.状態.エラー Then
            Return False
        End If

        If args.移動先サブグループ番号 = 退避情報型.サブグループ型.No２ Then
            If DoCheckGroupSubGroupMoveIn_Group4(args) = False Then
                Return False
            End If
        End If

        Return True

    End Function

    Private Function DoCheckGroupMoveIn_Group5(ByVal args As CheckMethodArgs) As Boolean

        If _退避情報.グループ状態(退避情報型.グループ型.No１) = 退避情報型.状態.エラー Then
            GoTo Phase_Err
        End If

        If _退避情報.グループ状態(退避情報型.グループ型.No２) = 退避情報型.状態.エラー Then
            GoTo Phase_Err
        End If

        If _退避情報.グループ状態(退避情報型.グループ型.No３) = 退避情報型.状態.エラー Then
            GoTo Phase_Err
        End If

        _退避情報.グループ状態(退避情報型.グループ型.No４) = 退避情報型.状態.エラー

        _退避情報.グループ状態(退避情報型.グループ型.No４) = 退避情報型.状態.正常

        Return True

Phase_Err:
        If args.移動元コントロール.Name = DetailGridEdit.Name Then
            DetailGridEdit.SetCellEdit(_fromCell.RowIndex, _fromCell.ColIndex)
        End If

        Return False

    End Function

    Private Function DoCheckGroupMoveIn_Group6(ByVal args As CheckMethodArgs) As Boolean

        If _退避情報.グループ状態(退避情報型.グループ型.No１) = 退避情報型.状態.エラー Then
            Return False
        End If

        If _退避情報.グループ状態(退避情報型.グループ型.No２) = 退避情報型.状態.エラー Then
            Return False
        End If

        If _退避情報.グループ状態(退避情報型.グループ型.No３) = 退避情報型.状態.エラー Then
            Return False
        End If

        If _退避情報.グループ状態(退避情報型.グループ型.No４) = 退避情報型.状態.エラー Then
            Return False
        End If

        If _退避情報.グループ状態(退避情報型.グループ型.No５) = 退避情報型.状態.エラー Then
            Return False
        End If

        Return True

    End Function

#End Region

#Region "移動先チェック サブグループ"

    Private Function DoCheckGroupSubGroupMoveIn_Group4(ByVal args As CheckMethodArgs) As Boolean

        If DetailGridEdit.EditRowIndex <> -1 AndAlso DetailGridEdit.EditColIndex <> -1 Then
            SaveGridEditIndex(DetailGridEdit, DetailGridEdit.EditRowIndex, DetailGridEdit.EditColIndex, DetailGridEdit.EditRowIndex, DetailGridEdit.EditColIndex)
            Dim errorRowIndex As Integer = DetailGridEdit.EditRowIndex
            If Grid_DoCheckLineMoveIn(errorRowIndex) = False Then
                args.失敗時動作 = CheckMethodArgs.失敗時動作型.移動する
                args.移動先コントロール = DetailGridEdit
                _focusSwitcher.CurrentControl = DetailGridEdit
                DetailGridEdit.SetCellEdit(errorRowIndex, GetDetailTopColumnName)
                DoCheck確定処理(args)
                Return False
            End If
            If Grid_DoCheckCellMoveIn() = False Then
                Return False
            End If
        End If

        Return True

    End Function

#End Region

    Private Function DoCheck前処理(ByVal args As CheckMethodArgs) As Boolean

        _checkMode = CheckType.DoCheckControl

        If _keyReturn = True Then
            Select Case args.移動元KeyDownCode
                Case Keys.None, Keys.F5
                    args.移動元KeyDownCode = System.Windows.Forms.Keys.Return
            End Select
        End If
        _keyReturn = False

        DoCheck前処理_KeyDown(args)

        Return True

    End Function

    Private Function DoCheck前処理_KeyDown(ByVal args As CheckMethodArgs) As Boolean

        If args.移動元TabKeyDown = True Then
            Return True
        End If

        Dim nextControl As Control = Nothing

        Select Case args.移動元KeyDownCode
            Case Keys.Up
                Select Case args.移動元コントロール.Name
                    Case execute.Name
                        '伝票検索のフラグ変更
                        If CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード)) = 処理区分型.削除 Then
                            If Is検索データ選択() = True Then
                                _検索自動表示 = True
                            End If
                            nextControl = shoriRenban.InputNumericalControl
                        End If
                End Select

            Case Keys.Return, Keys.Down

        End Select

        If nextControl IsNot Nothing Then
            args.移動先コントロール = nextControl
            Return False
        End If

        Return True

    End Function

    Private Sub DoCheck確定処理(ByVal args As CheckMethodArgs)

        If args.移動先グループ番号 = 退避情報型.グループ型.No１ Then
            shoriModeLabel.Visible = False
            If _退避情報.起動モード <> 起動モード型.詳細モード Then
                RowStatelbl.Visible = True
                Kakutei.Visible = True
            End If
        Else
            If _退避情報.起動モード <> 起動モード型.詳細モード Then
                shoriModeLabel.Visible = True
            End If
            Select Case CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード))
                Case 処理区分型.登録
                    shoriModeLabel.Text = "新規伝票"
                    shoriModeLabel.BackColor = Drawing.Color.GreenYellow
                    If _退避情報.起動モード <> 起動モード型.詳細モード Then
                        RowStatelbl.Visible = True
                        Kakutei.Visible = True
                    End If
                Case 処理区分型.修正
                    shoriModeLabel.Text = "伝票修正"
                    shoriModeLabel.BackColor = Drawing.Color.Yellow
                    If _退避情報.起動モード <> 起動モード型.詳細モード Then
                        RowStatelbl.Visible = True
                        Kakutei.Visible = True
                    End If
                Case 処理区分型.削除
                    shoriModeLabel.Text = "伝票削除"
                    shoriModeLabel.BackColor = Drawing.Color.Red
                    RowStatelbl.Visible = False
                    Kakutei.Visible = False
            End Select
        End If

        If args.移動先グループ番号 < 退避情報型.グループ型.No５ Then
            execute.Enabled = False
            If CType(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード), 処理区分型) = 処理区分型.削除 And
               args.移動先グループ番号 > 退避情報型.グループ型.No２ Then
                execute.Enabled = True
            End If
        Else
            execute.Enabled = True
        End If

        If args.移動先コントロール.Name = shoriRenban.Name Then
            display.Enabled = True
        Else
            display.Enabled = False
        End If

        Select Case args.移動先グループ番号
            Case 退避情報型.グループ型.No１, 退避情報型.グループ型.No２
                SetReadOnly_確定処理(False)
                If CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード)) = 処理区分型.削除 Then
                    args.移動先コントロール.Focus()
                End If

            Case 退避情報型.グループ型.No３
                If args.移動元グループ番号 < 退避情報型.グループ型.No３ Then
                    args.移動先コントロール.Focus()
                End If

            Case 退避情報型.グループ型.No６
                If CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード)) = 処理区分型.削除 And
                   args.移動元グループ番号 <> 退避情報型.グループ型.No４ Then
                    SetReadOnly_確定処理(True)
                End If
        End Select

        Select Case args.移動先コントロール.Name
            Case shori.Name
                _saveRenban = 0

            Case DetailGridEdit.Name
                Dim rowIndex As Integer = DetailGridEdit.EditRowIndex
                If rowIndex = -1 OrElse args.移動元KeyDownCode <> Keys.None Then
                    If args.移動元コントロール.TabIndex < DetailGridEdit.TabIndex Then
                        rowIndex = DetailGridEdit.TopIndex
                    Else
                        rowIndex = DetailGridEdit.RowCount - 1
                    End If
                End If

                Dim colName As String = DetailGridEdit.EditColName
                If colName = "" OrElse args.移動元KeyDownCode <> Keys.None Then
                    colName = 退避情報型.明細項目型.区分.ToString
                End If

                DetailGridEdit.SetCellEdit(rowIndex, colName)
        End Select

        'ファンクション再構築
        Select Case args.移動先コントロール.Name
            Case DetailGridEdit.Name
                RepairFunctionBar(DetailGridEdit, DetailGridEdit.EditColName)
                Detail_現在庫取得(DetailGridEdit.EditRowIndex, DetailGridEdit.EditColName)
            Case Else
                RepairFunctionBar(args.移動先コントロール)
                Detail_現在庫表示(-1, "")
        End Select

        _keyReturn = False

        If Not _確定押下時チェック中 Then         'A-CUST20200311 '-20200609
            StatusBar.StatusLabelControl.Text = ""
        End If                                    'A-CUST20200311 '-20200609

        'ステータスバー表示
        Select Case args.移動先コントロール.Name
            Case DetailGridEdit.Name
                Display_StatusBar(DetailGridEdit.EditRowIndex, DetailGridEdit.EditColName)
            Case Else
                Display_StatusBar(args.移動先コントロール)
        End Select

        'メニューバー「伝票発行」の設定
        If args.移動先コントロール.TabIndex <= denpyouDate.TabIndex Then
            Me.MenuBar.Items.Item("printMenu").Enabled = True
        Else
            Me.MenuBar.Items.Item("printMenu").Enabled = False
        End If

    End Sub

#Region "EditForm"

    Private Function EditForm_見積() As Boolean

        _退避情報.ClearDataTableヘッダー部(退避情報型.グループ型.No２)
        _退避情報.ClearDataTableヘッダー部(退避情報型.グループ型.No３)
        _退避情報.明細表示部.Clear()
        _退避情報.ClearDataTableフッター部()

        For Each groupNo As 退避情報型.グループ型 In [Enum].GetValues(GetType(退避情報型.グループ型))
            _退避情報.グループ状態(groupNo) = 退避情報型.状態.正常
        Next

        _maxRowCount = 0
        _limitMaxRow = _defaultMaxRow

        If CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード)) <> 処理区分型.登録 Then
            _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.伝票日付) = _退避情報.見積ヘッダー項目("CUSRE11002")
            _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.伝票日付チェックフラグ) = True
        End If

        If Is呼出元売上税率採用() = True Then
            _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.税率) = _退避情報.見積ヘッダー項目("CUSRE11003")
            _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.税率番号) = SetTaxRateCombobox(CDec(_退避情報.見積ヘッダー項目("CUSRE11003")))
        End If

        '得意先
        Dim torihikisaki As String = CStr(_退避情報.見積ヘッダー項目("CUSRE11004"))
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.得意先コード) = torihikisaki
        _退避情報.得意先 = CType(_退避情報.見積ヘッダー項目("CUSME01DT"), DataTable)
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.得意先名１) = _退避情報.得意先項目("CUSME01002")
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.得意先名２) = _退避情報.得意先項目("CUSME01003")
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.得意先マスター情報) = _退避情報.得意先.Copy

        '担当者
        _退避情報.担当者 = CType(_退避情報.見積ヘッダー項目("CUSME04DT"), DataTable)
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.担当者コード) = _退避情報.見積ヘッダー項目("CUSRE11007")
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.担当者名) = _退避情報.担当者項目("CUSME04002")
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.担当者マスター情報) = _退避情報.担当者.Copy

        '部門
        _退避情報.部門 = CType(_退避情報.見積ヘッダー項目("CUSME05DT"), DataTable)
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.部門コード) = _退避情報.見積ヘッダー項目("CUSRE11008")
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.部門名) = _退避情報.部門項目("CUSME05002")
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.部門マスター情報) = _退避情報.部門.Copy

        'A-CUST20201013↓
        '納品先
        _退避情報.納品先 = CType(_退避情報.見積ヘッダー項目("CUSME37DT"), DataTable)
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.納品先コード) = _退避情報.見積ヘッダー項目("CUSRE11024")
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.納品先名) = _退避情報.納品先項目("CUSME37003")
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.納品先マスター情報) = _退避情報.納品先.Copy
        'A-CUST20201013↑

        '要件
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.要件) = _退避情報.見積ヘッダー項目("CUSRE11012")

        '納期
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.納期) = _退避情報.見積ヘッダー項目("CUSRE11009")

        '支払方法
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.支払方法) = _退避情報.見積ヘッダー項目("CUSRE11010")

        '有効期限
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.有効期限) = _退避情報.見積ヘッダー項目("CUSRE11011")

        '消費税
        _退避情報.消費税 = CType(_退避情報.見積ヘッダー項目("CUSCE03SDT"), DataTable)
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.消費税コード) = _退避情報.見積ヘッダー項目("CUSRE11013")
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.消費税名) = _退避情報.消費税項目("CUSCE03003")
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.消費税マスター情報) = _退避情報.消費税.Copy

        'A-CUST20251104↓
        Dim dtFieldBuilder As New DataTable()

        ' 列を追加（K001～K030）
        For i As Integer = 1 To EXPANDITEMCOUNT
            dtFieldBuilder.Columns.Add("CUSRE11K" & i.ToString("D3"), GetType(String))
        Next

        ' 1行追加
        Dim dr As DataRow = dtFieldBuilder.NewRow()
        For i As Integer = 1 To EXPANDITEMCOUNT
            dr("CUSRE11K" & i.ToString("D3")) = _退避情報.見積ヘッダー項目("CUSRE11K" & i.ToString("D3"))
        Next
        dtFieldBuilder.Rows.Add(dr)

        ' プロパティに退避
        _退避情報.FieldBuilderヘッダー = dtFieldBuilder
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.FieldBuilder) = dtFieldBuilder
        'A-CUST20251104↑

        '--------------------
        '   明細部
        '--------------------
        For rowIndex As Integer = 0 To _退避情報.見積明細.Rows.Count - 1
            '明細項目編集
            EditForm_見積_明細(rowIndex)

            '各金額計算＆集計
            If Detail_各金額集計(rowIndex, 明細種類型.表示部) = False Then
                Return False
            End If

            _maxRowCount = rowIndex + 1
        Next

        If Detail_消費税計算() = False Then
            Return False
        End If

        If _maxRowCount > _limitMaxRow Then
            _limitMaxRow = _maxRowCount
        End If
        Set入力行数(False)

        '--------------------
        '   フッター部
        '--------------------
        '備考
        _退避情報.フッター部項目(退避情報型.フッター項目型.備考名) = CStr(_退避情報.見積ヘッダー項目("CUSRE11014"))

        Return True

    End Function

    Private Sub EditForm_見積_明細(ByVal rowIndex As Integer)

        Dim newRow As DataRow = _退避情報.CreateNewRow明細(False, rowIndex)
        _退避情報.明細表示部.Rows.Add(newRow)

        '行番号
        _退避情報.明細表示部項目(rowIndex, 退避情報型.明細項目型.行ＤＢ値) = _退避情報.見積明細項目(rowIndex, "CUSRE12003")

        '行区分
        _退避情報.明細表示部項目(rowIndex, 退避情報型.明細項目型.区分) = _退避情報.見積明細項目(rowIndex, "CUSRE12005")
        '_退避情報.区分 = CType(_退避情報.見積明細項目(rowIndex, "CUSCE03GDT"), DataTable)                      'D-CUST20200311 '-2020527-001
        '_退避情報.明細表示部項目(rowIndex, 退避情報型.明細項目型.区分名) = _退避情報.区分項目("CUSCE03004")    'D-CUST20200311 '-2020527-001
        'A-CUST20200311↓ '-2020527-001
        _退避情報.行区分 = CType(_退避情報.見積明細項目(rowIndex, "CUSCE03GDT"), DataTable)
        _退避情報.明細表示部項目(rowIndex, 退避情報型.明細項目型.区分名) = _退避情報.行区分項目("CUSCE03004")
        'マスター情報退避
        _退避情報.明細表示部項目(rowIndex, 退避情報型.明細項目型.行区分マスター情報) = _退避情報.行区分
        'A-CUST20200311↑ '-2020527-001

        '商品コード／名
        Dim shouhinCode As String = CStr(_退避情報.見積明細項目(rowIndex, "CUSRE12006"))
        _退避情報.明細表示部項目(rowIndex, 退避情報型.明細項目型.商品コード) = shouhinCode
        _退避情報.明細表示部項目(rowIndex, 退避情報型.明細項目型.商品名) = CStr(_退避情報.見積明細項目(rowIndex, "CUSRE12007"))
        _退避情報.明細表示部項目(rowIndex, 退避情報型.明細項目型.商品マスター情報) = CType(_退避情報.見積明細項目(rowIndex, "CUSME03DT"), DataTable).Copy
        _退避情報.商品 = CType(_退避情報.見積明細項目(rowIndex, "CUSME03DT"), DataTable).Copy
        If shouhinCode = _退避情報.手入力_商品コード Then
            _退避情報.明細表示部項目(rowIndex, 退避情報型.明細項目型.商品コード手入力) = True
        End If

        '課税区分
        _退避情報.明細表示部項目(rowIndex, 退避情報型.明細項目型.課税区分) = _退避情報.見積明細項目(rowIndex, "CUSRE12014")
        _退避情報.課税区分 = CType(_退避情報.見積明細項目(rowIndex, "CUSCE03KDT"), DataTable)
        _退避情報.明細表示部項目(rowIndex, 退避情報型.明細項目型.課税区分名) = _退避情報.課税区分項目("CUSCE03003")
        'マスター情報退避
        _退避情報.明細表示部項目(rowIndex, 退避情報型.明細項目型.課税区分マスター情報) = _退避情報.課税区分

        '倉庫コード／名
        _退避情報.倉庫 = CType(_退避情報.見積明細項目(rowIndex, "CUSME06DT"), DataTable)
        _退避情報.明細表示部項目(rowIndex, 退避情報型.明細項目型.倉庫コード) = _退避情報.見積明細項目(rowIndex, "CUSRE12013")
        _退避情報.明細表示部項目(rowIndex, 退避情報型.明細項目型.倉庫名) = _退避情報.倉庫項目("CUSME06003")
        'マスター情報退避
        _退避情報.明細表示部項目(rowIndex, 退避情報型.明細項目型.倉庫マスター情報) = _退避情報.倉庫

        '原単価
        _退避情報.明細表示部項目(rowIndex, 退避情報型.明細項目型.原単価) = CDec(_退避情報.見積明細項目(rowIndex, "CUSRE12020"))

        '原価金額
        _退避情報.明細表示部項目(rowIndex, 退避情報型.明細項目型.原価金額) = CDec(_退避情報.見積明細項目(rowIndex, "CUSRE12021"))

        '単位
        _退避情報.明細表示部項目(rowIndex, 退避情報型.明細項目型.単位) = CStr(_退避情報.見積明細項目(rowIndex, "CUSRE12008"))

        '数量
        _退避情報.明細表示部項目(rowIndex, 退避情報型.明細項目型.数量) = CDec(_退避情報.見積明細項目(rowIndex, "CUSRE12009"))

        '単価
        _退避情報.明細表示部項目(rowIndex, 退避情報型.明細項目型.単価) = CDec(_退避情報.見積明細項目(rowIndex, "CUSRE12010"))

        '金額
        _退避情報.明細表示部項目(rowIndex, 退避情報型.明細項目型.金額) = CDec(_退避情報.見積明細項目(rowIndex, "CUSRE12011"))

        '行摘要
        _退避情報.明細表示部項目(rowIndex, 退避情報型.明細項目型.行摘要) = CStr(_退避情報.見積明細項目(rowIndex, "CUSRE12012"))

        '小計
        _退避情報.明細表示部項目(rowIndex, 退避情報型.明細項目型.小計) = CType(_退避情報.見積明細項目(rowIndex, "CUSRE12023"), CheckState)

        '改頁
        _退避情報.明細表示部項目(rowIndex, 退避情報型.明細項目型.改頁) = CType(_退避情報.見積明細項目(rowIndex, "CUSRE12024"), CheckState)

        'A-CUST20211001↓
        '単価計算方法
        _退避情報.明細表示部項目(rowIndex, 退避情報型.明細項目型.単価計算方法) = CInt(_退避情報.見積明細項目(rowIndex, "CUSRE12027"))
        'A-CUST20211001↑

        'A-CUST20241219↓
        '--------------------
        '   サブ明細部
        '--------------------
        'サブ明細項目編集
        EditForm_見積_サブ明細(rowIndex)
        'A-CUST20241219↑

        'A-CUST20251104↓
        Dim dtFieldBuilder As New DataTable()

        ' 列を追加（K001～K030）
        For i As Integer = 1 To EXPANDITEMCOUNT
            dtFieldBuilder.Columns.Add("CUSRE12K" & i.ToString("D3"), GetType(String))
        Next

        ' 1行追加
        Dim dr As DataRow = dtFieldBuilder.NewRow()
        For i As Integer = 1 To EXPANDITEMCOUNT
            dr("CUSRE12K" & i.ToString("D3")) = _退避情報.見積明細項目(rowIndex, "CUSRE12K" & i.ToString("D3"))
        Next
        dtFieldBuilder.Rows.Add(dr)

        ' プロパティに退避
        _退避情報.明細入力部項目(退避情報型.明細項目型.ラベル1_02) = ""
        _退避情報.FieldBuilder明細 = dtFieldBuilder
        _退避情報.明細表示部項目(rowIndex, 退避情報型.明細項目型.FieldBuilder) = dtFieldBuilder
        _退避情報.明細入力部項目(退避情報型.明細項目型.FieldBuilder) = dtFieldBuilder

        'A-CUST20251104↑


    End Sub

    'A-CUST20241219↓
    ''' <summary>
    ''' 退避情報への編集処理（見積伝票：サブ明細）
    ''' </summary>
    ''' <param name="rowIndex"></param>
    ''' <remarks></remarks>
    Private Sub EditForm_見積_サブ明細(ByVal rowIndex As Integer)

        _退避情報.サブ明細情報.Clear()
        _退避情報.見積サブ明細.Clear()

        _退避情報.見積サブ明細 = CType(_退避情報.見積明細項目(rowIndex, "CUSRE29DT"), DataTable).Copy

        For サブIndex As Integer = 0 To _退避情報.見積サブ明細.Rows.Count - 1

            Dim newRow As DataRow = _退避情報.CreateNewRowサブ明細(退避情報型.GridType.info, サブIndex)
            _退避情報.サブ明細情報.Rows.Add(newRow)

            'サブ明細情報を退避
            '行番号
            _退避情報.サブ明細情報項目(サブIndex, 退避情報型.サブ明細項目型.行ＤＢ値) = _退避情報.見積サブ明細項目(サブIndex, "CUSRE29003")
            _退避情報.サブ明細情報項目(サブIndex, 退避情報型.サブ明細項目型.行確定済) = True

            '商品コード／名
            Dim shouhinCode As String = CStr(_退避情報.見積サブ明細項目(サブIndex, "CUSRE29004"))
            _退避情報.サブ明細情報項目(サブIndex, 退避情報型.サブ明細項目型.商品コード) = shouhinCode
            _退避情報.サブ明細情報項目(サブIndex, 退避情報型.サブ明細項目型.商品名) = CStr(_退避情報.見積サブ明細項目(サブIndex, "CUSRE29005"))
            _退避情報.サブ明細情報項目(サブIndex, 退避情報型.サブ明細項目型.商品マスター情報) = CType(_退避情報.見積サブ明細項目(サブIndex, "CUSME03DT"), DataTable).Copy
            _退避情報.商品 = CType(_退避情報.見積サブ明細項目(サブIndex, "CUSME03DT"), DataTable).Copy
            If shouhinCode = _退避情報.手入力_商品コード Then
                _退避情報.サブ明細情報項目(サブIndex, 退避情報型.サブ明細項目型.商品コード手入力) = True
            End If


            '単位
            _退避情報.サブ明細情報項目(サブIndex, 退避情報型.サブ明細項目型.単位) = CStr(_退避情報.見積サブ明細項目(サブIndex, "CUSRE29006"))

            '数量
            _退避情報.サブ明細情報項目(サブIndex, 退避情報型.サブ明細項目型.数量) = CDec(_退避情報.見積サブ明細項目(サブIndex, "CUSRE29007"))

            '単価
            _退避情報.サブ明細情報項目(サブIndex, 退避情報型.サブ明細項目型.単価) = CDec(_退避情報.見積サブ明細項目(サブIndex, "CUSRE29008"))

            '金額
            _退避情報.サブ明細情報項目(サブIndex, 退避情報型.サブ明細項目型.金額) = CDec(_退避情報.見積サブ明細項目(サブIndex, "CUSRE29009"))

        Next


Phase_End:
        If _退避情報.サブ明細情報.Rows.Count = 0 Then
            Dim newRow As DataRow = _退避情報.CreateNewRowサブ明細(退避情報型.GridType.info, 0)
            _退避情報.サブ明細情報.Rows.Add(newRow)
        End If

        '明細情報に退避
        _退避情報.明細表示部項目(rowIndex, 退避情報型.明細項目型.サブ明細情報) = _退避情報.サブ明細情報.Copy

        'サブ明細区分(ラベル1_01)
        Dim hasサブ明細区分 As Boolean = False
        For idx As Integer = 0 To _退避情報.サブ明細情報.Rows.Count - 1
            If CBool(_退避情報.サブ明細情報項目(idx, 退避情報型.サブ明細項目型.行確定済)) = True Then
                hasサブ明細区分 = True
                Exit For
            End If
        Next
        If hasサブ明細区分 = True Then
            _退避情報.明細表示部項目(rowIndex, 退避情報型.明細項目型.ラベル1_01) = "サブ明細有り"
        Else
            _退避情報.明細表示部項目(rowIndex, 退避情報型.明細項目型.ラベル1_01) = ""
        End If

    End Sub
    'A-CUST20241219↑

    ''' <summary>
    ''' フッター部初期処理
    ''' </summary>
    ''' <param name="exceptRowCalc">指定行の計算を行うか</param>
    ''' <param name="exceptRow">計算対象外の行</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function Footer_初期処理(Optional exceptRowCalc As Boolean = True, Optional ByVal exceptRow As Integer = -1) As Boolean

        _退避情報.フッター部項目(退避情報型.フッター項目型.対象金額) = 0
        _退避情報.フッター部項目(退避情報型.フッター項目型.消費税額) = 0
        _退避情報.フッター部項目(退避情報型.フッター項目型.合計金額) = 0
        _退避情報.フッター部項目(退避情報型.フッター項目型.消費税用_税抜_金額合計) = 0
        _退避情報.フッター部項目(退避情報型.フッター項目型.消費税用_税込_分解消費税計) = 0
        _退避情報.フッター部項目(退避情報型.フッター項目型.粗利額合計) = 0
        _退避情報.フッター部項目(退避情報型.フッター項目型.粗利率) = 0
        _退避情報.フッター部項目(退避情報型.フッター項目型.粗利用_税抜_金額合計) = 0
        _退避情報.フッター部項目(退避情報型.フッター項目型.更新用_非課税額) = 0

        '指定行を除いた額を算出する
        For I As Integer = 0 To _maxRowCount - 1
            '各金額計算＆集計
            If I <> exceptRow Then
                Dim 数量 As Decimal = CDec(_退避情報.明細表示部項目(I, 退避情報型.明細項目型.数量))
                Dim 単価 As Decimal = CDec(_退避情報.明細表示部項目(I, 退避情報型.明細項目型.単価))
                Dim 原単価 As Decimal = CDec(_退避情報.明細表示部項目(I, 退避情報型.明細項目型.原単価))

                If Detail_原価金額取得(I, 数量, 原単価, 明細種類型.表示部) = False Then
                    Return False
                End If

                If Detail_売上金額取得(I, 数量, 単価, 明細種類型.表示部) = False Then
                    Return False
                End If

                If Detail_各金額集計(I, 明細種類型.表示部) = False Then
                    Return False
                End If

            End If
        Next

        If exceptRowCalc = True And exceptRow <> -1 Then
            '指定行を加算する
            Dim 数量 As Decimal = CDec(_退避情報.明細入力部項目(退避情報型.明細項目型.数量))
            Dim 単価 As Decimal = CDec(_退避情報.明細入力部項目(退避情報型.明細項目型.単価))
            Dim 原単価 As Decimal = CDec(_退避情報.明細入力部項目(退避情報型.明細項目型.原単価))

            If Detail_原価金額取得(exceptRow, 数量, 原単価, 明細種類型.入力部) = False Then
                Return False
            End If

            If Detail_売上金額取得(exceptRow, 数量, 単価, 明細種類型.入力部) = False Then
                Return False
            End If

            If Detail_各金額集計(exceptRow, 明細種類型.入力部) = False Then
                Return False
            End If

        End If

        If Detail_消費税計算() = False Then
            Return False
        End If


        Return True

    End Function

#End Region

#Region "DisplayForm"

    Private Sub DisplayForm()

        DisplayForm_ヘッダー部()
        DisplayForm_明細部()
        DisplayForm_フッター部()

    End Sub

    ''' <summary>
    ''' ヘッダー部の表示
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub DisplayForm_ヘッダー部()

        If CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード)) <> 処理区分型.登録 Then
            denpyouDate.Date = CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.伝票日付))
        End If

        TokuisakiCode.TextValue = CStr(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.得意先コード))
        TokuisakiName1.Text = CStr(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.得意先名１))
        TokuisakiName2.Text = CStr(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.得意先名２))

        tantousha.TextValue = CStr(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.担当者コード))
        tantousha.DispNameText = CStr(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.担当者名))

        bumon.TextValue = CStr(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.部門コード))
        bumon.DispNameText = CStr(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.部門名))

        'A-CUST20201013↓
        nohinsaki.TextValue = CStr(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.納品先コード))
        nohinsaki.DispNameText = CStr(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.納品先名))
        'A-CUST20201013↑

        youken.Text = CStr(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.要件))

        nouki.Text = CStr(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.納期))

        shiharaiHoho.Text = CStr(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.支払方法))

        yuukoukigen.Text = CStr(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.有効期限))

        ShouhizeiCode.TextValue = CStr(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.消費税コード))
        ShouhizeiCode.DispNameText = CStr(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.消費税名))

    End Sub

    ''' <summary>
    ''' 明細部の表示
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub DisplayForm_明細部(Optional ByVal displayRow As Integer = -1)

        DetailGridEdit.Redraw = False
        DetailGridView.Redraw = False

        Dim fromIndex As Integer
        Dim toIndex As Integer

        If displayRow = -1 Then
            DetailGridView.RowCount = 0
            DetailGridView.DataTable = _退避情報.明細表示部.Copy
            fromIndex = 0
            toIndex = DetailGridEdit.Rows.Count - 1
        Else
            DetailGridView.DataTable = _退避情報.明細表示部.Copy
            fromIndex = displayRow
            toIndex = displayRow
        End If

        For row As Integer = fromIndex To toIndex

            '個別の記載

        Next

        If CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード)) = 処理区分型.削除 Then
            _limitMaxRow = _maxRowCount
        End If

        SetNewGridRow(True)

        DetailGridEdit.Redraw = True
        DetailGridView.Redraw = True

    End Sub

    ''' <summary>
    ''' フッター部の表示
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub DisplayForm_フッター部()

        Me.biko.Text = CStr(_退避情報.フッター部項目(退避情報型.フッター項目型.備考名))

        DisplayForm_合計部()

    End Sub

    ''' <summary>
    ''' 合計部の表示
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub DisplayForm_合計部()

        TotalArari.Value = CDec(_退避情報.フッター部項目(退避情報型.フッター項目型.粗利額合計))
        ArariRitu.Value = CDec(_退避情報.フッター部項目(退避情報型.フッター項目型.粗利率))

        If Is消費税計算() <> 消費税計算区分型.請求単位 Then
            TaisyoKingaku.Value = CDec(_退避情報.フッター部項目(退避情報型.フッター項目型.対象金額))
            Syouhizeigaku.Value = CDec(_退避情報.フッター部項目(退避情報型.フッター項目型.消費税額))
        Else
            TaisyoKingaku.Value = 0
            Syouhizeigaku.Value = 0
        End If
        totalKingaku.Value = CDec(_退避情報.フッター部項目(退避情報型.フッター項目型.合計金額))

    End Sub

#End Region

    Private Sub Header_クリア()

        '得意先コード/名
        TokuisakiCode.TextValue = ""
        TokuisakiName1.Text = ""
        TokuisakiName2.Text = ""

        '担当者コード/名
        tantousha.TextValue = ""
        tantousha.DispNameText = ""

        '部門コード/名
        bumon.TextValue = ""
        bumon.DispNameText = ""

        'A-CUST20201013↓
        '納品先コード/名
        nohinsaki.TextValue = ""
        nohinsaki.DispNameText = ""
        'A-CUST20201013↑

        '要件
        youken.Text = ""

        '納期
        nouki.Text = ""

        '支払方法
        shiharaiHoho.Text = ""

        '有効期限
        yuukoukigen.Text = ""

        '消費税コード/名
        ShouhizeiCode.TextValue = ""
        ShouhizeiCode.DispNameText = ""

        _退避情報.ClearDataTableヘッダー部(退避情報型.グループ型.No２)
        _退避情報.ClearDataTableヘッダー部(退避情報型.グループ型.No３)
        _退避情報.ClearDataTable得意先()
        _退避情報.ClearDataTable担当者()
        _退避情報.ClearDataTable部門()
        _退避情報.ClearDataTable納品先()       'A-CUST20201013
        _退避情報.ClearDataTable消費税()
        _退避情報.ClearDataTableFieldBuilderヘッダー()  'A-CUST20251104

    End Sub

    ''' <summary>
    ''' ヘッダー部 初期表示
    ''' </summary>
    ''' <param name="keepDate"></param>
    ''' <remarks></remarks>
    Private Function Header_初期表示(ByVal args As CheckMethodArgs,
                                     ByVal keepDate As Boolean) As Boolean

        '番号表示
        shoriRenban.Value = CLng(_退避情報.連番管理項目("CUSCE21008"))
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理連番) = shoriRenban.Value

        '伝票日付
        Dim dateError As Boolean = False
        If keepDate = False Then
            _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.伝票日付) = 0
            denpyouDate.Date = _退避情報.操作日付
            If DoCheckControlMoveOut_伝票日付(args) = False Then
                dateError = True
            End If
            _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.伝票日付チェックフラグ) = False
        End If

        If dateError = True And args.移動先コントロール.TabIndex > denpyouDate.TabIndex Then
            args.失敗時動作 = CheckMethodArgs.失敗時動作型.移動する
            args.移動先コントロール = denpyouDate
            Return False
        End If

        Return True

    End Function

    ''' <summary>
    ''' コントロールのグループ№取得
    ''' </summary>
    ''' <param name="targetControl"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetControlGroupNo(ByVal targetControl As Control) As 退避情報型.グループ型

        If TypeOf targetControl Is OSK.X1.Foundation.Controls.Common.Control = True Then
            Dim fcControl As OSK.X1.Foundation.Controls.Common.Control
            fcControl = CType(targetControl, OSK.X1.Foundation.Controls.Common.Control)
            Return CType(fcControl.GroupNo, 退避情報型.グループ型)

        ElseIf TypeOf targetControl Is OSK.X1.Foundation.Controls.GridEdit = True Then
            Dim fcControl As OSK.X1.Foundation.Controls.GridEdit
            fcControl = CType(targetControl, OSK.X1.Foundation.Controls.GridEdit)
            Return CType(fcControl.GroupNo, 退避情報型.グループ型)
        End If

    End Function

    ''' <summary>
    ''' 伝票発行ラベルの表示
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Display_伝票発行ラベル()

        Select Case CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.伝票発行))
            Case 伝票発行型.なし
                printModeLabel.Visible = False
            Case 伝票発行型.本発行
                printModeLabel.Visible = True
                printModeLabel.Text = 伝票発行型.本発行.ToString
        End Select

    End Sub

#Region "先頭/最終項目の取得"

    ''' <summary>
    ''' 明細部 行の先頭列名の取得
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetDetailTopColumnName() As String

        Return 退避情報型.明細項目型.行.ToString

    End Function

    ''' <summary>
    ''' 明細部 入力先頭列名の取得
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetDetailTopColumnName2() As String

        Return 退避情報型.明細項目型.区分.ToString

    End Function

    ''' <summary>
    ''' ヘッダー部 最終コントロールの取得
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetHeaderLastControl() As System.Windows.Forms.Control

        Return ShouhizeiCode.InputTextControl

    End Function

    ''' <summary>
    ''' フッター部 先頭項目の取得
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetFooterTopControl() As System.Windows.Forms.Control

        Return biko

    End Function

#End Region

    ''' <summary>
    ''' 明細行の最後の項目が入力不可となる場合の次移動先を設定
    ''' </summary>
    ''' <remarks>「Grid_DoCheckCellMoveIn～」メソッドからの使用を想定</remarks>
    Private Sub SetNextCellFocus行最後項目()

        Dim nextColindex As Integer = GetNextColumnNameFrom現在セル(_toCell.RowIndex, _toCell.ColIndex)

        If nextColindex >= 0 Then
            '次セルへ
            _toCell.ColIndex = nextColindex
            Exit Sub
        End If

        If _toCell.RowIndex + 1 < _limitMaxRow Then
            '次行先頭セルへ
            _toCell.RowIndex += 1
            _toCell.ColIndex = DetailGridEdit.GetColumnIndex(GetDetailTopColumnName())
        Else
            'フッター部へ
            _zeroEnd = True
        End If

        '現在行から抜ける為、行チェックを行う
        If Grid_DoCheckLineMoveOut() = False Then
            _zeroEnd = False
            _toCell.RowIndex = _changeCell.RowIndex
            _toCell.ColIndex = _changeCell.ColIndex
            Exit Sub
        End If

        '現在セルの最新内容値が表示されないので、ここで再設定
        DetailGridEdit.CurrentEditValue = DetailGridEdit.GetData(_fromCell.RowIndex, _fromCell.ColIndex)

    End Sub

    Private Sub 伝票検索表示処理(ByVal control As Control)

        _kensakuRenban = 0
        _検索データ選択 = False
        _検索自動表示 = False

        Dim result As Boolean = False
        Dim paramInfo As IDictionary = New Hashtable
        Dim localLoader As ProgramLoad.UserInterface.ILocalLoader = Nothing
        Dim 検索対象 As CabNo型 = CabNo型.伝票検索

        'A-CUST20210125↓
        Dim 汎用伝票検索対象 As HanyoNo型
        汎用伝票検索対象 = HanyoNo型.見積伝票検索
        'A-CUST20210125↑

        'D-CUST20210125↓
        'localLoader = LoaderCABSearch(検索対象)
        'If localLoader Is Nothing Then
        '    localLoader = New LocalLoader
        '    If localLoader.Startup(Me, CAB検索, 検索対象) = False Then
        '        localLoader = Nothing
        '        LoaderCABSearch(検索対象) = localLoader
        '        Exit Sub
        '    End If
        '    LoaderCABSearch(検索対象) = localLoader
        'End If

        'localLoader.Run(paramInfo)

        '_検索データ選択 = paramInfo.Contains("見積№")

        'If _検索データ選択 = True Then
        '    _kensakuRenban = CLng(paramInfo.Item("見積№"))
        'End If
        'D-CUST20210125↑

        'A-CUST20210125↓
        paramInfo.Item("任意項目2") = 1
        paramInfo.Item("再表示区分") = CheckState.Checked

        localLoader = LoaderHanyoSearch(汎用伝票検索対象)
        If localLoader Is Nothing Then
            localLoader = New LocalLoader
            localLoader.Startup(Me, 汎用伝票検索, 汎用伝票検索対象)
        End If
        LoaderHanyoSearch(HanyoNo型.見積伝票検索) = localLoader

        localLoader.Run(paramInfo)
        _検索データ選択 = paramInfo.Contains("@RET1")

        If _検索データ選択 = True Then
            _kensakuRenban = CLng(paramInfo.Item("@RET1"))
        End If
        'A-CUST20210125↑

    End Sub

    Private Sub 明細部表示処理(row As Integer)

        DetailGridEdit.Redraw = False
        DetailGridEdit.RowCount = 0
        _退避情報.明細入力部.Clear()
        _退避情報.明細入力部.ImportRow(CType(_退避情報.明細表示部.Rows(row), DataRow))
        DetailGridEdit.DataTable = _退避情報.明細入力部.Copy
        DetailGridEdit.Redraw = True

        _現在入力行 = row
        _getGenZaikoLine = -1
    End Sub

    ''' <summary>
    ''' 現在セル位置から次に移動可能なセルを取得
    ''' </summary>
    ''' <param name="currentRowIndex"></param>
    ''' <param name="currentColIndex"></param>
    ''' <returns></returns>
    ''' <remarks>戻り値=-1 は同一行に移動可能なセルが存在しない</remarks>
    Private Overloads Function GetNextColumnNameFrom現在セル(ByVal currentRowIndex As Integer, ByVal currentColIndex As Integer) As Integer

        Dim startTabIndex As Integer = DetailGridEdit.Columns(currentColIndex).TabIndex + 1
        Dim endTabIndex As Integer = _detailColumnInfoList.最終項目TabIndex

        For index As Integer = startTabIndex To endTabIndex
            If _detailColTabIndexList.ContainsKey(index) = False Then
                Continue For
            End If

            Dim nextColName As String = _detailColTabIndexList(index)
            Dim nextColIndex As Integer = DetailGridEdit.GetColumnIndex(nextColName)
            Select Case Isセル状態_EditType(DetailGridEdit, currentRowIndex, nextColIndex)
                Case GridEditType.Empty
                    Continue For
            End Select
            If Isセル状態_DisplayOnly(DetailGridEdit, currentRowIndex, nextColIndex) = True Then
                Continue For
            End If
            If Isセル状態_ReadOnly(DetailGridEdit, currentRowIndex, nextColIndex) = False AndAlso
               Isセル状態_EditType(DetailGridEdit, currentRowIndex, nextColIndex) <> GridEditType.Nothing Then
                Return nextColIndex
            End If
        Next

        Return -1

    End Function

    ''' <summary>
    ''' 現在セル位置から次に移動可能なセルを取得
    ''' </summary>
    ''' <param name="currentRowIndex"></param>
    ''' <param name="currentColName"></param>
    ''' <returns></returns>
    ''' <remarks>戻り値=-1 は同一行に移動可能なセルが存在しない</remarks>
    Private Overloads Function GetNextColumnNameFrom現在セル(ByVal currentRowIndex As Integer, ByVal currentColName As String) As Integer

        Dim colindex As Integer = DetailGridEdit.GetColumnIndex(currentColName)
        Return GetNextColumnNameFrom現在セル(currentRowIndex, colindex)

    End Function

    ''' <summary>
    ''' 指定行番号をＤＢ値として持つ行の表示行を取得する
    ''' </summary>
    ''' <param name="行番号"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function Get表示行From行ＤＢ値(ByVal 行番号 As Integer) As Integer
        Dim フォーカス行 As Integer = 0

        For detailIndex As Integer = 0 To _maxRowCount - 1
            If CInt(_退避情報.明細表示部項目(detailIndex, 退避情報型.明細項目型.行ＤＢ値)) = 行番号 Then
                フォーカス行 = detailIndex
                Exit For
            End If
        Next

        Return フォーカス行
    End Function

#Region "初期処理"

    ''' <summary>
    ''' イベントハンドラーの初期処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub InitializeAddHandler()
        AddHandler shoriRenban.InputNumericalControl.KeyDown, AddressOf shoriRenban_KeyDown

    End Sub

    ''' <summary>
    ''' コンテキストメニューの初期処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub InitializeContextMenu()
        _contextMenu.FunctionBar = functionBar
    End Sub

    ''' <summary>
    ''' データテーブルスキーマ情報をセット
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Initialize退避情報()

        _退避情報.Initializer(InitInfo, _myコントロール情報)

    End Sub

    ''' <summary>
    ''' フォーカススイッチの初期処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub InitializeFocusSwitcher()

        With _focusSwitcher

            .SetForm(Me)
            For Each ctrl As System.Windows.Forms.Control In _ControlsList
                .AddControl(ctrl)
                AddCheckMethod(ctrl)
            Next

            .AddPreviousCheckDefaultMethod(AddressOf DoCheck前処理)
            .AddCheckAfterDefaultMethod(AddressOf DoCheck確定処理)

            .AddGroupCheckMethod(退避情報型.グループ型.No１, CheckModeType.移動元チェック, AddressOf DoCheckGroupMoveOut_Group1)
            .AddGroupCheckMethod(退避情報型.グループ型.No２, CheckModeType.移動元チェック, AddressOf DoCheckGroupMoveOut_Group2)
            .AddGroupCheckMethod(退避情報型.グループ型.No３, CheckModeType.移動元チェック, AddressOf DoCheckGroupMoveOut_Group3)
            .AddGroupCheckMethod(退避情報型.グループ型.No４, CheckModeType.移動元チェック, AddressOf DoCheckGroupMoveOut_Group4)
            .AddGroupCheckMethod(退避情報型.グループ型.No５, CheckModeType.移動元チェック, AddressOf DoCheckGroupMoveOut_Group5)
            .AddGroupCheckMethod(退避情報型.グループ型.No６, CheckModeType.移動元チェック, AddressOf DoCheckGroupMoveOut_Group6)

            .AddGroupCheckMethod(退避情報型.グループ型.No１, CheckModeType.移動先チェック, AddressOf DoCheckGroupMoveIn_Group1)
            .AddGroupCheckMethod(退避情報型.グループ型.No２, CheckModeType.移動先チェック, AddressOf DoCheckGroupMoveIn_Group2)
            .AddGroupCheckMethod(退避情報型.グループ型.No３, CheckModeType.移動先チェック, AddressOf DoCheckGroupMoveIn_Group3)
            .AddGroupCheckMethod(退避情報型.グループ型.No４, CheckModeType.移動先チェック, AddressOf DoCheckGroupMoveIn_Group4)
            .AddGroupCheckMethod(退避情報型.グループ型.No５, CheckModeType.移動先チェック, AddressOf DoCheckGroupMoveIn_Group5)
            .AddGroupCheckMethod(退避情報型.グループ型.No６, CheckModeType.移動先チェック, AddressOf DoCheckGroupMoveIn_Group6)

            .AddSubGroupCheckMethod(退避情報型.グループ型.No４, 退避情報型.サブグループ型.No２, CheckModeType.移動先チェック, AddressOf DoCheckGroupSubGroupMoveIn_Group4)
        End With

    End Sub

    ''' <summary>
    ''' ファンクションバー初期処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub InitializeFunctionBar()

        For Each targetControl As Control In _ControlsList

            Select Case targetControl.Name
                Case shori.Name

                Case shoriRenban.Name
                    SetFunctionBar(targetControl, ファンクション名型.伝票検索)
                    SetFunctionBar(targetControl, ファンクション名型.参照検索)
                    SetFunctionBar(targetControl, ファンクション名型.次伝票)
                    SetFunctionBar(targetControl, ファンクション名型.前伝票)
                    SetFunctionBar(targetControl, ファンクション名型.最終伝票)

                Case denpyouDate.Name
                    SetFunctionBar(targetControl, ファンクション名型.参照検索)

                Case taxRate.Name
                    SetFunctionBar(targetControl, ファンクション名型.選択一覧)

                Case TokuisakiCode.Name
                    SetFunctionBar(targetControl, ファンクション名型.マスター検索)
                    SetFunctionBar(targetControl, ファンクション名型.クリア)

                Case TokuisakiName1.Name
                    SetFunctionBar(targetControl, ファンクション名型.クリア)

                Case TokuisakiName2.Name
                    SetFunctionBar(targetControl, ファンクション名型.クリア)

                Case tantousha.Name
                    SetFunctionBar(targetControl, ファンクション名型.マスター検索)
                    SetFunctionBar(targetControl, ファンクション名型.クリア)

                Case bumon.Name
                    SetFunctionBar(targetControl, ファンクション名型.マスター検索)
                    SetFunctionBar(targetControl, ファンクション名型.クリア)

                'A-CUST20201013↓
                Case nohinsaki.Name
                    SetFunctionBar(targetControl, ファンクション名型.マスター検索)
                    SetFunctionBar(targetControl, ファンクション名型.クリア)
                'A-CUST20201013↑

                Case youken.Name
                    SetFunctionBar(targetControl, ファンクション名型.クリア)

                Case nouki.Name
                    SetFunctionBar(targetControl, ファンクション名型.クリア)

                Case shiharaiHoho.Name
                    SetFunctionBar(targetControl, ファンクション名型.クリア)

                Case yuukoukigen.Name
                    SetFunctionBar(targetControl, ファンクション名型.クリア)

                Case ShouhizeiCode.Name
                    SetFunctionBar(targetControl, ファンクション名型.マスター検索)
                    SetFunctionBar(targetControl, ファンクション名型.クリア)

                Case DetailGridView.Name
                    SetFunctionBar(targetControl, ファンクション名型.選択)
                    SetFunctionBar(targetControl, ファンクション名型.クリア)
                    SetFunctionBar(targetControl, ファンクション名型.行挿入)
                    SetFunctionBar(targetControl, ファンクション名型.行削除)
                    SetFunctionBar(targetControl, ファンクション名型.行終了)
                    SetFunctionBar(targetControl, ファンクション名型.サブ明細)  'A-CUST20241219
                    'A-CUST20251104↓
                    If _退避情報.FieldBuilder明細使用 Then
                        SetFunctionBar(targetControl, ファンクション名型.FieldBuilder)
                    End If
                    'A-CUST20251104↑
                Case DetailGridEdit.Name
                    InitializeFunctionBar_Detail()

                Case biko.Name
                    SetFunctionBar(targetControl, ファンクション名型.クリア)
                    SetFunctionBar(targetControl, ファンクション名型.以下省略)
                Case execute.Name

            End Select
        Next
        functionBar.SetUpFunctionEvent(Me)

    End Sub

    ''' <summary>
    ''' ファンクションバー初期処理（明細グリッド）
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub InitializeFunctionBar_Detail()

        With DetailGridEdit
            For colIndex As Integer = 0 To .ColumnCount - 1
                Select Case .Columns(colIndex).Name
                    Case 退避情報型.明細項目型.行.ToString
                        SetFunctionBar(DetailGridEdit, .Columns(colIndex).Name, ファンクション名型.行終了)

                    Case 退避情報型.明細項目型.区分.ToString
                        SetFunctionBar(DetailGridEdit, .Columns(colIndex).Name, ファンクション名型.マスター検索)
                        SetFunctionBar(DetailGridEdit, .Columns(colIndex).Name, ファンクション名型.入力行クリア)
                        SetFunctionBar(DetailGridEdit, .Columns(colIndex).Name, ファンクション名型.行終了)

                    Case 退避情報型.明細項目型.商品コード.ToString
                        SetFunctionBar(DetailGridEdit, .Columns(colIndex).Name, ファンクション名型.マスター検索)
                        SetFunctionBar(DetailGridEdit, .Columns(colIndex).Name, ファンクション名型.入力行クリア)

                    Case 退避情報型.明細項目型.商品名.ToString
                        SetFunctionBar(DetailGridEdit, .Columns(colIndex).Name, ファンクション名型.入力行クリア)

                    Case 退避情報型.明細項目型.単位.ToString
                        SetFunctionBar(DetailGridEdit, .Columns(colIndex).Name, ファンクション名型.入力行クリア)

                    Case 退避情報型.明細項目型.課税区分.ToString
                        SetFunctionBar(DetailGridEdit, .Columns(colIndex).Name, ファンクション名型.マスター検索)
                        SetFunctionBar(DetailGridEdit, .Columns(colIndex).Name, ファンクション名型.入力行クリア)

                    Case 退避情報型.明細項目型.倉庫コード.ToString
                        SetFunctionBar(DetailGridEdit, .Columns(colIndex).Name, ファンクション名型.マスター検索)
                        SetFunctionBar(DetailGridEdit, .Columns(colIndex).Name, ファンクション名型.入力行クリア)

                    Case 退避情報型.明細項目型.数量.ToString
                        SetFunctionBar(DetailGridEdit, .Columns(colIndex).Name, ファンクション名型.入力行クリア)

                    Case 退避情報型.明細項目型.単価.ToString
                        SetFunctionBar(DetailGridEdit, .Columns(colIndex).Name, ファンクション名型.入力行クリア)
                        'A-CUST20241219↓
                        SetFunctionBar(DetailGridEdit, .Columns(colIndex).Name, ファンクション名型.単価履歴)
                        SetFunctionBar(DetailGridEdit, .Columns(colIndex).Name, ファンクション名型.サブ明細)
                        'A-CUST20241219↑
                        SetFunctionBar(DetailGridEdit, .Columns(colIndex).Name, ファンクション名型.サブ明細クリア)      'A-CUST20241219 '20250220_2


                    Case 退避情報型.明細項目型.金額.ToString
                        SetFunctionBar(DetailGridEdit, .Columns(colIndex).Name, ファンクション名型.入力行クリア)

                    Case 退避情報型.明細項目型.原単価.ToString
                        SetFunctionBar(DetailGridEdit, .Columns(colIndex).Name, ファンクション名型.入力行クリア)

                    Case 退避情報型.明細項目型.原価金額.ToString
                        SetFunctionBar(DetailGridEdit, .Columns(colIndex).Name, ファンクション名型.入力行クリア)

                    Case 退避情報型.明細項目型.行摘要.ToString
                        SetFunctionBar(DetailGridEdit, .Columns(colIndex).Name, ファンクション名型.入力行クリア)
                        'A-CUST20251104↓
                        If _退避情報.FieldBuilder明細使用 Then
                            SetFunctionBar(DetailGridEdit, .Columns(colIndex).Name, ファンクション名型.FieldBuilder)
                        End If
                        'A-CUST20251104↑

                    Case 退避情報型.明細項目型.小計.ToString
                        SetFunctionBar(DetailGridEdit, .Columns(colIndex).Name, ファンクション名型.入力行クリア)

                    Case 退避情報型.明細項目型.改頁.ToString
                        SetFunctionBar(DetailGridEdit, .Columns(colIndex).Name, ファンクション名型.入力行クリア)

                    Case Else

                End Select
            Next
        End With

    End Sub

    ''' <summary>
    ''' グリッド初期処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub InitializeGrid_DetailEdit()

        With DetailGridEdit

            '見出し行の設定
            .UseHeader = False
            .UseIndex = True
            .IndexLevelCount = 1
            .Indexs(0).ItemCount = .ColumnCount
            .UseDataAdjustedFontWidth = True
            .UseColorEditCellIndex = True
            .TreatDataType = 1
            Dim colIndex As Integer = 0
            For index As Integer = 0 To .ColumnCount - 1
                If index <> colIndex Then
                    .Indexs(0).Items(index).RelativeColumn = colIndex
                    Continue For
                End If
                .Indexs(0).Items(index).Alignment = HorzAlign.Center
                .Indexs(0).Items(index).DisplayName = .Columns(index).DspName
                .Indexs(0).Items(index).RelativeColumn = index
                If .Columns(index).Name.Equals(退避情報型.明細項目型.行.ToString) Then
                    .Indexs(0).Items(index).HideBottomLine = True
                End If
                If .Columns(index).Name.Equals(退避情報型.明細項目型.区分.ToString) Then
                    .Indexs(0).Items(index).HideBottomLine = True
                End If
                If .Columns(index).Name.Equals(退避情報型.明細項目型.課税区分.ToString) Then
                    .Indexs(0).Items(index).RelativeColumn = index + 1
                End If
                If .Columns(index).Name.Equals(退避情報型.明細項目型.倉庫コード.ToString) Then
                    .Indexs(0).Items(index).RelativeColumn = index + 1
                End If
                colIndex += 1

            Next

            '折り返し列の指定
            .Lines = _detailColumnInfoList.LineStartColumu.Count
            For Each colName As String In _detailColumnInfoList.LineStartColumu
                Dim index As Integer = _detailColumnInfoList.LineStartColumu.IndexOf(colName)
                .Line(index).StartIndex = .GetColumnIndex(colName)
            Next
            .UseMultiLineCurrentRowFrame = False
        End With

    End Sub

    ''' <summary>
    ''' グリッド初期処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub InitializeGrid_DetailView()

        With DetailGridView

            .UseHeader = False
            .UseIndex = True
            .DataTable.Clear()
            .RowCount = 0
            .UseDataAdjustedFontWidth = True
            .TreatDataType = 1
            '.ColumnCount = 退避情報型.明細項目型.Detailcnt1  'D-CUST20251104
            .IndexLevelCount = 2
            'A-CUST20251104↓
            If _退避情報.FieldBuilder明細使用 Then
                .ColumnCount = 退避情報型.明細項目型.Detailcnt1
                .Indexs(0).ItemCount = 退避情報型.明細項目型.ラベル1_02 + 1
                .Indexs(1).ItemCount = 退避情報型.明細項目型.FieldBuilder - 退避情報型.明細項目型.ラベル1_02
            Else
                .ColumnCount = 退避情報型.明細項目型.Detailcnt1 - 2
                .Indexs(0).ItemCount = 退避情報型.明細項目型.小計 + 1
                .Indexs(1).ItemCount = (退避情報型.明細項目型.改頁 - 1) - 退避情報型.明細項目型.小計
            End If
            'A-CUST20251104↑

            .Lines = 2
            .Line(0).StartIndex = 0
            '.Line(1).StartIndex = 退避情報型.明細項目型.ラベル2_01  'D-CUST20251104
            .BackColorSelected = Color.FromArgb(204, 236, 255)
            .ForeColorSelected = .ForeColor
            Dim MaxIndex As Integer = 0
            'A-CUST20251104↓
            If _退避情報.FieldBuilder明細使用 Then
                .Line(1).StartIndex = 退避情報型.明細項目型.ラベル2_01
                MaxIndex = 退避情報型.明細項目型.Detailcnt1 - 1
            Else
                .Line(1).StartIndex = 退避情報型.明細項目型.ラベル2_01 - 1
                MaxIndex = 退避情報型.明細項目型.Detailcnt1 - 3
            End If
            'A-CUST20251104↑
            For index As Integer = 退避情報型.明細項目型.行 To MaxIndex
                With .Columns(index)
                    .Name = DetailGridEdit.Columns(index).Name
                    .DspName = DetailGridEdit.Columns(index).DspName
                    .Width = DetailGridEdit.Columns(index).Width
                    .AlignmentHeader = DetailGridEdit.Columns(index).AlignmentHeader
                    .Alignment = DetailGridEdit.Columns(index).Alignment
                    .ControlAttribute = DetailGridEdit.Columns(index).ControlAttribute
                    .ZeroSaples = DetailGridEdit.Columns(index).ZeroSaples
                    'D-CUST20211110_01↓
                    'If index = 退避情報型.明細項目型.数量 AndAlso
                    '   _myコントロール情報.数量拡張表示 = True Then
                    '    .ReadOnly = Grid.Common.Boolean.False
                    '    .DisplayOnly = Grid.Common.Boolean.True
                    '    .EditType = GridEditType.InputNumeric
                    'End If
                    'D-CUST20211110_01↑
                    'A-CUST20211110_01↓
                    'D-CUST20251104↓
                    'If index = 退避情報型.明細項目型.数量 OrElse
                    '   index = 退避情報型.明細項目型.単価 OrElse
                    '   index = 退避情報型.明細項目型.原単価 Then
                    '    .ReadOnly = Grid.Common.Boolean.False
                    '    .DisplayOnly = Grid.Common.Boolean.True
                    '    .EditType = GridEditType.InputNumeric
                    'End If
                    'If index = 退避情報型.明細項目型.小計 OrElse
                    '   index = 退避情報型.明細項目型.改頁 Then
                    '    '.ReadOnly = Grid.Common.Boolean.False
                    '    '.DisplayOnly = Grid.Common.Boolean.True
                    '    .EditType = GridEditType.CheckBox
                    'End If
                    'D-CUST20251104↑
                    'A-CUST20251104↓
                    Dim 数量 As Integer = 0
                    Dim 単価 As Integer = 0
                    Dim 原単価 As Integer = 0
                    Dim 改頁 As Integer = 0
                    If _退避情報.FieldBuilder明細使用 Then
                        数量 = 退避情報型.明細項目型.数量
                        単価 = 退避情報型.明細項目型.単価
                        原単価 = 退避情報型.明細項目型.原単価
                        改頁 = 退避情報型.明細項目型.改頁
                    Else
                        数量 = 退避情報型.明細項目型.数量 - 1
                        単価 = 退避情報型.明細項目型.単価 - 1
                        原単価 = 退避情報型.明細項目型.原単価 - 1
                        改頁 = 退避情報型.明細項目型.改頁 - 1
                    End If
                    If index = 数量 OrElse
                       index = 単価 OrElse
                       index = 原単価 Then
                        .ReadOnly = Grid.Common.Boolean.False
                        .DisplayOnly = Grid.Common.Boolean.True
                        .EditType = GridEditType.InputNumeric
                    End If
                    If index = 退避情報型.明細項目型.小計 OrElse
                       index = 改頁 Then
                        '.ReadOnly = Grid.Common.Boolean.False
                        '.DisplayOnly = Grid.Common.Boolean.True
                        .EditType = GridEditType.CheckBox
                    End If
                    'A-CUST20251104↑
                    If index = 退避情報型.明細項目型.FieldBuilder Then
                        .EditType = GridEditType.CommandButton
                    End If
                End With
            Next

            '1行目の設定
            Dim colIndex As Integer = 0
            'A-CUST20251104↓
            Dim MaxCol As Integer = 0
            If _退避情報.FieldBuilder明細使用 Then
                MaxCol = 退避情報型.明細項目型.ラベル1_02
            Else
                MaxCol = 退避情報型.明細項目型.小計
            End If
            'A-CUST20251104↑
            'For I As Integer = 0 To 退避情報型.明細項目型.小計 'D-CUST20251104
            For I As Integer = 0 To MaxCol  'A-CUST20251104
                If I <> colIndex Then
                    .Indexs(0).Items(I).RelativeColumn = colIndex
                    Continue For
                End If
                .Indexs(0).Items(I).Alignment = HorzAlign.Center
                .Indexs(0).Items(I).DisplayName = .Columns(I).DspName
                .Indexs(0).Items(I).RelativeColumn = I
                If .Columns(I).Name.Equals(退避情報型.明細項目型.行.ToString) Then
                    .Indexs(0).Items(I).HideBottomLine = True
                End If
                If .Columns(I).Name.Equals(退避情報型.明細項目型.区分.ToString) Then
                    .Indexs(0).Items(I).HideBottomLine = True
                End If
                If .Columns(I).Name.Equals(退避情報型.明細項目型.課税区分.ToString) Then
                    .Indexs(0).Items(I).RelativeColumn = I + 1
                End If
                If .Columns(I).Name.Equals(退避情報型.明細項目型.倉庫コード.ToString) Then
                    .Indexs(0).Items(I).RelativeColumn = I + 1
                End If
                colIndex += 1
            Next

            '2行目の設定
            'A-CUST20251104↓
            If _退避情報.FieldBuilder明細使用 Then
                colIndex = 退避情報型.明細項目型.ラベル2_01
                MaxCol = 退避情報型.明細項目型.FieldBuilder

            Else
                colIndex = 退避情報型.明細項目型.ラベル2_01 - 1
                MaxCol = 退避情報型.明細項目型.改頁 - 1
            End If
            'A-CUST20251104↑
            Dim startcol As Integer = colIndex
            'For index As Integer = 退避情報型.明細項目型.ラベル2_01 To 退避情報型.明細項目型.改頁   'D-CUST20251104
            For index As Integer = startcol To MaxCol    'A-CUST20251104
                If index <> colIndex Then
                    .Indexs(1).Items(index - startcol).RelativeColumn = colIndex
                    Continue For
                End If
                .Indexs(1).Items(index - startcol).Alignment = HorzAlign.Center
                .Indexs(1).Items(index - startcol).DisplayName = .Columns(index).DspName
                .Indexs(1).Items(index - startcol).RelativeColumn = index
                colIndex += 1
            Next

        End With

    End Sub
    ''' <summary>
    ''' グリッドヘルパーの初期処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub InitializeGridHelper_Detail()

        _detailColumnInfoList.SetDetailGrid(DetailGridEdit)
        _gridHelper = New GridHelper(DetailGridEdit, _detailColumnInfoList, DETAIL_MAXIMUM_ROW)
        _gridHelper.SetupGridHelper()

        InitializeGrid_DetailEdit()

        _gridHelper.SetDataTable(_退避情報.明細入力部.Copy)

        _detailColTabIndexList = CollectionGridTabIndexOrder(DetailGridEdit)

    End Sub

    ''' <summary>
    ''' 消費税率情報の初期処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub InitializeTaxControl()

        _消費税率 = New 消費税率型
        _消費税率.Initialize(Me.InitInfo)

    End Sub

    ''' <summary>
    ''' myコントロール情報の初期処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub InitializeControlInfo()

        _myコントロール情報 = New Myコントロール情報型
        _myコントロール情報.InitializeCUSCE01(InitInfo)
        _myコントロール情報.InitializeCUSCE11(InitInfo)

    End Sub

    ''' <summary>
    ''' 日付情報チェック部品の初期処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub InitializeDateInfo()

        _日付チェック = New DateCheck

    End Sub

    ''' <summary>
    ''' 印刷情報の初期化
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Initialize印刷情報()

        If _退避情報.起動モード = 起動モード型.詳細モード Then
            Exit Sub
        End If

        Dim printInfo As New 印刷初期情報型
        Dim reportName As New 帳票識別型
        Dim reports(0) As 帳票識別型

        Dim printSetting As New PrintSetting
        printSetting.Initialize(Me)
        reportName.帳票識別名 = printSetting.Get帳票識別名("見積書")
        reportName.表示用帳票名 = printSetting.Get表示用帳票名("見積書")
        reports(0) = reportName

        printSetting.SetUp印刷初期情報(reports, printInfo)

        _退避情報.PrintingController.Initialize(printInfo)

    End Sub

    'A-CUST20211001↓
    Private Sub InitializeTanka()
        _単価取得 = CommonFactory.CreateInstance(Of IUnitPriceGetter)(Me, GetType(UnitPriceGetter))
        _単価取得.StartUp(Me, 0)
    End Sub
    'A-CUST20211001↑

    ''' <summary>
    ''' 画面タイトル設定
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetFormTitleName()
        Me.Text = ""
        Me.Text &= Me.システム環境情報.プログラム情報.名称
        If Me.システム環境情報.プログラム制御情報.会社名表示 = True Then
            Me.Text &= "－" & Me.システム環境情報.会社情報.名称
        End If

    End Sub

    ''' <summary>
    ''' 画面デザインの設定
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetUpDisplayDesign()

    End Sub

    ''' <summary>
    ''' 画面項目の再配置
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetUpDisplayMove()

        'コントロールの設定により画面上の項目位置が変動する場合、ここへ記述    

    End Sub

#End Region

#Region "入力項目省略"

    ''' <summary>
    ''' 入力項目機能 省略されない次セルの設定処理
    ''' </summary>
    ''' <param name="args"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ItemSelectNextColmnuSet(ByVal args As GridCheckMethodArgs) As Boolean

        Dim checkError As Boolean = False

        Dim endTabIndex As Integer = _detailColumnInfoList.最終項目TabIndex
        Dim currentCell As CellInfoType = _toCell
        Dim nextCell As CellInfoType = _toCell
        Dim tabIndex As Integer = currentCell.TabIndex

        Do
            If Is入力省略項目判定(currentCell.RowIndex, tabIndex) = False Then
                Exit Do
            End If

            If tabIndex > endTabIndex Then
                Exit Do
            End If

            If _detailColTabIndexList.ContainsKey(tabIndex) = False Then
                Continue Do
            End If

            nextCell.ColName = _detailColTabIndexList(tabIndex)
            nextCell.ColIndex = DetailGridEdit.GetColumnIndex(nextCell.ColName)

            '省略するセルのチェック
            SaveGridEditIndex(DetailGridEdit, currentCell.RowIndex, currentCell.ColIndex, nextCell.RowIndex, nextCell.ColIndex)
            If Grid_DoCheckCell(args) = False Then
                '省略される項目にエラーがある状態
                If (_changeCell.RowIndex = -1 AndAlso _changeCell.ColIndex = -1) OrElse
                   (_changeCell.RowIndex = nextCell.RowIndex AndAlso _changeCell.ColIndex = nextCell.ColIndex) Then
                    checkError = True
                    Exit Do
                End If
                '移動先確定から更に移動する状態
                nextCell.ColName = DetailGridEdit.Columns(_changeCell.ColIndex).Name
                nextCell.ColIndex = _changeCell.ColIndex
                nextCell.TabIndex = DetailGridEdit.GetColumnTabIndex(nextCell.ColIndex)
                tabIndex = nextCell.TabIndex
            End If

            currentCell = nextCell
        Loop

        '入力可能列が次行となる場合
        If tabIndex > endTabIndex Then
            nextCell.RowIndex = currentCell.RowIndex + 1
            nextCell.ColName = GetDetailTopColumnName()
            nextCell.ColIndex = DetailGridEdit.GetColumnIndex(nextCell.ColName)
            SaveGridEditIndex(DetailGridEdit, currentCell.RowIndex, currentCell.ColIndex, nextCell.RowIndex, nextCell.ColIndex)
            If Grid_DoCheckCell(args) = False Then
                checkError = True
            End If
            currentCell = nextCell
        End If

        args.GridEventArgs.ToRowIndex = currentCell.RowIndex
        args.GridEventArgs.ToColIndex = currentCell.ColIndex

        '移動先確定
        Dim result As Boolean = True
        If checkError = False Then
            If _limitMaxRow <= currentCell.RowIndex Then
                '最終行はフッター部へ
                GetFooterTopControl.Focus()
                args.GridEventArgs.Cancel = True
                result = False
            End If
        Else
            If _changeCell.RowIndex <> -1 Then args.GridEventArgs.ToRowIndex = _changeCell.RowIndex
            If _changeCell.ColIndex <> -1 Then
                _changeCell.ColIndex = GetChangeColIndex(args)
                args.GridEventArgs.ToColIndex = _changeCell.ColIndex
            End If
            result = False
        End If

        'セル情報再設定
        SaveGridEditIndex(
                        DetailGridEdit,
                        args.GridEventArgs.FromRowIndex,
                        args.GridEventArgs.FromColIndex,
                        args.GridEventArgs.ToRowIndex,
                        args.GridEventArgs.ToColIndex)

        Return result

    End Function

#End Region

    ''' <summary>
    ''' 入力行数制御
    ''' </summary>
    ''' <param name="revise">新規行の調整有無（初期値は調整あり）</param>
    ''' <remarks></remarks>
    Private Sub Set入力行数(Optional ByVal revise As Boolean = True)

        '-----------------------------------
        '   明細入力可能行数の設定
        '-----------------------------------
        If _maxRowCount < _defaultMaxRow Then
            _limitMaxRow = _defaultMaxRow
        End If

    End Sub

    Private Sub Set更新後フォーカス()

        '移動先コントロールの決定
        TokuisakiCode.InputTextControl.Focus()

    End Sub

    'D-CUST20200311↓ '-20200527
    '''' <summary>
    '''' メニューバー「ページ設定」ボタン活性／非活性の設定
    '''' </summary>
    '''' <remarks></remarks>
    'Private Sub SetMenuBar_ページ設定()

    '    If CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.伝票発行)) = 伝票発行型.なし Then
    '        Me.MenuBar.Items.Item("pageMenu").Enabled = False
    '    Else
    '        Me.MenuBar.Items.Item("pageMenu").Enabled = True
    '    End If

    'End Sub
    'D-CUST20200311↑ '-20200527

    ''' <summary>
    ''' フォームのReadOnly設定
    ''' </summary>
    ''' <param name="switch"></param>
    ''' <param name="doEvents"></param>
    ''' <remarks></remarks>
    Private Sub SetReadOnly_Form(
                            ByVal switch As Boolean,
                   Optional ByVal doEvents As Boolean = False)

        If switch = True Then
            StatusBar.PrepareDoProgress(doEvents)
            Me.Cursor = Cursors.WaitCursor
            _focusSwitcher.EnableEvent(False)
            If doEvents = True Then
                SetReadOnlyExpand()
            End If

        Else
            StatusBar.StopDoProgress()
            Me.Cursor = Cursors.Default
            _focusSwitcher.EnableEvent(True)
            If doEvents = True Then
                RestoreReadOnly()
            End If
        End If

    End Sub

    ''' <summary>
    ''' フォームのReadOnly設定
    ''' </summary>
    ''' <param name="action"></param>
    ''' <remarks></remarks>
    Private Sub SetReadOnly_確定処理(ByVal switch As Boolean,
                            Optional ByVal action As Integer = 0)

        Dim exceptionControls As New List(Of System.Windows.Forms.Control)

        '除外するコントロールの設定
        With exceptionControls
            .Add(shori)
            .Add(shoriRenban.InputNumericalControl)
            .Add(display)
            .Add(execute)
            If action = 1 Then
                .Add(biko)
            End If
            .Add(DetailGridView)
            .Add(DetailGridEdit)
            .Add(functionBar)
            .Add(MenuBar)
        End With

        If switch = True Then
            SetReadOnlyExpand(exceptionControls.ToArray)
        Else
            RestoreReadOnly()
        End If

        DetailGridEdit.DisplayOnly = switch
        DetailGridEdit.TabStop = Not switch

    End Sub

    ''' <summary>
    ''' 税率(コンボボックスの設定）
    ''' </summary>
    ''' <param name="targetComboBox"></param>
    ''' <param name="targetInputDate"></param>
    ''' <remarks></remarks>
    Private Sub SetUpComboBoxTaxRate(ByVal targetComboBox As SimpleControl.ComboBox,
                                     ByVal targetInputDate As SimpleControl.InputDate)

        Dim dt As DataTable = CType(InitInfo.Item("CUS消費税率情報"), DataTable)
        With targetComboBox
            .Clear()
            For taxCount As Integer = dt.Rows.Count To 1 Step -1
                .AddRow()
                .Items(.RowCount - 1) = String.Format("{0,5:0.00}", dt.Rows(taxCount - 1).Item("税率"))
            Next
            .DisplayRowCount = .RowCount
            Dim rate As Decimal
            If _消費税率.GetTaxInfo("0001", targetInputDate.Date, rate) = True Then
                SetTaxRateCombobox(rate)
            End If
        End With

    End Sub

    Private Sub SetRowStateLabel(Optional newrow As Boolean = False)

        If _現在入力行 < 0 Then
            Exit Sub
        End If

        'ラベル変更
        If newrow = True Or
           Val(_退避情報.明細入力部項目(退避情報型.明細項目型.行)) = 0 Or
           _maxRowCount < Val(_退避情報.明細入力部項目(退避情報型.明細項目型.行)) Or
           (_maxRowCount >= _現在入力行 + 1 AndAlso
            Is省略判定(コード判定対象型.商品コード, _退避情報.明細表示部項目(_現在入力行, 退避情報型.明細項目型.商品コード).ToString) = 省略判定結果型.省略) Then
            'クリア時、行未入力時、新規行、行挿入時
            RowStatelbl.Text = "新規行"
            RowStatelbl.BackColor = Drawing.Color.GreenYellow
        Else
            RowStatelbl.Text = "行修正"
            RowStatelbl.BackColor = Drawing.Color.Yellow
        End If

    End Sub

    Private Function SetTaxRateCombobox(rate As Decimal) As Integer

        For I As Integer = 0 To taxRate.ComboBoxControl.Items.Length - 1
            If CDec(taxRate.ComboBoxControl.Items(I)) = rate Then
                taxRate.ComboBoxControl.CurrentIndex = I
                Exit For
            End If
        Next

        Return taxRate.ComboBoxControl.CurrentIndex
    End Function

    ''' <summary>
    ''' 各コントロールのプロパティ設定
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetUpControlsProperty()

        With shori
            .GroupNo = 退避情報型.グループ型.No１
            .RemarkString = 退避情報型.ヘッダー項目型.処理モード.ToString
            If _退避情報.起動モード = 起動モード型.詳細モード Then
                .Visible = False
                headerPanel.BackColor = Color.Transparent
                headerPanel.BorderStyle = Foundation.Controls.Panel.BorderStyleType.None
            End If
        End With

        With shoriRenban
            With .InputNumericalControl
                .GroupNo = 退避情報型.グループ型.No２
                .Name = .Parent.Name
                .TabIndex = .Parent.TabIndex
                .RemarkString = 退避情報型.ヘッダー項目型.処理連番.ToString
                If _退避情報.起動モード = 起動モード型.詳細モード Then
                    .ReadOnly = True
                    .Tag = "@OAREA@"
                    .BorderStyle = OSK.X1.Foundation.Controls.Common.InputControl.BorderStyleType.Narrow
                End If
            End With
        End With

        With display
            .GroupNo = 退避情報型.グループ型.No２
            If _退避情報.起動モード = 起動モード型.詳細モード Then
                .Visible = False
            End If
        End With

        With CloseButton
            .GroupNo = 退避情報型.グループ型.No２
            If _退避情報.起動モード = 起動モード型.詳細モード Then
                .Visible = True
            Else
                .Visible = False
            End If
        End With

        With denpyouDate
            .DisplayFormat = InputDate.DisplayFormatType.YYYY
            .GroupNo = 退避情報型.グループ型.No３
            .SubGroupNo = 退避情報型.サブグループ型.No１
            .RemarkString = 退避情報型.ヘッダー項目型.伝票日付.ToString
            If _退避情報.起動モード = 起動モード型.詳細モード Then
                .ReadOnly = True
                .Tag = "@OAREA@"
                .BorderStyle = OSK.X1.Foundation.Controls.Common.InputControl.BorderStyleType.Narrow
            End If
        End With

        With taxRate
            With .ComboBoxControl
                .GroupNo = 退避情報型.グループ型.No３
                .SubGroupNo = 退避情報型.サブグループ型.No１
                .Name = .Parent.Name
                .TabIndex = .Parent.TabIndex
                .RemarkString = 退避情報型.ヘッダー項目型.税率.ToString
                If _退避情報.起動モード = 起動モード型.詳細モード Then
                    .ReadOnly = True
                    .Tag = "@OAREA@"
                    .BorderStyle = Combo.Common.Control.BorderStyleType.Narrow
                End If
            End With
            .AutoSize = True
        End With

        With TokuisakiCode
            With .InputTextControl
                .AutoResize = False
                .GroupNo = 退避情報型.グループ型.No３
                .SubGroupNo = 退避情報型.サブグループ型.No１
                .Name = .Parent.Name
                .MaxLength = _定義情報.得意先コード_桁数
                .TabIndex = .Parent.TabIndex
                .RemarkString = 退避情報型.ヘッダー項目型.得意先コード.ToString
                If _退避情報.起動モード = 起動モード型.詳細モード Then
                    .ReadOnly = True
                    .Tag = "@OAREA@"
                    .BorderStyle = OSK.X1.Foundation.Controls.Common.InputControl.BorderStyleType.Narrow
                End If
            End With
            .InputType = InputTextWithItemName.InputTypeList.数値のみ
            .ZeroFill = True
            .ZeroFillAlways = False
        End With

        With TokuisakiName1
            .GroupNo = 退避情報型.グループ型.No３
            .SubGroupNo = 退避情報型.サブグループ型.No１
            .RemarkString = 退避情報型.ヘッダー項目型.得意先名１.ToString
            .ReadOnly = True
            .Tag = "@OAREA@"
            .BorderStyle = OSK.X1.Foundation.Controls.Common.InputControl.BorderStyleType.Narrow
        End With

        With TokuisakiName2
            .GroupNo = 退避情報型.グループ型.No３
            .SubGroupNo = 退避情報型.サブグループ型.No１
            .RemarkString = 退避情報型.ヘッダー項目型.得意先名２.ToString
            .ReadOnly = True
            .Tag = "@OAREA@"
            .BorderStyle = OSK.X1.Foundation.Controls.Common.InputControl.BorderStyleType.Narrow
        End With

        With tantousha
            With .InputTextControl
                .AutoResize = False
                .GroupNo = 退避情報型.グループ型.No３
                .SubGroupNo = 退避情報型.サブグループ型.No１
                .Name = .Parent.Name
                .MaxLength = _定義情報.担当者コード_桁数
                .TabIndex = .Parent.TabIndex
                .RemarkString = 退避情報型.ヘッダー項目型.担当者コード.ToString
                If _退避情報.起動モード = 起動モード型.詳細モード Then
                    .ReadOnly = True
                    .Tag = "@OAREA@"
                    .BorderStyle = OSK.X1.Foundation.Controls.Common.InputControl.BorderStyleType.Narrow
                End If
            End With
            .InputType = InputTextWithItemNameAndInputName.InputModeType.数値のみ
            .ZeroFill = True
            .ZeroFillAlways = False
        End With

        With bumon
            With .InputTextControl
                .AutoResize = False
                .GroupNo = 退避情報型.グループ型.No３
                .SubGroupNo = 退避情報型.サブグループ型.No１
                .Name = .Parent.Name
                .MaxLength = _定義情報.部門コード_桁数
                .TabIndex = .Parent.TabIndex
                .RemarkString = 退避情報型.ヘッダー項目型.部門コード.ToString
                If _退避情報.起動モード = 起動モード型.詳細モード Then
                    .ReadOnly = True
                    .Tag = "@OAREA@"
                    .BorderStyle = OSK.X1.Foundation.Controls.Common.InputControl.BorderStyleType.Narrow
                End If
            End With
            .InputType = InputTextWithItemNameAndInputName.InputModeType.数値のみ
            .ZeroFill = True
            .ZeroFillAlways = False
        End With

        'A-CUST20201013↓
        With nohinsaki
            With .InputTextControl
                .AutoResize = False
                .GroupNo = 退避情報型.グループ型.No３
                .SubGroupNo = 退避情報型.サブグループ型.No１
                .Name = .Parent.Name
                .MaxLength = _定義情報.納品先コード_桁数
                .TabIndex = .Parent.TabIndex
                .RemarkString = 退避情報型.ヘッダー項目型.納品先コード.ToString
                If _退避情報.起動モード = 起動モード型.詳細モード Then
                    .ReadOnly = True
                    .Tag = "@OAREA@"
                    .BorderStyle = OSK.X1.Foundation.Controls.Common.InputControl.BorderStyleType.Narrow
                End If
            End With
            .InputType = InputTextWithItemNameAndInputName.InputModeType.数値のみ
            .ZeroFill = True
            .ZeroFillAlways = False
        End With
        'A-CUST20201013↑

        With youken
            .GroupNo = 退避情報型.グループ型.No３
            .SubGroupNo = 退避情報型.サブグループ型.No１
            .RemarkString = 退避情報型.ヘッダー項目型.要件.ToString
            If _退避情報.起動モード = 起動モード型.詳細モード Then
                .ReadOnly = True
                .Tag = "@OAREA@"
                .BorderStyle = OSK.X1.Foundation.Controls.Common.InputControl.BorderStyleType.Narrow
            End If
        End With

        With nouki
            .GroupNo = 退避情報型.グループ型.No３
            .SubGroupNo = 退避情報型.サブグループ型.No１
            .RemarkString = 退避情報型.ヘッダー項目型.納期.ToString
            If _退避情報.起動モード = 起動モード型.詳細モード Then
                .ReadOnly = True
                .Tag = "@OAREA@"
                .BorderStyle = OSK.X1.Foundation.Controls.Common.InputControl.BorderStyleType.Narrow
            End If
        End With

        With shiharaiHoho
            .GroupNo = 退避情報型.グループ型.No３
            .SubGroupNo = 退避情報型.サブグループ型.No１
            .RemarkString = 退避情報型.ヘッダー項目型.支払方法.ToString
            If _退避情報.起動モード = 起動モード型.詳細モード Then
                .ReadOnly = True
                .Tag = "@OAREA@"
                .BorderStyle = OSK.X1.Foundation.Controls.Common.InputControl.BorderStyleType.Narrow
            End If
        End With

        With yuukoukigen
            .GroupNo = 退避情報型.グループ型.No３
            .SubGroupNo = 退避情報型.サブグループ型.No１
            .RemarkString = 退避情報型.ヘッダー項目型.有効期限.ToString
            If _退避情報.起動モード = 起動モード型.詳細モード Then
                .ReadOnly = True
                .Tag = "@OAREA@"
                .BorderStyle = OSK.X1.Foundation.Controls.Common.InputControl.BorderStyleType.Narrow
            End If
        End With

        With ShouhizeiCode
            With .InputTextControl
                .GroupNo = 退避情報型.グループ型.No３
                .SubGroupNo = 退避情報型.サブグループ型.No１
                .Name = .Parent.Name
                .TabIndex = .Parent.TabIndex
                .RemarkString = 退避情報型.ヘッダー項目型.消費税コード.ToString
                If _退避情報.起動モード = 起動モード型.詳細モード Then
                    .ReadOnly = True
                    .Tag = "@OAREA@"
                    .BorderStyle = OSK.X1.Foundation.Controls.Common.InputControl.BorderStyleType.Narrow
                End If
            End With
            .InputType = InputTextWithItemNameAndInputName.InputModeType.数値のみ
            .ZeroFill = True
            .ZeroFillAlways = False
        End With

        With shoriModeLabel
            If _退避情報.起動モード = 起動モード型.詳細モード Then
                .Visible = False
            End If
        End With

        With printModeLabel
            If _退避情報.起動モード = 起動モード型.詳細モード Then
                .Visible = False
            End If
        End With

        With DetailGridView
            .GroupNo = 退避情報型.グループ型.No４
            .SubGroupNo = 退避情報型.サブグループ型.No１
            .RemarkString = .Name
            .SelectMode = Grid.View.SelectModeType.One
        End With

        With DetailGridEdit
            .GroupNo = 退避情報型.グループ型.No４
            .SubGroupNo = 退避情報型.サブグループ型.No２
            .RemarkString = .Name
            If _退避情報.起動モード = 起動モード型.詳細モード Then
                .Visible = False
            End If
            .UseMultiLineCurrentRowFrame = False
        End With

        With RowStatelbl
            .GroupNo = 退避情報型.グループ型.No４
            If _退避情報.起動モード = 起動モード型.詳細モード Then
                .Visible = False
            End If
        End With

        With Kakutei
            .GroupNo = 退避情報型.グループ型.No４
            .SubGroupNo = 退避情報型.サブグループ型.No３
            If _退避情報.起動モード = 起動モード型.詳細モード Then
                .Visible = False
            End If
        End With

        With biko
            .RemarkString = 退避情報型.フッター項目型.備考名.ToString
            .GroupNo = 退避情報型.グループ型.No５
            If _退避情報.起動モード = 起動モード型.詳細モード Then
                .ReadOnly = True
                .Tag = "@OAREA@"
                .BorderStyle = OSK.X1.Foundation.Controls.Common.InputControl.BorderStyleType.Narrow
            End If
        End With

        With SokoGenzaikolbl
            If _退避情報.起動モード = 起動モード型.詳細モード Then
                .Visible = False
            End If
        End With

        With SokoGenzaiko
            .DecimalDigits = _myコントロール情報.小数桁_数量
            'D-CUST20211110_01↓
            'If _myコントロール情報.数量拡張表示 = True Then
            '    .TextDisplayMode = InputNumerical.TextDisplayModeType.AdjustFontWidth
            'End If
            'D-CUST20211110_01↑
            .TextDisplayMode = InputNumerical.TextDisplayModeType.AdjustFontWidth           'A-CUST20211110_01
            If _退避情報.起動モード = 起動モード型.詳細モード Then
                .Visible = False
            End If
        End With

        With ZensyaGenzaikolbl
            If _退避情報.起動モード = 起動モード型.詳細モード Then
                .Visible = False
            End If
        End With

        With ZensyaGenzaiko
            .DecimalDigits = _myコントロール情報.小数桁_数量
            'D-CUST20211110_01↓
            'If _myコントロール情報.数量拡張表示 = True Then
            '    .TextDisplayMode = InputNumerical.TextDisplayModeType.AdjustFontWidth
            'End If
            'D-CUST20211110_01↑
            .TextDisplayMode = InputNumerical.TextDisplayModeType.AdjustFontWidth           'A-CUST20211110_01
            If _退避情報.起動モード = 起動モード型.詳細モード Then
                .Visible = False
            End If
        End With

        'A-CUST20211110_01↓
        '常に圧縮文字表示するようにプロパティを設定
        With TotalArari
            .TextDisplayMode = InputNumerical.TextDisplayModeType.AdjustFontWidth
        End With
        With TaisyoKingaku
            .TextDisplayMode = InputNumerical.TextDisplayModeType.AdjustFontWidth
        End With
        With Syouhizeigaku
            .TextDisplayMode = InputNumerical.TextDisplayModeType.AdjustFontWidth
        End With
        With totalKingaku
            .TextDisplayMode = InputNumerical.TextDisplayModeType.AdjustFontWidth
        End With
        'A-CUST20211110_01↑

        'A-CUST20251104↓
        With ExpandItemButton
            .GroupNo = 退避情報型.グループ型.No３
            If Not _退避情報.FieldBuilderヘッダー使用 Then
                .Visible = False
            End If
        End With
        'A-CUST20251104↑
        With execute
            .GroupNo = 退避情報型.グループ型.No６
            If _退避情報.起動モード = 起動モード型.詳細モード Then
                .Visible = False
            End If
        End With

    End Sub

    ''' <summary>
    ''' 項目のWidth取得
    ''' </summary>
    ''' <param name="controll">対象コントロール</param>
    ''' <param name="target">項目</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetWidth(ByVal controll As OSK.X1.Foundation.SmartControl.ISmartControl, ByVal target As String) As Integer
        Dim widthCalculator As New OSK.X1.Foundation.Utility.UserInterface.WidthCalculator
        Dim newSize As System.Drawing.Size
        newSize = widthCalculator.GetSize(CType(controll, System.Windows.Forms.Control), target, 10, 0)

        Return newSize.Width

    End Function

#Region "継承メソッド"

    Public Overrides Sub LoadImpl(ByVal sender As Object, ByVal e As System.EventArgs)
        MyBase.LoadImpl(sender, e)

    End Sub

#End Region

#Region "インターフェイス IEntryForm"

    Public Sub SetUpForm() Implements IEntryForm.SetUpForm

        '起動モード設定
        _ドリルダウン = False
        If ParamInfo IsNot Nothing Then
            If ParamInfo.Contains("DENPYONO") = True Then
                _ドリルダウン = True
                _退避情報.起動モード = 起動モード型.ドリルダウン
                'タスクバー等の制御
                Me.ShowInTaskbar = False
                Me.MinimizeBox = False
            End If
            If システム環境情報.プログラム情報.枝番 = 100 Then
                _退避情報.起動モード = 起動モード型.詳細モード
            End If
        End If

        If _isInitialize = True Then

            _定義情報 = New 定義情報型
            _detailColumnInfoList = New ColumnInfoList(InitInfo, SettingInfo)

            MenuBar.SetupHelp(SettingInfo)
            StatusBar.SetupStatusBar(SettingInfo)
            MessageViewer.StatusLabelControl = StatusBar.StatusLabelControl

            _ControlsList = CollectionFormControls(Me)

            '新規に生成した場合、メニューバーのヘルプは非表示とする
            Me.MenuBar.Items.Item("_help").Visible = False
            Me.functionBar.F1でヘルプ = FunctionBar.ヘルプタイプ.実行しない

            'タイトルバー設定
            SetFormTitleName()

            '消費税率情報の初期処理
            InitializeTaxControl()

            'コントロール初期化
            InitializeControlInfo()

            '日付情報取得部品の初期処理
            InitializeDateInfo()

            '印刷情報設定
            Initialize印刷情報()

            '画面コントロールのプロパティ設定
            Initialize退避情報()
            SetUpControlsProperty()
            InitializeFocusSwitcher()
            InitializeGridHelper_Detail()
            InitializeGrid_DetailView()

            InitializeContextMenu()
            InitializeFunctionBar()
            InitializeAddHandler()

            'A-CUST20211001↓
            '単価取得部品の初期処理
            InitializeTanka()
            'A-CUST20211001↑

            'A-CUST20251104↓
            '初期入力チェック情報取得とFieldBuilder情報取得
            If _退避情報.FieldBuilderヘッダー使用 Then
                InitHeaderExpandCheckDefinition()
            End If
            If _退避情報.FieldBuilder明細使用 Then
                InitMeisaiExpandCheckDefinition()
            End If
            'A-CUST20251104↑

            '表示デザイン設定          
            SetUpDisplayDesign()

            '画面項目の再配置
            SetUpDisplayMove()

            '-----------------
            '   機能制御情報
            '-----------------
            _印刷クリップボードコピー区分 = Me.GetInitInfo("印刷クリップボードコピー区分", _印刷クリップボードコピー区分)

            _defaultMaxRow = DETAIL_MAXIMUM_ROW
        Else
            If _退避情報.起動モード = 起動モード型.詳細モード Then
                SetUpControlsProperty()
            End If
        End If

        If _印刷クリップボードコピー区分 = False Or
           _退避情報.起動モード = 起動モード型.詳細モード Then
            _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.伝票発行) = 伝票発行型.なし
            Me.MenuBar.Items.Item("pageMenu").Visible = False
            Me.MenuBar.Items.Item("printMenu").Visible = False
        Else
            _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.伝票発行) = _myコントロール情報.伝票発行
        End If

        Display_伝票発行ラベル()

        shori.Value = 処理区分型.登録
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード) = shori.Value

        Clear(クリア型.起動時のみ)

        Dim args As CheckMethodArgs = New CheckMethodArgs(shori, shori, CheckMethodArgs.移動方向型.後へ, Keys.Return, False, 0)
        DoCheck確定処理(args)

        Me.ShowDialog()
    End Sub

#End Region

#Region "ファンクション用メソッド"

    Private Sub FunctionF2_選択押下(ByVal control As Control)

        If Check明細表示前チェック() = False Then
            Exit Sub
        End If

        明細部表示処理(DetailGridView.ListIndex)

        DetailGridEdit.SetCellEdit(0, GetDetailTopColumnName2)
        DetailGridEdit.Focus()
        'ラベル変更
        SetRowStateLabel()

    End Sub

    Private Sub FunctionF3_伝票検索(ByVal control As Control)

        DateControlFocusPosition(control, "GET")

        伝票検索表示処理(control)

        If _検索データ選択 = True Then

            shoriRenban.Value = _kensakuRenban
            _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理連番) = 0

            _検索後イベント = True
            display.Enabled = True

            _focusSwitcher.EnableEvent(False)
            shoriRenban.InputNumericalControl.Focus()
            _focusSwitcher.EnableEvent(True)

            _keyReturn = True

            Dim nextControl As Control = _focusSwitcher.GetNextControl(shoriRenban.InputNumericalControl)
            nextControl.Focus()
        Else
            DateControlFocusPosition(control, "SET")
        End If

    End Sub

    Private Sub FunctionF3_マスター検索(ByVal control As Control)

        Dim result As Boolean = False
        Dim paramInfo As IDictionary = New Hashtable
        Dim localLoader As ProgramLoad.UserInterface.ILocalLoader = Nothing
        Dim 検索対象 As New CabNo型
        Dim 枝番 As Integer = 0

        Select Case control.Name
            Case TokuisakiCode.Name

                検索対象 = CabNo型.得意先

            Case tantousha.Name

                検索対象 = CabNo型.担当者

            Case bumon.Name

                検索対象 = CabNo型.部門

                 'A-CUST20201013↓
            Case nohinsaki.Name

                検索対象 = CabNo型.納品先
                With paramInfo
                    .Add("得意先コード", CStr(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.得意先コード)))
                End With
               'A-CUST20201013↑

            Case ShouhizeiCode.Name

                検索対象 = CabNo型.消費税区分

                With paramInfo
                    .Add("種別", Get区分マスター種別値(区分マスター型.消費税区分))
                End With

            Case Else

        End Select

        枝番 = CInt(Mid(CType(検索対象, String), 1, 4))

        localLoader = LoaderCABSearch(検索対象)
        If localLoader Is Nothing Then
            localLoader = New LocalLoader
            If localLoader.Startup(Me, CAB検索, 枝番) = False Then
                localLoader = Nothing
                LoaderCABSearch(検索対象) = localLoader
                Exit Sub
            End If
            LoaderCABSearch(検索対象) = localLoader
        End If

        localLoader.Run(paramInfo)

        If paramInfo.Contains("コード") = True Then
            control.Text = CStr(paramInfo.Item("コード")).TrimEnd
            result = True
        End If

        If result = True Then
            _keyReturn = True
            _focusSwitcher.GetNextControl(control).Focus()
        End If

    End Sub

    Private Sub FunctionF3_マスター検索(ByVal gridEdit As OSK.X1.Foundation.SimpleControl.GridEdit, ByVal columnName As String)

        Dim nowRowIndex As Integer = gridEdit.EditRowIndex
        Dim nowColIndex As Integer = gridEdit.EditColIndex

        Dim result As Boolean = False
        Dim control As Control = Nothing
        Dim nextColIndex As Integer = -1
        Dim nextColName As String = ""
        Dim paramInfo As IDictionary = New Hashtable
        Dim localLoader As ProgramLoad.UserInterface.ILocalLoader = Nothing
        Dim 検索対象 As New CabNo型
        Dim 枝番 As Integer = 0

        Select Case columnName
            Case 退避情報型.明細項目型.区分.ToString

                検索対象 = CabNo型.行区分
                nextColName = 退避情報型.明細項目型.商品コード.ToString

                With paramInfo
                    .Add("種別", Get区分マスター種別値(区分マスター型.区分))
                End With

            Case 退避情報型.明細項目型.課税区分.ToString

                検索対象 = CabNo型.課税区分
                nextColName = 退避情報型.明細項目型.倉庫コード.ToString

                With paramInfo
                    .Add("種別", Get区分マスター種別値(区分マスター型.課税区分))
                End With

            Case 退避情報型.明細項目型.倉庫コード.ToString

                検索対象 = CabNo型.倉庫
                nextColName = 退避情報型.明細項目型.数量.ToString

            Case 退避情報型.明細項目型.商品コード.ToString

                検索対象 = CabNo型.商品
                nextColName = 退避情報型.明細項目型.商品名.ToString

            Case Else

        End Select

        枝番 = CInt(Mid(CStr(検索対象), 1, 4))

        localLoader = LoaderCABSearch(検索対象)
        If localLoader Is Nothing Then
            localLoader = New LocalLoader
            If localLoader.Startup(Me, CAB検索, 枝番) = False Then
                localLoader = Nothing
                LoaderCABSearch(検索対象) = localLoader
                Exit Sub
            End If
            LoaderCABSearch(検索対象) = localLoader
        End If

        localLoader.Run(paramInfo)

        If paramInfo.Contains("コード") = True Then
            gridEdit.CurrentEditValue = CStr(paramInfo.Item("コード")).TrimEnd
            result = True
        End If

        If result = True Then
            _keyReturn = True
            _gridKeyDownCode = Keys.Return

            If control IsNot Nothing Then
                _focusSwitcher.GetNextControl(control).Focus()
                Exit Sub
            End If

            '列番号でフォーカス移動
            If nextColIndex >= 0 Then
                gridEdit.SetCellEdit(nowRowIndex, nextColIndex)
                Exit Sub
            End If

            '列名でフォーカス移動
            If nextColName <> "" Then
                gridEdit.SetCellEdit(nowRowIndex, nextColName)
                Exit Sub
            End If
        End If

    End Sub

    Private Sub FunctionF3_選択一覧(ByVal control As Control)
        Dim nowControl As OSK.X1.Foundation.SimpleControl.ComboBox
        nowControl = TryCast(control, OSK.X1.Foundation.SimpleControl.ComboBox)
        If nowControl IsNot Nothing Then
            nowControl.DropDown(True)
        End If

    End Sub

    Private Sub FunctionF4_参照登録(ByVal control As Control)

        DateControlFocusPosition(control, "GET")

        伝票検索表示処理(control)

        If _検索データ選択 = True Then

            _検索後イベント = True

            Dim args As CheckMethodArgs = New CheckMethodArgs(
                                                       shoriRenban,
                                                       Nothing,
                                                       CheckMethodArgs.移動方向型.後へ,
                                                       Keys.None, False, 0)
            If DoCheckControlMoveOut_処理連番(args) = False Then
                DateControlFocusPosition(control, "SET")
                Exit Sub
            End If

            _keyReturn = True

            _focusSwitcher.EnableEvent(False)
            shoriRenban.InputNumericalControl.Focus()
            _focusSwitcher.EnableEvent(True)

            Dim nextControl As Control = _focusSwitcher.GetNextControl(shoriRenban.InputNumericalControl)
            nextControl.Focus()
        Else
            DateControlFocusPosition(control, "SET")
        End If

    End Sub

    Private Sub FunctionF5_入力行クリア(ByVal gridEdit As OSK.X1.Foundation.SimpleControl.GridEdit, ByVal columnName As String)

        'If MyBase.MessageViewer.Show(1006, "OTS", IMessageViewer.DefaultButtonType.No) = IMessageViewer.ShowResultType.No Then      'D-CUST20230315
        If MyBase.MessageViewer.Show(999000005, "OTS", IMessageViewer.DefaultButtonType.No) = IMessageViewer.ShowResultType.No Then  'A-CUST20230315
            Exit Sub
        End If

        Detail_現在庫表示(-1, "")

        SetNewGridRow(True, CInt(Val(_退避情報.明細入力部項目(退避情報型.明細項目型.行)) - 1))

        DetailGridEdit.SetCellEdit(0, GetDetailTopColumnName2)
        RepairFunctionBar(DetailGridEdit, GetDetailTopColumnName2)  'A-CUST20210906_10
        StatusBar.StatusLabelControl.Text = ""                      'A-CUST20210906_14
        Display_StatusBar(0, GetDetailTopColumnName2)               'A-CUST20210906_14
    End Sub

    Private Sub FunctionF5_クリア(ByVal control As Control)

        If MyBase.MessageViewer.Show(48, IMessageViewer.DefaultButtonType.No) = IMessageViewer.ShowResultType.No Then
            Exit Sub
        End If

        Clear(クリア型.全て)

        If CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード)) <> 処理区分型.登録 Then
            If Is検索データ選択() Then
                _検索自動表示 = True
            End If
        Else
            If _検索種類 = 検索種類型.伝票検索 Then
                _検索データ選択 = False
            End If
        End If

        _退避情報.グループ状態(退避情報型.グループ型.No１) = 退避情報型.状態.正常

        _keyReturn = True

        If CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード)) = 処理区分型.登録 Then
            _focusSwitcher.DoFocusMove(shori, shoriRenban.InputNumericalControl)
        Else
            shoriRenban.InputNumericalControl.Focus()
        End If

    End Sub

    Private Sub FunctionF6_１行挿入(ByVal control As Control)

        Dim 挿入行 As Integer = DetailGridView.ListIndex
        Dim topindex As Integer = DetailGridView.TopIndex

        If is行確定済判定() = True Then
            'If MessageViewer.Show(1006, "OTS", IMessageViewer.DefaultButtonType.No) = IMessageViewer.ShowResultType.No Then      'D-CUST20230315
            If MessageViewer.Show(999000005, "OTS", IMessageViewer.DefaultButtonType.No) = IMessageViewer.ShowResultType.No Then  'A-CUST20230315
                Exit Sub
            End If
        End If

        '退避情報に行追加し、グリッドビューへ反映
        SetNewGridRow(False, 挿入行)

        DetailGridView.TopIndex = topindex
        DetailGridView.ChangeSelectedState(挿入行)
        DetailGridEdit.Focus()
        DetailGridEdit.SetCellEdit(0, GetDetailTopColumnName2)

        _現在入力行 = 挿入行
    End Sub

    Private Sub FunctionF6_次伝票(ByVal control As Control)

        Dim args As CheckMethodArgs = New CheckMethodArgs(
                                                        shoriRenban.InputNumericalControl,
                                                        Nothing,
                                                        CheckMethodArgs.移動方向型.後へ,
                                                        Keys.F6, False, 0)

        If DoCheckControlMoveOut_処理連番(args) = False Then
            Exit Sub
        End If

        shoriRenban.InputNumericalControl.SelectAll()
        StatusBar.StatusLabelControl.Text = ""

    End Sub

    Private Sub FunctionF7_１行削除(ByVal control As Control)

        Dim 削除行 As Integer = DetailGridView.ListIndex
        Dim TopIndex As Integer = DetailGridView.TopIndex

        If MessageViewer.Show(2, IMessageViewer.DefaultButtonType.No) = IMessageViewer.ShowResultType.No Then
            Exit Sub
        End If

        'フッター部初期処理
        If Footer_初期処理(False, 削除行) = False Then
            Exit Sub
        End If
        DisplayForm_合計部()

        '表示グリッドより削除
        _退避情報.明細表示部.Rows.RemoveAt(削除行)

        If _fromCell.RowIndex <= _maxRowCount - 1 Then
            _maxRowCount -= 1
        End If

        '入力行と等しい場合は、入力グリッド行をクリア
        If Val(_退避情報.明細入力部項目(退避情報型.明細項目型.行)) = 削除行 + 1 Then
            SetNewGridRow(True)
        ElseIf Val(_退避情報.明細入力部項目(退避情報型.明細項目型.行)) > 削除行 + 1 Then
            _現在入力行 -= 1
            _退避情報.明細入力部項目(退避情報型.明細項目型.行) = Val(_退避情報.明細入力部項目(退避情報型.明細項目型.行)) - 1
            DetailGridEdit.SetData(0, 退避情報型.明細項目型.行, CInt(_退避情報.明細入力部項目(退避情報型.明細項目型.行)))
        End If

        If _退避情報.明細表示部.Rows.Count = 0 Then
            Dim defaultRow As DataRow = _退避情報.CreateNewRow明細(False, 1)
            _退避情報.明細表示部.Rows.Add(defaultRow)
            _退避情報.明細表示部項目(0, 退避情報型.明細項目型.行) = 1
        End If
        SetGridAnyRow()

        DetailGridView.TopIndex = TopIndex
        If _maxRowCount = 0 Or 削除行 < _maxRowCount Then
            DetailGridView.ChangeSelectedState(削除行)
        Else
            DetailGridView.ChangeSelectedState(削除行 - 1)
        End If

        DetailGridView.Focus()

        RepairFunctionBar(DetailGridView)

    End Sub

    Private Sub FunctionF7_前伝票(ByVal control As Control)

        Dim args As CheckMethodArgs = New CheckMethodArgs(
                                                        shoriRenban.InputNumericalControl,
                                                        Nothing,
                                                        CheckMethodArgs.移動方向型.後へ,
                                                        Keys.F7, False, 0)

        If DoCheckControlMoveOut_処理連番(args) = False Then
            Exit Sub
        End If

        shoriRenban.InputNumericalControl.SelectAll()
        StatusBar.StatusLabelControl.Text = ""

    End Sub

    Private Sub FunctionF8_最終伝票(ByVal control As Control)

        Dim args As CheckMethodArgs = New CheckMethodArgs(
                                                        shoriRenban.InputNumericalControl,
                                                        Nothing,
                                                        CheckMethodArgs.移動方向型.後へ,
                                                        Keys.F8, False, 0)

        If DoCheckControlMoveOut_処理連番(args) = False Then
            Exit Sub
        End If

        shoriRenban.InputNumericalControl.SelectAll()
        StatusBar.StatusLabelControl.Text = ""

    End Sub

    Private Sub FunctionF9_行終了(ByVal gridEdit As OSK.X1.Foundation.SimpleControl.GridEdit, ByVal columnName As String)

        GetFooterTopControl.Focus()

    End Sub

    Private Sub FunctionF9_行終了(ByVal control As System.Windows.Forms.Control)

        GetFooterTopControl.Focus()

    End Sub

    Private Sub FunctionF9_以下省略(ByVal control As System.Windows.Forms.Control)

        execute.Focus()

    End Sub

    'A-CUST20241219↓
    Private Sub FunctionF9_単価履歴(ByVal gridEdit As OSK.X1.Foundation.SimpleControl.GridEdit, ByVal columnName As String)

        Dim nowRowIndex As Integer = gridEdit.EditRowIndex
        Dim nowColIndex As Integer = gridEdit.EditColIndex

        Dim result As Boolean = False
        Dim control As Control = Nothing
        Dim nextColIndex As Integer = -1
        Dim nextColName As String = ""
        Dim paramInfo As IDictionary = New Hashtable


        With paramInfo
            .Add("XMLファイル名", "EO汎用サブ画面_見積単価履歴.xml")
            .Add("処理モード", 0) '選択モード
            .Add("項目1PARM1", CStr(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.得意先コード)))
            .Add("項目2PARM1", CStr(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.得意先名１)) & CStr(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.得意先名２)))
            .Add("項目3PARM1", CStr(_退避情報.明細入力部項目(退避情報型.明細項目型.商品コード)))
            .Add("項目4PARM1", CStr(_退避情報.明細入力部項目(退避情報型.明細項目型.商品名)))

        End With

        単価履歴検索 = CommonFactory.CreateInstance(Of OSK.X1.OTS.LIB.HanyoSubForm.UI.ISubForm)(Me, GetType(OSK.X1.OTS.LIB.HanyoSubForm.UI.SubForm))
        単価履歴検索.Initialize(Me)

        単価履歴検索.SetUpForm(paramInfo)

        If paramInfo.Contains("@RET1") = True Then
            gridEdit.CurrentEditValue = CStr(paramInfo.Item("@RET1")).TrimEnd
            result = True
        End If

        If result = True Then
            _keyReturn = True
            _gridKeyDownCode = Keys.Return

            If control IsNot Nothing Then
                _focusSwitcher.GetNextControl(control).Focus()
                Exit Sub
            End If

            '列番号でフォーカス移動
            If nextColIndex >= 0 Then
                gridEdit.SetCellEdit(nowRowIndex, nextColIndex)
                Exit Sub
            End If

            '列名でフォーカス移動
            If nextColName <> "" Then
                gridEdit.SetCellEdit(nowRowIndex, nextColName)
                Exit Sub
            End If
        End If

    End Sub

    Private Sub FunctionF10_サブ明細(ByVal gridEdit As OSK.X1.Foundation.SimpleControl.GridEdit, ByVal columnName As String)

        Dim nowRowIndex As Integer = gridEdit.EditRowIndex
        Dim nowColIndex As Integer = gridEdit.EditColIndex

        Dim result As Boolean = False
        Dim control As Control = Nothing
        Dim nextColIndex As Integer = -1
        Dim nextColName As String = ""
        Dim paramInfo As IDictionary = New Hashtable

        Dim dtサブ画面データ As New DataTable
        dtサブ画面データ.Columns.Add(New DataColumn("CUSRE29003", GetType(String))) '行
        dtサブ画面データ.Columns.Add(New DataColumn("CUSRE29004", GetType(String))) '商品コード
        dtサブ画面データ.Columns.Add(New DataColumn("CUSRE29005", GetType(String))) '商品名
        dtサブ画面データ.Columns.Add(New DataColumn("CUSRE29006", GetType(String))) '単位
        dtサブ画面データ.Columns.Add(New DataColumn("CUSRE29007", GetType(Decimal))) '数量
        dtサブ画面データ.Columns.Add(New DataColumn("CUSRE29008", GetType(Decimal))) '単価
        dtサブ画面データ.Columns.Add(New DataColumn("CUSRE29009", GetType(Decimal))) '金額

        If _退避情報.明細入力部項目(退避情報型.明細項目型.サブ明細情報) IsNot Nothing Then
            _退避情報.サブ明細表示部 = CType(_退避情報.明細入力部項目(退避情報型.明細項目型.サブ明細情報), DataTable).Copy

            For idx As Integer = 0 To _退避情報.サブ明細表示部.Rows.Count - 1
                If CBool(_退避情報.サブ明細表示部項目(idx, 退避情報型.サブ明細項目型.行確定済)) = True Then
                    Dim dr As DataRow = dtサブ画面データ.NewRow
                    dr.Item("CUSRE29003") = CStr(_退避情報.サブ明細表示部項目(idx, 退避情報型.サブ明細項目型.行))
                    dr.Item("CUSRE29004") = CStr(_退避情報.サブ明細表示部項目(idx, 退避情報型.サブ明細項目型.商品コード))
                    dr.Item("CUSRE29005") = CStr(_退避情報.サブ明細表示部項目(idx, 退避情報型.サブ明細項目型.商品名))
                    dr.Item("CUSRE29006") = CStr(_退避情報.サブ明細表示部項目(idx, 退避情報型.サブ明細項目型.単位))
                    dr.Item("CUSRE29007") = CDec(_退避情報.サブ明細表示部項目(idx, 退避情報型.サブ明細項目型.数量))
                    dr.Item("CUSRE29008") = CDec(_退避情報.サブ明細表示部項目(idx, 退避情報型.サブ明細項目型.単価))
                    dr.Item("CUSRE29009") = CDec(_退避情報.サブ明細表示部項目(idx, 退避情報型.サブ明細項目型.金額))
                    dtサブ画面データ.Rows.Add(dr)
                End If
            Next
        End If

        With paramInfo
            .Add("XMLファイル名", "EO汎用サブ画面_見積サブ明細.xml")
            .Add("処理モード", 1) '入力モード
            If dtサブ画面データ.Rows.Count = 0 Then
                .Add("サブ画面データ", Nothing)
            Else
                .Add("サブ画面データ", dtサブ画面データ)
            End If
            .Add("項目1PARM1", CLng(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理連番)))
            .Add("項目2PARM1", CStr(_退避情報.明細入力部項目(退避情報型.明細項目型.行)))
            .Add("項目3PARM1", CStr(_退避情報.明細入力部項目(退避情報型.明細項目型.商品コード)))
            .Add("項目4PARM1", CStr(_退避情報.明細入力部項目(退避情報型.明細項目型.商品名)))
            .Add("任意項目1", CDec(_退避情報.明細入力部項目(退避情報型.明細項目型.数量)))
            .Add("任意項目2", CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.伝票日付)))
        End With

        サブ明細入力 = CommonFactory.CreateInstance(Of OSK.X1.OTS.LIB.HanyoSubForm.UI.ISubForm)(Me, GetType(OSK.X1.OTS.LIB.HanyoSubForm.UI.SubForm))
        サブ明細入力.Initialize(Me)

        サブ明細入力.SetUpForm(paramInfo)

        If paramInfo.Contains("確定区分") = True AndAlso CBool(paramInfo.Item("確定区分")) = True Then
            If paramInfo.Item("サブ画面データ") IsNot Nothing Then

                Dim getData As DataTable = CType(paramInfo.Item("サブ画面データ"), DataTable)

                _退避情報.サブ明細表示部.Clear()
                Dim 金額SUM As Decimal = 0
                For idx As Integer = 0 To getData.Rows.Count - 1
                    _退避情報.サブ明細表示部.Rows.Add(_退避情報.CreateNewRowサブ明細(退避情報型.GridType.view, idx))
                    _退避情報.サブ明細表示部項目(idx, 退避情報型.サブ明細項目型.行.ToString) = idx + 1 '行
                    _退避情報.サブ明細表示部項目(idx, 退避情報型.サブ明細項目型.商品コード.ToString) = getData.Rows(idx).Item("CUSRE29004") '商品コード
                    _退避情報.サブ明細表示部項目(idx, 退避情報型.サブ明細項目型.商品名.ToString) = getData.Rows(idx).Item("CUSRE29005") '商品名
                    _退避情報.サブ明細表示部項目(idx, 退避情報型.サブ明細項目型.単位.ToString) = getData.Rows(idx).Item("CUSRE29006") '単位
                    _退避情報.サブ明細表示部項目(idx, 退避情報型.サブ明細項目型.数量.ToString) = getData.Rows(idx).Item("CUSRE29007") '数量
                    _退避情報.サブ明細表示部項目(idx, 退避情報型.サブ明細項目型.単価.ToString) = getData.Rows(idx).Item("CUSRE29008") '単価
                    _退避情報.サブ明細表示部項目(idx, 退避情報型.サブ明細項目型.金額.ToString) = getData.Rows(idx).Item("CUSRE29009") '金額
                    _退避情報.サブ明細表示部項目(idx, 退避情報型.サブ明細項目型.行確定済.ToString) = True

                    金額SUM += CDec(_退避情報.サブ明細表示部項目(idx, 退避情報型.サブ明細項目型.金額.ToString))
                Next

                Dim hasサブ明細 As Boolean = False
                If _退避情報.サブ明細表示部.Rows.Count > 0 Then
                    hasサブ明細 = True
                End If
                _退避情報.サブ明細表示部.Rows.Add(_退避情報.CreateNewRowサブ明細(退避情報型.GridType.view, _退避情報.サブ明細表示部.Rows.Count))

                _退避情報.明細入力部項目(退避情報型.明細項目型.サブ明細情報) = _退避情報.サブ明細表示部.Copy
                If hasサブ明細 = True Then
                    _退避情報.明細入力部項目(退避情報型.明細項目型.ラベル1_01) = "サブ明細有り"
                    gridEdit.SetData(nowRowIndex, 退避情報型.明細項目型.ラベル1_01.ToString, "サブ明細有り")
                Else
                    _退避情報.明細入力部項目(退避情報型.明細項目型.ラベル1_01) = ""
                    gridEdit.SetData(nowRowIndex, 退避情報型.明細項目型.ラベル1_01.ToString, "")
                End If

                gridEdit.CurrentEditValue = CStr(金額SUM).TrimEnd

                result = True
            End If
        End If

        If result = True Then
            _keyReturn = True
            _gridKeyDownCode = Keys.Return

            If control IsNot Nothing Then
                _focusSwitcher.GetNextControl(control).Focus()
                Exit Sub
            End If

            '列番号でフォーカス移動
            If nextColIndex >= 0 Then
                gridEdit.SetCellEdit(nowRowIndex, nextColIndex)
                Exit Sub
            End If

            '列名でフォーカス移動
            If nextColName <> "" Then
                gridEdit.SetCellEdit(nowRowIndex, nextColName)
                Exit Sub
            End If
        End If

    End Sub

    Private Sub FunctionF10_サブ明細(ByVal control As Control)

        Dim result As Boolean = False
        Dim nextColIndex As Integer = -1
        Dim nextColName As String = ""
        Dim paramInfo As IDictionary = New Hashtable

        Dim dtサブ画面データ As New DataTable
        dtサブ画面データ.Columns.Add(New DataColumn("CUSRE29003", GetType(String))) '行
        dtサブ画面データ.Columns.Add(New DataColumn("CUSRE29004", GetType(String))) '商品コード
        dtサブ画面データ.Columns.Add(New DataColumn("CUSRE29005", GetType(String))) '商品名
        dtサブ画面データ.Columns.Add(New DataColumn("CUSRE29006", GetType(String))) '単位
        dtサブ画面データ.Columns.Add(New DataColumn("CUSRE29007", GetType(Decimal))) '数量
        dtサブ画面データ.Columns.Add(New DataColumn("CUSRE29008", GetType(Decimal))) '単価
        dtサブ画面データ.Columns.Add(New DataColumn("CUSRE29009", GetType(Decimal))) '金額

        If _退避情報.明細表示部項目(DetailGridView.ListIndex, 退避情報型.明細項目型.サブ明細情報) IsNot Nothing Then
            _退避情報.サブ明細表示部 = CType(_退避情報.明細表示部項目(DetailGridView.ListIndex, 退避情報型.明細項目型.サブ明細情報), DataTable).Copy

            For idx As Integer = 0 To _退避情報.サブ明細表示部.Rows.Count - 1
                If CBool(_退避情報.サブ明細表示部項目(idx, 退避情報型.サブ明細項目型.行確定済)) = True Then
                    Dim dr As DataRow = dtサブ画面データ.NewRow
                    dr.Item("CUSRE29003") = CStr(_退避情報.サブ明細表示部項目(idx, 退避情報型.サブ明細項目型.行))
                    dr.Item("CUSRE29004") = CStr(_退避情報.サブ明細表示部項目(idx, 退避情報型.サブ明細項目型.商品コード))
                    dr.Item("CUSRE29005") = CStr(_退避情報.サブ明細表示部項目(idx, 退避情報型.サブ明細項目型.商品名))
                    dr.Item("CUSRE29006") = CStr(_退避情報.サブ明細表示部項目(idx, 退避情報型.サブ明細項目型.単位))
                    dr.Item("CUSRE29007") = CDec(_退避情報.サブ明細表示部項目(idx, 退避情報型.サブ明細項目型.数量))
                    dr.Item("CUSRE29008") = CDec(_退避情報.サブ明細表示部項目(idx, 退避情報型.サブ明細項目型.単価))
                    dr.Item("CUSRE29009") = CDec(_退避情報.サブ明細表示部項目(idx, 退避情報型.サブ明細項目型.金額))
                    dtサブ画面データ.Rows.Add(dr)
                End If
            Next
        End If

        With paramInfo
            .Add("XMLファイル名", "EO汎用サブ画面_見積サブ明細.xml")
            .Add("処理モード", 2) '参照モード
            If dtサブ画面データ.Rows.Count = 0 Then
                .Add("サブ画面データ", Nothing)
            Else
                .Add("サブ画面データ", dtサブ画面データ)
            End If
            .Add("項目1PARM1", CLng(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理連番)))
            .Add("項目2PARM1", CStr(_退避情報.明細表示部項目(DetailGridView.ListIndex, 退避情報型.明細項目型.行)))
            .Add("項目3PARM1", CStr(_退避情報.明細表示部項目(DetailGridView.ListIndex, 退避情報型.明細項目型.商品コード)))
            .Add("項目4PARM1", CStr(_退避情報.明細表示部項目(DetailGridView.ListIndex, 退避情報型.明細項目型.商品名)))
            .Add("任意項目1", CDec(_退避情報.明細表示部項目(DetailGridView.ListIndex, 退避情報型.明細項目型.数量)))
            .Add("任意項目2", CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.伝票日付)))
        End With

        サブ明細入力 = CommonFactory.CreateInstance(Of OSK.X1.OTS.LIB.HanyoSubForm.UI.ISubForm)(Me, GetType(OSK.X1.OTS.LIB.HanyoSubForm.UI.SubForm))
        サブ明細入力.Initialize(Me)

        サブ明細入力.SetUpForm(paramInfo)

    End Sub
    'A-CUST20241219↑

    'A-CUST20241219↓ '20250220_2
    Private Sub FunctionF11_サブ明細クリア(ByVal gridEdit As OSK.X1.Foundation.SimpleControl.GridEdit, ByVal columnName As String)

        If MessageViewer.Show(2, IMessageViewer.DefaultButtonType.No) = IMessageViewer.ShowResultType.No Then
            Exit Sub
        End If

        Dim nowRowIndex As Integer = gridEdit.EditRowIndex
        Dim nowColIndex As Integer = gridEdit.EditColIndex

        Dim result As Boolean = False
        Dim control As Control = Nothing
        Dim nextColIndex As Integer = -1
        Dim nextColName As String = ""
        Dim paramInfo As IDictionary = New Hashtable

        _退避情報.サブ明細表示部.Clear()
        _退避情報.サブ明細表示部.Rows.Add(_退避情報.CreateNewRowサブ明細(退避情報型.GridType.view, _退避情報.サブ明細表示部.Rows.Count))
        _退避情報.明細入力部項目(退避情報型.明細項目型.サブ明細情報) = _退避情報.サブ明細表示部.Copy
        _退避情報.明細入力部項目(退避情報型.明細項目型.ラベル1_01) = ""
        gridEdit.SetData(nowRowIndex, 退避情報型.明細項目型.ラベル1_01.ToString, "")

    End Sub
    'A-CUST20241219↑ '20250220_2

    'A-CUST20251104↓
    Private Sub FunctionF11_FieldBuilder(ByVal control As Control)
        Dim paramInfo As IDictionary = New Hashtable
        Dim dtサブ画面データ As New DataTable
        If _退避情報.明細表示部項目(DetailGridView.ListIndex, 退避情報型.明細項目型.FieldBuilder) IsNot Nothing OrElse
           CType(_退避情報.明細表示部項目(DetailGridView.ListIndex, 退避情報型.明細項目型.FieldBuilder), DataTable).Rows.Count > 0 Then
            dtサブ画面データ = CType(_退避情報.明細表示部項目(DetailGridView.ListIndex, 退避情報型.明細項目型.FieldBuilder), DataTable).Copy
        End If

        LaunchMeisaiExpandSubForm(dtサブ画面データ, 処理モード.参照, paramInfo)

    End Sub

    Private Sub FunctionF11_FieldBuilder(ByVal gridEdit As OSK.X1.Foundation.SimpleControl.GridEdit, ByVal columnName As String)
        Dim paramInfo As IDictionary = New Hashtable
        Dim dtサブ画面データ As New DataTable

        If _退避情報.明細入力部項目(退避情報型.明細項目型.FieldBuilder) IsNot Nothing Then
            dtサブ画面データ = CType(_退避情報.明細入力部項目(退避情報型.明細項目型.FieldBuilder), DataTable).Copy
        End If

        LaunchMeisaiExpandSubForm(dtサブ画面データ, 処理モード.入力, paramInfo)

    End Sub
    'A-CUST20251104↑

    ''' <summary>
    ''' コントロール毎のファンクション設定
    ''' </summary>
    ''' <param name="control"></param>
    ''' <param name="ファンクション名"></param>
    ''' <remarks>通常コントロール用</remarks>
    Private Overloads Sub SetFunctionBar(ByVal control As Control, ByVal ファンクション名 As ファンクション名型)

        Dim functionKey As FunctionControl.KeyType = Nothing
        Dim functionMethod As FunctionControl.FunctionMethod = Nothing
        Dim functionName As String = ファンクション名.ToString

        Select Case ファンクション名
            Case ファンクション名型.選択
                functionKey = FunctionControl.KeyType.F2
                functionMethod = AddressOf FunctionF2_選択押下

            Case ファンクション名型.マスター検索
                functionKey = FunctionControl.KeyType.F3
                functionMethod = AddressOf FunctionF3_マスター検索

            Case ファンクション名型.選択一覧
                functionKey = FunctionControl.KeyType.F3
                functionMethod = AddressOf FunctionF3_選択一覧

            Case ファンクション名型.伝票検索
                functionKey = FunctionControl.KeyType.F3
                functionMethod = AddressOf FunctionF3_伝票検索

            Case ファンクション名型.参照検索
                functionKey = FunctionControl.KeyType.F4
                functionMethod = AddressOf FunctionF4_参照登録

            Case ファンクション名型.クリア
                functionKey = FunctionControl.KeyType.F5
                functionMethod = AddressOf FunctionF5_クリア

            Case ファンクション名型.次伝票
                functionKey = FunctionControl.KeyType.F6
                functionMethod = AddressOf FunctionF6_次伝票

            Case ファンクション名型.行挿入
                functionName = "１" & functionName
                functionKey = FunctionControl.KeyType.F6
                functionMethod = AddressOf FunctionF6_１行挿入

            Case ファンクション名型.行削除
                functionName = "１" & functionName
                functionKey = FunctionControl.KeyType.F7
                functionMethod = AddressOf FunctionF7_１行削除

            Case ファンクション名型.前伝票
                functionKey = FunctionControl.KeyType.F7
                functionMethod = AddressOf FunctionF7_前伝票

            Case ファンクション名型.最終伝票
                functionKey = FunctionControl.KeyType.F8
                functionMethod = AddressOf FunctionF8_最終伝票

            Case ファンクション名型.以下省略
                functionKey = FunctionControl.KeyType.F9
                functionMethod = AddressOf FunctionF9_以下省略

            Case ファンクション名型.行終了
                functionKey = FunctionControl.KeyType.F9
                functionMethod = AddressOf FunctionF9_行終了

                'A-CUST20241219↓
            Case ファンクション名型.サブ明細
                functionKey = FunctionControl.KeyType.F10
                functionMethod = AddressOf FunctionF10_サブ明細
                'A-CUST20241219↑

                'A-CUST20251104↓
            Case ファンクション名型.FieldBuilder
                functionKey = FunctionControl.KeyType.F11
                functionMethod = AddressOf FunctionF11_FieldBuilder
                'A-CUST20251104↑
            Case Else
                Exit Sub

        End Select

        functionBar.Items.SetControl(control, functionKey, functionName, functionMethod)

    End Sub

    ''' <summary>
    ''' コントロール毎のファンクション設定（グリッド）
    ''' </summary>
    ''' <param name="gridEdit"></param>
    ''' <param name="columnName"></param>
    ''' <param name="ファンクション名"></param>
    ''' <remarks>グリッドコントロール用</remarks>
    Private Overloads Sub SetFunctionBar(ByVal gridEdit As OSK.X1.Foundation.SimpleControl.GridEdit, ByVal columnName As String, ByVal ファンクション名 As ファンクション名型)

        Dim functionKey As FunctionControl.KeyType = Nothing
        Dim functionGridMethod As FunctionControl.FunctionGridMethod = Nothing
        Dim functionName As String = ファンクション名.ToString

        Select Case ファンクション名

            Case ファンクション名型.マスター検索
                functionKey = FunctionControl.KeyType.F3
                functionGridMethod = AddressOf FunctionF3_マスター検索

            Case ファンクション名型.入力行クリア
                functionName = "クリア"
                functionKey = FunctionControl.KeyType.F5
                functionGridMethod = AddressOf FunctionF5_入力行クリア

            Case ファンクション名型.行終了
                functionKey = FunctionControl.KeyType.F9
                functionGridMethod = AddressOf FunctionF9_行終了

                'A-CUST20241219↓
            Case ファンクション名型.単価履歴
                functionKey = FunctionControl.KeyType.F9
                functionGridMethod = AddressOf FunctionF9_単価履歴

            Case ファンクション名型.サブ明細
                functionKey = FunctionControl.KeyType.F10
                functionGridMethod = AddressOf FunctionF10_サブ明細
                'A-CUST20241219↑

                'A-CUST20241219↓ '20250220_2
            Case ファンクション名型.サブ明細クリア
                functionKey = FunctionControl.KeyType.F11
                functionGridMethod = AddressOf FunctionF11_サブ明細クリア
                'A-CUST20241219↑ '20250220_2

                'A-CUST20251104↓
            Case ファンクション名型.FieldBuilder
                functionKey = FunctionControl.KeyType.F11
                functionGridMethod = AddressOf FunctionF11_FieldBuilder
                'A-CUST20251104↑
            Case Else
                Exit Sub

        End Select

        functionBar.Items.SetGridControl(gridEdit, columnName, functionKey, functionName, functionGridMethod)

    End Sub

    ''' <summary>
    ''' ファンクションバー再構築
    ''' </summary>
    ''' <param name="control"></param>
    ''' <remarks>通常コントロール用</remarks>
    Private Overloads Sub RepairFunctionBar(ByVal control As Control)

        For Each functionKey As FunctionControl.KeyType In [Enum].GetValues(GetType(FunctionControl.KeyType))
            If _退避情報.起動モード = 起動モード型.詳細モード Then
                functionBar.Items.Mode(control, functionKey).Visible = False
            Else
                functionBar.Items.Mode(control, functionKey).Visible = True
            End If
        Next

        '非表示させるファンクションの設定
        Select Case control.Name
            Case shoriRenban.Name
                functionBar.Items.Mode(control, FunctionControl.KeyType.F4).Visible = False
                functionBar.Items.Mode(control, FunctionControl.KeyType.F12).Visible = False

            Case denpyouDate.Name
                If CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード)) = 処理区分型.登録 Then
                    functionBar.Items.Mode(control, FunctionControl.KeyType.F3).Visible = False
                    functionBar.Items.Mode(control, FunctionControl.KeyType.F11).Visible = False
                Else
                    functionBar.Items.Mode(control, FunctionControl.KeyType.F4).Visible = False
                    functionBar.Items.Mode(control, FunctionControl.KeyType.F12).Visible = False
                End If

            Case DetailGridView.Name
                If Is行挿入可否(DetailGridView) = False Then
                    '行挿入
                    functionBar.Items.Mode(control, FunctionControl.KeyType.F6).Visible = False
                End If
                If Is行削除可否(DetailGridView) = False Then
                    '行削除
                    functionBar.Items.Mode(control, FunctionControl.KeyType.F7).Visible = False
                End If
                If CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード)) = 処理区分型.削除 Then
                    functionBar.Items.Mode(control, FunctionControl.KeyType.F2).Visible = False
                    functionBar.Items.Mode(control, FunctionControl.KeyType.F5).Visible = False
                    functionBar.Items.Mode(control, FunctionControl.KeyType.F6).Visible = False
                    functionBar.Items.Mode(control, FunctionControl.KeyType.F7).Visible = False
                    functionBar.Items.Mode(control, FunctionControl.KeyType.F9).Visible = False
                    functionBar.Items.Mode(control, FunctionControl.KeyType.F10).Visible = False  'A-CUST20241219
                    functionBar.Items.Mode(control, FunctionControl.KeyType.F11).Visible = False    'A-CUST20251104
                End If

                'A-CUST20241219↓ '20250220_1
                If DetailGridView.ListIndex >= 0 Then
                    Dim strData As Object = DetailGridView.GetData(DetailGridView.ListIndex, 退避情報型.明細項目型.ラベル1_01.ToString)
                    If strData Is Nothing OrElse strData.ToString.TrimEnd.TrimStart <> "サブ明細有り" Then
                        functionBar.Items.Mode(control, FunctionControl.KeyType.F10).Visible = False
                    End If
                End If
                'A-CUST20241219↑ '20250220_1

        End Select

        functionBar.SetTargetControl(control)

    End Sub

    ''' <summary>
    ''' ファンクションバー再構築（グリッド）
    ''' </summary>
    ''' <param name="gridEdit"></param>
    ''' <param name="columnName"></param>
    ''' <remarks>グリッドコントロール用</remarks>
    Private Overloads Sub RepairFunctionBar(ByVal gridEdit As OSK.X1.Foundation.SimpleControl.GridEdit, ByVal columnName As String)

        For Each functionKey As FunctionControl.KeyType In [Enum].GetValues(GetType(FunctionControl.KeyType))
            functionBar.Items.GridMode(gridEdit, columnName, functionKey).Visible = True
        Next

        Select Case columnName
            Case Else

        End Select

        functionBar.SetTargetGridControl(gridEdit, columnName)

    End Sub

#End Region

#Region "グリッド制御用メソッド"

    ''' <summary>
    ''' グリッドチェック
    ''' </summary>
    ''' <param name="args"></param>
    ''' <returns></returns>
    ''' <remarks>FocusSwitcherより呼び出される</remarks>
    Private Function Grid_DoCheck(ByVal args As GridCheckMethodArgs) As Boolean

        Dim result As Boolean = True

        If _gridKeyDownCode = Keys.None Then
            _gridKeyDownCode = args.GridEventArgs.Key
        End If

        If args.GridEventArgs.FromColIndex = args.GridEventArgs.ToColIndex AndAlso
           args.GridEventArgs.FromRowIndex = args.GridEventArgs.ToRowIndex Then
            result = True
            GoTo Phase_End
        End If

        If _gridCheckCansel <> 0 Then
            If _gridCheckCansel = -2 Then
                result = True
            Else
                result = False
            End If
            _gridCheckCansel = 0
            GoTo Phase_End
        End If

        '無条件に入力値を確定
        DetailGridEdit.DecideEditData()

        Grid_DoCheck前処理(args)

        If Grid_DoCheckCell(args) = False Then
            If _zeroEnd = True Then
                _zeroEnd = False
                GetFooterTopControl.Focus()
                args.GridEventArgs.Cancel = True
                result = True
                GoTo Phase_End
            End If

            If _changeCell.RowIndex = -1 And _changeCell.ColIndex = -1 Then
                result = False
                GoTo Phase_End
            End If

            If _changeCell.RowIndex <> -1 Then args.GridEventArgs.ToRowIndex = _changeCell.RowIndex
            If _changeCell.ColIndex <> -1 Then
                _changeCell.ColIndex = GetChangeColIndex(args)
                args.GridEventArgs.ToColIndex = _changeCell.ColIndex
            End If
        End If

        Grid_DoCheck確定処理(args)

Phase_End:
        _gridKeyDownCode = Keys.None
        _keyReturn = False
        _gridKeyTab = False

        Return result

    End Function

    ''' <summary>
    ''' グリッド セル毎のチェック
    ''' </summary>
    ''' <param name="args"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function Grid_DoCheckCell(ByVal args As GridCheckMethodArgs) As Boolean

        '移動元セルチェック
        If Grid_DoCheckCellMoveOut() = False Then
            If _zeroEnd AndAlso args.GridEventArgs.ToRowIndex = -1 Then
            Else
                DetailGridEdit.SelectAll()
                DetailGridEdit.UpdateCaretPos(0)
                Display_StatusBar(_fromCell.RowIndex, _fromCell.ColName)
                Return False
            End If
        End If

        '移動元サブグループセルチェック
        If Grid_DoCheckSubGroup() = False Then
            DetailGridEdit.SelectAll()
            DetailGridEdit.UpdateCaretPos(0)
            Return False
        End If

        '移動元行チェック
        If Grid_DoCheckLineMoveOut() = False Then
            If Is確定行加算可否() = True Then
                _maxRowCount = _fromCell.RowIndex + 1
            End If
            If _maxRowCount >= _fromCell.RowIndex + 1 Then
                If _zeroEnd = True Then
                    _zeroEnd = False
                    Return False
                End If
                If args.移動先グループ番号 > 退避情報型.グループ型.No４ Then
                    Return False
                End If
            End If
        End If

        '明細部以外へ移動時はここで終了
        If args.GridEventArgs.ToRowIndex = -1 Then
            Return True
        End If

        '移動先行チェック
        Dim errorRowIndex As Integer = -1
        If Grid_DoCheckLineMoveIn(errorRowIndex) = False Then
            'エラー行が現在行と異なる場合は、エラー行の先頭項目へ
            If _fromCell.RowIndex <> errorRowIndex Then
                _changeCell.RowIndex = errorRowIndex
                _changeCell.ColIndex = DetailGridEdit.GetColumnIndex(GetDetailTopColumnName)
            End If
            Return False
        End If

        '移動先セルチェック
        If Grid_DoCheckCellMoveIn() = False Then
            _changeCell.RowIndex = _fromCell.RowIndex
            _changeCell.ColIndex = _fromCell.ColIndex

            If _toCell.RowIndex <> args.GridEventArgs.ToRowIndex OrElse
               _toCell.ColIndex <> args.GridEventArgs.ToColIndex Then
                If Grid_DoCheckCell(args) = False Then
                    Return False
                End If
                _changeCell.RowIndex = _toCell.RowIndex
                _changeCell.ColIndex = _toCell.ColIndex
            Else
                StatusBar.StatusLabelControl.Text = ""
            End If
            Return False
        End If

        Return True

    End Function

    ''' <summary>
    ''' グリッド 移動先セルチェック
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function Grid_DoCheckCellMoveIn() As Boolean

        Select Case DetailGridEdit.Columns(_toCell.ColIndex).Name
            Case 退避情報型.明細項目型.商品コード.ToString
                If Grid_DoCheckCellMoveIn_商品コード() = False Then
                    Return False
                End If
            Case 退避情報型.明細項目型.商品名.ToString
                If Grid_DoCheckCellMoveIn_商品名() = False Then
                    Return False
                End If
            Case 退避情報型.明細項目型.単位.ToString
                If Grid_DoCheckCellMoveIn_単位() = False Then
                    Return False
                End If

            Case 退避情報型.明細項目型.倉庫コード.ToString
                If Grid_DoCheckCellMoveIn_倉庫コード() = False Then
                    Return False
                End If

            Case 退避情報型.明細項目型.課税区分.ToString
                If Grid_DoCheckCellMoveIn_課税区分() = False Then
                    Return False
                End If
            Case 退避情報型.明細項目型.原単価.ToString
                If Grid_DoCheckCellMoveIn_原単価() = False Then
                    Return False
                End If
            Case 退避情報型.明細項目型.原価金額.ToString
                If Grid_DoCheckCellMoveIn_原価金額() = False Then
                    Return False
                End If
            Case 退避情報型.明細項目型.数量.ToString
                If Grid_DoCheckCellMoveIn_数量() = False Then
                    Return False
                End If
            Case 退避情報型.明細項目型.単価.ToString
                If Grid_DoCheckCellMoveIn_単価() = False Then
                    Return False
                End If
            Case 退避情報型.明細項目型.金額.ToString
                If Grid_DoCheckCellMoveIn_金額() = False Then
                    Return False
                End If

            Case 退避情報型.明細項目型.小計.ToString
                If Grid_DoCheckCellMoveIn_小計() = False Then
                    Return False
                End If

            Case 退避情報型.明細項目型.改頁.ToString
                If Grid_DoCheckCellMoveIn_改頁() = False Then
                    Return False
                End If

            Case Else

        End Select

        Return True

    End Function

    Private Function Grid_DoCheckCellMoveIn_商品コード() As Boolean

        If _zeroEnd = True Then
            Return False
        End If

        Dim 行区分 As Integer = CInt(Val(_退避情報.明細入力部項目(退避情報型.明細項目型.区分)))

        If _gridKeyDownCode = Keys.None Then
            'If 行区分 = 取引区分属性型.メモ Then       'D-CUST20200311 '-20200527-001
            If 行区分 = 行区分型.メモ Then              'A-CUST20200311 '-20200527-001 
                Return False
            End If
            Return True
        End If

        'If 行区分 = 取引区分属性型.メモ Then       'D-CUST20200311 '-20200527-001
        If 行区分 = 行区分型.メモ Then              'A-CUST20200311 '-20200527-001
            If Isグリッド内移動方向(_fromCell, _toCell) = CheckMethodArgs.移動方向型.後へ Then
                _toCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.商品名.ToString)
            Else
                _toCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.区分.ToString)
            End If
            Return False
        End If

        Return True

    End Function

    Private Function Grid_DoCheckCellMoveIn_商品名() As Boolean

        Dim 行区分 As Integer = CInt(Val(_退避情報.明細入力部項目(退避情報型.明細項目型.区分)))

        'マウスクリックは入力可
        If _gridKeyDownCode = Keys.None Then
            Return True
        End If

        If Isグリッド内移動方向(_fromCell, _toCell) = CheckMethodArgs.移動方向型.後へ Then
            If CBool(_退避情報.明細入力部項目(退避情報型.明細項目型.商品コード手入力)) = True Then
                Return True
            End If
            'If 行区分 = 取引区分属性型.メモ Then       'D-CUST20200311 '-20200527-001
            If 行区分 = 行区分型.メモ Then              'A-CUST20200311 '-20200527-001
                Return True
            End If
            _toCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.課税区分.ToString)
            Return False
        End If

        Return True

    End Function

    Private Function Grid_DoCheckCellMoveIn_課税区分() As Boolean

        Dim 行区分 As Integer = CInt(Val(_退避情報.明細入力部項目(退避情報型.明細項目型.区分)))

        If _gridKeyDownCode = Keys.None Then
            'If 行区分 = 取引区分属性型.メモ Then       'D-CUST20200311 '-20200527-001
            If 行区分 = 行区分型.メモ Then              'A-CUST20200311 '-20200527-001
                Return False
            End If
            If Is得意先課税対象() = False Then
                Return False
            End If
            Return True
        End If

        'If 行区分 = 取引区分属性型.メモ Then       'D-CUST20200311 '-20200527-001
        If 行区分 = 行区分型.メモ Then              'A-CUST20200311 '-20200527-001
            If Isグリッド内移動方向(_fromCell, _toCell) = CheckMethodArgs.移動方向型.後へ Then
                _toCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.行摘要.ToString)
            Else
                _toCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.商品名.ToString)
            End If
            Return False
        End If

        If Is得意先課税対象() = False Then
            If Isグリッド内移動方向(_fromCell, _toCell) = CheckMethodArgs.移動方向型.後へ Then
                _toCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.数量.ToString)
            Else
                _toCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.商品コード.ToString)
            End If
            Return False
        Else
            If Isグリッド内移動方向(_fromCell, _toCell) = CheckMethodArgs.移動方向型.後へ Then
                _toCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.数量.ToString)
                Return False
            End If
        End If

        Return True

    End Function

    Private Function Grid_DoCheckCellMoveIn_単位() As Boolean

        Dim 行区分 As Integer = CInt(Val(_退避情報.明細入力部項目(退避情報型.明細項目型.区分)))

        'マウスクリックは入力可
        If _gridKeyDownCode = Keys.None Then
            'If 行区分 = 取引区分属性型.メモ Then       'D-CUST20200311 '-20200527-001
            If 行区分 = 行区分型.メモ Then              'A-CUST20200311 '-20200527-001
                Return False
            End If
            Return True
        End If

        'If 行区分 = 取引区分属性型.メモ Then       'D-CUST20200311 '-20200527-001
        If 行区分 = 行区分型.メモ Then              'A-CUST20200311 '-20200527-001
            If Isグリッド内移動方向(_fromCell, _toCell) = CheckMethodArgs.移動方向型.後へ Then
                _toCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.行摘要.ToString)
            Else
                _toCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.商品名.ToString)
            End If
            Return False
        End If

        If Isグリッド内移動方向(_fromCell, _toCell) = CheckMethodArgs.移動方向型.後へ Then
            _toCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.数量.ToString)
            Return False
        End If

        Return True

    End Function

    Private Function Grid_DoCheckCellMoveIn_倉庫コード() As Boolean

        Dim 行区分 As Integer = CInt(Val(_退避情報.明細入力部項目(退避情報型.明細項目型.区分)))

        'マウスクリックは入力可
        If _gridKeyDownCode = Keys.None Then
            'If 行区分 = 取引区分属性型.メモ Then       'D-CUST20200311 '-20200527-001
            If 行区分 = 行区分型.メモ Then              'A-CUST20200311 '-20200527-001
                Return False
            End If
            Return True
        End If

        If Isグリッド内移動方向(_fromCell, _toCell) = CheckMethodArgs.移動方向型.後へ Then
            _toCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.数量.ToString)
            Return False
        End If

        Return True

    End Function

    Private Function Grid_DoCheckCellMoveIn_数量() As Boolean

        Dim 行区分 As Integer = CInt(Val(_退避情報.明細入力部項目(退避情報型.明細項目型.区分)))

        If _gridKeyDownCode = Keys.None Then
            'If 行区分 = 取引区分属性型.メモ Then       'D-CUST20200311 '-20200527-001
            If 行区分 = 行区分型.メモ Then              'A-CUST20200311 '-20200527-001
                Return False
            End If
            Return True
        End If

        'If 行区分 = 取引区分属性型.メモ Then       'D-CUST20200311 '-20200527-001
        If 行区分 = 行区分型.メモ Then              'A-CUST20200311 '-20200527-001
            If Isグリッド内移動方向(_fromCell, _toCell) = CheckMethodArgs.移動方向型.後へ Then
                _toCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.行摘要.ToString)
            Else
                _toCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.商品名.ToString)
            End If
            Return False
        End If

        Return True

    End Function

    Private Function Grid_DoCheckCellMoveIn_原単価() As Boolean

        Dim 行区分 As Integer = CInt(Val(_退避情報.明細入力部項目(退避情報型.明細項目型.区分)))
        Dim 数量 As Decimal = CDec(_退避情報.明細入力部項目(退避情報型.明細項目型.数量))
        'A-CUST20200311↓ '-20200527-001
        _退避情報.行区分 = CType(_退避情報.明細入力部項目(退避情報型.明細項目型.行区分マスター情報), DataTable)
        Dim 取引区分属性 As Integer = CInt(Val(_退避情報.行区分項目("CUSCE03005")))
        'A-CUST20200311↑ '-20200527-001

        If _gridKeyDownCode = Keys.None Then
            'If 行区分 = 取引区分属性型.値引 Then           'D-CUST20200311 '-20200527-001
            If 取引区分属性 = 取引区分属性型.値引 Then    　'A-CUST20200311 '-20200527-001
                Return False
            End If
            'If 行区分 = 取引区分属性型.メモ Then       'D-CUST20200311 '-20200527-001
            If 行区分 = 行区分型.メモ Then              'A-CUST20200311 '-20200527-001
                Return False
            End If
            If 数量 = 0 Then
                Return False
            End If
            Return True
        End If

        'If 行区分 = 取引区分属性型.値引 Then           'D-CUST20200311 '-20200527-001
        If 取引区分属性 = 取引区分属性型.値引 Then    　'A-CUST20200311 '-20200527-001
            If Isグリッド内移動方向(_fromCell, _toCell) = CheckMethodArgs.移動方向型.後へ Then
                _toCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.単価.ToString)
            Else
                _toCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.商品コード.ToString)
            End If
            Return False
        End If

        'D-CUST20200311↓ '-20200527-001
        'If 行区分 <> 取引区分属性型.見本 Then
        '    If CBool(_退避情報.明細入力部項目(退避情報型.明細項目型.商品コード手入力)) = False Then
        '        If Isグリッド内移動方向(_fromCell, _toCell) = CheckMethodArgs.移動方向型.後へ Then
        '            _fromCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.原単価.ToString)
        '            _toCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.単価.ToString)
        '            Return False
        '        End If
        '    End If
        'End If
        'D-CUST20200311↑ '-20200527-001

        'If 行区分 = 取引区分属性型.メモ Then       'D-CUST20200311 '-20200527-001
        If 行区分 = 行区分型.メモ Then              'A-CUST20200311 '-20200527-001
            If Isグリッド内移動方向(_fromCell, _toCell) = CheckMethodArgs.移動方向型.後へ Then
                _toCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.行摘要.ToString)
            Else
                _toCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.商品名.ToString)
            End If
            Return False
        End If

        If 数量 = 0 Then
            If Isグリッド内移動方向(_fromCell, _toCell) = CheckMethodArgs.移動方向型.後へ Then
                _toCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.原価金額.ToString)
            Else
                _toCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.数量.ToString)
            End If
            Return False
        End If

        Return True

    End Function

    Private Function Grid_DoCheckCellMoveIn_原価金額() As Boolean

        Dim 行区分 As Integer = CInt(Val(_退避情報.明細入力部項目(退避情報型.明細項目型.区分)))
        Dim 数量 As Decimal = CDec(_退避情報.明細入力部項目(退避情報型.明細項目型.数量))
        Dim 原単価 As Decimal = CDec(_退避情報.明細入力部項目(退避情報型.明細項目型.原単価))
        'A-CUST20200311↓ '-20200527-001
        _退避情報.行区分 = CType(_退避情報.明細入力部項目(退避情報型.明細項目型.行区分マスター情報), DataTable)
        Dim 取引区分属性 As Integer = CInt(Val(_退避情報.行区分項目("CUSCE03005")))
        'A-CUST20200311↑ '-20200527-001

        If _gridKeyDownCode = Keys.None Then
            'If 行区分 = 取引区分属性型.値引 Then        'D-CUST20200311 '-20200527-001   
            If 取引区分属性 = 取引区分属性型.値引 Then   'A-CUST20200311 '-20200527-001  
                Return False
            End If
            'If 行区分 = 取引区分属性型.メモ Then        'D-CUST20200311 '-20200527-001
            If 行区分 = 行区分型.メモ Then               'A-CUST20200311 '-20200527-001
                Return False
            End If
            If 数量 <> 0 AndAlso 原単価 <> 0 Then
                Return False
            End If
            Return True
        End If

        'If 行区分 = 取引区分属性型.値引 Then        'D-CUST20200311 '-20200527-001   
        If 取引区分属性 = 取引区分属性型.値引 Then   'A-CUST20200311 '-20200527-001  
            If Isグリッド内移動方向(_fromCell, _toCell) = CheckMethodArgs.移動方向型.後へ Then
                _toCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.単価.ToString)
            Else
                _toCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.数量.ToString)
            End If
            Return False
        End If

        'If 行区分 = 取引区分属性型.メモ Then       'D-CUST20200311 '-20200527-001
        If 行区分 = 行区分型.メモ Then              'A-CUST20200311 '-20200527-001
            If Isグリッド内移動方向(_fromCell, _toCell) = CheckMethodArgs.移動方向型.後へ Then
                _toCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.行摘要.ToString)
            Else
                _toCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.商品名.ToString)
            End If
            Return False
        End If

        If 数量 <> 0 AndAlso 原単価 <> 0 Then
            If Isグリッド内移動方向(_fromCell, _toCell) = CheckMethodArgs.移動方向型.後へ Then
                'D-CUST20200311↓ '-20200527-001
                'If 行区分 = 取引区分属性型.見本 Then
                '    _toCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.行摘要.ToString)
                'Else
                '    _toCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.単価.ToString)
                'End If
                'D-CUST20200311↑ '-20200527-001
                'A-CUST20200311↓ '-20200527-001
                _toCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.単価.ToString)
                'A-CUST20200311↑ '-20200527-001
            Else
                _toCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.原単価.ToString)
            End If
            Return False
        End If

        Return True

    End Function

    Private Function Grid_DoCheckCellMoveIn_単価() As Boolean

        Dim 行区分 As Integer = CInt(Val(_退避情報.明細入力部項目(退避情報型.明細項目型.区分)))
        Dim 数量 As Decimal = CDec(_退避情報.明細入力部項目(退避情報型.明細項目型.数量))

        If _gridKeyDownCode = Keys.None Then
            'D-CUST20200311↓ '-20200527-001
            'If 行区分 = 取引区分属性型.見本 Then
            '    Return False
            'End If
            'D-CUST20200311↑ '-20200527-001
            'If 行区分 = 取引区分属性型.メモ Then       'D-CUST20200311 '-20200527-001
            If 行区分 = 行区分型.メモ Then              'A-CUST20200311 '-20200527-001
                Return False
            End If
            If 数量 = 0 Then
                Return False
            End If
            Return True
        End If
        'D-CUST20200311↓ '-20200527-001
        'If 行区分 = 取引区分属性型.見本 Then
        '    If Isグリッド内移動方向(_fromCell, _toCell) = CheckMethodArgs.移動方向型.後へ Then
        '        _toCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.行摘要.ToString)
        '    End If

        '    Return False
        'End If
        'D-CUST20200311↑ '-20200527-001

        'If 行区分 = 取引区分属性型.メモ Then       'D-CUST20200311 '-20200527-001
        If 行区分 = 行区分型.メモ Then              'A-CUST20200311 '-20200527-001
            If Isグリッド内移動方向(_fromCell, _toCell) = CheckMethodArgs.移動方向型.後へ Then
                _toCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.行摘要.ToString)
            Else
                _toCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.商品名.ToString)
            End If
            Return False
        End If

        If 数量 = 0 Then
            If Isグリッド内移動方向(_fromCell, _toCell) = CheckMethodArgs.移動方向型.後へ Then
                _toCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.金額.ToString)
            Else
                _toCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.原価金額.ToString)
            End If
            Return False
        End If

        Return True

    End Function

    Private Function Grid_DoCheckCellMoveIn_金額() As Boolean

        Dim 行区分 As Integer = CInt(Val(_退避情報.明細入力部項目(退避情報型.明細項目型.区分)))
        Dim 数量 As Decimal = CDec(_退避情報.明細入力部項目(退避情報型.明細項目型.数量))
        Dim 単価 As Decimal = CDec(_退避情報.明細入力部項目(退避情報型.明細項目型.単価))
        Dim 原単価 As Decimal = CDec(_退避情報.明細入力部項目(退避情報型.明細項目型.原単価))

        If _gridKeyDownCode = Keys.None Then
            'D-CUST20200311↓ '-20200527-001
            'If 行区分 = 取引区分属性型.見本 Then
            '    Return False
            'End If
            'D-CUST20200311↑ '-20200527-001
            'If 行区分 = 取引区分属性型.メモ Then       'D-CUST20200311 '-20200527-001
            If 行区分 = 行区分型.メモ Then              'A-CUST20200311 '-20200527-001
                Return False
            End If
            If 数量 <> 0 AndAlso 単価 <> 0 Then
                Return False
            End If
        End If

        'D-CUST20200311↓ '-20200527-001
        'If 行区分 = 取引区分属性型.見本 Then
        '    If Isグリッド内移動方向(_fromCell, _toCell) = CheckMethodArgs.移動方向型.前へ Then
        '        If 原単価 = 0 AndAlso Isセル状態_ReadOnly(DetailGridEdit, _toCell.RowIndex, 退避情報型.明細項目型.原価金額.ToString) = False Then
        '            _toCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.原価金額.ToString)
        '        Else
        '            If Isセル状態_ReadOnly(DetailGridEdit, _toCell.RowIndex, 退避情報型.明細項目型.原単価.ToString) = False Then
        '                _toCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.原単価.ToString)
        '            Else
        '                _toCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.数量.ToString)
        '            End If
        '        End If
        '    End If
        '    Return False
        'End If
        'D-CUST20200311↑ '-20200527-001

        'If 行区分 = 取引区分属性型.メモ Then       'D-CUST20200311 '-20200527-001
        If 行区分 = 行区分型.メモ Then              'A-CUST20200311 '-20200527-001
            If Isグリッド内移動方向(_fromCell, _toCell) = CheckMethodArgs.移動方向型.後へ Then
                _toCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.行摘要.ToString)
            Else
                _toCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.商品名.ToString)
            End If
            Return False
        End If

        If 数量 <> 0 AndAlso 単価 <> 0 Then
            If Isグリッド内移動方向(_fromCell, _toCell) = CheckMethodArgs.移動方向型.後へ Then
                _toCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.行摘要.ToString)
            Else
                _toCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.単価.ToString)
            End If
            Return False
        End If


        Return True

    End Function

    Private Function Grid_DoCheckCellMoveIn_小計() As Boolean

        Return True

    End Function

    Private Function Grid_DoCheckCellMoveIn_改頁() As Boolean

        Return True

    End Function

    ''' <summary>
    ''' グリッド 移動元セルチェック
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function Grid_DoCheckCellMoveOut() As Boolean

        _checkMode = CheckType.DoCheckControl

        'グリッド以外へ移動又は、前に戻る場合はチェックしない
        If Isグリッド内移動方向(_fromCell, _toCell) = CheckMethodArgs.移動方向型.前へ Then
            Return True
        End If

        Select Case DetailGridEdit.Columns(_fromCell.ColIndex).Name
            Case 退避情報型.明細項目型.行.ToString
                If Grid_DoCheckCellMoveOut_行() = False Then
                    Return False
                End If
            Case 退避情報型.明細項目型.区分.ToString
                If Grid_DoCheckCellMoveOut_区分() = False Then
                    Return False
                End If
            Case 退避情報型.明細項目型.商品コード.ToString
                If Grid_DoCheckCellMoveOut_商品コード() = False Then
                    Return False
                End If
            Case 退避情報型.明細項目型.商品名.ToString
                If Grid_DoCheckCellMoveOut_商品名() = False Then
                    Return False
                End If
            Case 退避情報型.明細項目型.課税区分.ToString
                If Grid_DoCheckCellMoveOut_課税区分() = False Then
                    Return False
                End If
            Case 退避情報型.明細項目型.単位.ToString
                If Grid_DoCheckCellMoveOut_単位() = False Then
                    Return False
                End If
            Case 退避情報型.明細項目型.倉庫コード.ToString
                If Grid_DoCheckCellMoveOut_倉庫コード() = False Then
                    Return False
                End If
            Case 退避情報型.明細項目型.原単価.ToString
                If Grid_DoCheckCellMoveOut_原単価() = False Then
                    Return False
                End If
            Case 退避情報型.明細項目型.数量.ToString
                If Grid_DoCheckCellMoveOut_数量() = False Then
                    Return False
                End If
            Case 退避情報型.明細項目型.単価.ToString
                If Grid_DoCheckCellMoveOut_単価() = False Then
                    Return False
                End If
            Case 退避情報型.明細項目型.金額.ToString
                If Grid_DoCheckCellMoveOut_金額() = False Then
                    Return False
                End If
            Case 退避情報型.明細項目型.行摘要.ToString
                If Grid_DoCheckCellMoveOut_行摘要() = False Then
                    Return False
                End If

            Case Else

        End Select

        Return True

    End Function

    Private Function Grid_DoCheckCellMoveOut_行() As Boolean

        Dim Gyo As Integer = CInt(Val(DetailGridEdit.GetData(_fromCell.RowIndex, 退避情報型.明細項目型.行.ToString)))
        Dim 行区分 As Integer = CInt(Val(_退避情報.明細入力部項目(退避情報型.明細項目型.区分)))

        Dim ClearFlg As Boolean = False

        If Val(_退避情報.明細入力部項目(退避情報型.明細項目型.行)) <> 0 And
           Val(_退避情報.明細入力部項目(退避情報型.明細項目型.行)) = Gyo Then
            If _fromCell.ColIndex = 退避情報型.明細項目型.行 Then
                DetailGridEdit.CurrentEditValue = _退避情報.明細入力部項目(退避情報型.明細項目型.行)  '行をクリアされても戻す
            End If
            Return True
        End If

        '入力行＞明細部の行+1の場合エラー
        If Gyo > _maxRowCount + 1 OrElse Gyo > _limitMaxRow Then
            StatusBar.StatusLabelControl.Text = メッセージ定数型.MASSAGE_A03
            Return False
        End If

        If Gyo = 0 And _maxRowCount = _limitMaxRow Then
            Return True
        End If

        '商品コード入力済みで変更時、確認
        Dim RowDelete As Boolean = False
        Dim is判定 As Boolean = False
        'If 行区分 = 取引区分属性型.メモ Then       'D-CUST20200311 '-20200527-001
        If 行区分 = 行区分型.メモ Then              'A-CUST20200311 '-20200527-001
            is判定 = True
        Else
            If Is省略判定(コード判定対象型.商品コード, CStr(_退避情報.明細入力部項目(退避情報型.明細項目型.商品コード))) = 省略判定結果型.入力 And
               Gyo <> Val(_退避情報.明細入力部項目(退避情報型.明細項目型.行)) Then
                is判定 = True
            End If
        End If

        If is判定 Then
            'If MyBase.MessageViewer.Show(1006, "OTS", IMessageViewer.DefaultButtonType.No) = IMessageViewer.ShowResultType.No Then      'D-CUST20230315
            If MyBase.MessageViewer.Show(999000005, "OTS", IMessageViewer.DefaultButtonType.No) = IMessageViewer.ShowResultType.No Then  'A-CUST20230315
                DetailGridEdit.CurrentEditValue = _退避情報.明細入力部項目(退避情報型.明細項目型.行)
                Return False
            End If
            ClearFlg = True
        End If

        '表示
        If Gyo = 0 Then

            Gyo = _maxRowCount + 1
            DetailGridEdit.SetData(0, 退避情報型.明細項目型.行, Gyo)
            SetNewGridRow(True)

            _現在入力行 = _maxRowCount

        ElseIf Gyo > _maxRowCount Then

            '新規行の追加
            SetNewGridRow(True)

            _現在入力行 = _maxRowCount     '0スタートの為

        Else
            明細部表示処理(Gyo - 1)
        End If

        '-------------
        '  確定処理
        '-------------
        _退避情報.明細入力部項目(退避情報型.明細項目型.行) = Gyo

        DetailGridView.TopIndex = _現在入力行 - 1
        If _現在入力行 >= _maxRowCount Then
            DetailGridView.ClearSelectedState()
        Else
            DetailGridView.ChangeSelectedState(_現在入力行)
        End If

        Return True

    End Function

    Private Function Grid_DoCheckCellMoveOut_区分() As Boolean

        Dim returnValue As Boolean = True
        Dim Kubun As String = CStr(DetailGridEdit.GetData(_fromCell.RowIndex, 退避情報型.明細項目型.区分.ToString))

        If Val(Kubun) = 0 Then
            Grid_MessageViewerShow(72)
            Return False
        End If

        If Kubun = CStr(_退避情報.明細入力部項目(退避情報型.明細項目型.区分)) Then
            Return True
        End If

        If Grid_DoCheckCell_区分(Kubun) = False Then
            Return False
        End If


        '-------------
        '  確定処理
        '-------------
        'D-CUST20200311↓ '-20200527-001
        'Select Case Val(_退避情報.明細入力部項目(退避情報型.明細項目型.区分))
        '    Case 取引区分属性型.値引
        '        _退避情報.明細入力部項目(退避情報型.明細項目型.原単価) = 0
        '        _退避情報.明細入力部項目(退避情報型.明細項目型.原価金額) = 0
        '        DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.原単価.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.原単価))
        '        DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.原価金額.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.原価金額))
        '    Case 取引区分属性型.見本
        '        _退避情報.明細入力部項目(退避情報型.明細項目型.単価) = 0
        '        _退避情報.明細入力部項目(退避情報型.明細項目型.金額) = 0
        '        _退避情報.明細入力部項目(退避情報型.明細項目型.内消費税額) = 0
        '        DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.単価.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.単価))
        '        DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.金額.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.金額))
        '    Case 取引区分属性型.メモ
        '        _退避情報.明細入力部項目(退避情報型.明細項目型.商品コード) = ""
        '        _退避情報.明細入力部項目(退避情報型.明細項目型.商品名) = ""
        '        _退避情報.ClearDataTable商品()
        '        _退避情報.明細入力部項目(退避情報型.明細項目型.商品マスター情報) = _退避情報.商品
        '        _退避情報.明細入力部項目(退避情報型.明細項目型.課税区分) = ""
        '        _退避情報.明細入力部項目(退避情報型.明細項目型.課税区分名) = ""
        '        _退避情報.明細入力部項目(退避情報型.明細項目型.倉庫コード) = ""
        '        _退避情報.明細入力部項目(退避情報型.明細項目型.倉庫名) = ""
        '        _退避情報.明細入力部項目(退避情報型.明細項目型.原単価) = 0
        '        _退避情報.明細入力部項目(退避情報型.明細項目型.原価金額) = 0
        '        _退避情報.明細入力部項目(退避情報型.明細項目型.単位) = ""
        '        _退避情報.明細入力部項目(退避情報型.明細項目型.数量) = 0
        '        _退避情報.明細入力部項目(退避情報型.明細項目型.単価) = 0
        '        _退避情報.明細入力部項目(退避情報型.明細項目型.金額) = 0
        '        _退避情報.明細入力部項目(退避情報型.明細項目型.内消費税額) = 0
        '        DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.商品コード.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.商品コード))
        '        DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.商品名.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.商品名))
        '        DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.課税区分.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.課税区分))
        '        DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.課税区分名.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.課税区分名))
        '        DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.倉庫コード.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.倉庫コード))
        '        DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.倉庫名.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.倉庫名))
        '        DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.原単価.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.原単価))
        '        DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.原価金額.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.原価金額))
        '        DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.単位.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.単位))
        '        DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.数量.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.数量))
        '        DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.単価.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.単価))
        '        DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.金額.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.金額))

        'End Select
        'D-CUST20200311↑ '-20200527-001
        'A-CUST20200311↓ '-20200527-001
        If Val(_退避情報.明細入力部項目(退避情報型.明細項目型.区分)) = 行区分型.メモ Then
            _退避情報.明細入力部項目(退避情報型.明細項目型.商品コード) = ""
            _退避情報.明細入力部項目(退避情報型.明細項目型.商品名) = ""
            _退避情報.ClearDataTable商品()
            _退避情報.明細入力部項目(退避情報型.明細項目型.商品マスター情報) = _退避情報.商品
            _退避情報.明細入力部項目(退避情報型.明細項目型.課税区分) = ""
            _退避情報.明細入力部項目(退避情報型.明細項目型.課税区分名) = ""
            _退避情報.明細入力部項目(退避情報型.明細項目型.倉庫コード) = ""
            _退避情報.明細入力部項目(退避情報型.明細項目型.倉庫名) = ""
            _退避情報.明細入力部項目(退避情報型.明細項目型.原単価) = 0
            _退避情報.明細入力部項目(退避情報型.明細項目型.原価金額) = 0
            _退避情報.明細入力部項目(退避情報型.明細項目型.単位) = ""
            _退避情報.明細入力部項目(退避情報型.明細項目型.数量) = 0
            _退避情報.明細入力部項目(退避情報型.明細項目型.単価) = 0
            _退避情報.明細入力部項目(退避情報型.明細項目型.金額) = 0
            _退避情報.明細入力部項目(退避情報型.明細項目型.内消費税額) = 0
            DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.商品コード.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.商品コード))
            DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.商品名.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.商品名))
            DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.課税区分.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.課税区分))
            DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.課税区分名.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.課税区分名))
            DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.倉庫コード.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.倉庫コード))
            DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.倉庫名.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.倉庫名))
            DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.原単価.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.原単価))
            DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.原価金額.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.原価金額))
            DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.単位.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.単位))
            DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.数量.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.数量))
            DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.単価.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.単価))
            DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.金額.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.金額))

        Else
            Select Case CInt(Val(_退避情報.行区分項目("CUSCE03005")))
                Case 取引区分属性型.値引
                    _退避情報.明細入力部項目(退避情報型.明細項目型.原単価) = 0
                    _退避情報.明細入力部項目(退避情報型.明細項目型.原価金額) = 0
                    DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.原単価.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.原単価))
                    DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.原価金額.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.原価金額))
                Case Else
            End Select
        End If
        'A-CUST20200311↑ '-20200527-001

        If Is商品確定済判定(_fromCell.RowIndex) = True Then
            _退避情報.明細入力部項目(退避情報型.明細項目型.商品コード) = ""
            returnValue = Grid_DoCheckCellMoveOut_商品コード()
        End If

        Return True
    End Function

    Private Function Grid_DoCheckCell_区分(ByVal Kubun As String, Optional Message As Boolean = True) As Boolean

        '区分マスターRead
        Dim param As New ReadParam
        With param
            .Container(ReadParam.項目名型.種別) = Get区分マスター種別値(区分マスター型.区分)
            .Container(ReadParam.項目名型.区分コード) = Kubun
        End With
        If ReadMaster_区分マスター(param) = False Then
            If Message = True Then
                Grid_MessageViewerShow(41)
            End If
            Return False
        End If

        'If Is入力可能行区分(CInt(Val(Kubun))) = False Then                                                    'D-CUST20200311 '-20200527-001
        If Is入力可能行区分(CInt(Val(Kubun)), CInt(Val(_退避情報.行区分項目("CUSCE03005")))) = False Then        'A-CUST20200311 '-20200527-001
            If Message = True Then
                Grid_MessageViewerShow(-5)
            End If
            Return False
        End If

        '-------------
        '  確定処理
        '-------------
        _退避情報.明細入力部項目(退避情報型.明細項目型.区分) = Kubun
        '_退避情報.明細入力部項目(退避情報型.明細項目型.区分名) = _退避情報.区分項目("CUSCE03004")          'D-CUST20200311 '-2020527-001
        _退避情報.明細入力部項目(退避情報型.明細項目型.区分名) = _退避情報.行区分項目("CUSCE03004")         'A-CUST20200311 '-2020527-001 
        _退避情報.明細入力部項目(退避情報型.明細項目型.行区分マスター情報) = _退避情報.行区分               'A-CUST20200311 '-2020527-001 
        DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.区分名.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.区分名))

        Return True

    End Function

    Private Function Grid_DoCheckCellMoveOut_商品コード() As Boolean

        Dim shouhinCode As String = CStr(DetailGridEdit.GetData(_fromCell.RowIndex, 退避情報型.明細項目型.商品コード.ToString)).TrimEnd

        Dim 行区分 As Integer = CInt(Val(_退避情報.明細入力部項目(退避情報型.明細項目型.区分)))
        'A-CUST20200311↓ '-20200527-001
        _退避情報.行区分 = CType(_退避情報.明細入力部項目(退避情報型.明細項目型.行区分マスター情報), DataTable)
        Dim 取引区分属性 As Integer = CInt(Val(_退避情報.行区分項目("CUSCE03005")))
        'D-CUST20200311↓ '-20200527-001

        'If 行区分 = 取引区分属性型.メモ Then       'D-CUST20200311 '-20200527-001
        If 行区分 = 行区分型.メモ Then              'A-CUST20200311 '-20200527-001
            Return True
        End If

        If Is省略判定(コード判定対象型.商品コード, shouhinCode) = 省略判定結果型.省略 Then
            Grid_MessageViewerShow(72)
            Return False
        End If

        If Is等式判定(コード判定対象型.商品コード,
                      shouhinCode,
                      CStr(_退避情報.明細入力部項目(退避情報型.明細項目型.商品コード))) = 等式判定結果型.等しい Then
            Return True
        End If

        '商品マスターRead
        Dim param As New ReadParam
        With param
            .Container(ReadParam.項目名型.商品コード) = shouhinCode
            If Is得意先課税対象() = False Then
                .Container(ReadParam.項目名型.区分コード) = "03"
            End If
        End With
        If ReadMaster_商品(param) = False Then
            Grid_MessageViewerShow(41)
            Return False
        End If

        '各種退避情報の保存
        Dim 退避_明細情報 As DataTable = _退避情報.明細表示部.Copy
        _退避情報.明細入力部項目(退避情報型.明細項目型.商品マスター情報) = _退避情報.商品.Copy

        '-------------
        '  確定処理
        '-------------
        DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.商品コード.ToString, CStr(_退避情報.明細入力部項目_商品情報("CUSME03001")))
        _退避情報.明細入力部項目(退避情報型.明細項目型.商品コード) = DetailGridEdit.GetData(_fromCell.RowIndex, 退避情報型.明細項目型.商品コード.ToString)
        If shouhinCode = _退避情報.手入力_商品コード Then
            '_退避情報.明細入力部項目(退避情報型.明細項目型.商品名) = CStr(_退避情報.明細入力部項目_商品情報("CUSME03002"))     'D-CUST20210906_02
            _退避情報.明細入力部項目(退避情報型.明細項目型.商品名) = ""                                                         'A-CUST20210906_02
            _退避情報.明細入力部項目(退避情報型.明細項目型.商品コード手入力) = True
        Else
            _退避情報.明細入力部項目(退避情報型.明細項目型.商品名) = CStr(_退避情報.明細入力部項目_商品情報("CUSME03002"))
            _退避情報.明細入力部項目(退避情報型.明細項目型.商品コード手入力) = False
        End If
        DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.商品名.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.商品名))

        'マスター情報の退避
        _退避情報.明細入力部項目(退避情報型.明細項目型.商品マスター情報) = _退避情報.商品


        '単位
        _退避情報.明細入力部項目(退避情報型.明細項目型.単位) = CStr(_退避情報.明細入力部項目_商品情報("CUSME03003"))
        DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.単位.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.単位))

        '原単価
        'If CInt(Val(_退避情報.明細入力部項目(退避情報型.明細項目型.区分))) <> 取引区分属性型.値引 Then       'D-CUST20200311 '-20200527-001  
        If 取引区分属性 <> 取引区分属性型.値引 Then                                                           'A-CUST20200311 '-20200527-001
            _退避情報.明細入力部項目(退避情報型.明細項目型.原単価) = GetGenTanka(CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.伝票日付)))
        Else
            _退避情報.明細入力部項目(退避情報型.明細項目型.原単価) = 0
        End If
        DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.原単価.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.原単価))

        '課税区分
        _退避情報.明細入力部項目(退避情報型.明細項目型.課税区分) = CStr(_退避情報.課税区分項目("CUSCE03002"))
        _退避情報.明細入力部項目(退避情報型.明細項目型.課税区分名) = CStr(_退避情報.課税区分項目("CUSCE03003"))
        _退避情報.明細入力部項目(退避情報型.明細項目型.課税区分マスター情報) = _退避情報.課税区分
        DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.課税区分.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.課税区分))
        DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.課税区分名.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.課税区分名))

        '倉庫コード
        If Is省略判定(コード判定対象型.倉庫コード, CStr(_退避情報.明細入力部項目(退避情報型.明細項目型.倉庫コード))) = 省略判定結果型.省略 Then
            _退避情報.明細入力部項目(退避情報型.明細項目型.倉庫コード) = CStr(_退避情報.倉庫項目("CUSME06001"))
            _退避情報.明細入力部項目(退避情報型.明細項目型.倉庫名) = CStr(_退避情報.倉庫項目("CUSME06003"))
            _退避情報.明細入力部項目(退避情報型.明細項目型.倉庫マスター情報) = _退避情報.倉庫
            DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.倉庫コード.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.倉庫コード))
            DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.倉庫名.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.倉庫名))
        End If

        '単価

        'D-CUST20200311↓ '-20200527-001
        'If CInt(Val(_退避情報.明細入力部項目(退避情報型.明細項目型.区分))) <> 取引区分属性型.見本 And
        '   CInt(Val(_退避情報.明細入力部項目(退避情報型.明細項目型.区分))) <> 取引区分属性型.値引 Then
        'D-CUST20200311↑ '-20200527-001
        'A-CUST20200311↓ '-20200527-001
        If 取引区分属性 <> 取引区分属性型.値引 Then
            'A-CUST20200311↑ '-20200527-001
            _退避情報.明細入力部項目(退避情報型.明細項目型.単価) = GetTanka(CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.伝票日付)))
        Else
            _退避情報.明細入力部項目(退避情報型.明細項目型.単価) = 0
            _退避情報.明細入力部項目(退避情報型.明細項目型.単価計算方法) = IUnitPriceReader.単価計算方法型.標準売上単価  'A-CUST20211001
        End If
        DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.単価.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.単価))

        _getGenZaikoLine = -1

        Return True

    End Function

    Private Function Grid_DoCheckCellMoveOut_商品名() As Boolean

        Dim shohinName As String = CStr(DetailGridEdit.GetData(_fromCell.RowIndex, 退避情報型.明細項目型.商品名.ToString))

        _退避情報.明細入力部項目(退避情報型.明細項目型.商品名) = shohinName

        Return True

    End Function

    Private Function Grid_DoCheckCellMoveOut_課税区分() As Boolean

        Dim 行区分 As Integer = CInt(Val(_退避情報.明細入力部項目(退避情報型.明細項目型.区分)))

        'If 行区分 = 取引区分属性型.メモ Then       'D-CUST20200311 '-20200527-001
        If 行区分 = 行区分型.メモ Then              'A-CUST20200311 '-20200527-001
            Return True
        End If

        Dim Kubun As String = CStr(DetailGridEdit.GetData(_fromCell.RowIndex, 退避情報型.明細項目型.課税区分.ToString))

        If Val(Kubun) = 0 Then
            Grid_MessageViewerShow(72)
            Return False
        End If

        If Kubun = CStr(_退避情報.明細入力部項目(退避情報型.明細項目型.課税区分)) Then
            Return True
        End If

        '区分マスターRead
        Dim param As New ReadParam
        With param
            .Container(ReadParam.項目名型.種別) = Get区分マスター種別値(区分マスター型.課税区分)
            .Container(ReadParam.項目名型.区分コード) = Kubun
        End With
        If ReadMaster_区分マスター(param) = False Then
            Grid_MessageViewerShow(41)
            Return False
        End If

        '-------------
        '  確定処理
        '-------------
        _退避情報.明細入力部項目(退避情報型.明細項目型.課税区分) = Kubun
        _退避情報.明細入力部項目(退避情報型.明細項目型.課税区分名) = _退避情報.課税区分項目("CUSCE03003")
        _退避情報.明細入力部項目(退避情報型.明細項目型.課税区分マスター情報) = _退避情報.課税区分
        DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.課税区分名.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.課税区分名))

        Return True

    End Function

    Private Function Grid_DoCheckCellMoveOut_単位() As Boolean

        Dim tani As String = CStr(DetailGridEdit.GetData(_fromCell.RowIndex, 退避情報型.明細項目型.単位.ToString))

        Dim 行区分 As Integer = CInt(Val(_退避情報.明細入力部項目(退避情報型.明細項目型.区分)))

        'If 行区分 = 取引区分属性型.メモ Then       'D-CUST20200311 '-20200527-001
        If 行区分 = 行区分型.メモ Then              'A-CUST20200311 '-20200527-001
            Return True
        End If

        '確定
        _退避情報.明細入力部項目(退避情報型.明細項目型.単位) = tani

        Return True

    End Function

    Private Function Grid_DoCheckCellMoveOut_倉庫コード() As Boolean

        Dim sokoCode As String = CStr(DetailGridEdit.GetData(_fromCell.RowIndex, 退避情報型.明細項目型.倉庫コード.ToString))

        Dim 行区分 As Integer = CInt(Val(_退避情報.明細入力部項目(退避情報型.明細項目型.区分)))

        'If 行区分 = 取引区分属性型.メモ Then       'D-CUST20200311 '-20200527-001
        If 行区分 = 行区分型.メモ Then              'A-CUST20200311 '-20200527-001
            Return True
        End If

        '省略可
        If Is省略判定(コード判定対象型.倉庫コード, sokoCode) = 省略判定結果型.省略 Then
            _退避情報.ClearDataTable倉庫()
            _退避情報.明細入力部項目(退避情報型.明細項目型.倉庫マスター情報) = _退避情報.倉庫
            _退避情報.明細入力部項目(退避情報型.明細項目型.倉庫コード) = ""
            _退避情報.明細入力部項目(退避情報型.明細項目型.倉庫名) = ""
            DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.倉庫コード.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.倉庫コード))
            DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.倉庫名.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.倉庫名))
            Return True
        End If

        If Is等式判定(コード判定対象型.倉庫コード,
                      sokoCode,
                      CStr(_退避情報.明細入力部項目(退避情報型.明細項目型.倉庫コード))) = 等式判定結果型.等しい Then
            Return True
        End If

        '倉庫マスターRead
        Dim param As New ReadParam
        With param
            .Container(ReadParam.項目名型.倉庫コード) = sokoCode
        End With
        If ReadMaster_倉庫マスター(param) = False Then
            Grid_MessageViewerShow(41)
            Return False
        End If

        '-------------
        '  確定処理
        '-------------
        Dim returnValue As Boolean = True

        _退避情報.明細入力部項目(退避情報型.明細項目型.倉庫コード) = sokoCode
        _退避情報.明細入力部項目(退避情報型.明細項目型.倉庫名) = CStr(_退避情報.倉庫項目("CUSME06003"))
        DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.倉庫コード.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.倉庫コード))
        DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.倉庫名.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.倉庫名))

        _退避情報.明細入力部項目(退避情報型.明細項目型.倉庫マスター情報) = _退避情報.倉庫

        _getGenZaikoLine = -1

        Return returnValue

    End Function

    Private Function Grid_DoCheckCellMoveOut_数量() As Boolean

        Dim suryo As Decimal = CDec(DetailGridEdit.GetData(_fromCell.RowIndex, 退避情報型.明細項目型.数量.ToString))

        Dim 行区分 As Integer = CInt(Val(_退避情報.明細入力部項目(退避情報型.明細項目型.区分)))

        'If 行区分 = 取引区分属性型.メモ Then       'D-CUST20200311 '-20200527-001
        If 行区分 = 行区分型.メモ Then              'A-CUST20200311 '-20200527-001
            Return True
        End If
        'D-CUST20200311↓ '-20200527-001
        'If CInt(Val(_退避情報.明細入力部項目(退避情報型.明細項目型.区分))) = 取引区分属性型.見本 Then
        '    If suryo = 0 Then
        '        Grid_MessageViewerShow(72)
        '        Return False
        '    End If
        'End If
        'D-CUST20200311↑ '-20200527-001

        'A-CUST20211001↓
        If suryo = CDec(_退避情報.明細入力部項目(退避情報型.明細項目型.数量)) Then
            Return True
        End If
        'A-CUST20211001↑

        '確定
        _退避情報.明細入力部項目(退避情報型.明細項目型.数量) = suryo

        'A-CUST20211001↓
        '単価
        Dim 取引区分属性 As Integer = CInt(Val(_退避情報.行区分項目("CUSCE03005")))
        If 取引区分属性 <> 取引区分属性型.見本 AndAlso
           取引区分属性 <> 取引区分属性型.値引 Then
            Dim 単価計算方法 As IUnitPriceReader.単価計算方法型 = CType(Val(_退避情報.明細入力部項目(退避情報型.明細項目型.単価計算方法)), IUnitPriceReader.単価計算方法型)
            Select Case 単価計算方法
                Case IUnitPriceReader.単価計算方法型.商品別数量別単価,
                     IUnitPriceReader.単価計算方法型.得意先_仕入先別数量別単価,
                     IUnitPriceReader.単価計算方法型.得意先_仕入先分類別数量別単価,
                     IUnitPriceReader.単価計算方法型.XML単価計算方法1 To IUnitPriceReader.単価計算方法型.XML単価計算方法10
                    _退避情報.明細入力部項目(退避情報型.明細項目型.単価) = GetTanka(CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.伝票日付)), 単価計算方法)
                    DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.単価.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.単価))
            End Select
        Else
            _退避情報.明細入力部項目(退避情報型.明細項目型.単価計算方法) = IUnitPriceReader.単価計算方法型.標準売上単価
        End If
        'A-CUST20211001↑

        Return True

    End Function

    Private Function Grid_DoCheckCellMoveOut_原単価() As Boolean

        Dim gentanka As Decimal = CDec(DetailGridEdit.GetData(_fromCell.RowIndex, 退避情報型.明細項目型.原単価.ToString))
        Dim suryo As Decimal = CDec(DetailGridEdit.GetData(_fromCell.RowIndex, 退避情報型.明細項目型.数量.ToString))

        Dim 行区分 As Integer = CInt(Val(_退避情報.明細入力部項目(退避情報型.明細項目型.区分)))

        'If 行区分 = 取引区分属性型.メモ Then       'D-CUST20200311 '-20200527-001
        If 行区分 = 行区分型.メモ Then              'A-CUST20200311 '-20200527-001
            Return True
        End If

        If Detail_原価金額取得(_fromCell.RowIndex, suryo, gentanka, 明細種類型.入力部) = False Then
            Return False
        End If

        '確定
        _退避情報.明細入力部項目(退避情報型.明細項目型.原単価) = gentanka

        Return True

    End Function

    Private Function Grid_DoCheckCellMoveOut_原価金額() As Boolean

        Dim kingaku As Decimal = CDec(DetailGridEdit.GetData(_fromCell.RowIndex, 退避情報型.明細項目型.原価金額.ToString))

        Dim 行区分 As Integer = CInt(Val(_退避情報.明細入力部項目(退避情報型.明細項目型.区分)))

        'If 行区分 = 取引区分属性型.メモ Then       'D-CUST20200311 '-20200527-001
        If 行区分 = 行区分型.メモ Then              'A-CUST20200311 '-20200527-001
            Return True
        End If

        '確定
        _退避情報.明細入力部項目(退避情報型.明細項目型.原価金額) = kingaku

        Return True

    End Function

    Private Function Grid_DoCheckCellMoveOut_単価() As Boolean

        Dim 数量 As Decimal = CDec(DetailGridEdit.GetData(_fromCell.RowIndex, 退避情報型.明細項目型.数量.ToString))
        Dim 単価 As Decimal = CDec(DetailGridEdit.GetData(_fromCell.RowIndex, 退避情報型.明細項目型.単価.ToString))

        Dim 行区分 As Integer = CInt(Val(_退避情報.明細入力部項目(退避情報型.明細項目型.区分)))

        'If 行区分 = 取引区分属性型.メモ Then       'D-CUST20200311 '-20200527-001
        If 行区分 = 行区分型.メモ Then              'A-CUST20200311 '-20200527-001
            Return True
        End If

        If Detail_売上金額取得(_fromCell.RowIndex, 数量, 単価, 明細種類型.入力部) = False Then
            Return False
        End If

        '確定
        _退避情報.明細入力部項目(退避情報型.明細項目型.単価) = 単価

        Return True

    End Function

    Private Function Grid_DoCheckCellMoveOut_金額() As Boolean

        Dim kingaku As Decimal = CDec(DetailGridEdit.GetData(_fromCell.RowIndex, 退避情報型.明細項目型.金額.ToString))

        Dim 行区分 As Integer = CInt(Val(_退避情報.明細入力部項目(退避情報型.明細項目型.区分)))

        'If 行区分 = 取引区分属性型.メモ Then       'D-CUST20200311 '-20200527-001
        If 行区分 = 行区分型.メモ Then              'A-CUST20200311 '-20200527-001
            Return True
        End If

        '確定
        _退避情報.明細入力部項目(退避情報型.明細項目型.金額) = kingaku

        Return True

    End Function

    Private Function Grid_DoCheckCellMoveOut_行摘要() As Boolean

        Dim tekiyou As String = CStr(DetailGridEdit.GetData(_fromCell.RowIndex, 退避情報型.明細項目型.行摘要.ToString))

        '確定
        _退避情報.明細入力部項目(退避情報型.明細項目型.行摘要) = tekiyou
        DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.行摘要.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.行摘要))

        Return True

    End Function

    ''' <summary>
    ''' グリッド 移動元行チェック
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function Grid_DoCheckLineMoveOut() As Boolean

        If (_zeroEnd = False AndAlso _fromCell.RowIndex = _toCell.RowIndex) And
           _確定押下時チェック中 = False Then
            Return True
        End If

        Dim result As Boolean = True
        Dim Save_Row As Integer = _changeCell.RowIndex
        Dim Save_Col As Integer = _changeCell.ColIndex

        _checkMode = CheckType.DoCheckGroup

        If Grid_DoCheckCellMoveOut_行() = False Then
            _changeCell.RowIndex = _fromCell.RowIndex
            _changeCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.行.ToString)
            result = False
            GoTo Phase_End
        End If

        If Grid_DoCheckCellMoveOut_区分() = False Then
            _changeCell.RowIndex = _fromCell.RowIndex
            _changeCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.区分.ToString)
            result = False
            GoTo Phase_End
        End If

        If Grid_DoCheckCellMoveOut_商品コード() = False Then
            _changeCell.RowIndex = _fromCell.RowIndex
            _changeCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.商品コード.ToString)
            result = False
            GoTo Phase_End
        End If

        If Grid_DoCheckCellMoveOut_商品名() = False Then
            _changeCell.RowIndex = _fromCell.RowIndex
            _changeCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.商品名.ToString)
            result = False
            GoTo Phase_End

        End If
        If Grid_DoCheckCellMoveOut_課税区分() = False Then
            _changeCell.RowIndex = _fromCell.RowIndex
            _changeCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.課税区分.ToString)
            result = False
            GoTo Phase_End
        End If

        If Grid_DoCheckCellMoveOut_単位() = False Then
            _changeCell.RowIndex = _fromCell.RowIndex
            _changeCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.単位.ToString)
            result = False
            GoTo Phase_End
        End If

        If Grid_DoCheckCellMoveOut_倉庫コード() = False Then
            _changeCell.RowIndex = _fromCell.RowIndex
            _changeCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.倉庫コード.ToString)
            result = False
            GoTo Phase_End
        End If

        If Grid_DoCheckCellMoveOut_数量() = False Then
            _changeCell.RowIndex = _fromCell.RowIndex
            _changeCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.数量.ToString)
            result = False
            GoTo Phase_End
        End If

        If Grid_DoCheckCellMoveOut_原単価() = False Then
            _changeCell.RowIndex = _fromCell.RowIndex
            _changeCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.原単価.ToString)
            result = False
            GoTo Phase_End

        End If

        If Grid_DoCheckCellMoveOut_原価金額() = False Then
            _changeCell.RowIndex = _fromCell.RowIndex
            _changeCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.原価金額.ToString)
            result = False
            GoTo Phase_End
        End If

        If Grid_DoCheckCellMoveOut_単価() = False Then
            _changeCell.RowIndex = _fromCell.RowIndex
            _changeCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.単価.ToString)
            result = False
            GoTo Phase_End
        End If

        If Grid_DoCheckCellMoveOut_金額() = False Then
            _changeCell.RowIndex = _fromCell.RowIndex
            _changeCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.金額.ToString)
            result = False
            GoTo Phase_End
        End If

        If Grid_DoCheckCellMoveOut_行摘要() = False Then
            _changeCell.RowIndex = _fromCell.RowIndex
            _changeCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.行摘要.ToString)
            result = False
            GoTo Phase_End
        End If

        '--------------------
        '   再計算処理
        '--------------------
        '数量＝０の場合、単価のクリア
        If CDec(_退避情報.明細入力部項目(退避情報型.明細項目型.数量)) = 0 Then
            _退避情報.明細入力部項目(退避情報型.明細項目型.単価) = 0
            _退避情報.明細入力部項目(退避情報型.明細項目型.原単価) = 0
            DetailGridEdit.SetData(0, 退避情報型.明細項目型.単価.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.単価))
            DetailGridEdit.SetData(0, 退避情報型.明細項目型.原単価.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.原単価))
        End If

        Dim 数量 As Decimal = CDec(_退避情報.明細入力部項目(退避情報型.明細項目型.数量))

        Dim 原単価 As Decimal = CDec(_退避情報.明細入力部項目(退避情報型.明細項目型.原単価))
        If Detail_原価金額取得(_fromCell.RowIndex, 数量, 原単価, 明細種類型.入力部) = False Then
            _changeCell.RowIndex = _fromCell.RowIndex
            _changeCell.ColIndex = _fromCell.ColIndex
            result = False
            GoTo Phase_End
        End If

        '売上金額
        Dim 単価 As Decimal = CDec(_退避情報.明細入力部項目(退避情報型.明細項目型.単価))
        If Detail_売上金額取得(_fromCell.RowIndex, 数量, 単価, 明細種類型.入力部) = False Then
            _changeCell.RowIndex = _fromCell.RowIndex
            _changeCell.ColIndex = _fromCell.ColIndex
            result = False
            GoTo Phase_End
        End If

        '--------------------
        '   行確定
        '--------------------
        If _確定押下時チェック中 Then
            If _fromCell.RowIndex + 1 > _maxRowCount Then
                _maxRowCount = _fromCell.RowIndex + 1
            End If
        End If

Phase_End:
        If _toCell.RowIndex <> 0 And _確定押下時チェック中 = False Then
            'グリッドから離れる際はエラーとしない
            _changeCell.RowIndex = Save_Row
            _changeCell.ColIndex = Save_Col
            result = True
        End If

        Return result

    End Function

    ''' <summary>
    ''' グリッド 移動先行チェック
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function Grid_DoCheckLineMoveIn(Optional ByRef errorRowIndex As Integer = -1) As Boolean

        errorRowIndex = _toCell.RowIndex

        '行終了
        If _zeroEnd = True Then
            Return True
        End If

        If _toCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.区分.ToString) Then
            Return True
        End If

        Return True

    End Function

    ''' <summary>
    ''' グリッド 移動元サブグループチェック
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function Grid_DoCheckSubGroup() As Boolean

        _checkMode = CheckType.DoCheckControl

        'グリッド以外へ移動又は、前に戻る場合はチェックしない
        If Isグリッド内移動方向(_fromCell, _toCell) = CheckMethodArgs.移動方向型.前へ Then
            Return True
        End If

        '前項目サブグループが未設定の場合、チェック終了
        If DetailGridEdit.Columns(_fromCell.ColIndex).SubGroupNo = 0 Then
            Return True
        End If

        '明細部項目以外の場合、チェック終了
        If _fromCell.ColIndex = -1 Then
            Return True
        End If

        If _toCell.ColIndex <> -1 Then
            If DetailGridEdit.Columns(_fromCell.ColIndex).SubGroupNo = DetailGridEdit.Columns(_toCell.ColIndex).SubGroupNo Then
                Return True
            End If
        End If

        Select Case DetailGridEdit.Columns(_fromCell.ColIndex).SubGroupNo
            'グリッド内でサブグループを設定した場合、ここにサブグループチェックを設定する
            Case Else
        End Select

        Return True

    End Function

    ''' <summary>
    ''' グリッド 確定処理
    ''' </summary>
    ''' <param name="args"></param>
    ''' <remarks></remarks>
    Private Sub Grid_DoCheck確定処理(ByVal args As GridCheckMethodArgs)

        Dim saveCell As CellInfoType = _changeCell

        'セル情報再設定
        SaveGridEditIndex(
                        DetailGridEdit,
                        args.GridEventArgs.FromRowIndex,
                        args.GridEventArgs.FromColIndex,
                        args.GridEventArgs.ToRowIndex,
                        args.GridEventArgs.ToColIndex)

        _zeroEnd = False

        '明細部以外へ移動時は処理を抜ける
        If _toCell.RowIndex = -1 OrElse _toCell.ColIndex = -1 Then
            GoTo Check_End
        End If

        If Grid_DoCheck確定処理_金額表示() = False Then
            saveCell = _changeCell
            args.GridEventArgs.ToRowIndex = _changeCell.RowIndex
            args.GridEventArgs.ToColIndex = _changeCell.ColIndex
            GoTo Check_End
        End If

        If _toCell.RowIndex > _limitMaxRow - 1 Then
            GoTo Check_End
        End If

        Display_StatusBar(_toCell.RowIndex, _toCell.ColName)
        Detail_現在庫取得(_toCell.RowIndex, _toCell.ColName)

        'ラベル変更
        SetRowStateLabel()

Check_End:
        _changeCell = saveCell

    End Sub

    ''' <summary>
    ''' 金額関連の表示
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function Grid_DoCheck確定処理_金額表示() As Boolean

        If _fromCell.RowIndex <> _toCell.RowIndex Then
            Return True
        End If

        Dim 売上金額表示 As Boolean = False

        If _toCell.TabIndex >= DetailGridEdit.GetColumnTabIndex(退避情報型.明細項目型.行摘要.ToString) Then
            売上金額表示 = True
        End If

        Dim 数量 As Decimal = CDec(_退避情報.明細入力部項目(退避情報型.明細項目型.数量))
        Dim 単価 As Decimal = CDec(_退避情報.明細入力部項目(退避情報型.明細項目型.単価))

        If 売上金額表示 = True Then
            If Detail_売上金額取得(_fromCell.RowIndex, 数量, 単価, 明細種類型.入力部) = False Then
                _changeCell = _fromCell
                _changeCell.ColIndex = DetailGridEdit.GetColumnIndex(退避情報型.明細項目型.単価.ToString)
                Return False
            End If
        End If

        Return True

    End Function

    ''' <summary>
    ''' グリッド 前処理
    ''' </summary>
    ''' <param name="args"></param>
    ''' <remarks></remarks>
    Private Sub Grid_DoCheck前処理(ByVal args As GridCheckMethodArgs)

        StatusBar.StatusLabelControl.Text = ""

        If _keyReturn = True And args.GridEventArgs.Key = Keys.None Then
            If args.GridEventArgs.FromRowIndex = args.GridEventArgs.ToRowIndex Then
                args.GridEventArgs.Key = System.Windows.Forms.Keys.Return
            End If
        End If
        _keyReturn = False
        _gridKeyTab = False

        Grid_DoCheck前処理_KeyDown(args)

        _移動先グループ番号 = args.移動先グループ番号

        SaveGridEditIndex(
                        DetailGridEdit,
                        args.GridEventArgs.FromRowIndex,
                        args.GridEventArgs.FromColIndex,
                        args.GridEventArgs.ToRowIndex,
                        args.GridEventArgs.ToColIndex)

        _zeroEnd = False

    End Sub

    Private Sub Grid_DoCheck前処理_KeyDown(ByVal args As GridCheckMethodArgs)

        If args.GridEventArgs.Key = Keys.Tab Then
            _gridKeyTab = True
            Exit Sub
        End If

        Dim rowIndex As Integer = args.GridEventArgs.FromRowIndex
        Dim colIndex As Integer = args.GridEventArgs.FromColIndex

        Select Case args.GridEventArgs.Key
            Case Keys.Return
                Select Case DetailGridEdit.Columns(colIndex).Name
                    Case Else
                End Select
            Case Keys.Up
                Select Case DetailGridEdit.Columns(colIndex).Name
                    Case Else
                End Select
        End Select

    End Sub

    ''' <summary>
    ''' グリッド内 エラーメッセージ表示処理
    ''' </summary>
    ''' <param name="messageNo"></param>
    ''' <remarks></remarks>
    Private Sub Grid_MessageViewerShow(ByVal messageNo As Integer)

        If _全行一括チェック中 = True Then
            Exit Sub
        End If

        If _focusSwitcher.CurrentControl Is Nothing Then
            GoTo Phase_MessageShow
        End If

        If _focusSwitcher.CurrentControl.Name = DetailGridEdit.Name Then
            '前方向への移動は表示対象外
            If Isグリッド内移動方向(_fromCell, _toCell) = CheckMethodArgs.移動方向型.前へ Then
                Exit Sub
            End If
        End If

Phase_MessageShow:
        '表示
        If _強制Redraw = True Then
            DetailGridEdit.Redraw = True
        End If
        If messageNo < 0 Then

            Select Case messageNo
                Case -5
                    OSK.X1.Foundation.UserInterface.OSKMessageBox.Show(Me, メッセージ定数型.MASSAGE_A05, システム環境情報.プログラム情報.名称, MessageBoxButtons.OK, MessageBoxIcon.Information)
            End Select

        Else
            MessageViewer.Show(messageNo)
        End If

        If _強制Redraw = True Then
            DetailGridEdit.Redraw = False
        End If

    End Sub

    ''' <summary>
    ''' 行№の再表示
    ''' </summary>
    ''' <param name="startRow"></param>
    ''' <remarks>対象行以降の行№を再表示</remarks>
    Private Sub Grid_ReDisplayGyoNo(ByVal startRow As Integer)

        For rowIndex As Integer = startRow To _退避情報.明細表示部.Rows.Count - 1
            Dim gyoNo As String = CStr(rowIndex + 1).ToString
            _退避情報.明細表示部項目(rowIndex, 退避情報型.明細項目型.行) = gyoNo
        Next

    End Sub

    ''' <summary>
    ''' 現在のEditセル情報を変数に抑える
    ''' </summary>
    ''' <param name="gridEdit"></param>
    ''' <param name="fromRowIndex"></param>
    ''' <param name="fromColIndex"></param>
    ''' <param name="toRowIndex"></param>
    ''' <param name="toColIndex"></param>
    ''' <remarks></remarks>
    Private Sub SaveGridEditIndex(ByVal gridEdit As OSK.X1.Foundation.Controls.GridEdit, ByVal fromRowIndex As Integer, ByVal fromColIndex As Integer, ByVal toRowIndex As Integer, ByVal toColIndex As Integer)

        'セル情報の初期化
        _fromCell.Initialize()
        _toCell.Initialize()
        _changeCell.Initialize()

        '移動元セル情報
        With _fromCell
            .RowIndex = fromRowIndex
            .ColIndex = fromColIndex
            If .RowIndex <> -1 AndAlso .ColIndex <> -1 Then
                .ColName = gridEdit.Columns(.ColIndex).Name
                .TabIndex = gridEdit.Columns(.ColIndex).TabIndex
            End If
        End With

        '移動先セル情報
        With _toCell
            .RowIndex = toRowIndex
            .ColIndex = toColIndex
            If .RowIndex <> -1 AndAlso .ColIndex <> -1 Then
                .ColName = gridEdit.Columns(.ColIndex).Name
                .TabIndex = gridEdit.Columns(.ColIndex).TabIndex
            End If
        End With

    End Sub

    ''' <summary>
    ''' 行終了処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Detail_行終了()

        If _maxRowCount < DetailGridEdit.RowCount Then
            Dim rowIndex As Integer = DetailGridEdit.RowCount - 1
            Dim defaultRow As DataRow = _退避情報.CreateNewRow明細(False, rowIndex)
            For index As Integer = 0 To DetailGridEdit.Columns.Count - 1
                Dim colName As String = DetailGridEdit.Columns(index).Name
                If _退避情報.明細表示部.Columns.Contains(colName) = True Then
                    DetailGridEdit.SetData(rowIndex, colName, defaultRow(colName))
                End If
            Next
            For index As Integer = 0 To _退避情報.明細表示部.Columns.Count - 1
                _退避情報.明細表示部.Rows(rowIndex).Item(index) = defaultRow(index)
            Next
        End If

    End Sub

    ''' <summary>
    ''' グリッドエディットに新規行を表示
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetNewGridRow(Optional GridEditOnly As Boolean = False, Optional Row As Integer = -1)

        If Row = -1 Then
            Row = _maxRowCount
        End If

        If GridEditOnly = True Then
            GoTo Clear_GridEdit
        End If

        '新規行の追加
        If DetailGridView.RowCount < _limitMaxRow Then
            Dim defaultRow As DataRow = _退避情報.CreateNewRow明細(False, Row)
            If Row = _maxRowCount Then
                _退避情報.明細表示部.Rows.Add(defaultRow)
            Else
                _退避情報.明細表示部.Rows.InsertAt(defaultRow, Row)
            End If
            _maxRowCount += 1
            Grid_ReDisplayGyoNo(0)
            DetailGridView.DataTable = _退避情報.明細表示部.Copy
        End If

Clear_GridEdit:

        '入力グリッドのクリア
        DetailGridEdit.Redraw = False
        DetailGridEdit.RowCount = 0
        If GridEditOnly = True Then
            _gridHelper.Insert(_退避情報.CreateNewRow明細(True))
            _退避情報.明細入力部.Clear()
            _退避情報.明細入力部.Rows.Add(_退避情報.CreateNewRow明細(True))
            _退避情報.明細入力部項目(退避情報型.明細項目型.行) = Row + 1
            If DetailGridView.RowCount >= _limitMaxRow Then
                _退避情報.明細入力部項目(退避情報型.明細項目型.行) = ""
            End If
        Else
            _退避情報.明細入力部.Clear()
            _退避情報.明細入力部.ImportRow(_退避情報.明細表示部.Rows(Row))
            If CStr(_退避情報.明細入力部項目(_退避情報.明細項目型.区分)) = "" Then
                _退避情報.明細入力部項目(_退避情報.明細項目型.区分) = "01"
            End If
        End If
        SettInitialvalue_Meisai()
        DetailGridEdit.DataTable = _退避情報.明細入力部.Copy
        DetailGridEdit.Redraw = True

        _現在入力行 = Row
        If Row = _limitMaxRow Then
            _現在入力行 = -1
        End If

        SetRowStateLabel()

        _getGenZaikoLine = -1

    End Sub

    ''' <summary>
    ''' グリッドエディットに指定行を表示
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetGridAnyRow(Optional row As Integer = -1)

        Grid_ReDisplayGyoNo(0)
        DetailGridView.Redraw = False
        DetailGridView.RowCount = 0
        DetailGridView.DataTable = _退避情報.明細表示部.Copy
        DetailGridView.Redraw = True

        'グリッドエディットへ反映
        DetailGridEdit.Redraw = False
        If row <> -1 Then
            _退避情報.明細入力部.Clear()
            _退避情報.明細入力部 = _退避情報.明細表示部.Clone
            _退避情報.明細入力部.ImportRow(_退避情報.明細表示部.Rows(row))
            DetailGridEdit.RowCount = 0
            DetailGridEdit.DataTable = _退避情報.明細入力部.Copy
        End If
        DetailGridEdit.Redraw = True

        RepairFunctionBar(DetailGridView)
        StatusBar.StatusLabelControl.Text = ""

    End Sub

#End Region

#Region "インスタンス作成処理"

    Private Function CreateDataAccessControlReader() As IControlReader
        Return DataAccessFactory(Of IControlReader).CreateInstance(Me, "ControlReader")
    End Function

    Private Function CreateDataAccessMasterReader() As IMasterReader
        Return DataAccessFactory(Of IMasterReader).CreateInstance(Me, "MasterReader")
    End Function

    Private Function CreateDataAccessDenpyouReader() As IDenpyouReader
        Return DataAccessFactory(Of IDenpyouReader).CreateInstance(Me, "DenpyouReader")
    End Function

    Private Function CreateDataAccessDenpyouUpdater() As IDenpyouUpdater
        Return DataAccessFactory(Of IDenpyouUpdater).CreateInstance(Me, "DenpyouUpdater")
    End Function
#End Region

#Region "データアクセス処理"

    ''' <summary>
    ''' 連番管理テーブルRead
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ReadControl_連番管理() As Boolean

        SetReadOnly_Form(True)

        Dim result As Boolean
        Dim resultData As DataTable
        Dim dataAccess As IControlReader = CreateDataAccessControlReader()

        resultData = dataAccess.ControlRead(IControlReader.テーブル一覧型.連番管理テーブル, Nothing)

        If resultData.Rows.Count > 0 Then
            result = True
            _退避情報.SaveDataValue(resultData, _退避情報.連番管理)
        Else
            result = False
        End If

        SetReadOnly_Form(False)

        Return result

    End Function

    ''' <summary>
    ''' 伝票Read
    ''' </summary>
    ''' <param name="param"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ReadDenpyou_伝票(ByVal param As ReadParam) As Boolean

        SetReadOnly_Form(True)

        StatusBar.StatusLabelControl.Text = "伝票検索中…"

        Dim result As Boolean
        Dim resultData As DataSet
        resultData = GetDenpyouData(IDenpyouReader.テーブル一覧型.見積伝票, param)

        Dim 存在 As Boolean = (resultData.Tables(IDenpyouReader.テーブル一覧型.見積伝票.ToString).Rows.Count > 0)
        If 存在 = True Then
            result = True

            Dim shiireData As DataTable = resultData.Tables(IDenpyouReader.テーブル一覧型.見積伝票.ToString)
            SaveDataValue_見積伝票(shiireData)

            'A-CUST20241219↓
            '見積サブ明細
            If resultData.Tables.Contains(IDenpyouReader.テーブル一覧型.見積サブ明細.ToString) = True Then
                Dim mitSubDetlData As DataTable = resultData.Tables(IDenpyouReader.テーブル一覧型.見積サブ明細.ToString)
                SaveDataValue_見積サブ明細(mitSubDetlData)
            End If
            'A-CUST20241219↑

        Else
            result = False
        End If

        StatusBar.StatusLabelControl.Text = ""

        SetReadOnly_Form(False)

        Return result

    End Function

    ''' <summary>
    ''' 見積伝票読み込み内容値の分解
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function SaveDataValue_見積伝票(ByVal targetData As DataTable) As Boolean

        If targetData.Rows.Count <= 0 Then
            Return False
        End If

        '-----------------------------------
        '   退避先DataTableの設定
        '-----------------------------------
        Dim saveData As IDictionary(Of String, DataTable) = New Dictionary(Of String, DataTable)

        '-- ヘッダー情報
        saveData.Add("CUSRE11", _退避情報.見積ヘッダー)
        saveData.Add("CUSME01", _退避情報.得意先)
        saveData.Add("CUSME04", _退避情報.担当者)
        saveData.Add("CUSME05", _退避情報.部門)
        saveData.Add("CUSME37", _退避情報.納品先)   'A-CUST20201013
        saveData.Add("S_CUSCE03", _退避情報.消費税)

        '-- 明細情報
        saveData.Add("CUSRE12", _退避情報.見積明細)
        saveData.Add("CUSME03", _退避情報.商品)
        saveData.Add("CUSME06", _退避情報.倉庫)
        saveData.Add("K_CUSCE03", _退避情報.課税区分)
        'saveData.Add("G_CUSCE03", _退避情報.区分)        'D-CUST20200311 '-2020527-001
        saveData.Add("G_CUSCE03", _退避情報.行区分)       'A-CUST20200311 '-2020527-001

        '-----------------------------------
        '   取得内容の退避
        '-----------------------------------
        _退避情報.SaveDataValue(targetData, saveData)

        '-----------------------------------
        '   マスター情報を一括退避
        '-----------------------------------
        '-- ヘッダー情報
        _退避情報.見積ヘッダー項目("CUSME01DT") = _退避情報.得意先.Copy
        _退避情報.見積ヘッダー項目("CUSME04DT") = _退避情報.担当者.Copy
        _退避情報.見積ヘッダー項目("CUSME05DT") = _退避情報.部門.Copy
        _退避情報.見積ヘッダー項目("CUSME37DT") = _退避情報.納品先.Copy   'A-CUST20201013
        _退避情報.見積ヘッダー項目("CUSCE03SDT") = _退避情報.消費税.Copy

        '-- 明細情報
        For row As Integer = 0 To _退避情報.見積明細.Rows.Count - 1
            _退避情報.見積明細項目(row, "CUSME03DT") = _退避情報.GetPullOutRows(row, _退避情報.商品)
            _退避情報.見積明細項目(row, "CUSME06DT") = _退避情報.GetPullOutRows(row, _退避情報.倉庫)
            '_退避情報.見積明細項目(row, "CUSCE03GDT") = _退避情報.GetPullOutRows(row, _退避情報.区分)      'D-CUST20200311 '-2020527-001
            _退避情報.見積明細項目(row, "CUSCE03GDT") = _退避情報.GetPullOutRows(row, _退避情報.行区分)     'A-CUST20200311 '-2020527-001 
            _退避情報.見積明細項目(row, "CUSCE03KDT") = _退避情報.GetPullOutRows(row, _退避情報.課税区分)
        Next

        '-----------------------------------
        '   終了
        '-----------------------------------
        Return True

    End Function

    'A-CUST20241219↓
    ''' <summary>
    ''' 見積サブ明細読み込み内容値の分解
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function SaveDataValue_見積サブ明細(ByVal targetData As DataTable) As Boolean

        '-----------------------------------
        '   退避先DataTableの設定
        '-----------------------------------
        Dim saveData As IDictionary(Of String, DataTable) = New Dictionary(Of String, DataTable)

        '-----------------------------------
        '   明細単位に取得／設定する
        '-----------------------------------
        For row As Integer = 0 To _退避情報.見積明細.Rows.Count - 1
            Dim 取得条件 As String = "MMITRE29_CUSRE29001 = " & CDec(_退避情報.見積明細項目(row, "CUSRE12001")) & " AND " &
                                     "MMITRE29_CUSRE29002 = " & CInt(_退避情報.見積明細項目(row, "CUSRE12003"))

            Dim drWork_見積サブ明細_ALL As DataRow() = targetData.Select(取得条件)

            Dim 一時取得dt As DataTable = targetData.Clone
            For サブIndex As Integer = 0 To drWork_見積サブ明細_ALL.Length - 1
                If 一時取得dt.Rows.Count >= 300 Then
                    Exit For
                End If

                '行追加
                一時取得dt.ImportRow(drWork_見積サブ明細_ALL(サブIndex))
            Next

            Dim 見積サブ明細_明細 As DataTable = _退避情報.見積サブ明細.Clone
            Dim 見積サブ明細商品_明細 As DataTable = _退避情報.商品.Clone

            '-----------------------------------
            '   退避先DataTableの設定
            '-----------------------------------
            saveData.Clear()

            saveData.Add("MMITRE29", 見積サブ明細_明細)
            saveData.Add("MURIME03", 見積サブ明細商品_明細)

            '-----------------------------------
            '   取得内容の退避
            '-----------------------------------
            _退避情報.SaveDataValue(一時取得dt, saveData)

            For index As Integer = 0 To 見積サブ明細_明細.Rows.Count - 1
                見積サブ明細_明細.Rows(index).Item("CUSME03DT") = _退避情報.GetPullOutRows(index, 見積サブ明細商品_明細)

            Next
            '-----------------------------------
            '   明細単位の退避
            '-----------------------------------
            _退避情報.見積明細項目(row, "CUSRE29DT") = 見積サブ明細_明細.Copy

        Next

        '-----------------------------------
        '   終了
        '-----------------------------------
        Return True

    End Function
    'A-CUST20241219↑

    ''' <summary>
    ''' 得意先マスターRead
    ''' </summary>
    ''' <param name="param"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ReadMaster_得意先(ByVal param As ReadParam) As Boolean

        SetReadOnly_Form(True)

        Dim result As Boolean
        Dim resultData As DataTable
        Dim dataAccess As IMasterReader = CreateDataAccessMasterReader()

        resultData = dataAccess.MasterRead(IMasterReader.テーブル一覧型.得意先マスター, param)

        If resultData.Rows.Count > 0 Then
            result = True
            Dim saveData As IDictionary(Of String, DataTable) = New Dictionary(Of String, DataTable)
            saveData.Add("CUSME01", _退避情報.得意先)
            saveData.Add("CUSME04", _退避情報.担当者)
            saveData.Add("CUSME05", _退避情報.部門)
            saveData.Add("CUSCE03", _退避情報.消費税)
            _退避情報.SaveDataValue(resultData, saveData)
        Else
            result = False
        End If

        SetReadOnly_Form(False)

        Return result

    End Function

    ''' <summary>
    ''' 担当者マスターRead
    ''' </summary>
    ''' <param name="param"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ReadMaster_担当者(ByVal param As ReadParam) As Boolean

        SetReadOnly_Form(True)

        Dim result As Boolean
        Dim resultData As DataTable
        Dim dataAccess As IMasterReader = CreateDataAccessMasterReader()

        resultData = dataAccess.MasterRead(IMasterReader.テーブル一覧型.担当者マスター, param)

        If resultData.Rows.Count > 0 Then
            result = True
            Dim saveData As IDictionary(Of String, DataTable) = New Dictionary(Of String, DataTable)
            saveData.Add("CUSME04", _退避情報.担当者)
            saveData.Add("CUSME05", _退避情報.部門)
            _退避情報.SaveDataValue(resultData, saveData)
        Else
            result = False
        End If

        SetReadOnly_Form(False)

        Return result

    End Function

    ''' <summary>
    ''' 部門マスターRead
    ''' </summary>
    ''' <param name="param"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ReadMaster_部門(ByVal param As ReadParam) As Boolean

        SetReadOnly_Form(True)

        Dim result As Boolean
        Dim resultData As DataTable
        Dim dataAccess As IMasterReader = CreateDataAccessMasterReader()

        resultData = dataAccess.MasterRead(IMasterReader.テーブル一覧型.部門マスター, param)

        If resultData.Rows.Count > 0 Then
            result = True
            Dim saveData As IDictionary(Of String, DataTable) = New Dictionary(Of String, DataTable)
            saveData.Add("CUSME05", _退避情報.部門)
            _退避情報.SaveDataValue(resultData, saveData)
        Else
            result = False
        End If

        SetReadOnly_Form(False)

        Return result

    End Function

    'A-CUST20201013↓
    ''' <summary>
    ''' 納品先マスターRead
    ''' </summary>
    ''' <param name="param"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ReadMaster_納品先(ByVal param As ReadParam) As Boolean

        SetReadOnly_Form(True)

        Dim result As Boolean
        Dim resultData As DataTable
        Dim dataAccess As IMasterReader = CreateDataAccessMasterReader()

        resultData = dataAccess.MasterRead(IMasterReader.テーブル一覧型.納品先マスター, param)

        If resultData.Rows.Count > 0 Then
            result = True
            Dim saveData As IDictionary(Of String, DataTable) = New Dictionary(Of String, DataTable)
            saveData.Add("CUSME37", _退避情報.納品先)
            _退避情報.SaveDataValue(resultData, saveData)
        Else
            result = False
        End If

        SetReadOnly_Form(False)

        Return result

    End Function
    'A-CUST20201013↑

    ''' <summary>
    ''' 区分マスターRead
    ''' </summary>
    ''' <param name="param"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ReadMaster_区分マスター(ByVal param As ReadParam) As Boolean

        SetReadOnly_Form(True)

        Dim result As Boolean
        Dim resultData As DataTable
        Dim dataAccess As IMasterReader = CreateDataAccessMasterReader()

        resultData = dataAccess.MasterRead(IMasterReader.テーブル一覧型.区分マスター, param)

        If resultData.Rows.Count > 0 Then
            result = True
            Dim saveData As IDictionary(Of String, DataTable) = New Dictionary(Of String, DataTable)
            If CStr(param.Container(ReadParam.項目名型.種別)) = Get区分マスター種別値(区分マスター型.消費税区分) Then
                saveData.Add("CUSCE03", _退避情報.消費税)
            ElseIf CStr(param.Container(ReadParam.項目名型.種別)) = Get区分マスター種別値(区分マスター型.区分) Then
                'saveData.Add("CUSCE03", _退避情報.区分)      'D-CUST20200311 '-2020527-001
                saveData.Add("CUSCE03", _退避情報.行区分)     'A-CUST20200311 '-2020527-001 
            ElseIf CStr(param.Container(ReadParam.項目名型.種別)) = Get区分マスター種別値(区分マスター型.課税区分) Then
                saveData.Add("CUSCE03", _退避情報.課税区分)
            End If

            _退避情報.SaveDataValue(resultData, saveData)
        Else
            result = False
        End If

        SetReadOnly_Form(False)

        Return result

    End Function

    ''' <summary>
    ''' 商品マスターRead
    ''' </summary>
    ''' <param name="param"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ReadMaster_商品(ByVal param As ReadParam) As Boolean

        SetReadOnly_Form(True)

        Dim result As Boolean
        Dim resultData As DataTable
        Dim dataAccess As IMasterReader = CreateDataAccessMasterReader()

        resultData = dataAccess.MasterRead(IMasterReader.テーブル一覧型.商品マスター, param)

        If resultData.Rows.Count > 0 Then
            result = True
            Dim saveData As IDictionary(Of String, DataTable) = New Dictionary(Of String, DataTable)
            saveData.Add("CUSME03", _退避情報.商品)
            saveData.Add("CUSME06", _退避情報.倉庫)
            saveData.Add("CUSCE03", _退避情報.課税区分)

            _退避情報.SaveDataValue(resultData, saveData)
        Else
            result = False
        End If

        SetReadOnly_Form(False)

        Return result

    End Function

    ''' <summary>
    ''' 倉庫マスターRead
    ''' </summary>
    ''' <param name="param"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ReadMaster_倉庫マスター(ByVal param As ReadParam) As Boolean

        SetReadOnly_Form(True)

        Dim result As Boolean
        Dim resultData As DataTable
        Dim dataAccess As IMasterReader = CreateDataAccessMasterReader()

        resultData = dataAccess.MasterRead(IMasterReader.テーブル一覧型.倉庫マスター, param)

        If resultData.Rows.Count > 0 Then
            result = True
            _退避情報.SaveDataValue(resultData, _退避情報.倉庫)
        Else
            result = False
        End If

        SetReadOnly_Form(False)

        Return result

    End Function

    ''' <summary>
    ''' 現在庫情報Read
    ''' </summary>
    ''' <param name="param"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ReadMaster_現在庫情報(ByVal param As ReadParam, ByRef ReturnValue As Decimal) As Boolean

        SetReadOnly_Form(True)

        Dim dataAccess As IMasterReader = CreateDataAccessMasterReader()

        ReturnValue = CDec(dataAccess.MasterRead(IMasterReader.取得項目型.倉庫別在庫, param))

        SetReadOnly_Form(False)

        Return True

    End Function

    ''' <summary>
    ''' セキュリティチェック
    ''' </summary>
    ''' <param name="param"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function Check_セキュリティ(ByVal param As ReadParam) As Boolean

        SetReadOnly_Form(True)

        Dim result As Boolean
        Dim dataAccess As IMasterReader = CreateDataAccessMasterReader()

        result = dataAccess.MasterCheck(IMasterReader.テーブル一覧型.セキュリティチェック, param)

        SetReadOnly_Form(False)

        Return result

    End Function

    ''' <summary>
    ''' マスター系データを取得する
    ''' </summary>
    ''' <param name="targetMaster">対象マスター種類</param>
    ''' <param name="readParam">読込パラメータ</param>
    ''' <returns>取得データ</returns>
    ''' <remarks></remarks>
    Private Function GetMasterData(ByVal targetMaster As IMasterReader.テーブル一覧型, ByVal readParam As ReadParam) As System.Data.DataTable

        Dim dataReader As New DataAccessor
        dataReader.Initialize(Me)

        Dim dataAccess As IMasterReader = CreateDataAccessMasterReader()

        dataReader.SetupMasterReader(dataAccess)

        Dim method As New DataAccessor.GetMasterDataMethod(AddressOf dataReader.GetMasterData)

        Dim exDA As Exception = Nothing
        Dim resultData As DataTable = Nothing

        'スレッドの開始
        Dim asyncResult As IAsyncResult
        asyncResult = method.BeginInvoke(targetMaster, readParam, exDA, Nothing, Nothing)

        WaitAccessorProcess(dataReader)

        resultData = method.EndInvoke(exDA, asyncResult)

        If exDA IsNot Nothing Then
            ThrowWithInnerException(exDA)
        End If

        Return resultData

    End Function

    ''' <summary>
    ''' 伝票系データを取得する
    ''' </summary>
    ''' <param name="targetDenpyou">対象伝票種類</param>
    ''' <param name="readParam">読込パラメータ</param>
    ''' <returns>取得データ</returns>
    ''' <remarks></remarks>
    Private Function GetDenpyouData(ByVal targetDenpyou As IDenpyouReader.テーブル一覧型, ByVal readParam As ReadParam) As System.Data.DataSet

        Dim dataReader As New DataAccessor
        dataReader.Initialize(Me)

        Dim dataAccess As IDenpyouReader = CreateDataAccessDenpyouReader()

        dataReader.SetupDenpyouReader(dataAccess)

        Dim method As New DataAccessor.GetDenpyouDataMethod(AddressOf dataReader.GetDenpyouData)

        Dim exDA As Exception = Nothing
        Dim resultData As DataSet = Nothing

        'スレッドの開始
        Dim asyncResult As IAsyncResult
        asyncResult = method.BeginInvoke(targetDenpyou, readParam, exDA, Nothing, Nothing)

        WaitAccessorProcess(dataReader)

        resultData = method.EndInvoke(exDA, asyncResult)

        If exDA IsNot Nothing Then
            ThrowWithInnerException(exDA)
        End If

        Return resultData

    End Function

    ''' <summary>
    ''' 伝票系データを更新する
    ''' </summary>
    ''' <param name="targetDenpyou">対象伝票種類</param>
    ''' <param name="updateParam">更新用パラメータ</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function UpdateDenpyouData(ByVal targetDenpyou As IDenpyouUpdater.テーブル一覧型, ByVal mode As 処理区分型, ByVal updateParam As UpdateParam, ByRef executeCheckInfo As IExecuteCheckInfo) As IResult

        Dim dataUpdater As New DataAccessor
        dataUpdater.Initialize(Me)

        Dim dataAccess As IDenpyouUpdater = CreateDataAccessDenpyouUpdater()

        dataUpdater.SetupDenpyouUpdater(dataAccess)

        Dim method As New DataAccessor.UpdateDenpyouDataMethod(AddressOf dataUpdater.UpdateDenpyouData)

        Dim exDA As Exception = Nothing
        Dim result As IResult = Nothing

        'スレッドの開始
        Dim asyncResult As IAsyncResult
        asyncResult = method.BeginInvoke(targetDenpyou, mode, updateParam, exDA, executeCheckInfo, Nothing, Nothing)

        WaitAccessorProcess(dataUpdater)

        result = method.EndInvoke(exDA, executeCheckInfo, asyncResult)

        If exDA IsNot Nothing Then
            ThrowWithInnerException(exDA)
        End If

        Return result

    End Function

    ''' <summary>
    ''' 処理状態を取得する
    ''' </summary>
    ''' <param name="accessorBase">DAにアクセス依頼を行なったインスタンス</param>
    ''' <remarks></remarks>
    Private Sub WaitAccessorProcess(ByVal accessorBase As DataAccessor)
        Do While accessorBase.EndFlag = False
            Me.StatusBar.DoProgress()
            Me.StatusBar.Refresh()
        Loop
    End Sub

#End Region

#Region "メニューバーイベント"

    ''' <summary>
    ''' メニューバー[終了]押下
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub endForm_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles endMenu.Click
        If _退避情報.起動モード = 起動モード型.詳細モード Then
            _focusSwitcher.CurrentControl = Nothing
        End If
        Me.Close()
    End Sub

    ''' <summary>
    ''' メニューバー[ページ設定]押下
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub pageMenu_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles pageMenu.Click

        _退避情報.PrintingController.ShowDialog(0)

    End Sub

    ''' <summary>
    ''' メニューバー[伝票発行]押下
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub printMenu_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles printMenu.Click

        Dim 条件 As IDictionary = New Hashtable
        Dim 結果 As IDictionary = New Hashtable

        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.伝票発行_変更前) = _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.伝票発行)

        With 条件
            .Add(伝票発行情報型.条件型.伝票発行.ToString, _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.伝票発行))
            .Add(伝票発行情報型.条件型.見積書情報.ToString, _退避情報.見積書情報)
        End With

        If _伝票発行 Is Nothing Then
            _伝票発行 = New PrintForm
            _伝票発行.Initialize(Me)
        End If

        If _伝票発行.SetUpForm(条件, 結果) = Windows.Forms.DialogResult.OK Then

            _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.伝票発行) = CInt(結果(伝票発行情報型.結果型.伝票発行.ToString))

            '伝票発行モードラベルの設定
            Display_伝票発行ラベル()

            'D-CUST20200311↓ '-20200527
            ''「ページ設定」ボタンの押下可否制御
            'SetMenuBar_ページ設定()
            'D-CUST20200311↑ '-20200527

        End If

    End Sub

#End Region

#Region "ガイドメッセージ"

    ''' <summary>
    ''' ステータスバーの表示
    ''' </summary>
    ''' <param name="control"></param>
    ''' <remarks>通常コントロール用</remarks>
    Private Overloads Sub Display_StatusBar(ByVal control As Control)

        If StatusBar.StatusLabelControl.Text <> "" Then Exit Sub

        Dim message As String = ""

        Select Case control.Name
            Case Else
        End Select

        StatusBar.StatusLabelControl.Text = message

        '前回更新内容の表示
        Display_登録連番()

    End Sub

    Private Overloads Sub Display_StatusBar(ByVal rowIndex As Integer, ByVal columnName As String)

        If StatusBar.StatusLabelControl.Text <> "" Then Exit Sub

        Dim message As String = ""

        Select Case columnName
            Case Else
        End Select

        StatusBar.StatusLabelControl.Text = message

        '前回更新内容の表示
        Display_登録連番()

    End Sub

    ''' <summary>
    ''' 前回更新内容の表示
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Display_登録連番()

        If StatusBar.StatusLabelControl.Text <> "" Then Exit Sub

        Dim message As String = ""

        If _更新後番号.伝票番号 <> 0 AndAlso shori.Value = 処理区分型.登録 Then
            message = ""
            message &= "前回内容 伝票No.:" & CStr(_更新後番号.伝票番号)
        End If

        StatusBar.StatusLabelControl.Text = message

    End Sub

#End Region

#Region "フォームイベント"

    Private Sub EntryForm_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing

        If _退避情報.起動モード = 起動モード型.詳細モード Then
            _focusSwitcher.CurrentControl = Nothing
        End If

        If _focusSwitcher.CurrentControl IsNot Nothing Then
            Select Case _focusSwitcher.CurrentControl.Name
                Case shori.Name, shoriRenban.Name, display.Name
                Case Else
                    If MessageViewer.Show(1, IMessageViewer.DefaultButtonType.No) = IMessageViewer.ShowResultType.No Then
                        e.Cancel = True
                        Exit Sub
                    End If
            End Select
        End If

        _gridCheckCansel = -2

        TokuisakiCode.TextValue = ""
        shori.ReadOnly = False
        shoriRenban.InputNumericalControl.ReadOnly = False
        shori.Focus()

    End Sub

    Private Sub EntryForm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown

        If e.KeyCode = Keys.ShiftKey Then Exit Sub

        Select Case e.KeyCode
            Case Keys.Escape
                If Me.システム環境情報.プログラム制御情報.Escキー終了機能 = True Then
                    If _退避情報.起動モード = 起動モード型.詳細モード Then
                        _focusSwitcher.CurrentControl = Nothing
                    End If
                    Me.Close()
                End If

        End Select

    End Sub

    Private Sub EntryForm_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown

        Dim backColor As Integer
        Dim foreColor As Integer
        Dim borderColor As Integer

        _isInitialize = False

        '------------------------------
        '   Grid表示域の色設定
        '------------------------------
        If Me.GetBySetteiNam("表示域", backColor, foreColor, borderColor) = True Then
            '明細部
            With DetailGridView
                For index As Integer = 0 To .ColumnCount - 1
                    If backColor <> -1 Then .Columns(index).BackColor = Me.ChangeRGB(backColor)
                    If foreColor <> -1 Then .Columns(index).ForeColor = Me.ChangeRGB(foreColor)
                Next
            End With
            '明細部
            With DetailGridEdit
                For index As Integer = 0 To .ColumnCount - 1
                    If .Columns(index).ReadOnly = Grid.Common.Boolean.True OrElse
                       .Columns(index).DisplayOnly = Grid.Common.Boolean.True Then
                        If backColor <> -1 Then .Columns(index).BackColor = Me.ChangeRGB(backColor)
                        If foreColor <> -1 Then .Columns(index).ForeColor = Me.ChangeRGB(foreColor)
                    End If
                Next
            End With
        End If

        CloseButton.Text = "閉じる"

        If _ドリルダウン = True Then
            shori.Value = 処理区分型.修正
            _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード) = shori.Value

            '処理連番にフォーカスを移動
            shoriRenban.InputNumericalControl.Focus()

            _keyReturn = True

            '連番をセット
            shoriRenban.Value = CLng(ParamInfo.Item("DENPYONO"))
            If _退避情報.起動モード = 起動モード型.ドリルダウン Then
                Dim nextControl As Control = _focusSwitcher.GetNextControl(shoriRenban.InputNumericalControl)
                nextControl.Focus()
            Else
                Dim args As New CheckMethodArgs(
                            shoriRenban,
                            denpyouDate,
                            CheckMethodArgs.移動方向型.後へ,
                            Keys.Return, False)
                DoCheckControlMoveOut_処理連番(args)

                If ParamInfo.Contains("GYONO") = True AndAlso
                    CInt(ParamInfo.Item("GYONO")) <> 0 Then
                    If CInt(ParamInfo.Item("GYONO")) > 1 Then
                        DetailGridView.TopIndex = CInt(ParamInfo.Item("GYONO")) - 2
                    Else
                        DetailGridView.TopIndex = CInt(ParamInfo.Item("GYONO")) - 1
                    End If
                    DetailGridView.ChangeSelectedState(CInt(ParamInfo.Item("GYONO")) - 1)
                End If
                If _退避情報.起動モード = 起動モード型.詳細モード Then
                    CloseButton.Focus()
                Else
                    DetailGridView.Focus()
                End If
            End If

            Exit Sub
        End If

    End Sub

#End Region

#Region "個別コントロールイベント"

    ''' <summary>
    ''' 処理選択を変更した時
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub shori_SelChange(ByVal sender As Object, ByVal e As System.EventArgs) Handles shori.SelChange

        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理連番) = 0
        _退避情報.グループ状態(退避情報型.グループ型.No２) = 退避情報型.状態.エラー

        '前回内容表示
        Display_登録連番()

    End Sub

    ''' <summary>
    ''' 処理連番のキーダウン
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub shoriRenban_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs)
        If e.Shift = True Then Exit Sub

        Select Case e.KeyCode
            Case Keys.PageUp
                FunctionF7_前伝票(CType(sender, Control))
                e.Handled = True
            Case Keys.PageDown
                FunctionF6_次伝票(CType(sender, Control))
                e.Handled = True
        End Select

    End Sub

    ''' <summary>
    ''' 表示ボタンをクリックした時
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub display_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles display.Click

        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理連番) = 0
        _退避情報.グループ状態(退避情報型.グループ型.No２) = 退避情報型.状態.エラー

        _keyReturn = True
        _focusSwitcher.GetNextControl(shoriRenban.InputNumericalControl).Focus()

    End Sub

    ''' <summary>
    ''' グリッドダブルクリック時
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub DetailGridView_DoubleClick(sender As Object, e As EventArgs) Handles DetailGridView.DoubleClick

        If _退避情報.起動モード = 起動モード型.詳細モード Or
           CType(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード), 処理区分型) = 処理区分型.削除 Then
            Exit Sub
        End If

        If Check明細表示前チェック() = False Then
            Exit Sub
        End If

        '未確定の行がある場合、削除
        For I As Integer = _退避情報.明細表示部.Rows.Count - 1 To 0 Step -1
            If CInt(_退避情報.明細表示部項目(I, 退避情報型.明細項目型.行)) = 0 Then
                _退避情報.明細表示部.Rows.RemoveAt(I)
            End If
        Next

        '未反映の行がある場合、削除
        If DetailGridView.Rows.Count <> _退避情報.明細表示部.Rows.Count Then
            _退避情報.明細表示部.Rows.RemoveAt(_現在入力行)
        End If

        明細部表示処理(DetailGridView.ListIndex)

        DetailGridEdit.SetCellEdit(0, GetDetailTopColumnName2)
        DetailGridEdit.Focus()

    End Sub

    ''' <summary>
    ''' グリッド行移動時
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub DetailGridView_SelChange(sender As Object, e As EventArgs) Handles DetailGridView.SelChange

        If DetailGridView.ListIndex = -1 Then Exit Sub

        RepairFunctionBar(DetailGridView)

    End Sub

    ''' <summary>
    '''　明細グリッドにこれ以上移動可能なセルがない時
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks>先頭行から上でこのイベントが走る</remarks>
    Private Sub DetailGridView_MoveAboveOnTop(sender As Object, e As EventArgs) Handles DetailGridView.MoveAboveOnTop

        If _退避情報.起動モード = 起動モード型.詳細モード Then
            Me.CloseButton.Focus()
        Else
            If CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード)) = 処理区分型.削除 Then
                Me.shoriRenban.InputNumericalControl.Focus()
            Else
                GetHeaderLastControl().Focus()
            End If
        End If
    End Sub

    ''' <summary>
    '''　明細グリッドにこれ以上移動可能なセルがない時
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks>最終行から下でこのイベントが走る</remarks>
    Private Sub DetailGridView_MoveBelowOnBottom(sender As Object, e As EventArgs) Handles DetailGridView.MoveBelowOnBottom
        If _退避情報.起動モード = 起動モード型.詳細モード Then
            '移動しない
        Else
            If CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード)) = 処理区分型.削除 Then
                Me.execute.Focus()
            Else
                _focusSwitcher.GetNextControl(DetailGridView).Focus()
            End If
        End If

    End Sub

    ''' <summary>
    ''' グリッドがフォーカスを取得した時
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub DetailGridEdit_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles DetailGridEdit.Enter

        SaveGridEditIndex(DetailGridEdit, -1, -1, DetailGridEdit.EditRowIndex, DetailGridEdit.EditColIndex)
        SaveGridEditIndex(DetailGridEdit, DetailGridEdit.EditRowIndex, DetailGridEdit.EditColIndex, DetailGridEdit.EditRowIndex, DetailGridEdit.EditColIndex)

        SetRowStateLabel()

        SetRowNumber()

        If _現在入力行 > 0 AndAlso
           Is新規行判定() = True Then
            Dim foundrow() As DataRow = _退避情報.明細表示部.Select(退避情報型.明細項目型.行.ToString & " = '" & Val(_退避情報.明細入力部項目(_退避情報.明細項目型.行)) & "'", "")
            '表示部に表示されている(行挿入時)場合は、行セレクト
            If foundrow.Length = 0 Then
                DetailGridView.ClearSelectedState()
                DetailGridView.SetListIndex(_maxRowCount - 1)
            Else
                DetailGridView.Redraw = False
                DetailGridView.TopIndex = 0
                DetailGridView.ChangeSelectedState(_現在入力行)
                DetailGridView.SetListIndex(_現在入力行)
                DetailGridView.Redraw = True
            End If
        End If

    End Sub

    ''' <summary>
    ''' 明細グリッド内でキー押下した時
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub DetailGridEdit_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles DetailGridEdit.KeyDown
        Select Case e.KeyCode
            Case Keys.Up
                If DetailGridEdit.EditColName = GetDetailTopColumnName(DetailGridEdit.EditRowIndex) Then
                    DetailGridEdit.MoveDirectionOnUpKey = Grid.Edit.MoveDirectionOnUp.Up
                Else
                    DetailGridEdit.MoveDirectionOnUpKey = Grid.Edit.MoveDirectionOnUp.Left
                End If

            Case Keys.Down
                DetailGridEdit.MoveDirectionOnDownKey = Grid.Edit.MoveDirectionOnDown.Down
                e.Handled = True

            Case Keys.Enter
                DetailGridEdit.MoveDirectionOnEnterKey = Grid.Edit.MoveDirectionOnEnter.Right

                If DetailGridEdit.EditColName = 退避情報型.明細項目型.商品コード.ToString Then
                    DetailGridEdit.DecideEditData()
                End If
        End Select

    End Sub

    ''' <summary>
    '''　明細グリッドにこれ以上移動可能なセルがない時
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks>今回は先頭行から上、最終行から下でこのイベントが走る</remarks>
    Private Sub DetailGridEdit_NoMoreMoveableCell(ByVal sender As Object, ByVal e As OSK.X1.Foundation.Controls.Grid.Common.NoMoreMoveableCellEventArgs) Handles DetailGridEdit.NoMoreMoveableCell

        Select Case e.Direction
            Case 0, 2
                '先頭行から上へ
                DetailGridView.Focus()
                If DetailGridView.ListIndex >= 0 Then
                    DetailGridView.ChangeSelectedState(DetailGridView.ListIndex)
                Else
                    DetailGridView.ChangeSelectedState(0)
                End If

            Case 1, 3
                '最終行から下へ
                SaveGridEditIndex(DetailGridEdit, e.RowIndex, e.ColIndex, e.RowIndex + 1, e.ColIndex)
                DetailGridEdit.DecideEditData()
                If Grid_DoCheckCellMoveOut() = False Then
                    _gridCheckCansel = -1
                    DetailGridEdit.SelectAll()
                    DetailGridEdit.UpdateCaretPos(0)
                    Exit Sub
                End If
                If Grid_DoCheckLineMoveOut() = False Then
                    If e.RowIndex <> _changeCell.RowIndex OrElse e.ColIndex <> _changeCell.ColIndex Then
                        _gridCheckCansel = -2   'エラー項目が現在セルと異なる
                    Else
                        _gridCheckCansel = -1   'エラー項目が現在セルである
                    End If
                    DetailGridEdit.SetCellEdit(_changeCell.RowIndex, _changeCell.ColIndex)
                    Exit Sub
                End If
                Kakutei.Focus()
        End Select

    End Sub

    ''' <summary>
    ''' 明細グリッドセル移動完了後処理
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub DetailGridEdit_ValidatedCell(ByVal sender As Object, ByVal e As OSK.X1.Foundation.Controls.Grid.Common.ValidatedCellEventArgs) Handles DetailGridEdit.ValidatedCell

        If e.ToRowIndex = -1 OrElse e.ToColIndex = -1 Then
            Exit Sub
        End If

        Detail_返品値引マイナス符号初期表示(e.ToRowIndex, DetailGridEdit.EditColName)

        RepairFunctionBar(DetailGridEdit, DetailGridEdit.EditColName)
        Display_StatusBar(DetailGridEdit.EditRowIndex, DetailGridEdit.EditColName)

    End Sub

    ''' <summary>
    ''' 明細グリッド内でボタン属性セルをクリックした時
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub DetailGridEdit_ButtonClick(ByVal sender As Object, ByVal e As OSK.X1.Foundation.Controls.Grid.Common.ButtonClickEventArgs) Handles DetailGridEdit.ButtonClick


        Select Case e.ColName
            Case 退避情報型.明細項目型.小計.ToString
                If DetailGridEdit.GetCellInfo(e.RowIndex, e.ColName).CheckState = CheckState.Checked Then
                    _退避情報.明細入力部項目(退避情報型.明細項目型.小計) = 0
                Else
                    _退避情報.明細入力部項目(退避情報型.明細項目型.小計) = 1
                    _退避情報.明細入力部項目(退避情報型.明細項目型.改頁) = 1
                    DetailGridEdit.SetData(e.RowIndex, 退避情報型.明細項目型.改頁.ToString, 1)
                    DetailGridEdit.GetCellInfo(e.RowIndex, 退避情報型.明細項目型.改頁.ToString).CheckState = CheckState.Checked
                End If
            Case 退避情報型.明細項目型.改頁.ToString
                If DetailGridEdit.GetCellInfo(e.RowIndex, e.ColName).CheckState = CheckState.Checked Then
                    _退避情報.明細入力部項目(退避情報型.明細項目型.改頁) = 0
                Else
                    _退避情報.明細入力部項目(退避情報型.明細項目型.改頁) = 1
                End If
            'A-CUST20251104↓
            Case 退避情報型.明細項目型.FieldBuilder.ToString
                Dim paramInfo As IDictionary = New Hashtable
                Dim dtサブ画面データ As New DataTable
                Try
                    dtサブ画面データ = CType(_退避情報.明細入力部項目(退避情報型.明細項目型.FieldBuilder), DataTable)
                Catch ex As Exception
                    dtサブ画面データ = New DataTable
                End Try
                LaunchMeisaiExpandSubForm(dtサブ画面データ, 処理モード.入力, paramInfo)

            Case Else
                Exit Sub
        End Select

    End Sub

    ''' <summary>
    ''' 実行ボタンのクリック
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub execute_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles execute.Click

        Dim mode As 処理区分型 = CType(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード), 処理区分型)

        If execute.Focused = False Then
            Exit Sub
        End If

        'A-CUST20251104↓
        If mode <> 処理区分型.削除 Then
            If _退避情報.FieldBuilderヘッダー使用 = True Then
                If PrecheckHeaderExpand() = False Then
                    Exit Sub
                End If
            End If
        End If
        'A-CUST20251104↑

        '更新前チェック処理
        If DoCheckBeforeExecute() = False Then
            Exit Sub
        End If

        If mode = 処理区分型.削除 Then
            If Me.MessageViewer.Show(2, IMessageViewer.DefaultButtonType.No) = IMessageViewer.ShowResultType.No Then
                If Is検索データ選択() = True Then
                    _検索自動表示 = True
                End If
                Exit Sub
            End If
        End If

        '-----------------------------------
        '   更新処理
        '-----------------------------------
        SetReadOnly_Uppdate(True, mode)

        Dim result As IResult = New Result
        Dim executeCheckInfo As IExecuteCheckInfo = Nothing
        Update_伝票データ(executeCheckInfo, result)

        Select Case result.結果
            Case IResult.resultError.成功
                Update_正常終了(mode, result)
                SetReadOnly_Uppdate(False, mode)
                Update_フォーカス移動()

            Case Else
                SetReadOnly_Uppdate(False, mode)
                Update_エラー終了(executeCheckInfo, result)
        End Select

    End Sub

    ''' <summary>
    ''' 行確定ボタンのクリック
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Kakutei_Click(sender As Object, e As EventArgs) Handles Kakutei.Click

        Dim 確定行 As Integer = -1

        SetRowNumber()

        _確定押下時チェック中 = True

        'A-CUST20251104↓
        '行確定のタイミングで明細のFieldBuilderの入力チェック
        If _退避情報.FieldBuilder明細使用 Then
            If PrecheckMeisaiExpand() = False Then
                Exit Sub
            End If
        End If
        'A-CUST20251104↑

        '最大行を超えた場合エラー
        If Val(_退避情報.明細入力部項目(_退避情報.明細項目型.行)) = 0 And _maxRowCount = _limitMaxRow Then
            'MessageViewer.Show(1010, "OTS")      'D-CUST20230315
            MessageViewer.Show(999000009, "OTS")  'A-CUST20230315
            SetNewGridRow(True)
            DetailGridEdit.SetCellEdit(0, GetDetailTopColumnName)
            DetailGridEdit.Focus()
            GoTo Phase_End
            Exit Sub
        End If

        If Grid_DoCheckLineMoveOut() = False Then
            DetailGridEdit.SetCellEdit(_changeCell.RowIndex, _changeCell.ColIndex)
            DetailGridEdit.Focus()
            GoTo Phase_End
            Exit Sub
        End If
        _確定押下時チェック中 = False
        確定行 = _現在入力行

        'フッター部初期処理
        If Footer_初期処理(True, _現在入力行) = False Then
            DetailGridEdit.SetCellEdit(0, GetDetailTopColumnName)
            DetailGridEdit.Focus()
            Exit Sub
        End If

        DisplayForm_合計部()

        '入力グリッドから表示グリッドへ反映
        DetailGridView.Redraw = False

        Dim foundrow() As DataRow = _退避情報.明細表示部.Select(退避情報型.明細項目型.行.ToString & " = '" & Val(_退避情報.明細入力部項目(_退避情報.明細項目型.行)) & "'", "")
        Dim update As Boolean = False

        If _退避情報.明細表示部.Rows.Count = 1 And
           Is省略判定(コード判定対象型.区分, _退避情報.明細表示部項目(0, 退避情報型.明細項目型.区分).ToString) = 省略判定結果型.省略 Then
            '1行目が空白行の場合
            update = True
        End If

        If foundrow.Length > 0 Or update = True Then
            Dim Name As String = ""
            Dim UpdateRow As Integer = _現在入力行
            Dim MaxCnt As Integer = 0   'A-CUST20251104
            If update = True Then
                UpdateRow = 0
                _退避情報.明細入力部項目(退避情報型.明細項目型.行) = 1
            End If

            For I As Integer = 0 To _退避情報.明細項目型.Detailcnt2 - 1
                Name = [Enum].GetName(GetType(退避情報型.明細項目型), I)
                If _退避情報.FieldBuilder明細使用 Then
                    _退避情報.明細表示部項目(UpdateRow, Name) = _退避情報.明細入力部項目(Name)
                Else
                    If Name = 退避情報型.明細項目型.ラベル1_02.ToString OrElse
                            Name = 退避情報型.明細項目型.FieldBuilder.ToString Then
                        Continue For
                    Else
                        _退避情報.明細表示部項目(UpdateRow, Name) = _退避情報.明細入力部項目(Name)
                    End If
                End If
                'D-CUST20241219

                'A-CUST20241219↓
                'If _退避情報.明細入力部.Columns(Name).DataType Is GetType(DataTable) Then
                '    _退避情報.明細表示部項目(UpdateRow, Name) = CType(_退避情報.明細入力部項目(Name), DataTable).Copy
                'Else
                '    _退避情報.明細表示部項目(UpdateRow, Name) = _退避情報.明細入力部項目(Name)
                'End If
                'A-CUST20241219↑

            Next
        Else
            '新規行の場合
            _退避情報.明細表示部.ImportRow(_退避情報.明細入力部.Rows(0))
            Grid_ReDisplayGyoNo(0)
        End If

        DetailGridView.RowCount = 0
        DetailGridView.DataTable = _退避情報.明細表示部.Copy
        For i As Integer = 0 To _退避情報.明細表示部.Rows.Count


        Next
        _maxRowCount = _退避情報.明細表示部.Rows.Count
        DetailGridView.Redraw = True

        '入力グリッドに新規行表示
        SetNewGridRow(True)
        SetRowStateLabel()

        '歯抜けで登録した場合の考慮
        If _現在入力行 <> -1 And
           確定行 >= _現在入力行 Then
            確定行 = _現在入力行 - 1
        End If

        If CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード)) <> 処理区分型.登録 Then
            If 確定行 <> 0 Then
                DetailGridView.TopIndex = 確定行 - 1
            End If
            DetailGridView.Focus()
            DetailGridView.SetListIndex(確定行)
            DetailGridView.ChangeSelectedState(確定行)
        Else
            DetailGridView.SetListIndex(確定行)
            DetailGridView.ChangeSelectedState(確定行)
            DetailGridEdit.SetCellEdit(0, GetDetailTopColumnName2)
            DetailGridEdit.Focus()
            SaveGridEditIndex(DetailGridEdit, -1, -1, DetailGridEdit.EditRowIndex, DetailGridEdit.EditColIndex)
            SaveGridEditIndex(DetailGridEdit, DetailGridEdit.EditRowIndex, DetailGridEdit.EditColIndex, DetailGridEdit.EditRowIndex, DetailGridEdit.EditColIndex)
        End If

        Detail_現在庫表示(-1, "")

Phase_End:
        _確定押下時チェック中 = False

    End Sub

    ''' <summary>
    ''' 閉じるボタンのクリック
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub CloseButton_Click(sender As Object, e As EventArgs) Handles CloseButton.Click
        If _退避情報.起動モード = 起動モード型.詳細モード Then
            _focusSwitcher.CurrentControl = Nothing
        End If
        Me.Close()
    End Sub

#End Region

#Region "更新処理"

    ''' <summary>
    ''' 実行前チェック
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function DoCheckBeforeExecute() As Boolean

        '未確定行のチェック
        Dim is未確定 As Boolean = False
        'If CInt(Val(_退避情報.明細入力部項目(退避情報型.明細項目型.区分))) = 取引区分属性型.メモ Then          'D-CUST20200311 '-20200527-001
        If CInt(Val(_退避情報.明細入力部項目(退避情報型.明細項目型.区分))) = 行区分型.メモ Then                 'A-CUST20200311 '-20200527-001
            is未確定 = True
        Else
            If Is省略判定(コード判定対象型.商品コード, _退避情報.明細入力部項目(退避情報型.明細項目型.商品コード).ToString) = 省略判定結果型.入力 Then
                is未確定 = True
            End If
        End If
        If is未確定 Then
            'If MessageViewer.Show(1008, "OTS", IMessageViewer.DefaultButtonType.No) = IMessageViewer.ShowResultType.No Then      'D-CUST20230315
            If MessageViewer.Show(999000007, "OTS", IMessageViewer.DefaultButtonType.No) = IMessageViewer.ShowResultType.No Then  'A-CUST20230315
                Return False
            End If
        End If

        '未入力行のチェック
        For I As Integer = 0 To _退避情報.明細表示部.Rows.Count - 1
            'If CInt(Val(_退避情報.明細表示部項目(I, 退避情報型.明細項目型.区分))) <> 取引区分属性型.メモ AndAlso                                           'D-CUST20200311 '-20200527-001
            If CInt(Val(_退避情報.明細表示部項目(I, 退避情報型.明細項目型.区分))) <> 行区分型.メモ AndAlso
               Is省略判定(コード判定対象型.商品コード, _退避情報.明細表示部項目(I, 退避情報型.明細項目型.商品コード).ToString) = 省略判定結果型.省略 Then   'A-CUST20200311 '-20200527-001
                'MessageViewer.Show(1009, "OTS", IMessageViewer.DefaultButtonType.OK, (I + 1).ToString)      'D-CUST20230315
                MessageViewer.Show(999000008, "OTS", IMessageViewer.DefaultButtonType.OK, (I + 1).ToString)  'A-CUST20230315
                Return False
            End If
        Next

        Return True

    End Function

    ''' <summary>
    ''' 伝票データ更新処理
    ''' </summary>
    ''' <param name="executeCheckInfo">排他用情報</param>
    ''' <param name="result">更新結果</param>
    ''' <remarks></remarks>
    Private Sub Update_伝票データ(ByRef executeCheckInfo As IExecuteCheckInfo, ByRef result As IResult)

        Dim mode As 処理区分型 = CType(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード), 処理区分型)

        Dim updateParam As UpdateParam = GetCompletedValue(mode)
        result = UpdateDenpyouData(IDenpyouUpdater.テーブル一覧型.見積伝票, mode, updateParam, executeCheckInfo)

    End Sub

    ''' <summary>
    ''' 更新実行時のReadOnly設定
    ''' </summary>
    ''' <param name="setSwitch"></param>
    ''' <param name="mode"></param>
    ''' <remarks></remarks>
    Private Sub SetReadOnly_Uppdate(
                                ByVal setSwitch As Boolean,
                                ByVal mode As 処理区分型)

        '-----------------------------------
        '   ガイドメッセージ設定
        '-----------------------------------
        If setSwitch = True Then
            Dim messageNo As Integer
            Select Case mode
                Case 処理区分型.登録
                    messageNo = 100
                Case 処理区分型.修正
                    messageNo = 101
                Case 処理区分型.削除
                    messageNo = 102
            End Select
            MessageViewer.Show(messageNo)
        Else
            StatusBar.StatusLabelControl.Text = ""
        End If

        '-----------------------------------
        '   更新前 ReadOnly解除
        '-----------------------------------
        '更新開始時のみ
        If setSwitch = True Then
            Select Case mode
                Case 処理区分型.削除
                    SetReadOnly_確定処理(False)
            End Select
        End If

        '-----------------------------------
        '   フォームの「×」ボタン制御
        '-----------------------------------
        CType(Me, DesignFormBase).CloseBox = Not setSwitch

        '-----------------------------------
        '   更新用 ReadOnly設定
        '-----------------------------------
        SetReadOnly_Form(setSwitch, True)

        '-----------------------------------
        '   更新後 ReadOnly再設定
        '-----------------------------------
        '更新終了時のみ
        If setSwitch = False Then
            Select Case mode
                Case 処理区分型.削除
                    SetReadOnly_確定処理(True)
            End Select
        End If

    End Sub

    ''' <summary>
    ''' 「_changeCell.ColIndex」が移動可能セルか判断する
    ''' </summary>
    ''' <param name="args"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetChangeColIndex(ByVal args As GridCheckMethodArgs) As Integer

        Select Case _changeCell.ColIndex
            '項目別にチェックが必要な場合、ここに記述する

            Case Else

        End Select

        Return _changeCell.ColIndex

    End Function

    ''' <summary>
    ''' 更新用データを返す
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetCompletedValue(ByVal mode As 処理区分型) As UpdateParam

        Dim param As New UpdateParam

        GetCompleted更新条件(mode, param)

        'ワーク・ヘッダー
        GetCompletedワーク_ヘッダー(mode, param)

        'ワーク・明細
        GetCompletedワーク_明細(mode, param)

        Return param

    End Function

    Private Sub InitializeDataTable更新条件(ByVal mode As 処理区分型, ByRef 更新条件 As DataTable)

        With 更新条件.Columns
            .Clear()
            .Add(New DataColumn(UpdateParam.更新条件型.当期期首年月日.ToString, GetType(String)))
            .Add(New DataColumn(UpdateParam.更新条件型.明細行数.ToString, GetType(Integer)))
            .Add(New DataColumn(UpdateParam.更新条件型.伝票番号.ToString, GetType(Long)))
            .Add(New DataColumn(UpdateParam.更新条件型.更新番号.ToString, GetType(Decimal)))

        End With
        _退避情報.CreateAddRow(更新条件)

    End Sub

    Private Sub GetCompleted更新条件(ByVal mode As 処理区分型, ByRef param As UpdateParam)

        Dim 更新条件 As New DataTable

        InitializeDataTable更新条件(mode, 更新条件)

        With 更新条件.Rows(0)
            .Item(UpdateParam.更新条件型.当期期首年月日.ToString) = _myコントロール情報.期首年月日
            .Item(UpdateParam.更新条件型.明細行数.ToString) = _maxRowCount
            .Item(UpdateParam.更新条件型.伝票番号.ToString) = _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理連番)
            Select Case mode
                Case 処理区分型.修正,
                     処理区分型.削除
                    .Item(UpdateParam.更新条件型.更新番号.ToString) = _退避情報.見積ヘッダー項目("CUSRE11999")

                Case Else
                    .Item(UpdateParam.更新条件型.更新番号.ToString) = 0

            End Select
        End With

        param.Container(UpdateParam.項目名型.更新条件) = 更新条件

    End Sub

    Private Sub GetCompletedワーク_ヘッダー(ByVal mode As 処理区分型, ByRef param As UpdateParam)

        Dim ワーク As New DataTable

        InitializeDataTableワーク(ワーク)
        _退避情報.CreateAddRow(ワーク)

        With ワーク.Rows(0)
            .Item("CUSWE01001") = システム環境情報.プログラム情報.実行ID
            .Item("CUSWE01002") = 1
            .Item("CUSWE01003") = 0
            .Item("CUSWE01004") = 0
            .Item("CUSWE01005") = 0

            'Dim WE01006(18) As String  'D-CUST20201013
            'Dim WE01006(19) As String   'A-CUST20201013    'D-CUST20251104
            Dim WE01006(49) As String   'A-CUST20251104
            AutoCnt = -1
            WE01006(AutoCnt) = CStr(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理連番))
            WE01006(AutoCnt) = CStr(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.伝票日付))
            WE01006(AutoCnt) = CStr(Val(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.税率)).ToString("0.00"))
            WE01006(AutoCnt) = CStr(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.消費税コード))
            WE01006(AutoCnt) = CStr(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.得意先コード))
            WE01006(AutoCnt) = CStr(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.担当者コード))
            WE01006(AutoCnt) = CStr(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.部門コード))
            WE01006(AutoCnt) = CStr(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.要件))
            WE01006(AutoCnt) = CStr(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.納期))
            WE01006(AutoCnt) = CStr(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.支払方法))
            WE01006(AutoCnt) = CStr(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.有効期限))
            WE01006(AutoCnt) = CStr(_退避情報.フッター部項目(退避情報型.フッター項目型.備考名))
            WE01006(AutoCnt) = CStr(_退避情報.フッター部項目(退避情報型.フッター項目型.対象金額))
            WE01006(AutoCnt) = CStr(_退避情報.フッター部項目(退避情報型.フッター項目型.消費税額))
            WE01006(AutoCnt) = CStr(_退避情報.フッター部項目(退避情報型.フッター項目型.合計金額))
            WE01006(AutoCnt) = CStr(_退避情報.フッター部項目(退避情報型.フッター項目型.粗利額合計))
            WE01006(AutoCnt) = CStr(_退避情報.フッター部項目(退避情報型.フッター項目型.更新用_非課税額))

            If mode = 処理区分型.登録 Then
                WE01006(AutoCnt) = "0"
                WE01006(AutoCnt) = "0"
            Else
                WE01006(AutoCnt) = CStr(_退避情報.見積ヘッダー項目("CUSRE11018"))
                WE01006(AutoCnt) = CStr(_退避情報.見積ヘッダー項目("CUSRE11019"))
            End If

            'A-CUST20201013↓
            WE01006(AutoCnt) = CStr(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.納品先コード))
            'A-CUST20201013↑

            'A-CUST20251104↓
            For i As Integer = 1 To EXPANDITEMCOUNT
                WE01006(AutoCnt) = CStr(_退避情報.FieldBuilderヘッダー項目("CUSRE11K" & i.ToString("D3")))
            Next
            'A-CUST20251104↑

            'A-CUST20230315↓
            For i As Integer = 0 To WE01006.Length - 1
                WE01006(i) = WE01006(i).Replace(vbTab, " ")
            Next
            'A-CUST20230315↑

            .Item("CUSWE01006") = String.Join(vbTab, WE01006)
            .Item("CUSWE01007") = CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード)) - 1
            .Item("CUSWE01008") = _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理連番)
            .Item("CUSWE01009") = 5
            .Item("CUSWE01010") = 0

            If mode = 処理区分型.登録 Then
                'D-CUST20220425↓
                '.Item("CUSWE01993") = システム環境情報.プログラム情報.ID.TrimEnd
                '.Item("CUSWE01994") = システム環境情報.ログオンユーザー情報.ID.TrimEnd
                '.Item("CUSWE01995") = 0
                'D-CUST20220425↑
                'A-CUST20220425↓
                .Item("CUSWE01991") = システム環境情報.プログラム情報.オリジナルID.TrimEnd
                .Item("CUSWE01992") = システム環境情報.プログラム情報.枝番
                .Item("CUSWE01993") = システム環境情報.ログオンユーザー情報.ID.TrimEnd
                .Item("CUSWE01INS") = 0
                'A-CUST20220425↑
                .Item("CUSWE01999") = 0
            Else
                'D-CUST20220425↓
                '.Item("CUSWE01993") = _退避情報.見積ヘッダー項目("CUSRE11993")
                '.Item("CUSWE01994") = _退避情報.見積ヘッダー項目("CUSRE11994")
                '.Item("CUSWE01995") = _退避情報.見積ヘッダー項目("CUSRE11995")
                'D-CUST20220425↑
                'A-CUST20220425↓
                .Item("CUSWE01991") = _退避情報.見積ヘッダー項目("CUSRE11991")
                .Item("CUSWE01992") = _退避情報.見積ヘッダー項目("CUSRE11992")
                .Item("CUSWE01993") = _退避情報.見積ヘッダー項目("CUSRE11993")
                .Item("CUSWE01INS") = _退避情報.見積ヘッダー項目("CUSRE11INS")
                'A-CUST20220425↑
                .Item("CUSWE01999") = Val(_退避情報.見積ヘッダー項目("CUSRE11999")) + 1
            End If
            'D-CUST20220425↓
            '.Item("CUSWE01996") = システム環境情報.プログラム情報.ID.TrimEnd
            '.Item("CUSWE01997") = システム環境情報.ログオンユーザー情報.ID.TrimEnd
            '.Item("CUSWE01998") = 0
            'D-CUST20220425↑
            'A-CUST20220425↓
            .Item("CUSWE01994") = システム環境情報.プログラム情報.オリジナルID.TrimEnd
            .Item("CUSWE01995") = システム環境情報.プログラム情報.枝番
            .Item("CUSWE01996") = システム環境情報.ログオンユーザー情報.ID.TrimEnd
            .Item("CUSWE01UPD") = 0         'A-CUST20241219
            'A-CUST20220425↑

            'マスターチェック用
            .Item("CHECK001") = _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.得意先コード)
            .Item("CHECK002") = _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.担当者コード)
            .Item("CHECK003") = _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.部門コード)
            .Item("CHECK004") = _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.消費税コード)
        End With

        _退避情報.RemoveJunkColumns(ワーク)
        param.Container(UpdateParam.項目名型.ワーク_ヘッダー) = ワーク

    End Sub

    Private Sub GetCompletedワーク_明細(ByVal mode As 処理区分型, ByRef param As UpdateParam)

        Dim ワーク_明細 As New DataTable
        Dim ワーク_サブ明細 As New DataTable   'A-CUST20241219

        Dim ワーク_ヘッダー As DataTable = CType(param.Container(UpdateParam.項目名型.ワーク_ヘッダー), DataTable)

        ワーク_明細 = ワーク_ヘッダー.Clone
        ワーク_サブ明細 = ワーク_ヘッダー.Clone   'A-CUST20241219

        'A-CUST20200311↓ '-20200527
        Dim 数量Format As String = "0"
        If _myコントロール情報.小数桁_数量 > 0 Then
            数量Format = "0." & New String("0"c, _myコントロール情報.小数桁_数量)
        End If
        Dim 売上単価Format As String = "0"
        If _myコントロール情報.小数桁_売上単価 > 0 Then
            売上単価Format = "0." & New String("0"c, _myコントロール情報.小数桁_売上単価)
        End If
        Dim 仕入単価Format As String = "0"
        If _myコントロール情報.小数桁_仕入単価 > 0 Then
            仕入単価Format = "0." & New String("0"c, _myコントロール情報.小数桁_仕入単価)
        End If
        'A-CUST20200311↑ '-20200527

        For row As Integer = 0 To _maxRowCount - 1

            _退避情報.CreateAddRow(ワーク_明細)

            With ワーク_明細.Rows(row)
                .Item("CUSWE01001") = システム環境情報.プログラム情報.実行ID
                .Item("CUSWE01002") = 1
                .Item("CUSWE01003") = 1
                .Item("CUSWE01004") = 0
                .Item("CUSWE01005") = row + 1

                'Dim WE01006(17) As String      'D-CUST20211001
                'Dim WE01006(18) As String       'A-CUST20211001    'D-CUST20251104
                Dim WE01006(48) As String        'A-CUST20251104
                AutoCnt = -1
                WE01006(AutoCnt) = CStr(_退避情報.明細表示部項目(row, 退避情報型.明細項目型.行))
                WE01006(AutoCnt) = CStr(_退避情報.明細表示部項目(row, 退避情報型.明細項目型.区分))
                WE01006(AutoCnt) = CStr(_退避情報.明細表示部項目(row, 退避情報型.明細項目型.商品コード))
                WE01006(AutoCnt) = CStr(_退避情報.明細表示部項目(row, 退避情報型.明細項目型.商品名))
                WE01006(AutoCnt) = CStr(_退避情報.明細表示部項目(row, 退避情報型.明細項目型.課税区分))
                WE01006(AutoCnt) = CStr(_退避情報.明細表示部項目(row, 退避情報型.明細項目型.単位))
                WE01006(AutoCnt) = CStr(_退避情報.明細表示部項目(row, 退避情報型.明細項目型.倉庫コード))
                'WE01006(AutoCnt) = CStr(Val(_退避情報.明細表示部項目(row, 退避情報型.明細項目型.数量)).ToString("0." & New String("0"c, _myコントロール情報.小数桁_数量)))         'D-CUST20200311 '-20200527
                'WE01006(AutoCnt) = CStr(Val(_退避情報.明細表示部項目(row, 退避情報型.明細項目型.原単価)).ToString("0." & New String("0"c, _myコントロール情報.小数桁_仕入単価)))   'D-CUST20200311 '-20200527   
                WE01006(AutoCnt) = CStr(Val(_退避情報.明細表示部項目(row, 退避情報型.明細項目型.数量)).ToString(数量Format))                                                        'A-CUST20200311 '-20200527
                WE01006(AutoCnt) = CStr(Val(_退避情報.明細表示部項目(row, 退避情報型.明細項目型.原単価)).ToString(仕入単価Format))                                                  'A-CUST20200311 '-20200527   
                WE01006(AutoCnt) = CStr(_退避情報.明細表示部項目(row, 退避情報型.明細項目型.原価金額))
                'WE01006(AutoCnt) = CStr(Val(_退避情報.明細表示部項目(row, 退避情報型.明細項目型.単価)).ToString("0." & New String("0"c, _myコントロール情報.小数桁_売上単価)))     'D-CUST20200311 '-20200527  
                WE01006(AutoCnt) = CStr(Val(_退避情報.明細表示部項目(row, 退避情報型.明細項目型.単価)).ToString(売上単価Format))                                                    'A-CUST20200311 '-20200527   
                WE01006(AutoCnt) = CStr(_退避情報.明細表示部項目(row, 退避情報型.明細項目型.金額))
                WE01006(AutoCnt) = CStr(_退避情報.明細表示部項目(row, 退避情報型.明細項目型.行摘要))
                WE01006(AutoCnt) = CStr(_退避情報.明細表示部項目(row, 退避情報型.明細項目型.小計))
                WE01006(AutoCnt) = CStr(_退避情報.明細表示部項目(row, 退避情報型.明細項目型.改頁))
                WE01006(AutoCnt) = CStr(_退避情報.明細表示部項目(row, 退避情報型.明細項目型.内消費税額))


                If mode = 処理区分型.登録 OrElse
                  Val(_退避情報.明細表示部項目(row, 退避情報型.明細項目型.行ＤＢ値)) = 0 Then
                    WE01006(AutoCnt) = "0"
                    WE01006(AutoCnt) = "0"
                Else
                    WE01006(AutoCnt) = CStr(_退避情報.見積明細項目(CInt(Val(_退避情報.明細表示部項目(row, 退避情報型.明細項目型.行ＤＢ値))) - 1, "CUSRE12025"))
                    WE01006(AutoCnt) = CStr(_退避情報.見積明細項目(CInt(Val(_退避情報.明細表示部項目(row, 退避情報型.明細項目型.行ＤＢ値))) - 1, "CUSRE12026"))
                End If

                WE01006(AutoCnt) = CStr(_退避情報.明細表示部項目(row, 退避情報型.明細項目型.単価計算方法))     'A-CUST20211001

                'A-CUST20251104↓
                Dim kakutyo_m As New DataTable

                kakutyo_m = CType(_退避情報.明細表示部項目(row, 退避情報型.明細項目型.FieldBuilder), DataTable)
                If kakutyo_m IsNot Nothing OrElse kakutyo_m.Rows.Count > 0 Then
                    For i As Integer = 0 To kakutyo_m.Rows.Count - 1
                        For j As Integer = 0 To kakutyo_m.Columns.Count - 1
                            WE01006(AutoCnt) = CStr(kakutyo_m.Rows(i).Item("CUSRE12K" & (j + 1).ToString("D3")))
                        Next
                    Next
                End If
                'A-CUST20251104↑


                'A-CUST20230315↓
                For i As Integer = 0 To WE01006.Length - 1
                    WE01006(i) = WE01006(i).Replace(vbTab, " ")
                Next
                'A-CUST20230315↑

                .Item("CUSWE01006") = String.Join(vbTab, WE01006)
                .Item("CUSWE01007") = ワーク_ヘッダー.Rows(0).Item("CUSWE01007")
                .Item("CUSWE01008") = ワーク_ヘッダー.Rows(0).Item("CUSWE01008")
                .Item("CUSWE01009") = ワーク_ヘッダー.Rows(0).Item("CUSWE01009")
                .Item("CUSWE01010") = ワーク_ヘッダー.Rows(0).Item("CUSWE01010")


                If mode = 処理区分型.登録 OrElse
                  Val(_退避情報.明細表示部項目(row, 退避情報型.明細項目型.行ＤＢ値)) = 0 Then
                    'D-CUST20220425↓
                    '.Item("CUSWE01993") = システム環境情報.プログラム情報.ID.TrimEnd
                    '.Item("CUSWE01994") = システム環境情報.ログオンユーザー情報.ID.TrimEnd
                    '.Item("CUSWE01995") = -1
                    'D-CUST20220425↑
                    'A-CUST20220425↓
                    .Item("CUSWE01991") = システム環境情報.プログラム情報.オリジナルID.TrimEnd
                    .Item("CUSWE01992") = システム環境情報.プログラム情報.枝番
                    .Item("CUSWE01993") = システム環境情報.ログオンユーザー情報.ID.TrimEnd
                    .Item("CUSWE01INS") = -1
                    'A-CUST20220425↑
                    .Item("CUSWE01999") = 0
                Else
                    'D-CUST20220425↓
                    '.Item("CUSWE01993") = CStr(_退避情報.見積明細項目(CInt(Val(_退避情報.明細表示部項目(row, 退避情報型.明細項目型.行ＤＢ値)) - 1), "CUSRE12993"))
                    '.Item("CUSWE01994") = CStr(_退避情報.見積明細項目(CInt(Val(_退避情報.明細表示部項目(row, 退避情報型.明細項目型.行ＤＢ値)) - 1), "CUSRE12994"))
                    '.Item("CUSWE01995") = CStr(_退避情報.見積明細項目(CInt(Val(_退避情報.明細表示部項目(row, 退避情報型.明細項目型.行ＤＢ値)) - 1), "CUSRE12995"))
                    'D-CUST20220425↑
                    'A-CUST20220425↓
                    .Item("CUSWE01991") = CStr(_退避情報.見積明細項目(CInt(Val(_退避情報.明細表示部項目(row, 退避情報型.明細項目型.行ＤＢ値)) - 1), "CUSRE12991"))
                    .Item("CUSWE01992") = CDec(_退避情報.見積明細項目(CInt(Val(_退避情報.明細表示部項目(row, 退避情報型.明細項目型.行ＤＢ値)) - 1), "CUSRE12992"))
                    .Item("CUSWE01993") = CStr(_退避情報.見積明細項目(CInt(Val(_退避情報.明細表示部項目(row, 退避情報型.明細項目型.行ＤＢ値)) - 1), "CUSRE12993"))
                    .Item("CUSWE01INS") = CStr(_退避情報.見積明細項目(CInt(Val(_退避情報.明細表示部項目(row, 退避情報型.明細項目型.行ＤＢ値)) - 1), "CUSRE12INS"))
                    'A-CUST20220425↑
                    .Item("CUSWE01999") = Val(_退避情報.見積明細項目(CInt(Val(_退避情報.明細表示部項目(row, 退避情報型.明細項目型.行ＤＢ値)) - 1), "CUSRE12999")) + 1
                End If

                'D-CUST20220425↓
                '.Item("CUSWE01996") = ワーク_ヘッダー.Rows(0).Item("CUSWE01996")
                '.Item("CUSWE01997") = ワーク_ヘッダー.Rows(0).Item("CUSWE01997")
                '.Item("CUSWE01998") = ワーク_ヘッダー.Rows(0).Item("CUSWE01998")
                'D-CUST20220425↑
                'A-CUST20220425↓
                .Item("CUSWE01994") = ワーク_ヘッダー.Rows(0).Item("CUSWE01994")
                .Item("CUSWE01995") = ワーク_ヘッダー.Rows(0).Item("CUSWE01995")
                .Item("CUSWE01996") = ワーク_ヘッダー.Rows(0).Item("CUSWE01996")
                .Item("CUSWE01UPD") = ワーク_ヘッダー.Rows(0).Item("CUSWE01UPD")       'A-CUST20241219
                'A-CUST20220425↑

                'マスターチェック用
                .Item("CHECK001") = _退避情報.明細表示部項目(row, 退避情報型.明細項目型.区分)
                .Item("CHECK002") = _退避情報.明細表示部項目(row, 退避情報型.明細項目型.商品コード)
                .Item("CHECK003") = _退避情報.明細表示部項目(row, 退避情報型.明細項目型.倉庫コード)
                .Item("CHECK004") = _退避情報.明細表示部項目(row, 退避情報型.明細項目型.課税区分)
            End With

            GetCompletedワーク_サブ明細(mode, ワーク_明細, row, ワーク_サブ明細)       'A-CUST20241219

        Next

        param.Container(UpdateParam.項目名型.ワーク_ヘッダー) = ワーク_ヘッダー

        _退避情報.RemoveJunkColumns(ワーク_明細)
        param.Container(UpdateParam.項目名型.ワーク_明細) = ワーク_明細

        'A-CUST20241219↓
        _退避情報.RemoveJunkColumns(ワーク_サブ明細)
        param.Container(UpdateParam.項目名型.ワーク_サブ明細) = ワーク_サブ明細
        'A-CUST20241219↑

    End Sub

    'A-CUST20241219↓
    Private Sub GetCompletedワーク_サブ明細(ByVal mode As 処理区分型,
                                            ByVal ワーク_明細 As DataTable,
                                            ByVal 明細Index As Integer,
                                            ByRef ワーク_サブ明細 As DataTable)

        _退避情報.サブ明細表示部 = CType(_退避情報.明細表示部項目(明細Index, 退避情報型.明細項目型.サブ明細情報), DataTable).Copy

        Dim 数量Format As String = "0"
        If _myコントロール情報.小数桁_数量 > 0 Then
            数量Format = "0." & New String("0"c, _myコントロール情報.小数桁_数量)
        End If
        Dim 売上単価Format As String = "0"
        If _myコントロール情報.小数桁_売上単価 > 0 Then
            売上単価Format = "0." & New String("0"c, _myコントロール情報.小数桁_売上単価)
        End If

        For row As Integer = 0 To _退避情報.サブ明細表示部.Rows.Count - 1

            If CBool(_退避情報.サブ明細表示部項目(row, 退避情報型.サブ明細項目型.行確定済)) = False Then
                Exit For
            End If

            _退避情報.CreateAddRow(ワーク_サブ明細)

            With ワーク_サブ明細.Rows(ワーク_サブ明細.Rows.Count - 1)

                .Item("CUSWE01001") = システム環境情報.プログラム情報.実行ID
                .Item("CUSWE01002") = 1
                .Item("CUSWE01003") = 2
                .Item("CUSWE01004") = 0
                .Item("CUSWE01005") = ワーク_サブ明細.Rows.Count

                Dim WE01006(7) As String
                AutoCnt = -1
                WE01006(AutoCnt) = CStr(_退避情報.明細表示部項目(明細Index, 退避情報型.明細項目型.行))
                WE01006(AutoCnt) = CStr(_退避情報.サブ明細表示部項目(row, 退避情報型.サブ明細項目型.行))
                WE01006(AutoCnt) = CStr(_退避情報.サブ明細表示部項目(row, 退避情報型.サブ明細項目型.商品コード))
                WE01006(AutoCnt) = CStr(_退避情報.サブ明細表示部項目(row, 退避情報型.サブ明細項目型.商品名))
                WE01006(AutoCnt) = CStr(_退避情報.サブ明細表示部項目(row, 退避情報型.サブ明細項目型.単位))
                WE01006(AutoCnt) = CStr(Val(_退避情報.サブ明細表示部項目(row, 退避情報型.サブ明細項目型.数量)).ToString(数量Format))
                WE01006(AutoCnt) = CStr(Val(_退避情報.サブ明細表示部項目(row, 退避情報型.サブ明細項目型.単価)).ToString(売上単価Format))
                WE01006(AutoCnt) = CStr(_退避情報.サブ明細表示部項目(row, 退避情報型.サブ明細項目型.金額))

                .Item("CUSWE01006") = String.Join(vbTab, WE01006)
                .Item("CUSWE01007") = ワーク_明細.Rows(明細Index).Item("CUSWE01007")
                .Item("CUSWE01008") = ワーク_明細.Rows(明細Index).Item("CUSWE01008")
                .Item("CUSWE01009") = ワーク_明細.Rows(明細Index).Item("CUSWE01009")
                .Item("CUSWE01010") = ワーク_明細.Rows(明細Index).Item("CUSWE01010")


                If mode = 処理区分型.登録 OrElse
                  Val(_退避情報.サブ明細表示部項目(row, 退避情報型.サブ明細項目型.行ＤＢ値)) = 0 Then
                    .Item("CUSWE01991") = システム環境情報.プログラム情報.オリジナルID.TrimEnd
                    .Item("CUSWE01992") = システム環境情報.プログラム情報.枝番
                    .Item("CUSWE01993") = システム環境情報.ログオンユーザー情報.ID.TrimEnd
                    .Item("CUSWE01INS") = -1
                    .Item("CUSWE01999") = 0
                Else
                    _退避情報.見積サブ明細 = CType(_退避情報.見積明細項目(CInt(Val(_退避情報.明細表示部項目(明細Index, 退避情報型.明細項目型.行ＤＢ値)) - 1), "CUSRE29DT"), DataTable).Copy
                    .Item("CUSWE01991") = CStr(_退避情報.見積サブ明細項目(CInt(Val(_退避情報.サブ明細表示部項目(row, 退避情報型.サブ明細項目型.行ＤＢ値)) - 1), "CUSRE29991"))
                    .Item("CUSWE01992") = CStr(_退避情報.見積サブ明細項目(CInt(Val(_退避情報.サブ明細表示部項目(row, 退避情報型.サブ明細項目型.行ＤＢ値)) - 1), "CUSRE29992"))
                    .Item("CUSWE01993") = CStr(_退避情報.見積サブ明細項目(CInt(Val(_退避情報.サブ明細表示部項目(row, 退避情報型.サブ明細項目型.行ＤＢ値)) - 1), "CUSRE29993"))
                    .Item("CUSWE01INS") = CStr(_退避情報.見積サブ明細項目(CInt(Val(_退避情報.サブ明細表示部項目(row, 退避情報型.サブ明細項目型.行ＤＢ値)) - 1), "CUSRE29INS"))
                    .Item("CUSWE01999") = Val(_退避情報.見積サブ明細項目(CInt(Val(_退避情報.サブ明細表示部項目(row, 退避情報型.サブ明細項目型.行ＤＢ値)) - 1), "CUSRE29999")) + 1
                End If

                .Item("CUSWE01994") = ワーク_明細.Rows(明細Index).Item("CUSWE01994")
                .Item("CUSWE01995") = ワーク_明細.Rows(明細Index).Item("CUSWE01995")
                .Item("CUSWE01996") = ワーク_明細.Rows(明細Index).Item("CUSWE01996")
                .Item("CUSWE01UPD") = ワーク_明細.Rows(明細Index).Item("CUSWE01UPD")

                'マスターチェック用
                .Item("CHECK001") = CStr(_退避情報.明細表示部項目(明細Index, 退避情報型.明細項目型.行))
                .Item("CHECK002") = CStr(_退避情報.サブ明細表示部項目(row, 退避情報型.サブ明細項目型.行))
                .Item("CHECK003") = _退避情報.サブ明細表示部項目(row, 退避情報型.サブ明細項目型.商品コード)
            End With

        Next

    End Sub
    'A-CUST20241219↑

    ''' <summary>
    ''' 正常終了時の更新後処理
    ''' </summary>
    ''' <param name="mode">処理区分</param>
    ''' <param name="result">更新結果</param>
    ''' <remarks></remarks>
    Private Sub Update_正常終了(ByVal mode As 処理区分型, ByVal result As IResult)

        Dim 更新後番号 As 更新後番号型

        更新後番号.Initialize()

        Select Case mode
            Case 処理区分型.修正
                GoTo Update_正常終了_Update
            Case 処理区分型.削除
                GoTo Update_正常終了_End
        End Select

        '-------------------------
        '   引渡しデータ値の分解
        '-------------------------

        '伝票へ登録した値
        更新後番号.伝票番号 = CLng(result.詳細情報取得(IResult.resultSucceed.伝票番号.ToString, 0))

        '-------------------------
        '   直前更新№の編集
        '-------------------------
        _更新後番号.伝票番号 = 更新後番号.伝票番号

        '-------------------------
        '   処理連番採番
        '-------------------------
        _退避情報.連番管理項目("CUSCE21008") = 更新後番号.伝票番号 + 1
        If CLng(_退避情報.連番管理項目("CUSCE21008")) > 9999999999 Then
            _退避情報.連番管理項目("CUSCE21008") = 1
        End If
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理連番) = CLng(_退避情報.連番管理項目("CUSCE21008"))


Update_正常終了_Update:

        '------------------------------
        '   見積書発行
        '------------------------------
        Dim 処理連番 As Long = 0
        Dim 発行済管理更新日 As Long = 0
        If CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.伝票発行)) <> 伝票発行型.なし Then
            If mode = 処理区分型.登録 Then
                処理連番 = 更新後番号.伝票番号
            Else
                処理連番 = CLng(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理連番))
            End If
            発行済管理更新日 = CLng(result.詳細情報取得(IResult.resultSucceed.発行済管理更新日時.ToString, 0))
            Print見積書(処理連番)
            DoUpdateSlipIssue(処理連番, 発行済管理更新日)
        End If

        StatusBar.StatusLabelControl.Text = ""

Update_正常終了_End:

        Clear(クリア型.全て)

        If CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード)) = 処理区分型.登録 Then
            Dim args As CheckMethodArgs = New CheckMethodArgs(execute, shori, CheckMethodArgs.移動方向型.後へ, Keys.None, False, 0)
            Header_初期表示(args, True)
        End If

        _退避情報.グループ状態(退避情報型.グループ型.No１) = 退避情報型.状態.正常


        _退避情報.グループ状態(退避情報型.グループ型.No２) = 退避情報型.状態.正常

    End Sub

    ''' <summary>
    ''' 更新エラー時の処理
    ''' </summary>
    ''' <param name="executeCheckInfo">排他用情報</param>
    ''' <param name="result">更新結果</param>
    ''' <remarks></remarks>
    Private Sub Update_エラー終了(ByVal executeCheckInfo As IExecuteCheckInfo, ByVal result As IResult)

        'エラーメッセージ表示
        Select Case result.結果
            Case IResult.resultError.同時実行不可

                Dim dialog As New ExecuteCheckDialog
                dialog.ShowMessage(Me, executeCheckInfo)

            Case IResult.resultError.締日更新中
                Me.MessageViewer.Show(result.エラー番号取得(result.結果.ToString), "OTS")

            Case Else

                Dim errorNo As Integer = 0
                Dim errorMessage(IResult.messageConnect.後尾) As String
                For index As Integer = 0 To errorMessage.Length - 1
                    errorMessage(index) = ""
                Next
                errorNo = result.エラー番号取得(result.結果.ToString)
                errorMessage(IResult.messageConnect.先頭) = CStr(result.エラー情報取得(result.結果.ToString, "", IResult.messageConnect.先頭))
                errorMessage(IResult.messageConnect.後尾) = CStr(result.エラー情報取得(result.結果.ToString, "", IResult.messageConnect.後尾))

                If errorNo = 0 Then
                    Dim errorMessageStyle As MsgBoxStyle = CType(MsgBoxStyle.OkOnly +
                                                                 MsgBoxStyle.DefaultButton1 +
                                                                 MsgBoxStyle.ApplicationModal +
                                                                 MsgBoxStyle.Exclamation,
                                                                 MsgBoxStyle)
                    OSK.X1.Foundation.UserInterface.OSKMessageBox.Show_MsgBox(Me, errorMessage(IResult.messageConnect.先頭) & errorMessage(IResult.messageConnect.後尾),
                           errorMessageStyle, Me.システム環境情報.プログラム情報.名称)
                Else
                    Me.MessageViewer.Show(errorNo,
                                          IMessageViewer.DefaultButtonType.OK,
                                          errorMessage(IResult.messageConnect.先頭),
                                          errorMessage(IResult.messageConnect.後尾))
                End If

        End Select

        Select Case result.結果
            Case IResult.resultError.一意制約違反,
                 IResult.resultError.他で更新済,
                 IResult.resultError.レコード無し

                If CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード)) = 処理区分型.登録 Then
                    '画面クリア
                    Clear(クリア型.全て)
                    '日付へ
                    _退避情報.グループ状態(退避情報型.グループ型.No１) = 退避情報型.状態.正常
                    _退避情報.グループ状態(退避情報型.グループ型.No２) = 退避情報型.状態.正常
                    _検索自動表示 = False
                    _検索データ選択 = False

                    denpyouDate.Focus()
                Else
                    '画面クリア
                    Clear(クリア型.全て)

                    '検索画面より選択時は、検索画面を再表示
                    If Is検索データ選択() = True Then
                        _検索自動表示 = True
                    End If

                    shoriRenban.InputNumericalControl.Focus()
                End If

            Case IResult.resultError.同時実行不可,
              IResult.resultError.マスター無し

                execute.Focus()

            Case Else
                _focusSwitcher.CurrentControl = Nothing
                Me.Close()

        End Select

    End Sub

    ''' <summary>
    ''' 更新後フォーカス移動
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub Update_フォーカス移動()

        If CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード)) = 処理区分型.登録 Then
            _検索データ選択 = False
            _検索自動表示 = False

            Set更新後フォーカス()
        Else
            If Is検索データ選択() = True Then
                _検索自動表示 = True
            End If
            shoriRenban.InputNumericalControl.Focus()
        End If

    End Sub

#End Region

#Region "チェック処理"

    Private Function Check伝票() As Boolean

        If CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード)) = 処理区分型.登録 Or
           _退避情報.起動モード = 起動モード型.詳細モード Then
            GoTo Check伝票_End
        End If

        '---------------------
        '  対象年月チェック
        '---------------------
        If Check伝票_対象年月() = False Then
            GoTo Check伝票_Error
        End If

        '---------------------
        '  受注引き当て済みチェック
        '---------------------
        If Check伝票_受注引き当て済み() = False Then
            GoTo Check伝票_Error
        End If

        'A-CUST20200311↓ '-20200527-002
        '---------------------
        '  売上引き当て済みチェック
        '---------------------
        If Check伝票_売上引き当て済み() = False Then
            GoTo Check伝票_Error
        End If
        'A-CUST20200311↑ '-20200527-002

Check伝票_End:

        Return True

Check伝票_Error:
        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理連番) = 0
        _ドリルダウン = False

        Return False

    End Function

    Private Function Check伝票_対象年月() As Boolean

        '入力可能日付チェック
        Dim check As Integer = 0

        _日付チェック.CheckDate(_myコントロール情報.期首年月日, _myコントロール情報.入力可能期間, CInt(_退避情報.見積ヘッダー項目("CUSRE11002")), check)

        If check = 1 Then
            'MessageViewer.Show(1001, "OTS")      'D-CUST20230315
            MessageViewer.Show(999000000, "OTS")  'A-CUST20230315
            Return False
        End If

        Return True

    End Function

    Private Function Check伝票_受注引き当て済み() As Boolean

        '受注引き当て済みチェック
        Dim check As Integer = 0

        If Val(_退避情報.見積ヘッダー項目("CUSRE11018")) <> 0 Then
            If shori.Value = 処理区分型.修正 Then
                check = 1
            ElseIf shori.Value = 処理区分型.削除 Then
                check = 2
            End If
        End If

        If check = 1 Then
            If OSK.X1.Foundation.UserInterface.OSKMessageBox.Show(Me, メッセージ定数型.MASSAGE_A04, システム環境情報.プログラム情報.名称, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) <> DialogResult.Yes Then
                Return False
            End If
        ElseIf check = 2 Then
            OSK.X1.Foundation.UserInterface.OSKMessageBox.Show(Me, メッセージ定数型.MASSAGE_A02, システム環境情報.プログラム情報.名称, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return False
        End If

        Return True

    End Function

    'A-CUST20200311↓ '-20200527-002
    Private Function Check伝票_売上引き当て済み() As Boolean

        '売上引き当て済みチェック
        Dim check As Integer = 0

        If Val(_退避情報.見積ヘッダー項目("CUSRE11019")) <> 0 Then
            If shori.Value = 処理区分型.修正 Then
                check = 1
            ElseIf shori.Value = 処理区分型.削除 Then
                check = 2
            End If
        End If

        If check = 1 Then
            If OSK.X1.Foundation.UserInterface.OSKMessageBox.Show(Me, メッセージ定数型.MASSAGE_A06, システム環境情報.プログラム情報.名称, MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) <> DialogResult.Yes Then
                Return False
            End If
        ElseIf check = 2 Then
            OSK.X1.Foundation.UserInterface.OSKMessageBox.Show(Me, メッセージ定数型.MASSAGE_A07, システム環境情報.プログラム情報.名称, MessageBoxButtons.OK, MessageBoxIcon.Information)
            Return False
        End If

        Return True

    End Function
    'A-CUST20200311↑ '-20200527-002

    ''' <summary>
    ''' 伝票表示前チェック
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function Check伝票_表示前チェック() As Boolean

        Dim 修飾登録 As Boolean = False

        If Is検索データ選択() = True Then
            If CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード)) = 処理区分型.登録 Then
                修飾登録 = True
            End If
        End If

        Return True

    End Function

    ''' <summary>
    ''' 伝票 データセキュリティチェック
    ''' </summary>
    ''' <param name="KeyDownCode"></param>
    ''' <returns> 0：正常／ -1：エラー（伝票表示不可）／ -2：エラー（伝票表示可）</returns>
    ''' <remarks></remarks>
    Private Function Check伝票_データセキュリティ(
                            ByVal KeyDownCode As System.Windows.Forms.Keys,
                            ByRef MessageNo As Integer) As Integer

        Dim param As New ReadParam

        '入力セキュリティチェック
        With param
            .Container(ReadParam.項目名型.セキュリティ種別) = 0
            .Container(ReadParam.項目名型.ログインID) = Me.システム環境情報.ログオンユーザー情報.ID
            .Container(ReadParam.項目名型.部門コード) = _退避情報.見積ヘッダー項目("CUSRE11008")
        End With
        If Check_セキュリティ(param) = False Then
            'MessageViewer.Show(1005, "OTS")      'D-CUST20230315
            MessageViewer.Show(999000004, "OTS")  'A-CUST20230315
            Return -1
        End If

        Return 0

    End Function

    ''' <summary>
    ''' 明細選択表示時 クリアチェック
    ''' </summary>
    ''' <remarks></remarks>
    Private Function Check明細表示前チェック() As Boolean

        If is行確定済判定() = True Then
            If DetailGridView.ListIndex = Val(_退避情報.明細入力部項目(退避情報型.明細項目型.行)) - 1 Then
                Return False
            Else
                'If MessageViewer.Show(1006, "OTS", IMessageViewer.DefaultButtonType.No) = IMessageViewer.ShowResultType.No Then      'D-CUST20230315
                If MessageViewer.Show(999000005, "OTS", IMessageViewer.DefaultButtonType.No) = IMessageViewer.ShowResultType.No Then  'A-CUST20230315
                    Return False
                End If
            End If
        End If

        Return True

    End Function

    ''' <summary>
    ''' 伝票読込コントロール判断
    ''' </summary>
    ''' <param name="targetControl">対象コントロール</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function Is伝票読込コントロール判断(ByVal targetControl As Control) As Boolean

        Select Case targetControl.Name
            Case denpyouDate.Name
                Return True
            Case DetailGridView.Name
                If CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード)) = 処理区分型.削除 Then
                    Return True
                End If
        End Select

        Return False

    End Function

    ''' <summary>
    ''' グリッド内部のフォーカス移動方向
    ''' </summary>
    ''' <param name="移動元"></param>
    ''' <param name="移動先"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function Isグリッド内移動方向(ByVal 移動元 As CellInfoType,
                                          ByVal 移動先 As CellInfoType,
                                          Optional ByVal gridEdit As OSK.X1.Foundation.Controls.GridEdit = Nothing) As CheckMethodArgs.移動方向型

        If _全行一括チェック中 = True Then
            Return CheckMethodArgs.移動方向型.前へ
        End If

        If gridEdit Is Nothing Then
            If 移動先.RowIndex = -1 Then
                Return CheckMethodArgs.移動方向型.前へ
            End If
        End If

        If CInt(Format(移動元.RowIndex, "000") & Format(移動元.TabIndex, "000")) <=
               CInt(Format(移動先.RowIndex, "000") & Format(移動先.TabIndex, "000")) Then
            Return CheckMethodArgs.移動方向型.後へ
        Else
            Return CheckMethodArgs.移動方向型.前へ
        End If

    End Function

    ''' <summary>
    ''' グリッド内でフォーカスが他行へ移動か判定
    ''' </summary>
    ''' <param name="移動元"></param>
    ''' <param name="移動先"></param>
    ''' <returns>False：同一行の移動／True：他行へ移動</returns>
    ''' <remarks></remarks>
    Private Function Isグリッド内他行移動(ByVal 移動元 As CellInfoType, ByVal 移動先 As CellInfoType) As Boolean

        If _gridKeyDownCode = Keys.None Then
            'マウスクリックも同じ扱いとする
            Return True
        End If

        If 移動元.RowIndex <> 移動先.RowIndex Then
            Return True
        End If

        Return False

    End Function

    ''' <summary>
    ''' セルのEditType状態を返す
    ''' </summary>
    ''' <param name="gridEdit">グリッド</param>
    ''' <param name="rowindex">行番号</param>
    ''' <param name="colindex">カラムインデックス</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function Isセル状態_EditType(ByVal gridEdit As OSK.X1.Foundation.SimpleControl.GridEdit,
                                         ByVal rowindex As Integer,
                                         ByVal colindex As Integer) As GridEditType

        Return CType(gridEdit.GetCellProperty(rowindex, colindex, Grid.GridCellProperty.EditType), GridEditType)

    End Function

    ''' <summary>
    ''' セルのEditType状態を返す
    ''' </summary>
    ''' <param name="gridEdit">グリッド</param>
    ''' <param name="rowindex">行番号</param>
    ''' <param name="colName">カラム名</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function Isセル状態_EditType(ByVal gridEdit As OSK.X1.Foundation.SimpleControl.GridEdit,
                                         ByVal rowindex As Integer,
                                         ByVal colName As String) As GridEditType

        Return CType(gridEdit.GetCellProperty(rowindex, colName, Grid.GridCellProperty.EditType), GridEditType)

    End Function

    ''' <summary>
    ''' セルのReadOnly状態を返す
    ''' </summary>
    ''' <param name="gridEdit">グリッド</param>
    ''' <param name="rowindex">行番号</param>
    ''' <param name="colindex">カラムインデックス</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function Isセル状態_ReadOnly(ByVal gridEdit As OSK.X1.Foundation.SimpleControl.GridEdit,
                                         ByVal rowindex As Integer,
                                         ByVal colindex As Integer) As Boolean

        Dim result_ReadOnly As Grid.Common.Boolean
        result_ReadOnly = CType(gridEdit.GetCellProperty(rowindex, colindex, Grid.GridCellProperty.ReadOnly), Grid.Common.Boolean)

        Return CBool(result_ReadOnly)

    End Function

    ''' <summary>
    ''' セルのReadOnly状態を返す
    ''' </summary>
    ''' <param name="gridEdit">グリッド</param>
    ''' <param name="rowindex">行番号</param>
    ''' <param name="colName">カラム</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function Isセル状態_ReadOnly(ByVal gridEdit As OSK.X1.Foundation.SimpleControl.GridEdit,
                                         ByVal rowindex As Integer,
                                         ByVal colName As String) As Boolean

        Dim result_ReadOnly As Grid.Common.Boolean
        result_ReadOnly = CType(gridEdit.GetCellProperty(rowindex, colName, Grid.GridCellProperty.ReadOnly), Grid.Common.Boolean)

        Return CBool(result_ReadOnly)

    End Function

    Private Function Is検索データ選択() As Boolean

        Select Case _検索種類
            Case 検索種類型.伝票検索
                Return _検索データ選択

        End Select
        Return False

    End Function

    ''' <summary>
    ''' 管理対象コントロールか判定
    ''' </summary>
    ''' <param name="control"></param>
    ''' <returns>False：対象外 True：対象</returns>
    ''' <remarks>FocusSwitcher登録対象かどうかの判定</remarks>
    Private Function Is管理対象コントロール判定(ByVal control As System.Windows.Forms.Control) As Boolean

        If TypeOf control Is OSK.X1.Foundation.Controls.Common.Control = True Then
            Select Case True
                Case TypeOf control Is OSK.X1.Foundation.SimpleControl.CheckBox
                Case TypeOf control Is OSK.X1.Foundation.SimpleControl.ComboBox
                Case TypeOf control Is OSK.X1.Foundation.SimpleControl.CommandButton
                Case TypeOf control Is OSK.X1.Foundation.SimpleControl.GridEdit
                Case TypeOf control Is OSK.X1.Foundation.SimpleControl.GroupOption
                Case TypeOf control Is OSK.X1.Foundation.SimpleControl.InputDate
                Case TypeOf control Is OSK.X1.Foundation.SimpleControl.InputNumerical
                Case TypeOf control Is OSK.X1.Foundation.SimpleControl.InputText
                Case Else
                    Return False
            End Select

            Dim fcControl As OSK.X1.Foundation.Controls.Common.Control
            fcControl = CType(control, OSK.X1.Foundation.Controls.Common.Control)

            If fcControl.ReadOnly = True Then
                Return False
            End If

        ElseIf TypeOf control Is OSK.X1.Foundation.Controls.GridEdit = True Then
        ElseIf TypeOf control Is OSK.X1.Foundation.Controls.GridView = True Then

        Else
            Return False
        End If

        Return True

    End Function

    ''' <summary>
    ''' 現在庫情報を取得するか否かの判定
    ''' </summary>
    ''' <param name="rowIndex"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function Is現在庫取得判定(ByVal rowIndex As Integer, ByVal colName As String) As Boolean

        '前回取得行と同一行は、取得不要
        If _getGenZaikoLine = rowIndex Then
            Return False
        End If

        '在庫管理を行わない商品の場合、取得不要
        Dim 商品情報 As DataTable = CType(_退避情報.明細入力部項目(退避情報型.明細項目型.商品マスター情報), DataTable)
        If CStr(商品情報.Rows(0).Item("CUSME03016")) <> "01" Then
            Return False
        End If

        '現在コントロールにより取得要否を判定
        Select Case colName
            Case 退避情報型.明細項目型.区分.ToString,
                 退避情報型.明細項目型.行.ToString,
                 退避情報型.明細項目型.商品コード.ToString
                If Is商品確定済判定(rowIndex) = False Then
                    Return False
                End If
        End Select
        Return True

    End Function

    ''' <summary>
    ''' 行挿入可能かどうか判定
    ''' </summary>
    ''' <param name="GridView"></param>
    ''' <returns>False：行挿入不可 True：行挿入可能</returns>
    ''' <remarks></remarks>
    Private Function Is行挿入可否(ByVal GridView As OSK.X1.Foundation.SimpleControl.GridView) As Boolean

        If _maxRowCount = _limitMaxRow Then
            Return False
        End If

        'If Is関連受注明細存在(GridView) Then       'D-CUST20200311 '-20200527-002
        If Is関連明細存在(GridView) Then            'A-CUST20200311 '-20200527-002  
            Return False
        End If

        Return True

    End Function

    ''' <summary>
    ''' 行削除可能かどうか判定
    ''' </summary>
    ''' <param name="GridView"></param>
    ''' <returns>False：行削除不可 True：行削除可能</returns>
    ''' <remarks></remarks>
    Private Function Is行削除可否(ByVal GridView As OSK.X1.Foundation.SimpleControl.GridView) As Boolean

        'If Is関連受注明細存在(GridView) Then       'D-CUST20200311 '-20200527-002
        If Is関連明細存在(GridView) Then            'A-CUST20200311 '-20200527-002
            Return False
        End If

        Return True

    End Function

    'D-CUST20200311↓ '-20200527-002
    '''' <summary>
    '''' 下位行に関連受注明細が存在するかチェック
    '''' </summary>
    '''' <param name="GridView"></param>
    '''' <returns>False：未存在 True：存在</returns>
    '''' <remarks></remarks>
    'Private Function Is関連受注明細存在(ByVal GridView As OSK.X1.Foundation.SimpleControl.GridView) As Boolean

    '    Dim mode As 処理区分型 = CType(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード), 処理区分型)

    '    If mode <> 処理区分型.登録 Then
    '        If GridView.ListIndex >= 0 Then
    '            For I As Integer = GridView.ListIndex To _maxRowCount - 1
    '                If Val(_退避情報.明細表示部項目(I, 退避情報型.明細項目型.行ＤＢ値)) <> 0 AndAlso
    '                   Val(CStr(_退避情報.見積明細項目(CInt(Val(_退避情報.明細表示部項目(I, 退避情報型.明細項目型.行ＤＢ値))) - 1, "CUSRE12025"))) <> 0 Then
    '                    Return True
    '                End If
    '            Next
    '        End If

    '    End If

    '    Return False

    'End Function
    'D-CUST20200311↑ '-20200527-002
    'A-CUST20200311↓ '-20200527-002
    ''' <summary>
    ''' 下位行に関連明細が存在するかチェック
    ''' </summary>
    ''' <param name="GridView"></param>
    ''' <returns>False：未存在 True：存在</returns>
    ''' <remarks></remarks>
    Private Function Is関連明細存在(ByVal GridView As OSK.X1.Foundation.SimpleControl.GridView) As Boolean

        Dim mode As 処理区分型 = CType(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード), 処理区分型)

        If mode <> 処理区分型.登録 Then
            If GridView.ListIndex >= 0 Then
                For I As Integer = GridView.ListIndex To _maxRowCount - 1
                    If Val(_退避情報.明細表示部項目(I, 退避情報型.明細項目型.行ＤＢ値)) <> 0 Then
                        '関連受注
                        If Val(CStr(_退避情報.見積明細項目(CInt(Val(_退避情報.明細表示部項目(I, 退避情報型.明細項目型.行ＤＢ値))) - 1, "CUSRE12025"))) <> 0 Then
                            Return True
                        End If
                        '関連売上
                        If Val(CStr(_退避情報.見積明細項目(CInt(Val(_退避情報.明細表示部項目(I, 退避情報型.明細項目型.行ＤＢ値))) - 1, "CUSRE12026"))) <> 0 Then
                            Return True
                        End If
                    End If
                Next
            End If

        End If

        Return False

    End Function
    'A-CUST20200311↑ '-20200527-002

    ''' <summary>
    ''' 入力グリッドに表示されているものが新規行かどうか判定
    ''' </summary>
    ''' <returns>False：修正 True：新規</returns>
    ''' <remarks></remarks>
    Private Function Is新規行判定() As Boolean

        If RowStatelbl.Text = "新規行" Then
            Return True
        End If

        Return False

    End Function

    ''' <summary>
    ''' 伝票呼出時に売上税率を呼び出し元から採用するか判定
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function Is呼出元売上税率採用() As Boolean

        If CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード)) <> 処理区分型.登録 Then
            '修正／削除時は、呼出元を採用
            Return True
        End If

        Return False

    End Function

    ''' <summary>
    ''' 行が確定済かどうか判定
    ''' </summary>
    ''' <returns>False：未確定 True：確定</returns>
    ''' <remarks></remarks>
    Private Function is行確定済判定() As Boolean

        'If CInt(Val(_退避情報.明細入力部項目(退避情報型.明細項目型.区分))) <> 取引区分属性型.メモ AndAlso          
        'Is省略判定(コード判定対象型.商品コード, _退避情報.明細入力部項目(退避情報型.明細項目型.商品コード).ToString) = 省略判定結果型.省略 Then          'D-CUST20200311 '-20200527-001
        If CInt(Val(_退避情報.明細入力部項目(退避情報型.明細項目型.区分))) <> 行区分型.メモ AndAlso
                Is省略判定(コード判定対象型.商品コード, _退避情報.明細入力部項目(退避情報型.明細項目型.商品コード).ToString) = 省略判定結果型.省略 Then   'A-CUST20200311 '-20200527-001  
            Return False
        End If

        Return True

    End Function

    ''' <summary>
    ''' 商品コードが確定済かどうか判定
    ''' </summary>
    ''' <param name="rowIndex"></param>
    ''' <returns>False：未確定 True：確定</returns>
    ''' <remarks></remarks>
    Private Function Is商品確定済判定(ByVal rowIndex As Integer) As Boolean

        Dim shohinCode As String = CStr(DetailGridEdit.GetData(rowIndex, 退避情報型.明細項目型.商品コード.ToString)).TrimEnd
        Dim gyoKbn As String = CStr(DetailGridEdit.GetData(rowIndex, 退避情報型.明細項目型.区分.ToString)).TrimEnd

        'If Val(gyoKbn) = 取引区分属性型.メモ Then               'D-CUST20200311 '-20200527-001
        If Val(gyoKbn) = 行区分型.メモ Then                      'A-CUST20200311 '-20200527-001 
            Return True
        End If

        If Is省略判定(コード判定対象型.商品コード, shohinCode) = 省略判定結果型.省略 Then
            Return False
        End If

        If shohinCode <> CStr(_退避情報.明細入力部項目(退避情報型.明細項目型.商品コード)) Then
            Return False
        End If

        Return True

    End Function

    ''' <summary>
    ''' _maxRowCountを加算してよいか否か
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function Is確定行加算可否() As Boolean

        Dim 条件１ As Boolean = False
        Dim 条件２ As Boolean = False

        If _fromCell.RowIndex + 1 = _limitMaxRow AndAlso Is商品確定済判定(_fromCell.RowIndex) = True Then
            条件１ = True
        End If

        If _fromCell.RowIndex + 1 <> DetailGridEdit.RowCount Then
            条件２ = True
        End If

        If 条件１ = False AndAlso 条件２ = False Then
            Return False
        End If

        If _fromCell.RowIndex + 1 <= _maxRowCount Then
            Return False
        End If

        Return True

    End Function

    ''' <summary>
    ''' 対象コードが省略値かどうか判定
    ''' </summary>
    ''' <param name="checkTarget">種類</param>
    ''' <param name="codeString">内容値</param>
    ''' <returns>False：非省略値 True：省略値</returns>
    ''' <remarks></remarks>
    Private Function Is省略判定(ByVal checkTarget As コード判定対象型, ByVal codeString As String) As 省略判定結果型

        Dim result As Boolean = False

        Select Case checkTarget
            Case コード判定対象型.取引先コード
                result = Val(codeString) = 0

            Case コード判定対象型.担当者コード
                result = Val(codeString) = 0

            Case コード判定対象型.部門コード
                result = Val(codeString) = 0

            Case コード判定対象型.倉庫コード
                result = Val(codeString) = 0

            Case コード判定対象型.商品コード
                result = codeString.Trim = ""

            Case コード判定対象型.区分
                result = Val(codeString) = 0

                'A-CUST20201013↓
            Case コード判定対象型.納品先コード
                result = Val(codeString) = 0
                'A-CUST20201013↑
        End Select

        If result = True Then
            Return 省略判定結果型.省略
        Else
            Return 省略判定結果型.入力
        End If

    End Function

    ''' <summary>
    ''' 対象コードが等しいかどうか判定
    ''' </summary>
    ''' <param name="checkTarget">種類</param>
    ''' <param name="対象コード">対象コード</param>
    ''' <param name="比較コード">比較コード</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function Is等式判定(ByVal checkTarget As コード判定対象型,
                                ByVal 対象コード As String,
                                ByVal 比較コード As String) As 等式判定結果型

        Dim result As Boolean = False

        Select Case checkTarget
            Case コード判定対象型.取引先コード
                result = Val(対象コード) = Val(比較コード)

            Case コード判定対象型.担当者コード
                result = Val(対象コード) = Val(比較コード)

            Case コード判定対象型.部門コード
                result = Val(対象コード) = Val(比較コード)

            Case コード判定対象型.倉庫コード
                result = Val(対象コード) = Val(比較コード)

            Case コード判定対象型.商品コード
                result = 対象コード.TrimEnd = 比較コード.TrimEnd

                'A-CUST20201013↓
            Case コード判定対象型.納品先コード
                result = Val(対象コード) = Val(比較コード)
                'A-CUST20201013↑

        End Select

        If result = True Then
            Return 等式判定結果型.等しい
        Else
            Return 等式判定結果型.異なる
        End If

    End Function

    ''' <summary>
    ''' 入力省略項目か判定（明細部用）
    ''' </summary>
    ''' <param name="rowIndex"></param>
    ''' <param name="tabIndex"></param>
    ''' <returns></returns>
    ''' <remarks>False：省略しない／True：省略する</remarks>
    Private Function Is入力省略項目判定(ByVal rowIndex As Integer, ByRef tabIndex As Integer) As Boolean

        Dim colName As String = _detailColTabIndexList(tabIndex)
        Dim colIndex As Integer = -2
        Dim endTabIndex As Integer = _detailColumnInfoList.最終項目TabIndex

        '移動可能セル無し
        If colIndex = -1 Then
            tabIndex = endTabIndex + 1
            Return True
        End If

        '移動先セル指定有り
        If colIndex >= 0 Then
            tabIndex = DetailGridEdit.Columns(colIndex).TabIndex - 1
        End If

        Do
            tabIndex += 1
            If tabIndex > endTabIndex Then
                Exit Do
            End If
            If _detailColTabIndexList.ContainsKey(tabIndex) = False Then
                Continue Do
            End If
            If Isセル状態_DisplayOnly(DetailGridEdit, rowIndex, _detailColTabIndexList(tabIndex)) = True Then
                Continue Do
            End If
            If Isセル状態_ReadOnly(DetailGridEdit, rowIndex, _detailColTabIndexList(tabIndex)) = False AndAlso
               Isセル状態_EditType(DetailGridEdit, rowIndex, _detailColTabIndexList(tabIndex)) <> GridEditType.Nothing Then
                Exit Do
            End If
        Loop
        Return True

    End Function

    ''' <summary>
    ''' セルのDisplayOnly状態を返す
    ''' </summary>
    ''' <param name="gridEdit">グリッド</param>
    ''' <param name="rowindex">行番号</param>
    ''' <param name="colindex">カラムインデックス</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function Isセル状態_DisplayOnly(ByVal gridEdit As OSK.X1.Foundation.SimpleControl.GridEdit,
                                            ByVal rowindex As Integer,
                                            ByVal colindex As Integer) As Boolean

        Dim result_DisplayOnly As Grid.Common.Boolean
        result_DisplayOnly = CType(gridEdit.GetCellProperty(rowindex, colindex, Grid.GridCellProperty.DisplayOnly), Grid.Common.Boolean)

        Return CBool(result_DisplayOnly)

    End Function

    ''' <summary>
    ''' セルのDisplayOnly状態を返す
    ''' </summary>
    ''' <param name="gridEdit">グリッド</param>
    ''' <param name="rowindex">行番号</param>
    ''' <param name="colName">カラム</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function Isセル状態_DisplayOnly(ByVal gridEdit As OSK.X1.Foundation.SimpleControl.GridEdit,
                                            ByVal rowindex As Integer,
                                            ByVal colName As String) As Boolean

        Dim result_DisplayOnly As Grid.Common.Boolean
        result_DisplayOnly = CType(gridEdit.GetCellProperty(rowindex, colName, Grid.GridCellProperty.DisplayOnly), Grid.Common.Boolean)

        Return CBool(result_DisplayOnly)

    End Function

    Private Function Is得意先課税対象() As Boolean

        If CStr(_退避情報.得意先項目("CUSME01019")) = "02" Then
            Return False
        End If

        Return True
    End Function

    Private Function Is消費税計算() As 消費税計算区分型

        Select Case CStr(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.消費税コード))
            Case "01"
                Return 消費税計算区分型.請求単位
            Case "02"
                Return 消費税計算区分型.伝票単位
            Case Else
                Return 消費税計算区分型.未設定
        End Select

    End Function

    Private Function Is課税区分(ByVal 課税区分 As String) As 課税区分型

        Select Case 課税区分
            Case "01"
                Return 課税区分型.税抜
            Case "02"
                Return 課税区分型.税込
            Case "03"
                Return 課税区分型.非課税
            Case Else
                Return 課税区分型.未設定
        End Select

    End Function

    Private Function Is得意先端数処理区分() As IMoneyCalculate.端数処理区分

        Select Case Val(_退避情報.得意先項目("CUSME01018"))
            Case 1
                Return IMoneyCalculate.端数処理区分.切捨
            Case 2
                Return IMoneyCalculate.端数処理区分.切上
            Case 3
                Return IMoneyCalculate.端数処理区分.四捨五入
        End Select

    End Function

    'D-CUST20200311↓ '-20200527-001
    'Private Function Is入力可能行区分(ByVal 区分 As Integer) As Boolean

    '    Select Case 区分
    '        Case 取引区分属性型.売上
    '        Case 取引区分属性型.値引
    '        Case 取引区分属性型.メモ
    '        Case Else
    '            Return False
    '    End Select

    '    Return True
    'End Function
    'D-CUST20200311↑ '-20200527-001
    'A-CUST20200311↓ '-20200527-001
    Private Function Is入力可能行区分(ByVal 区分 As Integer, ByVal 区分属性 As Integer) As Boolean

        If 区分属性 = 取引区分属性型.返品 Then
            Return False
        End If

        If 区分属性 = 取引区分属性型.見本 Then
            Return False
        End If

        Return True
    End Function
    'A-CUST20200311↑ '-20200527-001

    'A-CUST20200311↓ '-20200616-001
    Private Function Is計上済(Optional ByVal gyo As Integer = -1) As Boolean

        '登録時は常にFalse
        If shori.Value = 処理区分型.登録 Then Return False

        Select Case gyo
            Case -1     'ヘッダー

                '関連受注存在
                If Val(_退避情報.見積ヘッダー項目("CUSRE11018")) <> 0 Then
                    Return True
                End If

                '関連売上存在
                If Val(_退避情報.見積ヘッダー項目("CUSRE11019")) <> 0 Then
                    Return True
                End If

            Case Else   '明細
                If _maxRowCount > gyo Then
                    '関連受注存在
                    If Val(_退避情報.明細表示部項目(gyo, 退避情報型.明細項目型.行ＤＢ値)) <> 0 Then
                        If Val(_退避情報.見積明細項目(CInt(Val(_退避情報.明細表示部項目(gyo, 退避情報型.明細項目型.行ＤＢ値))) - 1, "CUSRE12025")) <> 0 Then
                            Return True
                        End If
                    End If
                    '関連売上存在
                    If Val(_退避情報.明細表示部項目(gyo, 退避情報型.明細項目型.行ＤＢ値)) <> 0 Then
                        If Val(_退避情報.見積明細項目(CInt(Val(_退避情報.明細表示部項目(gyo, 退避情報型.明細項目型.行ＤＢ値))) - 1, "CUSRE12026")) <> 0 Then
                            Return True
                        End If
                    End If
                End If
        End Select

        Return False

    End Function
    'A-CUST20200311↑ '-20200616-001

#End Region

#Region "内部処理"

    Private Sub Change明細課税区分()

        'If CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.処理モード)) = 処理区分型.修正 Then            'D-CUST20200311 '-20200609-002
        OSK.X1.Foundation.UserInterface.OSKMessageBox.Show(Me, メッセージ定数型.MASSAGE_A01, システム環境情報.プログラム情報.名称, MessageBoxButtons.OK, MessageBoxIcon.Information)
        'End If                                                                                                    'D-CUST20200311 '-20200609-002 

        '区分マスターRead
        Dim param As New ReadParam


        param = New ReadParam
        With param
            .Container(ReadParam.項目名型.種別) = Get区分マスター種別値(区分マスター型.課税区分)
            .Container(ReadParam.項目名型.区分コード) = "03"
        End With

        Dim 区分マスター存在 As Boolean = ReadMaster_区分マスター(param)
        If 区分マスター存在 = False Then
            _退避情報.ClearDataTable課税区分()
        End If

        For I As Integer = 0 To _maxRowCount - 1
            If Is省略判定(コード判定対象型.区分, CStr(_退避情報.明細表示部項目(I, 退避情報型.明細項目型.課税区分))) = 省略判定結果型.入力 Then
                _退避情報.明細表示部項目(I, 退避情報型.明細項目型.課税区分) = "03"
                _退避情報.明細表示部項目(I, 退避情報型.明細項目型.課税区分名) = _退避情報.課税区分項目("CUSCE03003")
                _退避情報.明細表示部項目(I, 退避情報型.明細項目型.課税区分マスター情報) = _退避情報.課税区分
                DetailGridView.SetData(I, 退避情報型.明細項目型.課税区分.ToString, _退避情報.明細表示部項目(I, 退避情報型.明細項目型.課税区分))
                DetailGridView.SetData(I, 退避情報型.明細項目型.課税区分名.ToString, _退避情報.明細表示部項目(I, 退避情報型.明細項目型.課税区分名))
            End If
        Next

        If Is課税区分(CStr(_退避情報.明細入力部項目(退避情報型.明細項目型.課税区分))) = 課税区分型.税抜 Or
                   Is課税区分(CStr(_退避情報.明細入力部項目(退避情報型.明細項目型.課税区分))) = 課税区分型.税込 Then
            _退避情報.明細入力部項目(退避情報型.明細項目型.課税区分) = "03"
            _退避情報.明細入力部項目(退避情報型.明細項目型.課税区分名) = _退避情報.課税区分項目("CUSCE03003")
            _退避情報.明細入力部項目(退避情報型.明細項目型.課税区分マスター情報) = _退避情報.課税区分
            DetailGridEdit.SetData(0, 退避情報型.明細項目型.課税区分.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.課税区分))
            DetailGridEdit.SetData(0, 退避情報型.明細項目型.課税区分名.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.課税区分名))
        End If

    End Sub

    ''' <summary>
    ''' 指定日付より原単価を算出する
    ''' </summary>
    ''' <param name="datevalue">指定日付</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetGenTanka(datevalue As Integer) As Decimal

        Dim tanka As Decimal = 0

        If CInt(_退避情報.明細入力部項目_商品情報("CUSME03009")) <> 0 And
           CInt(_退避情報.明細入力部項目_商品情報("CUSME03009")) <= datevalue Then
            tanka = CDec(_退避情報.明細入力部項目_商品情報("CUSME03013"))
        Else
            tanka = CDec(_退避情報.明細入力部項目_商品情報("CUSME03007"))
        End If

        Return tanka

    End Function

    ''' <summary>
    ''' 指定日付より単価を算出する
    ''' </summary>
    ''' <param name="datevalue">指定日付</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetTanka(datevalue As Integer, Optional ByVal TankaKeisanHouhou As IUnitPriceReader.単価計算方法型 = IUnitPriceReader.単価計算方法型.標準売上単価) As Decimal      'A-CUST20211001
        'Private Function GetTanka(datevalue As Integer) As Decimal     'D-CUST20211001

        Dim tanka As Decimal = 0

        'D-CUST20211001↓
        'If CInt(_退避情報.明細入力部項目_商品情報("CUSME03009")) <> 0 And
        '   CInt(_退避情報.明細入力部項目_商品情報("CUSME03009")) <= datevalue Then
        '    tanka = CDec(_退避情報.明細入力部項目_商品情報("CUSME03010"))
        'Else
        '    tanka = CDec(_退避情報.明細入力部項目_商品情報("CUSME03004"))
        'End If
        'D-CUST20211001↑
        'A-CUST20211001↓
        Dim TankaKbn As Integer = 0
        Dim Kizyunbi As Integer = datevalue
        Dim TorihikiCode As String = CStr(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.得意先コード))
        Dim ShohinCode As String = CStr(_退避情報.明細入力部項目(退避情報型.明細項目型.商品コード))
        Dim KanrenTankaHyojiKbn As Integer = 0
        Dim KanrenTanka As Decimal = CDec(_退避情報.明細入力部項目(退避情報型.明細項目型.単価))
        Dim Suryo As Decimal = CDec(_退避情報.明細入力部項目(退避情報型.明細項目型.数量))
        Dim param1 As String = ""
        Dim param2 As String = ""
        Dim param3 As String = ""
        Dim param4 As String = ""
        Dim param5 As String = ""
        Dim TankaKakeritu As Decimal
        Dim Tankasyubetu As Decimal
        Dim TanSetKbn As String = ""
        Dim ret1 As String = ""
        Dim ret2 As String = ""
        Dim ret3 As String = ""
        Dim ret4 As String = ""
        Dim ret5 As String = ""
        _単価取得.GetTanka(TankaKbn, Kizyunbi, TorihikiCode, ShohinCode, KanrenTankaHyojiKbn, KanrenTanka, Suryo,
                           param1, param2, param3, param4, param5,
                           tanka, TankaKakeritu, TankaKeisanHouhou, Tankasyubetu, TanSetKbn,
                           ret1, ret2, ret3, ret4, ret5)

        _退避情報.明細入力部項目(退避情報型.明細項目型.単価計算方法) = TankaKeisanHouhou

        If Val(TanSetKbn) <> 0 Then

            If Is得意先課税対象() = False Then
                Return tanka
            End If

            '区分マスターRead
            Dim param As New ReadParam
            With param
                .Container(ReadParam.項目名型.種別) = Get区分マスター種別値(区分マスター型.課税区分)
                .Container(ReadParam.項目名型.区分コード) = TanSetKbn
            End With
            If ReadMaster_区分マスター(param) = False Then
                Return tanka
            End If

            '-------------
            '  確定処理
            '-------------
            _退避情報.明細入力部項目(退避情報型.明細項目型.課税区分) = TanSetKbn
            _退避情報.明細入力部項目(退避情報型.明細項目型.課税区分名) = _退避情報.課税区分項目("CUSCE03003")
            _退避情報.明細入力部項目(退避情報型.明細項目型.課税区分マスター情報) = _退避情報.課税区分
            DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.課税区分.ToString, TanSetKbn)
            DetailGridEdit.SetData(_fromCell.RowIndex, 退避情報型.明細項目型.課税区分名.ToString, _退避情報.明細入力部項目(退避情報型.明細項目型.課税区分名))
        End If
        'A-CUST20211001↑

        Return tanka

    End Function

    ''' <summary>
    ''' 数量と単価より金額を計算する
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetKingaku(ByVal 数量 As Decimal,
                                ByVal 単価 As Decimal,
                                ByVal 数量小数桁 As Integer,
                                ByVal 単価小数桁 As Integer,
                                ByRef 金額 As Decimal,
                                Optional ByVal メッセージ表示 As Boolean = True) As Boolean

        Dim 端数区分 As IMoneyCalculate.端数処理区分
        'Dim 有効桁数 As Integer = 9                'D-CUST20211110_01
        Dim 有効桁数 As Integer = 10                'A-CUST20211110_01

        端数区分 = Is得意先端数処理区分()

        Dim moneyCalculate As New MoneyCalculate
        Dim result As Boolean = moneyCalculate.GetKingaku(数量,
                                                          単価,
                                                          数量小数桁,
                                                          単価小数桁,
                                                          端数区分,
                                                          有効桁数,
                                                          金額)

        If result = False OrElse System.Math.Abs(金額) > KINGAKU_MAXVALUE Then
            If メッセージ表示 = False Then
                Return False
            End If
            Grid_MessageViewerShow(75)
            Return False
        End If

        Return result

    End Function

    ''' <summary>
    ''' 数量と原単価より原価金額を計算する
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetGenkaKingaku(ByVal 数量 As Decimal,
                                ByVal 単価 As Decimal,
                                ByVal 数量小数桁 As Integer,
                                ByVal 単価小数桁 As Integer,
                                ByRef 金額 As Decimal,
                                Optional ByVal メッセージ表示 As Boolean = True) As Boolean

        Dim 端数区分 As IMoneyCalculate.端数処理区分
        'Dim 有効桁数 As Integer = 9             'D-CUST20211110_01
        Dim 有効桁数 As Integer = 10             'A-CUST20211110_01

        '端数区分 = CType(_myコントロール情報.金額端数処理_仕入 - 1, IMoneyCalculate.端数処理区分)      'D-CUST20200311 '-20200803
        'A-CUST20200311↓ '-20200803
        Select Case _myコントロール情報.金額端数処理_仕入
            Case 1 '切り捨て
                端数区分 = IMoneyCalculate.端数処理区分.切捨
                 'D-CUST20240514↓
            'Case 2 '四捨五入
            '    端数区分 = IMoneyCalculate.端数処理区分.四捨五入
            'Case 3 '切り上げ
            '    端数区分 = IMoneyCalculate.端数処理区分.切上
                 'D-CUST20240514↑
                'A-CUST20240514↓
            Case 2
                端数区分 = IMoneyCalculate.端数処理区分.切上
            Case 3
                端数区分 = IMoneyCalculate.端数処理区分.四捨五入
                'A-CUST20240514↑
        End Select
        'A-CUST20200311↑ '-20200803

        Dim moneyCalculate As New MoneyCalculate
        Dim result As Boolean = moneyCalculate.GetKingaku(数量,
                                                          単価,
                                                          数量小数桁,
                                                          単価小数桁,
                                                          端数区分,
                                                          有効桁数,
                                                          金額)

        If result = False OrElse System.Math.Abs(金額) > KINGAKU_MAXVALUE Then
            If メッセージ表示 = False Then
                Return False
            End If
            Grid_MessageViewerShow(75)
            Return False
        End If

        Return result

    End Function

    Private Sub GetBunkaiKingaku(ByVal 課税区分 As String, ByVal 金額 As Decimal, ByVal 税率 As Decimal,
                                 ByVal 端数区分 As IMoneyCalculate.端数処理区分, ByVal 端数単位 As Integer,
                                 ByRef 消費税額 As Decimal, ByRef 税抜金額 As Decimal)

        Dim moneyCalculate As New MoneyCalculate

        Select Case Is課税区分(課税区分)
            Case 課税区分型.税抜
                moneyCalculate.GetZeigaku(
                                        金額,
                                        税率,
                                        端数区分,
                                        端数単位,
                                        消費税額)
            Case 課税区分型.税込
                moneyCalculate.GetBunkai(
                                        金額,
                                        税率,
                                        端数区分,
                                        端数単位,
                                        消費税額,
                                        税抜金額
                                        )

        End Select

    End Sub

    ''' <summary>
    ''' 粗利額と税抜金額より粗利率を計算する
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function GetArariRitu(ByVal 粗利額 As Decimal,
                                  ByVal 税抜金額 As Decimal) As Decimal

        Dim 粗利率 As Decimal = 0

        If 税抜金額 = 0 Then
            粗利率 = 0
        Else
            粗利率 = Fix(((粗利額 * 1000D) / 税抜金額)) / 10
        End If

        Return 粗利率

    End Function

    Private Function Get区分マスター種別値(ByVal 区分 As 区分マスター型) As String

        Return String.Format("{0:D4}", CInt(区分))

    End Function

    Private Sub SetRowNumber()
        If Val(_退避情報.明細入力部項目(退避情報型.明細項目型.行)) <= 0 And
           _maxRowCount + 1 <= _limitMaxRow Then
            DetailGridEdit.SetData(0, 退避情報型.明細項目型.行, _maxRowCount + 1)
            _退避情報.明細入力部項目(退避情報型.明細項目型.行) = _maxRowCount + 1
            _現在入力行 = _maxRowCount
        End If
    End Sub

#End Region

#Region "印刷関連"

    ''' <summary>
    ''' 印字処理
    ''' </summary>
    ''' <param name="処理連番"></param>
    ''' <remarks></remarks>
    Private Sub Print見積書(ByVal 処理連番 As Long)

        Me.MessageViewer.Show(18)

        Dim printCommon As IPrintCommon = New PrintCommon
        Dim param As IDictionary = New Hashtable

        '見積書データ格納
        SetPrintData(処理連番)

        param.Add("コンピュータ名", Me.システム環境情報.コンピュータ情報.名前)
        param.Add("ユーザーID", Me.システム環境情報.ログオンユーザー情報.ID)
        param.Add("略称", Me.システム環境情報.ログオンユーザー情報.略称)
        param.Add("数量小数以下桁数", _myコントロール情報.小数桁_数量)
        param.Add("単価小数以下桁数", _myコントロール情報.小数桁_売上単価)
        param.Add("EMFファイル名", _myコントロール情報.見積伝票)
        printCommon.PrintingController = _退避情報.PrintingController
        printCommon.Initialize(Me)
        printCommon.PrintSync(Me, param, _退避情報.見積書情報)

        printCommon.PrintingController = Nothing

        StatusBar.StatusLabelControl.Text = ""

    End Sub

    ''' <summary>
    ''' データ格納
    ''' </summary>
    ''' <param name="処理連番"></param>
    ''' <remarks></remarks>
    Private Sub SetPrintData(ByVal 処理連番 As Long)

        _退避情報.見積書情報.Clear()

        _退避情報.得意先 = CType(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.得意先マスター情報), DataTable).Copy
        _退避情報.担当者 = CType(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.担当者マスター情報), DataTable).Copy

        '------------------------------
        '   印字内容編集
        '------------------------------
        Dim row As Integer = -1
        Dim indexMax As Integer = 0
        If _maxRowCount = 0 Then
            indexMax = 1
        Else
            indexMax = _maxRowCount - 1
        End If

        For index As Integer = 0 To indexMax

            _退避情報.CreateAddRow(_退避情報.見積書情報)

            row += 1
            With _退避情報
                '------------------------------
                '   見積ヘッダー情報
                '------------------------------
                .見積書情報項目(row, "HMIT001") = 処理連番                                                                  '見積№
                .見積書情報項目(row, "HMIT002") = CInt(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.伝票日付))        '見積日付
                If CStr(_退避情報.得意先項目("CUSME01003")).Trim = "" Then
                    .見積書情報項目(row, "HMIT003") = ""                                                                    '得意先名１
                    .見積書情報項目(row, "HMIT004") = CStr(_退避情報.得意先項目("CUSME01002"))                              '得意先名２ 
                Else
                    .見積書情報項目(row, "HMIT003") = CStr(_退避情報.得意先項目("CUSME01002"))                              '得意先名１ 
                    .見積書情報項目(row, "HMIT004") = CStr(_退避情報.得意先項目("CUSME01003"))                              '得意先名２ 
                End If
                .見積書情報項目(row, "HMIT005") = CStr(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.要件))            '要件
                .見積書情報項目(row, "HMIT006") = CStr(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.納期))            '納入期限
                .見積書情報項目(row, "HMIT007") = CStr(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.支払方法))        '支払方法
                .見積書情報項目(row, "HMIT008") = CStr(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.有効期限))  　    '有効期限
                .見積書情報項目(row, "HMIT009") = CStr(_退避情報.担当者項目("CUSME04003"))                                  '担当者
                .見積書情報項目(row, "HMIT010") = CDec(_退避情報.フッター部項目(退避情報型.フッター項目型.対象金額))        '伝票課税対象額
                .見積書情報項目(row, "HMIT011") = CDec(_退避情報.フッター部項目(退避情報型.フッター項目型.消費税額))        '伝票消費税額
                .見積書情報項目(row, "HMIT012") = CDec(_退避情報.フッター部項目(退避情報型.フッター項目型.更新用_非課税額)) '伝票非課税額
                'A-CUST20201013↓
                .見積書情報項目(row, "HMIT013") = CStr(_退避情報.納品先項目("CUSME37003"))                                  '納品先
                'A-CUST20201013↑

                '------------------------------
                '  見積明細情報
                '------------------------------
                _退避情報.商品 = CType(_退避情報.明細表示部項目(index, 退避情報型.明細項目型.商品マスター情報), DataTable).Copy

                '.見積書情報項目(row, "MMIT001") = CStr(_退避情報.明細表示部項目(index, 退避情報型.明細項目型.行))           '行№　　　'A-CUST20200311 '-20200527-003
                'A-CUST20200311↓ '-20200527-003
                If CInt(_退避情報.明細表示部項目(index, 退避情報型.明細項目型.区分)) = 行区分型.メモ Then
                    .見積書情報項目(row, "MMIT001") = 0                                                                         '行№
                Else
                    .見積書情報項目(row, "MMIT001") = CInt(_退避情報.明細表示部項目(index, 退避情報型.明細項目型.行))           '行№
                End If
                'A-CUST20200311↑ '-20200527-003
                .見積書情報項目(row, "MMIT002") = CStr(_退避情報.明細表示部項目(index, 退避情報型.明細項目型.商品コード))   '商品コード
                .見積書情報項目(row, "MMIT003") = CStr(_退避情報.明細表示部項目(index, 退避情報型.明細項目型.商品名))       '商品名

                If Val(CStr(_退避情報.明細部項目_商品情報(index, "CUSME03015"))) >= 900 AndAlso
                   Val(CStr(_退避情報.明細部項目_商品情報(index, "CUSME03015"))) <= 999 Then
                    .見積書情報項目(row, "MMIT004") = "*"                                                                   '税分類マーク
                Else
                    .見積書情報項目(row, "MMIT004") = ""                                                                    '税分類マーク
                End If
                .見積書情報項目(row, "MMIT005") = CDec(_退避情報.明細表示部項目(index, 退避情報型.明細項目型.数量))         '数量
                .見積書情報項目(row, "MMIT006") = CStr(_退避情報.明細表示部項目(index, 退避情報型.明細項目型.単位))         '単位
                .見積書情報項目(row, "MMIT007") = CDec(_退避情報.明細表示部項目(index, 退避情報型.明細項目型.単価))         '単価
                .見積書情報項目(row, "MMIT008") = CDec(_退避情報.明細表示部項目(index, 退避情報型.明細項目型.金額))         '金額
                .見積書情報項目(row, "MMIT009") = CStr(_退避情報.明細表示部項目(index, 退避情報型.明細項目型.行摘要))       '行摘要
                .見積書情報項目(row, "MMIT010") = CInt(_退避情報.明細表示部項目(index, 退避情報型.明細項目型.小計))         '小計チェックフラグ
                .見積書情報項目(row, "MMIT011") = CInt(_退避情報.明細表示部項目(index, 退避情報型.明細項目型.改頁))         '改頁チェックフラグ

            End With
        Next

    End Sub

#Region "伝票発行済管理"

    Private Sub DoUpdateSlipIssue(ByVal 処理連番 As Long, ByVal 発行済管理更新日 As Long)

        Dim slipIssueUpdate As ISlipIssueUpdate = CommonFactory.CreateInstance(Of ISlipIssueUpdate)(Me, GetType(SlipIssueUpdate))
        slipIssueUpdate.Initialize(Me)

        Dim insertData As DataTable = slipIssueUpdate.CreateInsertDataTable '引き渡し用DataTable生成
        insertData.Rows.Add(insertData.NewRow)
        With insertData.Rows(insertData.Rows.Count - 1)
            .Item(ISlipIssueUpdater.更新項目型.プログラム区分.ToString) = 30 '｛見積書｝
            .Item(ISlipIssueUpdater.更新項目型.伝票区分.ToString) = 1 '｛見積｝
            .Item(ISlipIssueUpdater.更新項目型.伝票No.ToString) = 処理連番
            .Item(ISlipIssueUpdater.更新項目型.発行済管理更新日時.ToString) = 発行済管理更新日
            '.Item(ISlipIssueUpdater.更新項目型.プログラムID.ToString) = Me.システム環境情報.プログラム情報.ID     'D-CUST20220425
            'A-CUST20220425↓
            .Item(ISlipIssueUpdater.更新項目型.プログラムID.ToString) = Me.システム環境情報.プログラム情報.オリジナルID
            .Item(ISlipIssueUpdater.更新項目型.プログラムID枝番.ToString) = Me.システム環境情報.プログラム情報.枝番
            'A-CUST20220425↑
        End With

        slipIssueUpdate.HakkouInsert(Me, insertData)

    End Sub


#End Region


#End Region
    'A-CUST20251104↓
#Region "FieldBuilder関連処理"

    Private Sub ExpandItemButton_click(sender As Object, e As EventArgs) Handles ExpandItemButton.Click
        Dim paramInfo As IDictionary = New Hashtable

        Dim dtサブ画面データ As DataTable = CType(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.FieldBuilder), DataTable).Copy

        LaunchHeaderExpandSubForm(dtサブ画面データ, 処理モード.入力, paramInfo)
    End Sub

    Private Sub InitHeaderExpandCheckDefinition()
        Dim paramInfo As IDictionary = New Hashtable
        Dim dtサブ画面データ As New DataTable

        LaunchHeaderExpandSubForm(dtサブ画面データ, 処理モード.初回起動, paramInfo)

    End Sub


    Private Function PrecheckHeaderExpand() As Boolean
        ' 定義がなければ何もしない
        If _expandHeaderCheck Is Nothing OrElse _expandHeaderCheck.Count = 0 Then Return True

        Dim header As DataTable = _退避情報.FieldBuilderヘッダー
        If header Is Nothing OrElse header.Rows.Count <= 0 Then Return True

        Dim row As DataRow = header.Rows(0)

        Dim launched As Boolean = False

        ' 各DB列事にチェック
        For k As Integer = 1 To EXPANDITEMCOUNT
            Dim kVar As String = "K" & k.ToString("D3")
            ' 定義に存在しないKはスキップ
            If Not _expandHeaderCheck.ContainsKey(kVar) Then Continue For

            Dim inputCheck As Integer = _expandHeaderCheck(kVar) ' 0/1/2
            Dim label As String = ""
            If _expandHeaderLabel IsNot Nothing AndAlso _expandHeaderLabel.ContainsKey(kVar) Then
                label = _expandHeaderLabel(kVar)
            Else
                label = kVar
            End If
            ' 実列（CUSRE11Kxxx）
            Dim colCus As String = "CUSRE11K" & k.ToString("D3")
            If Not header.Columns.Contains(colCus) Then Continue For
            Dim isEmpty As Boolean = False
            Select Case _expandHeaderZokusei(kVar)
                Case 属性.全角文字, 属性.半角文字, 属性.参照定義コード,
                     属性.画像, 属性.実行ファイル, 属性.ファイル,
                     属性.フォルダ, 属性.URL, 属性.メールアドレス
                    Dim itemVal As String = CType(row(colCus), String)
                    If itemVal = String.Empty Then
                        isEmpty = True
                    End If
                Case 属性.数値
                    Dim itemVal As Decimal = 0D
                    Dim rowval As String = CType(row(colCus), String)
                    If String.IsNullOrEmpty(rowval) Then
                        'itemValはそのまま
                    Else
                        If Not Decimal.TryParse(rowval, itemVal) Then
                        End If
                    End If
                    If itemVal = 0D Then
                        isEmpty = True
                    End If
                Case 属性.日付, 属性.日付_年度, 属性.日付_年月
                    Dim itemVal As Integer = 0
                    Dim rowval As String = CType(row(colCus), String)
                    If String.IsNullOrEmpty(rowval) Then
                        'itemValはそのまま
                    Else
                        If Not Integer.TryParse(rowval, itemVal) Then
                        End If
                    End If
                    If itemVal = 0 Then
                        isEmpty = True
                    End If
            End Select
            If isEmpty = False Then
                launched = True
                Continue For
            End If


            Select Case inputCheck
                Case 2 ' 必須
                    OSK.X1.Foundation.UserInterface.OSKMessageBox.Show(Me,
                        label & " は必須です。FieldBuilderの入力画面を開きます。",
                        システム環境情報.プログラム情報.名称,
                        MessageBoxButtons.OK, MessageBoxIcon.Information)

                    If Not LaunchHeaderExpandSubFormWithFocus(kVar) Then
                        'キャンセルされた場合は実行ボタンへフォーカスが戻る
                        launched = False
                    Else
                        launched = True
                        Exit For
                    End If
                    Exit For

                Case 1 ' 警告
                    Const MESSAGE_01 As String = "が入力されていません。処理を続行しますか？"
                    Dim res As DialogResult = OSK.X1.Foundation.UserInterface.OSKMessageBox.Show(Me,
                        label & MESSAGE_01,
                        システム環境情報.プログラム情報.名称,
                        MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                        MessageBoxDefaultButton.Button2)

                    If res <> DialogResult.Yes Then
                        If Not LaunchHeaderExpandSubFormWithFocus(kVar) Then
                            'キャンセルされた場合はほかの項目についても走査しておく
                            launched = False
                        Else
                            launched = True
                            Exit For
                        End If
                    Else
                    End If

                Case Else ' 0=省略可
                    launched = True
            End Select
        Next

        Return launched
    End Function


    Private Function LaunchHeaderExpandSubFormWithFocus(ByVal focusKVar As String) As Boolean
        Dim paramInfo As IDictionary = New Hashtable

        Dim dtサブ画面データ As DataTable = CType(_退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.FieldBuilder), DataTable).Copy

        With paramInfo
            .Add("初期フォーカス項目", focusKVar)
        End With

        LaunchHeaderExpandSubForm(dtサブ画面データ, 処理モード.入力, paramInfo)

        'データの更新は共通起動処理側で。ここは判定のみ。
        If paramInfo.Contains("確定区分") = True AndAlso CBool(paramInfo.Item("確定区分")) = True Then
            If paramInfo.Item("サブ画面データ") IsNot Nothing Then
            End If
        Else
            Return False
        End If
        Return True
    End Function

    '　FieldBuilderヘッダーの共通起動処理
    Private Sub LaunchHeaderExpandSubForm(ByVal dtサブデータ As DataTable, mode As Integer, ByRef paramInfo As IDictionary)
        Dim ExpandItemEntry As OSK.X1.OTS.LIB.FieldBuilder.UI.ISubForm = New OSK.X1.OTS.LIB.FieldBuilder.UI.SubForm

        ' 列名マッピングの生成
        Dim dic列名マップ As New Dictionary(Of String, String)
        For i As Integer = 1 To EXPANDITEMCOUNT
            dic列名マップ.Add("K" & i.ToString("D3"), "CUSRE11K" & i.ToString("D3"))
        Next
        With paramInfo
            .Add("XMLファイル名", "EO汎用_FieldBuilder_売上ヘッダー.xml")
            .Add("処理モード", mode)
            .Add("サブ画面データ", dtサブデータ)
            .Add("列名マップ", dic列名マップ)
        End With

        ExpandItemEntry.Initialize(Me)
        ExpandItemEntry.SetUpForm(paramInfo)

        Select Case mode
            Case 処理モード.初回起動
                _expandHeaderCheck = CType(paramInfo("FieldBuilder_入力チェック定義"), Dictionary(Of String, Integer))
                _expandHeaderLabel = CType(paramInfo("FieldBuilder_ラベル定義"), Dictionary(Of String, String))
                _expandHeaderZokusei = CType(paramInfo("FieldBuilder_属性"), Dictionary(Of String, Integer))
            Case 処理モード.入力
                If paramInfo.Contains("確定区分") = True AndAlso CBool(paramInfo.Item("確定区分")) = True Then
                    If paramInfo.Item("サブ画面データ") IsNot Nothing Then
                        Dim getData As DataTable = CType(paramInfo.Item("サブ画面データ"), DataTable)
                        _退避情報.FieldBuilderヘッダー = getData
                        _退避情報.ヘッダー部項目(退避情報型.ヘッダー項目型.FieldBuilder) = _退避情報.FieldBuilderヘッダー

                    End If
                End If
        End Select

    End Sub


    '------------明細用------------
    Private Sub InitMeisaiExpandCheckDefinition()
        Dim paramInfo As IDictionary = New Hashtable
        Dim dtサブ画面データ As New DataTable

        LaunchMeisaiExpandSubForm(dtサブ画面データ, 処理モード.初回起動, paramInfo)
    End Sub

    Private Function PrecheckMeisaiExpand() As Boolean
        ' 定義がなければ何もしない
        If _expandMeisaiCheck Is Nothing OrElse _expandMeisaiCheck.Count = 0 Then Return True

        Dim meisai As DataTable = CType(_退避情報.明細入力部項目(退避情報型.明細項目型.FieldBuilder), DataTable).Copy
        If meisai Is Nothing OrElse meisai.Rows.Count <= 0 Then Return True

        Dim row As DataRow = meisai.Rows(0)

        Dim launched As Boolean = False

        ' 各DB列事にチェック
        For k As Integer = 1 To EXPANDITEMCOUNT
            Dim kVar As String = "K" & k.ToString("D3")
            ' 定義に存在しないKはスキップ
            If Not _expandMeisaiCheck.ContainsKey(kVar) Then Continue For

            Dim inputCheck As Integer = _expandMeisaiCheck(kVar) ' 0/1/2
            Dim label As String = ""
            If _expandMeisaiLabel IsNot Nothing AndAlso _expandMeisaiLabel.ContainsKey(kVar) Then
                label = _expandMeisaiLabel(kVar)
            Else
                label = kVar
            End If
            ' 実列（CUSRE12Kxxx）
            Dim colCus As String = "CUSRE12K" & k.ToString("D3")
            If Not meisai.Columns.Contains(colCus) Then Continue For
            Dim isEmpty As Boolean = False
            Select Case _expandMeisaiZokusei(kVar)
                Case 属性.全角文字, 属性.半角文字, 属性.参照定義コード,
                     属性.画像, 属性.実行ファイル, 属性.ファイル,
                     属性.フォルダ, 属性.URL, 属性.メールアドレス
                    Dim itemVal As String = CType(row(colCus), String)
                    If itemVal = String.Empty Then
                        isEmpty = True
                    End If
                Case 属性.数値
                    Dim itemVal As Decimal = 0D
                    Dim rowval As String = CType(row(colCus), String)
                    If String.IsNullOrEmpty(rowval) Then
                        'itemValはそのまま
                    Else
                        If Not Decimal.TryParse(rowval, itemVal) Then
                        End If
                    End If
                    If itemVal = 0D Then
                        isEmpty = True
                    End If
                Case 属性.日付, 属性.日付_年度, 属性.日付_年月
                    Dim itemVal As Integer = 0
                    Dim rowval As String = CType(row(colCus), String)
                    If String.IsNullOrEmpty(rowval) Then
                        'itemValはそのまま
                    Else
                        If Not Integer.TryParse(rowval, itemVal) Then
                        End If
                    End If
                    If itemVal = 0 Then
                        isEmpty = True
                    End If
            End Select
            If isEmpty = False Then
                launched = True
                Continue For
            End If


            Select Case inputCheck
                Case 2 ' 必須
                    OSK.X1.Foundation.UserInterface.OSKMessageBox.Show(Me,
                        label & " は必須です。FieldBuilderの入力画面を開きます。",
                        システム環境情報.プログラム情報.名称,
                        MessageBoxButtons.OK, MessageBoxIcon.Information)

                    If Not LaunchMeisaiExpandSubFormWithFocus(kVar) Then
                        'キャンセルされた場合はほかの項目についても走査しておく
                        launched = False
                    Else
                        launched = True
                        Exit For
                    End If


                Case 1 ' 警告
                    Const MESSAGE_01 As String = "が入力されていません。処理を続行しますか？"
                    Dim res As DialogResult = OSK.X1.Foundation.UserInterface.OSKMessageBox.Show(Me,
                        label & MESSAGE_01,
                        システム環境情報.プログラム情報.名称,
                        MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                        MessageBoxDefaultButton.Button2)

                    If res <> DialogResult.Yes Then
                        If Not LaunchMeisaiExpandSubFormWithFocus(kVar) Then
                            'キャンセルされた場合はほかの項目についても走査しておく
                            launched = False
                        Else
                            launched = True
                            Exit For
                        End If
                    Else
                        launched = True
                    End If

                Case Else ' 0=省略可

            End Select
        Next

        Return launched
    End Function

    Private Function LaunchMeisaiExpandSubFormWithFocus(ByVal focusKVar As String) As Boolean
        Dim paramInfo As IDictionary = New Hashtable

        Dim dtサブ画面データ As DataTable = CType(_退避情報.明細入力部項目(退避情報型.明細項目型.FieldBuilder), DataTable).Copy

        With paramInfo
            .Add("初期フォーカス項目", focusKVar)
        End With

        LaunchMeisaiExpandSubForm(dtサブ画面データ, 処理モード.入力, paramInfo)

        '判定のために残す。データ更新は共通起動処理側。
        If paramInfo.Contains("確定区分") = True AndAlso CBool(paramInfo.Item("確定区分")) = True Then
            If paramInfo.Item("サブ画面データ") IsNot Nothing Then
            End If
        Else
            Return False
        End If
        Return True
    End Function

    '　FieldBuilder明細の共通起動処理
    Private Sub LaunchMeisaiExpandSubForm(ByVal dtサブデータ As DataTable, mode As Integer, ByRef paramInfo As IDictionary)
        Dim ExpandItemEntry As OSK.X1.OTS.LIB.FieldBuilder.UI.ISubForm = New OSK.X1.OTS.LIB.FieldBuilder.UI.SubForm

        ' 列名マッピングの生成
        Dim dic列名マップ As New Dictionary(Of String, String)
        For i As Integer = 1 To EXPANDITEMCOUNT
            dic列名マップ.Add("K" & i.ToString("D3"), "CUSRE12K" & i.ToString("D3"))
        Next
        With paramInfo
            .Add("XMLファイル名", "EO汎用_FieldBuilder_売上明細.xml")
            .Add("処理モード", mode)
            .Add("サブ画面データ", dtサブデータ)
            .Add("列名マップ", dic列名マップ)
        End With

        ExpandItemEntry.Initialize(Me)
        ExpandItemEntry.SetUpForm(paramInfo)

        Select Case mode
            Case 処理モード.初回起動
                ' 結果を戻す
                _expandMeisaiCheck = CType(paramInfo("FieldBuilder_入力チェック定義"), Dictionary(Of String, Integer))
                _expandMeisaiLabel = CType(paramInfo("FieldBuilder_ラベル定義"), Dictionary(Of String, String))
                _expandMeisaiZokusei = CType(paramInfo("FieldBuilder_属性"), Dictionary(Of String, Integer))
            Case 処理モード.入力
                If paramInfo.Contains("確定区分") = True AndAlso CBool(paramInfo.Item("確定区分")) = True Then
                    If paramInfo.Item("サブ画面データ") IsNot Nothing Then
                        Dim getData As DataTable = CType(paramInfo.Item("サブ画面データ"), DataTable)
                        _退避情報.FieldBuilder明細 = getData
                        _退避情報.明細入力部項目(退避情報型.明細項目型.FieldBuilder) = _退避情報.FieldBuilder明細
                    End If
                End If
        End Select

    End Sub

#End Region
    'A-CUST20251104↑
End Class