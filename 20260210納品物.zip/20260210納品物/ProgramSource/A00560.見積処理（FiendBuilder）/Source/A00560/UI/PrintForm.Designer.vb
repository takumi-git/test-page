﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PrintForm
    Inherits OSK.X1.Foundation.UIDesign.UserInterface.DesignFormBase

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Item1 As OSK.X1.Foundation.Controls.GroupOptionImpl.Item = New OSK.X1.Foundation.Controls.GroupOptionImpl.Item()
        Dim Item2 As OSK.X1.Foundation.Controls.GroupOptionImpl.Item = New OSK.X1.Foundation.Controls.GroupOptionImpl.Item()
        Me.伝票発行 = New OSK.X1.Foundation.SimpleControl.GroupOption()
        Me.キャンセル = New OSK.X1.Foundation.SimpleControl.CommandButton()
        Me.OK = New OSK.X1.Foundation.SimpleControl.CommandButton()
        Me.StatusBar = New OSK.X1.Foundation.SmartControl.StatusBar.StatusBar(Me.components)
        Me.SuspendLayout()
        '
        '伝票発行
        '
        Me.伝票発行.BorderStyle = OSK.X1.Foundation.Controls.GroupOption.BorderStyleType.Normal
        Me.伝票発行.FocusBackColor = System.Drawing.Color.Empty
        Me.伝票発行.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.伝票発行.ItemCount = 2
        Item1.Enabled = True
        Item1.Text = "なし"
        Item1.Visible = True
        Item2.Enabled = True
        Item2.Text = "本発行"
        Item2.Visible = True
        Me.伝票発行.Items = New OSK.X1.Foundation.Controls.GroupOptionImpl.Item() {Item1, Item2}
        Me.伝票発行.Location = New System.Drawing.Point(9, 9)
        Me.伝票発行.Name = "伝票発行"
        Me.伝票発行.PrevByShiftTabKey = False
        Me.伝票発行.PrevByUpKey = False
        Me.伝票発行.RemarkString = Nothing
        Me.伝票発行.Size = New System.Drawing.Size(215, 40)
        Me.伝票発行.TabIndex = 0
        Me.伝票発行.Title = "伝票発行"
        '
        'キャンセル
        '
        Me.キャンセル.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.キャンセル.FocusBackColor = System.Drawing.Color.Empty
        Me.キャンセル.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.キャンセル.Image = Nothing
        Me.キャンセル.Location = New System.Drawing.Point(144, 55)
        Me.キャンセル.Name = "キャンセル"
        Me.キャンセル.NextByDownKey = False
        Me.キャンセル.NextByEnterKey = False
        Me.キャンセル.NextByTabKey = False
        Me.キャンセル.PrevByLeftKey = True
        Me.キャンセル.RemarkString = Nothing
        Me.キャンセル.Size = New System.Drawing.Size(80, 24)
        Me.キャンセル.TabIndex = 6
        Me.キャンセル.Text = "キャンセル"
        Me.キャンセル.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'OK
        '
        Me.OK.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.OK.FocusBackColor = System.Drawing.Color.Empty
        Me.OK.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.OK.Image = Nothing
        Me.OK.Location = New System.Drawing.Point(56, 55)
        Me.OK.Name = "OK"
        Me.OK.NextByDownKey = False
        Me.OK.NextByEnterKey = False
        Me.OK.NextByRightKey = True
        Me.OK.RemarkString = Nothing
        Me.OK.Size = New System.Drawing.Size(80, 24)
        Me.OK.TabIndex = 5
        Me.OK.Text = "OK"
        Me.OK.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'StatusBar
        '
        Me.StatusBar.AutoGuideMessageClearFlag = False
        Me.StatusBar.Location = New System.Drawing.Point(0, 94)
        Me.StatusBar.MarqueeAnimationSpeed = 100
        Me.StatusBar.Name = "StatusBar"
        Me.StatusBar.ProgressStep = 5
        Me.StatusBar.ProgressStyle = System.Windows.Forms.ProgressBarStyle.Blocks
        Me.StatusBar.Size = New System.Drawing.Size(234, 23)
        Me.StatusBar.SizingGrip = False
        Me.StatusBar.StatusContainer = Nothing
        Me.StatusBar.TabIndex = 5
        Me.StatusBar.Tag = "@Exception@"
        Me.StatusBar.Text = "StatusBar1"
        '
        'PrintForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(234, 117)
        Me.Controls.Add(Me.StatusBar)
        Me.Controls.Add(Me.OK)
        Me.Controls.Add(Me.キャンセル)
        Me.Controls.Add(Me.伝票発行)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.KeyPreview = True
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "PrintForm"
        Me.ShowInTaskbar = False
        Me.Text = ""
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents 伝票発行 As OSK.X1.Foundation.SimpleControl.GroupOption
    Friend WithEvents キャンセル As OSK.X1.Foundation.SimpleControl.CommandButton
    Friend WithEvents OK As OSK.X1.Foundation.SimpleControl.CommandButton
    Friend WithEvents StatusBar As OSK.X1.Foundation.SmartControl.StatusBar.StatusBar
End Class
