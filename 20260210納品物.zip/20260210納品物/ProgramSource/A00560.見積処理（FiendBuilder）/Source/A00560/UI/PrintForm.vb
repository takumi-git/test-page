﻿Public Class PrintForm
    Inherits DesignFormBase

#Region "列挙"

    Private Enum 伝票発行型 As Integer
        なし = 0
        本発行
    End Enum

#End Region

#Region "内部変数"

    Private _myコントロール情報 As New Myコントロール情報型
    Private _伝票発行情報 As New 伝票発行情報型

#End Region

#Region "開始処理"

    Friend Function SetUpForm(ByVal 条件 As IDictionary, ByRef 結果 As IDictionary) As DialogResult

        Dim result As System.Windows.Forms.DialogResult = System.Windows.Forms.DialogResult.Cancel

        With _伝票発行情報
            .Initialize()
            .条件 = 条件
            .見積書情報 = CType(.条件(伝票発行情報型.条件型.見積書情報.ToString), DataTable).Clone
            .PrintingController = CType(.条件(伝票発行情報型.条件型.PrintingController.ToString), Printing.UserInterface.Controller)
        End With

        SetFormTitleName()

        StatusBar.SetupStatusBar(SettingInfo)
        MessageViewer.StatusLabelControl = StatusBar.StatusLabelControl

        result = Me.ShowDialog()

        If result = System.Windows.Forms.DialogResult.OK Then
            結果 = _伝票発行情報.結果
        End If

        Return result

    End Function

#End Region

#Region "継承メソッド"

    Public Overrides Sub LoadImpl(ByVal sender As Object, ByVal e As System.EventArgs)
        MyBase.LoadImpl(sender, e)
    End Sub

#End Region

#Region "初期処理"

    ''' <summary>
    ''' フォームタイトル名設定処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetFormTitleName()

        Dim st As New System.Text.StringBuilder

        st.Append("伝票発行")
        Me.Text = st.ToString

    End Sub

#End Region

#Region "イベント"

    Private Sub PrintForm_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown

        '伝票発行
        Select Case CInt(_伝票発行情報.条件(伝票発行情報型.条件型.伝票発行.ToString))
            Case 伝票発行型.なし To 伝票発行型.本発行
                伝票発行.Value = CInt(_伝票発行情報.条件(伝票発行情報型.条件型.伝票発行.ToString)) + 1
            Case Else
                伝票発行.Value = 伝票発行型.本発行
        End Select

        'フォーカスセット
        伝票発行.Focus()

    End Sub

    Private Sub PrintForm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown

        If e.KeyCode = Keys.ShiftKey Then Exit Sub

        Select Case e.KeyCode
            Case Keys.Escape
                Me.Close()
        End Select

    End Sub

    Private Sub OK_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles OK.Click

        '-------------------------
        '   戻り値設定
        '-------------------------
        _伝票発行情報.結果.Item(伝票発行情報型.結果型.伝票発行.ToString) = 伝票発行.Value - 1

        '-------------------------
        '   終了
        '-------------------------
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        伝票発行.Focus()
        Me.Close()

    End Sub

    Private Sub キャンセル_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles キャンセル.Click

        伝票発行.Focus()
        Me.Close()

    End Sub

#End Region

End Class
