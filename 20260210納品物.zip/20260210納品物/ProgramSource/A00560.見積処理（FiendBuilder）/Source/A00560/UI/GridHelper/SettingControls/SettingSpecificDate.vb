﻿''' <summary>
''' 特殊日付設定
''' </summary>
''' <remarks></remarks>
Public Class SettingSpecificDate
#Region "コンストラクタ"
    Sub New(ByVal eraStyle As OSK.X1.Foundation.Controls.InputSpecificDate.EraStyleType,
            ByVal eraList As OSK.X1.Foundation.Controls.InputSpecificDate.EraListType,
            ByVal eraDigit As OSK.X1.Foundation.Controls.InputSpecificDate.EraDigitType,
            ByVal displaySpinButton As Boolean,
            ByVal separator As OSK.X1.Foundation.Controls.InputSpecificDate.SeparatorType,
            ByVal zerofill As Boolean)

        _eraDigit = eraDigit
        _eraList = eraList
        _eraStyle = eraStyle
        _separator = separator
        _displaySpinButton = displaySpinButton
        _zerofill = zerofill




        _separator = separator
    End Sub
#End Region

#Region "プロパティ"

    Private _eraDigit As OSK.X1.Foundation.Controls.InputSpecificDate.EraDigitType
    ''' <summary>
    ''' 西暦桁数
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property EraDigit() As OSK.X1.Foundation.Controls.InputSpecificDate.EraDigitType
        Get
            Return _eraDigit
        End Get
        Set(ByVal value As OSK.X1.Foundation.Controls.InputSpecificDate.EraDigitType)
            _eraDigit = value
        End Set
    End Property

    Private _eraList As OSK.X1.Foundation.Controls.InputSpecificDate.EraListType
    ''' <summary>
    ''' 元号区分指定
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property EraList() As OSK.X1.Foundation.Controls.InputSpecificDate.EraListType
        Get
            Return _eraList
        End Get
        Set(ByVal value As OSK.X1.Foundation.Controls.InputSpecificDate.EraListType)
            _eraList = value
        End Set
    End Property

    Private _eraStyle As OSK.X1.Foundation.Controls.InputSpecificDate.EraStyleType
    ''' <summary>
    ''' 西暦・和暦区分
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property EraStyle() As OSK.X1.Foundation.Controls.InputSpecificDate.EraStyleType
        Get
            Return _eraStyle
        End Get
        Set(ByVal value As OSK.X1.Foundation.Controls.InputSpecificDate.EraStyleType)
            _eraStyle = value
        End Set
    End Property

    Private _displaySpinButton As Boolean
    ''' <summary>
    ''' スピンボタン表示
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property DisplaySpinButton() As Boolean
        Get
            Return _displaySpinButton
        End Get
        Set(ByVal value As Boolean)
            _displaySpinButton = value
        End Set
    End Property

    Private _separator As OSK.X1.Foundation.Controls.InputSpecificDate.SeparatorType
    ''' <summary>
    ''' セパレーター
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property Separator() As OSK.X1.Foundation.Controls.InputSpecificDate.SeparatorType
        Get
            Return _separator
        End Get
        Set(ByVal value As OSK.X1.Foundation.Controls.InputSpecificDate.SeparatorType)
            _separator = value
        End Set
    End Property

    Private _zerofill As Boolean
    ''' <summary>
    ''' ゼロフィル
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property Zerofill() As Boolean
        Get
            Return _zerofill
        End Get
        Set(ByVal value As Boolean)
            _zerofill = value
        End Set
    End Property

#End Region

End Class
