﻿Public Class SettingLabel



End Class
