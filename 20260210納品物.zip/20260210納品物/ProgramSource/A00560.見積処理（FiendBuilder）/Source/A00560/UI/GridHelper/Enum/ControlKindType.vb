﻿''' <summary>
''' コントロールタイプ
''' </summary>
''' <remarks></remarks>
Public Enum ControlKindType As Integer
    チェックボックス
    コンボボックス
    コマンドボタン
    状態
    ラベル
    テキスト
    数値
    コード
    日付
    時間
    設定なし
    特殊日付
End Enum
