﻿Public Class ColumnInfoListBase
    Inherits Base

#Region "インターフェイスメソッド"

    ''' <summary>
    ''' グリッドで使用する項目情報一覧を取得する
    ''' </summary>
    ''' <returns>グリッドで使用する項目情報一覧</returns>
    ''' <remarks></remarks>
    Public Function GetItemInfoList() As IColumnInfo()
        Return _list
    End Function

    ''' <summary>
    ''' グリッドで使用する項目情報を取得する
    ''' </summary>
    ''' <returns>グリッドで使用する項目情報</returns>
    ''' <remarks></remarks>
    Public Function GetItemInfo(ByVal name As String) As IColumnInfo
        Return SearchItemInfo(name)
    End Function
#End Region

#Region "コンストラクタ"

    Private _list() As IColumnInfo

    Public Sub New(ByVal initInfo As IDictionary)
        _initInfo = initInfo
        ReDim _list(-1)
    End Sub
    Public Sub New(ByVal initInfo As IDictionary, ByVal settingInfo As IDictionary)
        _initInfo = initInfo
        Initialize(settingInfo)
        ReDim _list(-1)
    End Sub

    Public Sub New(ByVal initInfo As IDictionary, ByVal columnCount As Integer)
        _initInfo = initInfo
        ReDim _list(columnCount - 1)
    End Sub

    Public Sub New(ByVal initInfo As IDictionary, ByVal settingInfo As IDictionary, ByVal columnCount As Integer)
        _initInfo = initInfo
        Initialize(settingInfo)
        ReDim _list(columnCount - 1)
    End Sub

#End Region

#Region "継承させるプロパティ"

    Private _initInfo As IDictionary
    ''' <summary>
    ''' InitInfo()
    ''' 個別設定情報
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Protected ReadOnly Property InitInfo() As System.Collections.IDictionary
        Get
            Return _initInfo
        End Get
    End Property

#End Region

#Region "継承させるメソッド"

    ''' <summary>
    ''' Indexを指定して、項目情報をセットする
    ''' </summary>
    ''' <param name="index">Index</param>
    ''' <param name="info">項目情報</param>
    ''' <remarks></remarks>
    Public Sub SetItemInfo(ByVal index As Integer, ByVal info As IColumnInfo)
        _list(index) = info
    End Sub

    ''' <summary>
    ''' 項目情報を追加する
    ''' </summary>
    ''' <param name="info"></param>
    ''' <remarks></remarks>
    Public Sub AddItemInfo(ByVal info As IColumnInfo)
        Dim newlist(_list.Length) As IColumnInfo

        For i As Integer = 0 To _list.Length - 1
            newlist(i) = _list(i)
        Next

        newlist(_list.Length) = info

        _list = newlist
    End Sub

    ''' <summary>
    ''' 個別情報の取得
    ''' </summary>
    ''' <typeparam name="T"></typeparam>
    ''' <param name="key"></param>
    ''' <param name="defaultValue"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetInitInfo(Of T)(ByVal key As String, ByVal defaultValue As T) As T
        If _initInfo.Contains(key) = True Then
            Return CType(_initInfo(key), T)
        Else
            Return defaultValue
        End If

    End Function

#End Region

#Region "内部メソッド"

    Private Function SearchItemInfo(ByVal name As String) As IColumnInfo
        For i As Integer = 0 To _list.Length - 1
            If _list(i).Name.ToUpper = name.ToUpper Then
                Return _list(i)
                Exit For
            End If
        Next
        Return Nothing
    End Function

#End Region

End Class
