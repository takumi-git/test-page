﻿Public Class ColumnInfo
    Implements IColumnInfo

#Region "コンストラクタ"

    ''' <summary>
    ''' State用コンストラクタ
    ''' </summary>
    ''' <param name="name"></param>
    ''' <param name="columWidth"></param>
    ''' <param name="titleName"></param>
    ''' <param name="groupNo"></param>
    ''' <param name="isHide"></param>
    ''' <param name="defaultValue"></param>
    ''' <param name="itemAlign"></param>
    ''' <param name="titleAlign"></param>
    ''' <param name="tabIndex"></param>
    ''' <param name="individualSetting"></param>
    ''' <remarks></remarks>
    Sub New(ByVal name As String, _
                ByVal columWidth As Integer, _
                ByVal titleName As String, _
                ByVal groupNo As Integer, _
                ByVal isHide As Boolean, _
                ByVal defaultValue As String, _
                ByVal itemAlign As HorzAlign, _
                ByVal titleAlign As HorzAlign, _
                ByVal tabIndex As Integer, _
                ByVal individualSetting As SettingState)
        _name = name
        _controlKind = ControlKind
        _columnWidth = columWidth
        _maxLength = MaxLength
        _titleName = titleName
        _groupNo = groupNo
        _hide = isHide

        _defaultValue = defaultValue
        _itemAlign = itemAlign
        _titleAlign = titleAlign
        _tabIndex = tabIndex

        _controlKind = ControlKindType.状態
        SetSetting(Of SettingState)(individualSetting)
    End Sub

    ''' <summary>
    ''' ラベル用コンストラクタ
    ''' </summary>
    ''' <param name="name"></param>
    ''' <param name="columWidth"></param>
    ''' <param name="titleName"></param>
    ''' <param name="groupNo"></param>
    ''' <param name="isHide"></param>
    ''' <param name="defaultValue"></param>
    ''' <param name="itemAlign"></param>
    ''' <param name="titleAlign"></param>
    ''' <param name="tabIndex"></param>
    ''' <param name="individualSetting"></param>
    ''' <remarks></remarks>
    Sub New(ByVal name As String, _
                ByVal columWidth As Integer, _
                ByVal titleName As String, _
                ByVal groupNo As Integer, _
                ByVal isHide As Boolean, _
                ByVal defaultValue As String, _
                ByVal itemAlign As HorzAlign, _
                ByVal titleAlign As HorzAlign, _
                ByVal tabIndex As Integer, _
                ByVal individualSetting As SettingLabel)
        _name = name
        _controlKind = ControlKind
        _columnWidth = columWidth
        _maxLength = MaxLength
        _titleName = titleName
        _groupNo = groupNo
        _hide = isHide

        _defaultValue = defaultValue
        _itemAlign = itemAlign
        _titleAlign = titleAlign
        _tabIndex = tabIndex

        _controlKind = ControlKindType.ラベル
        SetSetting(Of SettingLabel)(individualSetting)
    End Sub

    ''' <summary>
    ''' テキストボックス用コンストラクタ
    ''' </summary>
    ''' <param name="name"></param>
    ''' <param name="columWidth"></param>
    ''' <param name="titleName"></param>
    ''' <param name="groupNo"></param>
    ''' <param name="isHide"></param>
    ''' <param name="defaultValue"></param>
    ''' <param name="itemAlign"></param>
    ''' <param name="titleAlign"></param>
    ''' <param name="tabIndex"></param>
    ''' <param name="individualSetting"></param>
    ''' <remarks></remarks>
    Sub New(ByVal name As String, _
                ByVal columWidth As Integer, _
                ByVal titleName As String, _
                ByVal groupNo As Integer, _
                ByVal isHide As Boolean, _
                ByVal defaultValue As String, _
                ByVal itemAlign As HorzAlign, _
                ByVal titleAlign As HorzAlign, _
                ByVal tabIndex As Integer, _
                ByVal individualSetting As SettingInputText)
        _name = name
        _controlKind = ControlKind
        _columnWidth = columWidth
        _maxLength = MaxLength
        _titleName = titleName
        _groupNo = groupNo
        _hide = isHide

        _defaultValue = defaultValue
        _itemAlign = itemAlign
        _titleAlign = titleAlign
        _tabIndex = tabIndex

        _controlKind = ControlKindType.テキスト
        SetSetting(Of SettingInputText)(individualSetting)
    End Sub

    ''' <summary>
    ''' 数値コントロール用コンストラクタ
    ''' </summary>
    ''' <param name="name"></param>
    ''' <param name="columWidth"></param>
    ''' <param name="titleName"></param>
    ''' <param name="groupNo"></param>
    ''' <param name="isHide"></param>
    ''' <param name="defaultValue"></param>
    ''' <param name="itemAlign"></param>
    ''' <param name="titleAlign"></param>
    ''' <param name="tabIndex"></param>
    ''' <param name="format"></param>
    ''' <param name="individualSetting"></param>
    ''' <remarks></remarks>
    Sub New(ByVal name As String, _
                ByVal columWidth As Integer, _
                ByVal titleName As String, _
                ByVal groupNo As Integer, _
                ByVal isHide As Boolean, _
                ByVal defaultValue As String, _
                ByVal itemAlign As HorzAlign, _
                ByVal titleAlign As HorzAlign, _
                ByVal tabIndex As Integer, _
                ByVal format As String, _
                ByVal individualSetting As SettingInputNumerical)
        _name = name
        _controlKind = ControlKind
        _columnWidth = columWidth
        _maxLength = MaxLength
        _titleName = titleName
        _groupNo = groupNo
        _hide = isHide

        _defaultValue = defaultValue
        _itemAlign = itemAlign
        _titleAlign = titleAlign
        _tabIndex = tabIndex
        _Format = format

        _controlKind = ControlKindType.数値
        SetSetting(Of SettingInputNumerical)(individualSetting)
    End Sub

    ''' <summary>
    ''' テキストボックス(コード用)コンストラクタ
    ''' </summary>
    ''' <param name="name"></param>
    ''' <param name="columWidth"></param>
    ''' <param name="titleName"></param>
    ''' <param name="groupNo"></param>
    ''' <param name="isHide"></param>
    ''' <param name="defaultValue"></param>
    ''' <param name="itemAlign"></param>
    ''' <param name="titleAlign"></param>
    ''' <param name="tabIndex"></param>
    ''' <param name="individualSetting"></param>
    ''' <remarks></remarks>
    Sub New(ByVal name As String, _
                ByVal columWidth As Integer, _
                ByVal titleName As String, _
                ByVal groupNo As Integer, _
                ByVal isHide As Boolean, _
                ByVal defaultValue As String, _
                ByVal itemAlign As HorzAlign, _
                ByVal titleAlign As HorzAlign, _
                ByVal tabIndex As Integer, _
                ByVal individualSetting As SettingCode)
        _name = name
        _controlKind = ControlKind
        _columnWidth = columWidth
        _maxLength = MaxLength
        _titleName = titleName
        _groupNo = groupNo
        _hide = isHide

        _defaultValue = defaultValue
        _itemAlign = itemAlign
        _titleAlign = titleAlign
        _tabIndex = tabIndex

        _controlKind = ControlKindType.コード
        SetSetting(Of SettingCode)(individualSetting)
    End Sub

    ''' <summary>
    ''' チェックボックスコンストラクタ
    ''' </summary>
    ''' <param name="name"></param>
    ''' <param name="columWidth"></param>
    ''' <param name="titleName"></param>
    ''' <param name="groupNo"></param>
    ''' <param name="isHide"></param>
    ''' <param name="defaultValue"></param>
    ''' <param name="itemAlign"></param>
    ''' <param name="titleAlign"></param>
    ''' <param name="tabIndex"></param>
    ''' <param name="individualSetting"></param>
    ''' <remarks></remarks>
    Sub New(ByVal name As String, _
                ByVal columWidth As Integer, _
                ByVal titleName As String, _
                ByVal groupNo As Integer, _
                ByVal isHide As Boolean, _
                ByVal defaultValue As String, _
                ByVal itemAlign As HorzAlign, _
                ByVal titleAlign As HorzAlign, _
                ByVal tabIndex As Integer, _
                ByVal individualSetting As SettingCheckBox)
        _name = name
        _controlKind = ControlKind
        _columnWidth = columWidth
        _maxLength = MaxLength
        _titleName = titleName
        _groupNo = groupNo
        _hide = isHide

        _defaultValue = defaultValue
        _itemAlign = itemAlign
        _titleAlign = titleAlign
        _tabIndex = tabIndex

        _controlKind = ControlKindType.チェックボックス
        SetSetting(Of SettingCheckBox)(individualSetting)
    End Sub

    ''' <summary>
    ''' コンボボックスコンストラクタ
    ''' </summary>
    ''' <param name="name"></param>
    ''' <param name="columWidth"></param>
    ''' <param name="titleName"></param>
    ''' <param name="groupNo"></param>
    ''' <param name="isHide"></param>
    ''' <param name="defaultValue"></param>
    ''' <param name="itemAlign"></param>
    ''' <param name="titleAlign"></param>
    ''' <param name="tabIndex"></param>
    ''' <param name="individualSetting"></param>
    ''' <remarks></remarks>
    Sub New(ByVal name As String, _
                ByVal columWidth As Integer, _
                ByVal titleName As String, _
                ByVal groupNo As Integer, _
                ByVal isHide As Boolean, _
                ByVal defaultValue As String, _
                ByVal itemAlign As HorzAlign, _
                ByVal titleAlign As HorzAlign, _
                ByVal tabIndex As Integer, _
                ByVal individualSetting As SettingComboBox)
        _name = name
        _controlKind = ControlKind
        _columnWidth = columWidth
        _maxLength = MaxLength
        _titleName = titleName
        _groupNo = groupNo
        _hide = isHide

        _defaultValue = defaultValue
        _itemAlign = itemAlign
        _titleAlign = titleAlign
        _tabIndex = tabIndex

        _controlKind = ControlKindType.コンボボックス
        SetSetting(Of SettingComboBox)(individualSetting)
    End Sub

    ''' <summary>
    ''' コマンドボタンコンストラクタ
    ''' </summary>
    ''' <param name="name"></param>
    ''' <param name="columWidth"></param>
    ''' <param name="titleName"></param>
    ''' <param name="groupNo"></param>
    ''' <param name="isHide"></param>
    ''' <param name="defaultValue"></param>
    ''' <param name="itemAlign"></param>
    ''' <param name="titleAlign"></param>
    ''' <param name="tabIndex"></param>
    ''' <param name="individualSetting"></param>
    ''' <remarks></remarks>
    Sub New(ByVal name As String, _
                ByVal columWidth As Integer, _
                ByVal titleName As String, _
                ByVal groupNo As Integer, _
                ByVal isHide As Boolean, _
                ByVal defaultValue As String, _
                ByVal itemAlign As HorzAlign, _
                ByVal titleAlign As HorzAlign, _
                ByVal tabIndex As Integer, _
                ByVal individualSetting As SettingCommandButton)
        _name = name
        _controlKind = ControlKind
        _columnWidth = columWidth
        _maxLength = MaxLength
        _titleName = titleName
        _groupNo = groupNo
        _hide = isHide

        _defaultValue = defaultValue
        _itemAlign = itemAlign
        _titleAlign = titleAlign
        _tabIndex = tabIndex

        _controlKind = ControlKindType.コマンドボタン
        SetSetting(Of SettingCommandButton)(individualSetting)
    End Sub

    ''' <summary>
    ''' 日付コンストラクタ
    ''' </summary>
    ''' <param name="name"></param>
    ''' <param name="columWidth"></param>
    ''' <param name="titleName"></param>
    ''' <param name="groupNo"></param>
    ''' <param name="isHide"></param>
    ''' <param name="defaultValue"></param>
    ''' <param name="itemAlign"></param>
    ''' <param name="titleAlign"></param>
    ''' <param name="tabIndex"></param>
    ''' <param name="individualSetting"></param>
    ''' <remarks></remarks>
    Sub New(ByVal name As String, _
                ByVal columWidth As Integer, _
                ByVal titleName As String, _
                ByVal groupNo As Integer, _
                ByVal isHide As Boolean, _
                ByVal defaultValue As String, _
                ByVal itemAlign As HorzAlign, _
                ByVal titleAlign As HorzAlign, _
                ByVal tabIndex As Integer, _
                ByVal individualSetting As SettingDate)
        _name = name
        _controlKind = ControlKind
        _columnWidth = columWidth
        _maxLength = MaxLength
        _titleName = titleName
        _groupNo = groupNo
        _hide = isHide

        _defaultValue = defaultValue
        _itemAlign = itemAlign
        _titleAlign = titleAlign
        _tabIndex = tabIndex

        _controlKind = ControlKindType.日付
        SetSetting(Of SettingDate)(individualSetting)
    End Sub

    ''' <summary>
    ''' 特定日付コンストラクタ
    ''' </summary>
    ''' <param name="name"></param>
    ''' <param name="columWidth"></param>
    ''' <param name="titleName"></param>
    ''' <param name="groupNo"></param>
    ''' <param name="isHide"></param>
    ''' <param name="defaultValue"></param>
    ''' <param name="itemAlign"></param>
    ''' <param name="titleAlign"></param>
    ''' <param name="tabIndex"></param>
    ''' <param name="individualSetting"></param>
    ''' <remarks></remarks>
    Sub New(ByVal name As String, _
                ByVal columWidth As Integer, _
                ByVal titleName As String, _
                ByVal groupNo As Integer, _
                ByVal isHide As Boolean, _
                ByVal defaultValue As String, _
                ByVal itemAlign As HorzAlign, _
                ByVal titleAlign As HorzAlign, _
                ByVal tabIndex As Integer, _
                ByVal individualSetting As SettingSpecificDate)
        _name = name
        _controlKind = ControlKind
        _columnWidth = columWidth
        _maxLength = MaxLength
        _titleName = titleName
        _groupNo = groupNo
        _hide = isHide

        _defaultValue = defaultValue
        _itemAlign = itemAlign
        _titleAlign = titleAlign
        _tabIndex = tabIndex

        _controlKind = ControlKindType.特殊日付
        SetSetting(Of SettingSpecificDate)(individualSetting)
    End Sub

    ''' <summary>
    ''' 時刻コンストラクタ
    ''' </summary>
    ''' <param name="name"></param>
    ''' <param name="columWidth"></param>
    ''' <param name="titleName"></param>
    ''' <param name="groupNo"></param>
    ''' <param name="isHide"></param>
    ''' <param name="defaultValue"></param>
    ''' <param name="itemAlign"></param>
    ''' <param name="titleAlign"></param>
    ''' <param name="tabIndex"></param>
    ''' <param name="individualSetting"></param>
    ''' <remarks></remarks>
    Sub New(ByVal name As String, _
                ByVal columWidth As Integer, _
                ByVal titleName As String, _
                ByVal groupNo As Integer, _
                ByVal isHide As Boolean, _
                ByVal defaultValue As String, _
                ByVal itemAlign As HorzAlign, _
                ByVal titleAlign As HorzAlign, _
                ByVal tabIndex As Integer, _
                ByVal individualSetting As SettingTime)
        _name = name
        _controlKind = ControlKind
        _columnWidth = columWidth
        _maxLength = MaxLength
        _titleName = titleName
        _groupNo = groupNo
        _hide = isHide

        _defaultValue = defaultValue
        _itemAlign = itemAlign
        _titleAlign = titleAlign
        _tabIndex = tabIndex

        _controlKind = ControlKindType.時間
        SetSetting(Of SettingTime)(individualSetting)
    End Sub


#End Region

#Region "メソッド"

    Private _setting As Object
    ''' <summary>
    ''' コントロール別設定を渡す
    ''' </summary>
    ''' <typeparam name="T"></typeparam>
    ''' <param name="individualSetting"></param>
    ''' <remarks></remarks>
    Public Sub GetSetting(Of T)(ByRef individualSetting As T) Implements IColumnInfo.GetSetting
        individualSetting = CType(_setting, T)
    End Sub

    ''' <summary>
    ''' コントロール別設定を設定する
    ''' </summary>
    ''' <typeparam name="T"></typeparam>
    ''' <param name="individualSetting"></param>
    ''' <remarks></remarks>
    Public Sub SetSetting(Of T)(ByVal individualSetting As T) Implements IColumnInfo.SetSetting
        _setting = CType(individualSetting, T)
    End Sub

#End Region

#Region "プロパティ"

    Private _name As String
    ''' <summary>
    ''' 項目名称
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property Name() As String Implements IColumnInfo.Name
        Get
            Return _name
        End Get
        Set(ByVal value As String)
            _name = value
        End Set
    End Property

    Private _controlKind As ControlKindType
    ''' <summary>
    ''' コントロールの種類
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public ReadOnly Property ControlKind() As ControlKindType Implements IColumnInfo.ControlKind
        Get
            Return _controlKind
        End Get
    End Property

    Private _columnWidth As Single
    ''' <summary>
    ''' グリッドのカラム幅
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property ColumnWidth() As Single Implements IColumnInfo.ColumnWidth
        Get
            Return _columnWidth
        End Get
        Set(ByVal value As Single)
            _columnWidth = value
        End Set
    End Property

    Private _maxLength As Integer
    ''' <summary>
    ''' 最大入力文字数
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property MaxLength() As Integer Implements IColumnInfo.MaxLength
        Get
            Return _maxLength
        End Get
        Set(ByVal value As Integer)
            _maxLength = value
        End Set
    End Property

    Private _titleName As String
    ''' <summary>
    ''' タイトル名称
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property TitleName() As String Implements IColumnInfo.TitleName
        Get
            Return _titleName
        End Get
        Set(ByVal value As String)
            _titleName = value
        End Set
    End Property

    Private _groupNo As Integer
    ''' <summary>
    ''' グループ番号
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property GroupNo() As Integer Implements IColumnInfo.GroupNo
        Get
            Return _groupNo
        End Get
        Set(ByVal value As Integer)
            _groupNo = value
        End Set
    End Property

    Private _hide As Boolean
    ''' <summary>
    ''' 表示判定
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property Hide() As Boolean Implements IColumnInfo.Hide
        Get
            Return _hide
        End Get
        Set(ByVal value As Boolean)
            _hide = value
        End Set
    End Property

    Private _defaultValue As String
    ''' <summary>
    ''' 初期値
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property DefaultValue() As String Implements IColumnInfo.DefaultValue
        Get
            Return _defaultValue
        End Get
        Set(ByVal value As String)
            _defaultValue = value
        End Set
    End Property

    Private _itemAlign As HorzAlign
    ''' <summary>
    ''' 項目の位置
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property ItemAlign() As HorzAlign Implements IColumnInfo.ItemAlign
        Get
            Return _itemAlign
        End Get
        Set(ByVal value As HorzAlign)
            _itemAlign = value
        End Set
    End Property

    Private _titleAlign As HorzAlign
    ''' <summary>
    ''' タイトルの位置
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property TitleAlign() As HorzAlign Implements IColumnInfo.TitleAlign
        Get
            Return _titleAlign
        End Get
        Set(ByVal value As HorzAlign)
            _titleAlign = value
        End Set
    End Property

    Private _tabIndex As Integer
    ''' <summary>
    ''' タブインデックス
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property TabIndex() As Integer Implements IColumnInfo.TabIndex
        Get
            Return _tabIndex
        End Get
        Set(ByVal value As Integer)
            _tabIndex = value
        End Set
    End Property

    Private _Format As String
    ''' <summary>
    ''' フォーマット
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property Format() As String Implements IColumnInfo.Format
        Get
            Return _Format
        End Get
        Set(ByVal value As String)
            _Format = value
        End Set
    End Property

#End Region

End Class
