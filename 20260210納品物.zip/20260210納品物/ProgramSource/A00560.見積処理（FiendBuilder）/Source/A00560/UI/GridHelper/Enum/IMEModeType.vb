﻿Public Enum IMEモード型 As Integer
    オン
    オフ
    カナ
End Enum
