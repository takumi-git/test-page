﻿Public Class SettingInputNumerical

#Region "コンストラクタ"

    Sub New(ByVal commaDisplay As Boolean, ByVal integerDigits As Integer, ByVal decimalDigits As Integer)
        _commaDisplay = commaDisplay
        _decimalDigits = decimalDigits
        _integerDigits = integerDigits
        _acceptMinusKey = True
        _permitNull = False
        _dispSpinButton = False
    End Sub

    Sub New(ByVal commaDisplay As Boolean, ByVal integerDigits As Integer, ByVal decimalDigits As Integer, ByVal acceptMinusKey As Boolean)
        _commaDisplay = commaDisplay
        _decimalDigits = decimalDigits
        _integerDigits = integerDigits
        _acceptMinusKey = acceptMinusKey
        _permitNull = False
        _dispSpinButton = False
    End Sub

    Sub New(ByVal commaDisplay As Boolean, ByVal integerDigits As Integer, ByVal decimalDigits As Integer, ByVal acceptMinusKey As Boolean, ByVal permitNull As Boolean, ByVal dispSpinButton As Boolean)
        _commaDisplay = commaDisplay
        _decimalDigits = decimalDigits
        _integerDigits = integerDigits
        _acceptMinusKey = acceptMinusKey
        _permitNull = permitNull
        _dispSpinButton = dispSpinButton
    End Sub

    Sub New(ByVal commaDisplay As Boolean, ByVal integerDigits As Integer, ByVal decimalDigits As Integer, ByVal textDisplayMode As OSK.X1.Foundation.Controls.InputNumerical.TextDisplayModeType)
        _commaDisplay = commaDisplay
        _decimalDigits = decimalDigits
        _integerDigits = integerDigits
        _acceptMinusKey = True
        _permitNull = False
        _dispSpinButton = False
        _textDisplayMode = textDisplayMode
    End Sub

    Sub New(ByVal commaDisplay As Boolean, ByVal integerDigits As Integer, ByVal decimalDigits As Integer, ByVal acceptMinusKey As Boolean, ByVal textDisplayMode As OSK.X1.Foundation.Controls.InputNumerical.TextDisplayModeType)
        _commaDisplay = commaDisplay
        _decimalDigits = decimalDigits
        _integerDigits = integerDigits
        _acceptMinusKey = acceptMinusKey
        _permitNull = False
        _dispSpinButton = False
        _textDisplayMode = textDisplayMode
    End Sub

#End Region

#Region "プロパティ"

    Private _acceptMinusKey As Boolean
    ''' <summary>
    ''' マイナスキー受付判定
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property AcceptMinusKey() As Boolean
        Get
            Return _acceptMinusKey
        End Get
        Set(ByVal value As Boolean)
            _acceptMinusKey = value
        End Set
    End Property

    Private _commaDisplay As Boolean
    ''' <summary>
    ''' カンマ表示判定
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property CommaDisplay() As Boolean
        Get
            Return _commaDisplay
        End Get
        Set(ByVal value As Boolean)
            _commaDisplay = value
        End Set
    End Property

    Private _decimalDigits As Integer
    ''' <summary>
    ''' 小数部桁数
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property DecimalDigits() As Integer
        Get
            Return _decimalDigits
        End Get
        Set(ByVal value As Integer)
            _decimalDigits = value
        End Set
    End Property

    Private _integerDigits As Integer
    ''' <summary>
    ''' 整数部桁数
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property IntegerDigits() As Integer
        Get
            Return _integerDigits
        End Get
        Set(ByVal value As Integer)
            _integerDigits = value
        End Set
    End Property

    ''' <summary>
    ''' Null値入力許可
    ''' </summary>
    ''' <remarks></remarks>
    Private _permitNull As Boolean
    Public Property PermitNull() As Boolean
        Get
            Return _permitNull
        End Get
        Set(ByVal value As Boolean)
            _permitNull = value
        End Set
    End Property

    Private _dispSpinButton As Boolean
    ''' <summary>
    ''' スピンボタンの表示
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property DispSpinButton() As Boolean
        Get
            Return _dispSpinButton
        End Get
        Set(ByVal value As Boolean)
            _dispSpinButton = value
        End Set
    End Property

    Private _textDisplayMode As OSK.X1.Foundation.Controls.InputNumerical.TextDisplayModeType
    ''' <summary>
    ''' フォント幅調整
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property TextDisplayMode() As OSK.X1.Foundation.Controls.InputNumerical.TextDisplayModeType
        Get
            Return _textDisplayMode
        End Get
        Set(ByVal value As OSK.X1.Foundation.Controls.InputNumerical.TextDisplayModeType)
            _textDisplayMode = value
        End Set
    End Property


#End Region

End Class
