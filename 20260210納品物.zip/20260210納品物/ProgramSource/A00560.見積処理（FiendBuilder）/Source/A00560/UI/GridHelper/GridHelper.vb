﻿Public Class GridHelper

#Region "変数"

    'グリッド編集補助部品
    Private _editEntry As EditManager

#End Region

#Region "コンストラクタ"

    Sub New(ByVal gridEdit As SimpleControl.GridEdit, ByVal itemInfoList As ColumnInfoListBase, ByVal maxRowCount As Integer)

        Dim newTable As DataTable = New DataTable
        InitializeGridHelper(gridEdit, itemInfoList, maxRowCount, newTable)

    End Sub

    Private Sub InitializeGridHelper(ByVal gridEdit As SimpleControl.GridEdit, ByVal itemInfoList As ColumnInfoListBase, ByVal maxRowCount As Integer, ByVal newTable As DataTable)

        _editEntry = New EditManager(gridEdit)
        _editEntry.ItemInfoList = itemInfoList
        _editEntry.GridEdit.DataTable = newTable

    End Sub

#End Region

#Region "公開メソッド"

    ''' <summary>
    ''' 行を挿入する
    ''' </summary>
    ''' <param name="rowIndex">行番号</param>
    ''' <param name="row">行データ</param>
    ''' <remarks></remarks>
    Public Sub Insert(ByVal row As System.Data.DataRow, Optional ByVal rowIndex As Integer = -1)

        _editEntry.GridEdit.AddRow(rowIndex, 1)

        If rowIndex = -1 Then
            rowIndex = _editEntry.GridEdit.RowCount - 1
        End If

        For colIndex As Integer = 0 To _editEntry.GridEdit.Columns.Count - 1
            Dim colName As String = _editEntry.GridEdit.Columns(colIndex).Name
            If row.Table.Columns.Contains(colName) = True Then
                _editEntry.GridEdit.SetData(rowIndex, colName, row.Item(colName))
                _editEntry.GridEdit.GetDisplayCellInfo(rowIndex, colIndex).ReadOnly = _editEntry.GridEdit.Columns(colIndex).ReadOnly
            End If
        Next

    End Sub

    ''' <summary>
    ''' データテーブルをセットする
    ''' </summary>
    ''' <param name="dataTable">データテーブル</param>
    ''' <remarks></remarks>
    Public Sub SetDataTable(ByVal dataTable As System.Data.DataTable)

        _editEntry.GridEdit.DataTable = DataTable

    End Sub

    ''' <summary>
    ''' グリッドヘルパーを初期設定する
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub SetupGridHelper()

        _editEntry.SetupEdit()

    End Sub

#End Region

End Class
