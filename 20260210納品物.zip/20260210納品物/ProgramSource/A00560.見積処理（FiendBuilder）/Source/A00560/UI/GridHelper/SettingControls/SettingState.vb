﻿Public Class SettingState

End Class
