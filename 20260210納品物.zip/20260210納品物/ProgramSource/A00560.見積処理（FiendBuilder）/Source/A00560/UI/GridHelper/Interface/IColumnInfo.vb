﻿''' <summary>
''' 項目情報用インターフェース
''' </summary>
''' <remarks></remarks>
Public Interface IColumnInfo

#Region "プロパティ"

    ''' <summary>
    ''' 項目名称
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property Name() As String

    ''' <summary>
    ''' タイトル名称
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property TitleName() As String

    ''' <summary>
    ''' コントロールの種類
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    ReadOnly Property ControlKind() As ControlKindType

    ''' <summary>
    ''' 最大桁数
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property MaxLength() As Integer

    ''' <summary>
    ''' グリッドのカラム幅
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property ColumnWidth() As Single

    ''' <summary>
    ''' 非表示判定
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property Hide() As Boolean

    ''' <summary>
    ''' グループ番号
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property GroupNo() As Integer

    ''' <summary>
    ''' 初期値
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property DefaultValue() As String

    ''' <summary>
    ''' 項目の位置
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property ItemAlign() As OSK.X1.Foundation.Controls.Grid.Common.HorzAlign

    ''' <summary>
    ''' タイトルの位置
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property TitleAlign() As OSK.X1.Foundation.Controls.Grid.Common.HorzAlign

    ''' <summary>
    ''' タブインデックス
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property TabIndex() As Integer

    ''' <summary>
    ''' フォーマット
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property Format() As String

#End Region

#Region "メソッド"

    ''' <summary>
    ''' コントロール別設定を渡す
    ''' </summary>
    ''' <typeparam name="T"></typeparam>
    ''' <param name="individualSetting"></param>
    ''' <remarks></remarks>
    Sub GetSetting(Of T)(ByRef individualSetting As T)

    ''' <summary>
    ''' コントロール別設定を設定する
    ''' </summary>
    ''' <typeparam name="T"></typeparam>
    ''' <param name="settingValue"></param>
    ''' <remarks></remarks>
    Sub SetSetting(Of T)(ByVal settingValue As T)

#End Region

End Interface
