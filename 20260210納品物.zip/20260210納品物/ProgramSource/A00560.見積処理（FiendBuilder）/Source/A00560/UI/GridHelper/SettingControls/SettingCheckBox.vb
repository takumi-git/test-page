﻿Public Class SettingCheckBox

#Region "コンストラクタ"

    Sub New()
        _displayName = ""
    End Sub

    Sub New(ByVal displayName As String)
        _displayName = displayName
    End Sub

#End Region

#Region "プロパティ"
    Private _displayName As String
    Public Property DisplayName() As String
        Get
            Return _displayName
        End Get
        Set(ByVal value As String)
            _displayName = value
        End Set
    End Property
#End Region

End Class


