﻿Public Interface IEntryForm
    Inherits IInsideJob

    ''' <summary>
    ''' 初期処理を行なう
    ''' </summary>
    ''' <remarks></remarks>
    Sub SetUpForm()

    ''' <summary>
    ''' パラメータ情報
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property ParamInfo() As System.Collections.IDictionary

End Interface
