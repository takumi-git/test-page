﻿Public Class 退避情報型
    Inherits InsideJobBase

#Region "列挙"

    Friend Enum ヘッダー項目型
        伝票発行
        伝票発行_変更前
        処理モード
        処理連番
        伝票日付
        伝票日付_年月度
        伝票日付チェックフラグ
        税率
        税率番号
        得意先コード
        得意先名１
        得意先名２
        担当者コード
        担当者名
        部門コード
        部門名
        要件
        納期
        支払方法
        有効期限
        消費税コード
        消費税名
        得意先マスター情報
        担当者マスター情報
        部門マスター情報
        取引マスター情報
        消費税マスター情報
        'A-CUST20201013↓
        納品先コード
        納品先名
        納品先マスター情報
        'A-CUST20201013↑
        FieldBuilder    'A-CUST20251104
    End Enum

    Friend Enum 明細項目型
        '↓画面上表示されている項目
        '***1行目***
        行
        区分
        商品コード
        課税区分
        課税区分名
        倉庫コード
        倉庫名
        原単価
        原価金額
        ラベル1_01
        小計
        ラベル1_02 'A-CUST20251104

        '***2行目***
        ラベル2_01
        区分名
        商品名
        単位
        数量
        単価
        金額
        行摘要
        改頁
        FieldBuilder    'A-CUST20251104
        Detailcnt1

        '↑画面上表示されている項目
        内消費税額
        行ＤＢ値
        商品コード手入力
        商品マスター情報
        倉庫マスター情報
        行区分マスター情報       'A-CUST20200311 '-2020527-001
        課税区分マスター情報
        単価計算方法             'A-CUST20211001
        サブ明細情報             'A-CUST20241219
        Detailcnt2


    End Enum

    'A-CUST20241219↓
    Friend Enum サブ明細項目型
        '↓画面上表示されている項目
        '***1行目***
        行
        商品コード
        ラベル1_01
        ラベル1_02
        ラベル1_03
        ラベル1_04

        '***2行目***
        ラベル2_01
        商品名
        単位
        数量
        単価
        金額

        Detailcnt1

        '↑画面上表示されている項目
        行ＤＢ値
        行確定済
        商品コード手入力
        商品マスター情報
        Detailcnt2

    End Enum
    'A-CUST20241219↑

    Friend Enum フッター項目型
        倉庫別現在庫
        全社現在庫
        対象金額
        消費税額
        合計金額
        備考名
        消費税用_税抜_金額合計
        消費税用_税込_分解消費税計
        粗利額合計
        粗利率
        粗利用_税抜_金額合計
        更新用_非課税額
    End Enum

    Friend Enum グループ型 As Integer
        No１ = 1
        No２
        No３
        No４
        No５
        No６
    End Enum

    Friend Enum サブグループ型 As Integer
        No１ = 1
        No２
        No３
    End Enum

    Friend Enum 状態
        正常
        エラー
    End Enum

#End Region

#Region "内部変数"

    Private _Myコントロール情報 As Myコントロール情報型
    Private _定義情報 As 定義情報型

#End Region

#Region "コンストラクタ"

    Public Sub New()

        _printingController = New OSK.X1.Printing.UserInterface.Controller
        _起動モード = 起動モード型.通常モード
        _操作日付 = CInt(Now.ToString("yyyyMMdd"))
        _emptyDataSet = New DataSet

        _ヘッダー部 = New DataTable
        _明細表示部 = New DataTable
        _明細入力部 = New DataTable
        'A-CUST20241219↓
        _サブ明細表示部 = New DataTable
        _サブ明細入力部 = New DataTable
        _サブ明細情報 = New DataTable
        'A-CUST20241219↑
        _フッター部 = New DataTable
        _見積ヘッダー = CreateDataTable()
        _見積明細 = CreateDataTable()
        _見積サブ明細 = CreateDataTable()  'A-CUST20241219
        _得意先 = New DataTable
        _担当者 = New DataTable
        _部門 = New DataTable
        _納品先 = New DataTable   'A-CUST20201013
        _消費税 = New DataTable
        _課税区分 = New DataTable
        '_区分 = New DataTable            'D-CUST20200311 '-2020527-001
        _行区分 = New DataTable           'A-CUST20200311 '-2020527-001
        'A-CUST20251104↓
        _FieldBuilderヘッダー = New DataTable
        _FieldBuilder明細 = New DataTable
        'A-CUST20251104↑

        _商品 = New DataTable
        _倉庫 = New DataTable
        _連番管理 = New DataTable
        _見積書情報 = New DataTable
        ReDim _グループ状態(0 To 6)

    End Sub

#End Region

#Region "Initialize"

    Friend Sub Initializer(ByVal InitInfo As IDictionary,
                           ByVal コントロール情報 As Myコントロール情報型)

        _Myコントロール情報 = コントロール情報
        _定義情報 = New 定義情報型
        EmptyDataSet = CType(InitInfo.Item("プログラム専用.空のデータテーブル"), DataSet).Copy
        見積書情報 = CType(InitInfo.Item("プログラム専用.空の見積書データ"), DataTable).Copy
        'A-CUST20251104↓
        FieldBuilderヘッダー使用 = CType(InitInfo.Item("プログラム専用.FieldBuilder.ヘッダー.有効"), Boolean)
        FieldBuilder明細使用 = CType(InitInfo.Item("プログラム専用.FieldBuilder.明細.有効"), Boolean)
        'A-CUST20251104↑

        InitializeDataTable見積書情報()
        InitializeDataTable連番管理()
        InitializeDataTable見積伝票()
        InitializeDataTable見積サブ明細()     'A-CUST20241219
        InitializeDataTableヘッダー部()
        InitializeDataTable明細入力部()
        InitializeDataTableサブ明細入力部()   'A-CUST20241219
        InitializeDataTableフッター部()

    End Sub

#End Region

#Region "プロパティ"

    Private _emptyDataSet As DataSet
    Friend Property EmptyDataSet() As DataSet
        Get
            Return _emptyDataSet
        End Get
        Set(ByVal value As DataSet)
            _emptyDataSet = value.Copy
        End Set
    End Property

    Friend ReadOnly Property GetEmptyDataTable(ByVal target As IDenpyouReader.テーブル一覧型) As DataTable
        Get
            Return _emptyDataSet.Tables(target)
        End Get
    End Property

    Private _グループ状態() As 状態
    Friend Property グループ状態(ByVal groupNo As グループ型) As 状態
        Get
            Return _グループ状態(groupNo)
        End Get
        Set(ByVal value As 状態)
            _グループ状態(groupNo) = value
        End Set
    End Property

    'A-CUST20251104↓
    Private _FieldBuilderヘッダー使用 As Boolean
    Friend Property FieldBuilderヘッダー使用() As Boolean
        Get
            Return _FieldBuilderヘッダー使用
        End Get
        Set(ByVal value As Boolean)
            _FieldBuilderヘッダー使用 = value
        End Set
    End Property

    Private _FieldBuilder明細使用 As Boolean
    Friend Property FieldBuilder明細使用() As Boolean
        Get
            Return _FieldBuilder明細使用
        End Get
        Set(ByVal value As Boolean)
            _FieldBuilder明細使用 = value
        End Set
    End Property
    'A-CUST20251104↑

#Region "プログラム動作関連"
    Private _起動モード As 起動モード型
    Friend Property 起動モード() As 起動モード型
        Get
            Return _起動モード
        End Get
        Set(ByVal value As 起動モード型)
            _起動モード = value
        End Set
    End Property
#End Region

#Region "日付情報"

    Private _操作日付 As Integer
    Friend ReadOnly Property 操作日付() As Integer
        Get
            Return _操作日付
        End Get
    End Property

#End Region

#Region "初期値"

    Friend ReadOnly Property 初期値_商品コード() As String
        Get
            If _定義情報.商品コード_タイプ = 入力タイプ型.数字 Then
                Return New String(CChar("0"), _定義情報.商品コード_桁数)
            Else
                Return ""
            End If
        End Get
    End Property

    Friend ReadOnly Property 初期値_得意先コード() As String
        Get
            If _定義情報.得意先コード_タイプ = 入力タイプ型.数字 Then
                Return New String(CChar("0"), _定義情報.得意先コード_桁数)
            Else
                Return ""
            End If
        End Get
    End Property

    Friend ReadOnly Property 初期値_担当者コード() As String
        Get
            If _定義情報.担当者コード_タイプ = 入力タイプ型.数字 Then
                Return New String(CChar("0"), _定義情報.担当者コード_桁数)
            Else
                Return ""
            End If
        End Get
    End Property

    Friend ReadOnly Property 初期値_部門コード() As String
        Get
            If _定義情報.部門コード_タイプ = 入力タイプ型.数字 Then
                Return New String(CChar("0"), _定義情報.部門コード_桁数)
            Else
                Return ""
            End If
        End Get
    End Property

    'A-CUST20201013↓
    Friend ReadOnly Property 初期値_納品先コード() As String
        Get
            If _定義情報.納品先コード_タイプ = 入力タイプ型.数字 Then
                Return New String(CChar("0"), _定義情報.納品先コード_桁数)
            Else
                Return ""
            End If
        End Get
    End Property
    'A-CUST20201013↑

#End Region

#Region "手入力値"
    Friend ReadOnly Property 手入力_商品コード() As String
        Get
            Return New String(CChar("9"), _定義情報.商品コード_桁数)
        End Get
    End Property
#End Region

#Region "入力値関連"

    Private _ヘッダー部 As DataTable
    Friend Property ヘッダー部() As DataTable
        Get
            Return _ヘッダー部
        End Get
        Set(ByVal value As DataTable)
            _ヘッダー部 = value.Copy
        End Set
    End Property
    Friend Property ヘッダー部項目(ByVal columnName As 退避情報型.ヘッダー項目型) As Object
        Get
            Return trimEnd(_ヘッダー部.Rows(0).Item(columnName.ToString))
        End Get
        Set(ByVal value As Object)
            If _ヘッダー部.Columns(columnName.ToString).DataType Is GetType(DataTable) Then
                _ヘッダー部.Rows(0).Item(columnName.ToString) = CType(value, DataTable).Copy
            Else
                _ヘッダー部.Rows(0).Item(columnName.ToString) = value
            End If
        End Set
    End Property

    Private _明細表示部 As DataTable
    Friend Property 明細表示部() As DataTable
        Get
            Return _明細表示部
        End Get
        Set(ByVal value As DataTable)
            _明細表示部 = value.Copy
        End Set
    End Property
    Friend Property 明細表示部項目(ByVal rowIndex As Integer, ByVal columnName As String) As Object
        Get
            Return trimEnd(_明細表示部.Rows(rowIndex).Item(columnName))
        End Get
        Set(ByVal value As Object)
            If _明細表示部.Columns(columnName).DataType Is GetType(DataTable) Then
                _明細表示部.Rows(rowIndex).Item(columnName) = CType(value, DataTable).Copy
            Else
                _明細表示部.Rows(rowIndex).Item(columnName) = value
            End If
        End Set
    End Property
    Friend Property 明細表示部項目(ByVal rowIndex As Integer, ByVal columnName As 退避情報型.明細項目型) As Object
        Get
            Return 明細表示部項目(rowIndex, columnName.ToString)
        End Get
        Set(ByVal value As Object)
            明細表示部項目(rowIndex, columnName.ToString) = value
        End Set
    End Property
    Friend Property 明細部項目_商品情報(ByVal rowIndex As Integer, ByVal columnName As String) As Object
        Get
            Return trimEnd(CType(明細表示部項目(rowIndex, 明細項目型.商品マスター情報), DataTable).Rows(0).Item(columnName))
        End Get
        Set(ByVal value As Object)
            CType(明細表示部項目(rowIndex, 明細項目型.商品マスター情報), DataTable).Rows(0).Item(columnName) = value
        End Set
    End Property

    Private _明細入力部 As DataTable
    Friend Property 明細入力部() As DataTable
        Get
            Return _明細入力部
        End Get
        Set(ByVal value As DataTable)
            _明細入力部 = value.Copy
        End Set
    End Property
    Friend Property 明細入力部項目(ByVal columnName As String) As Object
        Get
            Return trimEnd(_明細入力部.Rows(0).Item(columnName))
        End Get
        Set(ByVal value As Object)
            If _明細入力部.Columns(columnName).DataType Is GetType(DataTable) Then
                _明細入力部.Rows(0).Item(columnName) = CType(value, DataTable).Copy
            Else
                _明細入力部.Rows(0).Item(columnName) = value
            End If
        End Set
    End Property
    Friend Property 明細入力部項目(ByVal columnName As 退避情報型.明細項目型) As Object
        Get
            Return 明細入力部項目(columnName.ToString)
        End Get
        Set(ByVal value As Object)
            明細入力部項目(columnName.ToString) = value
        End Set
    End Property

    Friend Property 明細入力部項目_商品情報(ByVal columnName As String) As Object
        Get
            Return trimEnd(CType(明細入力部項目(明細項目型.商品マスター情報), DataTable).Rows(0).Item(columnName))
        End Get
        Set(ByVal value As Object)
            CType(明細入力部項目(明細項目型.商品マスター情報), DataTable).Rows(0).Item(columnName) = value
        End Set
    End Property

    Friend Property 明細入力部項目_行区分情報(ByVal columnName As String) As Object
        Get
            Return trimEnd(CType(明細入力部項目(明細項目型.倉庫マスター情報), DataTable).Rows(0).Item(columnName))
        End Get
        Set(ByVal value As Object)
            CType(明細入力部項目(明細項目型.商品マスター情報), DataTable).Rows(0).Item(columnName) = value
        End Set
    End Property

    Private _フッター部 As DataTable
    Friend Property フッター部() As DataTable
        Get
            Return _フッター部
        End Get
        Set(ByVal value As DataTable)
            _フッター部 = value.Copy
        End Set
    End Property
    Friend Property フッター部項目(ByVal columnName As 退避情報型.フッター項目型) As Object
        Get
            Return trimEnd(_フッター部.Rows(0).Item(columnName.ToString))
        End Get
        Set(ByVal value As Object)
            If _フッター部.Columns(columnName.ToString).DataType Is GetType(DataTable) Then
                _フッター部.Rows(0).Item(columnName.ToString) = CType(value, DataTable).Copy
            Else
                _フッター部.Rows(0).Item(columnName.ToString) = value
            End If
        End Set
    End Property

    'A-CUST20241219↓
    Private _サブ明細表示部 As DataTable
    Friend Property サブ明細表示部() As DataTable
        Get
            Return _サブ明細表示部
        End Get
        Set(ByVal value As DataTable)
            _サブ明細表示部 = value.Copy
        End Set
    End Property
    Friend Property サブ明細表示部項目(ByVal rowIndex As Integer, ByVal columnName As String) As Object
        Get
            Return trimEnd(_サブ明細表示部.Rows(rowIndex).Item(columnName))
        End Get
        Set(ByVal value As Object)
            If _サブ明細表示部.Columns(columnName).DataType Is GetType(DataTable) Then
                _サブ明細表示部.Rows(rowIndex).Item(columnName) = CType(value, DataTable).Copy
            Else
                _サブ明細表示部.Rows(rowIndex).Item(columnName) = value
            End If
        End Set
    End Property
    Friend Property サブ明細表示部項目(ByVal rowIndex As Integer, ByVal columnName As 退避情報型.サブ明細項目型) As Object
        Get
            Return サブ明細表示部項目(rowIndex, columnName.ToString)
        End Get
        Set(ByVal value As Object)
            サブ明細表示部項目(rowIndex, columnName.ToString) = value
        End Set
    End Property
    Friend Property サブ明細部項目_商品情報(ByVal rowIndex As Integer, ByVal columnName As String) As Object
        Get
            Return trimEnd(CType(サブ明細表示部項目(rowIndex, サブ明細項目型.商品マスター情報), DataTable).Rows(0).Item(columnName))
        End Get
        Set(ByVal value As Object)
            CType(サブ明細表示部項目(rowIndex, サブ明細項目型.商品マスター情報), DataTable).Rows(0).Item(columnName) = value
        End Set
    End Property

    Private _サブ明細入力部 As DataTable
    Friend Property サブ明細入力部() As DataTable
        Get
            Return _サブ明細入力部
        End Get
        Set(ByVal value As DataTable)
            _サブ明細入力部 = value.Copy
        End Set
    End Property
    Friend Property サブ明細入力部項目(ByVal columnName As String) As Object
        Get
            Return trimEnd(_サブ明細入力部.Rows(0).Item(columnName))
        End Get
        Set(ByVal value As Object)
            If _サブ明細入力部.Columns(columnName).DataType Is GetType(DataTable) Then
                _サブ明細入力部.Rows(0).Item(columnName) = CType(value, DataTable).Copy
            Else
                _サブ明細入力部.Rows(0).Item(columnName) = value
            End If
        End Set
    End Property
    Friend Property サブ明細入力部項目(ByVal columnName As 退避情報型.サブ明細項目型) As Object
        Get
            Return サブ明細入力部項目(columnName.ToString)
        End Get
        Set(ByVal value As Object)
            サブ明細入力部項目(columnName.ToString) = value
        End Set
    End Property

    Friend Property サブ明細入力部項目_商品情報(ByVal columnName As String) As Object
        Get
            Return trimEnd(CType(サブ明細入力部項目(サブ明細項目型.商品マスター情報), DataTable).Rows(0).Item(columnName))
        End Get
        Set(ByVal value As Object)
            CType(サブ明細入力部項目(サブ明細項目型.商品マスター情報), DataTable).Rows(0).Item(columnName) = value
        End Set
    End Property

    Private _サブ明細情報 As DataTable
    Friend Property サブ明細情報() As DataTable
        Get
            Return _サブ明細情報
        End Get
        Set(ByVal value As DataTable)
            _サブ明細情報 = value.Copy
        End Set
    End Property
    Friend Property サブ明細情報項目(ByVal rowIndex As Integer, ByVal columnName As String) As Object
        Get
            Return trimEnd(_サブ明細情報.Rows(rowIndex).Item(columnName))
        End Get
        Set(ByVal value As Object)
            If _サブ明細情報.Columns(columnName).DataType Is GetType(DataTable) Then
                _サブ明細情報.Rows(rowIndex).Item(columnName) = CType(value, DataTable).Copy
            Else
                _サブ明細情報.Rows(rowIndex).Item(columnName) = value
            End If
        End Set
    End Property
    Friend Property サブ明細情報項目(ByVal rowIndex As Integer, ByVal columnName As 退避情報型.サブ明細項目型) As Object
        Get
            Return サブ明細情報項目(rowIndex, columnName.ToString)
        End Get
        Set(ByVal value As Object)
            サブ明細情報項目(rowIndex, columnName.ToString) = value
        End Set
    End Property
    'A-CUST20241219↑

#End Region

#Region "コントロールテーブル情報関連"

    Private _連番管理 As DataTable
    Friend Property 連番管理() As DataTable
        Get
            Return _連番管理
        End Get
        Set(ByVal value As DataTable)
            _連番管理 = value.Copy
        End Set
    End Property
    Friend Property 連番管理項目(ByVal columnName As String) As Object
        Get
            Return trimEnd(_連番管理.Rows(0).Item(columnName))
        End Get
        Set(ByVal value As Object)
            _連番管理.Rows(0).Item(columnName) = value
        End Set
    End Property

#End Region

#Region "マスター情報関連"

    Private _得意先 As DataTable
    Friend Property 得意先() As DataTable
        Get
            Return _得意先
        End Get
        Set(ByVal value As DataTable)
            _得意先 = value.Copy
        End Set
    End Property
    Friend Property 得意先項目(ByVal columnName As String) As Object
        Get
            Return trimEnd(_得意先.Rows(0).Item(columnName))
        End Get
        Set(ByVal value As Object)
            _得意先.Rows(0).Item(columnName) = value
        End Set
    End Property

    Private _商品 As DataTable
    Friend Property 商品() As DataTable
        Get
            Return _商品
        End Get
        Set(ByVal value As DataTable)
            _商品 = value.Copy
        End Set
    End Property
    Friend Property 商品項目(ByVal columnName As String) As Object
        Get
            Return trimEnd(_商品.Rows(0).Item(columnName))
        End Get
        Set(ByVal value As Object)
            _商品.Rows(0).Item(columnName) = value
        End Set
    End Property

    Private _担当者 As DataTable
    Friend Property 担当者() As DataTable
        Get
            Return _担当者
        End Get
        Set(ByVal value As DataTable)
            _担当者 = value.Copy
        End Set
    End Property
    Friend Property 担当者項目(ByVal columnName As String) As Object
        Get
            Return trimEnd(_担当者.Rows(0).Item(columnName))
        End Get
        Set(ByVal value As Object)
            _担当者.Rows(0).Item(columnName) = value
        End Set
    End Property

    Private _部門 As DataTable
    Friend Property 部門() As DataTable
        Get
            Return _部門
        End Get
        Set(ByVal value As DataTable)
            _部門 = value.Copy
        End Set
    End Property
    Friend Property 部門項目(ByVal columnName As String) As Object
        Get
            Return trimEnd(_部門.Rows(0).Item(columnName))
        End Get
        Set(ByVal value As Object)
            _部門.Rows(0).Item(columnName) = value
        End Set
    End Property

    Private _倉庫 As DataTable
    Friend Property 倉庫() As DataTable
        Get
            Return _倉庫
        End Get
        Set(ByVal value As DataTable)
            _倉庫 = value.Copy
        End Set
    End Property
    Friend Property 倉庫項目(ByVal columnName As String) As Object
        Get
            Return trimEnd(_倉庫.Rows(0).Item(columnName))
        End Get
        Set(ByVal value As Object)
            _倉庫.Rows(0).Item(columnName) = value
        End Set
    End Property

    Private _消費税 As DataTable
    Friend Property 消費税() As DataTable
        Get
            Return _消費税
        End Get
        Set(ByVal value As DataTable)
            _消費税 = value.Copy
        End Set
    End Property
    Friend Property 消費税項目(ByVal columnName As String) As Object
        Get
            Return trimEnd(_消費税.Rows(0).Item(columnName))
        End Get
        Set(ByVal value As Object)
            _消費税.Rows(0).Item(columnName) = value
        End Set
    End Property

    Private _課税区分 As DataTable
    Friend Property 課税区分() As DataTable
        Get
            Return _課税区分
        End Get
        Set(ByVal value As DataTable)
            _課税区分 = value.Copy
        End Set
    End Property
    Friend Property 課税区分項目(ByVal columnName As String) As Object
        Get
            Return trimEnd(_課税区分.Rows(0).Item(columnName))
        End Get
        Set(ByVal value As Object)
            _課税区分.Rows(0).Item(columnName) = value
        End Set
    End Property

    'A-CUST20200311↓ '-2020527-001
    Private _行区分 As DataTable
    Friend Property 行区分() As DataTable
        Get
            Return _行区分
        End Get
        Set(ByVal value As DataTable)
            _行区分 = value.Copy
        End Set
    End Property
    Friend Property 行区分項目(ByVal columnName As String) As Object
        Get
            Return trimEnd(_行区分.Rows(0).Item(columnName))
        End Get
        Set(ByVal value As Object)
            _行区分.Rows(0).Item(columnName) = value
        End Set
    End Property
    'A-CUST20200311↑ '-2020527-001

    'D-CUST20200311↓ '-2020527-001
    'Private _区分 As DataTable
    'Friend Property 区分() As DataTable
    '    Get
    '        Return _区分
    '    End Get
    '    Set(ByVal value As DataTable)
    '        _区分 = value.Copy
    '    End Set
    'End Property
    'Friend Property 区分項目(ByVal columnName As String) As Object
    '    Get
    '        Return trimEnd(_区分.Rows(0).Item(columnName))
    '    End Get
    '    Set(ByVal value As Object)
    '        _区分.Rows(0).Item(columnName) = value
    '    End Set
    'End Property
    'D-CUST20200311↑ '-2020527-001

    'A-CUST20201013↓
    Private _納品先 As DataTable
    Friend Property 納品先() As DataTable
        Get
            Return _納品先
        End Get
        Set(ByVal value As DataTable)
            _納品先 = value.Copy
        End Set
    End Property
    Friend Property 納品先項目(ByVal columnName As String) As Object
        Get
            Return trimEnd(_納品先.Rows(0).Item(columnName))
        End Get
        Set(ByVal value As Object)
            _納品先.Rows(0).Item(columnName) = value
        End Set
    End Property
    'A-CUST20201013↑
    'A-CUST20251104↓

    Private _FieldBuilderヘッダー As DataTable
    Friend Property FieldBuilderヘッダー() As DataTable
        Get
            Return _FieldBuilderヘッダー
        End Get
        Set(ByVal value As DataTable)
            _FieldBuilderヘッダー = value.Copy
        End Set
    End Property

    Friend Property FieldBuilderヘッダー項目(ByVal columnName As String) As Object
        Get
            Return trimEnd(_FieldBuilderヘッダー.Rows(0).Item(columnName))
        End Get
        Set(ByVal value As Object)
            _FieldBuilderヘッダー.Rows(0).Item(columnName) = value
        End Set
    End Property

    Private _FieldBuilder明細 As DataTable
    Friend Property FieldBuilder明細() As DataTable
        Get
            Return _FieldBuilder明細
        End Get
        Set(ByVal value As DataTable)
            _FieldBuilder明細 = value.Copy
        End Set
    End Property

    Friend Property FieldBuilder明細項目(ByVal columnName As String) As Object
        Get
            Return trimEnd(_FieldBuilder明細.Rows(0).Item(columnName))
        End Get
        Set(ByVal value As Object)
            _FieldBuilder明細.Rows(0).Item(columnName) = value
        End Set
    End Property
    'A-CUST20251104↑
#End Region

#Region "伝票関連"

    Private _見積ヘッダー As DataTable
    Friend Property 見積ヘッダー() As DataTable
        Get
            Return _見積ヘッダー
        End Get
        Set(ByVal value As DataTable)
            _見積ヘッダー = value.Copy
        End Set
    End Property
    Friend Property 見積ヘッダー項目(ByVal columnName As String) As Object
        Get
            Return trimEnd(_見積ヘッダー.Rows(0).Item(columnName))
        End Get
        Set(ByVal value As Object)
            _見積ヘッダー.Rows(0).Item(columnName) = value
        End Set
    End Property

    Private _見積明細 As DataTable
    Friend Property 見積明細() As DataTable
        Get
            Return _見積明細
        End Get
        Set(ByVal value As DataTable)
            _見積明細 = value.Copy
        End Set
    End Property
    Friend Property 見積明細項目(ByVal rowIndex As Integer, ByVal columnName As String) As Object
        Get
            Return trimEnd(_見積明細.Rows(rowIndex).Item(columnName))
        End Get
        Set(ByVal value As Object)
            _見積明細.Rows(rowIndex).Item(columnName) = value
        End Set
    End Property

    'A-CUST20241219↓
    Private _見積サブ明細 As DataTable
    Friend Property 見積サブ明細() As DataTable
        Get
            Return _見積サブ明細
        End Get
        Set(ByVal value As DataTable)
            _見積サブ明細 = value.Copy
        End Set
    End Property
    Friend Property 見積サブ明細項目(ByVal rowIndex As Integer, ByVal columnName As String) As Object
        Get
            Return trimEnd(_見積サブ明細.Rows(rowIndex).Item(columnName))
        End Get
        Set(ByVal value As Object)
            _見積サブ明細.Rows(rowIndex).Item(columnName) = value
        End Set
    End Property
    'A-CUST20241219↑

#End Region

#Region "印刷関連"

    Private _printingController As OSK.X1.Printing.UserInterface.Controller
    Public Property PrintingController() As OSK.X1.Printing.UserInterface.Controller
        Get
            Return _printingController
        End Get
        Set(ByVal value As OSK.X1.Printing.UserInterface.Controller)
            _printingController = value
        End Set
    End Property

    Private _見積書情報 As DataTable
    Friend Property 見積書情報() As DataTable
        Get
            Return _見積書情報
        End Get
        Set(ByVal value As DataTable)
            _見積書情報 = value.Copy
        End Set
    End Property
    Friend Property 見積書情報項目(ByVal rowIndex As Integer, ByVal columnName As String) As Object
        Get
            Return trimEnd(_見積書情報.Rows(rowIndex).Item(columnName))
        End Get
        Set(ByVal value As Object)
            _見積書情報.Rows(rowIndex).Item(columnName) = value
        End Set
    End Property

#End Region
#End Region

#Region "公開メソッド"

    Friend Sub ClearDataTableヘッダー部(ByVal clearTarget As 退避情報型.グループ型)

        With ヘッダー部.Rows(0)
            If clearTarget = 退避情報型.グループ型.No１ Then
                .Item(退避情報型.ヘッダー項目型.処理連番.ToString) = 0
                .Item(退避情報型.ヘッダー項目型.伝票日付.ToString) = 0
                .Item(退避情報型.ヘッダー項目型.伝票日付_年月度.ToString) = 0
                .Item(退避情報型.ヘッダー項目型.伝票日付チェックフラグ.ToString) = False
                .Item(退避情報型.ヘッダー項目型.税率番号.ToString) = 0
                .Item(退避情報型.ヘッダー項目型.税率.ToString) = 0
            End If
            If clearTarget = 退避情報型.グループ型.No２ Then
            End If
            If clearTarget = 退避情報型.グループ型.No３ Then
                .Item(退避情報型.ヘッダー項目型.得意先コード.ToString) = 初期値_得意先コード
                .Item(退避情報型.ヘッダー項目型.得意先名１.ToString) = ""
                .Item(退避情報型.ヘッダー項目型.得意先名２.ToString) = ""
                .Item(退避情報型.ヘッダー項目型.担当者コード.ToString) = 初期値_担当者コード
                .Item(退避情報型.ヘッダー項目型.担当者名.ToString) = ""
                .Item(退避情報型.ヘッダー項目型.部門コード.ToString) = 初期値_部門コード
                .Item(退避情報型.ヘッダー項目型.部門名.ToString) = ""
                .Item(退避情報型.ヘッダー項目型.要件.ToString) = ""
                .Item(退避情報型.ヘッダー項目型.納期.ToString) = ""
                .Item(退避情報型.ヘッダー項目型.支払方法.ToString) = ""
                .Item(退避情報型.ヘッダー項目型.有効期限.ToString) = ""
                .Item(退避情報型.ヘッダー項目型.消費税コード.ToString) = ""
                .Item(退避情報型.ヘッダー項目型.消費税名.ToString) = ""
                .Item(退避情報型.ヘッダー項目型.得意先マスター情報.ToString) = 得意先.Copy
                .Item(退避情報型.ヘッダー項目型.担当者マスター情報.ToString) = 担当者.Copy
                .Item(退避情報型.ヘッダー項目型.部門マスター情報.ToString) = 部門.Copy
                .Item(退避情報型.ヘッダー項目型.消費税マスター情報.ToString) = 消費税.Copy
                'A-CUST20201013↓
                .Item(退避情報型.ヘッダー項目型.納品先コード.ToString) = 初期値_納品先コード
                .Item(退避情報型.ヘッダー項目型.納品先名.ToString) = ""
                .Item(退避情報型.ヘッダー項目型.納品先マスター情報.ToString) = 納品先.Copy
                'A-CUST20201013↑
                .Item(退避情報型.ヘッダー項目型.FieldBuilder.ToString) = FieldBuilderヘッダー.Copy  'A-CUST20251104
            End If
        End With

    End Sub

    Friend Sub ClearDataTableフッター部()

        With フッター部.Rows(0)
            .Item(退避情報型.フッター項目型.倉庫別現在庫.ToString) = 0
            .Item(退避情報型.フッター項目型.全社現在庫.ToString) = 0
            .Item(退避情報型.フッター項目型.対象金額.ToString) = 0
            .Item(退避情報型.フッター項目型.消費税額.ToString) = 0
            .Item(退避情報型.フッター項目型.合計金額.ToString) = 0
            .Item(退避情報型.フッター項目型.備考名.ToString) = ""

            .Item(退避情報型.フッター項目型.消費税用_税抜_金額合計.ToString) = 0
            .Item(退避情報型.フッター項目型.消費税用_税込_分解消費税計.ToString) = 0
            .Item(退避情報型.フッター項目型.粗利額合計.ToString) = 0
            .Item(退避情報型.フッター項目型.粗利率.ToString) = 0
            .Item(退避情報型.フッター項目型.粗利用_税抜_金額合計.ToString) = 0
            .Item(退避情報型.フッター項目型.更新用_非課税額.ToString) = 0
        End With

    End Sub

    Friend Sub ClearDataTable得意先()

        SetDefaultValue(得意先)

        得意先項目("CUSME01001") = 初期値_得意先コード

    End Sub

    Friend Sub ClearDataTable担当者()

        SetDefaultValue(担当者)

        担当者項目("CUSME04001") = 初期値_担当者コード
        担当者項目("CUSME04005") = 初期値_部門コード

    End Sub

    'A-CUST20201013↓
    Friend Sub ClearDataTable納品先()

        SetDefaultValue(納品先)

        納品先項目("CUSME37002") = 初期値_納品先コード

    End Sub
    'A-CUST20201013↑

    Friend Sub ClearDataTable商品()

        SetDefaultValue(商品)

        商品項目("CUSME03001") = 初期値_商品コード

    End Sub

    Friend Sub ClearDataTable倉庫()

        SetDefaultValue(倉庫)

        倉庫項目("CUSME06001") = "000000"

    End Sub

    Friend Sub ClearDataTable部門()

        SetDefaultValue(部門)

        部門項目("CUSME05001") = 初期値_部門コード

    End Sub

    Friend Sub ClearDataTable消費税()

        SetDefaultValue(消費税)

    End Sub

    Friend Sub ClearDataTable課税区分()

        SetDefaultValue(課税区分)

    End Sub

    Friend Sub ClearDataTableFieldBuilderヘッダー()
        SetDefaultValue(FieldBuilderヘッダー)
    End Sub
    Friend Sub ClearDataTableFieldBuilder明細()
        SetDefaultValue(FieldBuilder明細)
    End Sub

    Friend Function CreateNewRow明細(ByVal GridEdit As Boolean, Optional ByVal targetLine As Integer = 0) As DataRow

        Dim gyoNo As String
        gyoNo = CStr(targetLine + 1).ToString
        Dim newRow As DataRow
        If GridEdit = True Then
            newRow = 明細入力部.NewRow
        Else
            newRow = 明細表示部.NewRow
        End If

        newRow.Item(退避情報型.明細項目型.行.ToString) = gyoNo
        If GridEdit = True Then
            newRow.Item(退避情報型.明細項目型.区分.ToString) = "01"
        Else
            newRow.Item(退避情報型.明細項目型.区分.ToString) = ""
        End If
        newRow.Item(退避情報型.明細項目型.区分名.ToString) = ""
        newRow.Item(退避情報型.明細項目型.商品コード.ToString) = ""
        newRow.Item(退避情報型.明細項目型.商品名.ToString) = ""
        newRow.Item(退避情報型.明細項目型.単位.ToString) = ""
        newRow.Item(退避情報型.明細項目型.課税区分.ToString) = ""
        newRow.Item(退避情報型.明細項目型.課税区分名.ToString) = ""
        newRow.Item(退避情報型.明細項目型.倉庫コード.ToString) = ""
        newRow.Item(退避情報型.明細項目型.倉庫名.ToString) = ""
        newRow.Item(退避情報型.明細項目型.数量.ToString) = 0
        newRow.Item(退避情報型.明細項目型.原単価.ToString) = 0
        newRow.Item(退避情報型.明細項目型.原価金額.ToString) = 0
        newRow.Item(退避情報型.明細項目型.単価.ToString) = 0
        newRow.Item(退避情報型.明細項目型.金額.ToString) = 0
        newRow.Item(退避情報型.明細項目型.行摘要.ToString) = ""
        newRow.Item(退避情報型.明細項目型.小計.ToString) = CheckState.Unchecked
        newRow.Item(退避情報型.明細項目型.改頁.ToString) = CheckState.Unchecked
        newRow.Item(退避情報型.明細項目型.内消費税額.ToString) = 0
        newRow.Item(退避情報型.明細項目型.行ＤＢ値.ToString) = 0
        newRow.Item(退避情報型.明細項目型.商品コード手入力.ToString) = False
        newRow.Item(退避情報型.明細項目型.商品マスター情報.ToString) = 商品.Copy
        newRow.Item(退避情報型.明細項目型.倉庫マスター情報.ToString) = 倉庫.Copy
        newRow.Item(退避情報型.明細項目型.行区分マスター情報.ToString) = 行区分.Copy
        newRow.Item(退避情報型.明細項目型.課税区分マスター情報.ToString) = 課税区分.Copy
        'A-CUST20241219↓
        サブ明細表示部.Clear()
        サブ明細表示部.Rows.Add(CreateNewRowサブ明細(GridType.view))
        newRow.Item(退避情報型.明細項目型.サブ明細情報.ToString) = サブ明細表示部.Copy
        'A-CUST20241219↑
        newRow.Item(退避情報型.明細項目型.ラベル1_01.ToString) = ""
        newRow.Item(退避情報型.明細項目型.ラベル2_01.ToString) = ""

        'A-CUST20251104↓
        If _FieldBuilder明細使用 Then
            newRow.Item(退避情報型.明細項目型.FieldBuilder.ToString) = FieldBuilder明細.Copy
        End If
        'A-CUST20251104↑

        Return newRow

    End Function

    'A-CUST20241219↓
    Enum GridType
        edit = 0
        view = 1
        info = 2
    End Enum

    Friend Function CreateNewRowサブ明細(ByVal GridEdit As GridType, Optional ByVal targetLine As Integer = 0) As DataRow

        Dim gyoNo As String
        gyoNo = CStr(targetLine + 1).ToString
        Dim newRow As DataRow
        Select Case GridEdit
            Case GridType.edit
                newRow = サブ明細入力部.NewRow
            Case GridType.view
                newRow = サブ明細表示部.NewRow
            Case GridType.info
                newRow = サブ明細情報.NewRow
            Case Else
                newRow = サブ明細入力部.NewRow
        End Select

        newRow.Item(退避情報型.サブ明細項目型.行.ToString) = gyoNo
        newRow.Item(退避情報型.サブ明細項目型.商品コード.ToString) = ""
        newRow.Item(退避情報型.サブ明細項目型.商品名.ToString) = ""
        newRow.Item(退避情報型.サブ明細項目型.単位.ToString) = ""
        newRow.Item(退避情報型.サブ明細項目型.数量.ToString) = 0
        newRow.Item(退避情報型.サブ明細項目型.単価.ToString) = 0
        newRow.Item(退避情報型.サブ明細項目型.金額.ToString) = 0
        newRow.Item(退避情報型.サブ明細項目型.行ＤＢ値.ToString) = 0
        newRow.Item(退避情報型.サブ明細項目型.行確定済.ToString) = False
        newRow.Item(退避情報型.サブ明細項目型.商品コード手入力.ToString) = False
        newRow.Item(退避情報型.サブ明細項目型.商品マスター情報.ToString) = 商品.Copy
        newRow.Item(退避情報型.サブ明細項目型.ラベル1_01.ToString) = ""
        newRow.Item(退避情報型.サブ明細項目型.ラベル1_02.ToString) = ""
        newRow.Item(退避情報型.サブ明細項目型.ラベル1_03.ToString) = ""
        newRow.Item(退避情報型.サブ明細項目型.ラベル1_04.ToString) = ""
        newRow.Item(退避情報型.サブ明細項目型.ラベル2_01.ToString) = ""

        Return newRow

    End Function
    'A-CUST20241219↑

    ''' <summary>
    ''' 対象DataTableより１行抜き出し、退避DataTableの位置0行に格納する
    ''' </summary>
    ''' <param name="row"></param>
    ''' <param name="dataTable"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function GetPullOutRows(ByVal row As Integer, ByVal dataTable As DataTable) As DataTable

        Dim dt As DataTable = dataTable.Clone
        dt.Clear()
        dt.Rows.Add(dt.NewRow)
        dt.Rows(0).ItemArray = dataTable.Rows(row).ItemArray
        Return dt.Copy

    End Function

    ''' <summary>
    ''' 取得データを指定された退避用テーブルに移送する
    ''' </summary>
    ''' <param name="getData">取得DataTable</param>
    ''' <param name="saveData">退避DataTable</param>
    ''' <remarks>一括移送</remarks>
    Friend Overloads Sub SaveDataValue(ByVal getData As DataTable, ByRef saveData As DataTable)

        SetDataTableProperty(getData)

        saveData.Clear()
        saveData = getData.Copy

    End Sub

    ''' <summary>
    ''' 取得データを指定された退避用テーブルに移送する
    ''' </summary>
    ''' <param name="getData">取得DataTable</param>
    ''' <param name="saveData">退避DataTable（※複数指定可）</param>
    ''' <remarks>個別移送（指定文字を元に行列毎に抜き出し、指定した退避DataTableへ移送）</remarks>
    Friend Overloads Sub SaveDataValue(ByVal getData As DataTable, ByRef saveData As IDictionary(Of String, DataTable))

        SetDataTableProperty(getData)

        For Each key As String In saveData.Keys
            saveData(key).Clear()
            For row As Integer = 0 To getData.Rows.Count - 1
                CreateAddRow(CType(saveData(key), DataTable))
                For col As Integer = 0 To getData.Columns.Count - 1
                    If Strings.InStr(getData.Columns.Item(col).ColumnName, key) > 0 Then
                        Dim colName As String = RemoveAliasName(getData.Columns(col).ColumnName)
                        saveData(key).Rows(row).Item(colName) = getData.Rows(row).Item(col)
                    End If
                Next
            Next
        Next

    End Sub

    Friend Sub SaveDataColumnValue(ByVal getData As DataTable, ByVal key As String, ByRef saveData As DataTable)

        For row As Integer = 0 To getData.Rows.Count - 1
            For col As Integer = 0 To getData.Columns.Count - 1
                If Strings.InStr(getData.Columns.Item(col).ColumnName, key) > 0 Then
                    Dim colName As String = RemoveAliasName(getData.Columns(col).ColumnName)
                    saveData.Rows(row).Item(colName) = getData.Rows(row).Item(col)
                End If
            Next
        Next

    End Sub

    ''' <summary>
    ''' 不要なDataTable属性列を除去する
    ''' </summary>
    ''' <param name="targetDataTable"></param>
    ''' <remarks></remarks>
    Friend Sub RemoveJunkColumns(ByRef targetDataTable As DataTable)

        Dim dt As DataTable = targetDataTable.Copy

        With dt

            For colIndex As Integer = 0 To .Columns.Count - 1
                'DataTable属性列以外は対象外
                If .Columns(colIndex).DataType IsNot GetType(DataTable) Then
                    Continue For
                End If

                'DataTable属性列に設定されているDataTableがカラか判定
                Dim junkColName As String = .Columns(colIndex).ColumnName
                For rowIndex As Integer = 0 To .Rows.Count - 1
                    If CType(.Rows(rowIndex).Item(colIndex), DataTable).Rows.Count <> 0 Then
                        junkColName = ""
                        Exit For
                    End If
                Next

                '不要列をtargetDataTableから除去
                If junkColName <> "" Then
                    targetDataTable.Columns.Remove(junkColName)
                End If
            Next

        End With

    End Sub

#End Region

#Region "内部メソッド"

    Friend Sub CreateAddRow(ByRef targetDataTable As DataTable)
        SetAddDefaultValue(targetDataTable)
        targetDataTable.Rows.Add(targetDataTable.NewRow)
    End Sub

    ''' <summary>
    ''' DataTableのXMLフォーマットをBinaryに変更する
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function CreateDataTable() As DataTable
        Dim result As New DataTable

        result.RemotingFormat = SerializationFormat.Binary

        Return result

    End Function

    Private Sub InitializeDataTableヘッダー部()

        With ヘッダー部.Columns
            .Clear()
            .Add(New DataColumn(退避情報型.ヘッダー項目型.伝票発行.ToString, GetType(Integer)))
            .Add(New DataColumn(退避情報型.ヘッダー項目型.伝票発行_変更前.ToString, GetType(Integer)))
            .Add(New DataColumn(退避情報型.ヘッダー項目型.処理モード.ToString, GetType(処理区分型)))
            .Add(New DataColumn(退避情報型.ヘッダー項目型.処理連番.ToString, GetType(Long)))
            .Add(New DataColumn(退避情報型.ヘッダー項目型.伝票日付.ToString, GetType(Integer)))
            .Add(New DataColumn(退避情報型.ヘッダー項目型.伝票日付_年月度.ToString, GetType(Integer)))
            .Add(New DataColumn(退避情報型.ヘッダー項目型.伝票日付チェックフラグ.ToString, GetType(Boolean)))
            .Add(New DataColumn(退避情報型.ヘッダー項目型.税率番号.ToString, GetType(Integer)))
            .Add(New DataColumn(退避情報型.ヘッダー項目型.税率.ToString, GetType(Decimal)))
            .Add(New DataColumn(退避情報型.ヘッダー項目型.得意先コード.ToString, GetType(String)))
            .Add(New DataColumn(退避情報型.ヘッダー項目型.得意先名１.ToString, GetType(String)))
            .Add(New DataColumn(退避情報型.ヘッダー項目型.得意先名２.ToString, GetType(String)))
            .Add(New DataColumn(退避情報型.ヘッダー項目型.担当者コード.ToString, GetType(String)))
            .Add(New DataColumn(退避情報型.ヘッダー項目型.担当者名.ToString, GetType(String)))
            .Add(New DataColumn(退避情報型.ヘッダー項目型.部門コード.ToString, GetType(String)))
            .Add(New DataColumn(退避情報型.ヘッダー項目型.部門名.ToString, GetType(String)))
            .Add(New DataColumn(退避情報型.ヘッダー項目型.要件.ToString, GetType(String)))
            .Add(New DataColumn(退避情報型.ヘッダー項目型.納期.ToString, GetType(String)))
            .Add(New DataColumn(退避情報型.ヘッダー項目型.支払方法.ToString, GetType(String)))
            .Add(New DataColumn(退避情報型.ヘッダー項目型.有効期限.ToString, GetType(String)))
            .Add(New DataColumn(退避情報型.ヘッダー項目型.消費税コード.ToString, GetType(String)))
            .Add(New DataColumn(退避情報型.ヘッダー項目型.消費税名.ToString, GetType(String)))
            .Add(New DataColumn(退避情報型.ヘッダー項目型.得意先マスター情報.ToString, GetType(DataTable)))
            .Add(New DataColumn(退避情報型.ヘッダー項目型.担当者マスター情報.ToString, GetType(DataTable)))
            .Add(New DataColumn(退避情報型.ヘッダー項目型.部門マスター情報.ToString, GetType(DataTable)))
            .Add(New DataColumn(退避情報型.ヘッダー項目型.取引マスター情報.ToString, GetType(DataTable)))
            .Add(New DataColumn(退避情報型.ヘッダー項目型.消費税マスター情報.ToString, GetType(DataTable)))
            'A-CUST20201013↓
            .Add(New DataColumn(退避情報型.ヘッダー項目型.納品先コード.ToString, GetType(String)))
            .Add(New DataColumn(退避情報型.ヘッダー項目型.納品先名.ToString, GetType(String)))
            .Add(New DataColumn(退避情報型.ヘッダー項目型.納品先マスター情報.ToString, GetType(DataTable)))
            'A-CUST20201013↑
            'A-CUST20251104↓
            .Add(New DataColumn(退避情報型.ヘッダー項目型.FieldBuilder.ToString, GetType(DataTable)))
            'A-CUST20251104↑
        End With

        CreateAddRow(ヘッダー部)

    End Sub

    Private Sub InitializeDataTable明細入力部()

        With 明細入力部.Columns
            .Clear()
            .Add(New DataColumn(退避情報型.明細項目型.行.ToString, GetType(String)))
            .Add(New DataColumn(退避情報型.明細項目型.区分.ToString, GetType(String)))
            .Add(New DataColumn(退避情報型.明細項目型.区分名.ToString, GetType(String)))
            .Add(New DataColumn(退避情報型.明細項目型.商品コード.ToString, GetType(String)))
            .Add(New DataColumn(退避情報型.明細項目型.商品名.ToString, GetType(String)))
            .Add(New DataColumn(退避情報型.明細項目型.単位.ToString, GetType(String)))
            .Add(New DataColumn(退避情報型.明細項目型.課税区分.ToString, GetType(String)))
            .Add(New DataColumn(退避情報型.明細項目型.課税区分名.ToString, GetType(String)))
            .Add(New DataColumn(退避情報型.明細項目型.倉庫コード.ToString, GetType(String)))
            .Add(New DataColumn(退避情報型.明細項目型.倉庫名.ToString, GetType(String)))
            .Add(New DataColumn(退避情報型.明細項目型.数量.ToString, GetType(Decimal)))
            .Add(New DataColumn(退避情報型.明細項目型.原単価.ToString, GetType(Decimal)))
            .Add(New DataColumn(退避情報型.明細項目型.原価金額.ToString, GetType(Decimal)))
            .Add(New DataColumn(退避情報型.明細項目型.単価.ToString, GetType(Decimal)))
            .Add(New DataColumn(退避情報型.明細項目型.金額.ToString, GetType(Decimal)))
            .Add(New DataColumn(退避情報型.明細項目型.行摘要.ToString, GetType(String)))
            .Add(New DataColumn(退避情報型.明細項目型.小計.ToString, GetType(Integer)))
            .Add(New DataColumn(退避情報型.明細項目型.改頁.ToString, GetType(Integer)))

            .Add(New DataColumn(退避情報型.明細項目型.FieldBuilder.ToString, GetType(DataTable))) 'A-CUST20251104

            .Add(New DataColumn(退避情報型.明細項目型.内消費税額.ToString, GetType(Decimal)))
            .Add(New DataColumn(退避情報型.明細項目型.行ＤＢ値.ToString, GetType(Integer)))
            .Add(New DataColumn(退避情報型.明細項目型.Detailcnt1.ToString, GetType(Integer)))
            .Add(New DataColumn(退避情報型.明細項目型.商品コード手入力.ToString, GetType(Boolean)))
            .Add(New DataColumn(退避情報型.明細項目型.商品マスター情報.ToString, GetType(DataTable)))
            .Add(New DataColumn(退避情報型.明細項目型.倉庫マスター情報.ToString, GetType(DataTable)))
            .Add(New DataColumn(退避情報型.明細項目型.行区分マスター情報.ToString, GetType(DataTable)))            'A-CUST20200311 '-2020527-001
            .Add(New DataColumn(退避情報型.明細項目型.課税区分マスター情報.ToString, GetType(DataTable)))
            .Add(New DataColumn(退避情報型.明細項目型.単価計算方法.ToString, GetType(Integer)))                    'A-CUST20211001
            .Add(New DataColumn(退避情報型.明細項目型.サブ明細情報.ToString, GetType(DataTable)))                  'A-CUST20241219
            .Add(New DataColumn(退避情報型.明細項目型.ラベル1_01.ToString, GetType(String)))

            .Add(New DataColumn(退避情報型.明細項目型.ラベル1_02.ToString, GetType(String))) 'A-CUST20251104

            .Add(New DataColumn(退避情報型.明細項目型.ラベル2_01.ToString, GetType(String)))
            .Add(New DataColumn(退避情報型.明細項目型.Detailcnt2.ToString, GetType(String)))
        End With

        CreateAddRow(明細入力部)

        明細表示部 = 明細入力部.Copy

    End Sub

    'A-CUST20241219↓
    Private Sub InitializeDataTableサブ明細入力部()

        With サブ明細入力部.Columns
            .Clear()
            .Add(New DataColumn(退避情報型.サブ明細項目型.行.ToString, GetType(String)))
            .Add(New DataColumn(退避情報型.サブ明細項目型.商品コード.ToString, GetType(String)))
            .Add(New DataColumn(退避情報型.サブ明細項目型.商品名.ToString, GetType(String)))
            .Add(New DataColumn(退避情報型.サブ明細項目型.単位.ToString, GetType(String)))
            .Add(New DataColumn(退避情報型.サブ明細項目型.数量.ToString, GetType(Decimal)))
            .Add(New DataColumn(退避情報型.サブ明細項目型.単価.ToString, GetType(Decimal)))
            .Add(New DataColumn(退避情報型.サブ明細項目型.金額.ToString, GetType(Decimal)))
            .Add(New DataColumn(退避情報型.サブ明細項目型.行ＤＢ値.ToString, GetType(Integer)))
            .Add(New DataColumn(退避情報型.サブ明細項目型.行確定済.ToString, GetType(Boolean)))
            .Add(New DataColumn(退避情報型.サブ明細項目型.Detailcnt1.ToString, GetType(Integer)))
            .Add(New DataColumn(退避情報型.サブ明細項目型.商品コード手入力.ToString, GetType(Boolean)))
            .Add(New DataColumn(退避情報型.サブ明細項目型.商品マスター情報.ToString, GetType(DataTable)))
            .Add(New DataColumn(退避情報型.サブ明細項目型.ラベル1_01.ToString, GetType(String)))
            .Add(New DataColumn(退避情報型.サブ明細項目型.ラベル1_02.ToString, GetType(String)))
            .Add(New DataColumn(退避情報型.サブ明細項目型.ラベル1_03.ToString, GetType(String)))
            .Add(New DataColumn(退避情報型.サブ明細項目型.ラベル1_04.ToString, GetType(String)))
            .Add(New DataColumn(退避情報型.サブ明細項目型.ラベル2_01.ToString, GetType(String)))
            .Add(New DataColumn(退避情報型.サブ明細項目型.Detailcnt2.ToString, GetType(String)))
        End With

        CreateAddRow(サブ明細入力部)

        サブ明細表示部 = サブ明細入力部.Copy
        サブ明細情報 = サブ明細入力部.Copy

    End Sub
    'A-CUST20241219↑

    Private Sub InitializeDataTableフッター部()
        With フッター部.Columns
            .Clear()
            .Add(New DataColumn(退避情報型.フッター項目型.倉庫別現在庫.ToString, GetType(Decimal)))
            .Add(New DataColumn(退避情報型.フッター項目型.全社現在庫.ToString, GetType(Decimal)))
            .Add(New DataColumn(退避情報型.フッター項目型.対象金額.ToString, GetType(Decimal)))
            .Add(New DataColumn(退避情報型.フッター項目型.消費税額.ToString, GetType(Decimal)))
            .Add(New DataColumn(退避情報型.フッター項目型.合計金額.ToString, GetType(Decimal)))
            .Add(New DataColumn(退避情報型.フッター項目型.備考名.ToString, GetType(String)))
            .Add(New DataColumn(退避情報型.フッター項目型.消費税用_税抜_金額合計.ToString, GetType(Decimal)))
            .Add(New DataColumn(退避情報型.フッター項目型.消費税用_税込_分解消費税計.ToString, GetType(Decimal)))
            .Add(New DataColumn(退避情報型.フッター項目型.粗利額合計.ToString, GetType(Decimal)))
            .Add(New DataColumn(退避情報型.フッター項目型.粗利率.ToString, GetType(Decimal)))
            .Add(New DataColumn(退避情報型.フッター項目型.粗利用_税抜_金額合計.ToString, GetType(Decimal)))
            .Add(New DataColumn(退避情報型.フッター項目型.更新用_非課税額.ToString, GetType(Decimal)))
        End With

        CreateAddRow(フッター部)

    End Sub

    Private Sub InitializeDataTable見積書情報()

        SetDataTableProperty(見積書情報)

    End Sub

    Private Sub InitializeDataTable連番管理()

        With 連番管理.Columns
            .Clear()
            .Add(New DataColumn("CUSCE21008", GetType(Long)))
        End With

        CreateAddRow(連番管理)

    End Sub

    Private Sub InitializeDataTable見積伝票()

        Dim Data As DataTable = GetEmptyDataTable(IDenpyouReader.テーブル一覧型.見積伝票).Copy

        SetDataTableProperty(Data)

        For index As Integer = 0 To Data.Columns.Count - 1

            Dim dataType As System.Type = Data.Columns(index).DataType
            Dim columnName As String = Data.Columns(index).ColumnName
            Dim removeName As String = RemoveAliasName(columnName)

            Select Case Strings.Left(columnName, 1)
                Case "H"
                    If Strings.InStr(columnName, "CUSRE11") > 0 Then
                        見積ヘッダー.Columns.Add(New DataColumn(removeName, dataType))
                    End If

                    If Strings.InStr(columnName, "CUSME01") > 0 Then
                        得意先.Columns.Add(New DataColumn(removeName, dataType))
                    End If

                    If Strings.InStr(columnName, "CUSME04") > 0 Then
                        担当者.Columns.Add(New DataColumn(removeName, dataType))
                    End If

                    If Strings.InStr(columnName, "CUSME05") > 0 Then
                        部門.Columns.Add(New DataColumn(removeName, dataType))
                    End If

                    If Strings.InStr(columnName, "S_CUSCE03") > 0 Then
                        消費税.Columns.Add(New DataColumn(removeName, dataType))
                    End If

                    'A-CUST20201013↓
                    If Strings.InStr(columnName, "CUSME37") > 0 Then
                        納品先.Columns.Add(New DataColumn(removeName, dataType))
                    End If
                    'A-CUST20201013↑

                    'A-CUST20251104↓
                    If Strings.InStr(columnName, "CUSRE11K") > 0 Then
                        FieldBuilderヘッダー.Columns.Add(New DataColumn(removeName, dataType))
                    End If
                    'A-CUST20251104↑


                Case "M"
                    If Strings.InStr(columnName, "CUSRE12") > 0 Then
                        見積明細.Columns.Add(New DataColumn(removeName, dataType))
                    End If

                    If Strings.InStr(columnName, "CUSME03") > 0 Then
                        商品.Columns.Add(New DataColumn(removeName, dataType))
                    End If

                    If Strings.InStr(columnName, "CUSME06") > 0 Then
                        倉庫.Columns.Add(New DataColumn(removeName, dataType))
                    End If

                    If Strings.InStr(columnName, "K_CUSCE03") > 0 Then
                        課税区分.Columns.Add(New DataColumn(removeName, dataType))
                    End If

                    If Strings.InStr(columnName, "G_CUSCE03") > 0 Then
                        '区分.Columns.Add(New DataColumn(removeName, dataType))       'D-CUST20200311 '-2020527-001
                        行区分.Columns.Add(New DataColumn(removeName, dataType))      'A-CUST20200311 '-2020527-001 
                    End If

                    'A-CUST20251104↓
                    If Strings.InStr(columnName, "CUSRE12K") > 0 Then
                        FieldBuilder明細.Columns.Add(New DataColumn(removeName, dataType))
                    End If
                    'A-CUST20251104↑
            End Select
        Next

        'マスター情報一括退避用
        With 見積ヘッダー
            .Columns.Add(New DataColumn("CUSME01DT", GetType(DataTable)))
            .Columns.Add(New DataColumn("CUSME04DT", GetType(DataTable)))
            .Columns.Add(New DataColumn("CUSME05DT", GetType(DataTable)))
            .Columns.Add(New DataColumn("CUSME37DT", GetType(DataTable)))  'A-CUST20201013
            .Columns.Add(New DataColumn("CUSCE03SDT", GetType(DataTable)))
        End With

        With 見積明細
            .Columns.Add(New DataColumn("CUSME03DT", GetType(DataTable)))
            .Columns.Add(New DataColumn("CUSME06DT", GetType(DataTable)))
            .Columns.Add(New DataColumn("CUSCE03GDT", GetType(DataTable)))
            .Columns.Add(New DataColumn("CUSCE03KDT", GetType(DataTable)))
            .Columns.Add(New DataColumn("CUSRE29DT", GetType(DataTable)))  'A-CUST20241219
        End With

        CreateAddRow(見積ヘッダー)
        CreateAddRow(見積明細)

        CreateAddRow(得意先)
        CreateAddRow(担当者)
        CreateAddRow(部門)
        CreateAddRow(納品先)  'A-CUST20201013
        CreateAddRow(消費税)
        CreateAddRow(商品)
        CreateAddRow(倉庫)
        'CreateAddRow(区分)       'D-CUST20200311 '-2020527-001
        CreateAddRow(行区分)      'A-CUST20200311 '-2020527-001
        CreateAddRow(課税区分)

        'A-CUST20251104↓
        CreateAddRow(FieldBuilderヘッダー)
        CreateAddRow(FieldBuilder明細)
        'A-CUST20251104↑

    End Sub

    'A-CUST20241219↓
    Private Sub InitializeDataTable見積サブ明細()

        Dim mitSubData As DataTable = GetEmptyDataTable(IDenpyouReader.テーブル一覧型.見積サブ明細).Copy

        SetDataTableProperty(mitSubData)

        For index As Integer = 0 To mitSubData.Columns.Count - 1

            Dim dataType As System.Type = mitSubData.Columns(index).DataType
            Dim columnName As String = mitSubData.Columns(index).ColumnName
            Dim removeName As String = RemoveAliasName(columnName)

            If Strings.InStr(columnName, "MMITRE29") > 0 Then
                見積サブ明細.Columns.Add(New DataColumn(removeName, dataType))
            End If

        Next

        With 見積サブ明細
            .Columns.Add(New DataColumn("CUSME03DT", GetType(DataTable)))
        End With

    End Sub
    'A-CUST20241219↑

    ''' <summary>
    ''' DBより取得した項目名より別名を除く
    ''' </summary>
    ''' <param name="targetName"></param>
    ''' <returns></returns>
    ''' <remarks>最初に見つかった"_"より前を別名のとする。その文字以降を返す</remarks>
    Private Function RemoveAliasName(ByVal targetName As String) As String

        Dim startIndex As Integer = Strings.InStr(targetName, "_")
        Dim count As Integer = targetName.Length - startIndex

        Return targetName.Substring(startIndex, count)

    End Function

    ''' <summary>
    ''' データテーブルプロパティ設定
    ''' </summary>
    ''' <param name="targetDataTable"></param>
    ''' <remarks></remarks>
    Private Sub SetDataTableProperty(ByRef targetDataTable As DataTable)

        For i As Integer = 0 To targetDataTable.Columns.Count - 1
            targetDataTable.Columns.Item(i).AllowDBNull = True      'Null値の許可
            targetDataTable.Columns.Item(i).ReadOnly = False        '読込専用の解除
        Next

    End Sub

    Private Sub SetDefaultValue(ByRef targetDataTable As DataTable)

        For index As Integer = 0 To targetDataTable.Columns.Count - 1
            If targetDataTable.Columns(index).DataType Is GetType(String) Then
                targetDataTable.Rows(0).Item(index) = ""
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Integer) Then
                targetDataTable.Rows(0).Item(index) = 0
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Long) Then
                targetDataTable.Rows(0).Item(index) = 0
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Decimal) Then
                targetDataTable.Rows(0).Item(index) = 0
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Boolean) Then
                targetDataTable.Rows(0).Item(index) = False
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Date) Then
                targetDataTable.Rows(0).Item(index) = 0
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Object) Then
                targetDataTable.Rows(0).Item(index) = Nothing
            End If
            If targetDataTable.Columns(index).DataType Is GetType(DataTable) Then
                targetDataTable.Rows(0).Item(index) = New DataTable
            End If
            If targetDataTable.Columns(index).DataType Is GetType(IDictionary) Then
                targetDataTable.Rows(0).Item(index) = Nothing
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Short) Then
                targetDataTable.Rows(0).Item(index) = 0
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Single) Then
                targetDataTable.Rows(0).Item(index) = 0
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Double) Then
                targetDataTable.Rows(0).Item(index) = 0
            End If
        Next

    End Sub

    Private Sub SetAddDefaultValue(ByRef targetDataTable As DataTable)

        For index As Integer = 0 To targetDataTable.Columns.Count - 1

            If targetDataTable.Columns(index).DataType Is GetType(String) Then
                targetDataTable.Columns(index).DefaultValue = ""
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Integer) Then
                targetDataTable.Columns(index).DefaultValue = 0
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Long) Then
                targetDataTable.Columns(index).DefaultValue = 0
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Decimal) Then
                targetDataTable.Columns(index).DefaultValue = 0
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Boolean) Then
                targetDataTable.Columns(index).DefaultValue = False
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Date) Then
                targetDataTable.Columns(index).DefaultValue = 0
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Object) Then
                targetDataTable.Columns(index).DefaultValue = Nothing
            End If
            If targetDataTable.Columns(index).DataType Is GetType(DataTable) Then
                targetDataTable.Columns(index).DefaultValue = New DataTable
            End If
            If targetDataTable.Columns(index).DataType Is GetType(IDictionary) Then
                targetDataTable.Columns(index).DefaultValue = Nothing
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Short) Then
                targetDataTable.Columns(index).DefaultValue = 0
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Single) Then
                targetDataTable.Columns(index).DefaultValue = 0
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Double) Then
                targetDataTable.Columns(index).DefaultValue = 0
            End If
        Next

    End Sub

    ''' <summary>
    ''' 後ろの空白をカット
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    ''' <remarks>Stringタイプのみ対象。以外はそのまま返す</remarks>
    Private Function trimEnd(ByVal value As Object) As Object

        If value.GetType Is GetType(String) Then
            Return CStr(value).TrimEnd
        End If

        Return value

    End Function

#End Region

End Class
