﻿Public Class FocusSwitch
    Inherits FocusSwitcher

    Public Overrides Function DoFocusMove(ByVal args As Foundation.FocusSwitch.CheckMethodArgs) As Boolean
        Dim moveResult As Boolean = False
        Dim checkResult As Boolean = False

        Dim nextControl As Control
        nextControl = args.移動先コントロール
        CurrentControl = args.移動元コントロール

        '実行フラグがFalseの場合、チェックを行わない。
        If EnableEventValue = False Then
            Return True
        End If

        '移動先と移動元が同一の場合、チェックなし、移動キャンセル
        If args.移動元コントロール Is args.移動先コントロール Then
            Return False
        End If

        'チェック前処理
        PreviousCheck(args)

        '移動元コントロールのチェック
        If args.移動方向 = CheckMethodArgs.移動方向型.前へ Then
            '前へ移動する場合はチェックしない                      
        Else
            If ActiveControlCheck(args) = False Then
                If args.失敗時動作 = CheckMethodArgs.失敗時動作型.移動する Then
                    If nextControl Is args.移動先コントロール = False Then
                        ControlOperationHelper.ShowCurrentTabPage(args.移動先コントロール)
                        CurrentControl = args.移動先コントロール
                        args.移動先コントロール.Focus()
                    End If
                    Return True
                End If
                SetSelectAll(args)
                Return False
            End If
        End If

        '移動元サブグループチェック
        If args.移動方向 = CheckMethodArgs.移動方向型.前へ Then
            '前へ移動する場合はチェックしない                      
        ElseIf args.移動元サブグループ番号 = 0 Then
            'サブグループ番号未設定はチェックしない                                                         
        ElseIf args.移動先サブグループ番号 = args.移動元サブグループ番号 Then
            'サブグループ番号が同一はチェックしない                                                         
        Else
            If ActiveSubGroupCheck(args) = False Then
                If args.失敗時動作 = CheckMethodArgs.失敗時動作型.移動する Then
                    If nextControl Is args.移動先コントロール = False Then
                        ControlOperationHelper.ShowCurrentTabPage(args.移動先コントロール)
                        CurrentControl = args.移動先コントロール
                        args.移動先コントロール.Focus()
                    End If
                    If args.移動元コントロール Is args.移動先コントロール = True Then
                        SetSelectAll(args)
                    End If
                    Return True
                End If
                SetSelectAll(args)
                Return False
            End If
        End If

        '移動元グループチェック
        If args.移動先グループ番号 = 1 And args.移動元グループ番号 = 2 Then
            'チェックしない                                                     
        ElseIf args.移動先グループ番号 <= 2 And args.移動元グループ番号 >= 3 Then
            'チェックしない                                                         
        ElseIf args.移動先グループ番号 = args.移動元グループ番号 Then
            'チェックしない                                                         
        Else
            If ActiveGroupCheck(args) = False Then
                If args.移動方向 = CheckMethodArgs.移動方向型.前へ Then
                    '前へ移動する場合は次処理へ                              
                    args.移動先コントロール = nextControl
                Else
                    If args.失敗時動作 = CheckMethodArgs.失敗時動作型.移動する Then
                        If nextControl Is args.移動先コントロール = False Then
                            ControlOperationHelper.ShowCurrentTabPage(args.移動先コントロール)
                            CurrentControl = args.移動先コントロール
                            args.移動先コントロール.Focus()
                        End If
                        Return True
                    End If
                    Return False
                End If
            End If
        End If

        '移動先サブグループチェック
        If args.移動元サブグループ番号 = 0 Then
            'サブグループ番号未設定はチェックしない                                                         
        ElseIf args.移動先サブグループ番号 = args.移動元サブグループ番号 Then
            'サブグループ番号が同一はチェックしない                                                         
        Else
            If NextSubGroupCheck(args) = False Then
                If args.失敗時動作 = CheckMethodArgs.失敗時動作型.移動する Then
                    If nextControl Is args.移動先コントロール = False Then
                        ControlOperationHelper.ShowCurrentTabPage(args.移動先コントロール)
                        CurrentControl = args.移動先コントロール
                        args.移動先コントロール.Focus()
                    End If
                    If args.移動元コントロール Is args.移動先コントロール = True Then
                        SetSelectAll(args)
                    End If
                    Return True
                End If
                Return False
            End If
        End If

        '移動先グループチェック
        If args.移動先グループ番号 = args.移動元グループ番号 Then
            'チェックしない                                                         
        Else
            If NextGroupCheck(args) = False Then
                If args.失敗時動作 = CheckMethodArgs.失敗時動作型.移動する Then
                    If nextControl Is args.移動先コントロール = False Then
                        ControlOperationHelper.ShowCurrentTabPage(args.移動先コントロール)
                        CurrentControl = args.移動先コントロール
                        args.移動先コントロール.Focus()
                    End If
                    Return True
                End If
                Return False
            End If
        End If

        '移動先コントロールのチェック
        If NextControlCheck(args) = False Then
            If args.失敗時動作 = CheckMethodArgs.失敗時動作型.移動する Then
                If nextControl Is args.移動先コントロール = False Then
                    ControlOperationHelper.ShowCurrentTabPage(args.移動先コントロール)
                    CurrentControl = args.移動先コントロール
                    args.移動先コントロール.Focus()
                End If
                Return True
            End If
            Return False
        End If

        'チェック完了後処理
        CheckAfter(args)

        CurrentControl = args.移動先コントロール
        If nextControl Is args.移動先コントロール = False Then
            ControlOperationHelper.ShowCurrentTabPage(args.移動先コントロール)
            args.移動先コントロール.Focus()
        End If

        Return True

    End Function

    Private Sub SetSelectAll(ByVal args As Foundation.FocusSwitch.CheckMethodArgs)

        Select Case True
            Case TypeOf args.移動元コントロール Is OSK.X1.Foundation.SimpleControl.InputNumerical
                CType(args.移動元コントロール, OSK.X1.Foundation.SimpleControl.InputNumerical).SelectAll()

            Case TypeOf args.移動元コントロール Is OSK.X1.Foundation.SimpleControl.InputText
                CType(args.移動元コントロール, OSK.X1.Foundation.SimpleControl.InputText).SelectAll()
                CType(args.移動元コントロール, OSK.X1.Foundation.SimpleControl.InputText).UpdateCaretPos(0)

        End Select

    End Sub

End Class
