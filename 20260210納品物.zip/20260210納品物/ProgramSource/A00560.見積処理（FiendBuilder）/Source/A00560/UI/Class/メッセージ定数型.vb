﻿Friend Class メッセージ定数型


    Friend Const MASSAGE_A01 As String = "消費税計算方法を変更します。"
    Friend Const MASSAGE_A02 As String = "受注引当済みの伝票です。"
    Friend Const MASSAGE_A03 As String = "入力値が不正です。"
    'Friend Const MASSAGE_A04 As String = MASSAGE_A02                                        'D-CUST20200311 '-20200609-001
    Friend Const MASSAGE_A04 As String = "受注引当済みの伝票です。処理を続行しますか？"      'A-CUST20200311 '-20200609-001
    Friend Const MASSAGE_A05 As String = "使用不可な区分です。"
    'Friend Const MASSAGE_A06 As String = "売上引当済みの伝票です。"                         'D-CUST20200311 '-20200609-001
    Friend Const MASSAGE_A06 As String = "売上引当済みの伝票です。処理を続行しますか？"      'A-CUST20200311 '-20200609-001
    'Friend Const MASSAGE_A07 As String = MASSAGE_A06                                        'D-CUST20200311 '-20200609-001
    Friend Const MASSAGE_A07 As String = "売上引当済みの伝票です。"                          'A-CUST20200311 '-20200609-001

End Class


