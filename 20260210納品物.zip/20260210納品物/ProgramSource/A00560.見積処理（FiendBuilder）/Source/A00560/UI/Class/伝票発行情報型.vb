﻿Public Class 伝票発行情報型

#Region "列挙"

    Friend Enum 条件型 As Integer
        伝票発行
        見積書情報
        PrintingController
    End Enum

    Friend Enum 結果型 As Integer
        伝票発行
    End Enum

#End Region

#Region "コンストラクタ"

    Public Sub New()

        _printingController = New OSK.X1.Printing.UserInterface.Controller

        _条件 = New Hashtable
        _結果 = New Hashtable

        _見積書情報 = New DataTable

    End Sub

#End Region

#Region "Initialize"

    Friend Sub Initialize()

        For Each keyName As String In [Enum].GetNames(GetType(結果型))
            If _結果.Contains(keyName) = False Then
                _結果.Add(keyName, Nothing)
            End If
        Next

    End Sub

#End Region

#Region "プロパティ"

    Private _条件 As IDictionary
    Friend Property 条件() As IDictionary
        Get
            Return _条件
        End Get
        Set(ByVal value As IDictionary)
            _条件 = value
        End Set
    End Property

    Private _結果 As IDictionary
    Friend Property 結果() As IDictionary
        Get
            Return _結果
        End Get
        Set(ByVal value As IDictionary)
            _結果 = value
        End Set
    End Property

#End Region

#Region "印刷関連"

    Private _printingController As OSK.X1.Printing.UserInterface.Controller
    Public Property PrintingController() As OSK.X1.Printing.UserInterface.Controller
        Get
            Return _printingController
        End Get
        Set(ByVal value As OSK.X1.Printing.UserInterface.Controller)
            _printingController = value
        End Set
    End Property

    Private _見積書情報 As DataTable
    Friend Property 見積書情報() As DataTable
        Get
            Return _見積書情報
        End Get
        Set(ByVal value As DataTable)
            _見積書情報 = value.Copy
        End Set
    End Property
    Friend Property 見積書情報項目(ByVal rowIndex As Integer, ByVal columnName As String) As Object
        Get
            Return trimEnd(_見積書情報.Rows(rowIndex).Item(columnName))
        End Get
        Set(ByVal value As Object)
            _見積書情報.Rows(rowIndex).Item(columnName) = value
        End Set
    End Property

#End Region

#Region "内部メソッド"

    ''' <summary>
    ''' DataRow生成
    ''' </summary>
    ''' <param name="targetDataTable"></param>
    ''' <remarks></remarks>
    Friend Sub CreateAddRow(ByRef targetDataTable As DataTable)
        SetAddDefaultValue(targetDataTable)
        targetDataTable.Rows.Add(targetDataTable.NewRow)
    End Sub

    ''' <summary>
    ''' 型に該当する初期値を設定
    ''' </summary>
    ''' <param name="targetDataTable"></param>
    ''' <remarks></remarks>
    Private Sub SetAddDefaultValue(ByRef targetDataTable As DataTable)

        For index As Integer = 0 To targetDataTable.Columns.Count - 1
            If targetDataTable.Columns(index).DataType Is GetType(String) Then
                targetDataTable.Columns(index).DefaultValue = ""
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Integer) Then
                targetDataTable.Columns(index).DefaultValue = 0
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Long) Then
                targetDataTable.Columns(index).DefaultValue = 0
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Decimal) Then
                targetDataTable.Columns(index).DefaultValue = 0
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Boolean) Then
                targetDataTable.Columns(index).DefaultValue = False
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Date) Then
                targetDataTable.Columns(index).DefaultValue = 0
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Object) Then
                targetDataTable.Columns(index).DefaultValue = Nothing
            End If
            If targetDataTable.Columns(index).DataType Is GetType(DataTable) Then
                targetDataTable.Columns(index).DefaultValue = New DataTable
            End If
            If targetDataTable.Columns(index).DataType Is GetType(IDictionary) Then
                targetDataTable.Columns(index).DefaultValue = Nothing
            End If
        Next

    End Sub

    ''' <summary>
    ''' 後ろの空白をカット
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    ''' <remarks>Stringタイプのみ対象。以外はそのまま返す</remarks>
    Private Function trimEnd(ByVal value As Object) As Object

        If value.GetType Is GetType(String) Then
            Return CStr(value).TrimEnd
        End If

        Return value

    End Function

#End Region

End Class
