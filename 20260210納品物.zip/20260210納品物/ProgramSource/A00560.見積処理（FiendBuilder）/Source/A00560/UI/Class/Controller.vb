﻿Public Class Controller
    Inherits JobBase

    Private _entryForm As IEntryForm

    ''' <summary>
    ''' 起動処理
    ''' </summary>
    ''' <param name="paramInfo">パラメータ情報
    ''' 他のプログラムから呼ばれたときに何かしら値が入ってくるもの。</param>
    ''' <remarks></remarks>
    Public Overrides Sub Run(ByVal paramInfo As System.Collections.IDictionary)

        If _entryForm Is Nothing Then
            _entryForm = New EntryForm()
            _entryForm.Initialize(Me)
        End If
        _entryForm.ParamInfo = paramInfo
        _entryForm.SetUpForm()

    End Sub

End Class
