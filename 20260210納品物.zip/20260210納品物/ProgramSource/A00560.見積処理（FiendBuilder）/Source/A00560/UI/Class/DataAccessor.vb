﻿Public Class DataAccessor
    Inherits InsideJobBase

    Private _masterReader As IMasterReader
    Private _denpyouReader As IDenpyouReader
    Private _denpyouUpdater As IDenpyouUpdater

#Region "プロパティ"

    Private _endFlag As Boolean
    Public ReadOnly Property EndFlag() As Boolean
        Get
            Return _endFlag
        End Get
    End Property

#End Region

#Region "メソッド"

    ''' <summary>
    ''' データアクセスのインスタンスを設定する（マスターデータ取得用）
    ''' </summary>
    ''' <typeparam name="T"></typeparam>
    ''' <param name="dataAccessor">データアクセス</param>
    ''' <remarks></remarks>
    Friend Sub SetupMasterReader(Of T)(ByVal dataAccessor As T)
        _masterReader = CType(dataAccessor, IMasterReader)
        _endFlag = False
    End Sub

    ''' <summary>
    ''' データアクセスのインスタンスを設定する（伝票データ取得用）
    ''' </summary>
    ''' <typeparam name="T"></typeparam>
    ''' <param name="dataAccessor">データアクセス</param>
    ''' <remarks></remarks>
    Friend Sub SetupDenpyouReader(Of T)(ByVal dataAccessor As T)
        _denpyouReader = CType(dataAccessor, IDenpyouReader)
        _endFlag = False
    End Sub

    ''' <summary>
    ''' データアクセスのインスタンスを設定する（伝票データ更新用）
    ''' </summary>
    ''' <typeparam name="T"></typeparam>
    ''' <param name="dataAccessor">データアクセス</param>
    ''' <remarks></remarks>
    Friend Sub SetupDenpyouUpdater(Of T)(ByVal dataAccessor As T)
        _denpyouUpdater = CType(dataAccessor, IDenpyouUpdater)
        _endFlag = False
    End Sub

    ''' <summary>
    ''' マスター系データを取得する
    ''' </summary>
    ''' <param name="targetMaster">対象伝票種類</param>
    ''' <param name="readParam">読込パラメータ</param>
    ''' <param name="exDA"></param>
    ''' <returns>取得データ</returns>
    ''' <remarks></remarks>
    Friend Delegate Function GetMasterDataMethod(ByVal targetMaster As IMasterReader.テーブル一覧型, ByVal readParam As ReadParam, ByRef exDA As Exception) As System.Data.DataTable

    Friend Function GetMasterData(ByVal targetMaster As IMasterReader.テーブル一覧型, ByVal readParam As ReadParam, ByRef exDA As Exception) As System.Data.DataTable
        Try
            Dim dataTable As DataTable = _masterReader.MasterRead(targetMaster, readParam)
            Return dataTable
        Catch ex As Exception
            exDA = ex
            Return Nothing
        Finally
            _endFlag = True
        End Try
    End Function

    ''' <summary>
    ''' 伝票系データを取得する
    ''' </summary>
    ''' <param name="targetDenpyou">対象伝票種類</param>
    ''' <param name="readParam">読込パラメータ</param>
    ''' <param name="exDA"></param>
    ''' <returns>取得データ</returns>
    ''' <remarks></remarks>
    Friend Delegate Function GetDenpyouDataMethod(ByVal targetDenpyou As IDenpyouReader.テーブル一覧型, ByVal readParam As ReadParam, ByRef exDA As Exception) As System.Data.DataSet

    Friend Function GetDenpyouData(ByVal targetDenpyou As IDenpyouReader.テーブル一覧型, ByVal readParam As ReadParam, ByRef exDA As Exception) As System.Data.DataSet
        Try
            Dim dataSet As DataSet = _denpyouReader.DenpyouRead(targetDenpyou, readParam)
            Return dataSet
        Catch ex As Exception
            exDA = ex
            Return Nothing
        Finally
            _endFlag = True
        End Try
    End Function

    ''' <summary>
    ''' 伝票系データを更新する
    ''' </summary>
    ''' <param name="targetDenpyou">対象伝票種類</param>
    ''' <param name="updateParam">更新パラメータ</param>
    ''' <param name="exDA"></param>
    ''' <returns>取得データ</returns>
    ''' <remarks></remarks>
    Friend Delegate Function UpdateDenpyouDataMethod(ByVal targetDenpyou As IDenpyouUpdater.テーブル一覧型, ByVal mode As 処理区分型, ByVal updateParam As UpdateParam, ByRef exDA As Exception, ByRef executeCheckInfo As IExecuteCheckInfo) As IResult

    Friend Function UpdateDenpyouData(ByVal targetDenpyou As IDenpyouUpdater.テーブル一覧型, ByVal mode As 処理区分型, ByVal updateParam As UpdateParam, ByRef exDA As Exception, ByRef executeCheckInfo As IExecuteCheckInfo) As IResult
        Try
            Dim result As IResult = _denpyouUpdater.DenpyouUpdate(targetDenpyou, mode, updateParam, executeCheckInfo)
            Return result
        Catch ex As Exception
            exDA = ex
            Return Nothing
        Finally
            _endFlag = True
        End Try
    End Function

#End Region

End Class

