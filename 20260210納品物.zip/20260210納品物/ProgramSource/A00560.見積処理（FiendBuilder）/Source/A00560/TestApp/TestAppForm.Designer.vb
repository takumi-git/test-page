﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class TestAppForm
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.CommandButton1 = New OSK.X1.Foundation.SimpleControl.CommandButton()
        Me.CommandButton2 = New OSK.X1.Foundation.SimpleControl.CommandButton()
        Me.CommandButton3 = New OSK.X1.Foundation.SimpleControl.CommandButton()
        Me.CTI = New OSK.X1.Foundation.SimpleControl.CheckBox()
        Me.Panel1 = New OSK.X1.Foundation.SimpleControl.Panel(Me.components)
        Me.tokCode = New OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemName()
        Me.接続DB = New OSK.X1.Foundation.SmartControl.InputTextWithItemName.ComboBoxWithItemName()
        Me.業務管理者 = New OSK.X1.Foundation.SimpleControl.CheckBox()
        Me.画面表示 = New OSK.X1.Foundation.SimpleControl.CheckBox()
        Me.削除自動実行 = New OSK.X1.Foundation.SimpleControl.CheckBox()
        Me.ddRenban = New OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputNumericalWithItemName()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'CommandButton1
        '
        Me.CommandButton1.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.CommandButton1.FocusBackColor = System.Drawing.Color.Empty
        Me.CommandButton1.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.CommandButton1.Image = Nothing
        Me.CommandButton1.Location = New System.Drawing.Point(12, 37)
        Me.CommandButton1.Name = "CommandButton1"
        Me.CommandButton1.NextByEnterKey = False
        Me.CommandButton1.RemarkString = Nothing
        Me.CommandButton1.Size = New System.Drawing.Size(144, 34)
        Me.CommandButton1.TabIndex = 1
        Me.CommandButton1.Text = "スタンドアロン"
        Me.CommandButton1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'CommandButton2
        '
        Me.CommandButton2.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.CommandButton2.FocusBackColor = System.Drawing.Color.Empty
        Me.CommandButton2.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.CommandButton2.Image = Nothing
        Me.CommandButton2.Location = New System.Drawing.Point(12, 77)
        Me.CommandButton2.Name = "CommandButton2"
        Me.CommandButton2.NextByEnterKey = False
        Me.CommandButton2.RemarkString = Nothing
        Me.CommandButton2.Size = New System.Drawing.Size(144, 34)
        Me.CommandButton2.TabIndex = 2
        Me.CommandButton2.Text = "分散"
        Me.CommandButton2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'CommandButton3
        '
        Me.CommandButton3.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.CommandButton3.FocusBackColor = System.Drawing.Color.Empty
        Me.CommandButton3.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.CommandButton3.Image = Nothing
        Me.CommandButton3.Location = New System.Drawing.Point(12, 117)
        Me.CommandButton3.Name = "CommandButton3"
        Me.CommandButton3.NextByEnterKey = False
        Me.CommandButton3.RemarkString = Nothing
        Me.CommandButton3.Size = New System.Drawing.Size(144, 34)
        Me.CommandButton3.TabIndex = 3
        Me.CommandButton3.Text = "ドリルダウン"
        Me.CommandButton3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'CTI
        '
        Me.CTI.CheckState = System.Windows.Forms.CheckState.Unchecked
        Me.CTI.DrawFocusFrame = True
        Me.CTI.FocusBackColor = System.Drawing.Color.Empty
        Me.CTI.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.CTI.IndeterminateText = ""
        Me.CTI.Location = New System.Drawing.Point(12, 171)
        Me.CTI.Name = "CTI"
        Me.CTI.RemarkString = Nothing
        Me.CTI.Size = New System.Drawing.Size(71, 19)
        Me.CTI.TabIndex = 4
        Me.CTI.Text = "CTI連携"
        Me.CTI.UncheckedText = ""
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.tokCode)
        Me.Panel1.Location = New System.Drawing.Point(6, 182)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(159, 41)
        Me.Panel1.TabIndex = 5
        '
        'tokCode
        '
        Me.tokCode.AllowBottomPosition = True
        Me.tokCode.AutoResizeInputControl = True
        Me.tokCode.BackColor = System.Drawing.Color.Transparent
        Me.tokCode.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.tokCode.GroupNo = 0
        Me.tokCode.Indent = 0
        Me.tokCode.InnerSpace = 3
        Me.tokCode.InputAreaFont = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.tokCode.InputControlReadOnly = False
        Me.tokCode.InputControlSize = New System.Drawing.Size(88, 19)
        Me.tokCode.InputTextImeMode = OSK.X1.Foundation.Controls.InputText.ImeModeType.NoControl
        Me.tokCode.InputType = OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemName.InputTypeList.全文字入力可
        Me.tokCode.ItemName = "得意先"
        Me.tokCode.ItemNameAreaHeight = 19
        Me.tokCode.ItemNameAreaWidth = 50
        Me.tokCode.ItemNameBorderColor = System.Drawing.SystemColors.Window
        Me.tokCode.ItemNameBorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.tokCode.ItemNameFont = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.tokCode.ItemNameTextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Equal
        Me.tokCode.Location = New System.Drawing.Point(9, 12)
        Me.tokCode.MaxLength = 11
        Me.tokCode.MaxLengthMode = OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CharCount
        Me.tokCode.Name = "tokCode"
        Me.tokCode.RemarkString = Nothing
        Me.tokCode.Size = New System.Drawing.Size(141, 19)
        Me.tokCode.SubGroupNo = 0
        Me.tokCode.TabIndex = 6
        Me.tokCode.TextValue = "12345678901"
        Me.tokCode.ZeroFill = False
        Me.tokCode.ZeroFillAlways = False
        '
        '接続DB
        '
        Me.接続DB.AllowBottomPosition = True
        Me.接続DB.AutoResizeInputControl = False
        Me.接続DB.BackColor = System.Drawing.Color.Transparent
        Me.接続DB.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.接続DB.GroupNo = 0
        Me.接続DB.Indent = 0
        Me.接続DB.InnerSpace = 3
        Me.接続DB.InputAreaFont = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.接続DB.InputControlReadOnly = False
        Me.接続DB.InputControlSize = New System.Drawing.Size(94, 19)
        Me.接続DB.ItemName = "接続DB"
        Me.接続DB.ItemNameAreaHeight = 19
        Me.接続DB.ItemNameAreaWidth = 60
        Me.接続DB.ItemNameBorderColor = System.Drawing.SystemColors.Window
        Me.接続DB.ItemNameBorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.接続DB.ItemNameFont = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.接続DB.ItemNameTextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Equal
        Me.接続DB.Location = New System.Drawing.Point(6, 12)
        Me.接続DB.Name = "接続DB"
        Me.接続DB.RemarkString = Nothing
        Me.接続DB.Size = New System.Drawing.Size(157, 19)
        Me.接続DB.SubGroupNo = 0
        Me.接続DB.TabIndex = 0
        Me.接続DB.表示スタイル = OSK.X1.Foundation.Controls.Combo.Common.Control.StyleType.DropDownList
        Me.接続DB.表示項目数 = 0
        Me.接続DB.表示項目番号 = -1
        '
        '業務管理者
        '
        Me.業務管理者.CheckState = System.Windows.Forms.CheckState.Checked
        Me.業務管理者.DrawFocusFrame = True
        Me.業務管理者.FocusBackColor = System.Drawing.Color.Empty
        Me.業務管理者.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.業務管理者.IndeterminateText = ""
        Me.業務管理者.Location = New System.Drawing.Point(6, 229)
        Me.業務管理者.Name = "業務管理者"
        Me.業務管理者.RemarkString = Nothing
        Me.業務管理者.Size = New System.Drawing.Size(150, 19)
        Me.業務管理者.TabIndex = 7
        Me.業務管理者.Text = "業務管理者"
        Me.業務管理者.UncheckedText = ""
        '
        '画面表示
        '
        Me.画面表示.CheckState = System.Windows.Forms.CheckState.Unchecked
        Me.画面表示.DrawFocusFrame = True
        Me.画面表示.FocusBackColor = System.Drawing.Color.Empty
        Me.画面表示.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.画面表示.IndeterminateText = ""
        Me.画面表示.Location = New System.Drawing.Point(6, 300)
        Me.画面表示.Name = "画面表示"
        Me.画面表示.RemarkString = Nothing
        Me.画面表示.Size = New System.Drawing.Size(181, 19)
        Me.画面表示.TabIndex = 20
        Me.画面表示.Text = "削除自動実行 - 画面表示"
        Me.画面表示.UncheckedText = ""
        '
        '削除自動実行
        '
        Me.削除自動実行.CheckState = System.Windows.Forms.CheckState.Unchecked
        Me.削除自動実行.DrawFocusFrame = True
        Me.削除自動実行.FocusBackColor = System.Drawing.Color.Empty
        Me.削除自動実行.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.削除自動実行.IndeterminateText = ""
        Me.削除自動実行.Location = New System.Drawing.Point(6, 279)
        Me.削除自動実行.Name = "削除自動実行"
        Me.削除自動実行.RemarkString = Nothing
        Me.削除自動実行.Size = New System.Drawing.Size(150, 19)
        Me.削除自動実行.TabIndex = 19
        Me.削除自動実行.Text = "削除自動実行"
        Me.削除自動実行.UncheckedText = ""
        '
        'ddRenban
        '
        Me.ddRenban.AllowBottomPosition = True
        Me.ddRenban.AutoResizeInputControl = True
        Me.ddRenban.BackColor = System.Drawing.Color.Transparent
        Me.ddRenban.Font = New System.Drawing.Font("MS UI Gothic", 10.5!)
        Me.ddRenban.GroupNo = 2
        Me.ddRenban.Indent = 0
        Me.ddRenban.InnerSpace = 3
        Me.ddRenban.InputAreaFont = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.ddRenban.InputControlReadOnly = False
        Me.ddRenban.InputControlSize = New System.Drawing.Size(80, 19)
        Me.ddRenban.ItemName = "ドリルダウン連番"
        Me.ddRenban.ItemNameAreaHeight = 19
        Me.ddRenban.ItemNameAreaWidth = 100
        Me.ddRenban.ItemNameBorderColor = System.Drawing.SystemColors.Window
        Me.ddRenban.ItemNameBorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.ddRenban.ItemNameFont = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.ddRenban.ItemNameTextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Equal
        Me.ddRenban.Location = New System.Drawing.Point(6, 254)
        Me.ddRenban.Minus = "-"
        Me.ddRenban.Name = "ddRenban"
        Me.ddRenban.RemarkString = Nothing
        Me.ddRenban.Size = New System.Drawing.Size(183, 19)
        Me.ddRenban.SubGroupNo = 0
        Me.ddRenban.TabIndex = 18
        Me.ddRenban.Value = New Decimal(New Integer() {0, 0, 0, 0})
        Me.ddRenban.カンマ表示 = False
        Me.ddRenban.スピンボタンの値 = Nothing
        Me.ddRenban.スピンボタンの表示 = False
        Me.ddRenban.ゼロ表示 = False
        Me.ddRenban.マイナス入力 = False
        Me.ddRenban.マイナス入力時の色 = System.Drawing.SystemColors.WindowText
        Me.ddRenban.小数桁数 = 0
        Me.ddRenban.整数桁数 = 10
        Me.ddRenban.最大値 = New Decimal(New Integer() {-469762049, -590869294, 5421010, 393216})
        Me.ddRenban.最小値 = New Decimal(New Integer() {-469762049, -590869294, 5421010, -2147090432})
        '
        'TestAppForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(194, 331)
        Me.Controls.Add(Me.画面表示)
        Me.Controls.Add(Me.削除自動実行)
        Me.Controls.Add(Me.ddRenban)
        Me.Controls.Add(Me.業務管理者)
        Me.Controls.Add(Me.接続DB)
        Me.Controls.Add(Me.CTI)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.CommandButton3)
        Me.Controls.Add(Me.CommandButton2)
        Me.Controls.Add(Me.CommandButton1)
        Me.Name = "TestAppForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents CommandButton1 As OSK.X1.Foundation.SimpleControl.CommandButton
    Friend WithEvents CommandButton2 As OSK.X1.Foundation.SimpleControl.CommandButton
    Friend WithEvents CommandButton3 As OSK.X1.Foundation.SimpleControl.CommandButton
    Friend WithEvents CTI As OSK.X1.Foundation.SimpleControl.CheckBox
    Friend WithEvents Panel1 As OSK.X1.Foundation.SimpleControl.Panel
    Friend WithEvents tokCode As OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemName
    Friend WithEvents 接続DB As OSK.X1.Foundation.SmartControl.InputTextWithItemName.ComboBoxWithItemName
    Friend WithEvents 業務管理者 As OSK.X1.Foundation.SimpleControl.CheckBox
    Friend WithEvents 画面表示 As SimpleControl.CheckBox
    Friend WithEvents 削除自動実行 As SimpleControl.CheckBox
    Friend WithEvents ddRenban As SmartControl.InputTextWithItemName.InputNumericalWithItemName
End Class
