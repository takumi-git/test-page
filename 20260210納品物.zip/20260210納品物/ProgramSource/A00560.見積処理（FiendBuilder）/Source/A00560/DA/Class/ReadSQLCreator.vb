﻿Public Class ReadSQLCreator
    Inherits InsideDataHandlerBase

    Private _readParam As ReadParam

    Private Const EXPANDITEMCOUNT As Integer = 30   'A-CUST20251104
    Public Overloads Sub Initialize(ByVal creator As OSK.X1.Foundation.DataAccess.IDataHandler, ByVal readParam As ReadParam)

        MyBase.Initialize(creator)

        If readParam Is Nothing Then Exit Sub

        _readParam = readParam

    End Sub

#Region "SQLの組立て"

    ''' <summary>
    ''' 商品マスター情報の取得
    ''' </summary>
    ''' <param name="paramInfo"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function MakeSQL商品マスター(ByRef paramInfo As ParamInfoList) As String

        Dim sql As New System.Text.StringBuilder

        sql.Append(" SELECT ")
        sql.Append(" " & SelectItem商品マスター())
        sql.Append("," & SelectItem区分マスター())
        sql.Append("," & SelectItem倉庫マスター())

        sql.Append(" FROM ")
        sql.Append(Me.ExchangeTableName("CUS98ME03SHOHIN ") & QueryWrapper.AddNoLock)

        sql.Append(" LEFT OUTER JOIN ")
        sql.Append(Me.ExchangeTableName("CUS98CE03KUBUN ") & " " & QueryWrapper.AddNoLock)
        sql.Append(" ON  " & "CUSCE03001 = '0060' ")
        If _readParam.Container(ReadParam.項目名型.区分コード) IsNot Nothing Then
            sql.Append(" AND " & "CUSCE03002 = " & GetParameter(パラメータ型.区分コード, paramInfo))
        Else
            sql.Append(" AND " & "CUSCE03002 = " & "CUSME03017")
        End If

        sql.Append(" LEFT OUTER JOIN ")
        sql.Append(Me.ExchangeTableName("CUS98ME06SOKO ") & " " & QueryWrapper.AddNoLock)
        sql.Append(" ON  " & "CUSME06001 = CUSME03019 ")

        sql.Append(" WHERE ")
        sql.Append(" CUSME03001 = " & GetParameter(パラメータ型.商品コード, paramInfo))

        sql.Append(QueryWrapper.AddUR())

        Return sql.ToString

    End Function

    ''' <summary>
    ''' 部門マスター情報の取得
    ''' </summary>
    ''' <param name="paramInfo"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function MakeSQL部門マスター(ByRef paramInfo As ParamInfoList) As String

        Dim sql As New System.Text.StringBuilder

        sql.Append(" SELECT ")
        sql.Append(" " & SelectItem部門マスター())

        sql.Append(" FROM ")
        sql.Append(Me.ExchangeTableName("CUS98ME05BUMON ") & QueryWrapper.AddNoLock)

        sql.Append(" WHERE ")
        sql.Append("   CUSME05001 = " & GetParameter(パラメータ型.部門コード, paramInfo))

        sql.Append(QueryWrapper.AddUR())

        Return sql.ToString

    End Function

    ''' <summary>
    ''' 区分マスター情報の取得
    ''' </summary>
    ''' <param name="paramInfo"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function MakeSQL区分マスター(ByRef paramInfo As ParamInfoList) As String

        Dim sql As New System.Text.StringBuilder

        sql.Append(" SELECT ")
        sql.Append(" " & SelectItem区分マスター())

        sql.Append(" FROM ")
        sql.Append(Me.ExchangeTableName("CUS98CE03KUBUN ") & QueryWrapper.AddNoLock)

        sql.Append(" WHERE ")
        sql.Append("     CUSCE03001 = " & GetParameter(パラメータ型.種別, paramInfo))
        sql.Append(" AND CUSCE03002 = " & GetParameter(パラメータ型.区分コード, paramInfo))

        sql.Append(QueryWrapper.AddUR())

        Return sql.ToString

    End Function

    ''' <summary>
    ''' 得意先マスター情報の取得
    ''' </summary>
    ''' <param name="paramInfo"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function MakeSQL得意先マスター(ByRef paramInfo As ParamInfoList) As String

        Dim sql As New System.Text.StringBuilder

        sql.Append(" SELECT ")
        sql.Append(" " & SelectItem得意先マスター())
        sql.Append("," & SelectItem担当者マスター())
        sql.Append("," & SelectItem部門マスター())
        sql.Append("," & SelectItem区分マスター())

        sql.Append(" FROM ")
        sql.Append(Me.ExchangeTableName("CUS98ME01TOKUI ") & " " & QueryWrapper.AddNoLock)

        sql.Append(" LEFT OUTER JOIN ")
        sql.Append(Me.ExchangeTableName("CUS98ME04TANTO ") & " " & QueryWrapper.AddNoLock)
        sql.Append(" ON " & "CUSME04001 = " & "CUSME01016")

        sql.Append(" LEFT OUTER JOIN ")
        sql.Append(Me.ExchangeTableName("CUS98ME05BUMON ") & " " & QueryWrapper.AddNoLock)
        sql.Append(" ON " & "CUSME05001 = " & "CUSME04005")

        sql.Append(" LEFT OUTER JOIN ")
        sql.Append(Me.ExchangeTableName("CUS98CE03KUBUN ") & " " & QueryWrapper.AddNoLock)
        sql.Append(" ON  " & "CUSCE03001 = '0030' ")
        sql.Append(" AND " & "CUSCE03002 = " & "CUSME01017")

        sql.Append(" WHERE ")
        sql.Append("       " & "CUSME01001 = " & GetParameter(パラメータ型.得意先コード, paramInfo))

        sql.Append(QueryWrapper.AddUR())

        Return sql.ToString

    End Function

    ''' <summary>
    ''' 担当者マスター情報の取得
    ''' </summary>
    ''' <param name="paramInfo"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function MakeSQL担当者マスター(ByRef paramInfo As ParamInfoList) As String

        Dim sql As New System.Text.StringBuilder

        sql.Append(" SELECT ")
        sql.Append(" " & SelectItem担当者マスター())
        sql.Append("," & SelectItem部門マスター())

        sql.Append(" FROM ")
        sql.Append(Me.ExchangeTableName("CUS98ME04TANTO ") & " " & QueryWrapper.AddNoLock)

        sql.Append(" LEFT OUTER JOIN ")
        sql.Append(Me.ExchangeTableName("CUS98ME05BUMON ") & " " & QueryWrapper.AddNoLock)
        sql.Append(" ON " & "CUSME05001 = " & "CUSME04005")

        sql.Append(" WHERE ")
        sql.Append("       " & "CUSME04001 = " & GetParameter(パラメータ型.担当者コード, paramInfo))

        sql.Append(QueryWrapper.AddUR())

        Return sql.ToString

    End Function

    'A-CUST20201013↓
    ''' <summary>
    ''' 納品先マスター情報の取得
    ''' </summary>
    ''' <param name="paramInfo"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function MakeSQL納品先マスター(ByRef paramInfo As ParamInfoList) As String

        Dim sql As New System.Text.StringBuilder

        sql.Append(" SELECT ")
        sql.Append(" " & SelectItem納品先マスター())

        sql.Append(" FROM ")
        sql.Append(Me.ExchangeTableName("CUS98ME37NOHIN ") & QueryWrapper.AddNoLock)

        sql.Append(" WHERE ")
        sql.Append("     CUSME37001 = " & GetParameter(パラメータ型.得意先コード, paramInfo))
        sql.Append(" AND CUSME37002 = " & GetParameter(パラメータ型.納品先コード, paramInfo))

        sql.Append(QueryWrapper.AddUR())

        Return sql.ToString

    End Function
    'A-CUST20201013↑

    ''' <summary>
    ''' 倉庫マスター情報の取得
    ''' </summary>
    ''' <param name="paramInfo"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function MakeSQL倉庫マスター(ByRef paramInfo As ParamInfoList) As String

        Dim sql As New System.Text.StringBuilder

        sql.Append(" SELECT ")
        sql.Append(" " & SelectItem倉庫マスター())

        sql.Append(" FROM ")
        sql.Append(Me.ExchangeTableName("CUS98ME06SOKO ") & QueryWrapper.AddNoLock)

        sql.Append(" WHERE ")
        sql.Append(" CUSME06001 = " & GetParameter(パラメータ型.倉庫コード, paramInfo))

        sql.Append(QueryWrapper.AddUR())

        Return sql.ToString

    End Function

    ''' <summary>
    ''' 発行済管理テーブル情報の取得
    ''' </summary>
    ''' <param name="paramInfo"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function MakeSQL発行済管理テーブル(ByRef paramInfo As ParamInfoList) As String

        Dim sql As New System.Text.StringBuilder

        sql.Append(" SELECT ")
        sql.Append(" " & SelectItem発行済管理テーブル())

        sql.Append(" FROM ")
        sql.Append(Me.ExchangeTableName("CUS98RE91HAKKOU ") & QueryWrapper.AddNoLock)

        sql.Append(" WHERE ")
        sql.Append("       CUSRE91001 = 30 ")               'プログラム区分 ＝ 30｛見積書｝
        sql.Append(" AND   CUSRE91002 = 1 ")                '伝票区分 ＝ 1｛見積｝
        sql.Append(" AND   CUSRE91003 = " & GetParameter(パラメータ型.伝票番号, paramInfo))

        sql.Append(QueryWrapper.AddUR())

        Return sql.ToString

    End Function

    ''' <summary>
    ''' 倉庫別現在庫情報の取得
    ''' </summary>
    ''' <param name="paramInfo"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function MakeSQL倉庫別現在庫(ByRef paramInfo As ParamInfoList) As String

        Dim sql As New System.Text.StringBuilder

        sql.Append(" SELECT ")
        sql.Append(" " & SelectItem倉庫マスター())

        sql.Append(" FROM ")
        sql.Append(Me.ExchangeTableName("CUS98ME06SOKO ") & QueryWrapper.AddNoLock)

        sql.Append(" WHERE ")
        sql.Append(" CUSME06001 = " & GetParameter(パラメータ型.倉庫コード, paramInfo))

        sql.Append(QueryWrapper.AddUR())

        Return sql.ToString

    End Function

    ''' <summary>
    ''' コントロールテーブルの取得
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function MakeSQLコントロールテーブル() As String

        Dim sql As New System.Text.StringBuilder

        sql.Append(" SELECT ")
        sql.Append(" " & SelectItemコントロールテーブル())

        sql.Append(" FROM ")
        sql.Append(" " & Me.ExchangeTableName("CUS98CE01CONTROL ") & QueryWrapper.AddNoLock)

        sql.Append(QueryWrapper.AddUR())

        Return sql.ToString

    End Function

    ''' <summary>
    ''' 日付管理テーブルの取得
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function MakeSQL日付管理テーブル() As String

        Dim sql As New System.Text.StringBuilder

        sql.Append(" SELECT ")
        sql.Append(" " & SelectItem日付管理テーブル())

        sql.Append(" FROM ")
        sql.Append(" " & Me.ExchangeTableName("CUS98CE11DATE ") & QueryWrapper.AddNoLock)

        sql.Append(QueryWrapper.AddUR())

        Return sql.ToString

    End Function

    ''' <summary>
    ''' 連番管理テーブルの取得
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function MakeSQL連番管理テーブル() As String

        Dim sql As New System.Text.StringBuilder

        sql.Append(" SELECT ")
        sql.Append(" " & SelectItem連番管理テーブル())

        sql.Append(" FROM ")
        sql.Append(" " & Me.ExchangeTableName("CUS98CE21RENBAN ") & QueryWrapper.AddNoLock)

        sql.Append(" WHERE ")
        sql.Append("     CUSCE21001 = '021'")

        sql.Append(QueryWrapper.AddUR())

        Return sql.ToString

    End Function

    ''' <summary>
    ''' 見積ヘッダー情報の取得
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function MakeSQL見積ヘッダー(ByRef paramInfo As ParamInfoList) As String

        Dim sql As New System.Text.StringBuilder

        sql.Append(" SELECT ")
        sql.Append(QueryWrapper.AddIndexHintOracle(GetIndexHint("SEL_A_1")))
        sql.Append(" " & SelectItem見積ヘッダーテーブル())
        sql.Append(" FROM ")
        'sql.Append(Me.ExchangeTableName("CUS98RE11MITSUMORIH ") & QueryWrapper.AddNoLock(GetIndexHint("RE01_A_1")))   'D-CUST20200311 '-20200527
        sql.Append(Me.ExchangeTableName("CUS98RE11MITSUMORIH ") & QueryWrapper.AddNoLock(GetIndexHint("RE11_A_1")))    'A-CUST20200311 '-20200527
        sql.Append(" WHERE ")
        sql.Append("     " & "CUSRE11001 = " & GetParameter(パラメータ型.伝票番号, paramInfo))
        sql.Append(QueryWrapper.AddUR())

        Return sql.ToString

    End Function

    ''' <summary>
    ''' 見積伝票情報の取得
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function MakeSQL見積伝票(ByRef paramInfo As ParamInfoList, ByVal 初回起動 As Boolean) As String

        Dim sql As New System.Text.StringBuilder
        Dim sqlRowNum As System.Text.StringBuilder

        Dim aliasHURIME01 As String = "HURIME01"
        Dim aliasHURIME04 As String = "HURIME04"
        Dim aliasHURIME05 As String = "HURIME05"
        Dim aliasHMITRE11 As String = "HMITRE11"
        Dim aliasHURICE03_S As String = "HURICE03S"     '消費税
        Dim aliasHMITME37 As String = "HURIME37"　　　　'A-CUST20201013

        Dim aliasMURIME03 As String = "MURIME03"
        Dim aliasMURIME06 As String = "MURIME06"
        Dim aliasMMITRE12 As String = "MMITRE12"
        Dim aliasMURICE03_G As String = "MURICE03G"     '行区分
        Dim aliasMURICE03_K As String = "MURICE03K"     '課税区分

        sql.Append(" SELECT * FROM ( ")
        sql.Append(" SELECT ")
        sql.Append(QueryWrapper.AddIndexHintOracle(GetIndexHint("SEL_B_1")))

        '--------------------
        '   取得項目定義
        '--------------------
        'ヘッダー情報
        sql.Append(" " & SelectItem見積ヘッダーテーブル(aliasHMITRE11))
        sql.Append("," & SelectItem得意先マスター(aliasHURIME01))
        sql.Append("," & SelectItem担当者マスター(aliasHURIME04))
        sql.Append("," & SelectItem部門マスター(aliasHURIME05))
        sql.Append("," & SelectItem区分マスター(aliasHURICE03_S))
        sql.Append("," & SelectItem納品先マスター(aliasHMITME37))　　　'A-CUST20201013

        '明細情報
        sql.Append("," & SelectItem見積明細テーブル(aliasMMITRE12))
        sql.Append("," & SelectItem商品マスター(aliasMURIME03))
        sql.Append("," & SelectItem倉庫マスター(aliasMURIME06))
        sql.Append("," & SelectItem区分マスター(aliasMURICE03_K))
        sql.Append("," & SelectItem区分マスター(aliasMURICE03_G))

        sqlRowNum = New System.Text.StringBuilder
        sqlRowNum.Append(",ROW_NUMBER() OVER( ")
        sqlRowNum.Append(" ORDER BY ")
        sqlRowNum.Append(" " & aliasHMITRE11 & ".CUSRE11001 ")
        Select Case CInt(_readParam.Container(ReadParam.項目名型.読込種別))
            Case ReadParam.読込種別型.前伝票, ReadParam.読込種別型.最終伝票
                sqlRowNum.Append(" DESC ")
        End Select
        sqlRowNum.Append("," & aliasMMITRE12 & ".CUSRE12003 ")
        sqlRowNum.Append(" ) RN ")

        sql.Append(QueryWrapper.AddSQLServerString(sqlRowNum.ToString))
        sql.Append(QueryWrapper.AddOracleString(sqlRowNum.ToString))

        '--------------------
        '   テーブル定義
        '--------------------
        '見積ヘッダー
        sql.Append(" FROM ")
        'sql.Append(Me.ExchangeTableName("CUS98RE11MITSUMORIH ") & aliasHMITRE11 & " " & QueryWrapper.AddNoLock(GetIndexHint("RE01_B_1")))        'D-CUST20200311 '-20200527
        sql.Append(Me.ExchangeTableName("CUS98RE11MITSUMORIH ") & aliasHMITRE11 & " " & QueryWrapper.AddNoLock(GetIndexHint("RE11_B_1")))         'A-CUST20200311 '-20200527

        '見積明細
        sql.Append(" INNER JOIN ")
        'sql.Append(Me.ExchangeTableName("CUS98RE12MITSUMORIM ") & aliasMMITRE12 & " " & QueryWrapper.AddNoLock(GetIndexHint("RE02_B_1")))        'D-CUST20200311 '-20200527
        sql.Append(Me.ExchangeTableName("CUS98RE12MITSUMORIM ") & aliasMMITRE12 & " " & QueryWrapper.AddNoLock(GetIndexHint("RE12_B_1")))         'A-CUST20200311 '-20200527
        sql.Append("  ON " & aliasMMITRE12 & ".CUSRE12001 = " & aliasHMITRE11 & ".CUSRE11001 ")
        sql.Append(" AND " & aliasMMITRE12 & ".CUSRE12002 = 0 ")

        '得意先マスター
        sql.Append(" LEFT OUTER JOIN ")
        sql.Append(Me.ExchangeTableName("CUS98ME01TOKUI ") & aliasHURIME01 & " " & QueryWrapper.AddNoLock)
        sql.Append("  ON " & aliasHURIME01 & ".CUSME01001 = " & aliasHMITRE11 & ".CUSRE11004 ")

        '担当者マスター
        sql.Append(" LEFT OUTER JOIN ")
        sql.Append(Me.ExchangeTableName("CUS98ME04TANTO ") & aliasHURIME04 & " " & QueryWrapper.AddNoLock)
        sql.Append("  ON " & aliasHURIME04 & ".CUSME04001 = " & aliasHMITRE11 & ".CUSRE11007 ")

        '部門マスター
        sql.Append(" LEFT OUTER JOIN ")
        sql.Append(Me.ExchangeTableName("CUS98ME05BUMON ") & aliasHURIME05 & " " & QueryWrapper.AddNoLock)
        sql.Append("  ON " & aliasHURIME05 & ".CUSME05001 = " & aliasHMITRE11 & ".CUSRE11008 ")


        '区分マスター（消費税）
        sql.Append(" LEFT OUTER JOIN ")
        sql.Append(Me.ExchangeTableName("CUS98CE03KUBUN ") & aliasHURICE03_S & " " & QueryWrapper.AddNoLock)
        sql.Append("  ON " & aliasHURICE03_S & ".CUSCE03002 = " & aliasHMITRE11 & ".CUSRE11013 ")
        sql.Append("  AND " & aliasHURICE03_S & ".CUSCE03001 = '0030' ")

        '商品マスター
        sql.Append(" LEFT OUTER JOIN ")
        sql.Append(Me.ExchangeTableName("CUS98ME03SHOHIN ") & aliasMURIME03 & QueryWrapper.AddNoLock)
        sql.Append(" ON " & aliasMURIME03 & ".CUSME03001 = " & aliasMMITRE12 & ".CUSRE12006")

        '倉庫マスター
        sql.Append(" LEFT OUTER JOIN ")
        sql.Append(Me.ExchangeTableName("CUS98ME06SOKO ") & aliasMURIME06 & QueryWrapper.AddNoLock)
        sql.Append(" ON " & aliasMURIME06 & ".CUSME06001 = " & aliasMMITRE12 & ".CUSRE12013")

        '区分マスター（区分）
        sql.Append(" LEFT OUTER JOIN ")
        sql.Append(Me.ExchangeTableName("CUS98CE03KUBUN ") & aliasMURICE03_G & " " & QueryWrapper.AddNoLock)
        sql.Append("  ON " & aliasMURICE03_G & ".CUSCE03002 = " & aliasMMITRE12 & ".CUSRE12005 ")
        sql.Append("  AND " & aliasMURICE03_G & ".CUSCE03001 = '0003' ")

        '区分マスター（課税区分）
        sql.Append(" LEFT OUTER JOIN ")
        sql.Append(Me.ExchangeTableName("CUS98CE03KUBUN ") & aliasMURICE03_K & " " & QueryWrapper.AddNoLock)
        sql.Append("  ON " & aliasMURICE03_K & ".CUSCE03002 = " & aliasMMITRE12 & ".CUSRE12014 ")
        sql.Append("  AND " & aliasMURICE03_K & ".CUSCE03001 = '0060' ")

        'A-CUST20201013↓
        '納品先マスター
        sql.Append(" LEFT OUTER JOIN ")
        sql.Append(Me.ExchangeTableName("CUS98ME37NOHIN ") & aliasHMITME37 & " " & QueryWrapper.AddNoLock)
        sql.Append("  ON " & aliasHMITME37 & ".CUSME37001 = " & aliasHMITRE11 & ".CUSRE11004 ")
        sql.Append(" AND " & aliasHMITME37 & ".CUSME37002 = " & aliasHMITRE11 & ".CUSRE11024 ")
        'A-CUST20201013↑

        '--------------------
        '   検索条件
        '--------------------
        sql.Append(" WHERE ")
        sql.Append("     " & aliasHMITRE11 & ".CUSRE11001 = " & GetParameter(パラメータ型.伝票番号, paramInfo))

        sql.Append(" ) SUBTBL ")
        sqlRowNum = New System.Text.StringBuilder
        sqlRowNum.Append(" WHERE SUBTBL.RN <= 300 ")

        sql.Append(QueryWrapper.AddSQLServerString(sqlRowNum.ToString))
        sql.Append(QueryWrapper.AddOracleString(sqlRowNum.ToString))

        '--------------------
        '   並び順
        '--------------------
        sql.Append(" ORDER BY ")
        sql.Append(" SUBTBL." & aliasHMITRE11 & "_CUSRE11001 ")

        Select Case CInt(_readParam.Container(ReadParam.項目名型.読込種別))
            Case ReadParam.読込種別型.前伝票, ReadParam.読込種別型.最終伝票
                sql.Append(" DESC ")
        End Select
        sql.Append(",SUBTBL." & aliasMMITRE12 & "_CUSRE12003 ")

        sql.Append(QueryWrapper.AddDB2String(" FETCH FIRST 300 ROWS ONLY OPTIMIZE FOR 300 ROWS "))

        sql.Append(QueryWrapper.AddUR())

        Return sql.ToString

    End Function

    ''' <summary>
    ''' 見積伝票情報の取得（次前最終伝票表示の連番絞込み）
    ''' </summary>
    ''' <param name="paramInfo"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function MakeSQL見積伝票_次前最終用連番取得(ByRef paramInfo As ParamInfoList) As String

        Dim sql As New System.Text.StringBuilder
        Dim sqlRowNum As System.Text.StringBuilder

        Dim aliasHMITRE11 As String = "HMITRE11"

        sql.Append(" SELECT * FROM ( ")
        sql.Append(" SELECT ")
        sql.Append(QueryWrapper.AddIndexHintOracle(GetIndexHint("SEL_C_1")))

        '--------------------
        '   取得項目定義
        '--------------------
        sql.Append(" " & ItemBuilder(aliasHMITRE11, "CUSRE11001", "", GetDefault(属性.数値)))                '伝票№

        sqlRowNum = New System.Text.StringBuilder
        sqlRowNum.Append(",ROW_NUMBER() OVER( ")
        sqlRowNum.Append(" ORDER BY ")
        sqlRowNum.Append(" " & aliasHMITRE11 & ".CUSRE11001 ")
        Select Case CInt(_readParam.Container(ReadParam.項目名型.読込種別))
            Case ReadParam.読込種別型.前伝票, ReadParam.読込種別型.最終伝票
                sqlRowNum.Append(" DESC ")
        End Select
        sqlRowNum.Append(" ) RN ")

        sql.Append(QueryWrapper.AddSQLServerString(sqlRowNum.ToString))
        sql.Append(QueryWrapper.AddOracleString(sqlRowNum.ToString))

        '--------------------
        '   テーブル定義
        '--------------------
        '取引ヘッダー
        sql.Append(" FROM ")
        'sql.Append(Me.ExchangeTableName("CUS98RE11MITSUMORIH ") & aliasHMITRE11 & QueryWrapper.AddNoLock(GetIndexHint("RE01_C_1")))           'D-CUST20200311 '-20200527
        sql.Append(Me.ExchangeTableName("CUS98RE11MITSUMORIH ") & aliasHMITRE11 & QueryWrapper.AddNoLock(GetIndexHint("RE11_C_1")))            'A-CUST20200311 '-20200527

        '--------------------
        '   検索条件
        '--------------------
        sql.Append(" WHERE ")
        Select Case CInt(_readParam.Container(ReadParam.項目名型.読込種別))
            Case ReadParam.読込種別型.次伝票
                sql.Append("   " & aliasHMITRE11 & ".CUSRE11001 >  " & GetParameter(パラメータ型.伝票番号, paramInfo))
            Case ReadParam.読込種別型.前伝票
                sql.Append("   " & aliasHMITRE11 & ".CUSRE11001 <  " & GetParameter(パラメータ型.伝票番号, paramInfo))
            Case ReadParam.読込種別型.最終伝票
                sql.Append("   " & aliasHMITRE11 & ".CUSRE11001 <= " & GetParameter(パラメータ型.伝票番号, paramInfo))
        End Select

        sql.Append(" ) SUBTBL ")
        sqlRowNum = New System.Text.StringBuilder
        sqlRowNum.Append(" WHERE SUBTBL.RN <= 1 ")

        sql.Append(QueryWrapper.AddSQLServerString(sqlRowNum.ToString))
        sql.Append(QueryWrapper.AddOracleString(sqlRowNum.ToString))

        '--------------------
        '   並び順
        '--------------------
        sql.Append(" ORDER BY ")
        sql.Append(" SUBTBL." & aliasHMITRE11 & "_CUSRE11001 ")
        Select Case CInt(_readParam.Container(ReadParam.項目名型.読込種別))
            Case ReadParam.読込種別型.前伝票, ReadParam.読込種別型.最終伝票
                sql.Append(" DESC ")
        End Select

        sql.Append(QueryWrapper.AddDB2String(" FETCH FIRST 1 ROWS ONLY OPTIMIZE FOR 1 ROWS "))

        sql.Append(QueryWrapper.AddUR())

        Return sql.ToString

    End Function


    'A-CUST20241219↓
    ''' <summary>
    ''' 見積伝票情報の取得（見積サブ明細情報）
    ''' </summary>
    ''' <param name="paramInfo"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function MakeSQL見積伝票_見積サブ明細情報(ByRef paramInfo As ParamInfoList) As String

        Dim sql As New System.Text.StringBuilder
        Dim aliasMMITRE29 As String = "MMITRE29"
        Dim aliasMURIME03 As String = "MURIME03"

        sql.Append(" SELECT ")
        sql.Append(QueryWrapper.AddIndexHintOracle(GetIndexHint("SEL_E_1")))

        sql.Append(" " & SelectItem見積サブ明細テーブル(aliasMMITRE29))
        sql.Append("," & SelectItem商品マスター(aliasMURIME03))

        '見積サブ明細
        sql.Append(" FROM ")
        sql.Append(Me.ExchangeTableName("CUS98RE29MITSUMORISUBM ") & aliasMMITRE29 & " " & QueryWrapper.AddNoLock(GetIndexHint("RE29_E_1")))

        '商品マスター
        sql.Append(" LEFT OUTER JOIN ")
        sql.Append(Me.ExchangeTableName("CUS98ME03SHOHIN ") & aliasMURIME03 & QueryWrapper.AddNoLock)
        sql.Append(" ON " & aliasMURIME03 & ".CUSME03001 = " & aliasMMITRE29 & ".CUSRE29004")

        sql.Append(" WHERE ")
        sql.Append("     " & aliasMMITRE29 & ".CUSRE29001 = " & GetParameter(パラメータ型.伝票番号, paramInfo))

        sql.Append(" ORDER BY ")
        sql.Append("  " & aliasMMITRE29 & ".CUSRE29002 ")
        sql.Append(" ," & aliasMMITRE29 & ".CUSRE29003 ")

        sql.Append(QueryWrapper.AddUR())

        Return sql.ToString

    End Function
    'A-CUST20241219↑

#End Region

#Region "各テーブル取得列名定義"

    ''' <summary>
    ''' 見積ヘッダーテーブル取得列名定義
    ''' </summary>
    ''' <param name="tableAlias"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function SelectItem見積ヘッダーテーブル(Optional ByVal tableAlias As String = "") As String

        Dim item As New System.Text.StringBuilder

        item.Append(" " & ItemBuilder(tableAlias, "CUSRE11001", "", GetDefault(属性.数値)))             '見積№
        item.Append("," & ItemBuilder(tableAlias, "CUSRE11002", "", GetDefault(属性.数値)))             '見積日付
        item.Append("," & ItemBuilder(tableAlias, "CUSRE11003", "", GetDefault(属性.数値)))             '消費税率
        item.Append("," & ItemBuilder(tableAlias, "CUSRE11004", "", GetDefault(属性.文字)))             '得意先コード
        item.Append("," & ItemBuilder(tableAlias, "CUSRE11005", "", GetDefault(属性.文字)))             '得意先名１
        item.Append("," & ItemBuilder(tableAlias, "CUSRE11006", "", GetDefault(属性.文字)))             '得意先名２
        item.Append("," & ItemBuilder(tableAlias, "CUSRE11007", "", GetDefault(属性.文字)))             '担当者コード
        item.Append("," & ItemBuilder(tableAlias, "CUSRE11008", "", GetDefault(属性.文字)))             '部門コード
        item.Append("," & ItemBuilder(tableAlias, "CUSRE11009", "", GetDefault(属性.文字)))             '納期
        item.Append("," & ItemBuilder(tableAlias, "CUSRE11010", "", GetDefault(属性.文字)))             '支払条件
        item.Append("," & ItemBuilder(tableAlias, "CUSRE11011", "", GetDefault(属性.文字)))             '有効期限
        item.Append("," & ItemBuilder(tableAlias, "CUSRE11012", "", GetDefault(属性.文字)))             '要件
        item.Append("," & ItemBuilder(tableAlias, "CUSRE11013", "", GetDefault(属性.文字)))             '消費税計算区分
        item.Append("," & ItemBuilder(tableAlias, "CUSRE11014", "", GetDefault(属性.文字)))             '備考
        item.Append("," & ItemBuilder(tableAlias, "CUSRE11015", "", GetDefault(属性.数値)))             '課税対象額
        item.Append("," & ItemBuilder(tableAlias, "CUSRE11016", "", GetDefault(属性.数値)))             '消費税額
        item.Append("," & ItemBuilder(tableAlias, "CUSRE11017", "", GetDefault(属性.数値)))             '粗利額
        item.Append("," & ItemBuilder(tableAlias, "CUSRE11018", "", GetDefault(属性.数値)))             '関連受注伝票枚数
        item.Append("," & ItemBuilder(tableAlias, "CUSRE11019", "", GetDefault(属性.数値)))             '関連売上伝票枚数
        item.Append("," & ItemBuilder(tableAlias, "CUSRE11020", "", GetDefault(属性.数値)))             '操作日付
        item.Append("," & ItemBuilder(tableAlias, "CUSRE11021", "", GetDefault(属性.文字)))             'ログインID
        item.Append("," & ItemBuilder(tableAlias, "CUSRE11022", "", GetDefault(属性.数値)))             '伝票行数
        item.Append("," & ItemBuilder(tableAlias, "CUSRE11023", "", GetDefault(属性.数値)))             '非課税額
        'D-CUST20220425↓
        'item.Append("," & ItemBuilder(tableAlias, "CUSRE11993", "", GetDefault(属性.文字)))             '登録プログラムID
        'item.Append("," & ItemBuilder(tableAlias, "CUSRE11994", "", GetDefault(属性.文字)))             '登録者
        'item.Append("," & ItemBuilder(tableAlias, "CUSRE11995", "", GetDefault(属性.数値)))             '登録日時
        'item.Append("," & ItemBuilder(tableAlias, "CUSRE11996", "", GetDefault(属性.文字)))             '最終更新プログラムID
        'item.Append("," & ItemBuilder(tableAlias, "CUSRE11997", "", GetDefault(属性.文字)))             '最終更新者
        'item.Append("," & ItemBuilder(tableAlias, "CUSRE11998", "", GetDefault(属性.数値)))             '最終更新日時
        'item.Append("," & ItemBuilder(tableAlias, "CUSRE11999", "", GetDefault(属性.数値)))             '更新番号
        'D-CUST20220425↑
        'A-CUST20220425↓
        item.Append("," & ItemBuilder(tableAlias, "CUSRE11991", "", GetDefault(属性.文字)))             '登録プログラムID
        item.Append("," & ItemBuilder(tableAlias, "CUSRE11992", "", GetDefault(属性.数値)))             '登録プログラムID枝番
        item.Append("," & ItemBuilder(tableAlias, "CUSRE11993", "", GetDefault(属性.文字)))             '登録者
        item.Append("," & ItemBuilder(tableAlias, "CUSRE11994", "", GetDefault(属性.文字)))             '最終更新プログラムID
        item.Append("," & ItemBuilder(tableAlias, "CUSRE11995", "", GetDefault(属性.数値)))             '最終更新プログラムID枝番
        item.Append("," & ItemBuilder(tableAlias, "CUSRE11996", "", GetDefault(属性.文字)))             '最終更新者
        item.Append("," & ItemBuilder(tableAlias, "CUSRE11999", "", GetDefault(属性.数値)))             '更新番号
        item.Append("," & ItemBuilder(tableAlias, "CUSRE11INS", "", GetDefault(属性.数値)))             '登録日時
        item.Append("," & ItemBuilder(tableAlias, "CUSRE11UPD", "", GetDefault(属性.数値)))             '最終更新日時
        'A-CUST20220425↑

        'A-CUST20201013↓
        item.Append("," & ItemBuilder(tableAlias, "CUSRE11024", "", GetDefault(属性.文字)))             '納品先コード
        'A-CUST20201013↑

        'A-CUST20251104↓
        For i As Integer = 1 To EXPANDITEMCOUNT
            item.Append("," & ItemBuilder(tableAlias, "CUSRE11K" & i.ToString("D3"), "", GetDefault(属性.文字)))　'FieldBuilderヘッダー項目
        Next
        'A-CUST20251104↑


        Return item.ToString

    End Function

    ''' <summary>
    ''' 見積明細テーブル取得列名定義
    ''' </summary>
    ''' <param name="tableAlias"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function SelectItem見積明細テーブル(Optional ByVal tableAlias As String = "") As String

        Dim item As New System.Text.StringBuilder

        item.Append(" " & ItemBuilder(tableAlias, "CUSRE12001", "", GetDefault(属性.数値)))             '見積№
        item.Append("," & ItemBuilder(tableAlias, "CUSRE12002", "", GetDefault(属性.数値)))             '明細区分
        item.Append("," & ItemBuilder(tableAlias, "CUSRE12003", "", GetDefault(属性.数値)))             '行№
        item.Append("," & ItemBuilder(tableAlias, "CUSRE12004", "", GetDefault(属性.数値)))             '見積日付
        item.Append("," & ItemBuilder(tableAlias, "CUSRE12005", "", GetDefault(属性.文字)))             '区分
        item.Append("," & ItemBuilder(tableAlias, "CUSRE12006", "", GetDefault(属性.文字)))             '商品コード
        item.Append("," & ItemBuilder(tableAlias, "CUSRE12007", "", GetDefault(属性.文字)))             '商品名
        item.Append("," & ItemBuilder(tableAlias, "CUSRE12008", "", GetDefault(属性.文字)))             '単位
        item.Append("," & ItemBuilder(tableAlias, "CUSRE12009", "", GetDefault(属性.数値)))             '数量
        item.Append("," & ItemBuilder(tableAlias, "CUSRE12010", "", GetDefault(属性.数値)))             '単価
        item.Append("," & ItemBuilder(tableAlias, "CUSRE12011", "", GetDefault(属性.数値)))             '金額
        item.Append("," & ItemBuilder(tableAlias, "CUSRE12012", "", GetDefault(属性.文字)))             '行摘要
        item.Append("," & ItemBuilder(tableAlias, "CUSRE12013", "", GetDefault(属性.文字)))             '倉庫コード
        item.Append("," & ItemBuilder(tableAlias, "CUSRE12014", "", GetDefault(属性.文字)))             '課税区分
        item.Append("," & ItemBuilder(tableAlias, "CUSRE12015", "", GetDefault(属性.文字)))             '消費税率分類
        item.Append("," & ItemBuilder(tableAlias, "CUSRE12016", "", GetDefault(属性.数値)))             '税率
        item.Append("," & ItemBuilder(tableAlias, "CUSRE12017", "", GetDefault(属性.数値)))             '課税対象額
        item.Append("," & ItemBuilder(tableAlias, "CUSRE12018", "", GetDefault(属性.数値)))             '消費税
        item.Append("," & ItemBuilder(tableAlias, "CUSRE12019", "", GetDefault(属性.数値)))             '売上属性
        item.Append("," & ItemBuilder(tableAlias, "CUSRE12020", "", GetDefault(属性.数値)))             '原単価
        item.Append("," & ItemBuilder(tableAlias, "CUSRE12021", "", GetDefault(属性.数値)))             '原価金額
        item.Append("," & ItemBuilder(tableAlias, "CUSRE12022", "", GetDefault(属性.数値)))             '粗利額
        item.Append("," & ItemBuilder(tableAlias, "CUSRE12023", "", GetDefault(属性.数値)))             '小計チェックフラグ
        item.Append("," & ItemBuilder(tableAlias, "CUSRE12024", "", GetDefault(属性.数値)))             '改頁チェックフラグ
        item.Append("," & ItemBuilder(tableAlias, "CUSRE12025", "", GetDefault(属性.数値)))             '関連受注伝票枚数
        item.Append("," & ItemBuilder(tableAlias, "CUSRE12026", "", GetDefault(属性.数値)))             '関連売上伝票枚数
        item.Append("," & ItemBuilder(tableAlias, "CUSRE12027", "", GetDefault(属性.数値)))             '単価計算方法     'A-CUST20211001
        'D-CUST20220425↓
        'item.Append("," & ItemBuilder(tableAlias, "CUSRE12993", "", GetDefault(属性.文字)))             '登録プログラムID
        'item.Append("," & ItemBuilder(tableAlias, "CUSRE12994", "", GetDefault(属性.文字)))             '登録者
        'item.Append("," & ItemBuilder(tableAlias, "CUSRE12995", "", GetDefault(属性.数値)))             '登録日時
        'item.Append("," & ItemBuilder(tableAlias, "CUSRE12996", "", GetDefault(属性.文字)))             '最終更新プログラムID
        'item.Append("," & ItemBuilder(tableAlias, "CUSRE12997", "", GetDefault(属性.文字)))             '最終更新者
        'item.Append("," & ItemBuilder(tableAlias, "CUSRE12998", "", GetDefault(属性.数値)))             '最終更新日時
        'item.Append("," & ItemBuilder(tableAlias, "CUSRE12999", "", GetDefault(属性.数値)))             '更新番号
        'D-CUST20220425↑
        'A-CUST20220425↓
        item.Append("," & ItemBuilder(tableAlias, "CUSRE12991", "", GetDefault(属性.文字)))             '登録プログラムID
        item.Append("," & ItemBuilder(tableAlias, "CUSRE12992", "", GetDefault(属性.数値)))             '登録プログラムID枝番
        item.Append("," & ItemBuilder(tableAlias, "CUSRE12993", "", GetDefault(属性.文字)))             '登録者
        item.Append("," & ItemBuilder(tableAlias, "CUSRE12994", "", GetDefault(属性.文字)))             '最終更新プログラムID
        item.Append("," & ItemBuilder(tableAlias, "CUSRE12995", "", GetDefault(属性.数値)))             '最終更新プログラムID枝番
        item.Append("," & ItemBuilder(tableAlias, "CUSRE12996", "", GetDefault(属性.文字)))             '最終更新者
        item.Append("," & ItemBuilder(tableAlias, "CUSRE12999", "", GetDefault(属性.数値)))             '更新番号
        item.Append("," & ItemBuilder(tableAlias, "CUSRE12INS", "", GetDefault(属性.数値)))             '登録日時
        item.Append("," & ItemBuilder(tableAlias, "CUSRE12UPD", "", GetDefault(属性.数値)))             '最終更新日時
        'A-CUST20220425↑

        'A-CUST20251104↓
        For i As Integer = 1 To EXPANDITEMCOUNT
            item.Append("," & ItemBuilder(tableAlias, "CUSRE12K" & i.ToString("D3"), "", GetDefault(属性.文字)))  'FieldBuilder明細項目
        Next
        'A-CUST20251104↑

        Return item.ToString

    End Function

    ''' <summary>
    ''' 得意先マスター取得列名定義
    ''' </summary>
    ''' <param name="tableAlias"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function SelectItem得意先マスター(Optional ByVal tableAlias As String = "") As String

        Dim item As New System.Text.StringBuilder

        item.Append(" " & ItemBuilder(tableAlias, "CUSME01001", "", GetDefault(属性.文字)))             '得意先コード
        item.Append("," & ItemBuilder(tableAlias, "CUSME01002", "", GetDefault(属性.文字)))             '得意先名１
        item.Append("," & ItemBuilder(tableAlias, "CUSME01003", "", GetDefault(属性.文字)))             '得意先名２
        item.Append("," & ItemBuilder(tableAlias, "CUSME01004", "", GetDefault(属性.文字)))             '得意先略称
        item.Append("," & ItemBuilder(tableAlias, "CUSME01005", "", GetDefault(属性.文字)))             '索引
        item.Append("," & ItemBuilder(tableAlias, "CUSME01006", "", GetDefault(属性.文字)))             '郵便番号
        item.Append("," & ItemBuilder(tableAlias, "CUSME01007", "", GetDefault(属性.文字)))             '住所１
        item.Append("," & ItemBuilder(tableAlias, "CUSME01008", "", GetDefault(属性.文字)))             '住所２
        item.Append("," & ItemBuilder(tableAlias, "CUSME01009", "", GetDefault(属性.文字)))             '住所３
        item.Append("," & ItemBuilder(tableAlias, "CUSME01010", "", GetDefault(属性.文字)))             '電話番号
        item.Append("," & ItemBuilder(tableAlias, "CUSME01011", "", GetDefault(属性.文字)))             'ＦＡＸ番号
        item.Append("," & ItemBuilder(tableAlias, "CUSME01012", "", GetDefault(属性.数値)))             '締日
        item.Append("," & ItemBuilder(tableAlias, "CUSME01013", "", GetDefault(属性.文字)))             '入金サイクル
        item.Append("," & ItemBuilder(tableAlias, "CUSME01014", "", GetDefault(属性.数値)))             '入金日
        item.Append("," & ItemBuilder(tableAlias, "CUSME01015", "", GetDefault(属性.文字)))             '入金条件
        item.Append("," & ItemBuilder(tableAlias, "CUSME01016", "", GetDefault(属性.文字)))             '担当者コード
        item.Append("," & ItemBuilder(tableAlias, "CUSME01017", "", GetDefault(属性.文字)))             '消費税計算区分
        item.Append("," & ItemBuilder(tableAlias, "CUSME01018", "", GetDefault(属性.文字)))             '金額端数処理
        item.Append("," & ItemBuilder(tableAlias, "CUSME01019", "", GetDefault(属性.文字)))             '課税対象区分
        item.Append("," & ItemBuilder(tableAlias, "CUSME01020", "", GetDefault(属性.数値)))             '期首売掛残高
        item.Append("," & ItemBuilder(tableAlias, "CUSME01021", "", GetDefault(属性.数値)))             '前回請求残高
        'D-CUST20220425↓
        'item.Append("," & ItemBuilder(tableAlias, "CUSME01993", "", GetDefault(属性.文字)))             '登録プログラムID
        'item.Append("," & ItemBuilder(tableAlias, "CUSME01994", "", GetDefault(属性.文字)))             '登録者
        'item.Append("," & ItemBuilder(tableAlias, "CUSME01995", "", GetDefault(属性.数値)))             '登録日時
        'item.Append("," & ItemBuilder(tableAlias, "CUSME01996", "", GetDefault(属性.文字)))             '最終更新プログラムID
        'item.Append("," & ItemBuilder(tableAlias, "CUSME01997", "", GetDefault(属性.文字)))             '最終更新者
        'item.Append("," & ItemBuilder(tableAlias, "CUSME01998", "", GetDefault(属性.数値)))             '最終更新日時
        'item.Append("," & ItemBuilder(tableAlias, "CUSME01999", "", GetDefault(属性.数値)))             '更新番号
        'D-CUST20220425↑
        'A-CUST20220425↓
        item.Append("," & ItemBuilder(tableAlias, "CUSME01991", "", GetDefault(属性.文字)))             '登録プログラムID
        item.Append("," & ItemBuilder(tableAlias, "CUSME01992", "", GetDefault(属性.数値)))             '登録プログラムID枝番
        item.Append("," & ItemBuilder(tableAlias, "CUSME01993", "", GetDefault(属性.文字)))             '登録者
        item.Append("," & ItemBuilder(tableAlias, "CUSME01994", "", GetDefault(属性.文字)))             '最終更新プログラムID
        item.Append("," & ItemBuilder(tableAlias, "CUSME01995", "", GetDefault(属性.数値)))             '最終更新プログラムID枝番
        item.Append("," & ItemBuilder(tableAlias, "CUSME01996", "", GetDefault(属性.文字)))             '最終更新者
        item.Append("," & ItemBuilder(tableAlias, "CUSME01999", "", GetDefault(属性.数値)))             '更新番号
        item.Append("," & ItemBuilder(tableAlias, "CUSME01INS", "", GetDefault(属性.数値)))             '登録日時
        item.Append("," & ItemBuilder(tableAlias, "CUSME01UPD", "", GetDefault(属性.数値)))             '最終更新日時
        'A-CUST20220425↑

        Return item.ToString

    End Function

    ''' <summary>
    ''' 商品マスター取得列名定義
    ''' </summary>
    ''' <param name="tableAlias"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function SelectItem商品マスター(Optional ByVal tableAlias As String = "") As String

        Dim item As New System.Text.StringBuilder

        item.Append(" " & ItemBuilder(tableAlias, "CUSME03001", "", GetDefault(属性.文字)))             '商品コード
        item.Append("," & ItemBuilder(tableAlias, "CUSME03002", "", GetDefault(属性.文字)))             '商品名
        item.Append("," & ItemBuilder(tableAlias, "CUSME03003", "", GetDefault(属性.文字)))             '単位
        item.Append("," & ItemBuilder(tableAlias, "CUSME03004", "", GetDefault(属性.数値)))             '売上単価
        item.Append("," & ItemBuilder(tableAlias, "CUSME03005", "", GetDefault(属性.数値)))             '仕入単価
        item.Append("," & ItemBuilder(tableAlias, "CUSME03006", "", GetDefault(属性.数値)))             '在庫評価単価
        item.Append("," & ItemBuilder(tableAlias, "CUSME03007", "", GetDefault(属性.数値)))             '原単価
        item.Append("," & ItemBuilder(tableAlias, "CUSME03008", "", GetDefault(属性.数値)))             '上代単価
        item.Append("," & ItemBuilder(tableAlias, "CUSME03009", "", GetDefault(属性.数値)))             '新単価実施日
        item.Append("," & ItemBuilder(tableAlias, "CUSME03010", "", GetDefault(属性.数値)))             '新売上単価
        item.Append("," & ItemBuilder(tableAlias, "CUSME03011", "", GetDefault(属性.数値)))             '新仕入単価
        item.Append("," & ItemBuilder(tableAlias, "CUSME03012", "", GetDefault(属性.数値)))             '新在庫評価単価
        item.Append("," & ItemBuilder(tableAlias, "CUSME03013", "", GetDefault(属性.数値)))             '新原単価
        item.Append("," & ItemBuilder(tableAlias, "CUSME03014", "", GetDefault(属性.数値)))             '新上代単価
        item.Append("," & ItemBuilder(tableAlias, "CUSME03015", "", GetDefault(属性.文字)))             '消費税率分類
        item.Append("," & ItemBuilder(tableAlias, "CUSME03016", "", GetDefault(属性.文字)))             '在庫管理区分
        item.Append("," & ItemBuilder(tableAlias, "CUSME03017", "", GetDefault(属性.文字)))             '売上課税区分
        item.Append("," & ItemBuilder(tableAlias, "CUSME03018", "", GetDefault(属性.文字)))             '仕入課税区分
        item.Append("," & ItemBuilder(tableAlias, "CUSME03019", "", GetDefault(属性.文字)))             '基準倉庫コード
        'D-CUST20220425↓
        'item.Append("," & ItemBuilder(tableAlias, "CUSME03993", "", GetDefault(属性.文字)))             '登録プログラムID
        'item.Append("," & ItemBuilder(tableAlias, "CUSME03994", "", GetDefault(属性.文字)))             '登録者
        'item.Append("," & ItemBuilder(tableAlias, "CUSME03995", "", GetDefault(属性.数値)))             '登録日時
        'item.Append("," & ItemBuilder(tableAlias, "CUSME03996", "", GetDefault(属性.文字)))             '最終更新プログラムID
        'item.Append("," & ItemBuilder(tableAlias, "CUSME03997", "", GetDefault(属性.文字)))             '最終更新者
        'item.Append("," & ItemBuilder(tableAlias, "CUSME03998", "", GetDefault(属性.数値)))             '最終更新日時
        'item.Append("," & ItemBuilder(tableAlias, "CUSME03999", "", GetDefault(属性.数値)))             '更新番号
        'D-CUST20220425↑
        'A-CUST20220425↓
        item.Append("," & ItemBuilder(tableAlias, "CUSME03991", "", GetDefault(属性.文字)))             '登録プログラムID
        item.Append("," & ItemBuilder(tableAlias, "CUSME03992", "", GetDefault(属性.数値)))             '登録プログラムID枝番
        item.Append("," & ItemBuilder(tableAlias, "CUSME03993", "", GetDefault(属性.文字)))             '登録者
        item.Append("," & ItemBuilder(tableAlias, "CUSME03994", "", GetDefault(属性.文字)))             '最終更新プログラムID
        item.Append("," & ItemBuilder(tableAlias, "CUSME03995", "", GetDefault(属性.数値)))             '最終更新プログラムID枝番
        item.Append("," & ItemBuilder(tableAlias, "CUSME03996", "", GetDefault(属性.文字)))             '最終更新者
        item.Append("," & ItemBuilder(tableAlias, "CUSME03999", "", GetDefault(属性.数値)))             '更新番号
        item.Append("," & ItemBuilder(tableAlias, "CUSME03INS", "", GetDefault(属性.数値)))             '登録日時
        item.Append("," & ItemBuilder(tableAlias, "CUSME03UPD", "", GetDefault(属性.数値)))             '最終更新日時
        'A-CUST20220425↑

        Return item.ToString

    End Function

    ''' <summary>
    ''' 担当者マスター取得列名定義
    ''' </summary>
    ''' <param name="tableAlias"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function SelectItem担当者マスター(Optional ByVal tableAlias As String = "") As String

        Dim item As New System.Text.StringBuilder

        item.Append(" " & ItemBuilder(tableAlias, "CUSME04001", "", GetDefault(属性.文字)))             '担当者コード
        item.Append("," & ItemBuilder(tableAlias, "CUSME04002", "", GetDefault(属性.文字)))             '担当者名
        item.Append("," & ItemBuilder(tableAlias, "CUSME04003", "", GetDefault(属性.文字)))             '担当者略称
        item.Append("," & ItemBuilder(tableAlias, "CUSME04004", "", GetDefault(属性.文字)))             'フリガナ
        item.Append("," & ItemBuilder(tableAlias, "CUSME04005", "", GetDefault(属性.文字)))             '部門コード
        'D-CUST20220425↓
        'item.Append("," & ItemBuilder(tableAlias, "CUSME04993", "", GetDefault(属性.文字)))             '登録プログラムID
        'item.Append("," & ItemBuilder(tableAlias, "CUSME04994", "", GetDefault(属性.文字)))             '登録者
        'item.Append("," & ItemBuilder(tableAlias, "CUSME04995", "", GetDefault(属性.数値)))             '登録日時
        'item.Append("," & ItemBuilder(tableAlias, "CUSME04996", "", GetDefault(属性.文字)))             '最終更新プログラムID
        'item.Append("," & ItemBuilder(tableAlias, "CUSME04997", "", GetDefault(属性.文字)))             '最終更新者
        'item.Append("," & ItemBuilder(tableAlias, "CUSME04998", "", GetDefault(属性.数値)))             '最終更新日時
        'item.Append("," & ItemBuilder(tableAlias, "CUSME04999", "", GetDefault(属性.数値)))             '更新番号
        'D-CUST20220425↑
        'A-CUST20220425↓
        item.Append("," & ItemBuilder(tableAlias, "CUSME04991", "", GetDefault(属性.文字)))             '登録プログラムID
        item.Append("," & ItemBuilder(tableAlias, "CUSME04992", "", GetDefault(属性.数値)))             '登録プログラムID枝番
        item.Append("," & ItemBuilder(tableAlias, "CUSME04993", "", GetDefault(属性.文字)))             '登録者
        item.Append("," & ItemBuilder(tableAlias, "CUSME04994", "", GetDefault(属性.文字)))             '最終更新プログラムID
        item.Append("," & ItemBuilder(tableAlias, "CUSME04995", "", GetDefault(属性.数値)))             '最終更新プログラムID枝番
        item.Append("," & ItemBuilder(tableAlias, "CUSME04996", "", GetDefault(属性.文字)))             '最終更新者
        item.Append("," & ItemBuilder(tableAlias, "CUSME04999", "", GetDefault(属性.数値)))             '更新番号
        item.Append("," & ItemBuilder(tableAlias, "CUSME04INS", "", GetDefault(属性.数値)))             '登録日時
        item.Append("," & ItemBuilder(tableAlias, "CUSME04UPD", "", GetDefault(属性.数値)))             '最終更新日時
        'A-CUST20220425↑

        Return item.ToString

    End Function

    ''' <summary>
    ''' 部門マスター取得列名定義
    ''' </summary>
    ''' <param name="tableAlias"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function SelectItem部門マスター(Optional ByVal tableAlias As String = "") As String

        Dim item As New System.Text.StringBuilder

        item.Append(" " & ItemBuilder(tableAlias, "CUSME05001", "", GetDefault(属性.文字)))             '部門コード
        item.Append("," & ItemBuilder(tableAlias, "CUSME05002", "", GetDefault(属性.文字)))             '部門名
        item.Append("," & ItemBuilder(tableAlias, "CUSME05003", "", GetDefault(属性.文字)))             '部門略称
        item.Append("," & ItemBuilder(tableAlias, "CUSME05004", "", GetDefault(属性.文字)))             '索引
        'D-CUST20220425↓
        'item.Append("," & ItemBuilder(tableAlias, "CUSME05993", "", GetDefault(属性.文字)))             '登録プログラムID
        'item.Append("," & ItemBuilder(tableAlias, "CUSME05994", "", GetDefault(属性.文字)))             '登録者
        'item.Append("," & ItemBuilder(tableAlias, "CUSME05995", "", GetDefault(属性.数値)))             '登録日時
        'item.Append("," & ItemBuilder(tableAlias, "CUSME05996", "", GetDefault(属性.文字)))             '最終更新プログラムID
        'item.Append("," & ItemBuilder(tableAlias, "CUSME05997", "", GetDefault(属性.文字)))             '最終更新者
        'item.Append("," & ItemBuilder(tableAlias, "CUSME05998", "", GetDefault(属性.数値)))             '最終更新日時
        'item.Append("," & ItemBuilder(tableAlias, "CUSME05999", "", GetDefault(属性.数値)))             '更新番号
        'D-CUST20220425↑
        'A-CUST20220425↓
        item.Append("," & ItemBuilder(tableAlias, "CUSME05991", "", GetDefault(属性.文字)))             '登録プログラムID
        item.Append("," & ItemBuilder(tableAlias, "CUSME05992", "", GetDefault(属性.数値)))             '登録プログラムID枝番
        item.Append("," & ItemBuilder(tableAlias, "CUSME05993", "", GetDefault(属性.文字)))             '登録者
        item.Append("," & ItemBuilder(tableAlias, "CUSME05994", "", GetDefault(属性.文字)))             '最終更新プログラムID
        item.Append("," & ItemBuilder(tableAlias, "CUSME05995", "", GetDefault(属性.数値)))             '最終更新プログラムID枝番
        item.Append("," & ItemBuilder(tableAlias, "CUSME05996", "", GetDefault(属性.文字)))             '最終更新者
        item.Append("," & ItemBuilder(tableAlias, "CUSME05999", "", GetDefault(属性.数値)))             '更新番号
        item.Append("," & ItemBuilder(tableAlias, "CUSME05INS", "", GetDefault(属性.数値)))             '登録日時
        item.Append("," & ItemBuilder(tableAlias, "CUSME05UPD", "", GetDefault(属性.数値)))             '最終更新日時
        'A-CUST20220425↑

        Return item.ToString

    End Function

    ''' <summary>
    ''' 倉庫マスター取得列名定義
    ''' </summary>
    ''' <param name="tableAlias"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function SelectItem倉庫マスター(Optional ByVal tableAlias As String = "") As String

        Dim item As New System.Text.StringBuilder

        item.Append(" " & ItemBuilder(tableAlias, "CUSME06001", "", GetDefault(属性.文字)))             '倉庫コード
        item.Append("," & ItemBuilder(tableAlias, "CUSME06002", "", GetDefault(属性.文字)))             '倉庫名
        item.Append("," & ItemBuilder(tableAlias, "CUSME06003", "", GetDefault(属性.文字)))             '倉庫略称
        item.Append("," & ItemBuilder(tableAlias, "CUSME06004", "", GetDefault(属性.文字)))             '索引
        'D-CUST20220425↓
        'item.Append("," & ItemBuilder(tableAlias, "CUSME06993", "", GetDefault(属性.文字)))             '登録プログラムID
        'item.Append("," & ItemBuilder(tableAlias, "CUSME06994", "", GetDefault(属性.文字)))             '登録者
        'item.Append("," & ItemBuilder(tableAlias, "CUSME06995", "", GetDefault(属性.数値)))             '登録日時
        'item.Append("," & ItemBuilder(tableAlias, "CUSME06996", "", GetDefault(属性.文字)))             '最終更新プログラムID
        'item.Append("," & ItemBuilder(tableAlias, "CUSME06997", "", GetDefault(属性.文字)))             '最終更新者
        'item.Append("," & ItemBuilder(tableAlias, "CUSME06998", "", GetDefault(属性.数値)))             '最終更新日時
        'item.Append("," & ItemBuilder(tableAlias, "CUSME06999", "", GetDefault(属性.数値)))             '更新番号
        'D-CUST20220425↑
        'A-CUST20220425↓
        item.Append("," & ItemBuilder(tableAlias, "CUSME06991", "", GetDefault(属性.文字)))             '登録プログラムID
        item.Append("," & ItemBuilder(tableAlias, "CUSME06992", "", GetDefault(属性.数値)))             '登録プログラムID枝番
        item.Append("," & ItemBuilder(tableAlias, "CUSME06993", "", GetDefault(属性.文字)))             '登録者
        item.Append("," & ItemBuilder(tableAlias, "CUSME06994", "", GetDefault(属性.文字)))             '最終更新プログラムID
        item.Append("," & ItemBuilder(tableAlias, "CUSME06995", "", GetDefault(属性.数値)))             '最終更新プログラムID枝番
        item.Append("," & ItemBuilder(tableAlias, "CUSME06996", "", GetDefault(属性.文字)))             '最終更新者
        item.Append("," & ItemBuilder(tableAlias, "CUSME06999", "", GetDefault(属性.数値)))             '更新番号
        item.Append("," & ItemBuilder(tableAlias, "CUSME06INS", "", GetDefault(属性.数値)))             '登録日時
        item.Append("," & ItemBuilder(tableAlias, "CUSME06UPD", "", GetDefault(属性.数値)))             '最終更新日時
        'A-CUST20220425↑

        Return item.ToString

    End Function

    ''' <summary>
    ''' 発行済管理テーブル取得列名定義
    ''' </summary>
    ''' <param name="tableAlias"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function SelectItem発行済管理テーブル(Optional ByVal tableAlias As String = "") As String

        Dim item As New System.Text.StringBuilder

        item.Append(" " & ItemBuilder(tableAlias, "CUSRE91008", "", GetDefault(属性.文字)))             '発行済管理更新日時

        Return item.ToString

    End Function

    ''' <summary>
    ''' コントロールテーブル取得列名定義
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function SelectItemコントロールテーブル() As String

        Dim item As New System.Text.StringBuilder

        item.Append(" " & ItemBuilder("", "CUSCE01001", "", GetDefault(属性.文字)))
        item.Append("," & ItemBuilder("", "CUSCE01002", "", GetDefault(属性.文字)))

        Return item.ToString

    End Function

    'A-CUST20201013↓
    Friend Function SelectItem納品先マスター(Optional ByVal tableAlias As String = "") As String

        Dim item As New System.Text.StringBuilder

        item.Append(" " & ItemBuilder(tableAlias, "CUSME37001", "", GetDefault(属性.文字)))             '得意先コード
        item.Append("," & ItemBuilder(tableAlias, "CUSME37002", "", GetDefault(属性.文字)))             '納品先コード
        item.Append("," & ItemBuilder(tableAlias, "CUSME37003", "", GetDefault(属性.文字)))             '納品先名
        item.Append("," & ItemBuilder(tableAlias, "CUSME37004", "", GetDefault(属性.文字)))             '索引
        item.Append("," & ItemBuilder(tableAlias, "CUSME37005", "", GetDefault(属性.文字)))             '荷受人名１
        item.Append("," & ItemBuilder(tableAlias, "CUSME37006", "", GetDefault(属性.文字)))             '荷受人名２
        item.Append("," & ItemBuilder(tableAlias, "CUSME37007", "", GetDefault(属性.文字)))             '郵便番号
        item.Append("," & ItemBuilder(tableAlias, "CUSME37008", "", GetDefault(属性.文字)))             '住所１
        item.Append("," & ItemBuilder(tableAlias, "CUSME37009", "", GetDefault(属性.文字)))             '住所２
        item.Append("," & ItemBuilder(tableAlias, "CUSME37010", "", GetDefault(属性.文字)))             '住所３
        item.Append("," & ItemBuilder(tableAlias, "CUSME37011", "", GetDefault(属性.文字)))             '電話番号
        item.Append("," & ItemBuilder(tableAlias, "CUSME37012", "", GetDefault(属性.文字)))             'ＦＡＸ番号
        'D-CUST20220425↓
        'item.Append("," & ItemBuilder(tableAlias, "CUSME37993", "", GetDefault(属性.文字)))             '登録プログラムID
        'item.Append("," & ItemBuilder(tableAlias, "CUSME37994", "", GetDefault(属性.文字)))             '登録者
        'item.Append("," & ItemBuilder(tableAlias, "CUSME37995", "", GetDefault(属性.数値)))             '登録日時
        'item.Append("," & ItemBuilder(tableAlias, "CUSME37996", "", GetDefault(属性.文字)))             '最終更新プログラムID
        'item.Append("," & ItemBuilder(tableAlias, "CUSME37997", "", GetDefault(属性.文字)))             '最終更新者
        'item.Append("," & ItemBuilder(tableAlias, "CUSME37998", "", GetDefault(属性.数値)))             '最終更新日時
        'item.Append("," & ItemBuilder(tableAlias, "CUSME37999", "", GetDefault(属性.数値)))             '更新番号
        'D-CUST20220425↑
        'A-CUST20220425↓
        item.Append("," & ItemBuilder(tableAlias, "CUSME37991", "", GetDefault(属性.文字)))             '登録プログラムID
        item.Append("," & ItemBuilder(tableAlias, "CUSME37992", "", GetDefault(属性.数値)))             '登録プログラムID枝番
        item.Append("," & ItemBuilder(tableAlias, "CUSME37993", "", GetDefault(属性.文字)))             '登録者
        item.Append("," & ItemBuilder(tableAlias, "CUSME37994", "", GetDefault(属性.文字)))             '最終更新プログラムID
        item.Append("," & ItemBuilder(tableAlias, "CUSME37995", "", GetDefault(属性.数値)))             '最終更新プログラムID枝番
        item.Append("," & ItemBuilder(tableAlias, "CUSME37996", "", GetDefault(属性.文字)))             '最終更新者
        item.Append("," & ItemBuilder(tableAlias, "CUSME37999", "", GetDefault(属性.数値)))             '更新番号
        item.Append("," & ItemBuilder(tableAlias, "CUSME37INS", "", GetDefault(属性.数値)))             '登録日時
        item.Append("," & ItemBuilder(tableAlias, "CUSME37UPD", "", GetDefault(属性.数値)))             '最終更新日時
        'A-CUST20220425↑

        Return item.ToString

    End Function
    'A-CUST20201013↑

    ''' <summary>
    ''' 区分マスター取得列名定義
    ''' </summary>
    ''' <param name="tableAlias"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function SelectItem区分マスター(Optional ByVal tableAlias As String = "") As String

        Dim item As New System.Text.StringBuilder

        item.Append(" " & ItemBuilder(tableAlias, "CUSCE03001", "", GetDefault(属性.文字)))             '種別
        item.Append("," & ItemBuilder(tableAlias, "CUSCE03002", "", GetDefault(属性.文字)))             '区分
        item.Append("," & ItemBuilder(tableAlias, "CUSCE03003", "", GetDefault(属性.文字)))             '区分名
        item.Append("," & ItemBuilder(tableAlias, "CUSCE03004", "", GetDefault(属性.文字)))             '区分略称
        item.Append("," & ItemBuilder(tableAlias, "CUSCE03005", "", GetDefault(属性.数値)))             '属性

        Return item.ToString

    End Function

    ''' <summary>
    ''' 日付管理テーブル取得列名定義
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function SelectItem日付管理テーブル() As String

        Dim item As New System.Text.StringBuilder

        item.Append(" " & ItemBuilder("", "CUSCE11001", "", GetDefault(属性.文字)))
        item.Append("," & ItemBuilder("", "CUSCE11002", "", GetDefault(属性.数値)))
        item.Append("," & ItemBuilder("", "CUSCE11003", "", GetDefault(属性.数値)))
        item.Append("," & ItemBuilder("", "CUSCE11004", "", GetDefault(属性.数値)))
        item.Append("," & ItemBuilder("", "CUSCE11005", "", GetDefault(属性.数値)))

        Return item.ToString

    End Function

    ''' <summary>
    ''' 連番管理テーブル取得列名定義
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function SelectItem連番管理テーブル() As String

        Dim item As New System.Text.StringBuilder

        item.Append(" " & ItemBuilder("", "CUSCE21008", "", GetDefault(属性.数値)))

        Return item.ToString

    End Function

    'A-CUST20241219↓
    ''' <summary>
    ''' 見積サブ明細テーブル取得列名定義
    ''' </summary>
    ''' <param name="tableAlias"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function SelectItem見積サブ明細テーブル(Optional ByVal tableAlias As String = "") As String

        Dim item As New System.Text.StringBuilder

        item.Append(" " & ItemBuilder(tableAlias, "CUSRE29001", "", GetDefault(属性.数値)))     '見積№
        item.Append("," & ItemBuilder(tableAlias, "CUSRE29002", "", GetDefault(属性.数値)))     'メイン行№
        item.Append("," & ItemBuilder(tableAlias, "CUSRE29003", "", GetDefault(属性.数値)))     '行№
        item.Append("," & ItemBuilder(tableAlias, "CUSRE29004", "", GetDefault(属性.文字)))     '商品コード
        item.Append("," & ItemBuilder(tableAlias, "CUSRE29005", "", GetDefault(属性.文字)))     '商品名
        item.Append("," & ItemBuilder(tableAlias, "CUSRE29006", "", GetDefault(属性.文字)))     '単位
        item.Append("," & ItemBuilder(tableAlias, "CUSRE29007", "", GetDefault(属性.数値)))     '数量
        item.Append("," & ItemBuilder(tableAlias, "CUSRE29008", "", GetDefault(属性.数値)))     '単価
        item.Append("," & ItemBuilder(tableAlias, "CUSRE29009", "", GetDefault(属性.数値)))     '金額
        item.Append("," & ItemBuilder(tableAlias, "CUSRE29991", "", GetDefault(属性.文字)))     '登録プログラムID
        item.Append("," & ItemBuilder(tableAlias, "CUSRE29992", "", GetDefault(属性.数値)))     '登録プログラムID枝番
        item.Append("," & ItemBuilder(tableAlias, "CUSRE29993", "", GetDefault(属性.文字)))     '登録者
        item.Append("," & ItemBuilder(tableAlias, "CUSRE29INS", "", GetDefault(属性.数値)))     '登録日時
        item.Append("," & ItemBuilder(tableAlias, "CUSRE29994", "", GetDefault(属性.文字)))     '最終更新プログラムID
        item.Append("," & ItemBuilder(tableAlias, "CUSRE29995", "", GetDefault(属性.数値)))     '最終更新プログラムID枝番
        item.Append("," & ItemBuilder(tableAlias, "CUSRE29996", "", GetDefault(属性.文字)))     '最終更新者
        item.Append("," & ItemBuilder(tableAlias, "CUSRE29UPD", "", GetDefault(属性.数値)))     '最終更新日時
        item.Append("," & ItemBuilder(tableAlias, "CUSRE29999", "", GetDefault(属性.数値)))     '更新番号

        Return item.ToString

    End Function
    'A-CUST20241219↑

#End Region

#Region "内部メソッド"

    ''' <summary>
    ''' 取得項目の組み立て
    ''' </summary>
    ''' <param name="tableAlias">対象テーブルの別名</param>
    ''' <param name="itemName">取得列名</param>
    ''' <param name="itemAlias">取得列名の別名</param>
    ''' <param name="itemDefault">NULL時の初期値</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ItemBuilder(
                                ByVal tableAlias As String,
                                ByVal itemName As String,
                                ByVal itemAlias As String,
                                ByVal itemDefault As String) As String

        Dim st As New System.Text.StringBuilder

        st.Append(QueryWrapper.AddIsNull)
        st.Append(" (")
        If Not String.IsNullOrEmpty(tableAlias) Then
            st.Append(tableAlias & ".")
        End If
        st.Append(itemName)
        st.Append(",")
        st.Append(itemDefault)
        st.Append(") ")
        If Not String.IsNullOrEmpty(itemAlias) Then
            st.Append(itemAlias)
        ElseIf Not String.IsNullOrEmpty(tableAlias) Then
            st.Append(tableAlias & "_" & itemName)
        Else
            st.Append(itemName)
        End If

        Return st.ToString
    End Function

    Private Enum 属性
        文字
        数値
    End Enum

    Private Function GetDefault(ByVal type As 属性) As String
        Dim st As String = ""

        Select Case type
            Case 属性.文字
                st = "' '"
            Case 属性.数値
                st = "0."
            Case Else
        End Select
        Return st

    End Function

#End Region

#Region "パラメータ"

    Private Enum パラメータ型 As Integer
        伝票区分
        伝票番号
        得意先コード
        部門コード
        区分コード
        種別
        商品コード
        担当者コード
        倉庫コード
        納品先コード   'A-CUST20201013
    End Enum

    Private Const PARAMETER_MARKER As String = "?"

    Private Function GetParameter(ByVal targetType As パラメータ型,
                                  ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList) As String

        Dim newParameter As New OSK.X1.DataAccess.ParamInfo

        newParameter.Name = "Param" & CStr(paramInfo.Count)

        Select Case targetType
            Case パラメータ型.伝票区分
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 1
                    .Scale = 0
                    .Value = CDec(_readParam.Container(ReadParam.項目名型.伝票区分))
                End With
            Case パラメータ型.伝票番号
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 10
                    .Scale = 0
                    .Value = CDec(_readParam.Container(ReadParam.項目名型.伝票番号))
                End With
            Case パラメータ型.得意先コード
                With newParameter
                    .Type = DbType.AnsiStringFixedLength
                    .Size = 11
                    .Value = CStr(_readParam.Container(ReadParam.項目名型.得意先コード))
                End With
            Case パラメータ型.商品コード
                With newParameter
                    .Type = DbType.AnsiStringFixedLength
                    .Size = 20
                    .Value = CStr(_readParam.Container(ReadParam.項目名型.商品コード))
                End With
            Case パラメータ型.担当者コード
                With newParameter
                    .Type = DbType.AnsiStringFixedLength
                    .Size = 6
                    .Value = CStr(_readParam.Container(ReadParam.項目名型.担当者コード))
                End With
            Case パラメータ型.倉庫コード
                With newParameter
                    .Type = DbType.AnsiStringFixedLength
                    .Size = 6
                    .Value = CStr(_readParam.Container(ReadParam.項目名型.倉庫コード))
                End With
            Case パラメータ型.部門コード
                With newParameter
                    .Type = DbType.AnsiStringFixedLength
                    .Size = 6
                    .Value = CStr(_readParam.Container(ReadParam.項目名型.部門コード))
                End With
            Case パラメータ型.種別
                With newParameter
                    .Type = DbType.AnsiStringFixedLength
                    .Size = 4
                    .Value = CStr(_readParam.Container(ReadParam.項目名型.種別))
                End With
            Case パラメータ型.区分コード
                With newParameter
                    .Type = DbType.AnsiStringFixedLength
                    .Size = 2
                    .Value = CStr(_readParam.Container(ReadParam.項目名型.区分コード))
                End With
                'A-CUST20201013↓
            Case パラメータ型.納品先コード
                With newParameter
                    .Type = DbType.AnsiStringFixedLength
                    .Size = 6
                    .Value = CStr(_readParam.Container(ReadParam.項目名型.納品先コード))
                End With
                'A-CUST20201013↑
            Case Else
                Throw New System.Exception("paramTypeパラメータ不正")
        End Select

        paramInfo.Add(newParameter)

        Return PARAMETER_MARKER

    End Function

#End Region

#Region "ストアド"

    Private Enum ストアドパラメータ型 As Integer
        倉庫コード
        商品コード
        期首年月
        指定年月
        指定年月日
        自社締日付
        数量小数点以下桁数
        端数単位処理方法
        在庫数量
        リターンコード1
        リターンコード2
    End Enum

    ''' <summary>
    ''' ストアドパラメータセット
    ''' </summary>
    ''' <remarks></remarks>
    Friend Sub MakeParameterストアド(ByRef paramInfo As ParamInfoList)

        GetReadParameterストアド(ストアドパラメータ型.倉庫コード, paramInfo)
        GetReadParameterストアド(ストアドパラメータ型.商品コード, paramInfo)
        GetReadParameterストアド(ストアドパラメータ型.期首年月, paramInfo)
        GetReadParameterストアド(ストアドパラメータ型.指定年月, paramInfo)
        GetReadParameterストアド(ストアドパラメータ型.指定年月日, paramInfo)
        GetReadParameterストアド(ストアドパラメータ型.自社締日付, paramInfo)
        GetReadParameterストアド(ストアドパラメータ型.数量小数点以下桁数, paramInfo)
        GetReadParameterストアド(ストアドパラメータ型.端数単位処理方法, paramInfo)
        GetReadParameterストアド(ストアドパラメータ型.在庫数量, paramInfo)

    End Sub

    Private Sub GetReadParameterストアド(
                                        ByVal targetType As ストアドパラメータ型,
                                        ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList)

        Dim newParameter As New OSK.X1.DataAccess.ParamInfo

        Select Case targetType
            Case ストアドパラメータ型.倉庫コード
                With newParameter
                    .Type = DbType.AnsiStringFixedLength
                    .Size = 11
                    .Value = CStr(_readParam.Container(ReadParam.項目名型.倉庫コード_ストアド))
                    .Name = "SOUKOCD"
                End With

            Case ストアドパラメータ型.商品コード
                With newParameter
                    .Type = DbType.AnsiStringFixedLength
                    .Size = 20
                    .Precision = 0
                    .Scale = 0
                    .Value = CStr(_readParam.Container(ReadParam.項目名型.商品コード_ストアド))
                    .Name = "SHOUHINCD"
                End With

            Case ストアドパラメータ型.期首年月
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 6
                    .Scale = 0
                    .Value = CInt(_readParam.Container(ReadParam.項目名型.期首年月_ストアド))
                    .Name = "KISYUYM"
                End With

            Case ストアドパラメータ型.指定年月
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 6
                    .Scale = 0
                    .Value = CInt(_readParam.Container(ReadParam.項目名型.指定年月_ストアド))
                    .Name = "YYYYMM"
                End With

            Case ストアドパラメータ型.指定年月日
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 8
                    .Scale = 0
                    .Value = CInt(_readParam.Container(ReadParam.項目名型.指定年月日_ストアド))
                    .Name = "YYYYMMDD"
                End With

            Case ストアドパラメータ型.自社締日付
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 2
                    .Scale = 0
                    .Value = CInt(_readParam.Container(ReadParam.項目名型.自社締日付_ストアド))
                    .Name = "SHIMEBI"
                End With

            Case ストアドパラメータ型.数量小数点以下桁数
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 1
                    .Scale = 0
                    .Value = CInt(_readParam.Container(ReadParam.項目名型.数量小数点以下桁数_ストアド))
                    .Name = "SYOUSUUKETA_SURYO"
                End With

            Case ストアドパラメータ型.端数単位処理方法
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 1
                    .Scale = 0
                    .Value = CInt(_readParam.Container(ReadParam.項目名型.端数単位処理方法_ストアド))
                    .Name = "HASUUKBN"
                End With

            Case ストアドパラメータ型.在庫数量
                With newParameter
                    .Direction = ParameterDirection.ReturnValue
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 19
                    .Scale = 4
                    .Value = 0
                    .Name = "ZAIKOSUU"
                End With

            Case ストアドパラメータ型.リターンコード1
                With newParameter
                    .Direction = ParameterDirection.Output
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 1
                    .Scale = 0
                    .Value = 0
                    .Name = "RETCD1"
                End With

            Case ストアドパラメータ型.リターンコード2
                With newParameter
                    .Direction = ParameterDirection.Output
                    .Type = DbType.String
                    .Size = 30
                    .Value = ""
                    .Name = "RETCD2"
                End With
            Case Else
                Throw New System.Exception("paramTypeパラメータ不正")
        End Select

        paramInfo.Add(newParameter)

    End Sub

#End Region

End Class

''' <summary>
''' 見積伝票即時発行用SQL構築クラス
''' </summary>
''' <remarks></remarks>
Public Class PrintSqlCreator
    Inherits InsideDataHandlerBase

    Private _readParam As ReadParam

    Public Overloads Sub Initialize(ByVal creator As OSK.X1.Foundation.DataAccess.IDataHandler, ByVal readParam As ReadParam)

        MyBase.Initialize(creator)

        If readParam Is Nothing Then Exit Sub

        _readParam = readParam

    End Sub

#Region "MakeSQL"

    ''' <summary>
    ''' 即時発行用DataTable作成用（見積書）
    ''' </summary>
    ''' <param name="SQL"></param>
    ''' <param name="parameter"></param>
    ''' <remarks></remarks>
    Public Sub MakeSQL即時発行用(
                                ByRef SQL As String,
                                ByRef parameter As ParamInfoList)

        '◆◇◆SQL文作成◇◆◇
        Dim st As New System.Text.StringBuilder

        '◆ＳＥＬＥＣＴ条件
        st.Append("SELECT ")
        st.Append(QueryWrapper.AddIndexHintOracle(GetIndexHint("SEL_D_1")))

        'ヘッダー部
        st.Append(" HMIT.CUSRE11001                                         HMIT001")       '見積№
        st.Append(",HMIT.CUSRE11002                                         HMIT002")       '見積日付
        st.Append("," & QueryWrapper.AddIsNull & "(CUSME01.CUSME01002,' ')  HMIT003")       '得意先名１
        st.Append("," & QueryWrapper.AddIsNull & "(CUSME01.CUSME01003,' ')  HMIT004")       '得意先名２
        st.Append("," & QueryWrapper.AddIsNull & "(HMIT.CUSRE11012,' ')     HMIT005")       '要件
        st.Append("," & QueryWrapper.AddIsNull & "(HMIT.CUSRE11009,' ')     HMIT006")       '納入期限
        st.Append("," & QueryWrapper.AddIsNull & "(HMIT.CUSRE11010,' ')     HMIT007")       '支払方法
        st.Append("," & QueryWrapper.AddIsNull & "(HMIT.CUSRE11011,' ')     HMIT008")       '有効期限
        st.Append("," & QueryWrapper.AddIsNull & "(CUSME04.CUSME04002,' ')  HMIT009")       '担当者
        st.Append(",HMIT.CUSRE11015                                         HMIT010")       '伝票課税対象額
        st.Append(",HMIT.CUSRE11016                                         HMIT011")       '伝票消費税額
        st.Append(",HMIT.CUSRE11023                                         HMIT012")       '伝票非課税額
        'A-CUST20201013↓
        st.Append("," & QueryWrapper.AddIsNull & "(CUSME37.CUSME37003,' ')  HMIT013")
        'A-CUST20201013↑

        '明細部
        st.Append(",MMIT.CUSRE12003                                         MMIT001")       '行№
        st.Append(",MMIT.CUSRE12006                                         MMIT002")       '商品コード
        st.Append("," & QueryWrapper.AddIsNull & "(MMIT.CUSRE12007,' ')     MMIT003")       '商品名
        st.Append(",'*'                                                     MMIT004")       '税分類マーク
        st.Append(",MMIT.CUSRE12009                                         MMIT005")       '数量
        st.Append("," & QueryWrapper.AddIsNull & "(MMIT.CUSRE12008,' ')     MMIT006")       '単位
        st.Append(",MMIT.CUSRE12010                                         MMIT007")       '単価
        st.Append(",MMIT.CUSRE12011                                         MMIT008")       '金額
        st.Append("," & QueryWrapper.AddIsNull & "(MMIT.CUSRE12012,' ')     MMIT009")       '行摘要
        st.Append(",MMIT.CUSRE12023                                         MMIT010")       '小計チェックフラグ
        st.Append(",MMIT.CUSRE12024                                         MMIT011")       '改頁チェックフラグ

        '◆ＦＲＯＭ条件
        st.Append(" FROM " & Me.ExchangeTableName("CUS98RE11MITSUMORIH") & " HMIT ")
        'st.Append(QueryWrapper.AddNoLock(GetIndexHint("RE01_D_1")))       'D-CUST20200311 '-20200527
        st.Append(QueryWrapper.AddNoLock(GetIndexHint("RE11_D_1")))        'A-CUST20200311 '-20200527

        '見積明細
        st.Append(" INNER JOIN ")
        st.Append(Me.ExchangeTableName("CUS98RE12MITSUMORIM ") & " MMIT ")
        'st.Append(QueryWrapper.AddNoLock(GetIndexHint("RE02_D_1")))        'D-CUST20200311 '-20200527
        st.Append(QueryWrapper.AddNoLock(GetIndexHint("RE12_D_1")))         'A-CUST20200311 '-20200527
        st.Append("  ON MMIT.CUSRE12001 = HMIT.CUSRE11001 ")
        st.Append(" AND MMIT.CUSRE12002 = 0 ")

        '得意先マスター
        st.Append(" LEFT OUTER JOIN ")
        st.Append(Me.ExchangeTableName("CUS98ME01TOKUI ") & " CUSME01 " & QueryWrapper.AddNoLock)
        st.Append("  ON CUSME01.CUSME01001 = HMIT.CUSRE11004 ")

        '担当者マスター
        st.Append(" LEFT OUTER JOIN ")
        st.Append(Me.ExchangeTableName("CUS98ME04TANTO ") & " CUSME04 " & QueryWrapper.AddNoLock)
        st.Append("  ON CUSME04.CUSME04001 = HMIT.CUSRE11007 ")

        'A-CUST20201013↓
        '納品先マスター
        st.Append(" LEFT OUTER JOIN ")
        st.Append(Me.ExchangeTableName("CUS98ME37NOHIN ") & "CUSME37" & QueryWrapper.AddNoLock)
        st.Append("  ON CUSME37.CUSME37001 = HMIT.CUSRE11004 ")
        st.Append(" AND CUSME37.CUSME37002 = HMIT.CUSRE11024 ")
        'A-CUST20201013↑

        st.Append(" WHERE 1 = 2 ")
        st.Append(QueryWrapper.AddUR())

        SQL = st.ToString

    End Sub

#End Region

End Class
