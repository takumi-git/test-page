﻿Public Class UpdateSQLCreator
    Inherits InsideDataHandlerBase

    Private _updateParam As UpdateParam

    Public Overloads Sub Initialize(ByVal creator As OSK.X1.Foundation.DataAccess.IDataHandler, ByVal updateParam As UpdateParam)

        MyBase.Initialize(creator)

        If updateParam Is Nothing Then Exit Sub

        _updateParam = updateParam

    End Sub

#Region "SQLの組立て"

#Region "登録"

    ''' <summary>
    ''' ワーク(ヘッダー)の更新（Insert）
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function MakeSQLInsertワーク(ByRef paramInfo As ParamInfoList) As String

        'データ展開
        _updateParam.ワーク = CType(_updateParam.Container(UpdateParam.項目名型.ワーク情報), DataTable)

        Dim sql As New System.Text.StringBuilder

        sql.Append(" INSERT INTO ")
        sql.Append(Me.ExchangeTableName("CUS98WE01WORK") & " ( ")
        sql.Append(" " & InsertItemワークテーブル())
        sql.Append(") VALUES ( ")
        sql.Append(" " & GetInsertParameterワークテーブル(UpdateParam.ワークテーブル項目型.CUSWE01001, paramInfo))
        sql.Append("," & GetInsertParameterワークテーブル(UpdateParam.ワークテーブル項目型.CUSWE01002, paramInfo))
        sql.Append("," & GetInsertParameterワークテーブル(UpdateParam.ワークテーブル項目型.CUSWE01003, paramInfo))
        sql.Append("," & GetInsertParameterワークテーブル(UpdateParam.ワークテーブル項目型.CUSWE01004, paramInfo))
        sql.Append("," & GetInsertParameterワークテーブル(UpdateParam.ワークテーブル項目型.CUSWE01005, paramInfo))
        sql.Append("," & GetInsertParameterワークテーブル(UpdateParam.ワークテーブル項目型.CUSWE01006, paramInfo))
        sql.Append("," & GetInsertParameterワークテーブル(UpdateParam.ワークテーブル項目型.CUSWE01007, paramInfo))
        sql.Append("," & GetInsertParameterワークテーブル(UpdateParam.ワークテーブル項目型.CUSWE01008, paramInfo))
        sql.Append("," & GetInsertParameterワークテーブル(UpdateParam.ワークテーブル項目型.CUSWE01009, paramInfo))
        sql.Append("," & GetInsertParameterワークテーブル(UpdateParam.ワークテーブル項目型.CUSWE01010, paramInfo))
        sql.Append("," & GetInsertParameterワークテーブル(UpdateParam.ワークテーブル項目型.CUSWE01993, paramInfo))
        sql.Append("," & GetInsertParameterワークテーブル(UpdateParam.ワークテーブル項目型.CUSWE01994, paramInfo))
        sql.Append("," & GetInsertParameterワークテーブル(UpdateParam.ワークテーブル項目型.CUSWE01995, paramInfo))
        sql.Append("," & GetInsertParameterワークテーブル(UpdateParam.ワークテーブル項目型.CUSWE01996, paramInfo))
        'D-CUST20220425↓
        'sql.Append("," & GetInsertParameterワークテーブル(UpdateParam.ワークテーブル項目型.CUSWE01997, paramInfo))
        'sql.Append("," & GetInsertParameterワークテーブル(UpdateParam.ワークテーブル項目型.CUSWE01998, paramInfo))
        'D-CUST20220425↑
        'A-CUST20220425↓
        sql.Append("," & GetInsertParameterワークテーブル(UpdateParam.ワークテーブル項目型.CUSWE01991, paramInfo))
        sql.Append("," & GetInsertParameterワークテーブル(UpdateParam.ワークテーブル項目型.CUSWE01992, paramInfo))
        sql.Append("," & GetInsertParameterワークテーブル(UpdateParam.ワークテーブル項目型.CUSWE01INS, paramInfo))
        sql.Append("," & GetInsertParameterワークテーブル(UpdateParam.ワークテーブル項目型.CUSWE01UPD, paramInfo))       'A-CUST20241219
        'A-CUST20220425↑
        sql.Append("," & GetInsertParameterワークテーブル(UpdateParam.ワークテーブル項目型.CUSWE01999, paramInfo))

        sql.Append(" ) ")

        Return sql.ToString

    End Function

#End Region

#End Region

#Region "各テーブル更新列名定義"

#Region "登録"

    ''' <summary>
    ''' ワークテーブル登録列名定義
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function InsertItemワークテーブル() As String

        Dim item As New System.Text.StringBuilder

        item.Append(" " & UpdateParam.ワークテーブル項目型.CUSWE01001.ToString)
        item.Append("," & UpdateParam.ワークテーブル項目型.CUSWE01002.ToString)
        item.Append("," & UpdateParam.ワークテーブル項目型.CUSWE01003.ToString)
        item.Append("," & UpdateParam.ワークテーブル項目型.CUSWE01004.ToString)
        item.Append("," & UpdateParam.ワークテーブル項目型.CUSWE01005.ToString)
        item.Append("," & UpdateParam.ワークテーブル項目型.CUSWE01006.ToString)
        item.Append("," & UpdateParam.ワークテーブル項目型.CUSWE01007.ToString)
        item.Append("," & UpdateParam.ワークテーブル項目型.CUSWE01008.ToString)
        item.Append("," & UpdateParam.ワークテーブル項目型.CUSWE01009.ToString)
        item.Append("," & UpdateParam.ワークテーブル項目型.CUSWE01010.ToString)
        item.Append("," & UpdateParam.ワークテーブル項目型.CUSWE01993.ToString)
        item.Append("," & UpdateParam.ワークテーブル項目型.CUSWE01994.ToString)
        item.Append("," & UpdateParam.ワークテーブル項目型.CUSWE01995.ToString)
        item.Append("," & UpdateParam.ワークテーブル項目型.CUSWE01996.ToString)
        'D-CUST20220425↓
        'item.Append("," & UpdateParam.ワークテーブル項目型.CUSWE01997.ToString)
        'item.Append("," & UpdateParam.ワークテーブル項目型.CUSWE01998.ToString)
        'D-CUST20220425↑
        'A-CUST20220425↓
        item.Append("," & UpdateParam.ワークテーブル項目型.CUSWE01991.ToString)
        item.Append("," & UpdateParam.ワークテーブル項目型.CUSWE01992.ToString)
        item.Append("," & UpdateParam.ワークテーブル項目型.CUSWE01INS.ToString)
        item.Append("," & UpdateParam.ワークテーブル項目型.CUSWE01UPD.ToString)       'A-CUST20241219
        'A-CUST20220425↑
        item.Append("," & UpdateParam.ワークテーブル項目型.CUSWE01999.ToString)

        Return item.ToString

    End Function

#End Region

#End Region

#Region "パラメータ"

    Private Const PARAMETER_MARKER As String = "?"

#Region "登録"

    Private Function GetInsertParameterワークテーブル(ByVal targetType As UpdateParam.ワークテーブル項目型,
                                                      ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList) As String

        Dim newParameter As New OSK.X1.DataAccess.ParamInfo

        newParameter.Name = "Param" & CStr(paramInfo.Count)

        Select Case targetType
            Case UpdateParam.ワークテーブル項目型.CUSWE01001
                With newParameter
                    .Type = DbType.AnsiStringFixedLength
                    .Size = 36
                    .Precision = 0
                    .Scale = 0
                    .Value = CStr(_updateParam.ワークテーブル項目(targetType.ToString))
                End With

            Case UpdateParam.ワークテーブル項目型.CUSWE01002
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 1
                    .Scale = 0
                    .Value = CDec(_updateParam.ワークテーブル項目(targetType.ToString))
                End With

            Case UpdateParam.ワークテーブル項目型.CUSWE01003
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 1
                    .Scale = 0
                    .Value = CDec(_updateParam.ワークテーブル項目(targetType.ToString))
                End With

            Case UpdateParam.ワークテーブル項目型.CUSWE01004
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 1
                    .Scale = 0
                    .Value = CDec(_updateParam.ワークテーブル項目(targetType.ToString))
                End With

            Case UpdateParam.ワークテーブル項目型.CUSWE01005
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 3
                    .Scale = 0
                    .Value = CDec(_updateParam.ワークテーブル項目(targetType.ToString))
                End With

            Case UpdateParam.ワークテーブル項目型.CUSWE01006
                With newParameter
                    .Type = DbType.String
                    .Size = 20000
                    .Value = CStr(_updateParam.ワークテーブル項目(targetType.ToString, False))
                End With

            Case UpdateParam.ワークテーブル項目型.CUSWE01007
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 1
                    .Scale = 0
                    .Value = CDec(_updateParam.ワークテーブル項目(targetType.ToString))
                End With

            Case UpdateParam.ワークテーブル項目型.CUSWE01008
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 10
                    .Scale = 0
                    .Value = CDec(_updateParam.ワークテーブル項目(targetType.ToString))
                End With

            Case UpdateParam.ワークテーブル項目型.CUSWE01010
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 10
                    .Scale = 0
                    .Value = CDec(_updateParam.ワークテーブル項目(targetType.ToString))
                End With

            Case UpdateParam.ワークテーブル項目型.CUSWE01009
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 2
                    .Scale = 0
                    .Value = CDec(_updateParam.ワークテーブル項目(targetType.ToString))
                End With

                'A-CUST20220425↓
            Case UpdateParam.ワークテーブル項目型.CUSWE01991
                With newParameter
                    .Type = DbType.AnsiStringFixedLength
                    .Size = 32
                    .Precision = 0
                    .Scale = 0
                    .Value = CStr(_updateParam.ワークテーブル項目(targetType.ToString))
                End With

            Case UpdateParam.ワークテーブル項目型.CUSWE01992
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 9
                    .Scale = 0
                    .Value = CDec(_updateParam.ワークテーブル項目(targetType.ToString))
                End With
                'A-CUST20220425↑

            Case UpdateParam.ワークテーブル項目型.CUSWE01993
                With newParameter
                    '.Type = DbType.AnsiStringFixedLength     'D-CUST20220425
                    .Type = DbType.String     'A-CUST20220425
                    .Size = 64
                    .Precision = 0
                    .Scale = 0
                    .Value = CStr(_updateParam.ワークテーブル項目(targetType.ToString))
                End With

            Case UpdateParam.ワークテーブル項目型.CUSWE01994
                With newParameter
                    'D-CUST20220425↓
                    '.Type = DbType.String
                    '.Size = 64
                    'D-CUST20220425↑
                    'A-CUST20220425↓
                    .Type = DbType.AnsiStringFixedLength
                    .Size = 32
                    'A-CUST20220425↑
                    .Precision = 0
                    .Scale = 0
                    .Value = CStr(_updateParam.ワークテーブル項目(targetType.ToString))
                End With

            Case UpdateParam.ワークテーブル項目型.CUSWE01995
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    '.Precision = 14      'D-CUST20220425
                    .Precision = 9      'A-CUST20220425
                    .Scale = 0
                    .Value = CDec(_updateParam.ワークテーブル項目(targetType.ToString))
                End With

            Case UpdateParam.ワークテーブル項目型.CUSWE01996
                With newParameter
                    '.Type = DbType.AnsiStringFixedLength     'D-CUST20220425
                    .Type = DbType.String     'A-CUST20220425
                    .Size = 64
                    .Precision = 0
                    .Scale = 0
                    .Value = CStr(_updateParam.ワークテーブル項目(targetType.ToString))
                End With

                'D-CUST20220425↓
                'Case UpdateParam.ワークテーブル項目型.CUSWE01997
                '    With newParameter
                '        .Type = DbType.String
                '        .Size = 64
                '        .Precision = 0
                '        .Scale = 0
                '        .Value = CStr(_updateParam.ワークテーブル項目(targetType.ToString))
                '    End With
                'D-CUST20220425↑

                'Case UpdateParam.ワークテーブル項目型.CUSWE01998      'D-CUST20220425
            Case UpdateParam.ワークテーブル項目型.CUSWE01INS     'A-CUST20220425
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    'D-CUST20220425↓
                    '.Precision = 14
                    '.Scale = 0
                    'D-CUST20220425↑
                    'A-CUST20220425↓
                    .Precision = 20
                    .Scale = 6
                    'A-CUST20220425↑
                    .Value = CDec(_updateParam.ワークテーブル項目(targetType.ToString))
                End With

                'A-CUST20241219↓
            Case UpdateParam.ワークテーブル項目型.CUSWE01UPD
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 14
                    .Scale = 0
                    .Value = CDec(_updateParam.ワークテーブル項目(targetType.ToString))
                End With
                'A-CUST20241219↑

            Case UpdateParam.ワークテーブル項目型.CUSWE01999
                With newParameter
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 9
                    .Scale = 0
                    .Value = CDec(_updateParam.ワークテーブル項目(targetType.ToString))
                End With


            Case Else
                Throw New System.Exception("paramTypeパラメータ不正")
        End Select

        paramInfo.Add(newParameter)

        Return PARAMETER_MARKER

    End Function

#End Region

#End Region

#Region "ストアド"

    Private Enum ストアドパラメータ型 As Integer
        GUID
        伝票番号
        対象年月度
        リターンコード1
        リターンコード2
    End Enum

    ''' <summary>
    ''' ストアドパラメータセット(伝票系)登録
    ''' </summary>
    ''' <remarks></remarks>
    Friend Sub MakeParameter伝票ストアド_登録(ByRef paramInfo As ParamInfoList)

        GetUpdateParameterストアド(ストアドパラメータ型.GUID, paramInfo)
        GetUpdateParameterストアド(ストアドパラメータ型.伝票番号, paramInfo)
        GetUpdateParameterストアド(ストアドパラメータ型.リターンコード1, paramInfo)
        GetUpdateParameterストアド(ストアドパラメータ型.リターンコード2, paramInfo)

    End Sub

    ''' <summary>
    ''' ストアドパラメータセット(伝票系)削除
    ''' </summary>
    ''' <remarks></remarks>
    Friend Sub MakeParameter伝票ストアド_削除(ByRef paramInfo As ParamInfoList)

        GetUpdateParameterストアド(ストアドパラメータ型.GUID, paramInfo)
        GetUpdateParameterストアド(ストアドパラメータ型.リターンコード1, paramInfo)
        GetUpdateParameterストアド(ストアドパラメータ型.リターンコード2, paramInfo)

    End Sub

    ''' <summary>
    ''' ストアドパラメータセット(ワーク)
    ''' </summary>
    ''' <remarks></remarks>
    Friend Sub MakeParameterワークストアド(ByRef paramInfo As ParamInfoList)

        GetUpdateParameterストアド(ストアドパラメータ型.GUID, paramInfo)
        GetUpdateParameterストアド(ストアドパラメータ型.リターンコード1, paramInfo)
        GetUpdateParameterストアド(ストアドパラメータ型.リターンコード2, paramInfo)

    End Sub

    Private Sub GetUpdateParameterストアド(
                                        ByVal targetType As ストアドパラメータ型,
                                        ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList)

        Dim newParameter As New OSK.X1.DataAccess.ParamInfo

        Select Case targetType
            Case ストアドパラメータ型.GUID
                With newParameter
                    .Type = DbType.AnsiStringFixedLength
                    .Size = 36
                    .Value = CStr(_updateParam.Container(UpdateParam.項目名型.GUID_ストアド))
                    .Name = "GUID"
                End With

            Case ストアドパラメータ型.伝票番号
                With newParameter
                    .Direction = ParameterDirection.Output
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 10
                    .Scale = 0
                    .Value = 0
                    .Name = "RENBAN"
                End With
            Case ストアドパラメータ型.リターンコード1
                With newParameter
                    .Direction = ParameterDirection.Output
                    .Type = DbType.Decimal
                    .Size = 0
                    .Precision = 1
                    .Scale = 0
                    .Value = 0
                    .Name = "RETCD1"
                End With
            Case ストアドパラメータ型.リターンコード2
                With newParameter
                    .Direction = ParameterDirection.Output
                    .Type = DbType.String
                    .Size = 30
                    .Value = ""
                    .Name = "RETCD2"
                End With
            Case Else
                Throw New System.Exception("paramTypeパラメータ不正")
        End Select

        paramInfo.Add(newParameter)

    End Sub

#End Region
End Class
