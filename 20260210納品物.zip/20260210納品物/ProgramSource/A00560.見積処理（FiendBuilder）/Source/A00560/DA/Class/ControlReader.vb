﻿Public Class ControlReader
    Inherits DataHandlerBase
    Implements IControlReader

    Private _readSQLCreator As ReadSQLCreator

    Public Function ControlRead(ByVal targetTable As IControlReader.テーブル一覧型, ByVal param As ReadParam) As System.Data.DataTable Implements IControlReader.ControlRead

        SetUpDAC()

        Dim dt As New DataTable

        Using connection As DbConnection = OpenConnection()

            _readSQLCreator = New ReadSQLCreator
            _readSQLCreator.Initialize(Me, param)

            Select Case targetTable
                Case IControlReader.テーブル一覧型.コントロールテーブル
                    dt = ReadDataコントロールテーブル(connection, param)

                Case IControlReader.テーブル一覧型.日付管理テーブル
                    dt = ReadData日付管理テーブル(connection, param)

                Case IControlReader.テーブル一覧型.連番管理テーブル
                    dt = ReadData連番管理テーブル(connection, param)
            End Select

            CloseConnection(connection)
        End Using

        Return dt

        Return Nothing

    End Function

    Private Function ReadDataコントロールテーブル(ByVal connection As DbConnection, ByVal readParam As ReadParam) As DataTable

        Dim sql As String = ""
        Dim paramInfo As ParamInfoList = New ParamInfoList
        sql &= _readSQLCreator.MakeSQLコントロールテーブル

        Dim dt As New DataTable
        dt = DataAccess.GetDataTable(connection, sql, paramInfo)
        dt.TableName = IControlReader.テーブル一覧型.コントロールテーブル.ToString

        Return dt

    End Function

    Private Function ReadData日付管理テーブル(ByVal connection As DbConnection, ByVal readParam As ReadParam) As DataTable

        Dim sql As String = ""
        Dim paramInfo As ParamInfoList = New ParamInfoList
        sql &= _readSQLCreator.MakeSQL日付管理テーブル

        Dim dt As New DataTable
        dt = DataAccess.GetDataTable(connection, sql, paramInfo)
        dt.TableName = IControlReader.テーブル一覧型.日付管理テーブル.ToString

        Return dt

    End Function

    Private Function ReadData連番管理テーブル(ByVal connection As DbConnection, ByVal readParam As ReadParam) As DataTable

        Dim sql As String = ""
        Dim paramInfo As ParamInfoList = New ParamInfoList
        sql &= _readSQLCreator.MakeSQL連番管理テーブル

        Dim dt As New DataTable
        dt = DataAccess.GetDataTable(connection, sql, paramInfo)
        dt.TableName = IControlReader.テーブル一覧型.連番管理テーブル.ToString

        Return dt

    End Function

End Class
