﻿Public Class 更新情報型

#Region "列挙"

    Friend Enum データ区分型
        変更前
        変更後
    End Enum

#End Region

#Region "コンストラクタ"

    Public Sub New()
        _更新条件 = New DataTable

        _実行管理 = New DataTable
        _日付管理 = New DataTable

        For index As Integer = 0 To [Enum].GetNames(GetType(データ区分型)).Length
            _ワーク_ヘッダー(index) = New DataTable
            _見積ヘッダー(index) = New DataTable
            _ワーク_明細(index) = New DataTable
            _ワーク_サブ明細(index) = New DataTable  'A-CUST20241219
        Next

        _発行済管理更新日時 = 0

    End Sub

#End Region

#Region "プロパティ"

#Region "コントロールテーブル情報関連"

    Private _実行管理 As DataTable
    Friend Property 実行管理() As DataTable
        Get
            Return _実行管理
        End Get
        Set(ByVal value As DataTable)
            _実行管理 = value.Copy
        End Set
    End Property
    Friend Property 実行管理項目(ByVal columnName As String) As Object
        Get
            Return trimEnd(_実行管理.Rows(0).Item(columnName))
        End Get
        Set(ByVal value As Object)
            _実行管理.Rows(0).Item(columnName) = value
        End Set
    End Property

    Private _日付管理 As DataTable
    Friend Property 日付管理() As DataTable
        Get
            Return _日付管理
        End Get
        Set(ByVal value As DataTable)
            _日付管理 = value.Copy
        End Set
    End Property
    Friend Property 日付管理項目(ByVal columnName As String) As Object
        Get
            Return trimEnd(_日付管理.Rows(0).Item(columnName))
        End Get
        Set(ByVal value As Object)
            _日付管理.Rows(0).Item(columnName) = value
        End Set
    End Property
#End Region

#Region "条件関連"

    Private _更新条件 As DataTable
    Friend Property 更新条件() As DataTable
        Get
            Return _更新条件
        End Get
        Set(ByVal value As DataTable)
            _更新条件 = value.Copy
        End Set
    End Property
    Friend Property 更新条件項目(ByVal columnName As UpdateParam.更新条件型) As Object
        Get
            Return trimEnd(_更新条件.Rows(0).Item(columnName.ToString))
        End Get
        Set(ByVal value As Object)
            _更新条件.Rows(0).Item(columnName.ToString) = value
        End Set
    End Property

#End Region

#Region "伝票関連"

    Private _見積ヘッダー([Enum].GetNames(GetType(データ区分型)).Length) As DataTable
    Friend Property 見積ヘッダー(ByVal dataKubun As データ区分型) As DataTable
        Get
            Return _見積ヘッダー(dataKubun)
        End Get
        Set(ByVal value As DataTable)
            _見積ヘッダー(dataKubun) = value.Copy
        End Set
    End Property
    Friend Property 見積ヘッダー項目(ByVal dataKubun As データ区分型, ByVal columnName As String) As Object
        Get
            Return trimEnd(_見積ヘッダー(dataKubun).Rows(0).Item(columnName))
        End Get
        Set(ByVal value As Object)
            _見積ヘッダー(dataKubun).Rows(0).Item(columnName) = value
        End Set
    End Property

    Private _ワーク_ヘッダー([Enum].GetNames(GetType(データ区分型)).Length) As DataTable
    Friend Property ワーク_ヘッダー(ByVal dataKubun As データ区分型) As DataTable
        Get
            Return _ワーク_ヘッダー(dataKubun)
        End Get
        Set(ByVal value As DataTable)
            _ワーク_ヘッダー(dataKubun) = value.Copy
        End Set
    End Property
    Friend Property ワーク_ヘッダー項目(ByVal dataKubun As データ区分型, ByVal columnName As String) As Object
        Get
            Return trimEnd(_ワーク_ヘッダー(dataKubun).Rows(0).Item(columnName))
        End Get
        Set(ByVal value As Object)
            _ワーク_ヘッダー(dataKubun).Rows(0).Item(columnName) = value
        End Set
    End Property

    Private _ワーク_明細([Enum].GetNames(GetType(データ区分型)).Length) As DataTable
    Friend Property ワーク_明細(ByVal dataKubun As データ区分型) As DataTable
        Get
            Return _ワーク_明細(dataKubun)
        End Get
        Set(ByVal value As DataTable)
            _ワーク_明細(dataKubun) = value.Copy
        End Set
    End Property
    Friend Property ワーク_明細項目(ByVal dataKubun As データ区分型, ByVal rowIndex As Integer, ByVal columnName As String) As Object
        Get
            Return trimEnd(_ワーク_明細(dataKubun).Rows(rowIndex).Item(columnName))
        End Get
        Set(ByVal value As Object)
            _ワーク_明細(dataKubun).Rows(rowIndex).Item(columnName) = value
        End Set
    End Property

    'A-CUST20241219↓
    Private _ワーク_サブ明細([Enum].GetNames(GetType(データ区分型)).Length) As DataTable
    Friend Property ワーク_サブ明細(ByVal dataKubun As データ区分型) As DataTable
        Get
            Return _ワーク_サブ明細(dataKubun)
        End Get
        Set(ByVal value As DataTable)
            _ワーク_サブ明細(dataKubun) = value.Copy
        End Set
    End Property
    Friend Property ワーク_サブ明細項目(ByVal dataKubun As データ区分型, ByVal rowIndex As Integer, ByVal columnName As String) As Object
        Get
            Return trimEnd(_ワーク_サブ明細(dataKubun).Rows(rowIndex).Item(columnName))
        End Get
        Set(ByVal value As Object)
            _ワーク_サブ明細(dataKubun).Rows(rowIndex).Item(columnName) = value
        End Set
    End Property
    'A-CUST20241219↑

    Private _更新伝票番号 As Long
    Friend Property 更新伝票番号() As Long
        Get
            Return _更新伝票番号
        End Get
        Set(ByVal value As Long)
            _更新伝票番号 = value
        End Set
    End Property

    Private _発行済管理更新日時 As Long
    Friend Property 発行済管理更新日時() As Long
        Get
            Return _発行済管理更新日時
        End Get
        Set(ByVal value As Long)
            _発行済管理更新日時 = value
        End Set
    End Property

#End Region

#End Region

#Region "公開メソッド"

    ''' <summary>
    ''' データテーブルの作成
    ''' </summary>
    ''' <param name="dt"></param>
    ''' <param name="addColName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function MakeDataTable(ByVal dt As DataTable, ByVal addColName As String) As DataTable

        Dim getData As DataTable = dt.Copy
        Dim resultData As DataTable = New DataTable

        SetDataTableProperty(getData)

        For index As Integer = 0 To getData.Columns.Count - 1

            Dim dataType As System.Type = getData.Columns(index).DataType
            Dim columnName As String = getData.Columns(index).ColumnName
            Dim removeName As String = RemoveAliasName(columnName)

            If Strings.InStr(columnName, addColName) > 0 Then
                resultData.Columns.Add(New DataColumn(removeName, dataType))
            End If

        Next

        CreateAddRow(resultData)

        Return resultData

    End Function

    ''' <summary>
    ''' 取得データを指定された退避用テーブルに移送する
    ''' </summary>
    ''' <param name="getData">取得DataTable</param>
    ''' <param name="saveData">退避DataTable（※複数指定可）</param>
    ''' <remarks>個別移送（指定文字を元に行列毎に抜き出し、指定した退避DataTableへ移送）</remarks>
    Friend Overloads Sub SaveDataValue(ByVal getData As DataTable, ByRef saveData As IDictionary(Of String, DataTable))

        SetDataTableProperty(getData)

        For Each key As String In saveData.Keys
            saveData(key).Clear()
            For row As Integer = 0 To getData.Rows.Count - 1
                CreateAddRow(CType(saveData(key), DataTable))
                For col As Integer = 0 To getData.Columns.Count - 1
                    If Strings.InStr(getData.Columns.Item(col).ColumnName, key) > 0 Then
                        Dim colName As String = RemoveAliasName(getData.Columns(col).ColumnName)
                        saveData(key).Rows(row).Item(colName) = getData.Rows(row).Item(col)
                    End If
                Next
            Next
        Next

    End Sub

    ''' <summary>
    ''' データテーブルプロパティ設定
    ''' </summary>
    ''' <param name="targetDataTable"></param>
    ''' <remarks></remarks>
    Friend Sub SetDataTableProperty(ByRef targetDataTable As DataTable)

        For i As Integer = 0 To targetDataTable.Columns.Count - 1
            targetDataTable.Columns.Item(i).AllowDBNull = True      'Null値の許可
            targetDataTable.Columns.Item(i).ReadOnly = False        '読込専用の解除
        Next

    End Sub

#End Region

#Region "内部メソッド"

    Private Sub SetAddDefaultValue(ByRef targetDataTable As DataTable)

        For index As Integer = 0 To targetDataTable.Columns.Count - 1
            If targetDataTable.Columns(index).DataType Is GetType(String) Then
                targetDataTable.Columns(index).DefaultValue = ""
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Integer) Then
                targetDataTable.Columns(index).DefaultValue = 0
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Long) Then
                targetDataTable.Columns(index).DefaultValue = 0
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Decimal) Then
                targetDataTable.Columns(index).DefaultValue = 0
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Boolean) Then
                targetDataTable.Columns(index).DefaultValue = False
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Date) Then
                targetDataTable.Columns(index).DefaultValue = 0
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Object) Then
                targetDataTable.Columns(index).DefaultValue = Nothing
            End If
            If targetDataTable.Columns(index).DataType Is GetType(DataTable) Then
                targetDataTable.Columns(index).DefaultValue = New DataTable
            End If
            If targetDataTable.Columns(index).DataType Is GetType(IDictionary) Then
                targetDataTable.Columns(index).DefaultValue = Nothing
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Short) Then
                targetDataTable.Columns(index).DefaultValue = 0
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Single) Then
                targetDataTable.Columns(index).DefaultValue = 0
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Double) Then
                targetDataTable.Columns(index).DefaultValue = 0
            End If
        Next

    End Sub

    Friend Sub CreateAddRow(ByRef targetDataTable As DataTable)

        SetAddDefaultValue(targetDataTable)
        targetDataTable.Rows.Add(targetDataTable.NewRow)

    End Sub

    ''' <summary>
    ''' DBより取得した項目名より別名を除く
    ''' </summary>
    ''' <param name="targetName"></param>
    ''' <returns></returns>
    ''' <remarks>最初に見つかった"_"より前を別名とする。その文字以降を返す</remarks>
    Private Function RemoveAliasName(ByVal targetName As String) As String

        Dim startIndex As Integer = Strings.InStr(targetName, "_")
        Dim count As Integer = targetName.Length - startIndex

        Return targetName.Substring(startIndex, count)

    End Function

    ''' <summary>
    ''' 後ろの空白をカット
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    ''' <remarks>Stringタイプのみ対象。以外はそのまま返す</remarks>
    Private Function trimEnd(ByVal value As Object) As Object

        If value.GetType Is GetType(String) Then
            Return CStr(value).TrimEnd
        End If

        Return value

    End Function

#End Region

End Class
