﻿''' <summary>
''' 取引データ更新用
''' </summary>
''' <remarks></remarks>
Public Class DenpyouUpdater
    Inherits DataHandlerBase
    Implements IDenpyouUpdater

#Region "Const変数"

    'ストアド用Const変数
    'D-CUST20241219↓
    'Private Const INSERT_ストアド_取引登録 As String = "OSKCUS98A00500INS"
    'Private Const DELETE_ストアド_取引削除 As String = "OSKCUS98A00500DEL"
    'D-CUST20241219↑
    'A-CUST20241219↓
    Private Const INSERT_ストアド_取引登録 As String = "OSKCUS98A00550INS"
    Private Const DELETE_ストアド_取引削除 As String = "OSKCUS98A00550DEL"
    'A-CUST20241219↑

    Private Const DELETE_ストアド_ワーク削除 As String = "OSKCUS98WORKDEL"

#End Region

#Region "変数"

    Private _更新情報 As 更新情報型
    Private _updateSqlCreator As UpdateSQLCreator
    Private _readParam As ReadParam

    Private _システム日付 As Integer
    Private _システム時刻 As Decimal

#End Region

#Region "メソッド"

    ''' <summary>
    ''' ワークデータの更新
    ''' </summary>
    ''' <param name="targetDenpyou"></param>
    ''' <param name="mode"></param>
    ''' <param name="param"></param>
    ''' <param name="executeCheckInfo"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function DenpyouUpdate(ByVal targetDenpyou As IDenpyouUpdater.テーブル一覧型,
                                  ByVal mode As 処理区分型,
                                  ByVal param As UpdateParam,
                                  ByRef executeCheckInfo As IExecuteCheckInfo) As IResult Implements IDenpyouUpdater.DenpyouUpdate

        Initialize(Me.SettingInfo)

        SetUpDAC()

        Dim result As IResult

        Using connection As DbConnection = OpenConnection()

            _updateSqlCreator = New UpdateSQLCreator
            _updateSqlCreator.Initialize(Me, param)

            result = Execute伝票(connection, mode, param, executeCheckInfo)

        End Using

        Return result

    End Function

    ''' <summary>
    ''' 更新処理実行用メソッド
    ''' </summary>
    ''' <param name="connection">接続情報</param>
    ''' <param name="mode">処理区分</param>
    ''' <param name="param">更新項目</param>
    ''' <returns>更新結果</returns>
    ''' <remarks></remarks>
    Private Function Execute伝票(ByVal connection As DbConnection,
                                 ByVal mode As 処理区分型,
                                 ByVal param As UpdateParam,
                                 ByRef executeCheckInfo As IExecuteCheckInfo) As IResult

        Dim result As IResult = New Result

        Dim chkctrl As IExecuteControlerForUpdate = New ExecuteControlerForUpdate
        chkctrl.Initialize(Me)

        '条件の取得
        GetUpdateParam(mode, param)

        InitializeDateInfo()

        '各チェック処理
        result = ExecuteDoCheck(connection, mode, param)
        If result.結果 <> IResult.resultError.成功 Then GoTo Execute伝票_終了

        '排他チェック
        Select Case chkctrl.StartExecution(executeCheckInfo, CheckCondition.通常チェック)
            Case ExecuteCheckResult.成功

            Case ExecuteCheckResult.排他エラー
                result.結果 = IResult.resultError.同時実行不可
                GoTo Execute伝票_終了
        End Select

        '伝票更新処理[ワーク更新]
        result = DoWorkUpdate(connection, mode, param)
        If result.結果 <> IResult.resultError.成功 Then GoTo 更新終了

        'ストアド実行
        result = DoUpdate(connection, mode, param, chkctrl)
        If result.結果 <> IResult.resultError.成功 Then GoTo 更新終了

更新終了:
        If result.結果 = IResult.resultError.成功 Then
            chkctrl.EndExecution()
        End If

        chkctrl.Release()


Execute伝票_終了:

        CloseConnection(connection)

        If result.結果 = IResult.resultError.成功 Then
            If mode <> 処理区分型.削除 Then
                result.詳細情報追加(IResult.resultSucceed.伝票番号.ToString, _更新情報.更新伝票番号)
                result.詳細情報追加(IResult.resultSucceed.発行済管理更新日時.ToString, _更新情報.発行済管理更新日時)
            End If
        End If

        Return result

    End Function

    ''' <summary>
    ''' 各チェック処理
    ''' </summary>
    ''' <param name="connection">接続情報</param>
    ''' <param name="mode">処理区分</param>
    ''' <param name="param">更新項目</param>
    ''' <returns>更新結果</returns>
    ''' <remarks></remarks>
    Private Function ExecuteDoCheck(ByVal connection As DbConnection,
                                    ByVal mode As 処理区分型,
                                    ByVal param As UpdateParam) As IResult

        Dim result As IResult = New Result

        '日付変更チェック
        result = 日付変更チェック(connection, mode)
        If result.結果 <> IResult.resultError.成功 Then Return result

        '各マスターの存在チェック
        If mode <> 処理区分型.削除 Then
            result = Checkマスター(connection, mode, 更新情報型.データ区分型.変更後)
            If result.結果 <> IResult.resultError.成功 Then Return result
        End If

        '見積ヘッダーテーブルの読込
        If mode <> 処理区分型.登録 Then
            Dim DenpyouNo As Long
            DenpyouNo = CLng(_更新情報.更新条件項目(UpdateParam.更新条件型.伝票番号))
            result = ReadData(Nothing, connection, 読込種類型.見積ヘッダー, DenpyouNo)
            If result.結果 <> IResult.resultError.成功 Then Return result
        End If

        'D-CUST20210707 ↓
        ''更新番号チェック
        'If mode <> 処理区分型.登録 Then
        '    If CDec(_更新情報.見積ヘッダー項目(更新情報型.データ区分型.変更前, "CUSRE11999")) <> CDec(_更新情報.更新条件項目(UpdateParam.更新条件型.更新番号)) Then
        '        result.結果 = IResult.resultError.他で更新済
        '        result.エラー番号追加(IResult.resultError.他で更新済.ToString, 61)
        '        Return result
        '    End If
        'End If
        'D-CUST20210707 ↑ 

        '発行済管理更新日時の取得
        If mode = 処理区分型.修正 Then
            Dim DenpyouNo As Long
            DenpyouNo = CLng(_更新情報.更新条件項目(UpdateParam.更新条件型.伝票番号))
            result = ReadData(Nothing, connection, 読込種類型.発行済管理テーブル, DenpyouNo)
            If result.結果 <> IResult.resultError.成功 Then Return result
        End If

        Return result
    End Function

    ''' <summary>
    ''' 更新処理
    ''' </summary>
    ''' <param name="connection">接続情報</param>
    ''' <param name="mode">処理区分</param>
    ''' <param name="param">更新項目</param>
    ''' <returns>更新結果</returns>
    ''' <remarks></remarks>
    Private Function DoWorkUpdate(ByVal connection As DbConnection,
                                  ByVal mode As 処理区分型,
                                  ByVal param As UpdateParam) As IResult

        Dim result As IResult = New Result

        Using transaction As DbTransaction = DataAccess.BeginTransaction(connection)

            '***伝票更新処理[ワーク更新]***

            '<--- 更新用テーブル編集 --->
            Call SetDataワーク_ヘッダー(mode)
            Call SetDataワーク_明細(mode)

            '<--- 更新処理 --->

            'ワーク(ヘッダー)登録
            result = InsertData(transaction, param, 登録種類型.ワーク_ヘッダー, _更新情報.ワーク_ヘッダー(更新情報型.データ区分型.変更後))
            If result.結果 <> IResult.resultError.成功 Then GoTo 更新終了

            'ワーク(明細)登録
            For rowIndex As Integer = 0 To CInt(_更新情報.更新条件項目(UpdateParam.更新条件型.明細行数)) - 1
                Dim newDT As DataTable = _更新情報.ワーク_明細(更新情報型.データ区分型.変更後).Select("CUSWE01005 = " & rowIndex + 1).CopyToDataTable
                result = InsertData(transaction, param, 登録種類型.ワーク_明細, newDT)
                If result.結果 <> IResult.resultError.成功 Then GoTo 更新終了
            Next

            'A-CUST20241219↓
            'ワーク(サブ明細)登録
            For rowIndex As Integer = 0 To _更新情報.ワーク_サブ明細(更新情報型.データ区分型.変更後).Rows.Count - 1
                Dim newDT As DataTable = _更新情報.ワーク_サブ明細(更新情報型.データ区分型.変更後).Select("CUSWE01005 = " & rowIndex + 1).CopyToDataTable
                result = InsertData(transaction, param, 登録種類型.ワーク_サブ明細, newDT)
                If result.結果 <> IResult.resultError.成功 Then GoTo 更新終了
            Next
            'A-CUST20241219↑

更新終了:
            If result.結果 = IResult.resultError.成功 Then
                DataAccess.CommitTransaction(transaction)
            Else
                DataAccess.RollbackTransaction(transaction)
            End If


        End Using

        Return result

    End Function

    ''' <summary>
    ''' 更新処理
    ''' </summary>
    ''' <param name="connection">接続情報</param>
    ''' <param name="mode">処理区分</param>
    ''' <param name="param">更新項目</param>
    ''' <returns>更新結果</returns>
    ''' <remarks></remarks>
    Private Function DoUpdate(ByVal connection As DbConnection,
                              ByVal mode As 処理区分型,
                              ByVal param As UpdateParam,
                              ByRef chkctrl As IExecuteControlerForUpdate) As IResult

        Dim result As IResult = New Result

        Using transaction As DbTransaction = DataAccess.BeginTransaction(connection)

            '連番管理テーブルの排他ロック
            DataAccess.SetLockTimeOut(transaction)
            DataAccess.LockTable(transaction, "CUS98CE21RENBAN", LockMode.Exclusive, False)

            'A-CUST20210707 ↓ 
            '更新番号チェック
            If mode <> 処理区分型.登録 Then
                Dim DenpyouNo As Long
                DenpyouNo = CLng(_更新情報.更新条件項目(UpdateParam.更新条件型.伝票番号))
                result = ReadData(transaction, connection, 読込種類型.見積ヘッダー, DenpyouNo)
                If result.結果 <> IResult.resultError.成功 Then GoTo ストアド実行

                If CDec(_更新情報.見積ヘッダー項目(更新情報型.データ区分型.変更前, "CUSRE11999")) <> CDec(_更新情報.更新条件項目(UpdateParam.更新条件型.更新番号)) Then
                    result.結果 = IResult.resultError.他で更新済
                    result.エラー番号追加(IResult.resultError.他で更新済.ToString, 61)
                    GoTo ストアド実行
                End If
            End If
            'A-CUST20210707 ↑ 

            'ストアド実行
            If mode <> 処理区分型.登録 Then
                result = Updateストアド(transaction, param, DELETE_ストアド_取引削除)
                If result.結果 <> IResult.resultError.成功 Then GoTo 更新終了
            End If

            If mode <> 処理区分型.削除 Then
                result = Updateストアド(transaction, param, INSERT_ストアド_取引登録)
                If result.結果 <> IResult.resultError.成功 Then GoTo 更新終了
            End If

            result = Updateストアド(transaction, param, DELETE_ストアド_ワーク削除)
            If result.結果 <> IResult.resultError.成功 Then GoTo 更新終了

更新終了:
            If result.結果 = IResult.resultError.成功 Then
                DataAccess.CommitTransaction(transaction)
            Else
                DataAccess.RollbackTransaction(transaction)
            End If

            'A-CUST20210707 ↓ 
            '正常時はここで終了
            Return result
ストアド実行：
            Dim resultstd As IResult = New Result
            resultstd = Updateストアド(transaction, param, DELETE_ストアド_ワーク削除)
            If resultstd.結果 = IResult.resultError.成功 Then
                DataAccess.CommitTransaction(transaction)
            Else
                DataAccess.RollbackTransaction(transaction)
            End If
            'A-CUST20210707 ↑ 

        End Using

        Return result

    End Function

#End Region

#Region "各種チェック処理"

    Private Function 日付変更チェック(ByVal Connection As DbConnection, ByVal mode As 処理区分型) As IResult

        Dim result As IResult = New Result

        result.結果 = IResult.resultError.想定された失敗

        Dim readKeys As New List(Of Object)
        result = ReadData(Nothing, Connection, 読込種類型.日付管理テーブル, readKeys.ToArray)

        '当期期首月日取得
        If result.結果 <> IResult.resultError.成功 Then
            GoTo 日付変更チェック_Error
        End If
        If CInt(_更新情報.更新条件項目(UpdateParam.更新条件型.当期期首年月日)) <> CInt(_更新情報.日付管理項目("CUSCE11002")) Then
            GoTo 日付変更チェック_Error
        End If

日付変更チェック_End:

        result.結果 = IResult.resultError.成功
        Return result

日付変更チェック_Error:

        result.結果 = IResult.resultError.日付変更エラー
        result.エラー番号追加(IResult.resultError.日付変更エラー.ToString, 59)
        Return result

    End Function

    ''' <summary>
    ''' マスターチェック
    ''' </summary>
    ''' <param name="connection">接続情報</param>
    ''' <param name="mode">処理区分</param>
    ''' <param name="データ区分">データ区分</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function Checkマスター(ByVal connection As DbConnection,
                                   ByVal mode As 処理区分型,
                                   ByVal データ区分 As 更新情報型.データ区分型) As IResult

        Dim readKeys As New List(Of Object)

        Dim result As IResult = New Result
        Dim errorMessage(IResult.messageConnect.後尾) As String
        For index As Integer = 0 To errorMessage.Length - 1
            errorMessage(index) = ""
        Next

        result.結果 = IResult.resultError.想定された失敗

        '得意先マスター
        With readKeys
            .Clear()
            .Add(_更新情報.ワーク_ヘッダー項目(データ区分, "CHECK001"))
        End With
        result = ReadData(Nothing, connection, 読込種類型.得意先, readKeys.ToArray)
        If result.結果 <> IResult.resultError.成功 Then
            errorMessage(IResult.messageConnect.後尾) &= vbCrLf & "得意先コード：" & CStr(readKeys.Item(0))
            GoTo Checkマスター_Error
        End If

        '担当者マスター
        With readKeys
            .Clear()
            .Add(_更新情報.ワーク_ヘッダー項目(データ区分, "CHECK002"))
        End With
        result = ReadData(Nothing, connection, 読込種類型.担当者, readKeys.ToArray)
        If result.結果 <> IResult.resultError.成功 Then
            errorMessage(IResult.messageConnect.後尾) &= vbCrLf & "担当者コード：" & CStr(readKeys.Item(0))
            GoTo Checkマスター_Error
        End If

        '部門マスター
        With readKeys
            .Clear()
            .Add(_更新情報.ワーク_ヘッダー項目(データ区分, "CHECK003"))
        End With
        result = ReadData(Nothing, connection, 読込種類型.部門, readKeys.ToArray)
        If result.結果 <> IResult.resultError.成功 Then
            errorMessage(IResult.messageConnect.後尾) &= vbCrLf & "部門コード：" & CStr(readKeys.Item(0))
            GoTo Checkマスター_Error
        End If

        '区分マスター[消費税]
        With readKeys
            .Clear()
            .Add(Get区分マスター種別値(区分マスター型.消費税区分))
            .Add(_更新情報.ワーク_ヘッダー項目(データ区分, "CHECK004"))
        End With
        result = ReadData(Nothing, connection, 読込種類型.区分, readKeys.ToArray)
        If result.結果 <> IResult.resultError.成功 Then
            errorMessage(IResult.messageConnect.後尾) &= vbCrLf & "消費税区分：" & CStr(readKeys.Item(1))
            GoTo Checkマスター_Error
        End If

        For rowIndex As Integer = 0 To CInt(_更新情報.更新条件項目(UpdateParam.更新条件型.明細行数)) - 1

            errorMessage(IResult.messageConnect.後尾) = CStr(_更新情報.ワーク_明細項目(データ区分, rowIndex, "CUSWE01005")).PadLeft(2) & "行目"

            '区分マスター[区分]
            Dim kbn As String = CStr(_更新情報.ワーク_明細項目(データ区分, rowIndex, "CHECK001"))
            With readKeys
                .Clear()
                .Add(Get区分マスター種別値(区分マスター型.区分))
                .Add(kbn)
            End With
            result = ReadData(Nothing, connection, 読込種類型.区分, readKeys.ToArray)
            If result.結果 <> IResult.resultError.成功 Then
                errorMessage(IResult.messageConnect.後尾) &= vbCrLf & "行区分：" & CStr(readKeys.Item(1))
                GoTo Checkマスター_Error
            End If

            Dim shohinCode As String = CStr(_更新情報.ワーク_明細項目(データ区分, rowIndex, "CHECK002"))
            If Not shohinCode.TrimEnd.Equals("") Then
                '商品マスター
                With readKeys
                    .Clear()
                    .Add(shohinCode)
                End With
                result = ReadData(Nothing, connection, 読込種類型.商品, readKeys.ToArray)
                If result.結果 <> IResult.resultError.成功 Then
                    errorMessage(IResult.messageConnect.後尾) &= vbCrLf & "商品コード：" & CStr(readKeys.Item(0))
                    GoTo Checkマスター_Error
                End If
            End If

            '区分マスター[課税区分]
            Dim kazeikbn As String = CStr(_更新情報.ワーク_明細項目(データ区分, rowIndex, "CHECK004"))
            If Not kazeikbn.TrimEnd.Equals("") Then
                With readKeys
                    .Clear()
                    .Add(Get区分マスター種別値(区分マスター型.課税区分))
                    .Add(kazeikbn)
                End With
                result = ReadData(Nothing, connection, 読込種類型.区分, readKeys.ToArray)
                If result.結果 <> IResult.resultError.成功 Then
                    errorMessage(IResult.messageConnect.後尾) &= vbCrLf & "課税区分：" & CStr(readKeys.Item(1))
                    GoTo Checkマスター_Error
                End If
            End If

            '倉庫マスター
            Dim sokoCode As String = CStr(_更新情報.ワーク_明細項目(データ区分, rowIndex, "CHECK003"))
            If Not sokoCode.TrimEnd.Equals("") Then
                With readKeys
                    .Clear()
                    .Add(sokoCode)
                End With
                result = ReadData(Nothing, connection, 読込種類型.倉庫, readKeys.ToArray)
                If result.結果 <> IResult.resultError.成功 Then
                    errorMessage(IResult.messageConnect.後尾) &= vbCrLf & "倉庫コード：" & CStr(readKeys.Item(0))
                    GoTo Checkマスター_Error
                End If
            End If

        Next

        'A-CUST20241219↓
        For rowIndex As Integer = 0 To _更新情報.ワーク_サブ明細(データ区分).Rows.Count - 1
            Dim 行番号 As String = "明細部" & CStr(_更新情報.ワーク_サブ明細項目(データ区分, rowIndex, "CHECK001")).PadLeft(3) & "行目" &
                                   "-サブ明細部" & CStr(_更新情報.ワーク_サブ明細項目(データ区分, rowIndex, "CHECK002")).PadLeft(3) & "行目"
            errorMessage(IResult.messageConnect.後尾) = vbCrLf & 行番号
            Dim shohinCode As String = CStr(_更新情報.ワーク_サブ明細項目(データ区分, rowIndex, "CHECK003"))
            If Not shohinCode.TrimEnd.Equals("") Then
                '商品マスター
                With readKeys
                    .Clear()
                    .Add(shohinCode)
                End With
                result = ReadData(Nothing, connection, 読込種類型.商品, readKeys.ToArray)
                If result.結果 <> IResult.resultError.成功 Then
                    errorMessage(IResult.messageConnect.後尾) &= vbCrLf & "商品コード：" & CStr(readKeys.Item(0))
                    GoTo Checkマスター_Error
                End If
            End If

        Next
        'A-CUST20241219↑

Checkマスター_End:

        result.結果 = IResult.resultError.成功
        Return result

Checkマスター_Error:

        result.結果 = IResult.resultError.マスター無し
        result.エラー番号追加(IResult.resultError.マスター無し.ToString, 113)
        result.エラー情報追加(IResult.resultError.マスター無し.ToString, errorMessage(IResult.messageConnect.先頭), IResult.messageConnect.先頭)
        result.エラー情報追加(IResult.resultError.マスター無し.ToString, errorMessage(IResult.messageConnect.後尾), IResult.messageConnect.後尾)
        Return result

    End Function

#End Region

#Region "各テーブル情報取得処理"

    Private Enum 読込種類型
        得意先
        担当者
        部門
        区分
        倉庫
        商品
        見積ヘッダー
        日付管理テーブル
        発行済管理テーブル
        納品先    'A-CUST20201013
    End Enum

    ''' <summary>
    ''' 情報取得処理
    ''' </summary>
    ''' <param name="transaction">トランザクション情報</param>
    ''' <param name="connection">接続情報</param>
    ''' <param name="読込種類">読込種類</param>
    ''' <param name="readerParam">読込用情報</param>
    ''' <returns>エラー情報</returns>
    ''' <remarks></remarks>
    Private Function ReadData(ByVal transaction As DbTransaction,
                              ByVal connection As DbConnection,
                              ByVal 読込種類 As 読込種類型,
                              ByVal ParamArray readerParam() As Object) As IResult

        Dim result As IResult = New Result
        Dim paramInfo As ParamInfoList = New ParamInfoList

        Dim readSqlCreator As ReadSQLCreator
        readSqlCreator = New ReadSQLCreator

        'パラメータ設定
        Dim param As New ReadParam
        Select Case 読込種類
            Case 読込種類型.得意先
                param.Container(ReadParam.項目名型.得意先コード) = CStr(readerParam(0))
            Case 読込種類型.担当者
                param.Container(ReadParam.項目名型.担当者コード) = CStr(readerParam(0))
            Case 読込種類型.部門
                param.Container(ReadParam.項目名型.部門コード) = CStr(readerParam(0))
            Case 読込種類型.倉庫
                param.Container(ReadParam.項目名型.倉庫コード) = CStr(readerParam(0))
            Case 読込種類型.区分
                param.Container(ReadParam.項目名型.種別) = CStr(readerParam(0))
                param.Container(ReadParam.項目名型.区分コード) = CStr(readerParam(1))
            Case 読込種類型.商品
                param.Container(ReadParam.項目名型.商品コード) = CStr(readerParam(0))
            Case 読込種類型.見積ヘッダー
                param.Container(ReadParam.項目名型.伝票番号) = CLng(readerParam(0))
            Case 読込種類型.発行済管理テーブル
                param.Container(ReadParam.項目名型.伝票番号) = CLng(readerParam(0))
            Case 読込種類型.日付管理テーブル
                'A-CUST20201013↓
            Case 読込種類型.納品先
                param.Container(ReadParam.項目名型.得意先コード) = CStr(readerParam(0))
                param.Container(ReadParam.項目名型.納品先コード) = CStr(readerParam(1))
                'A-CUST20201013↑
            Case Else
        End Select

        readSqlCreator.Initialize(Me, param)

        'SQL作成
        Dim sql As String = ""
        Select Case 読込種類
            Case 読込種類型.得意先
                sql = readSqlCreator.MakeSQL得意先マスター(paramInfo)
            Case 読込種類型.担当者
                sql = readSqlCreator.MakeSQL担当者マスター(paramInfo)
            Case 読込種類型.部門
                sql = readSqlCreator.MakeSQL部門マスター(paramInfo)
            Case 読込種類型.倉庫
                sql = readSqlCreator.MakeSQL倉庫マスター(paramInfo)
            Case 読込種類型.区分
                sql = readSqlCreator.MakeSQL区分マスター(paramInfo)
            Case 読込種類型.商品
                sql = readSqlCreator.MakeSQL商品マスター(paramInfo)
            Case 読込種類型.見積ヘッダー
                sql = readSqlCreator.MakeSQL見積ヘッダー(paramInfo)
            Case 読込種類型.発行済管理テーブル
                sql = readSqlCreator.MakeSQL発行済管理テーブル(paramInfo)
            Case 読込種類型.日付管理テーブル
                sql = readSqlCreator.MakeSQL日付管理テーブル()
                'A-CUST20201013↓
            Case 読込種類型.納品先
                sql = readSqlCreator.MakeSQL納品先マスター(paramInfo)
                'A-CUST20201013↑
        End Select


        'ロックタイムアウトの設定
        Select Case 読込種類
                Case 読込種類型.見積ヘッダー
                    If transaction Is Nothing Then
                        DataAccess.SetLockTimeOut(connection, 0)
                    Else
                        DataAccess.SetLockTimeOut(transaction, 0)
                    End If
            End Select

            Dim dt As New DataTable
            If transaction Is Nothing Then
                dt = DataAccess.GetDataTable(connection, sql, paramInfo)
            Else
                dt = DataAccess.GetDataTable(transaction, sql, paramInfo)
            End If

            If dt.Rows.Count > 0 Then
                result.結果 = IResult.resultError.成功

                _更新情報.SetDataTableProperty(dt)

            'データ受取
            Select Case 読込種類
                Case 読込種類型.見積ヘッダー
                    _更新情報.見積ヘッダー(更新情報型.データ区分型.変更前) = dt
                Case 読込種類型.発行済管理テーブル
                    _更新情報.発行済管理更新日時 = CLng(dt.Rows(0).Item("CUSRE91008"))
                Case 読込種類型.日付管理テーブル
                    _更新情報.日付管理 = dt
            End Select
        Else
                Select Case 読込種類
                    Case 読込種類型.発行済管理テーブル
                        _更新情報.発行済管理更新日時 = 0
                    Case Else
                        result.結果 = IResult.resultError.レコード無し
                        result.エラー番号追加(IResult.resultError.レコード無し.ToString, 60)
                End Select
            End If


            Return result

    End Function

#End Region

#Region "各テーブル情報登録処理"

    Private Enum 登録種類型
        ワーク_ヘッダー
        ワーク_明細
        ワーク_サブ明細    'A-CUST20241219
    End Enum

    ''' <summary>
    ''' 登録処理
    ''' </summary>
    ''' <param name="transaction">トランザクション情報</param>
    ''' <param name="param">パラメータ</param>
    ''' <param name="登録種類">登録種類</param>
    ''' <param name="inserterParam">登録用情報</param>
    ''' <returns>エラー情報</returns>
    ''' <remarks></remarks>
    Private Function InsertData(ByVal transaction As DbTransaction,
                                ByVal param As UpdateParam,
                                ByVal 登録種類 As 登録種類型,
                                ByVal ParamArray inserterParam() As Object) As IResult

        Dim result As IResult = New Result
        Dim paramInfo As ParamInfoList = New ParamInfoList

        'パラメータ設定
        Select Case 登録種類
            Case 登録種類型.ワーク_ヘッダー, 登録種類型.ワーク_明細
                param.Container(UpdateParam.項目名型.ワーク情報) = CType(inserterParam(0), DataTable)
                'A-CUST20241219↓
            Case 登録種類型.ワーク_サブ明細
                param.Container(UpdateParam.項目名型.ワーク情報) = CType(inserterParam(0), DataTable)
                'A-CUST20241219↑
        End Select

        'SQL作成
        Dim sql As String = ""
        Select Case 登録種類
            Case 登録種類型.ワーク_ヘッダー, 登録種類型.ワーク_明細
                sql = _updateSqlCreator.MakeSQLInsertワーク(paramInfo)
                'A-CUST20241219↓
            Case 登録種類型.ワーク_サブ明細
                sql = _updateSqlCreator.MakeSQLInsertワーク(paramInfo)
                'A-CUST20241219↑
        End Select

        DataAccess.ExecuteNonQuery(transaction, sql, paramInfo)
        result.結果 = IResult.resultError.成功

        Return result

    End Function

#End Region

#Region "更新情報取得"

    ''' <summary>
    ''' 更新条件の取得
    ''' </summary>
    ''' <param name="mode">処理区分</param>
    ''' <param name="param">更新項目</param>
    ''' <remarks></remarks>
    Private Sub GetUpdateParam(ByVal mode As 処理区分型,
                               ByVal param As UpdateParam)

        _readParam = New ReadParam

        _更新情報 = New 更新情報型

        _更新情報.更新条件 = CType(param.Container(UpdateParam.項目名型.更新条件), DataTable)

        _更新情報.ワーク_ヘッダー(更新情報型.データ区分型.変更後) = CType(param.Container(UpdateParam.項目名型.ワーク_ヘッダー), DataTable)
        _更新情報.ワーク_明細(更新情報型.データ区分型.変更後) = CType(param.Container(UpdateParam.項目名型.ワーク_明細), DataTable)
        _更新情報.ワーク_サブ明細(更新情報型.データ区分型.変更後) = CType(param.Container(UpdateParam.項目名型.ワーク_サブ明細), DataTable) 'A-CUST20241219

        If mode <> 処理区分型.登録 Then
            _更新情報.更新伝票番号 = CLng(_更新情報.更新条件項目(UpdateParam.更新条件型.伝票番号))
        End If

    End Sub

    ''' <summary>
    ''' 日付情報の初期処理
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub InitializeDateInfo()

        Dim システム日付時刻 As DateTime = DateTime.Now
        _システム日付 = CInt(システム日付時刻.ToString("yyyyMMdd"))
        _システム時刻 = CDec(システム日付時刻.ToString("yyyyMMddHHmmss"))

    End Sub

    ''' <summary>
    ''' ヘッダー情報の設定
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetDataワーク_ヘッダー(ByVal mode As 処理区分型)

        If mode = 処理区分型.登録 Then
            '_更新情報.ワーク_ヘッダー項目(更新情報型.データ区分型.変更後, "CUSWE01995") = _システム時刻     'D-CUST20220425
            _更新情報.ワーク_ヘッダー項目(更新情報型.データ区分型.変更後, "CUSWE01INS") = _システム時刻      'A-CUST20220425
        End If
        '_更新情報.ワーク_ヘッダー項目(更新情報型.データ区分型.変更後, "CUSWE01998") = _システム時刻     'D-CUST20220425
        _更新情報.ワーク_ヘッダー項目(更新情報型.データ区分型.変更後, "CUSWE01UPD") = _システム時刻      'A-CUST20241219

    End Sub

    ''' <summary>
    ''' 明細情報の設定
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub SetDataワーク_明細(ByVal mode As 処理区分型)

        For rowIndex As Integer = 0 To CInt(_更新情報.更新条件項目(UpdateParam.更新条件型.明細行数)) - 1
            'D-CUST20220425↓
            'If Val(_更新情報.ワーク_明細項目(更新情報型.データ区分型.変更後, rowIndex, "CUSWE01995")) = -1 Then
            '    _更新情報.ワーク_明細項目(更新情報型.データ区分型.変更後, rowIndex, "CUSWE01995") = _システム時刻
            'D-CUST20220425↑
            'A-CUST20220425↓
            If Val(_更新情報.ワーク_明細項目(更新情報型.データ区分型.変更後, rowIndex, "CUSWE01INS")) = -1 Then
                _更新情報.ワーク_明細項目(更新情報型.データ区分型.変更後, rowIndex, "CUSWE01INS") = _システム時刻
                'A-CUST20220425↑
            End If
            '_更新情報.ワーク_明細項目(更新情報型.データ区分型.変更後, rowIndex, "CUSWE01998") = CLng(_更新情報.ワーク_ヘッダー項目(更新情報型.データ区分型.変更後, "CUSWE01998"))     'D-CUST20220425
            _更新情報.ワーク_明細項目(更新情報型.データ区分型.変更後, rowIndex, "CUSWE01UPD") = CLng(_更新情報.ワーク_ヘッダー項目(更新情報型.データ区分型.変更後, "CUSWE01UPD"))       'A-CUST20241219

        Next

        'A-CUST20241219↓
        'サブ明細
        For rowIndex As Integer = 0 To _更新情報.ワーク_サブ明細(更新情報型.データ区分型.変更後).Rows.Count - 1
            If Val(_更新情報.ワーク_サブ明細項目(更新情報型.データ区分型.変更後, rowIndex, "CUSWE01INS")) = -1 Then
                _更新情報.ワーク_サブ明細項目(更新情報型.データ区分型.変更後, rowIndex, "CUSWE01INS") = _システム時刻
            End If
            _更新情報.ワーク_サブ明細項目(更新情報型.データ区分型.変更後, rowIndex, "CUSWE01UPD") = CLng(_更新情報.ワーク_ヘッダー項目(更新情報型.データ区分型.変更後, "CUSWE01UPD"))
        Next
        'A-CUST20241219↑

    End Sub

#End Region

#Region "各ストアド更新処理"

    ''' <summary>
    ''' ストアド更新処理
    ''' </summary>
    ''' <param name="transaction">トランザクション情報</param>
    ''' <param name="param">パラメータ</param>
    ''' <param name="storedName">ストアド名</param>
    ''' <returns>エラー情報</returns>
    ''' <remarks></remarks>
    Private Function Updateストアド(ByVal transaction As DbTransaction,
                                    ByVal param As UpdateParam,
                                    ByVal storedName As String) As IResult

        Dim result As IResult = New Result
        Dim paramInfo As ParamInfoList = New ParamInfoList

        Dim データ区分 As 更新情報型.データ区分型 = 更新情報型.データ区分型.変更後

        Select Case storedName
            Case INSERT_ストアド_取引登録

                'ストアド引渡パラメータ設定
                With param
                    .Container(UpdateParam.項目名型.GUID_ストアド) = CStr(_更新情報.ワーク_ヘッダー項目(データ区分, "CUSWE01001"))
                End With

                _updateSqlCreator.MakeParameter伝票ストアド_登録(paramInfo)

            Case DELETE_ストアド_取引削除

                'ストアド引渡パラメータ設定
                With param
                    .Container(UpdateParam.項目名型.GUID_ストアド) = CStr(_更新情報.ワーク_ヘッダー項目(データ区分, "CUSWE01001"))
                End With

                _updateSqlCreator.MakeParameter伝票ストアド_削除(paramInfo)


            Case DELETE_ストアド_ワーク削除

                'ストアド引渡パラメータ設定
                With param
                    .Container(UpdateParam.項目名型.GUID_ストアド) = CStr(_更新情報.ワーク_ヘッダー項目(データ区分, "CUSWE01001"))
                End With

                _updateSqlCreator.MakeParameterワークストアド(paramInfo)

        End Select

        DataAccess.ExecuteStoredProcedure(transaction, storedName, paramInfo)
        Select Case CInt(Getパラメータ(paramInfo, "RETCD1", 属性.数値))
            Case 0
                result.結果 = IResult.resultError.成功
                Select Case storedName
                    Case INSERT_ストアド_取引登録
                        _更新情報.更新伝票番号 = CLng(Getパラメータ(paramInfo, "RENBAN", 属性.数値))
                End Select
            Case Else
                Dim errorMessage As String = ""
                errorMessage &= storedName & Space(5)
                errorMessage &= CStr(Getパラメータ(paramInfo, "RETCD2", 属性.文字))
                HandleStoredProcedureError(errorMessage)
        End Select

        Return result

    End Function

#End Region

#Region "内部メソッド"

    Private Enum 属性 As Integer
        文字
        数値
    End Enum

    ''' <summary>
    ''' パラメータ内容を取得する
    ''' </summary>
    ''' <param name="paramInfo">パラメータ配列</param>
    ''' <param name="取得項目名">取得したい項目名</param>
    ''' <param name="取得項目属性">取得したい項目の属性</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function Getパラメータ(ByVal paramInfo As ParamInfoList,
                                   ByVal 取得項目名 As String,
                                   ByVal 取得項目属性 As 属性) As Object

        Dim パラメータ名 As String = ""

        Dim 取得パラメータ As Object = Nothing
        Select Case 取得項目属性
            Case 属性.文字
                取得パラメータ = ""
            Case 属性.数値
                取得パラメータ = 0
        End Select

        For index As Integer = 0 To paramInfo.Count - 1
            パラメータ名 = paramInfo(index).Name.Trim
            If Left(パラメータ名, 1) = "@" Then
                パラメータ名 = Mid(パラメータ名, 2, パラメータ名.Length - 1)
            End If
            If パラメータ名.Trim = 取得項目名.Trim Then
                取得パラメータ = paramInfo(index).Value
                Exit For
            End If
        Next

        Return 取得パラメータ

    End Function

    Private Function Get区分マスター種別値(ByVal 区分 As 区分マスター型) As String

        Return String.Format("{0:D4}", CInt(区分))

    End Function

#End Region

End Class
