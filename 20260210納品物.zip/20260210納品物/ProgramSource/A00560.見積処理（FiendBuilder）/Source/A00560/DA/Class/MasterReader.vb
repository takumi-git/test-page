﻿Public Class MasterReader
    Inherits DataHandlerBase
    Implements IMasterReader

    Private _readSQLCreator As ReadSQLCreator

#Region "Const変数"

    'ストアド用Const変数
    Private Const READ_ストアド_倉庫別在庫数 As String = "OSKCUS98INVENTORYNUMBER"

#End Region

#Region "公開メソッド"

    Overloads Function MasterRead(ByVal targetMaster As IMasterReader.テーブル一覧型, ByVal param As ReadParam) As System.Data.DataTable Implements IMasterReader.MasterRead

        SetUpDAC()

        Dim resultDataTable As New DataTable

        Using connection As DbConnection = OpenConnection()

            _readSQLCreator = New ReadSQLCreator
            _readSQLCreator.Initialize(Me, param)

            Select Case targetMaster
                Case IMasterReader.テーブル一覧型.得意先マスター
                    resultDataTable = ReadData得意先マスター(connection)

                Case IMasterReader.テーブル一覧型.商品マスター
                    resultDataTable = ReadData商品マスター(connection)

                Case IMasterReader.テーブル一覧型.担当者マスター
                    resultDataTable = ReadData担当者マスター(connection)

                Case IMasterReader.テーブル一覧型.部門マスター
                    resultDataTable = ReadData部門マスター(connection)

                Case IMasterReader.テーブル一覧型.区分マスター
                    resultDataTable = ReadData区分マスター(connection)

                Case IMasterReader.テーブル一覧型.倉庫マスター
                    resultDataTable = ReadData倉庫マスター(connection)

                Case IMasterReader.テーブル一覧型.発行済管理テーブル
                    resultDataTable = ReadData発行済管理テーブル(connection)

                    'A-CUST20201013↓
                Case IMasterReader.テーブル一覧型.納品先マスター
                    resultDataTable = ReadData納品先マスター(connection)
                    'A-CUST20201013↑
            End Select

            CloseConnection(connection)
        End Using

        Return resultDataTable

    End Function

    Overloads Function MasterRead(ByVal targetMaster As IMasterReader.取得項目型, ByVal param As ReadParam) As Object Implements IMasterReader.MasterRead

        SetUpDAC()

        Dim resultValue As New Object

        Using connection As DbConnection = OpenConnection()

            _readSQLCreator = New ReadSQLCreator
            _readSQLCreator.Initialize(Me, param)

            Select Case targetMaster

                Case IMasterReader.取得項目型.倉庫別在庫
                    resultValue = ReadData倉庫別在庫(connection, param)

            End Select

            CloseConnection(connection)
        End Using

        Return resultValue

    End Function

    Public Function MasterCheck(ByVal targetMaster As IMasterReader.テーブル一覧型, ByVal param As ReadParam) As Boolean Implements IMasterReader.MasterCheck

        SetUpDAC()

        Dim result As Boolean = False

        Using connection As DbConnection = OpenConnection()

            Select Case targetMaster
                Case IMasterReader.テーブル一覧型.セキュリティチェック
                    result = Checkセキュリティ(connection, param)
            End Select

            CloseConnection(connection)
        End Using

        Return result

    End Function

#End Region

#Region "内部メソッド"

    Private Function ReadData得意先マスター(ByVal connection As DbConnection) As DataTable

        Dim sql As String = ""
        Dim paramInfo As ParamInfoList = New ParamInfoList
        sql &= _readSQLCreator.MakeSQL得意先マスター(paramInfo)

        Dim dt As New DataTable
        dt = DataAccess.GetDataTable(connection, sql, paramInfo)
        dt.TableName = IMasterReader.テーブル一覧型.得意先マスター.ToString

        Return dt

    End Function

    Private Function ReadData担当者マスター(ByVal connection As DbConnection) As DataTable

        Dim sql As String = ""
        Dim paramInfo As ParamInfoList = New ParamInfoList
        sql &= _readSQLCreator.MakeSQL担当者マスター(paramInfo)

        Dim dt As New DataTable
        dt = DataAccess.GetDataTable(connection, sql, paramInfo)
        dt.TableName = IMasterReader.テーブル一覧型.担当者マスター.ToString

        Return dt


    End Function

    Private Function ReadData商品マスター(ByVal connection As DbConnection) As DataTable

        Dim sql As String = ""
        Dim paramInfo As ParamInfoList = New ParamInfoList
        sql &= _readSQLCreator.MakeSQL商品マスター(paramInfo)

        Dim dt As New DataTable
        dt = DataAccess.GetDataTable(connection, sql, paramInfo)
        dt.TableName = IMasterReader.テーブル一覧型.商品マスター.ToString

        Return dt

    End Function

    Private Function ReadData部門マスター(ByVal connection As DbConnection) As DataTable

        Dim sql As String = ""
        Dim paramInfo As ParamInfoList = New ParamInfoList
        sql &= _readSQLCreator.MakeSQL部門マスター(paramInfo)

        Dim dt As New DataTable
        dt = DataAccess.GetDataTable(connection, sql, paramInfo)
        dt.TableName = IMasterReader.テーブル一覧型.部門マスター.ToString

        Return dt

    End Function

    Private Function ReadData区分マスター(ByVal connection As DbConnection) As DataTable

        Dim sql As String = ""
        Dim paramInfo As ParamInfoList = New ParamInfoList
        sql &= _readSQLCreator.MakeSQL区分マスター(paramInfo)

        Dim dt As New DataTable
        dt = DataAccess.GetDataTable(connection, sql, paramInfo)
        dt.TableName = IMasterReader.テーブル一覧型.区分マスター.ToString

        Return dt

    End Function

    Private Function ReadData倉庫マスター(ByVal connection As DbConnection) As DataTable

        Dim sql As String = ""
        Dim paramInfo As ParamInfoList = New ParamInfoList
        sql &= _readSQLCreator.MakeSQL倉庫マスター(paramInfo)

        Dim dt As New DataTable
        dt = DataAccess.GetDataTable(connection, sql, paramInfo)
        dt.TableName = IMasterReader.テーブル一覧型.倉庫マスター.ToString

        Return dt

    End Function

    Private Function ReadData発行済管理テーブル(ByVal connection As DbConnection) As DataTable

        Dim sql As String = ""
        Dim paramInfo As ParamInfoList = New ParamInfoList
        sql &= _readSQLCreator.MakeSQL発行済管理テーブル(paramInfo)

        Dim dt As New DataTable
        dt = DataAccess.GetDataTable(connection, sql, paramInfo)
        dt.TableName = IMasterReader.テーブル一覧型.発行済管理テーブル.ToString

        Return dt

    End Function

    Private Function ReadData倉庫別在庫(ByVal connection As DbConnection, ByVal param As ReadParam) As Decimal

        Dim value As New Object
        Dim Result As IResult = New Result
        Using transaction As DbTransaction = DataAccess.BeginTransaction(connection)

            Result = Readストアド(transaction, param, READ_ストアド_倉庫別在庫数, value)

        End Using

        Return CDec(value)

    End Function

    'A-CUST20201013↓
    Private Function ReadData納品先マスター(ByVal connection As DbConnection) As DataTable

        Dim sql As String = ""
        Dim paramInfo As ParamInfoList = New ParamInfoList
        sql &= _readSQLCreator.MakeSQL納品先マスター(paramInfo)

        Dim dt As New DataTable
        dt = DataAccess.GetDataTable(connection, sql, paramInfo)
        dt.TableName = IMasterReader.テーブル一覧型.納品先マスター.ToString

        Return dt

    End Function
    'A-CUST20201013↑

    Private Function Checkセキュリティ(ByVal connection As DbConnection, ByVal param As ReadParam) As Boolean

        Dim DataSec As New CUSSecIDGetter
        Dim Syubetu As Integer
        Dim ID As String = ""
        DataSec.Initialize(Me)
        DataSec.GetSecIDInfo(connection,
                             CInt(param.Container(ReadParam.項目名型.セキュリティ種別)),
                             CStr(param.Container(ReadParam.項目名型.ログインID)),
                             CStr(param.Container(ReadParam.項目名型.部門コード)),
                             Syubetu,
                             ID)

        If ID Is String.Empty Then
            Return False
        End If

        Return True

    End Function

    ''' <summary>
    ''' 列の追加
    ''' </summary>
    ''' <param name="addColName"></param>
    ''' <param name="addDataType"></param>
    ''' <param name="mainData"></param>
    ''' <remarks></remarks>
    Private Sub AddColumn(ByVal addColName As String, ByVal addDataType As Type, ByRef mainData As DataTable)

        Dim dc As DataColumn

        If Not mainData.Columns.Contains(addColName) Then
            dc = New DataColumn(addColName, addDataType)
            mainData.Columns.Add(dc)
        End If

    End Sub

    ''' <summary>
    ''' 列の追加及び、内容値の設定
    ''' </summary>
    ''' <param name="dt"></param>
    ''' <param name="aliasName"></param>
    ''' <param name="mainData"></param>
    ''' <remarks></remarks>
    Private Sub AddColumnAndSet(ByVal dt As DataTable, ByVal aliasName As String, ByVal rowIndex As Integer, ByRef mainData As DataTable)

        For col As Integer = 0 To dt.Columns.Count - 1

            Dim colName As String = dt.Columns(col).ColumnName
            Dim newName As String = aliasName & colName

            AddColumn(newName, dt.Columns(col).DataType, mainData)
            mainData.Rows(rowIndex).Item(newName) = dt.Rows(0).Item(colName)
        Next

    End Sub

    ''' <summary>
    ''' 退避DataTableのカラム名を元に対象DataTableより内容値を設定
    ''' </summary>
    ''' <param name="mainData">対象DataTable</param>
    ''' <param name="rowindex"></param>
    ''' <param name="setData">退避DataTable</param>
    ''' <remarks>退避DataTableはスキーマ作成済の事</remarks>
    Private Sub SetDataTableEachItem(
                                ByVal mainData As DataTable,
                                ByVal rowindex As Integer,
                                ByVal setData As DataTable,
                       Optional ByVal targetColName As String = "")

        setData.Rows.Add(setData.NewRow)

        For index As Integer = 0 To mainData.Columns.Count - 1
            Dim columnName As String = mainData.Columns(index).ColumnName

            If targetColName = "" OrElse Strings.InStr(columnName, targetColName) > 0 Then

                Dim removeName As String = RemoveAliasName(columnName)

                If setData.Columns.Contains(removeName) Then
                    setData.Rows(0).Item(removeName) = mainData.Rows(rowindex).Item(columnName)
                End If

            End If
        Next

    End Sub

    ''' <summary>
    ''' DBより取得した項目名より別名を除く
    ''' </summary>
    ''' <param name="targetName"></param>
    ''' <returns></returns>
    ''' <remarks>最初に見つかった"_"より前を別名のとする。その文字以降を返す</remarks>
    Private Function RemoveAliasName(ByVal targetName As String) As String

        Dim startIndex As Integer = Strings.InStr(targetName, "_")
        Dim count As Integer = targetName.Length - startIndex

        Return targetName.Substring(startIndex, count)

    End Function

#End Region

#Region "ストアド"

    ''' <summary>
    ''' ストアド読込処理
    ''' </summary>
    ''' <param name="transaction">トランザクション情報</param>
    ''' <param name="param">パラメータ</param>
    ''' <param name="storedName">ストアド名</param>
    ''' <returns>エラー情報</returns>
    ''' <remarks></remarks>
    Private Function Readストアド(ByVal transaction As DbTransaction,
                                  ByVal Param As ReadParam,
                                  ByVal storedName As String,
                                  ByRef ReturnValue As Object) As IResult

        Dim result As IResult = New Result
        Dim paramInfo As ParamInfoList = New ParamInfoList

        Dim データ区分 As 更新情報型.データ区分型 = 更新情報型.データ区分型.変更後

        Select Case storedName
            Case READ_ストアド_倉庫別在庫数

                _readSQLCreator.MakeParameterストアド(paramInfo)

        End Select

        DataAccess.ExecuteStoredProcedure(transaction, storedName, paramInfo)
        Select Case CInt(Getパラメータ(paramInfo, "RETCD1", 属性.数値))
            Case 0
                result.結果 = IResult.resultError.成功
                Select Case storedName
                    Case READ_ストアド_倉庫別在庫数
                        ReturnValue = Getパラメータ(paramInfo, "ZAIKOSUU", 属性.数値)
                End Select
            Case Else
                Dim errorMessage As String = ""
                errorMessage &= storedName & Space(5)
                errorMessage &= CStr(Getパラメータ(paramInfo, "RETCD2", 属性.文字))
                HandleStoredProcedureError(errorMessage)
        End Select

        Return result

    End Function

    Private Enum 属性 As Integer
        文字
        数値
    End Enum

    ''' <summary>
    ''' パラメータ内容を取得する
    ''' </summary>
    ''' <param name="paramInfo">パラメータ配列</param>
    ''' <param name="取得項目名">取得したい項目名</param>
    ''' <param name="取得項目属性">取得したい項目の属性</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function Getパラメータ(ByVal paramInfo As ParamInfoList,
                                   ByVal 取得項目名 As String,
                                   ByVal 取得項目属性 As 属性) As Object

        Dim パラメータ名 As String = ""

        Dim 取得パラメータ As Object = Nothing
        Select Case 取得項目属性
            Case 属性.文字
                取得パラメータ = ""
            Case 属性.数値
                取得パラメータ = 0
        End Select

        For index As Integer = 0 To paramInfo.Count - 1
            パラメータ名 = paramInfo(index).Name.Trim
            If Left(パラメータ名, 1) = "@" Then
                パラメータ名 = Mid(パラメータ名, 2, パラメータ名.Length - 1)
            End If
            If パラメータ名.Trim = 取得項目名.Trim Then
                取得パラメータ = paramInfo(index).Value
                Exit For
            End If
        Next

        Return 取得パラメータ

    End Function

#End Region

End Class
