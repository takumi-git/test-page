﻿''' <summary>
''' 取引データ取得用
''' </summary>
''' <remarks></remarks>
Public Class DenpyouReader
    Inherits DataHandlerBase
    Implements IDenpyouReader

#Region "内部変数"

    Private _readSQLCreator As ReadSQLCreator

    Private _初期起動 As Boolean = False

#End Region

#Region "メソッド"

    ''' <summary>
    ''' データの取得
    ''' </summary>
    ''' <param name="targetDenpyou"></param>
    ''' <param name="param"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function DenpyouRead(ByVal targetDenpyou As IDenpyouReader.テーブル一覧型, ByVal param As ReadParam) As System.Data.DataSet Implements IDenpyouReader.DenpyouRead

        SetUpDAC()

        Dim ds As New DataSet

        Using connection As DbConnection = OpenConnection()

            _readSQLCreator = New ReadSQLCreator
            _readSQLCreator.Initialize(Me, param)

            Select Case targetDenpyou
                Case IDenpyouReader.テーブル一覧型.見積伝票
                    '------------------------------
                    '   見積伝票
                    '------------------------------
                    If CLng(param.Container(ReadParam.項目名型.伝票番号)) = -1 Then
                        _初期起動 = True
                    End If
                    Dim mitDenp As DataTable = ReadData見積伝票(connection, param)
                    ds.Tables.Add(mitDenp)

                    'A-CUST20241219↓
                    '------------------------------
                    '   見積サブ明細
                    '------------------------------
                    If _初期起動 = True OrElse mitDenp.Rows.Count <> 0 Then
                        Dim mitSubDenp As DataTable = ReadData見積サブ明細(connection, param)
                        ds.Tables.Add(mitSubDenp)
                    End If
                    'A-CUST20241219↑


            End Select

            CloseConnection(connection)
        End Using

        ds.RemotingFormat = SerializationFormat.Binary

        Return ds

    End Function

    Private Function ReadData見積伝票(ByVal connection As DbConnection, ByVal param As ReadParam) As DataTable

        If CInt(param.Container(ReadParam.項目名型.読込種別)) = ReadParam.読込種別型.最終伝票 Then
            Dim renbanParamInfo As ParamInfoList = New ParamInfoList
            Dim renbanSQL As String = _readSQLCreator.MakeSQL連番管理テーブル
            Dim renbanDT As DataTable = DataAccess.GetDataTable(connection, renbanSQL, renbanParamInfo)
            param.Container(ReadParam.項目名型.伝票番号) = CLng(renbanDT.Rows(0).Item("CUSCE21008"))
        End If

        If CInt(param.Container(ReadParam.項目名型.読込種別)) <> ReadParam.読込種別型.一伝票 Then
            '次前最終伝票取得の場合、表示対象伝票の絞込みを行う
            Dim dt2 As New DataTable
            Dim sql2 As String = ""
            Dim paramInfo2 As ParamInfoList = New ParamInfoList
            sql2 &= _readSQLCreator.MakeSQL見積伝票_次前最終用連番取得(paramInfo2)
            dt2 = DataAccess.GetDataTable(connection, sql2, paramInfo2)

            If dt2.Rows.Count = 0 Then
                '取得できない場合は処理終了
                dt2.TableName = IDenpyouReader.テーブル一覧型.見積伝票.ToString
                Return dt2
            End If

            '取得した処理連番で１件伝票取得へ
            param.Container(ReadParam.項目名型.読込種別) = ReadParam.読込種別型.一伝票
            param.Container(ReadParam.項目名型.伝票番号) = CLng(dt2.Rows(0).Item("HMITRE11_CUSRE11001"))
        End If

        Dim sql As String = ""
        Dim paramInfo As ParamInfoList = New ParamInfoList
        sql &= _readSQLCreator.MakeSQL見積伝票(paramInfo, _初期起動)

        Dim dt As New DataTable
        If CInt(param.Container(ReadParam.項目名型.読込種別)) = ReadParam.読込種別型.一伝票 Then
            '-- １件伝票取得
            dt = DataAccess.GetDataTable(connection, sql, paramInfo)
        End If

        dt.TableName = IDenpyouReader.テーブル一覧型.見積伝票.ToString

        Return dt

    End Function

    'A-CUST20241219↓
    ''' <summary>
    ''' 見積サブ明細テーブル 読込処理
    ''' </summary>
    ''' <param name="connection"></param>
    ''' <param name="param"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function ReadData見積サブ明細(ByVal connection As DbConnection, ByVal param As ReadParam) As DataTable

        Dim sql As String = ""
        Dim paramInfo As ParamInfoList = New ParamInfoList
        sql &= _readSQLCreator.MakeSQL見積伝票_見積サブ明細情報(paramInfo)

        Dim dt As New DataTable
        dt = DataAccess.GetDataTable(connection, sql, paramInfo)

        dt.TableName = IDenpyouReader.テーブル一覧型.見積サブ明細.ToString

        Return dt

    End Function
    'A-CUST20241219↑


    ''' <summary>
    ''' 行データを設定する
    ''' </summary>
    ''' <param name="reader"></param>
    ''' <param name="table"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function MakeNewDataRow(ByVal reader As DbDataReader, ByVal table As DataTable) As DataRow

        Dim dr As DataRow
        dr = table.NewRow()
        For i As Integer = 0 To reader.FieldCount - 1
            dr(reader.GetName(i)) = reader.GetValue(i)
        Next
        Return dr

    End Function

    ''' <summary>
    ''' テーブルに列を設定する
    ''' </summary>
    ''' <param name="reader">reader</param>
    ''' <param name="table">datatable</param>
    ''' <remarks></remarks>
    Private Sub SetUpTable(ByVal reader As DbDataReader, ByRef table As DataTable)

        Dim dc As DataColumn
        For i As Integer = 0 To reader.FieldCount - 1
            dc = New DataColumn(reader.GetName(i), reader(i).GetType)
            table.Columns.Add(dc)
        Next

    End Sub

    ''' <summary>
    ''' 退避DataTableのカラム名を元に対象DataTableより内容値を設定
    ''' </summary>
    ''' <param name="mainData">対象DataTable</param>
    ''' <param name="rowindex"></param>
    ''' <param name="setData">退避DataTable</param>
    ''' <remarks>退避DataTableはスキーマ作成済の事</remarks>
    Private Sub SetDataTableEachItem( _
                                ByVal mainData As DataTable, _
                                ByVal rowindex As Integer, _
                                ByVal setData As DataTable, _
                       Optional ByVal targetColName As String = "")

        setData.Rows.Add(setData.NewRow)

        For index As Integer = 0 To mainData.Columns.Count - 1
            Dim columnName As String = mainData.Columns(index).ColumnName

            If targetColName = "" OrElse Strings.InStr(columnName, targetColName) > 0 Then

                Dim removeName As String = RemoveAliasName(columnName)

                If setData.Columns.Contains(removeName) Then
                    setData.Rows(0).Item(removeName) = mainData.Rows(rowindex).Item(columnName)
                End If

            End If
        Next

    End Sub

    ''' <summary>
    ''' DBより取得した項目名より別名を除く
    ''' </summary>
    ''' <param name="targetName"></param>
    ''' <returns></returns>
    ''' <remarks>最初に見つかった"_"より前を別名のとする。その文字以降を返す</remarks>
    Private Function RemoveAliasName(ByVal targetName As String) As String

        Dim startIndex As Integer = Strings.InStr(targetName, "_")
        Dim count As Integer = targetName.Length - startIndex

        Return targetName.Substring(startIndex, count)

    End Function

    ''' <summary>
    ''' 列の追加
    ''' </summary>
    ''' <param name="addColName"></param>
    ''' <param name="addDataType"></param>
    ''' <param name="mainData"></param>
    ''' <remarks></remarks>
    Private Sub AddColumn(ByVal addColName As String, ByVal addDataType As Type, ByRef mainData As DataTable)

        Dim dc As DataColumn

        If Not mainData.Columns.Contains(addColName) Then
            dc = New DataColumn(addColName, addDataType)
            mainData.Columns.Add(dc)
        End If

    End Sub

#End Region

End Class
