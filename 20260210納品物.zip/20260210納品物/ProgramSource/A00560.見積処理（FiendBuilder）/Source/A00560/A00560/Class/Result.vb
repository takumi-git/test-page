﻿''' <summary>
''' データベースの結果を管理する
''' </summary>
''' <remarks></remarks>
<Serializable()>
Public Class Result
    Implements IResult

#Region "コンストラクタ"

    Sub New()
        _詳細情報 = New Hashtable
        _エラー番号 = New Hashtable
        For index As Integer = 0 To [Enum].GetNames(GetType(IResult.messageConnect)).Length - 1
            _エラー情報(index) = New Hashtable
        Next
    End Sub

#End Region

#Region "プロパティ"

    ''' <summary>
    ''' データベース取得・更新のエラー番号
    ''' </summary>
    ''' <remarks></remarks>
    Private _エラー番号 As IDictionary
    Public Property エラー番号() As IDictionary Implements IResult.エラー番号
        Get
            Return _エラー番号
        End Get
        Set(ByVal value As IDictionary)
            _エラー番号 = value
        End Set
    End Property

    ''' <summary>
    ''' データベース取得・更新のエラー詳細情報
    ''' </summary>
    ''' <remarks></remarks>
    Private _エラー情報([Enum].GetNames(GetType(IResult.messageConnect)).Length - 1) As IDictionary
    Public Property エラー情報(Optional ByVal messageConnect As IResult.messageConnect = IResult.messageConnect.後尾) As IDictionary Implements IResult.エラー情報
        Get
            Return _エラー情報(messageConnect)
        End Get
        Set(ByVal value As IDictionary)
            _エラー情報(messageConnect) = value
        End Set
    End Property

    ''' <summary>
    ''' データベース取得・更新の結果情報
    ''' </summary>
    ''' <remarks></remarks>
    Private _結果 As IResult.resultError
    Public Property 結果() As IResult.resultError Implements IResult.結果
        Get
            Return _結果
        End Get
        Set(ByVal value As IResult.resultError)
            _結果 = value
            '成功した場合、エラー番号のクリア
            If value = IResult.resultError.成功 Then
                _エラー番号.Clear()
                For index As Integer = 0 To [Enum].GetNames(GetType(IResult.messageConnect)).Length - 1
                    _エラー情報(index).Clear()
                Next
            End If
        End Set
    End Property

    ''' <summary>
    ''' データベース取得・更新の結果詳細情報
    ''' </summary>
    ''' <remarks></remarks>
    Private _詳細情報 As IDictionary
    Public Property 詳細情報() As IDictionary Implements IResult.詳細情報
        Get
            Return _詳細情報
        End Get
        Set(ByVal value As IDictionary)
            _詳細情報 = value
        End Set
    End Property

#End Region

#Region "メソッド"

    ''' <summary>
    ''' エラー番号を返す、存在しない場合はデフォルト値を返す
    ''' </summary>
    ''' <param name="key">要素のキー値</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function エラー番号取得(ByVal key As String) As Integer Implements IResult.エラー番号取得
        If _エラー番号.Contains(key) Then
            Return CInt(_エラー番号.Item(key))
        Else
            Return 0
        End If
    End Function

    ''' <summary>
    ''' エラー番号に要素keyが存在するか判定を行い、存在すれば一旦削除を行って、要素keyを追加する
    ''' </summary>
    ''' <param name="key">要素のキー値</param>
    ''' <param name="value">要素の値</param>
    ''' <remarks></remarks>
    Public Sub エラー番号追加(ByVal key As String, ByVal value As Integer) Implements IResult.エラー番号追加
        If _エラー番号.Contains(key) Then
            _エラー番号.Remove(key)
            _エラー番号.Add(key, value)
        Else
            _エラー番号.Add(key, value)
        End If
    End Sub

    ''' <summary>
    ''' エラー情報を返す、存在しない場合はデフォルト値を返す
    ''' </summary>
    ''' <param name="key">要素のキー値</param>
    ''' <param name="defaultValue">デフォルト値</param>
    ''' <param name="messageConnect">メッセージ連結部分</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function エラー情報取得(ByVal key As String,
                                   ByVal defaultValue As Object,
                          Optional ByVal messageConnect As IResult.messageConnect = IResult.messageConnect.後尾) As Object Implements IResult.エラー情報取得
        If _エラー情報(messageConnect).Contains(key) Then
            Return _エラー情報(messageConnect).Item(key)
        Else
            Return defaultValue
        End If
    End Function

    ''' <summary>
    ''' エラー情報に要素keyが存在するか判定を行い、存在すれば一旦削除を行って、要素keyを追加する
    ''' </summary>
    ''' <param name="key">要素のキー値</param>
    ''' <param name="value">要素の値</param>
    ''' <param name="messageConnect">メッセージ連結部分</param>
    ''' <remarks></remarks>
    Public Sub エラー情報追加(ByVal key As String,
                              ByVal value As Object,
                     Optional ByVal messageConnect As IResult.messageConnect = IResult.messageConnect.後尾) Implements IResult.エラー情報追加
        If _エラー情報(messageConnect).Contains(key) Then
            _エラー情報(messageConnect).Remove(key)
            _エラー情報(messageConnect).Add(key, value)
        Else
            _エラー情報(messageConnect).Add(key, value)
        End If
    End Sub

    ''' <summary>
    ''' 詳細情報を返す、存在しない場合はデフォルト値を返す
    ''' </summary>
    ''' <param name="key">要素のキー値</param>
    ''' <param name="defaultValue">デフォルト値</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function 詳細情報取得(ByVal key As String, ByVal defaultValue As Object) As Object Implements IResult.詳細情報取得
        If _詳細情報.Contains(key) Then
            Return _詳細情報.Item(key)
        Else
            Return defaultValue
        End If
    End Function

    ''' <summary>
    ''' 詳細情報に要素keyが存在するか判定を行い、存在すれば一旦削除を行って、要素keyを追加する
    ''' </summary>
    ''' <param name="key">要素のキー値</param>
    ''' <param name="value">要素の値</param>
    ''' <remarks></remarks>
    Public Sub 詳細情報追加(ByVal key As String, ByVal value As Object) Implements IResult.詳細情報追加
        If _詳細情報.Contains(key) Then
            _詳細情報.Remove(key)
            _詳細情報.Add(key, value)
        Else
            _詳細情報.Add(key, value)
        End If
    End Sub

#End Region

End Class
