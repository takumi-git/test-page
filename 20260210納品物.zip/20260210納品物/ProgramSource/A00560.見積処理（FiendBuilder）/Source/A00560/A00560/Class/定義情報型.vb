﻿Public Class 定義情報型

#Region "桁数定義"
    Public ReadOnly Property 得意先コード_桁数() As Integer
        Get
            Return 11
        End Get
    End Property

    Public ReadOnly Property 部門コード_桁数() As Integer
        Get
            Return 6
        End Get
    End Property

    Public ReadOnly Property 担当者コード_桁数() As Integer
        Get
            Return 6
        End Get
    End Property

    Public ReadOnly Property 商品コード_桁数() As Integer
        Get
            Return 20
        End Get
    End Property

    'A-CUST20201013↓
    Public ReadOnly Property 納品先コード_桁数() As Integer
        Get
            Return 6
        End Get
    End Property
    'A-CUST20201013↑

#End Region

#Region "入力タイプ定義"
    Public ReadOnly Property 得意先コード_タイプ() As 入力タイプ型
        Get
            Return 入力タイプ型.数字
        End Get
    End Property

    Public ReadOnly Property 担当者コード_タイプ() As 入力タイプ型
        Get
            Return 入力タイプ型.数字
        End Get
    End Property

    Public ReadOnly Property 部門コード_タイプ() As 入力タイプ型
        Get
            Return 入力タイプ型.数字
        End Get
    End Property

    Public ReadOnly Property 商品コード_タイプ() As 入力タイプ型
        Get
            Return 入力タイプ型.英数カナ
        End Get
    End Property

    'A-CUST20201013↓
    Public ReadOnly Property 納品先コード_タイプ() As 入力タイプ型
        Get
            Return 入力タイプ型.数字
        End Get
    End Property
    'A-CUST20201013↑

#End Region

End Class
