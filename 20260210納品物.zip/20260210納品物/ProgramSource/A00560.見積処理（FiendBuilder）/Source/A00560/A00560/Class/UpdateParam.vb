﻿<Serializable()>
Public Class UpdateParam

    Public Enum 項目名型
        '（伝播用）
        更新条件
        ワーク_ヘッダー
        ワーク_明細
        ワーク_サブ明細    'A-CUST20241219
        '（更新用）
        ワーク情報
        GUID_ストアド
        処理連番_ストアド
        伝票番号_ストアド
    End Enum

#Region "伝播用"

    Public Enum 更新条件型
        当期期首年月日
        明細行数
        伝票番号
        更新番号
    End Enum

#End Region

#Region "更新用"

    Public Enum ワークテーブル項目型
        CUSWE01001
        CUSWE01002
        CUSWE01003
        CUSWE01004
        CUSWE01005
        CUSWE01006
        CUSWE01007
        CUSWE01008
        CUSWE01009
        CUSWE01010
        CUSWE01993
        CUSWE01994
        CUSWE01995
        CUSWE01996
        'D-CUST20220425↓
        'CUSWE01997
        'CUSWE01998
        'D-CUST20220425↑
        'A-CUST20220425↓
        CUSWE01991
        CUSWE01992
        CUSWE01INS
        CUSWE01UPD          'A-CUST20241219
        'A-CUST20220425↑
        CUSWE01999
    End Enum

#End Region

    Public Sub New()
        _container = New Hashtable

        _ワーク = New DataTable

    End Sub

    Private _container As IDictionary
    Public Property Container(ByVal key As 項目名型) As Object
        Get
            If _container.Contains(key.ToString) = True Then
                Return _container.Item(key.ToString)
            Else
                Return Nothing
            End If
        End Get
        Set(ByVal value As Object)
            If _container.Contains(key.ToString) = True Then
                _container.Item(key.ToString) = value
            Else
                _container.Add(key.ToString, value)
            End If
        End Set
    End Property

#Region "伝票関連（更新用）"

    Private _ワーク As DataTable
    Public Property ワーク() As DataTable
        Get
            Return _ワーク
        End Get
        Set(ByVal value As DataTable)
            _ワーク = value.Copy
        End Set
    End Property

    ''' <summary>
    ''' ワークテーブルの値を返す
    ''' </summary>
    ''' <param name="columnName"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Property ワークテーブル項目(ByVal columnName As String, Optional trim As Boolean = True) As Object
        Get
            If trim = True Then
                Return trimEnd(_ワーク.Rows(0).Item(columnName))
            Else
                Return _ワーク.Rows(0).Item(columnName)
            End If
        End Get
        Set(ByVal value As Object)
            _ワーク.Rows(0).Item(columnName) = value
        End Set
    End Property

#End Region

#Region "内部メソッド"

    ''' <summary>
    ''' 後ろの空白をカット
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    ''' <remarks>Stringタイプのみ対象。以外はそのまま返す</remarks>
    Private Function trimEnd(ByVal value As Object) As Object

        If value.GetType Is GetType(String) Then
            Return CStr(value).TrimEnd
        End If

        Return value

    End Function

#End Region

End Class
