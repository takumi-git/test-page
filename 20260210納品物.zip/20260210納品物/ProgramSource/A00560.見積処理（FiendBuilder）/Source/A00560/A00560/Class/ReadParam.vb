﻿<Serializable()> _
Public Class ReadParam

    Public Enum 項目名型
        読込種別
        伝票区分
        伝票番号
        得意先コード
        担当者コード
        部門コード
        納品先コード    'A-CUST20201013
        種別
        区分コード
        商品コード
        倉庫コード
        ログインID
        商品マスター情報

        'セキュリティ情報
        セキュリティ種別

        'ストアド
        倉庫コード_ストアド
        商品コード_ストアド
        期首年月_ストアド
        指定年月_ストアド
        指定年月日_ストアド
        自社締日付_ストアド
        数量小数点以下桁数_ストアド
        端数単位処理方法_ストアド
        在庫数量_ストアド

    End Enum

    Public Enum 読込種別型
        一伝票
        次伝票
        前伝票
        最終伝票
    End Enum

    Public Sub New()
        _container = New Hashtable
    End Sub

    Private _container As IDictionary
    Public Property Container(ByVal key As 項目名型) As Object
        Get
            If _container.Contains(key.ToString) = True Then
                Return _container.Item(key.ToString)
            Else
                Return Nothing
            End If
        End Get
        Set(ByVal value As Object)
            If _container.Contains(key.ToString) = True Then
                _container.Item(key.ToString) = value
            Else
                _container.Add(key.ToString, value)
            End If
        End Set
    End Property

End Class
