﻿Public Enum 起動モード型 As Integer
    通常モード = 0
    詳細モード
    ドリルダウン
End Enum

Public Enum 処理区分型 As Integer
    登録 = 1
    修正
    削除
End Enum

Public Enum 取引区分属性型 As Integer
    売上 = 1
    返品
    値引
    見本
    取消 = 9
    'メモ = 91            'D-CUST20200311 '-20200527-001
End Enum

'A-CUST20200311↓ '-20200527-001
Public Enum 行区分型 As Integer
    メモ = 91
End Enum
'A-CUST20200311↑ '-20200527-001

Public Enum 入力タイプ型 As Integer
    数字 = 0
    英数カナ = 1
End Enum

Public Enum 伝票発行型 As Integer
    なし = 0
    本発行
End Enum

Public Enum 区分マスター型 As Integer
    区分 = 3
    消費税区分 = 30
    課税区分 = 60
End Enum

Public Enum 消費税計算区分型 As Integer
    未設定
    請求単位
    伝票単位
End Enum

Public Enum 課税区分型 As Integer
    未設定
    税抜
    税込
    非課税
End Enum
