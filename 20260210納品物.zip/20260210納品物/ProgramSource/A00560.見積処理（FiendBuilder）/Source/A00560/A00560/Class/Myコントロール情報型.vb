﻿Public Class Myコントロール情報型

#Region "変数"

#Region "コントロール"

    Private _infoCUSCE01 As IDictionary
    Private _infoCUSCE11 As IDictionary

#End Region

#End Region

#Region "コンストラクタ"

    Public Sub New()

        _infoCUSCE01 = New Hashtable
        _infoCUSCE11 = New Hashtable

    End Sub

#End Region

#Region "公開メソッド"

    ''' <summary>
    ''' コントロールテーブルの初期化
    ''' </summary>
    ''' <param name="controlInfoCE01">コントロールテーブル情報</param>
    ''' <remarks></remarks>
    Public Sub InitializeCUSCE01(ByVal controlInfoCE01 As IDictionary)

        _infoCUSCE01 = CType(controlInfoCE01.Item(IControlReader.テーブル一覧型.コントロールテーブル.ToString), Collections.IDictionary)

    End Sub

    ''' <summary>
    ''' 日付管理テーブルの初期化
    ''' </summary>
    ''' <param name="controlInfoCE11">コントロールテーブル情報</param>
    ''' <remarks></remarks>
    Public Sub InitializeCUSCE11(ByVal controlInfoCE11 As IDictionary)

        _infoCUSCE11 = CType(controlInfoCE11.Item(IControlReader.テーブル一覧型.日付管理テーブル.ToString), Collections.IDictionary)
    End Sub

#End Region

#Region "プロパティ"

    Public ReadOnly Property InfoCUSCE01() As IDictionary
        Get
            Return _infoCUSCE01
        End Get
    End Property

    Public ReadOnly Property 小数桁_数量() As Integer
        Get
            Return CInt(GetAddControlInfo(_infoCUSCE01, "SHOSU_001", 0))
        End Get
    End Property

    Public ReadOnly Property 小数桁_売上単価() As Integer
        Get
            Return CInt(GetAddControlInfo(_infoCUSCE01, "SHOSU_002", 0))
        End Get
    End Property

    Public ReadOnly Property 小数桁_仕入単価() As Integer
        Get
            Return CInt(GetAddControlInfo(_infoCUSCE01, "SHOSU_003", 0))
        End Get
    End Property

    Public ReadOnly Property 金額端数処理() As Integer
        Get
            Return CInt(GetAddControlInfo(_infoCUSCE01, "ZAIKO_001", 1))
        End Get
    End Property

    Public ReadOnly Property 金額端数処理_仕入() As Integer
        Get
            Return CInt(GetAddControlInfo(_infoCUSCE01, "HASUU_001", 1))
        End Get
    End Property


#Region "伝票発行"
    Public ReadOnly Property 伝票発行() As Integer
        Get
            Return CInt(GetAddControlInfo(_infoCUSCE01, "SHOKI_001", 0))
        End Get
    End Property

    Public ReadOnly Property 見積伝票() As String
        Get
            Return CStr(GetAddControlInfo(_infoCUSCE01, "MITSUMORI_001", ""))
        End Get
    End Property
#End Region

#Region "日付管理"
    Public ReadOnly Property 期首年月日() As Integer
        Get
            Return CInt(GetAddControlInfo(_infoCUSCE11, "CUSCE11002", 0))
        End Get
    End Property

    Public ReadOnly Property 期首年月() As Integer
        Get
            Return CInt(GetAddControlInfo(_infoCUSCE11, "CUSCE11003", 0))
        End Get
    End Property

    Public ReadOnly Property 自社締日() As Integer
        Get
            Return CInt(GetAddControlInfo(_infoCUSCE11, "CUSCE11004", 0))
        End Get
    End Property

    Public ReadOnly Property 入力可能期間() As Integer
        Get
            Return CInt(GetAddControlInfo(_infoCUSCE11, "CUSCE11005", 0))
        End Get
    End Property
#End Region

#Region "その他"
    Public ReadOnly Property 数量拡張表示() As Boolean
        Get
            If 小数桁_数量 >= 4 Then
                Return True
            Else
                Return False
            End If
        End Get
    End Property
#End Region
#End Region

#Region "内部メソッド"

    Protected Function GetAddControlInfo(Of T)(ByVal controlInfo As IDictionary, ByVal Key As String, ByVal defaultValue As T) As T
        If controlInfo.Contains(Key) = True Then
            If controlInfo(Key) Is "" Then
                Select Case GetType(T).ToString
                    Case "System.Int16", "System.Int32", "System.Int64", "System.Decimal", "System.Single", "System.Double"
                        Dim dummyValue As Object = 0
                        Return CType(dummyValue, T)
                        Exit Function
                End Select
            End If
            Return CType(controlInfo(Key), T)
        Else
            Return defaultValue
        End If
    End Function

#End Region

End Class
