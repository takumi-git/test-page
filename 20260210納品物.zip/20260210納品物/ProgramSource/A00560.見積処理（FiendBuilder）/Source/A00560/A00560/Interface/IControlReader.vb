﻿Public Interface IControlReader
    Inherits IBase

    Enum テーブル一覧型
        コントロールテーブル = 0
        日付管理テーブル
        連番管理テーブル
    End Enum

    Function ControlRead(ByVal targetTable As テーブル一覧型, ByVal param As ReadParam) As DataTable

End Interface
