﻿''' <summary>
''' 伝票更新インターフェース
''' </summary>
''' <remarks></remarks>
Public Interface IDenpyouUpdater
    Inherits IBase

    Enum テーブル一覧型
        見積伝票 = 0
    End Enum

    Function DenpyouUpdate(ByVal targetDenpyou As テーブル一覧型, _
                           ByVal mode As 処理区分型, _
                           ByVal param As UpdateParam, _
                           ByRef executeCheckInfo As IExecuteCheckInfo) As IResult

End Interface
