﻿Public Interface IMasterReader
    Inherits IBase

    Enum テーブル一覧型
        得意先マスター = 0
        商品マスター
        担当者マスター
        部門マスター
        区分マスター
        倉庫マスター
        発行済管理テーブル
        セキュリティチェック
        納品先マスター   'A-CUST20201013
    End Enum

    Enum 取得項目型
        倉庫別在庫 = 0
    End Enum

    Overloads Function MasterRead(ByVal targetMaster As テーブル一覧型, ByVal param As ReadParam) As DataTable

    Overloads Function MasterRead(ByVal targetMaster As 取得項目型, ByVal param As ReadParam) As Object

    Function MasterCheck(ByVal targetMaster As テーブル一覧型, ByVal param As ReadParam) As Boolean

End Interface
