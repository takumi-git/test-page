﻿''' <summary>
''' 伝票読込インターフェース
''' </summary>
''' <remarks></remarks>
Public Interface IDenpyouReader
    Inherits IBase

    Enum テーブル一覧型
        見積伝票 = 0
        見積サブ明細      'A-CUST20241219
    End Enum

    Function DenpyouRead(ByVal targetDenpyou As テーブル一覧型, ByVal param As ReadParam) As DataSet

End Interface
