﻿''' <summary>
''' 更新結果用
''' </summary>
''' <remarks></remarks>
<CLSCompliant(True)> _
Public Interface IResult

#Region "列挙"

    Enum resultError
        成功
        ロック中
        他で更新済
        一意制約違反
        レコード無し
        ファイル無し
        データ終了
        同時実行不可
        想定された失敗
        マスター無し
        日付変更エラー
        締日更新中
    End Enum

    Enum resultSucceed
        伝票番号
        発行済管理更新日時
    End Enum

    Enum messageConnect
        先頭
        後尾
    End Enum

#End Region

#Region "プロパティ"

    Property 結果() As resultError

    Property 詳細情報() As IDictionary

    Property エラー番号() As IDictionary

    Property エラー情報(Optional ByVal messageConnect As messageConnect = messageConnect.後尾) As IDictionary

#End Region

#Region "メソッド"

    Sub 詳細情報追加(ByVal key As String, ByVal value As Object)

    Function 詳細情報取得(ByVal key As String, ByVal defaultValue As Object) As Object

    Sub エラー番号追加(ByVal key As String, ByVal value As Integer)

    Function エラー番号取得(ByVal key As String) As Integer

    Sub エラー情報追加(ByVal key As String, _
                       ByVal value As Object, _
              Optional ByVal messageConnect As messageConnect = messageConnect.後尾)

    Function エラー情報取得(ByVal key As String, _
                            ByVal defaultValue As Object, _
                   Optional ByVal messageConnect As messageConnect = messageConnect.後尾) As Object

#End Region

End Interface
