﻿<CLSCompliant(True)> _
Public Interface IReadParam

    ''' <summary>
    ''' DataTable名
    ''' </summary>
    ''' <remarks></remarks>
    Enum テーブル名型 As Integer
        売上伝票
        仕入伝票
    End Enum

    Property コントロール情報() As IDictionary

End Interface
