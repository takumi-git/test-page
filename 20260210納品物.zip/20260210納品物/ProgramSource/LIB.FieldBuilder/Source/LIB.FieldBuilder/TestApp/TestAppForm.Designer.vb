﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class TestAppForm
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.CommandButton1 = New OSK.X1.Foundation.SimpleControl.CommandButton()
        Me.CommandButton2 = New OSK.X1.Foundation.SimpleControl.CommandButton()
        Me.CommandButton3 = New OSK.X1.Foundation.SimpleControl.CommandButton()
        Me.再表示区分 = New OSK.X1.Foundation.SimpleControl.CheckBox()
        Me.戻り値Panel = New OSK.X1.Foundation.SimpleControl.Panel(Me.components)
        Me.戻り値３ = New OSK.X1.Foundation.SimpleControl.InputText()
        Me.戻り値２ = New OSK.X1.Foundation.SimpleControl.InputText()
        Me.戻り値１ = New OSK.X1.Foundation.SimpleControl.InputText()
        Me.戻り値Panel.SuspendLayout()
        Me.SuspendLayout()
        '
        'CommandButton1
        '
        Me.CommandButton1.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.CommandButton1.FocusBackColor = System.Drawing.Color.Empty
        Me.CommandButton1.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.CommandButton1.Image = Nothing
        Me.CommandButton1.Location = New System.Drawing.Point(12, 12)
        Me.CommandButton1.Name = "CommandButton1"
        Me.CommandButton1.NextByEnterKey = False
        Me.CommandButton1.RemarkString = Nothing
        Me.CommandButton1.Size = New System.Drawing.Size(144, 34)
        Me.CommandButton1.TabIndex = 0
        Me.CommandButton1.Text = "スタンドアロン"
        Me.CommandButton1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'CommandButton2
        '
        Me.CommandButton2.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.CommandButton2.FocusBackColor = System.Drawing.Color.Empty
        Me.CommandButton2.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.CommandButton2.Image = Nothing
        Me.CommandButton2.Location = New System.Drawing.Point(12, 52)
        Me.CommandButton2.Name = "CommandButton2"
        Me.CommandButton2.NextByEnterKey = False
        Me.CommandButton2.RemarkString = Nothing
        Me.CommandButton2.Size = New System.Drawing.Size(144, 34)
        Me.CommandButton2.TabIndex = 1
        Me.CommandButton2.Text = "分散"
        Me.CommandButton2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'CommandButton3
        '
        Me.CommandButton3.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.CommandButton3.FocusBackColor = System.Drawing.Color.Empty
        Me.CommandButton3.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.CommandButton3.Image = Nothing
        Me.CommandButton3.Location = New System.Drawing.Point(12, 92)
        Me.CommandButton3.Name = "CommandButton3"
        Me.CommandButton3.NextByEnterKey = False
        Me.CommandButton3.RemarkString = Nothing
        Me.CommandButton3.Size = New System.Drawing.Size(144, 34)
        Me.CommandButton3.TabIndex = 3
        Me.CommandButton3.Text = "ドリルダウン"
        Me.CommandButton3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '再表示区分
        '
        Me.再表示区分.CheckState = System.Windows.Forms.CheckState.Unchecked
        Me.再表示区分.DrawFocusFrame = True
        Me.再表示区分.FocusBackColor = System.Drawing.Color.Empty
        Me.再表示区分.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.再表示区分.IndeterminateText = ""
        Me.再表示区分.Location = New System.Drawing.Point(16, 28)
        Me.再表示区分.Name = "再表示区分"
        Me.再表示区分.RemarkString = Nothing
        Me.再表示区分.Size = New System.Drawing.Size(100, 26)
        Me.再表示区分.TabIndex = 4
        Me.再表示区分.Text = "再表示区分"
        Me.再表示区分.UncheckedText = ""
        '
        '戻り値Panel
        '
        Me.戻り値Panel.Controls.Add(Me.戻り値３)
        Me.戻り値Panel.Controls.Add(Me.再表示区分)
        Me.戻り値Panel.Controls.Add(Me.戻り値２)
        Me.戻り値Panel.Controls.Add(Me.戻り値１)
        Me.戻り値Panel.Font = New System.Drawing.Font("MS UI Gothic", 10.5!)
        Me.戻り値Panel.Location = New System.Drawing.Point(12, 141)
        Me.戻り値Panel.Name = "戻り値Panel"
        Me.戻り値Panel.Size = New System.Drawing.Size(144, 156)
        Me.戻り値Panel.TabIndex = 5
        Me.戻り値Panel.Title = "戻り値"
        Me.戻り値Panel.TitleVisible = True
        '
        '戻り値３
        '
        Me.戻り値３.AutoResize = True
        Me.戻り値３.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.戻り値３.FocusBackColor = System.Drawing.Color.Empty
        Me.戻り値３.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.戻り値３.Insert = False
        Me.戻り値３.Location = New System.Drawing.Point(16, 110)
        Me.戻り値３.MaxLength = 10
        Me.戻り値３.Name = "戻り値３"
        Me.戻り値３.RemarkString = Nothing
        Me.戻り値３.Size = New System.Drawing.Size(100, 19)
        Me.戻り値３.TabIndex = 2
        Me.戻り値３.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        '戻り値２
        '
        Me.戻り値２.AutoResize = True
        Me.戻り値２.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.戻り値２.FocusBackColor = System.Drawing.Color.Empty
        Me.戻り値２.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.戻り値２.Insert = False
        Me.戻り値２.Location = New System.Drawing.Point(16, 85)
        Me.戻り値２.MaxLength = 10
        Me.戻り値２.Name = "戻り値２"
        Me.戻り値２.RemarkString = Nothing
        Me.戻り値２.Size = New System.Drawing.Size(100, 19)
        Me.戻り値２.TabIndex = 1
        Me.戻り値２.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        '戻り値１
        '
        Me.戻り値１.AutoResize = True
        Me.戻り値１.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.戻り値１.FocusBackColor = System.Drawing.Color.Empty
        Me.戻り値１.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.戻り値１.Insert = False
        Me.戻り値１.Location = New System.Drawing.Point(16, 60)
        Me.戻り値１.MaxLength = 10
        Me.戻り値１.Name = "戻り値１"
        Me.戻り値１.RemarkString = Nothing
        Me.戻り値１.Size = New System.Drawing.Size(100, 19)
        Me.戻り値１.TabIndex = 0
        Me.戻り値１.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TestAppForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(533, 314)
        Me.Controls.Add(Me.戻り値Panel)
        Me.Controls.Add(Me.CommandButton3)
        Me.Controls.Add(Me.CommandButton2)
        Me.Controls.Add(Me.CommandButton1)
        Me.Name = "TestAppForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form1"
        Me.戻り値Panel.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents CommandButton1 As OSK.X1.Foundation.SimpleControl.CommandButton
    Friend WithEvents CommandButton2 As OSK.X1.Foundation.SimpleControl.CommandButton
    Friend WithEvents CommandButton3 As OSK.X1.Foundation.SimpleControl.CommandButton
    Friend WithEvents 再表示区分 As SimpleControl.CheckBox
    Friend WithEvents 戻り値Panel As SimpleControl.Panel
    Friend WithEvents 戻り値３ As SimpleControl.InputText
    Friend WithEvents 戻り値２ As SimpleControl.InputText
    Friend WithEvents 戻り値１ As SimpleControl.InputText
End Class
