﻿Public Class SubForm
    Inherits DesignFormBase
    Implements ISubForm

#Region "列挙"
    Private Enum GroupNo As Integer
        グループ１ = 1
        グループ２
        グループ３
    End Enum

    Private Enum 省略判定結果型
        省略可 = 0
        警告
        必須
    End Enum

    Private Enum 抽出対象型 As Integer
        計算対象 = 0   '計算時に使用する項目を取得する
        反映先対象      '反映先の＠変数を取得する
    End Enum

    Private Enum 処理モード As Integer
        初回起動 = 0
        入力
        参照
    End Enum
#End Region

#Region "定数"
    Private Const MESSAGE_01 As String = "が入力されていません。処理を続行しますか？"
    Private Const EXPANTITEMCOUNT As Integer = 30
#End Region

#Region "内部変数"
    Private _contextMenu As SmartControl.ContextMenu.ContextMenu
    Private _functionEvent As Boolean
    Private _画面クリア中 As Boolean
    Private _focusSwitcher As IFocusSwitcher
    Private _ControlList() As Control
    Private _isInitialize As Boolean
    Private _dataGet As Boolean
    Private _FieldBuilder As List(Of ExpandItemParam.FieldBuilder定義型)
    Private _defaultValues As IDictionary
    Private _systdate As Integer
    Private _UserID As String
    Private _任意項目設定数 As Integer = 30
    '画面制御関連
    Private _keyF9_行終了 As Boolean
    '入力値制御関連
    Private _退避情報 As 退避情報型
    Private _conditionList As List(Of ExpandItemParam.FieldBuilder定義型)
    '計算式解析部品
    Private _計算式解析 As CalculateAnalysis
    '戦略マップ(UIHelper.vb)
    Private _strategyMap As Dictionary(Of ExpandItemParam.属性型, IUIHelper)
    Private _pendingExecute As Boolean = False
    Private _列名マップ As Dictionary(Of String, String)
    Private _actionButtons As List(Of SimpleControl.CommandButton)
    Private _buttonsByInputCtrl As Dictionary(Of String, List(Of SimpleControl.CommandButton))
    Private _btnInfoMap As Dictionary(Of SimpleControl.CommandButton, ButtonInfo)
    Private _accessor As IExpandItemAccessor
    Private _focusctrl As Control
#End Region

#Region "プロパティ"
    Private _paramInfo As System.Collections.IDictionary
    ''' <summary>
    ''' パラメータ情報（他処理より呼ばれる場合は必要になる）
    ''' </summary>
    Public Property ParamInfo() As System.Collections.IDictionary Implements ISubForm.ParamInfo
        Get
            Return _paramInfo
        End Get
        Set(ByVal value As System.Collections.IDictionary)
            _paramInfo = value
        End Set
    End Property
#End Region

#Region "構造体"
    Private Structure CellInfoType
        Dim RowIndex As Integer
        Dim ColIndex As Integer
        Dim ColName As String
        Dim TabIndex As Integer
        Sub Initialize()
            RowIndex = -1
            ColIndex = -1
            ColName = ""
            TabIndex = 0
        End Sub
    End Structure

    Private Structure ButtonInfo
        Dim Target As Control
        Dim Attr As ExpandItemParam.属性型
        Sub New(ByVal target As Control, ByVal attr As ExpandItemParam.属性型)
            Me.Target = target
            Me.Attr = attr
        End Sub
    End Structure
#End Region

#Region "コンストラクタ"
    Public Sub New()
        InitializeComponent()
        _contextMenu = New SmartControl.ContextMenu.ContextMenu
        _FieldBuilder = New List(Of ExpandItemParam.FieldBuilder定義型)
        _focusSwitcher = New FocusSwitcher
        _退避情報 = New 退避情報型
        _退避情報.Initialize(Me)
        _計算式解析 = New CalculateAnalysis
        _defaultValues = New Hashtable
        _isInitialize = True
        Me.サイズ保存 = False
        _actionButtons = New List(Of SimpleControl.CommandButton)()
        _buttonsByInputCtrl = New Dictionary(Of String, List(Of SimpleControl.CommandButton))(StringComparer.Ordinal)
        _btnInfoMap = New Dictionary(Of SimpleControl.CommandButton, ButtonInfo)()
        _focusctrl = New Control
    End Sub
#End Region

#Region "開始処理"
    Public Sub SetUpForm(ByRef 引受情報 As IDictionary) Implements ISubForm.SetUpForm
        _dataGet = False
        _systdate = CInt(Now.ToString("yyyyMMdd"))
        _UserID = システム環境情報.ログオンユーザー情報.ID
        functionBar.F1でヘルプ = FunctionBar.ヘルプタイプ.実行しない
        _paramInfo = 引受情報
        _列名マップ = CType(ParamInfo.Item("列名マップ"), Dictionary(Of String, String))

        'プログラム個別情報取得
        Dim infoXML As IDictionary = New Hashtable
        _conditionList = New List(Of ExpandItemParam.FieldBuilder定義型)
        Dim dataAccess As IControlReader = CreateDataAccessControlReader()
        dataAccess.Startup(infoXML, CStr(ParamInfo.Item("XMLファイル名")), _conditionList)

        If CInt(ParamInfo.Item("処理モード")) = 処理モード.初回起動 Then
            Dim checkMap As New Dictionary(Of String, Integer)(StringComparer.Ordinal)
            Dim labelMap As New Dictionary(Of String, String)(StringComparer.Ordinal)
            Dim zokuseiMap As New Dictionary(Of String, Integer)(StringComparer.Ordinal)
            For Each ei As ExpandItemParam.FieldBuilder定義型 In _conditionList
                Dim keyval As String = SafeString(ei.DB列名)
                If keyval.StartsWith("K", StringComparison.OrdinalIgnoreCase) Then
                    Dim inputcheck As Integer = CInt(ei.入力チェック) ' 0/1/2
                    checkMap(keyval) = inputcheck
                    Dim name As String = SafeString(ei.タイトル)
                    labelMap(keyval) = If(name.Length > 0, name, keyval)
                    Dim zokusei As Integer = CInt(ei.属性)
                    zokuseiMap(keyval) = zokusei
                End If
            Next
            ParamInfo("FieldBuilder_入力チェック定義") = checkMap
            ParamInfo("FieldBuilder_ラベル定義") = labelMap
            ParamInfo("FieldBuilder_属性") = zokuseiMap

            ' 画面を開かずに戻る
            Exit Sub

        End If
        SetPrivateInitInfo(InitInfo, infoXML)
        SetFormName()
        Me.ShowDialog()
    End Sub

    Private Function CreateDataAccessControlReader() As IControlReader
        Dim assemblyName As String = "OSK.X1.OTS.LIB.FieldBuilder.DA"
        Return DataAccessFactory(Of IControlReader).CreateInstance(Me, assemblyName, "ControlReader")
    End Function

    Private Sub SetPrivateInitInfo(ByRef initInfo As System.Collections.IDictionary, ByVal infoXML As System.Collections.IDictionary)
        If initInfo.Contains("プログラム専用.プログラム名") Then
            initInfo.Remove("プログラム専用.プログラム名")
        End If
        initInfo.Add("プログラム専用.プログラム名", infoXML.Item("プログラム専用.プログラム名"))

        If initInfo.Contains("プログラム専用.画面横幅") Then
            initInfo.Remove("プログラム専用.画面横幅")
        End If
        initInfo.Add("プログラム専用.画面横幅", infoXML.Item("プログラム専用.画面横幅"))

        If initInfo.Contains("プログラム専用.FieldBuilder設定") Then
            initInfo.Remove("プログラム専用.FieldBuilder設定")
        End If
        initInfo.Add("プログラム専用.FieldBuilder設定", _conditionList)
    End Sub

    Public Overrides Sub LoadImpl(ByVal sender As Object, ByVal e As System.EventArgs)
        MyBase.LoadImpl(sender, e)

        ' 戦略マップ初期化（UIAttrStrategies.vb のファクトリを呼び出し）
        Dim displayFormat_1 As OSK.X1.Foundation.Controls.InputDate.DisplayFormatType = ResolveDisplayFormat(CInt(InitInfo.Item("プログラム専用.日付形式")))
        _strategyMap = AttrStrategyFactory.BuildStrategyMap(displayFormat_1)

        SetContorls()
        ApplyInputValue()
        _ControlList = InitializeControlList(Me)

        Me.MessageViewer.Initialize(Me.SettingInfo)
        Me.MessageViewer.StatusLabelControl = Me.statusBar.StatusLabelControl

        SetAddhandler()
        SetProperty()
        InitializePosition()
        InitializeContextMenu()
        InitializeFunction()
        InitializeFocusSwitcher()
        Clear(True)
        _accessor = New PanelExpandItemAccessor(Me.FieldBuilderPanel)

        Dim focusKVar As String = String.Empty
        If ParamInfo IsNot Nothing AndAlso ParamInfo.Contains("初期フォーカス項目") Then
            focusKVar = CStr(ParamInfo.Item("初期フォーカス項目"))
        End If
        If Not String.IsNullOrWhiteSpace(focusKVar) Then
            Dim eiFocus As ExpandItemParam.FieldBuilder定義型 = GetFieldBuilder_DB列目(focusKVar)
            _focusctrl = Me.FieldBuilderPanel.Controls(CType(eiFocus.control, Control).Name)
            If _focusctrl IsNot Nothing AndAlso _focusctrl.CanFocus Then
                Dim args As CheckMethodArgs = New CheckMethodArgs(_focusctrl, _focusctrl, CheckMethodArgs.移動方向型.後へ, Keys.Return, False, 0)
                DoCheck確定処理(args)
            End If
        Else
            Dim args As CheckMethodArgs = New CheckMethodArgs(GetFirstControl(), GetFirstControl(), CheckMethodArgs.移動方向型.後へ, Keys.Return, False, 0)
            DoCheck確定処理(args)
        End If

        'Dim args As CheckMethodArgs = New CheckMethodArgs(GetFirstControl(), GetFirstControl(), CheckMethodArgs.移動方向型.後へ, Keys.Return, False, 0)
        'DoCheck確定処理(args)
    End Sub

    Public Overrides Sub OnLoadChangeFormSize()
        Dim 表示Height As Integer = Me.Height
        MyBase.OnLoadChangeFormSize()
        Dim 保存Height As Integer = Me.Height
        Me.Height = 表示Height
        Me.Top -= CInt((表示Height - 保存Height) / 2)
    End Sub
#End Region

#Region "初期処理"
    Private Sub SetContorls()
        Dim interval As Integer = 6
        Dim control As Control = Nothing
        Dim TabIndex As Integer = 1
        Dim point As Point = New Point(9, 9)
        Dim adjustHeight As Integer = 0
        Dim index As Integer = 0

        Me.FieldBuilderPanel.SuspendLayout()

        For Each obj As Object In CType(InitInfo.Item("プログラム専用.FieldBuilder設定"), List(Of ExpandItemParam.FieldBuilder定義型))
            Dim FieldBuilder As ExpandItemParam.FieldBuilder定義型 = CType(obj, ExpandItemParam.FieldBuilder定義型)

            'DB列名マッピング適用
            Dim original As String = FieldBuilder.DB列名
            If _列名マップ IsNot Nothing AndAlso _列名マップ.ContainsKey(original) Then
                FieldBuilder.DB列名 = _列名マップ(original)
            Else
                FieldBuilder.DB列名 = original
            End If

            If Not _strategyMap.ContainsKey(FieldBuilder.属性) Then
                Continue For
            End If

            control = _strategyMap(FieldBuilder.属性).CreateControl(FieldBuilder)
            control.TabIndex = TabIndex
            FieldBuilder.control = control

            RememberDefaults(TabIndex, FieldBuilder)

            control.Name = "ConditionCtrl_" & CStr(index).PadLeft(2, "0"c)
            control.Location = point
            Me.FieldBuilderPanel.Controls.Add(control)

            Dim isUrlOrMail As Boolean = FieldBuilder.属性 = ExpandItemParam.属性型.URL OrElse FieldBuilder.属性 = ExpandItemParam.属性型.メールアドレス
            Dim needRefer As Boolean = FieldBuilder.ボタン使用 = 1 AndAlso Not isUrlOrMail
            Dim needOpen As Boolean = FieldBuilder.属性 = ExpandItemParam.属性型.URL OrElse FieldBuilder.属性 = ExpandItemParam.属性型.メールアドレス _
                                      OrElse FieldBuilder.属性 = ExpandItemParam.属性型.画像 OrElse FieldBuilder.属性 = ExpandItemParam.属性型.実行ファイル _
                                      OrElse FieldBuilder.属性 = ExpandItemParam.属性型.ファイル OrElse FieldBuilder.属性 = ExpandItemParam.属性型.フォルダ

            Dim lastInput As Control = control
            Dim btnRefer As SimpleControl.CommandButton = Nothing

            '参照ボタン作成
            If needRefer Then
                btnRefer = CreateActionButton("参照", lastInput, FieldBuilder.属性)
                btnRefer.TabIndex = TabIndex + 1
                btnRefer.Name = "ConditionCtrl_" & CStr(index + 1).PadLeft(2, "0"c)
                btnRefer.Location = New Point(lastInput.Right + interval, point.Y - 1)
                _actionButtons.Add(btnRefer)
                RegisterInputCtrlButton(lastInput.Name, btnRefer)
                TabIndex += 1
                index += 1
            End If

            '開くボタン作成
            If needOpen Then
                Dim btnOpen As SimpleControl.CommandButton = CreateActionButton("開く ", lastInput, FieldBuilder.属性, interval + 1)
                btnOpen.TabIndex = TabIndex + 1
                btnOpen.Name = "ConditionCtrl_" & CStr(index + 1).PadLeft(2, "0"c)
                Dim xOpen As Integer
                If (btnRefer IsNot Nothing) Then
                    xOpen = btnRefer.Right + 3
                Else
                    xOpen = lastInput.Right + interval
                End If
                btnOpen.Location = New Point(xOpen, point.Y - 1)
                _actionButtons.Add(btnOpen)
                RegisterInputCtrlButton(lastInput.Name, btnOpen)
                TabIndex += 1
                index += 1
            End If

            adjustHeight += control.Height + interval
            point = New Point(9, 9 + adjustHeight)
            TabIndex += 1
            index += 1
        Next

        For Each btn As Control In _actionButtons
            Me.FieldBuilderPanel.Controls.Add(btn)
        Next

        Me.FieldBuilderPanel.ResumeLayout(True)
        Me.FieldBuilderPanel.PerformLayout()
    End Sub

    Private Sub SetDefaultValues()
        Dim i As Integer = 0
        Dim dt As DataTable = CType(ParamInfo.Item("サブ画面データ"), DataTable)
        Dim isViewMode As Boolean = (CInt(ParamInfo.Item("処理モード")) = 処理モード.参照)

        For Each FieldBuilder As ExpandItemParam.FieldBuilder定義型 In _FieldBuilder
            Dim ctrl As Control = Me.FieldBuilderPanel.Controls(CType(FieldBuilder.control, Control).Name)

            If ctrl Is Nothing Then
                Continue For
            End If

            If isViewMode AndAlso _strategyMap.ContainsKey(FieldBuilder.属性) Then
                _strategyMap(FieldBuilder.属性).SetReadOnly(ctrl, True)
            End If

            If (dt IsNot Nothing) AndAlso (dt.Rows.Count > 0) AndAlso dt.Columns.Contains(FieldBuilder.DB列名) Then
                Dim raw As Object = dt.Rows(0)(FieldBuilder.DB列名)
                Dim v As String
                If (raw Is Nothing) OrElse IsDBNull(raw) Then
                    v = ""
                Else
                    v = CStr(raw).Trim()
                End If

                Select Case FieldBuilder.属性
                    Case ExpandItemParam.属性型.数値
                        Dim d As Decimal = 0D
                        If Not Decimal.TryParse(v, d) Then
                            d = 0D
                        End If
                        v = d.ToString()

                    Case ExpandItemParam.属性型.日付, ExpandItemParam.属性型.日付_年月, ExpandItemParam.属性型.日付_年度
                        Dim n As Integer = 0
                        If Not Integer.TryParse(v, n) Then
                            n = 0
                        End If
                        v = n.ToString()
                End Select

                If _strategyMap.ContainsKey(FieldBuilder.属性) AndAlso FieldBuilder.デフォルト値 IsNot Nothing AndAlso FieldBuilder.デフォルト値.Count > 0 Then
                    FieldBuilder.デフォルト値(0) = v
                End If
            End If
            i += 1
        Next

    End Sub

    Private Sub SetFormName()
        Me.Text = ""
        If InitInfo.Contains("プログラム専用.プログラム名") Then
            Me.Text &= CStr(InitInfo.Item("プログラム専用.プログラム名"))
        End If
        If Me.システム環境情報.プログラム制御情報.会社名表示 Then
            Me.Text &= "－" & Me.システム環境情報.会社情報.名称
        End If
    End Sub

    Private Sub SetAddhandler()
        Dim control As Control = Nothing
        Me.statusBar.AutoGuideMessageClearFlag = True
        Me.statusBar.SetUpAutoClear(Me)
        For Each FieldBuilder As ExpandItemParam.FieldBuilder定義型 In _FieldBuilder
            control = Me.FieldBuilderPanel.Controls(CType(FieldBuilder.control, Control).Name)
        Next
    End Sub

    Private Sub SetProperty()
        Dim control As Control = Nothing
        Dim displayFormat_1 As OSK.X1.Foundation.Controls.InputDate.DisplayFormatType = ResolveDisplayFormat(CInt(InitInfo.Item("プログラム専用.日付形式")))
        For Each FieldBuilder As ExpandItemParam.FieldBuilder定義型 In _FieldBuilder
            control = Me.FieldBuilderPanel.Controls(CType(FieldBuilder.control, Control).Name)

            If control Is Nothing Then
                Continue For
            End If

            Select Case FieldBuilder.検索種別
                Case ExpandItemParam.検索種別型._1件指定
                    Select Case FieldBuilder.属性
                        Case ExpandItemParam.属性型.全角文字, ExpandItemParam.属性型.半角文字
                            Dim c As InputTextWithItemName = CType(control, InputTextWithItemName)
                            c.InputTextControl.GroupNo = GroupNo.グループ１
                            c.InputTextControl.Name = control.Name

                        Case ExpandItemParam.属性型.数値
                            Dim c As InputNumericalWithItemName = CType(control, InputNumericalWithItemName)
                            c.InputNumericalControl.GroupNo = GroupNo.グループ１
                            c.InputNumericalControl.Name = control.Name

                        Case ExpandItemParam.属性型.日付, ExpandItemParam.属性型.日付_年月, ExpandItemParam.属性型.日付_年度
                            Dim c As InputDateWithItemName = CType(control, InputDateWithItemName)
                            c.InputDateControl.GroupNo = GroupNo.グループ１
                            c.InputDateControl.Name = control.Name
                            c.InputDateControl.DisplayFormat = displayFormat_1
                            c.Width += 5

                        Case ExpandItemParam.属性型.URL, ExpandItemParam.属性型.ファイル, ExpandItemParam.属性型.実行ファイル,
                             ExpandItemParam.属性型.画像, ExpandItemParam.属性型.フォルダ, ExpandItemParam.属性型.メールアドレス
                            If TypeOf control Is SimpleControl.CommandButton Then
                                Dim b As SimpleControl.CommandButton = CType(control, SimpleControl.CommandButton)
                                b.GroupNo = GroupNo.グループ１
                                b.Name = control.Name
                            Else
                                Dim c As InputTextWithItemName = CType(control, InputTextWithItemName)
                                c.InputTextControl.GroupNo = GroupNo.グループ１
                                c.InputTextControl.Name = control.Name
                            End If

                        Case ExpandItemParam.属性型.参照定義コード
                            Dim c As InputTextWithItemNameAndInputName = CType(control, InputTextWithItemNameAndInputName)
                            c.InputTextControl.GroupNo = GroupNo.グループ１
                            c.Name = control.Name
                            c.InputTextControl.Name = control.Name
                    End Select
            End Select
        Next

        With Me.execute
            .GroupNo = GroupNo.グループ３
            .Visible = True
            Select Case CInt(ParamInfo.Item("処理モード"))
                Case 処理モード.入力
                    .Text = "確定"
                Case 処理モード.参照
                    .Visible = False
            End Select
        End With

        With Me.cancel
            .GroupNo = GroupNo.グループ３
            .Visible = True
            If CInt(ParamInfo.Item("処理モード")) = 処理モード.参照 Then
                .Text = "戻る"
            End If
        End With
    End Sub

    Private Sub InitializePosition()
        Dim interval As Integer = 6
        Me.FieldBuilderPanel.AutoScroll = True
        Me.FieldBuilderPanel.AutoScrollMargin = New Size(0, interval)
        SetFormHeight()
    End Sub

    Private Sub SetFormHeight()
        Me.Size = New Drawing.Size(CInt(InitInfo.Item("プログラム専用.画面横幅")), Me.Height)
    End Sub

    Private Sub InitializeFocusSwitcher()
        With _focusSwitcher
            .SetForm(Me)
            For Each ctrl As Control In _ControlList
                .AddControl(ctrl)
            Next
            .AddControl(Me.execute)
            .AddControl(Me.cancel)
            .AddPreviousCheckDefaultMethod(AddressOf DoCheck前処理)
            .AddCheckAfterDefaultMethod(AddressOf DoCheck確定処理)
            .AddGroupCheckMethod(GroupNo.グループ１, CheckModeType.移動元チェック, AddressOf DoCheckGroupMoveOut_Group1)
            .AddGroupCheckMethod(GroupNo.グループ３, CheckModeType.移動先チェック, AddressOf DoCheckGroupMoveIn_Group3)
        End With
    End Sub

    Private Function InitializeControlList(ByVal top As Control) As Control()
        Dim ctrlList As ArrayList = New ArrayList
        For Each ctrl As Control In top.Controls
            If CheckTargetControl(ctrl) Then
                ctrlList.Add(ctrl)
            End If
            If ctrl.HasChildren Then
                ctrlList.AddRange(InitializeControlList(ctrl))
            End If
        Next
        Return CType(ctrlList.ToArray(GetType(Control)), Control())
    End Function

    Private Function CheckTargetControl(ByVal ctrl As Control) As Boolean
        If TypeOf ctrl Is OSK.X1.Foundation.Controls.Common.Control Then
            Select Case True
                Case TypeOf ctrl Is SimpleControl.CheckBox
                Case TypeOf ctrl Is SimpleControl.ComboBox
                Case TypeOf ctrl Is SimpleControl.CommandButton
                Case TypeOf ctrl Is SimpleControl.GridView
                Case TypeOf ctrl Is SimpleControl.GridEdit
                Case TypeOf ctrl Is SimpleControl.GroupOption
                Case TypeOf ctrl Is SimpleControl.InputDate
                Case TypeOf ctrl Is SimpleControl.InputNumerical
                Case TypeOf ctrl Is SimpleControl.InputText
                Case Else
                    Return False
            End Select
            Dim fcControl As Common.Control = CType(ctrl, Common.Control)
            If fcControl.ReadOnly Then
                Return False
            End If
        ElseIf TypeOf ctrl Is GridView Then
            ' 対象
        ElseIf TypeOf ctrl Is GridEdit Then
            ' 対象
        Else
            Return False
        End If
        Return True
    End Function

    Private Sub RegisterInputCtrlButton(ByVal InputCtrlName As String, ByVal btn As SimpleControl.CommandButton)
        If Not _buttonsByInputCtrl.ContainsKey(InputCtrlName) Then
            _buttonsByInputCtrl(InputCtrlName) = New List(Of SimpleControl.CommandButton)()
        End If
        _buttonsByInputCtrl(InputCtrlName).Add(btn)
    End Sub

    Private Sub AdjustButtonsForViewMode(ByVal isViewMode As Boolean)
        Dim interval As Integer = 6
        For Each btn As SimpleControl.CommandButton In _actionButtons
            Dim info As ButtonInfo = Nothing
            If (Not _btnInfoMap.TryGetValue(btn, info)) OrElse (info.Target Is Nothing) Then
                Continue For
            End If
            Dim target As Control = info.Target

            If isViewMode Then
                If btn.Text = "参照" Then
                    btn.Visible = False
                ElseIf btn.Text = "開く " Then
                    Dim referBtn As SimpleControl.CommandButton = FindSiblingButton(target.Name, "参照")
                    If referBtn IsNot Nothing Then
                        btn.Location = referBtn.Location
                    Else
                        btn.Location = New Point(target.Right + interval, target.Top - 1)
                    End If
                    btn.BringToFront()
                    btn.Visible = True
                    Dim value As String = GetControlValue(target)
                    If value = String.Empty Then
                        btn.Enabled = False
                    Else
                        btn.Enabled = True
                    End If
                End If
            Else
                btn.Visible = True
                If btn.Text = "開く " Then
                    Dim referBtn As SimpleControl.CommandButton = FindSiblingButton(target.Name, "参照")
                    Dim xOpen As Integer
                    If (referBtn IsNot Nothing) AndAlso referBtn.Visible Then
                        xOpen = referBtn.Right + 3
                    Else
                        xOpen = target.Right + interval
                    End If
                    btn.Location = New Point(xOpen, target.Top - 1)
                End If
            End If
        Next
    End Sub

    Private Function FindSiblingButton(ByVal inputCtrlName As String, ByVal text As String) As SimpleControl.CommandButton
        Dim list As List(Of SimpleControl.CommandButton) = Nothing
        If (Not _buttonsByInputCtrl.TryGetValue(inputCtrlName, list)) OrElse (list Is Nothing) Then
            Return Nothing
        End If
        For Each b As SimpleControl.CommandButton In list
            If String.Equals(b.Text, text, StringComparison.Ordinal) Then
                Return b
            End If
        Next
        Return Nothing
    End Function

    Private Function ResolveDisplayFormat(ByVal mode As Integer) As OSK.X1.Foundation.Controls.InputDate.DisplayFormatType
        Select Case mode
            Case 0
                Return OSK.X1.Foundation.Controls.InputDate.DisplayFormatType.YYYY
            Case 1
                Return OSK.X1.Foundation.Controls.InputDate.DisplayFormatType.YY
            Case 2
                Return OSK.X1.Foundation.Controls.InputDate.DisplayFormatType.gggEE
            Case Else
                Return OSK.X1.Foundation.Controls.InputDate.DisplayFormatType.YYYY
        End Select
    End Function

    Private Function GetControlValue(ByVal target As Control) As String
        For Each FieldBuilder As ExpandItemParam.FieldBuilder定義型 In _FieldBuilder
            Dim ctrl As Control = Me.FieldBuilderPanel.Controls(CType(FieldBuilder.control, Control).Name)
            If TypeOf FieldBuilder.control Is SimpleControl.CommandButton Then
                Continue For
            End If
            If target.Name = ctrl.Name Then
                If TypeOf ctrl Is InputTextWithItemName Then
                    Return CType(ctrl, InputTextWithItemName).TextValue

                ElseIf TypeOf ctrl Is InputNumericalWithItemName Then
                    Return CType(ctrl, InputNumericalWithItemName).Value.ToString()
                ElseIf TypeOf ctrl Is InputDateWithItemName Then
                    Return CType(ctrl, InputDateWithItemName).DateValue.ToString()
                ElseIf TypeOf ctrl Is InputTextWithItemNameAndInputName Then
                    Return CType(ctrl, InputTextWithItemNameAndInputName).InputTextControl.Text
                End If
            End If
        Next
        Return String.Empty
    End Function

#End Region

#Region "画面クリア"
    Private Sub Clear(Optional ByVal isLoad As Boolean = False)
        ClearDefault(isLoad)
    End Sub

#Region "画面クリア（初期状態）"
    Private Sub ClearDefault(Optional ByVal isLoad As Boolean = False)
        Dim ctrl As Control = Nothing
        Dim 参照FieldBuilder As ExpandItemParam.FieldBuilder定義型 = New ExpandItemParam.FieldBuilder定義型
        Dim code As String = String.Empty
        Dim isViewMode As Boolean = (CInt(ParamInfo.Item("処理モード")) = 処理モード.参照)
        For Each FieldBuilder As ExpandItemParam.FieldBuilder定義型 In _FieldBuilder
            ctrl = Me.FieldBuilderPanel.Controls(CType(FieldBuilder.control, Control).Name)
            If TypeOf FieldBuilder.control Is SimpleControl.CommandButton Then
                Continue For
            End If
            If _strategyMap.ContainsKey(FieldBuilder.属性) Then
                _strategyMap(FieldBuilder.属性).SetDefault(ctrl, FieldBuilder.デフォルト値)
            End If
            If FieldBuilder.属性 = ExpandItemParam.属性型.参照定義コード Then
                参照FieldBuilder = FieldBuilder
                Dim comp As InputTextWithItemNameAndInputName = CType(ctrl, InputTextWithItemNameAndInputName)
                code = comp.InputTextControl.Text
                If code Is Nothing Then
                    code = String.Empty
                End If
                code = code.Trim()
            End If
        Next
        If code.Length > 0 Then
            DisplayItem(参照FieldBuilder, code)
        End If

        AdjustButtonsForViewMode(isViewMode)
    End Sub
#End Region
#End Region

#Region "フォーカス制御"
    Private Function DoCheckGroupMoveOut_Group1(ByVal args As CheckMethodArgs) As Boolean
        If args.移動先グループ番号 <= GroupNo.グループ１ Then
            Return True
        End If
        If args.移動先コントロール Is cancel Then Return True
        If Not CanOutput() Then
            args.失敗時動作 = CheckMethodArgs.失敗時動作型.移動する
            Return False
        End If
        Return True
    End Function

    Private Function DoCheckGroupMoveIn_Group3(ByVal args As CheckMethodArgs) As Boolean
        Return True
    End Function

    Private Function DoCheck前処理(ByVal args As CheckMethodArgs) As Boolean
        If _functionEvent = True AndAlso args.移動元KeyDownCode = Keys.None Then
            args.移動元KeyDownCode = System.Windows.Forms.Keys.Return
        End If
        _functionEvent = False

        Select Case args.移動先コントロール.Name
            Case execute.Name
                Select Case args.移動元グループ番号
                    Case GroupNo.グループ１
                    Case Else
                        If args.移動元コントロール Is Me.cancel AndAlso args.移動方向 = CheckMethodArgs.移動方向型.前へ Then
                            args.移動先コントロール = Me.execute
                        ElseIf args.移動元KeyDownCode <> Keys.None Then
                            args.移動先コントロール = _focusSwitcher.GetPrevControl(execute)
                        End If
                End Select
        End Select

        If Not TryResolveDispNameOnLeave(args) Then
            args.失敗時動作 = CheckMethodArgs.失敗時動作型.移動する
            Return False
        End If
        If Not TryCalculateAnalysis(args) Then
            args.失敗時動作 = CheckMethodArgs.失敗時動作型.移動する
        End If
        Return True
    End Function

    Private Sub DoCheck確定処理(ByVal args As CheckMethodArgs)
        If args.移動先グループ番号 < GroupNo.グループ２ Then
            Me.FieldBuilderPanel.Controls(0).Enabled = True
        End If
        If args.失敗時動作 = CheckMethodArgs.失敗時動作型.移動する Then
            ' そのまま
        Else
            statusBar.StatusLabelControl.Text = ""
        End If
        _functionEvent = False

        If _pendingExecute AndAlso args.移動先コントロール Is Me.execute Then
            _pendingExecute = False
            If args.移動元TabKeyDown Then
            ElseIf _keyF9_行終了 Then
                _keyF9_行終了 = False
            Else
                Me.BeginInvoke(New Action(Sub() Me.execute.PerformClick()))
            End If
        End If
    End Sub
#End Region

#Region "イベント"
    Private Sub ExpandItemForm_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        If _isInitialize Then
            _isInitialize = False
        End If
        SetDefaultValues()
        Clear()
        Dim firstControl As New Control
        If CInt(ParamInfo.Item("処理モード")) <> 処理モード.参照 Then

            If _focusctrl IsNot Nothing AndAlso _focusctrl.CanFocus Then
                _focusctrl.Focus()
            Else
                firstControl = GetFirstControl()
                If firstControl IsNot Nothing AndAlso firstControl.CanFocus Then
                    firstControl.Focus()
                End If
            End If
        End If

    End Sub

    Private Sub KensakuForm_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Me.KeyDown
        If e.KeyCode = Keys.ShiftKey Then
            Exit Sub
        End If
        Select Case e.KeyCode
            Case Keys.Escape
                Me.Close()
        End Select
    End Sub
#End Region

#Region "条件チェック"
    Private Function CanOutput() As Boolean
        Return CheckCondition()
    End Function

    Private Function CheckCondition() As Boolean
        Return IsCorrectDisplayValue()
    End Function

    Private Function IsCorrectDisplayValue() As Boolean
        Dim control As Control = Nothing
        For Each FieldBuilder As ExpandItemParam.FieldBuilder定義型 In _FieldBuilder
            control = Me.FieldBuilderPanel.Controls(CType(FieldBuilder.control, Control).Name)
            Select Case FieldBuilder.検索種別
                Case ExpandItemParam.検索種別型._1件指定
                    If Not IsCorrectOneDataControl(FieldBuilder, control) Then
                        Return False
                    End If
            End Select
        Next
        Return True
    End Function

    Private Function IsCorrectOneDataControl(ByVal FieldBuilder As ExpandItemParam.FieldBuilder定義型, ByVal control As Control) As Boolean

        Dim result As PanelExpandItemAccessor.ValidationResult = _accessor.Validate(FieldBuilder)

        ' --- 必須未入力：エラーメッセージ（247）＋フォーカス返却 ---
        If Not result.IsValid AndAlso result.HasMissingRequired Then
            If result.FirstErrorControl IsNot Nothing Then
                result.FirstErrorControl.Focus()
            End If
            Me.MessageViewer.Show(247, , result.FirstErrorItemName)
            Return False
        End If

        ' --- 警告：Yes/No確認（MESSAGE_01） ---
        If result.IsWarning Then
            Dim message As String = result.WarningItemName & MESSAGE_01
            If OSKMessageBox.Show(message,
                              Me.システム環境情報.プログラム情報.名称,
                              MessageBoxButtons.YesNo,
                              MessageBoxIcon.Question,
                              MessageBoxDefaultButton.Button2) <> DialogResult.Yes Then
                If result.WarningControl IsNot Nothing AndAlso result.WarningControl.CanFocus Then
                    result.WarningControl.Focus()
                End If
                Return False
            End If
            Me._pendingExecute = True
        End If

        Return True
    End Function
#End Region

#Region "マスター取得時のパラメータ設定"
    Private Sub GetKensakuJoken任意項目(ByRef param As ExpandItemParam)
        For i As Integer = 1 To _任意項目設定数
            param.任意項目.Add("任意項目" & CStr(i), Get任意項目(i))
        Next
    End Sub

    Private Function Get任意項目(ByVal index As Integer) As String
        Dim 任意項目 As String
        If Not ParamInfo.Contains("任意項目" & CStr(index)) Then
            任意項目 = ""
        Else
            任意項目 = CStr(ParamInfo.Item("任意項目" & CStr(index)))
        End If
        Return 任意項目
    End Function
#End Region

#Region "データ読込"
    Private Sub 画面入力制御(ByVal readOnlyMode As Boolean)
        Select Case readOnlyMode
            Case True
                Me.statusBar.PrepareDoProgress()
            Case Else
                Me.statusBar.StopDoProgress()
                Me.statusBar.StatusLabelControl.Text = ""
                RestoreReadOnly()
        End Select
    End Sub

    Private Sub WaitAccessorProcess(ByVal accessorBase As DataAccessor)
        Do While accessorBase.EndFlag = False
            Me.statusBar.DoProgress()
            Me.statusBar.Refresh()
        Loop
    End Sub
#End Region

#Region "先頭項目へのフォーカス"
    Private Function GetFirstControl() As Control
        Dim firstControl As Control
        Dim FieldBuilder As ExpandItemParam.FieldBuilder定義型 = CType(_FieldBuilder(0), ExpandItemParam.FieldBuilder定義型)
        firstControl = Me.FieldBuilderPanel.Controls(CType(FieldBuilder.control, Control).Name)

        Select Case FieldBuilder.検索種別
            Case ExpandItemParam.検索種別型._1件指定
                Select Case FieldBuilder.属性
                    Case ExpandItemParam.属性型.全角文字, ExpandItemParam.属性型.半角文字, ExpandItemParam.属性型.画像,
                         ExpandItemParam.属性型.実行ファイル, ExpandItemParam.属性型.ファイル, ExpandItemParam.属性型.フォルダ,
                         ExpandItemParam.属性型.URL, ExpandItemParam.属性型.メールアドレス
                        firstControl = CType(Me.FieldBuilderPanel.Controls(CType(FieldBuilder.control, Control).Name), InputTextWithItemName).InputTextControl
                    Case ExpandItemParam.属性型.数値
                        firstControl = CType(Me.FieldBuilderPanel.Controls(CType(FieldBuilder.control, Control).Name), InputNumericalWithItemName).InputNumericalControl
                    Case ExpandItemParam.属性型.日付, ExpandItemParam.属性型.日付_年月, ExpandItemParam.属性型.日付_年度
                        firstControl = CType(Me.FieldBuilderPanel.Controls(CType(FieldBuilder.control, Control).Name), InputDateWithItemName).InputDateControl
                    Case ExpandItemParam.属性型.参照定義コード
                        firstControl = CType(Me.FieldBuilderPanel.Controls(CType(FieldBuilder.control, Control).Name), InputTextWithItemNameAndInputName).InputTextControl
                    Case Else
                        firstControl = Me.FieldBuilderPanel.Controls(CType(FieldBuilder.control, Control).Name)
                End Select
            Case Else
                firstControl = Me.FieldBuilderPanel.Controls(CType(FieldBuilder.control, Control).Name)
        End Select
        Return firstControl
    End Function
#End Region

#Region "ファンクションバー"
    Private Sub InitializeFunction()
        Dim control As Control = Nothing
        With functionBar
            With .Items
                For Each FieldBuilder As ExpandItemParam.FieldBuilder定義型 In _FieldBuilder
                    control = Me.FieldBuilderPanel.Controls(CType(FieldBuilder.control, Control).Name)
                    Select Case FieldBuilder.検索種別
                        Case ExpandItemParam.検索種別型._1件指定
                            Select Case FieldBuilder.属性
                                Case ExpandItemParam.属性型.全角文字, ExpandItemParam.属性型.半角文字
                                    .SetControl(CType(control, InputTextWithItemName).InputTextControl, FunctionControl.KeyType.F5, "クリア", AddressOf DisplayClear)
                                    .SetControl(CType(control, InputTextWithItemName).InputTextControl, FunctionControl.KeyType.F9, "以下省略", AddressOf RequestDoComplete)
                                    If FieldBuilder.計算式 = 1 AndAlso FieldBuilder.入力可否 = 1 Then
                                        .SetControl(CType(control, InputTextWithItemName).InputTextControl, FunctionControl.KeyType.F12, "再計算", AddressOf RequestRecalculate)
                                    End If

                                Case ExpandItemParam.属性型.数値
                                    .SetControl(CType(control, InputNumericalWithItemName).InputNumericalControl, FunctionControl.KeyType.F5, "クリア", AddressOf DisplayClear)
                                    .SetControl(CType(control, InputNumericalWithItemName).InputNumericalControl, FunctionControl.KeyType.F9, "以下省略", AddressOf RequestDoComplete)
                                    If FieldBuilder.計算式 = 1 AndAlso FieldBuilder.入力可否 = 1 Then
                                        .SetControl(CType(control, InputNumericalWithItemName).InputNumericalControl, FunctionControl.KeyType.F12, "再計算", AddressOf RequestRecalculate)
                                    End If

                                Case ExpandItemParam.属性型.日付, ExpandItemParam.属性型.日付_年月, ExpandItemParam.属性型.日付_年度
                                    .SetControl(CType(control, InputDateWithItemName).InputDateControl, FunctionControl.KeyType.F5, "クリア", AddressOf DisplayClear)
                                    .SetControl(CType(control, InputDateWithItemName).InputDateControl, FunctionControl.KeyType.F9, "以下省略", AddressOf RequestDoComplete)

                                Case ExpandItemParam.属性型.画像, ExpandItemParam.属性型.実行ファイル, ExpandItemParam.属性型.ファイル, ExpandItemParam.属性型.フォルダ
                                    If FieldBuilder.ボタン使用 = 1 Then
                                        .SetControl(CType(control, InputTextWithItemName).InputTextControl, FunctionControl.KeyType.F3, "参照", AddressOf OpenDialogByKey)
                                        .SetControl(CType(control, InputTextWithItemName).InputTextControl, FunctionControl.KeyType.F5, "クリア", AddressOf DisplayClear)
                                        .SetControl(CType(control, InputTextWithItemName).InputTextControl, FunctionControl.KeyType.F7, "開く", AddressOf OpenAppByKey)
                                        .SetControl(CType(control, InputTextWithItemName).InputTextControl, FunctionControl.KeyType.F9, "以下省略", AddressOf RequestDoComplete)
                                    End If

                                Case ExpandItemParam.属性型.URL, ExpandItemParam.属性型.メールアドレス
                                    If FieldBuilder.ボタン使用 = 1 Then
                                        .SetControl(CType(control, InputTextWithItemName).InputTextControl, FunctionControl.KeyType.F5, "クリア", AddressOf DisplayClear)
                                        .SetControl(CType(control, InputTextWithItemName).InputTextControl, FunctionControl.KeyType.F7, "開く", AddressOf OpenAppByKey)
                                        .SetControl(CType(control, InputTextWithItemName).InputTextControl, FunctionControl.KeyType.F9, "以下省略", AddressOf RequestDoComplete)
                                    End If

                                Case ExpandItemParam.属性型.参照定義コード
                                    .SetControl(CType(control, InputTextWithItemNameAndInputName).InputTextControl, FunctionControl.KeyType.F3, "マスター検索", AddressOf MasterSearch)
                                    .SetControl(CType(control, InputTextWithItemNameAndInputName).InputTextControl, FunctionControl.KeyType.F5, "クリア", AddressOf DisplayClear)
                                    .SetControl(CType(control, InputTextWithItemNameAndInputName).InputTextControl, FunctionControl.KeyType.F9, "以下省略", AddressOf RequestDoComplete)
                            End Select
                    End Select
                Next
            End With
            .SetUpFunctionEvent(Me)
        End With
    End Sub

    Private Sub MasterSearch(ByVal control As Control)
        Dim result As Boolean = False
        Dim paramInfo As IDictionary = New Hashtable
        Dim index As Integer = -1
        _functionEvent = True

        For Each FieldBuilder As ExpandItemParam.FieldBuilder定義型 In _FieldBuilder
            index += 1
            If control.Name.StartsWith(CType(FieldBuilder.control, Control).Name) Then
                If FieldBuilder.マスター検索項目.loader Is Nothing Then
                    FieldBuilder.マスター検索項目.loader = New ProgramLoad.UserInterface.LocalLoader
                    CType(FieldBuilder.マスター検索項目.loader, ILocalLoader).Startup(Me, FieldBuilder.マスター検索項目.コード検索, FieldBuilder.マスター検索項目.コード検索枝番)
                End If
                For Each 引数 As KeyValuePair(Of String, Object) In FieldBuilder.マスター検索項目.引数
                    paramInfo.Add(引数.Key, 引数.Value)
                Next
                CType(FieldBuilder.マスター検索項目.loader, ILocalLoader).Run(paramInfo)
                If paramInfo.Contains(FieldBuilder.マスター検索項目.戻り値(0)) Then
                    Select Case FieldBuilder.検索種別
                        Case Else
                            control.Text = CType(paramInfo.Item(FieldBuilder.マスター検索項目.戻り値(0)), String)
                    End Select
                    result = True
                End If
                If result Then
                    _focusSwitcher.GetNextControl(control).Focus()
                Else
                    control.Focus()
                End If
                _FieldBuilder(index) = FieldBuilder
                Exit For
            End If
        Next
    End Sub


    Private Sub DisplayClear(ByVal control As Control)
        If MyBase.MessageViewer.Show(48, IMessageViewer.DefaultButtonType.No) = IMessageViewer.ShowResultType.No Then
            Exit Sub
        End If
        _画面クリア中 = True
        _functionEvent = True
        ClearDefault()
        ClearAll()
        _画面クリア中 = False
        Dim firstCtrl As Control = GetFirstControl()
        If (firstCtrl IsNot Nothing) AndAlso firstCtrl.CanFocus Then
            firstCtrl.Focus()
        End If
    End Sub

    Private Sub RequestDoComplete(ByVal control As Control)
        _keyF9_行終了 = True
        Me.execute.Focus()
    End Sub

    Private Sub OpenDialogByKey(ByVal control As Control)
        Dim FieldBuilder As ExpandItemParam.FieldBuilder定義型 = CType(_FieldBuilder(0), ExpandItemParam.FieldBuilder定義型)
        Dim inputctrl As Control = Nothing
        Dim selectedPath As String = String.Empty
        If Not Find_Def_Control(control, inputctrl, FieldBuilder) Then
            Exit Sub
        End If
        Select Case FieldBuilder.属性
            Case ExpandItemParam.属性型.画像, ExpandItemParam.属性型.実行ファイル, ExpandItemParam.属性型.ファイル, ExpandItemParam.属性型.フォルダ
                OpenDialog(inputctrl, FieldBuilder.属性)
        End Select
        If _focusSwitcher IsNot Nothing Then
            Dim nextCtrl As Control = _focusSwitcher.GetNextControl(control)
            If (nextCtrl IsNot Nothing) AndAlso nextCtrl.CanFocus Then
                nextCtrl.Focus()
            End If
        End If
    End Sub

    Private Sub OpenAppByKey(ByVal control As Control)
        Dim FieldBuilder As ExpandItemParam.FieldBuilder定義型 = CType(_FieldBuilder(0), ExpandItemParam.FieldBuilder定義型)
        Dim inputctrl As Control = Nothing
        If Not Find_Def_Control(control, inputctrl, FieldBuilder) Then
            Exit Sub
        End If
        Select Case FieldBuilder.属性
            Case ExpandItemParam.属性型.URL, ExpandItemParam.属性型.メールアドレス, ExpandItemParam.属性型.画像,
                 ExpandItemParam.属性型.実行ファイル, ExpandItemParam.属性型.ファイル, ExpandItemParam.属性型.フォルダ
                OpenApp(inputctrl, FieldBuilder.属性)
        End Select
    End Sub

    Private Function Find_Def_Control(ByVal control As Control,
                                      ByRef inputctrl As Control,
                                      ByRef FieldBuilder As ExpandItemParam.FieldBuilder定義型) As Boolean
        For Each FieldBuilder定義 As ExpandItemParam.FieldBuilder定義型 In _FieldBuilder
            Dim comp As Control = Me.FieldBuilderPanel.Controls(CType(FieldBuilder定義.control, Control).Name)
            If (comp IsNot Nothing) AndAlso String.Equals(comp.Name, control.Name, StringComparison.Ordinal) Then
                inputctrl = comp
                FieldBuilder = FieldBuilder定義
                Return True
            End If
        Next
        FieldBuilder = Nothing
        Return False
    End Function

    Private Sub ClearAll()
        Dim ctrl As Control
        For Each FieldBuilder As ExpandItemParam.FieldBuilder定義型 In Me._FieldBuilder
            ctrl = Me.FieldBuilderPanel.Controls(CType(FieldBuilder.control, Control).Name)
            Select Case FieldBuilder.属性
                Case ExpandItemParam.属性型.全角文字,
                     ExpandItemParam.属性型.半角文字,
                     ExpandItemParam.属性型.URL,
                     ExpandItemParam.属性型.メールアドレス,
                     ExpandItemParam.属性型.画像,
                     ExpandItemParam.属性型.実行ファイル,
                     ExpandItemParam.属性型.ファイル,
                     ExpandItemParam.属性型.フォルダ
                    Dim c As InputTextWithItemName = CType(ctrl, InputTextWithItemName)
                    c.TextValue = String.Empty

                Case ExpandItemParam.属性型.数値
                    Dim c As InputNumericalWithItemName = CType(ctrl, InputNumericalWithItemName)
                    c.Value = 0D

                Case ExpandItemParam.属性型.日付,
                     ExpandItemParam.属性型.日付_年月,
                     ExpandItemParam.属性型.日付_年度
                    Dim c As InputDateWithItemName = CType(ctrl, InputDateWithItemName)
                    c.DateValue = 0

                Case ExpandItemParam.属性型.参照定義コード
                    Dim c As InputTextWithItemNameAndInputName = CType(ctrl, InputTextWithItemNameAndInputName)
                    c.InputTextControl.Text = String.Empty
                    c.DispNameControl.Text = String.Empty
            End Select
        Next
    End Sub

    Private Sub RequestRecalculate(ByVal control As Control)
        Dim wrapper As Control
        If (control IsNot Nothing) AndAlso (control.Parent IsNot Nothing) Then
            wrapper = control.Parent
        Else
            wrapper = control
        End If

        ''フォーカスのFieldBuilder（反映先想定）を特定
        Dim currentEi As New ExpandItemParam.FieldBuilder定義型
        Dim found As Boolean = False
        For Each FieldBuilder As ExpandItemParam.FieldBuilder定義型 In Me._FieldBuilder
            Dim c As Control = Me.FieldBuilderPanel.Controls(CType(FieldBuilder.control, Control).Name)
            If (c IsNot Nothing) AndAlso String.Equals(c.Name, wrapper.Name, StringComparison.Ordinal) Then
                currentEi = FieldBuilder
                found = True
                Exit For
            End If
        Next
        If Not found Then
            Exit Sub
        End If
        '反映先の @項目変数を取得（例："@K1"）。未設定なら終了
        Dim destVar As String = SafeString(currentEi.項目変数).Trim()
        If destVar.Length = 0 Then
            Exit Sub
        End If

        Dim successAny As Boolean = False
        Dim executedKeys As HashSet(Of String) = New HashSet(Of String)(StringComparer.Ordinal)
        For Each 計算元FieldBuilder As ExpandItemParam.FieldBuilder定義型 In Me._FieldBuilder
            Dim isCalcSource As Boolean = (計算元FieldBuilder.計算式 = 1) AndAlso (CInt(計算元FieldBuilder.入力可否) = 0) AndAlso HasCalcDefinition(計算元FieldBuilder)
            If Not isCalcSource Then
                Continue For
            End If

            Dim reflectDef As String = SafeString(計算元FieldBuilder.計算式項目.反映先).Trim()
            If reflectDef.Length = 0 Then
                Continue For
            End If

            Dim varList As List(Of String) = Get変数一覧(reflectDef, 抽出対象型.反映先対象)
            If (varList Is Nothing) OrElse (varList.Count = 0) Then
                Continue For
            End If

            Dim hit As Boolean = False
            For Each s As String In varList
                If String.Equals(s, destVar, StringComparison.Ordinal) Then
                    hit = True
                    Exit For
                End If
            Next
            If Not hit Then
                Continue For
            End If
            '重複計算をスキップ
            Dim getData As String = SafeString(計算元FieldBuilder.計算式項目.取得データ).Trim()
            Dim dedupKey As String = getData & "\n" & destVar
            If Not executedKeys.Add(dedupKey) Then
                Continue For
            End If

            Dim srcCtrl As Control = Me.FieldBuilderPanel.Controls(CType(計算元FieldBuilder.control, Control).Name)
            If srcCtrl Is Nothing Then
                Continue For
            End If

            Dim args As CheckMethodArgs = New CheckMethodArgs(srcCtrl, srcCtrl, CheckMethodArgs.移動方向型.後へ, Keys.Return, False, 0)
            Dim ok As Boolean = TryCalculateAnalysis(args)
            successAny = successAny OrElse ok
        Next
        '1件でも成功したら次項目へフォーカス
        If successAny AndAlso _focusSwitcher IsNot Nothing Then
            Dim nextCtrl As Control = _focusSwitcher.GetNextControl(control)
            If nextCtrl IsNot Nothing AndAlso nextCtrl.CanFocus Then
                nextCtrl.Focus()
            End If
        End If
    End Sub

    '計算式定義の有効性チェック（Null＋中身の妥当性まで）
    Private Function HasCalcDefinition(ByVal FieldBuilder As ExpandItemParam.FieldBuilder定義型) As Boolean
        Dim calcDef As Object = CType(FieldBuilder.計算式項目, Object)
        If calcDef Is Nothing Then
            Return False
        End If
        Dim getData As String = SafeString(FieldBuilder.計算式項目.取得データ).Trim()
        Dim dest As String = SafeString(FieldBuilder.計算式項目.反映先).Trim()
        If getData.Length = 0 OrElse dest.Length = 0 Then
            Return False
        End If
        Return True
    End Function
#End Region

#Region "コンテキストメニュー"
    Private Sub InitializeContextMenu()
        _contextMenu.FunctionBar = functionBar
    End Sub
#End Region

#Region "メニューバーイベント"
    Private Sub endForm_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles endMenu.Click
        Me.Close()
    End Sub
#End Region

#Region "予約語変換"
    Private Function ReservedWordConv(ByVal value As String) As String
        Dim resultvalue As String = value
        Select Case value
            Case "@SYSDATE"
                resultvalue = CType(_systdate, String)
            Case "@USERID"
                resultvalue = _UserID
        End Select
        Return resultvalue
    End Function
#End Region

#Region "検索条件を自動的に隠す"
    Private Sub HideCondtionView(ByVal hide As Boolean)
        If Me.FieldBuilderPanel.Visible = Not hide Then
            Exit Sub
        End If
        Me.FieldBuilderPanel.Visible = Not hide
    End Sub

    Private Sub KensakuForm_FormClosed(ByVal sender As Object, ByVal e As FormClosedEventArgs) Handles Me.FormClosed
        HideCondtionView(False)
    End Sub
#End Region

#Region "省略判定"
    Private Function Is省略判定(ByVal FieldBuilder As ExpandItemParam.FieldBuilder定義型) As 省略判定結果型
        Select Case FieldBuilder.入力チェック
            Case 0
                Return 省略判定結果型.省略可
            Case 1
                Return 省略判定結果型.警告
            Case 2
                Return 省略判定結果型.必須
            Case Else
                Return 省略判定結果型.省略可
        End Select
    End Function
#End Region

#Region "データ読込（ExpandItem）"
    Private Function ReadData_ExpandItem(ByVal settingInfo As System.Collections.IDictionary, ByVal jokenParam As ExpandItemParam) As DataTable
        Dim dataReader As DataAccessor = New DataAccessor()
        dataReader.Initialize(Me)
        Dim assemblyName As String = "OSK.X1.OTS.LIB.FieldBuilder.DA"
        Dim dataAccess As IDataReader = DataAccessFactory(Of IDataReader).CreateInstance(Me, assemblyName, "DataReader")
        dataReader.SetupDataReader(dataAccess)
        Dim method As DataAccessor.ReadData_DetailMethod = New DataAccessor.ReadData_DetailMethod(AddressOf dataReader.ReadData_ExpandItem)
        Dim exDA As Exception = Nothing
        Dim resultData As DataTable = Nothing
        Dim asyncResult As IAsyncResult = method.BeginInvoke(settingInfo, jokenParam, exDA, Nothing, Nothing)
        WaitAccessorProcess(dataReader)
        resultData = method.EndInvoke(exDA, asyncResult)
        If exDA IsNot Nothing Then
            ThrowWithInnerException(exDA)
        End If
        Return resultData
    End Function
#End Region

    Private Sub cancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cancel.Click
        Select Case CInt(ParamInfo.Item("処理モード"))
            Case 処理モード.参照
                ParamInfo.Item("確定区分") = False
        End Select
        Me.Close()
    End Sub

    Private Sub execute_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles execute.Click
        Select Case CInt(ParamInfo.Item("処理モード"))
            Case 処理モード.入力
                ParamInfo.Item("確定区分") = True
                Dim getData As New DataTable
                '戻り値のDataTableのカラムを作成(未使用分も含める)
                If CType(ParamInfo.Item("サブ画面データ"), DataTable) Is Nothing OrElse CType(ParamInfo.Item("サブ画面データ"), DataTable).Rows.Count <= 0 Then
                    For i As Integer = 1 To EXPANTITEMCOUNT
                        getData.Columns.Add(New DataColumn(_列名マップ("K" & i.ToString("D3")), GetType(String)))
                    Next
                Else
                    getData = CType(ParamInfo.Item("サブ画面データ"), DataTable).Clone
                End If
                Dim row As DataRow = getData.NewRow
                '行を追加する前に各カラムの値を初期化(未使用のFieldBuilderに対応するため)
                For Each col As DataColumn In getData.Columns
                    row(col.ColumnName) = ""
                Next

                For Each FieldBuilder As ExpandItemParam.FieldBuilder定義型 In _FieldBuilder
                    Dim colName As String = FieldBuilder.DB列名
                    Dim ctrl As Control = Me.FieldBuilderPanel.Controls(CType(FieldBuilder.control, Control).Name)
                    Dim valueObj As Object = Nothing
                    Select Case FieldBuilder.属性
                        Case ExpandItemParam.属性型.数値
                            Dim c As InputNumericalWithItemName = CType(ctrl, InputNumericalWithItemName)
                            valueObj = c.Value
                        Case ExpandItemParam.属性型.日付
                            Dim c As InputDateWithItemName = CType(ctrl, InputDateWithItemName)
                            valueObj = c.DateValue
                        Case ExpandItemParam.属性型.日付_年月
                            Dim c As InputDateWithItemName = CType(ctrl, InputDateWithItemName)
                            Dim y As Integer = c.InputDateControl.Year
                            Dim m As Integer = c.InputDateControl.Month
                            valueObj = (y * 100) + m
                        Case ExpandItemParam.属性型.日付_年度
                            Dim c As InputDateWithItemName = CType(ctrl, InputDateWithItemName)
                            valueObj = c.InputDateControl.Year
                        Case ExpandItemParam.属性型.参照定義コード
                            Dim c As InputTextWithItemNameAndInputName = CType(ctrl, InputTextWithItemNameAndInputName)
                            valueObj = c.InputTextControl.Text
                        Case Else
                            Dim c As InputTextWithItemName = CType(ctrl, InputTextWithItemName)
                            valueObj = c.TextValue
                    End Select
                    If (valueObj IsNot Nothing) AndAlso (valueObj.ToString() <> "") Then
                        row(colName) = CStr(valueObj)
                    Else
                        row(colName) = ""
                    End If
                Next
                getData.Rows.Add(row)
                ParamInfo.Item("サブ画面データ") = getData
                Me.Close()
        End Select
    End Sub

#Region "ボタン使用クリック"
    Private Sub OnReferButtonClick(ByVal sender As Object, ByVal e As EventArgs)
        Dim btn As SimpleControl.CommandButton = CType(sender, SimpleControl.CommandButton)
        Select Case btn.Text
            Case "参照"
                SetDialog(btn)
            Case "開く "
                SetApp(btn)
        End Select
    End Sub

    Private Sub SetDialog(ByVal btn As SimpleControl.CommandButton)
        Dim targetControl As Control = Nothing
        Dim attr As ExpandItemParam.属性型
        MakeBtnInfo(btn, targetControl, attr)
        OpenDialog(targetControl, attr)
        If _focusSwitcher IsNot Nothing Then
            Dim nextCtrl As Control = _focusSwitcher.GetNextControl(btn)
            If (nextCtrl IsNot Nothing) AndAlso nextCtrl.CanFocus Then
                nextCtrl.Focus()
            End If
        End If
    End Sub

    Private Sub OpenDialog(ByVal targetControl As Control, ByVal attr As ExpandItemParam.属性型)
        Dim selectedPath As String = String.Empty
        Dim currentText As String = TryCast(targetControl, InputTextWithItemName).TextValue.Trim()
        Select Case attr
            Case ExpandItemParam.属性型.画像
                Using dlg As OpenFileDialog = New OpenFileDialog()
                    dlg.InitialDirectory = currentText
                    dlg.Title = "画像ファイルを選択してください"
                    dlg.Filter = "画像(*.bmp,*.jpg,*.jpeg)|*.bmp;*.jpg;*.jpeg"
                    If dlg.ShowDialog() = DialogResult.OK Then
                        selectedPath = dlg.FileName
                    End If
                End Using
            Case ExpandItemParam.属性型.実行ファイル
                Using dlg As OpenFileDialog = New OpenFileDialog()
                    dlg.InitialDirectory = currentText
                    dlg.Title = "実行ファイルを選択してください"
                    dlg.Filter = "実行ファイル|*.exe|すべてのファイル|*.*"
                    If dlg.ShowDialog() = DialogResult.OK Then
                        selectedPath = dlg.FileName
                    End If
                End Using
            Case ExpandItemParam.属性型.ファイル
                Using dlg As OpenFileDialog = New OpenFileDialog()
                    dlg.InitialDirectory = currentText
                    dlg.Title = "ファイルを選択してください"
                    dlg.Filter = "すべてのファイル|*.*"
                    If dlg.ShowDialog() = DialogResult.OK Then
                        selectedPath = dlg.FileName
                    End If
                End Using
            Case ExpandItemParam.属性型.フォルダ
                Using dlg As FolderBrowserDialog = New FolderBrowserDialog()
                    dlg.SelectedPath = currentText
                    dlg.Description = "フォルダを選択してください"
                    If dlg.ShowDialog() = DialogResult.OK Then
                        selectedPath = dlg.SelectedPath
                    End If
                End Using
        End Select
        If Not String.IsNullOrEmpty(selectedPath) Then
            Dim t As InputTextWithItemName = TryCast(targetControl, InputTextWithItemName)
            If t IsNot Nothing Then
                t.TextValue = selectedPath
            End If
        End If
    End Sub

    Private Sub SetApp(ByVal btn As SimpleControl.CommandButton)
        Dim targetControl As Control = Nothing
        Dim attr As ExpandItemParam.属性型
        MakeBtnInfo(btn, targetControl, attr)
        OpenApp(targetControl, attr)
    End Sub

    Private Sub OpenApp(ByVal targetControl As Control, ByVal attr As ExpandItemParam.属性型)
        Dim 入力値 As String = CType(targetControl, InputTextWithItemName).TextValue.Trim()
        Dim errflg As Boolean = True
        Try
            Select Case attr
                Case ExpandItemParam.属性型.画像
                    If 入力値 = "" Then
                        OSK.X1.Foundation.UserInterface.OSKMessageBox.Show(Me, "画像ファイルが指定されていません。", "FieldBuilder", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        errflg = False
                        Exit Select
                    End If
                    If Not Check画像ファイル拡張子(入力値) Then
                        OSK.X1.Foundation.UserInterface.OSKMessageBox.Show(Me, "指定できる画像ファイルの形式はBMP、JPG、JPEGです。", "FieldBuilder", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        errflg = False
                        Exit Select
                    End If
                    System.Diagnostics.Process.Start(入力値)

                Case ExpandItemParam.属性型.実行ファイル
                    If 入力値 = "" Then
                        OSK.X1.Foundation.UserInterface.OSKMessageBox.Show(Me, "実行ファイルが指定されていません。", "FieldBuilder", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        errflg = False
                        Exit Select
                    End If
                    Try
                        Shell(入力値, AppWinStyle.NormalFocus)
                    Catch ex As Exception
                        OSK.X1.Foundation.UserInterface.OSKMessageBox.Show(Me, "指定されたファイルを実行できません。", "FieldBuilder", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        errflg = False
                        Exit Select
                    End Try

                Case ExpandItemParam.属性型.ファイル
                    If 入力値 = "" Then
                        OSK.X1.Foundation.UserInterface.OSKMessageBox.Show(Me, "ファイルが指定されていません。", "FieldBuilder", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        errflg = False
                        Exit Select
                    End If
                    System.Diagnostics.Process.Start(入力値)

                Case ExpandItemParam.属性型.フォルダ
                    Dim フォルダパス As String = 入力値
                    If フォルダパス = "" Then
                        OSK.X1.Foundation.UserInterface.OSKMessageBox.Show(Me, "フォルダが指定されていません。", "FieldBuilder", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        errflg = False
                        Exit Select
                    ElseIf Not System.IO.Directory.Exists(フォルダパス) Then
                        OSK.X1.Foundation.UserInterface.OSKMessageBox.Show(Me, "指定されたフォルダは存在しません。", "FieldBuilder", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        errflg = False
                        Exit Select
                    End If
                    System.Diagnostics.Process.Start(フォルダパス)

                Case ExpandItemParam.属性型.URL
                    If 入力値 = "" Then
                        OSK.X1.Foundation.UserInterface.OSKMessageBox.Show(Me, "URLが指定されていません。", "FieldBuilder", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        errflg = False
                        Exit Select
                    End If
                    Dim url As String = 入力値
                    If url.Length > 0 AndAlso Not url.ToLowerInvariant().StartsWith("http") Then
                        url = "http://" & url
                    End If
                    System.Diagnostics.Process.Start(url)

                Case ExpandItemParam.属性型.メールアドレス
                    If 入力値 = "" Then
                        OSK.X1.Foundation.UserInterface.OSKMessageBox.Show(Me, "メールアドレスが指定されていません。", "FieldBuilder", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        errflg = False
                        Exit Select
                    End If
                    System.Diagnostics.Process.Start("mailto:" & 入力値)
            End Select
        Catch ex As Exception
            OSK.X1.Foundation.UserInterface.OSKMessageBox.Show(Me, ex.Message, "FieldBuilder", MessageBoxButtons.OK, MessageBoxIcon.Information)
            errflg = False
        Finally
            If Not errflg Then
                CType(targetControl, InputTextWithItemName).InputTextControl.Focus()
            End If
        End Try
    End Sub

    Private Sub MakeBtnInfo(ByVal btn As SimpleControl.CommandButton, ByRef targetControl As Control, ByRef attr As ExpandItemParam.属性型)
        Dim info As ButtonInfo = Nothing
        If Not _btnInfoMap.TryGetValue(btn, info) Then
            Exit Sub
        End If
        Dim target As Control = info.Target
        If target Is Nothing Then
            Exit Sub
        End If
        targetControl = target
        attr = info.Attr
    End Sub

    Private Function Check画像ファイル拡張子(ByVal 入力ファイル名 As String) As Boolean
        Dim ext As String = System.IO.Path.GetExtension(入力ファイル名).ToUpperInvariant()
        Return (ext = ".BMP" OrElse ext = ".JPG" OrElse ext = ".JPEG")
    End Function
#End Region

#Region "マスター取得（参照定義コードの名称解決）"
    Private Function TryResolveDispNameOnLeave(ByVal args As CheckMethodArgs) As Boolean
        Dim fromCtrl As Control = args.移動元コントロール
        If fromCtrl Is Nothing Then
            Return True
        End If
        For Each FieldBuilder As ExpandItemParam.FieldBuilder定義型 In _FieldBuilder
            If FieldBuilder.検索種別 <> ExpandItemParam.検索種別型._1件指定 Then
                Continue For
            End If
            If FieldBuilder.属性 <> ExpandItemParam.属性型.参照定義コード Then
                Continue For
            End If
            Dim comp As InputTextWithItemNameAndInputName = TryCast(Me.FieldBuilderPanel.Controls(CType(FieldBuilder.control, Control).Name), InputTextWithItemNameAndInputName)
            If comp Is Nothing Then
                Continue For
            End If
            If Not String.Equals(comp.InputTextControl.Name, fromCtrl.Name, StringComparison.Ordinal) Then
                Continue For
            End If
            Dim code As String = comp.InputTextControl.Text
            If code Is Nothing Then
                code = String.Empty
            End If
            code = code.Trim()
            If code.Length = 0 Then
                comp.DispNameControl.Text = String.Empty
                Return True
            End If
            If Not DisplayItem(FieldBuilder, code) Then
                comp.DispNameControl.Text = String.Empty
                MessageViewer.Show(41)
                comp.InputTextControl.Focus()
                comp.InputTextControl.SelectAll()
                Return False
            End If
            Exit For
        Next
        Return True
    End Function

    Private Function DisplayItem(ByVal FieldBuilder As ExpandItemParam.FieldBuilder定義型,
                                 ByVal code As String) As Boolean
        Dim sqlTemplateRaw As String = FieldBuilder.マスター取得項目.取得データ
        Dim sqlTemplate As String
        If sqlTemplateRaw Is Nothing Then
            sqlTemplate = String.Empty
        Else
            sqlTemplate = sqlTemplateRaw
        End If
        If String.IsNullOrWhiteSpace(sqlTemplate) Then
            Return False
        End If

        Dim param As ExpandItemParam = BuildExecParamFromSql_FieldBuilder(sqlTemplate, code, FieldBuilder)
        Dim dt As DataTable = ReadData_ExpandItem(Me.SettingInfo, param)
        If (dt Is Nothing) OrElse (dt.Rows.Count = 0) Then
            Return False
        End If

        'データが取得でき、反映先が存在する場合、表示を行う。
        If FieldBuilder.マスター取得項目.反映先.TrimEnd <> "" Then
            Dim list反映先 As List(Of String) = Get変数一覧(FieldBuilder.マスター取得項目.反映先.TrimEnd, 抽出対象型.反映先対象)

            For i As Integer = 0 To list反映先.Count - 1
                Dim 反映先項目 As ExpandItemParam.FieldBuilder定義型 = GetFieldBuilder_項目変数(list反映先(i).TrimEnd)
                If TypeOf 反映先項目.control Is SimpleControl.CommandButton Then
                    Continue For
                End If

                Dim valueText As String
                If dt.Rows(0).IsNull(i) Then
                    valueText = ""
                Else
                    valueText = CStr(dt.Rows(0)(i)).Trim()
                End If

                Select Case 反映先項目.属性
                    Case ExpandItemParam.属性型.数値
                        Dim ctrl As InputNumericalWithItemName = TryCast(Me.FieldBuilderPanel.Controls(CType(反映先項目.control, Control).Name), InputNumericalWithItemName)
                        Dim decVal As Decimal = 0D
                        Decimal.TryParse(valueText, decVal)
                        ctrl.Value = decVal

                    Case ExpandItemParam.属性型.日付, ExpandItemParam.属性型.日付_年月, ExpandItemParam.属性型.日付_年度
                        Dim ctrl As InputDateWithItemName = TryCast(Me.FieldBuilderPanel.Controls(CType(反映先項目.control, Control).Name), InputDateWithItemName)
                        Dim intVal As Integer = 0
                        Integer.TryParse(valueText, intVal)
                        ctrl.DateValue = intVal

                    Case ExpandItemParam.属性型.参照定義コード
                        Dim ctrl As InputTextWithItemNameAndInputName = TryCast(Me.FieldBuilderPanel.Controls(CType(反映先項目.control, Control).Name), InputTextWithItemNameAndInputName)
                        ctrl.DispNameControl.Text = valueText

                    Case Else
                        Dim ctrl As InputTextWithItemName = TryCast(Me.FieldBuilderPanel.Controls(CType(反映先項目.control, Control).Name), InputTextWithItemName)
                        ctrl.TextValue = valueText
                End Select
            Next
        End If
        Return True
    End Function

    Private Function BuildExecParamFromSql_FieldBuilder(ByVal sqlTemplate As String,
                                                   ByVal code As String,
                                                   ByVal FieldBuilder As ExpandItemParam.FieldBuilder定義型) As ExpandItemParam
        Dim workSqlRaw As String = sqlTemplate
        Dim workSql As String
        If workSqlRaw Is Nothing Then
            workSql = String.Empty
        Else
            workSql = workSqlRaw
        End If
        Dim execSql As String = String.Empty
        Dim param As ExpandItemParam = New ExpandItemParam()
        Dim count As Integer = 1
        GetKensakuJoken任意項目(CType(param, ExpandItemParam))

        Do
            Dim nextIndex As Integer = workSql.IndexOf("@"c)
            If nextIndex = -1 Then
                execSql &= workSql.TrimEnd()
                Exit Do
            End If
            Dim target() As Char = workSql.ToCharArray()
            Dim 変数名 As String = String.Empty
            For i As Integer = nextIndex To target.Length - 1
                Dim ch As Char = target(i)
                If Char.IsWhiteSpace(ch) Then
                    Exit For
                End If
                変数名 &= CStr(ch)
            Next
            execSql &= Mid(workSql, 1, nextIndex)
            execSql &= "@" & count.ToString()

            Dim 値 As Object = Nothing
            If (Not String.IsNullOrEmpty(FieldBuilder.項目変数)) AndAlso String.Equals(変数名, FieldBuilder.項目変数, StringComparison.OrdinalIgnoreCase) Then
                値 = code
            ElseIf String.Equals(変数名, "@SYSDATE", StringComparison.OrdinalIgnoreCase) OrElse String.Equals(変数名, "@USERID", StringComparison.OrdinalIgnoreCase) Then
                値 = ReservedWordConv(変数名)
            Else
                値 = String.Empty
            End If

            Dim FieldBuilder検索 As ExpandItemParam.検索条件 = New ExpandItemParam.検索条件()
            FieldBuilder検索.initialize()
            FieldBuilder検索.FieldBuilder = 値
            If FieldBuilder.属性 = ExpandItemParam.属性型.参照定義コード Then
                FieldBuilder検索.属性 = ExpandItemParam.属性型.半角文字
            ElseIf TypeOf 値 Is Decimal OrElse IsNumeric(値) Then
                FieldBuilder検索.属性 = ExpandItemParam.属性型.数値
            Else
                FieldBuilder検索.属性 = ExpandItemParam.属性型.半角文字
            End If
            If 値 IsNot Nothing Then
                FieldBuilder検索.桁数 = CStr(値).Length
            Else
                FieldBuilder検索.桁数 = 0
            End If
            FieldBuilder検索.小数 = 0
            FieldBuilder検索.置換文字列 = New List(Of String)() From {String.Empty}
            param.FieldBuilder.Add(FieldBuilder検索)

            workSql = Mid(workSql, nextIndex + 1 + 変数名.Length)
            count += 1
        Loop
        CType(param, ExpandItemParam).取得用SQL = execSql
        Return param
    End Function

    Private Function GetFieldBuilder_項目変数(ByVal kmkName As String) As ExpandItemParam.FieldBuilder定義型
        Dim FieldBuilder As New ExpandItemParam.FieldBuilder定義型
        For Each FieldBuilder In _FieldBuilder
            If FieldBuilder.項目変数 = kmkName Then
                Exit For
            End If
        Next
        Return FieldBuilder
    End Function

    Private Function GetFieldBuilder_DB列目(ByVal kmkName As String) As ExpandItemParam.FieldBuilder定義型
        Dim FieldBuilder As New ExpandItemParam.FieldBuilder定義型
        For Each FieldBuilder In _FieldBuilder
            If FieldBuilder.DB列名 = _列名マップ(kmkName) Then
                Exit For
            End If
        Next
        Return FieldBuilder
    End Function
#End Region

#Region "計算式判定"
    Private Function TryCalculateAnalysis(ByVal args As CheckMethodArgs) As Boolean
        Dim fromCtrl As Control = args.移動元コントロール
        If fromCtrl Is Nothing Then Return True

        ' 対象FieldBuilderを検索
        Dim 対象FieldBuilder As ExpandItemParam.FieldBuilder定義型 ' 値型
        Dim found As Boolean = False
        For Each FieldBuilder As ExpandItemParam.FieldBuilder定義型 In _FieldBuilder
            Dim ctrlCur As Control = CType(FieldBuilder.control, Control)
            If ctrlCur IsNot Nothing AndAlso ctrlCur.Name = fromCtrl.Name Then
                対象FieldBuilder = FieldBuilder
                If 対象FieldBuilder.計算式 <> 1 Then Return True
                If CType(対象FieldBuilder.計算式項目, Object) Is Nothing Then Return True

                Dim 取得データ As String = SafeString(対象FieldBuilder.計算式項目.取得データ)
                Dim 反映先 As String = SafeString(対象FieldBuilder.計算式項目.反映先).Trim()
                If 取得データ = "" OrElse 反映先 = "" Then Return True

                Dim decDigit As Integer = 0
                Integer.TryParse(SafeString(対象FieldBuilder.小数), decDigit)

                '@変数の抽出と置換
                Dim txtList As List(Of String) = New List(Of String)()
                txtList = Get変数一覧(取得データ, 抽出対象型.計算対象)

                ' 長いトークンを優先して置換（@K1 と @K10 の衝突回避）
                txtList.Sort(Function(a As String, b As String) b.Length.CompareTo(a.Length))

                For Each 変数名 As String In txtList
                    Dim 置換文字列 As String = Nothing

                    If String.Equals(変数名, "@SYSDATE", StringComparison.OrdinalIgnoreCase) Then
                        置換文字列 = Me._systdate.ToString()

                    ElseIf String.Equals(変数名, "@USERID", StringComparison.OrdinalIgnoreCase) Then
                        置換文字列 = """" & Me._UserID.Replace("""", """""") & """"

                    Else
                        Dim 参照FieldBuilder As ExpandItemParam.FieldBuilder定義型 = GetFieldBuilder_項目変数(変数名)
                        Dim ctrl As Control = CType(参照FieldBuilder.control, Control)

                        If ctrl IsNot Nothing Then
                            Select Case 参照FieldBuilder.属性
                                Case ExpandItemParam.属性型.数値
                                    Dim 数値値 As Decimal = CType(ctrl, InputNumericalWithItemName).Value
                                    置換文字列 = 数値値.ToString()

                                Case Else
                                    Dim 文字列値 As String = CType(ctrl, InputTextWithItemName).TextValue
                                    置換文字列 = """" & 文字列値.Replace("""", """""") & """"
                            End Select
                        End If
                    End If

                    If 置換文字列 IsNot Nothing Then
                        取得データ = 取得データ.Replace(変数名, 置換文字列)
                    End If
                Next


                ' 計算実行
                Dim errMsg As String = ""
                Dim resultType As ICalculateAnalysis.ResultType
                Dim resultNumeric As Decimal = 0D
                Dim resultstring As String = ""
                Dim 計算結果 As ICalculateAnalysis.ErrorType =
                _計算式解析.GetKeisan(取得データ, decDigit, errMsg, resultType, resultNumeric, resultstring)

                ' エラー表示（移動継続）
                If 計算結果 = ICalculateAnalysis.ErrorType.計算成功 Then
                    ' 結果反映
                    Dim 反映先FieldBuilder As ExpandItemParam.FieldBuilder定義型 = GetFieldBuilder_項目変数(反映先)
                    Dim ctrlDest As Control = CType(反映先FieldBuilder.control, Control)
                    If 反映先FieldBuilder.属性 = ExpandItemParam.属性型.数値 Then
                        Dim numCtrl As InputNumericalWithItemName = CType(ctrlDest, InputNumericalWithItemName)
                        If resultType = ICalculateAnalysis.ResultType.数値 Then
                            numCtrl.Value = resultNumeric
                        Else
                            Dim d As Decimal = 0D
                            Decimal.TryParse(resultstring, d)
                            numCtrl.Value = d
                        End If
                    Else
                        Dim txtCtrl As InputTextWithItemName = CType(ctrlDest, InputTextWithItemName)
                        txtCtrl.TextValue = If(resultType = ICalculateAnalysis.ResultType.数値, resultNumeric.ToString(), resultstring)
                    End If
                    Return True
                Else
                    OSK.X1.Foundation.UserInterface.OSKMessageBox.Show(Me, errMsg, システム環境情報.プログラム情報.名称,
                        MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Return False
                End If
            End If
        Next
        Return True
    End Function

    Private Function TokenEvaluator(ByVal m As System.Text.RegularExpressions.Match) As String
        Dim v As String = m.Value

        ' 予約語
        If String.Equals(v, "@SYSDATE", StringComparison.OrdinalIgnoreCase) Then
            Dim ymd As Integer = _systdate
            Return ymd.ToString()
        ElseIf String.Equals(v, "@USERID", StringComparison.OrdinalIgnoreCase) Then
            Dim uid As String = _UserID
            Return """" & uid.Replace("""", """""") & """"
        End If

        ' 項目変数 → 現在値
        Dim ei As ExpandItemParam.FieldBuilder定義型 = GetFieldBuilder_項目変数(v)
        Dim ctrl As Control = CType(ei.control, Control)
        If ctrl Is Nothing Then
            Return v
        End If

        Select Case ei.属性
            Case ExpandItemParam.属性型.数値
                Dim numCtrl As InputNumericalWithItemName = CType(ctrl, InputNumericalWithItemName)
                Dim valNum As Decimal = numCtrl.Value
                Return valNum.ToString()

            Case Else
                ' 文字列はダブルクォートで囲む（内部の " はエスケープ）
                Dim txtCtrl As InputTextWithItemName = TryCast(ctrl, InputTextWithItemName)
                Dim s As String = If(txtCtrl IsNot Nothing, txtCtrl.TextValue, String.Empty)
                Return """" & s.Replace("""", """""") & """"
        End Select
    End Function

    Private Function SafeString(ByVal s As Object) As String
        If s Is Nothing Then
            Return ""
        Else
            Return CStr(s)
        End If
    End Function

    Private Sub ApplyInputValue()
        Dim FieldBuilder定義 As ExpandItemParam.FieldBuilder定義型
        Dim ctrl As Control
        Dim 反映先List As HashSet(Of String) = New HashSet(Of String)(StringComparer.Ordinal)

        For Each FieldBuilder定義 In Me._FieldBuilder
            If FieldBuilder定義.計算式 <> 1 OrElse CType(FieldBuilder定義.計算式項目, Object) Is Nothing Then
                Continue For
            End If
            Dim 反映先定義 As String = SafeString(FieldBuilder定義.計算式項目.反映先)
            If String.IsNullOrWhiteSpace(反映先定義) Then
                Continue For
            End If
            反映先List.UnionWith(Get変数一覧(反映先定義, 抽出対象型.反映先対象))
        Next

        For Each FieldBuilder定義 In _FieldBuilder
            ctrl = Me.FieldBuilderPanel.Controls(CType(FieldBuilder定義.control, Control).Name)
            If ctrl Is Nothing Then
                Continue For
            End If

            Dim 入力可否値 As Integer = CInt(FieldBuilder定義.入力可否)

            Dim 項目変数 As String = SafeString(FieldBuilder定義.項目変数)
            Dim 反映先項目変数 As Boolean = (項目変数.Length > 0 AndAlso 反映先List.Contains(項目変数))

            Dim 入力可能 As Boolean
            If 入力可否値 = 1 Then
                入力可能 = True
            ElseIf 入力可否値 = 0 AndAlso 反映先項目変数 Then
                入力可能 = False
            Else
                入力可能 = True
            End If

            If (_strategyMap IsNot Nothing) AndAlso _strategyMap.ContainsKey(FieldBuilder定義.属性) Then
                _strategyMap(FieldBuilder定義.属性).SetReadOnly(ctrl, Not 入力可能)
            End If

            If TypeOf ctrl Is InputTextWithItemName Then
                Dim c As InputTextWithItemName = CType(ctrl, InputTextWithItemName)
                c.InputTextControl.TabStop = 入力可能
            ElseIf TypeOf ctrl Is InputNumericalWithItemName Then
                Dim c As InputNumericalWithItemName = CType(ctrl, InputNumericalWithItemName)
                c.InputNumericalControl.TabStop = 入力可能
            ElseIf TypeOf ctrl Is InputDateWithItemName Then
                Dim c As InputDateWithItemName = CType(ctrl, InputDateWithItemName)
                c.InputDateControl.TabStop = 入力可能
            End If
        Next
    End Sub

    Private Function Get変数一覧(ByVal 対象文字列 As String, ByVal 抽出対象 As 抽出対象型) As List(Of String)
        Dim txtList As List(Of String) = New List(Of String)()
        Dim 位置 As Integer = 0
        Dim count As Integer
        If 対象文字列 Is Nothing Then
            count = 0
        Else
            count = 対象文字列.Length
        End If

        While 位置 < count
            Dim txt As Char = 対象文字列.Chars(位置)
            If txt = "@"c Then
                Dim 開始位置 As Integer = 位置
                位置 += 1
                Select Case 抽出対象
                    Case 抽出対象型.計算対象
                        While 位置 < count AndAlso (Char.IsLetterOrDigit(対象文字列.Chars(位置)) OrElse 対象文字列.Chars(位置) = "_"c)
                            位置 += 1
                        End While
                    Case 抽出対象型.反映先対象
                        While 位置 < count AndAlso 対象文字列.Chars(位置) <> ","c
                            位置 += 1
                        End While
                End Select
                Dim 変数名 As String = 対象文字列.Substring(開始位置, 位置 - 開始位置).Trim()
                If (変数名.Length > 1) AndAlso (Not txtList.Contains(変数名)) Then
                    txtList.Add(変数名)
                End If
            Else
                位置 += 1
            End If
            If (抽出対象 = 抽出対象型.反映先対象) AndAlso (位置 < count) AndAlso (対象文字列.Chars(位置) = ","c) Then
                位置 += 1
            End If
        End While
        Return txtList
    End Function
#End Region

#Region "ボタン生成,デフォルト退避"
    Private Function CreateActionButton(ByVal text As String,
                                        ByVal target As Control,
                                        ByVal attr As ExpandItemParam.属性型) As SimpleControl.CommandButton
        Dim btn As SimpleControl.CommandButton = New SimpleControl.CommandButton()
        btn.Text = text
        btn.Width = ItemWidth.GetWidth(btn, btn.Text)
        AddHandler btn.Click, AddressOf OnReferButtonClick
        RegisterButtonInfo(btn, target, attr)
        Return btn
    End Function

    Private Function CreateActionButton(ByVal text As String,
                                        ByVal target As Control,
                                        ByVal attr As ExpandItemParam.属性型,
                                        ByVal extraWidth As Integer) As SimpleControl.CommandButton
        Dim btn As SimpleControl.CommandButton = New SimpleControl.CommandButton()
        btn.Text = text
        Dim baseWidth As Integer = ItemWidth.GetWidth(btn, btn.Text)
        btn.Width = baseWidth + extraWidth
        AddHandler btn.Click, AddressOf OnReferButtonClick
        RegisterButtonInfo(btn, target, attr)
        Return btn
    End Function

    Private Sub RegisterButtonInfo(ByVal btn As SimpleControl.CommandButton,
                                   ByVal target As Control,
                                   ByVal attr As ExpandItemParam.属性型)
        If _btnInfoMap Is Nothing Then
            _btnInfoMap = New Dictionary(Of SimpleControl.CommandButton, ButtonInfo)()
        End If
        _btnInfoMap(btn) = New ButtonInfo(target, attr)
    End Sub

    Private Function TryGetButtonInfo(ByVal btn As SimpleControl.CommandButton,
                                      ByRef info As ButtonInfo) As Boolean
        If _btnInfoMap Is Nothing Then
            Return False
        End If
        Return _btnInfoMap.TryGetValue(btn, info)
    End Function

    Private Sub RememberDefaults(ByVal tabIndex As Integer,
                                 ByVal FieldBuilder As ExpandItemParam.FieldBuilder定義型)
        Dim defaults() As String
        ReDim defaults(FieldBuilder.デフォルト値.Count - 1)
        For i As Integer = 0 To FieldBuilder.デフォルト値.Count - 1
            FieldBuilder.デフォルト値(i) = ReservedWordConv(FieldBuilder.デフォルト値(i))
            defaults(i) = FieldBuilder.デフォルト値(i)
        Next
        _defaultValues.Add(tabIndex - 1, defaults)
        _FieldBuilder.Add(FieldBuilder)
    End Sub
#End Region
End Class