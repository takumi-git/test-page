﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class SubForm
    Inherits OSK.X1.Foundation.UIDesign.UserInterface.DesignFormBase

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim FunctionControlList1 As OSK.X1.Foundation.SmartControl.FunctionBar.FunctionControlList = New OSK.X1.Foundation.SmartControl.FunctionBar.FunctionControlList()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(SubForm))
        Me.BottomToolStripPanel = New System.Windows.Forms.ToolStripPanel()
        Me.TopToolStripPanel = New System.Windows.Forms.ToolStripPanel()
        Me.RightToolStripPanel = New System.Windows.Forms.ToolStripPanel()
        Me.LeftToolStripPanel = New System.Windows.Forms.ToolStripPanel()
        Me.KensakuPanel = New System.Windows.Forms.ToolStripContentPanel()
        Me.KensakuContainer = New System.Windows.Forms.ToolStripContainer()
        Me.statusBar = New OSK.X1.Foundation.SmartControl.StatusBar.StatusBar(Me.components)
        Me.cancel = New OSK.X1.Foundation.SimpleControl.CommandButton()
        Me.execute = New OSK.X1.Foundation.SimpleControl.CommandButton()
        Me.functionBar = New OSK.X1.Foundation.SmartControl.FunctionBar.FunctionBar()
        Me.FieldBuilderPanel = New OSK.X1.Foundation.SimpleControl.Panel(Me.components)
        Me.MenuBar = New OSK.X1.Foundation.SmartControl.MenuBar.MenuBar(Me.components)
        Me.endMenu = New System.Windows.Forms.ToolStripMenuItem()
        Me.KensakuContainer.BottomToolStripPanel.SuspendLayout()
        Me.KensakuContainer.ContentPanel.SuspendLayout()
        Me.KensakuContainer.SuspendLayout()
        Me.MenuBar.SuspendLayout()
        Me.SuspendLayout()
        '
        'BottomToolStripPanel
        '
        Me.BottomToolStripPanel.Location = New System.Drawing.Point(0, 0)
        Me.BottomToolStripPanel.Name = "BottomToolStripPanel"
        Me.BottomToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal
        Me.BottomToolStripPanel.RowMargin = New System.Windows.Forms.Padding(3, 0, 0, 0)
        Me.BottomToolStripPanel.Size = New System.Drawing.Size(0, 0)
        '
        'TopToolStripPanel
        '
        Me.TopToolStripPanel.Location = New System.Drawing.Point(0, 0)
        Me.TopToolStripPanel.Name = "TopToolStripPanel"
        Me.TopToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal
        Me.TopToolStripPanel.RowMargin = New System.Windows.Forms.Padding(3, 0, 0, 0)
        Me.TopToolStripPanel.Size = New System.Drawing.Size(0, 0)
        '
        'RightToolStripPanel
        '
        Me.RightToolStripPanel.Location = New System.Drawing.Point(0, 0)
        Me.RightToolStripPanel.Name = "RightToolStripPanel"
        Me.RightToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal
        Me.RightToolStripPanel.RowMargin = New System.Windows.Forms.Padding(3, 0, 0, 0)
        Me.RightToolStripPanel.Size = New System.Drawing.Size(0, 0)
        '
        'LeftToolStripPanel
        '
        Me.LeftToolStripPanel.Location = New System.Drawing.Point(0, 0)
        Me.LeftToolStripPanel.Name = "LeftToolStripPanel"
        Me.LeftToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal
        Me.LeftToolStripPanel.RowMargin = New System.Windows.Forms.Padding(3, 0, 0, 0)
        Me.LeftToolStripPanel.Size = New System.Drawing.Size(0, 0)
        '
        'KensakuPanel
        '
        Me.KensakuPanel.Size = New System.Drawing.Size(781, 518)
        '
        'KensakuContainer
        '
        '
        'KensakuContainer.BottomToolStripPanel
        '
        Me.KensakuContainer.BottomToolStripPanel.Controls.Add(Me.statusBar)
        '
        'KensakuContainer.ContentPanel
        '
        Me.KensakuContainer.ContentPanel.BackColor = System.Drawing.Color.Transparent
        Me.KensakuContainer.ContentPanel.Controls.Add(Me.cancel)
        Me.KensakuContainer.ContentPanel.Controls.Add(Me.execute)
        Me.KensakuContainer.ContentPanel.Controls.Add(Me.functionBar)
        Me.KensakuContainer.ContentPanel.Controls.Add(Me.FieldBuilderPanel)
        Me.KensakuContainer.ContentPanel.Size = New System.Drawing.Size(902, 564)
        Me.KensakuContainer.Dock = System.Windows.Forms.DockStyle.Fill
        Me.KensakuContainer.LeftToolStripPanelVisible = False
        Me.KensakuContainer.Location = New System.Drawing.Point(0, 24)
        Me.KensakuContainer.Name = "KensakuContainer"
        Me.KensakuContainer.RightToolStripPanelVisible = False
        Me.KensakuContainer.Size = New System.Drawing.Size(902, 586)
        Me.KensakuContainer.TabIndex = 0
        Me.KensakuContainer.TabStop = False
        Me.KensakuContainer.Text = "conditionContainer"
        Me.KensakuContainer.TopToolStripPanelVisible = False
        '
        'statusBar
        '
        Me.statusBar.AutoGuideMessageClearFlag = False
        Me.statusBar.Dock = System.Windows.Forms.DockStyle.None
        Me.statusBar.Location = New System.Drawing.Point(0, 0)
        Me.statusBar.MarqueeAnimationSpeed = 100
        Me.statusBar.Name = "statusBar"
        Me.statusBar.ProgressStep = 10
        Me.statusBar.ProgressStyle = System.Windows.Forms.ProgressBarStyle.Blocks
        Me.statusBar.Size = New System.Drawing.Size(902, 22)
        Me.statusBar.SizingGrip = False
        Me.statusBar.StatusContainer = Nothing
        Me.statusBar.TabIndex = 2
        Me.statusBar.Tag = "@Exception@"
        '
        'cancel
        '
        Me.cancel.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cancel.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.cancel.FocusBackColor = System.Drawing.Color.Empty
        Me.cancel.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.cancel.Image = Nothing
        Me.cancel.Location = New System.Drawing.Point(814, 505)
        Me.cancel.Name = "cancel"
        Me.cancel.NextByDownKey = False
        Me.cancel.NextByEnterKey = False
        Me.cancel.NextByTabKey = False
        Me.cancel.RemarkString = Nothing
        Me.cancel.Size = New System.Drawing.Size(80, 24)
        Me.cancel.TabIndex = 9005
        Me.cancel.Text = "キャンセル"
        Me.cancel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'execute
        '
        Me.execute.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.execute.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.execute.FocusBackColor = System.Drawing.Color.Empty
        Me.execute.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.execute.Image = Nothing
        Me.execute.Location = New System.Drawing.Point(729, 505)
        Me.execute.Name = "execute"
        Me.execute.NextByEnterKey = False
        Me.execute.RemarkString = Nothing
        Me.execute.Size = New System.Drawing.Size(80, 24)
        Me.execute.TabIndex = 9004
        Me.execute.Text = "実行"
        Me.execute.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'functionBar
        '
        Me.functionBar.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.functionBar.F1でヘルプ = OSK.X1.Foundation.SmartControl.FunctionBar.FunctionBar.ヘルプタイプ.実行する
        Me.functionBar.ForeColor = System.Drawing.SystemColors.ControlText
        Me.functionBar.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden
        Me.functionBar.GroupNo = 0
        FunctionControlList1.個別指定ファンクションキー = OSK.X1.Foundation.SmartControl.FunctionBar.FunctionControl.KeyType.F7
        FunctionControlList1.個別指定表示状態 = False
        Me.functionBar.Items = FunctionControlList1
        Me.functionBar.Location = New System.Drawing.Point(0, 539)
        Me.functionBar.Name = "functionBar"
        Me.functionBar.ShowItemToolTips = False
        Me.functionBar.Size = New System.Drawing.Size(902, 25)
        Me.functionBar.Stretch = True
        Me.functionBar.SubGroupNo = 0
        Me.functionBar.TabIndex = 16
        Me.functionBar.Tag = ""
        Me.functionBar.個別指定ファンクションキー = OSK.X1.Foundation.SmartControl.FunctionBar.FunctionControl.KeyType.F7
        '
        'FieldBuilderPanel
        '
        Me.FieldBuilderPanel.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.FieldBuilderPanel.BorderStyle = OSK.X1.Foundation.Controls.Panel.BorderStyleType.None
        Me.FieldBuilderPanel.Font = New System.Drawing.Font("MS UI Gothic", 10.5!)
        Me.FieldBuilderPanel.Location = New System.Drawing.Point(12, 27)
        Me.FieldBuilderPanel.Name = "FieldBuilderPanel"
        Me.FieldBuilderPanel.Size = New System.Drawing.Size(878, 472)
        Me.FieldBuilderPanel.TabIndex = 7
        Me.FieldBuilderPanel.TitleVisible = True
        '
        'MenuBar
        '
        Me.MenuBar.CanOverflow = True
        Me.MenuBar.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.endMenu})
        Me.MenuBar.Location = New System.Drawing.Point(0, 0)
        Me.MenuBar.MenuContainer = Nothing
        Me.MenuBar.Name = "MenuBar"
        Me.MenuBar.Padding = New System.Windows.Forms.Padding(0, 1, 0, 2)
        Me.MenuBar.Size = New System.Drawing.Size(902, 24)
        Me.MenuBar.TabIndex = 1
        Me.MenuBar.Text = "MenuBar1"
        '
        'endMenu
        '
        Me.endMenu.Name = "endMenu"
        Me.endMenu.Overflow = System.Windows.Forms.ToolStripItemOverflow.AsNeeded
        Me.endMenu.Size = New System.Drawing.Size(58, 21)
        Me.endMenu.Text = "終了(&X)"
        '
        'SubForm
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.AutoScroll = True
        Me.AutoSize = True
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(902, 610)
        Me.Controls.Add(Me.KensakuContainer)
        Me.Controls.Add(Me.MenuBar)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.KeyPreview = True
        Me.MainMenuStrip = Me.MenuBar
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "SubForm"
        Me.Text = "ExpandItemForm"
        Me.KensakuContainer.BottomToolStripPanel.ResumeLayout(False)
        Me.KensakuContainer.BottomToolStripPanel.PerformLayout()
        Me.KensakuContainer.ContentPanel.ResumeLayout(False)
        Me.KensakuContainer.ContentPanel.PerformLayout()
        Me.KensakuContainer.ResumeLayout(False)
        Me.KensakuContainer.PerformLayout()
        Me.MenuBar.ResumeLayout(False)
        Me.MenuBar.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents KensakuContainer As System.Windows.Forms.ToolStripContainer
    Friend WithEvents BottomToolStripPanel As System.Windows.Forms.ToolStripPanel
    Friend WithEvents TopToolStripPanel As System.Windows.Forms.ToolStripPanel
    Friend WithEvents RightToolStripPanel As System.Windows.Forms.ToolStripPanel
    Friend WithEvents LeftToolStripPanel As System.Windows.Forms.ToolStripPanel
    Friend WithEvents KensakuPanel As System.Windows.Forms.ToolStripContentPanel
    Protected WithEvents statusBar As OSK.X1.Foundation.SmartControl.StatusBar.StatusBar
    Protected WithEvents functionBar As OSK.X1.Foundation.SmartControl.FunctionBar.FunctionBar
    Friend WithEvents MenuBar As MenuBar.MenuBar
    Friend WithEvents endMenu As ToolStripMenuItem
    Friend WithEvents FieldBuilderPanel As SimpleControl.Panel
    Friend WithEvents execute As SimpleControl.CommandButton
    Friend WithEvents cancel As SimpleControl.CommandButton
End Class
