﻿Public Class ItemWidth

    ''' <summary>
    ''' 項目幅のWidth取得
    ''' </summary>
    ''' <param name="controll">対象コントロール</param>
    ''' <param name="target">項目</param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Shared Function GetWidth(ByVal controll As OSK.X1.Foundation.SmartControl.ISmartControl, ByVal target As String) As Integer
        Dim widthCalculator As New OSK.X1.Foundation.Utility.UserInterface.WidthCalculator
        Dim newSize As Size
        newSize = widthCalculator.GetSize(CType(controll, System.Windows.Forms.Control), target, 10, 0)

        Return newSize.Width
    End Function

End Class
