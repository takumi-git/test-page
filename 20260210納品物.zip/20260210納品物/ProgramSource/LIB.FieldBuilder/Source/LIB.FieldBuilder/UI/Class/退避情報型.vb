﻿Public Class 退避情報型
    Inherits InsideJobBase

#Region "列挙"

    Friend Enum 明細項目型
        状態
        変更区分
        行
    End Enum

    Friend Enum グループ型 As Integer
        No１ = 1
        No２
        No３
        No４
        No５
        No６
    End Enum

    Friend Enum サブグループ型 As Integer
        No１ = 1
        No２
        No３
    End Enum

    Friend Enum 状態
        正常
        エラー
    End Enum

#End Region

#Region "内部変数"

#End Region

#Region "コンストラクタ"

    Public Sub New()

        _操作日付 = CInt(Now.ToString("yyyyMMdd"))

        _明細部 = New DataTable

        ReDim _グループ状態(0 To 6)

    End Sub

#End Region

#Region "プロパティ"

    Private _グループ状態() As 状態
    Friend Property グループ状態(ByVal groupNo As グループ型) As 状態
        Get
            Return _グループ状態(groupNo)
        End Get
        Set(ByVal value As 状態)
            _グループ状態(groupNo) = value
        End Set
    End Property

#Region "日付情報"

    Private _操作日付 As Integer
    Friend ReadOnly Property 操作日付() As Integer
        Get
            Return _操作日付
        End Get
    End Property

#End Region

#Region "初期値"

#End Region

#Region "手入力値"

#End Region

#Region "入力値関連"

    Private _明細部 As DataTable
    Friend Property 明細部() As DataTable
        Get
            Return _明細部
        End Get
        Set(ByVal value As DataTable)
            _明細部 = value.Copy
        End Set
    End Property
    Friend Property 明細部項目(ByVal rowIndex As Integer, ByVal columnName As String) As Object
        Get
            Return trimEnd(_明細部.Rows(rowIndex).Item(columnName))
        End Get
        Set(ByVal value As Object)
            If _明細部.Columns(columnName).DataType Is GetType(DataTable) Then
                _明細部.Rows(rowIndex).Item(columnName) = CType(value, DataTable).Copy
            Else
                _明細部.Rows(rowIndex).Item(columnName) = value
            End If
        End Set
    End Property
    Friend Property 明細部項目(ByVal rowIndex As Integer, ByVal columnName As 退避情報型.明細項目型) As Object
        Get
            Return 明細部項目(rowIndex, columnName.ToString)
        End Get
        Set(ByVal value As Object)
            明細部項目(rowIndex, columnName.ToString) = value
        End Set
    End Property

#End Region

#Region "コントロールテーブル情報関連"

#End Region

#Region "マスター情報関連"

#End Region

#Region "伝票関連"


#End Region

#End Region

#Region "公開メソッド"

    ''' <summary>
    ''' 対象DataTableより１行抜き出し、退避DataTableの位置0行に格納する
    ''' </summary>
    ''' <param name="row"></param>
    ''' <param name="dataTable"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Friend Function GetPullOutRows(ByVal row As Integer, ByVal dataTable As DataTable) As DataTable

        Dim dt As DataTable = dataTable.Clone
        dt.Clear()
        dt.Rows.Add(dt.NewRow)
        dt.Rows(0).ItemArray = dataTable.Rows(row).ItemArray
        Return dt.Copy

    End Function

    ''' <summary>
    ''' 取得データを指定された退避用テーブルに移送する
    ''' </summary>
    ''' <param name="getData">取得DataTable</param>
    ''' <param name="saveData">退避DataTable</param>
    ''' <remarks>一括移送</remarks>
    Friend Overloads Sub SaveDataValue(ByVal getData As DataTable, ByRef saveData As DataTable)

        SetDataTableProperty(getData)

        saveData.Clear()
        saveData = getData.Copy

    End Sub

    ''' <summary>
    ''' 取得データを指定された退避用テーブルに移送する
    ''' </summary>
    ''' <param name="getData">取得DataTable</param>
    ''' <param name="saveData">退避DataTable（※複数指定可）</param>
    ''' <remarks>個別移送（指定文字を元に行列毎に抜き出し、指定した退避DataTableへ移送）</remarks>
    Friend Overloads Sub SaveDataValue(ByVal getData As DataTable, ByRef saveData As IDictionary(Of String, DataTable))

        SetDataTableProperty(getData)

        For Each key As String In saveData.Keys
            saveData(key).Clear()
            For row As Integer = 0 To getData.Rows.Count - 1
                CreateAddRow(CType(saveData(key), DataTable))
                For col As Integer = 0 To getData.Columns.Count - 1
                    If Strings.InStr(getData.Columns.Item(col).ColumnName, key) > 0 Then
                        Dim colName As String = RemoveAliasName(getData.Columns(col).ColumnName)
                        saveData(key).Rows(row).Item(colName) = getData.Rows(row).Item(col)
                    End If
                Next
            Next
        Next

    End Sub

    Friend Sub SaveDataColumnValue(ByVal getData As DataTable, ByVal key As String, ByRef saveData As DataTable)

        For row As Integer = 0 To getData.Rows.Count - 1
            For col As Integer = 0 To getData.Columns.Count - 1
                If Strings.InStr(getData.Columns.Item(col).ColumnName, key) > 0 Then
                    Dim colName As String = RemoveAliasName(getData.Columns(col).ColumnName)
                    saveData.Rows(row).Item(colName) = getData.Rows(row).Item(col)
                End If
            Next
        Next

    End Sub

    ''' <summary>
    ''' 不要なDataTable属性列を除去する
    ''' </summary>
    ''' <param name="targetDataTable"></param>
    ''' <remarks></remarks>
    Friend Sub RemoveJunkColumns(ByRef targetDataTable As DataTable)

        Dim dt As DataTable = targetDataTable.Copy

        With dt

            For colIndex As Integer = 0 To .Columns.Count - 1
                'DataTable属性列以外は対象外
                If .Columns(colIndex).DataType IsNot GetType(DataTable) Then
                    Continue For
                End If

                'DataTable属性列に設定されているDataTableがカラか判定
                Dim junkColName As String = .Columns(colIndex).ColumnName
                For rowIndex As Integer = 0 To .Rows.Count - 1
                    If CType(.Rows(rowIndex).Item(colIndex), DataTable).Rows.Count <> 0 Then
                        junkColName = ""
                        Exit For
                    End If
                Next

                '不要列をtargetDataTableから除去
                If junkColName <> "" Then
                    targetDataTable.Columns.Remove(junkColName)
                End If
            Next

        End With

    End Sub



#End Region

#Region "内部メソッド"

    Friend Sub CreateAddRow(ByRef targetDataTable As DataTable)
        SetAddDefaultValue(targetDataTable)
        targetDataTable.Rows.Add(targetDataTable.NewRow)
    End Sub

    ''' <summary>
    ''' DBより取得した項目名より別名を除く
    ''' </summary>
    ''' <param name="targetName"></param>
    ''' <returns></returns>
    ''' <remarks>最初に見つかった"_"より前を別名のとする。その文字以降を返す</remarks>
    Private Function RemoveAliasName(ByVal targetName As String) As String

        Dim startIndex As Integer = Strings.InStr(targetName, "_")
        Dim count As Integer = targetName.Length - startIndex

        Return targetName.Substring(startIndex, count)

    End Function

    ''' <summary>
    ''' データテーブルプロパティ設定
    ''' </summary>
    ''' <param name="targetDataTable"></param>
    ''' <remarks></remarks>
    Private Sub SetDataTableProperty(ByRef targetDataTable As DataTable)

        For i As Integer = 0 To targetDataTable.Columns.Count - 1
            targetDataTable.Columns.Item(i).AllowDBNull = True      'Null値の許可
            targetDataTable.Columns.Item(i).ReadOnly = False        '読込専用の解除
        Next

    End Sub

    Private Sub SetDefaultValue(ByRef targetDataTable As DataTable)

        For index As Integer = 0 To targetDataTable.Columns.Count - 1
            If targetDataTable.Columns(index).DataType Is GetType(String) Then
                targetDataTable.Rows(0).Item(index) = ""
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Integer) Then
                targetDataTable.Rows(0).Item(index) = 0
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Long) Then
                targetDataTable.Rows(0).Item(index) = 0
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Decimal) Then
                targetDataTable.Rows(0).Item(index) = 0
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Boolean) Then
                targetDataTable.Rows(0).Item(index) = False
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Date) Then
                targetDataTable.Rows(0).Item(index) = 0
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Object) Then
                targetDataTable.Rows(0).Item(index) = Nothing
            End If
            If targetDataTable.Columns(index).DataType Is GetType(DataTable) Then
                targetDataTable.Rows(0).Item(index) = New DataTable
            End If
            If targetDataTable.Columns(index).DataType Is GetType(IDictionary) Then
                targetDataTable.Rows(0).Item(index) = Nothing
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Short) Then
                targetDataTable.Rows(0).Item(index) = 0
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Single) Then
                targetDataTable.Rows(0).Item(index) = 0
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Double) Then
                targetDataTable.Rows(0).Item(index) = 0
            End If
        Next

    End Sub

    Private Sub SetAddDefaultValue(ByRef targetDataTable As DataTable)

        For index As Integer = 0 To targetDataTable.Columns.Count - 1

            If targetDataTable.Columns(index).DataType Is GetType(String) Then
                targetDataTable.Columns(index).DefaultValue = ""
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Integer) Then
                targetDataTable.Columns(index).DefaultValue = 0
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Long) Then
                targetDataTable.Columns(index).DefaultValue = 0
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Decimal) Then
                targetDataTable.Columns(index).DefaultValue = 0
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Boolean) Then
                targetDataTable.Columns(index).DefaultValue = False
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Date) Then
                targetDataTable.Columns(index).DefaultValue = 0
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Object) Then
                targetDataTable.Columns(index).DefaultValue = Nothing
            End If
            If targetDataTable.Columns(index).DataType Is GetType(DataTable) Then
                targetDataTable.Columns(index).DefaultValue = New DataTable
            End If
            If targetDataTable.Columns(index).DataType Is GetType(IDictionary) Then
                targetDataTable.Columns(index).DefaultValue = Nothing
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Short) Then
                targetDataTable.Columns(index).DefaultValue = 0
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Single) Then
                targetDataTable.Columns(index).DefaultValue = 0
            End If
            If targetDataTable.Columns(index).DataType Is GetType(Double) Then
                targetDataTable.Columns(index).DefaultValue = 0
            End If
        Next

    End Sub

    ''' <summary>
    ''' 後ろの空白をカット
    ''' </summary>
    ''' <param name="value"></param>
    ''' <returns></returns>
    ''' <remarks>Stringタイプのみ対象。以外はそのまま返す</remarks>
    Private Function trimEnd(ByVal value As Object) As Object

        If value.GetType Is GetType(String) Then
            Return CStr(value).TrimEnd
        End If

        Return value

    End Function

#End Region

End Class
