﻿Public Class DataAccessor
    Inherits InsideJobBase

    Private _dataReader As IDataReader

#Region "プロパティ"

    Private _endFlag As Boolean
    Public ReadOnly Property EndFlag() As Boolean
        Get
            Return _endFlag
        End Get
    End Property

#End Region

#Region "メソッド"

    ''' <summary>
    ''' データアクセスのインスタンスを設定する
    ''' </summary>
    ''' <typeparam name="T"></typeparam>
    ''' <param name="dataAccessor">データアクセス</param>
    ''' <remarks></remarks>
    Friend Sub SetupDataReader(Of T)(ByVal dataAccessor As T)
        _dataReader = CType(dataAccessor, IDataReader)
        _endFlag = False
    End Sub

#End Region

#Region "データの取得"

#Region "メソッド"

    ''' <summary>
    ''' データを取得する
    ''' </summary>
    ''' <param name="settingInfo">システム共通設定情報</param>
    ''' <param name="jokenParam">パラメータ</param>
    ''' <param name="exDA"></param>
    ''' <returns>取得データ</returns>
    ''' <remarks></remarks>
    Friend Delegate Function ReadData_DetailMethod(ByVal settingInfo As System.Collections.IDictionary, ByVal jokenParam As ExpandItemParam, ByRef exDA As Exception) As DataTable

    Friend Function ReadData_ExpandItem(ByVal settingInfo As System.Collections.IDictionary, ByVal jokenParam As ExpandItemParam, ByRef exDA As Exception) As DataTable
        Try
            Dim dataTable As DataTable = _dataReader.ReadData_ExpandItem(settingInfo, jokenParam)
            Return dataTable
        Catch ex As Exception
            exDA = ex
            Return Nothing
        Finally
            _endFlag = True
        End Try
    End Function

#End Region

#End Region

End Class
