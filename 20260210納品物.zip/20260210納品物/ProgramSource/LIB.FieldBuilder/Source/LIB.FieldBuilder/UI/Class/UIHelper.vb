﻿Imports System
Imports System.Collections.Generic

' ▼属性ごとの振る舞いを戦略クラスに分離
Public Interface IUIHelper
    Function CreateControl(ByVal FieldBuilder As ExpandItemParam.FieldBuilder定義型) As Control
    Sub SetDefault(ByVal ctrl As Control, ByVal defaults As List(Of String))
    Sub SetReadOnly(ByVal ctrl As Control, ByVal isReadOnly As Boolean)
    Function GetValue(ByVal ctrl As Control) As Object
End Interface

' 文字入力（全角/半角/URL/メール/ファイル/フォルダ/画像/実行ファイル）共通
Public Class TextStrategy
    Implements IUIHelper
    Private Const MAXDISPLENGTH As Integer = 64
    Public Function CreateControl(ByVal FieldBuilder As ExpandItemParam.FieldBuilder定義型) As Control _
        Implements IUIHelper.CreateControl

        Dim control As InputTextWithItemName = New InputTextWithItemName()

        Dim dispLength As Integer = CInt(FieldBuilder.桁数)
        control.ItemName = FieldBuilder.タイトル
        If dispLength > MAXDISPLENGTH Then
            control.MaxLength = MAXDISPLENGTH
            control.AutoResizeInputControl = False
            control.InputTextControl.DispTextToolTip = True
            control.InputTextControl.DispTextToolTipMode = OSK.X1.Foundation.Controls.Common.DispToolTipModeType.OverflowOnly
        Else
            control.AutoResizeInputControl = True
        End If
        control.MaxLength = dispLength
        control.MaxLengthMode = Foundation.Controls.InputText.MaxLengthModeType.CustomLength


        Select Case FieldBuilder.属性
            Case ExpandItemParam.属性型.全角文字
                ' IME：ひらがな ＋ 全角のみ許可
                control.InputType = InputTextWithItemName.InputTypeList.全文字入力可
                control.InputTextControl.ImeMode = control.InputTextImeMode.Hiragana
            Case ExpandItemParam.属性型.半角文字
                ' IME：無効（オフ） ＋ 半角のみ許可
                control.InputType = InputTextWithItemName.InputTypeList.半角文字のみ
                control.InputTextControl.ImeMode = control.InputTextImeMode.NoControl
            Case ExpandItemParam.属性型.URL,
             ExpandItemParam.属性型.メールアドレス,
             ExpandItemParam.属性型.ファイル,
             ExpandItemParam.属性型.フォルダ,
             ExpandItemParam.属性型.画像,
             ExpandItemParam.属性型.実行ファイル
                ' IME：無効（オフ）／フィルタなし（全文字可）
                control.InputTextControl.ImeMode = control.InputTextImeMode.NoControl
                control.InputType = InputTextWithItemName.InputTypeList.全文字入力可
        End Select


        Return control
    End Function

    Public Sub SetDefault(ByVal ctrl As Control, ByVal defaults As List(Of String)) _
        Implements IUIHelper.SetDefault
        Dim control As InputTextWithItemName = CType(ctrl, InputTextWithItemName)
        control.TextValue = defaults(0)
    End Sub

    Public Sub SetReadOnly(ByVal ctrl As Control, ByVal isReadOnly As Boolean) _
        Implements IUIHelper.SetReadOnly
        If CType(ctrl, InputTextWithItemName).AutoResizeInputControl = False Then
            CType(ctrl, InputTextWithItemName).InputControlReadOnly = isReadOnly
            CType(ctrl, InputTextWithItemName).InputTextControl.CanFocusByUser = Not isReadOnly
            CType(ctrl, InputTextWithItemName).InputTextControl.DisplayOnly = isReadOnly
        Else
            CType(ctrl, InputTextWithItemName).InputControlReadOnly = isReadOnly
        End If
    End Sub

    Public Function GetValue(ByVal ctrl As Control) As Object _
        Implements IUIHelper.GetValue
        Return CType(ctrl, InputTextWithItemName).TextValue
    End Function
End Class
' 数値戦略
Public Class NumericStrategy
    Implements IUIHelper

    Public Function CreateControl(ByVal FieldBuilder As ExpandItemParam.FieldBuilder定義型) As Control _
        Implements IUIHelper.CreateControl

        Dim control As InputNumericalWithItemName = New InputNumericalWithItemName()

        control.ItemName = FieldBuilder.タイトル
        control.整数桁数 = CInt(FieldBuilder.桁数)
        control.小数桁数 = CInt(FieldBuilder.小数)
        control.カンマ表示 = (FieldBuilder.カンマ = 1)
        Return control
    End Function

    Public Sub SetDefault(ByVal ctrl As Control, ByVal defaults As List(Of String)) _
        Implements IUIHelper.SetDefault
        CType(ctrl, InputNumericalWithItemName).Value = CDec(defaults(0))
    End Sub

    Public Sub SetReadOnly(ByVal ctrl As Control, ByVal isReadOnly As Boolean) _
        Implements IUIHelper.SetReadOnly
        CType(ctrl, InputNumericalWithItemName).InputControlReadOnly = isReadOnly
    End Sub

    Public Function GetValue(ByVal ctrl As Control) As Object _
        Implements IUIHelper.GetValue
        Return CType(ctrl, InputNumericalWithItemName).Value
    End Function
End Class

' 日付戦略（通常／年月／年度をコンストラクタ引数で切り替え）
Public Class DateStrategy
    Implements IUIHelper

    Private ReadOnly _format As InputDate.DisplayFormatType
    Private ReadOnly _ym As Boolean
    Private ReadOnly _yearOnly As Boolean

    Public Sub New(ByVal format As InputDate.DisplayFormatType,
                   ByVal ym As Boolean,
                   ByVal yearOnly As Boolean)
        _format = format
        _ym = ym
        _yearOnly = yearOnly
    End Sub

    Public Function CreateControl(ByVal FieldBuilder As ExpandItemParam.FieldBuilder定義型) As Control _
        Implements IUIHelper.CreateControl

        Dim control As InputDateWithItemName = New InputDateWithItemName()

        control.ItemName = FieldBuilder.タイトル
        control.区切り文字 = CType(FieldBuilder.区切り文字, InputDateWithItemName.SeparatorType)
        control.DispSpinButton = True
        control.InputDateControl.DisplayFormat = _format
        If _ym Then
            control.日付形式 = InputDateWithItemName.DateFormatType.年月
            control.InputDateControl.HiddenDay = 1
        End If
        If _yearOnly Then
            control.日付形式 = InputDateWithItemName.DateFormatType.年
            control.InputDateControl.HiddenDay = 1
            control.InputDateControl.HiddenMonth = 1
        End If
        Return control
    End Function

    Public Sub SetDefault(ByVal ctrl As Control, ByVal defaults As List(Of String)) _
        Implements IUIHelper.SetDefault
        Dim datevlue As Integer = CInt(defaults(0))
        Dim inputDate As InputDateWithItemName = CType(ctrl, InputDateWithItemName)
        If _ym Then
            Dim year As Integer = datevlue \ 100
            Dim month As Integer = datevlue Mod 100
            inputDate.InputDateControl.Year = year
            inputDate.InputDateControl.Month = month
            inputDate.DateValue = (year * 10000) + (month * 100) + 1
        ElseIf _yearOnly Then
            Dim year As Integer = datevlue
            inputDate.InputDateControl.Year = year
            inputDate.DateValue = (year * 10000) + 101
        Else
            inputDate.DateValue = datevlue
        End If

    End Sub

    Public Sub SetReadOnly(ByVal ctrl As Control, ByVal isReadOnly As Boolean) _
        Implements IUIHelper.SetReadOnly
        CType(ctrl, InputDateWithItemName).InputControlReadOnly = isReadOnly
    End Sub

    Public Function GetValue(ByVal ctrl As Control) As Object _
        Implements IUIHelper.GetValue
        Return CType(ctrl, InputDateWithItemName).DateValue
    End Function
End Class

' 参照定義コード（名称表示付き）戦略
Public Class RefCodeStrategy
    Implements IUIHelper

    Public Function CreateControl(ByVal FieldBuilder As ExpandItemParam.FieldBuilder定義型) As Control _
        Implements IUIHelper.CreateControl
        Dim Utility As New OSK.X1.Foundation.Utility.UserInterface.WidthCalculator
        Dim maxDispLength As Integer = 32
        Dim dispLength As Integer = CInt(FieldBuilder.桁数)
        Dim control As InputTextWithItemNameAndInputName = New InputTextWithItemNameAndInputName()

        control.ItemName = FieldBuilder.タイトル
        If dispLength > maxDispLength Then
            control.MaxLength = maxDispLength
            control.AutoResizeInputControl = False
            control.InputTextControl.DispTextToolTip = True
            control.InputTextControl.DispTextToolTipMode = OSK.X1.Foundation.Controls.Common.DispToolTipModeType.OverflowOnly
        Else
            control.AutoResizeInputControl = True
        End If
        control.MaxLength = dispLength
        control.MaxLengthMode = Foundation.Controls.InputText.MaxLengthModeType.CustomLength
        If FieldBuilder.タイプ = 1 Then
            control.InputType = InputTextWithItemNameAndInputName.InputModeType.全文字入力可
            If FieldBuilder.大文字変換 = 1 Then
                control.InputType = InputTextWithItemNameAndInputName.InputModeType.ログインID入力モード
            End If
            control.ZeroFill = False
        Else
            control.InputType = InputTextWithItemNameAndInputName.InputModeType.数値のみ
            control.ZeroFill = True
        End If

        control.DispNameAreaWidth = Utility.GetSize(control.DispNameControl, 48).Width 'TODO　名称の幅取得方法


        Return control
    End Function

    Public Sub SetDefault(ByVal ctrl As Control, ByVal defaults As List(Of String)) _
        Implements IUIHelper.SetDefault
        Dim control As InputTextWithItemNameAndInputName = CType(ctrl, InputTextWithItemNameAndInputName)
        control.InputTextControl.Text = defaults(0)
        control.DispNameControl.Text = String.Empty
    End Sub

    Public Sub SetReadOnly(ByVal ctrl As Control, ByVal isReadOnly As Boolean) _
        Implements IUIHelper.SetReadOnly
        CType(ctrl, InputTextWithItemNameAndInputName).InputControlReadOnly = isReadOnly


        CType(ctrl, InputTextWithItemNameAndInputName).Enabled = True

        CType(ctrl, InputTextWithItemNameAndInputName).TabStop = Not isReadOnly
        Try
            CType(ctrl, InputTextWithItemNameAndInputName).InputTextControl.TabStop = Not isReadOnly
        Catch
        End Try

    End Sub

    Public Function GetValue(ByVal ctrl As Control) As Object _
        Implements IUIHelper.GetValue
        Return CType(ctrl, InputTextWithItemNameAndInputName).InputTextControl.Text
    End Function
End Class

' ▼戦略ファクトリ（SubForm から呼び出す）
Public NotInheritable Class AttrStrategyFactory
    Private Sub New()
    End Sub

    Public Shared Function BuildStrategyMap(ByVal displayFormat As OSK.X1.Foundation.Controls.InputDate.DisplayFormatType) _
        As Dictionary(Of ExpandItemParam.属性型, IUIHelper)

        Dim map As Dictionary(Of ExpandItemParam.属性型, IUIHelper) =
            New Dictionary(Of ExpandItemParam.属性型, IUIHelper)()

        ' 文字系（同一戦略へ集約）
        map(ExpandItemParam.属性型.全角文字) = New TextStrategy()
        map(ExpandItemParam.属性型.半角文字) = New TextStrategy()
        map(ExpandItemParam.属性型.URL) = New TextStrategy()
        map(ExpandItemParam.属性型.メールアドレス) = New TextStrategy()
        map(ExpandItemParam.属性型.ファイル) = New TextStrategy()
        map(ExpandItemParam.属性型.フォルダ) = New TextStrategy()
        map(ExpandItemParam.属性型.画像) = New TextStrategy()
        map(ExpandItemParam.属性型.実行ファイル) = New TextStrategy()

        ' 数値
        map(ExpandItemParam.属性型.数値) = New NumericStrategy()

        ' 日付
        map(ExpandItemParam.属性型.日付) = New DateStrategy(displayFormat, ym:=False, yearOnly:=False)
        map(ExpandItemParam.属性型.日付_年月) = New DateStrategy(displayFormat, ym:=True, yearOnly:=False)
        map(ExpandItemParam.属性型.日付_年度) = New DateStrategy(displayFormat, ym:=False, yearOnly:=True)

        ' 参照定義コード
        map(ExpandItemParam.属性型.参照定義コード) = New RefCodeStrategy()

        Return map
    End Function
End Class