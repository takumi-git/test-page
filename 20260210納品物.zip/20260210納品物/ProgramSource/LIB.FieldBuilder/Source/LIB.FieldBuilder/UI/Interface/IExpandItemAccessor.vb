﻿Public Interface IExpandItemAccessor


    ''' <summary>
    ''' FieldBuilder項目の未入力/必須/警告の判定結果を返す
    ''' </summary>
    ''' <param name="expandItem">FieldBuilder項目の一覧</param>
    ''' <returns>判定結果</returns>
    Function Validate(ByVal expandItem As ExpandItemParam.FieldBuilder定義型) _
        As PanelExpandItemAccessor.ValidationResult


End Interface
