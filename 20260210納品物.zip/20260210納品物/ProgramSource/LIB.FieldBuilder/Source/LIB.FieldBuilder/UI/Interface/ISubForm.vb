﻿Public Interface ISubForm
    Inherits IInsideJob

    ''' <summary>
    ''' エントリー画面の開始処理
    ''' </summary>
    ''' <remarks></remarks>
    Sub SetUpForm(ByRef paramInfo As IDictionary)

    ''' <summary>
    ''' パラメータ情報
    ''' </summary>
    ''' <value></value>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Property ParamInfo() As System.Collections.IDictionary

End Interface
