﻿Public Class Initializer
    Inherits InitializerBase

    Public Overrides Function Startup(ByVal connection As System.Data.Common.DbConnection, ByRef initInfo As System.Collections.IDictionary, ByRef resultMessage As String, ByRef checkInfo As Foundation.ExecuteCheck.IExecuteCheckInfo) As Foundation.Startup.IStarter.AccessResultType

        Dim accessResultType As Startup.IStarter.AccessResultType = IStarter.AccessResultType.成功

        ''販売コントロールテーブル情報取得
        'Dim controlReader As HAN.LIB.ControlInfo.DataAccess.IHANControlReader
        'controlReader = CommonFactory.CreateInstance(Of HAN.LIB.ControlInfo.DataAccess.IHANControlReader)(Me, GetType(HAN.LIB.ControlInfo.DataAccess.HANControlReader))
        'controlReader.Initialize(Me)
        'controlReader.GetControlInfo(connection, initInfo, IHANControlReader.コントロール型.HANコントロールテーブル)

        ''項目名称設定テーブル情報取得
        'Dim itemNameReader As CMN.LIB.ItemNameInfo.DataAccess.IItemNameReader
        'itemNameReader = CommonFactory.CreateInstance(Of CMN.LIB.ItemNameInfo.DataAccess.IItemNameReader)(Me, GetType(CMN.LIB.ItemNameInfo.DataAccess.ItemNameReader))
        'itemNameReader.Initialize(Me)
        'itemNameReader.GetItemNameInfo(connection, initInfo)

        Return accessResultType

    End Function

End Class
