﻿''' <summary>
''' 更新用インターフェイス 
''' </summary>
''' <remarks></remarks>
Public Interface IDataUpdater
    Inherits IBase

    ''' <summary>
    ''' データ更新を行う
    ''' </summary>
    ''' <param name="settingInfo">システム共通設定情報</param>
    ''' <param name="UpdateParam">パラメータ</param>
    ''' <returns>取得データ</returns>
    ''' <remarks></remarks>
    Function DataUpdate(ByVal settingInfo As IDictionary,
                        ByVal UpdateParam As UpdateParam,
                        ByRef executeCheckInfo As IExecuteCheckInfo) As IResult

End Interface
