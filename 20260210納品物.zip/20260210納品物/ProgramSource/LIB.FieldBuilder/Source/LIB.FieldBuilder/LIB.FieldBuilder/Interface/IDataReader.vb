﻿''' <summary>
''' 読込用インターフェイス 
''' </summary>
''' <remarks></remarks>
Public Interface IDataReader
    Inherits IBase
    ''' <summary>
    ''' データの取得を行う(明細部)
    ''' </summary>
    ''' <param name="settingInfo">システム共通設定情報</param>
    ''' <param name="jokenParam">パラメータ</param>
    ''' <returns>取得データ</returns>
    ''' <remarks></remarks>
    Function ReadData_ExpandItem(ByVal settingInfo As IDictionary, ByVal jokenParam As ExpandItemParam) As DataTable

End Interface
