﻿<CLSCompliant(False)>
<Serializable()>
Public Class UpdateParam

#Region "列挙型"
    Public Enum 更新パラメータ型 As Integer
        登録プログラムID
        登録者
        登録日時
        最終更新プログラムID
        最終更新者
        最終更新日時
        更新番号
        登録プログラムID枝番
        最終更新プログラムID枝番

    End Enum

    Public Enum 属性型 As Integer
        コード型
        文字型
        数値型
    End Enum

#End Region

#Region "構造体"
    <Serializable()>
    Public Structure 更新条件
        Dim 属性 As 属性型
        Dim 列名 As String
        Dim 更新値 As Object
        Dim 桁数 As Integer
        Dim 小数 As Integer
        Dim 項目変数 As String
        Sub initialize()
            属性 = New 属性型
            列名 = ""
            桁数 = 0
            小数 = 0
            項目変数 = ""
        End Sub
    End Structure

#End Region

#Region "コンストラクタ"

    Public Sub New()

        _UpdateData = New DataTable
        条件項目 = New List(Of 更新条件)
        登録条件項目 = New List(Of 更新条件)
        削除条件項目 = New List(Of 更新条件)

    End Sub

#End Region

#Region "プロパティ"

    Private _登録用SQL As String
    Public Property 登録用SQL() As String
        Get
            Return _登録用SQL
        End Get
        Set(ByVal value As String)
            _登録用SQL = value
        End Set
    End Property

    Private _削除用SQL As String
    Public Property 削除用SQL() As String
        Get
            Return _削除用SQL
        End Get
        Set(ByVal value As String)
            _削除用SQL = value
        End Set
    End Property

#Region "データ"
    Private _UpdateData As DataTable
    Public Property UpdateData As DataTable
        Get
            Return _UpdateData
        End Get
        Set(ByVal value As DataTable)
            _UpdateData = value
        End Set
    End Property

    Private _条件項目 As List(Of 更新条件)
    Public Property 条件項目() As List(Of 更新条件)
        Get
            Return _条件項目
        End Get
        Set(ByVal value As List(Of 更新条件))
            _条件項目 = value
        End Set
    End Property

    Private _登録条件項目 As List(Of 更新条件)
    Public Property 登録条件項目() As List(Of 更新条件)
        Get
            Return _登録条件項目
        End Get
        Set(ByVal value As List(Of 更新条件))
            _登録条件項目 = value
        End Set
    End Property

    Private _削除条件項目 As List(Of 更新条件)
    Public Property 削除条件項目() As List(Of 更新条件)
        Get
            Return _削除条件項目
        End Get
        Set(ByVal value As List(Of 更新条件))
            _削除条件項目 = value
        End Set
    End Property

    Private _履歴項目更新 As Integer
    Public Property 履歴項目更新 As Integer
        Get
            Return _履歴項目更新
        End Get
        Set(ByVal value As Integer)
            _履歴項目更新 = value
        End Set
    End Property

    Private _列名 As String
    Public Property 列名 As String
        Get
            Return _列名
        End Get
        Set(ByVal value As String)
            _列名 = value
        End Set
    End Property

#End Region
#End Region

End Class
