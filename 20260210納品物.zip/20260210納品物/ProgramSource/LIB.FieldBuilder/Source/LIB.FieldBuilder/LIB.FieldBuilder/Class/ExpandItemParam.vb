﻿<CLSCompliant(False)>
<Serializable()>
Public Class ExpandItemParam

#Region "列挙型"

#Region "データ読込"
    Public Enum 検索種別型 As Integer
        _1件指定
    End Enum
    Public Enum 属性型 As Integer
        未使用 = 0
        全角文字
        半角文字
        数値
        日付
        日付_年月
        日付_年度
        参照定義コード
        画像
        実行ファイル
        ファイル
        フォルダ
        URL
        メールアドレス
    End Enum

#End Region

#End Region

#Region "構造体"
    <Serializable()>
    Public Structure 検索条件
        Dim 検索種別 As 検索種別型
        Dim 属性 As 属性型
        Dim 条件句 As String
        Dim FieldBuilder As Object
        Dim 置換文字列 As List(Of String)
        Dim 桁数 As Integer
        Dim 小数 As Integer
        Dim 桁数2 As Integer
        Dim 属性2 As 属性型
        Dim DB属性 As 属性型
        Dim DB桁数 As Integer
        Dim DB属性2 As 属性型
        Dim DB桁数2 As Integer
        Dim 名称付条件句 As String
        Sub initialize()
            検索種別 = New 検索種別型
            属性 = New 属性型
            置換文字列 = New List(Of String)
            属性2 = New 属性型
            DB属性 = New 属性型
            DB桁数 = 0
            DB属性2 = New 属性型
            DB桁数2 = 0
            名称付条件句 = ""
        End Sub
    End Structure

    <Serializable()>
    Public Structure FieldBuilder定義型
        Dim control As Object
        Dim タイトル As String
        Dim 検索種別 As ExpandItemParam.検索種別型
        Dim 属性 As ExpandItemParam.属性型
        Dim タイプ As Integer
        Dim 桁数 As Integer
        Dim 小数 As Integer
        Dim カンマ As Integer
        Dim マイナス As Integer
        Dim 入力チェック As Integer
        Dim 項目 As List(Of String)
        Dim デフォルト値 As List(Of String)
        Dim 条件句 As String
        Dim 置換文字列 As List(Of String)
        Dim 詳細条件 As Integer
        Dim DB属性 As ExpandItemParam.属性型
        Dim DB桁数 As Integer
        Dim 大文字変換 As Integer
        Dim ボタン使用 As Integer
        Dim DB列名 As String
        Dim マスター検索 As Integer
        Dim マスター検索項目 As マスター検索項目型
        Dim マスター取得 As Integer
        Dim マスター取得項目 As マスター取得項目型
        Dim 項目変数 As String
        Dim 区切り文字 As Integer
        Dim 計算式 As Integer
        Dim 計算式項目 As 計算式項目型
        Dim 入力可否 As Integer

        Sub initialize()
            control = Nothing
            タイトル = ""
            検索種別 = New ExpandItemParam.検索種別型
            属性 = New ExpandItemParam.属性型
            タイプ = 0
            桁数 = 0
            小数 = 0
            カンマ = 0
            入力チェック = 0
            マイナス = 0
            項目 = New List(Of String)
            デフォルト値 = New List(Of String)
            条件句 = ""
            置換文字列 = New List(Of String)
            詳細条件 = 0
            DB属性 = New ExpandItemParam.属性型
            DB桁数 = 0
            大文字変換 = 0
            ボタン使用 = 0
            DB列名 = ""
            マスター検索 = 0
            マスター検索項目.initialize()
            マスター取得 = 0
            マスター取得項目.initialize()
            項目変数 = ""
            区切り文字 = 0
            計算式 = 0
            計算式項目.initialize()
            入力可否 = 0
        End Sub

    End Structure

    <Serializable()>
    Public Structure マスター検索項目型
        Dim コード検索 As String
        Dim コード検索枝番 As Integer
        Dim 項目 As List(Of String)
        Dim loader As Object
        Dim 引数 As Dictionary(Of String, Object)
        Dim 戻り値 As List(Of String)
        Dim 反映先 As String
        Sub initialize()
            コード検索 = ""
            コード検索枝番 = 0
            項目 = New List(Of String)
            loader = Nothing
            引数 = New Dictionary(Of String, Object)
            戻り値 = New List(Of String)
        End Sub
    End Structure

    <Serializable()>
    Public Structure マスター取得項目型
        Dim 取得データ As String
        Dim 反映先 As String
        Sub initialize()
            取得データ = ""
            反映先 = ""
        End Sub
    End Structure

    <Serializable()>
    Public Structure 計算式項目型
        Dim 取得データ As String
        Dim 反映先 As String
        Sub initialize()
            取得データ = ""
            反映先 = ""
        End Sub
    End Structure

#End Region


#Region "コンストラクタ"

    Public Sub New()

        '検索方法 = 検索方法型.初回
        最大表示件数 = 0
        任意項目 = New Hashtable
        FieldBuilder = New List(Of 検索条件)

    End Sub

#End Region

#Region "プロパティ"

#Region "データ読込"
    Private _最大表示件数 As Long
    Public Property 最大表示件数() As Long
        Get
            Return _最大表示件数
        End Get
        Set(ByVal value As Long)
            _最大表示件数 = value
        End Set
    End Property

    Private _任意項目 As IDictionary
    Public Property 任意項目() As IDictionary
        Get
            Return _任意項目
        End Get
        Set(ByVal value As IDictionary)
            _任意項目 = value
        End Set
    End Property

#End Region

#Region "画面条件"
    Private _FieldBuilder As List(Of 検索条件)
    Public Property FieldBuilder() As List(Of 検索条件)
        Get
            Return _FieldBuilder
        End Get
        Set(ByVal value As List(Of 検索条件))
            _FieldBuilder = value
        End Set
    End Property

    Private _取得用SQL As String
    Public Property 取得用SQL() As String
        Get
            Return _取得用SQL
        End Get
        Set(ByVal value As String)
            _取得用SQL = value
        End Set
    End Property
#End Region

#End Region

End Class
