﻿Public Class StateSafeHostApp

    Public Shared Sub Main()

        Dim clientSinkProvider As New BinaryClientFormatterSinkProvider
        Dim serverSinkProvider As New BinaryServerFormatterSinkProvider

        Console.WriteLine("StateSafeHostApp RemotingHost")

        Dim props As IDictionary
        props = New Hashtable
        props.Item("port") = 8180

        Dim channel As TcpChannel
        channel = New TcpChannel(props, clientSinkProvider, serverSinkProvider)

        ChannelServices.RegisterChannel(channel, False)

        RemotingConfiguration.RegisterWellKnownServiceType(GetType(OSK.X1.StateSafe.AppDomainStateSafe.StateManagerService), _
                                                           "RemotingStateManagerService", _
                                                           WellKnownObjectMode.SingleCall)    'X1変換Tool-20160525

        Pause()

    End Sub

    Private Shared Sub Pause()
        Console.WriteLine("Pause Push Any Key !")
        Console.ReadLine()
    End Sub
End Class
