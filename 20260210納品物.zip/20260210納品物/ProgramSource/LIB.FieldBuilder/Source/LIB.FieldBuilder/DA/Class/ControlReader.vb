﻿<Serializable()>
Public Class ControlReader
    Inherits DataHandlerBase
    Implements IControlReader

    Public Sub Startup(ByRef infoXML As System.Collections.IDictionary, ByVal NmXML As String,
                       ByRef conditionList As List(Of ExpandItemParam.FieldBuilder定義型)) Implements IControlReader.Startup

        'プログラム個別情報取得
        SetPrivateInitInfo(infoXML, NmXML, conditionList)

    End Sub

    Private Sub SetPrivateInitInfo(ByRef initInfo As System.Collections.IDictionary, ByVal NmXML As String,
                                   ByRef conditionList As List(Of ExpandItemParam.FieldBuilder定義型))

        Dim xmlDoc As New XmlDocument()
        Dim 業務区分 As String = Me.システム環境情報.業務情報.ID
        Dim パターン名 As String = NmXML
        xmlDoc.Load(System.IO.Path.Combine(System.Configuration.ConfigurationManager.AppSettings("アプリケーション設定データパス"), パターン名))

        Dim routenodes As XmlNodeList = xmlDoc.GetElementsByTagName("プログラム情報")
        For Each nodes As XmlNode In routenodes
            For Each childNode As XmlNode In nodes.ChildNodes
                For Each childNode2 As XmlNode In childNode.ChildNodes
                    Dim pgName As String = CStr(childNode2.InnerText)
                    If initInfo.Contains("プログラム専用.プログラム名") Then
                        initInfo.Remove("プログラム専用.プログラム名")
                    End If
                    initInfo.Add("プログラム専用.プログラム名", pgName)
                Next
            Next
        Next

        routenodes = xmlDoc.GetElementsByTagName("パターン情報")
        Dim formwidth As Integer = 0
        Dim DisplayFormat As Integer = 0
        Dim mode As Integer = 0
        Dim Exec As Integer = 0
        Dim Preview As Integer = 0
        Dim Print As Integer = 0
        Dim MaxDispCount As Long = 0
        Dim index As Integer = 0
        For Each nodes As XmlNode In routenodes
            '<パターン情報>
            formwidth = CInt(nodes.Attributes.Item(0).Value)
            If initInfo.Contains("プログラム専用.画面横幅") Then
                initInfo.Remove("プログラム専用.画面横幅")
            End If
            initInfo.Add("プログラム専用.画面横幅", formwidth)

            For Each childNode As XmlNode In nodes.ChildNodes
                '<FieldBuilder>
                For Each childNode2 As XmlNode In childNode.ChildNodes

                    Select Case childNode2.Name
                        Case "項目"
                            setConditionList(childNode2, conditionList)
                    End Select
                    index += 1
                Next
            Next
        Next

        '項目
        If initInfo.Contains("プログラム専用.FieldBuilder") Then
            initInfo.Remove("プログラム専用.FieldBuilder")
        End If
        initInfo.Add("プログラム専用.FieldBuilder設定", conditionList)


    End Sub
    Private Sub setConditionList(ByVal node As XmlNode, ByRef conditionList As List(Of ExpandItemParam.FieldBuilder定義型))
        'XMLをシリアライズ
        Dim 条件項目 As ExpandItemParam.FieldBuilder定義型 = New ExpandItemParam.FieldBuilder定義型
        条件項目.initialize()
        With 条件項目
            .タイトル = node.Attributes("タイトル").Value
            .検索種別 = ExpandItemParam.検索種別型._1件指定  '1件指定固定

            '下記省略可能項目(nothingで判断可能）
            If node.Attributes("桁数") IsNot Nothing Then
                .桁数 = CInt(node.Attributes("桁数").Value)
            End If

            If node.Attributes("小数") IsNot Nothing Then
                .小数 = CInt(node.Attributes("小数").Value)
            End If
            If node.Attributes("属性") IsNot Nothing Then
                .属性 = CType(node.Attributes("属性").Value, ExpandItemParam.属性型)
            End If
            If node.Attributes("タイプ") IsNot Nothing Then
                .タイプ = CInt(node.Attributes("タイプ").Value)
            End If
            If node.Attributes("大文字変換") IsNot Nothing Then
                .大文字変換 = CInt(node.Attributes("大文字変換").Value)
            End If
            If node.Attributes("カンマ") IsNot Nothing Then
                .カンマ = CInt(node.Attributes("カンマ").Value)
            End If
            If node.Attributes("マイナス") IsNot Nothing Then
                .マイナス = CInt(node.Attributes("マイナス").Value)
            End If
            If node.Attributes("入力チェック") IsNot Nothing Then
                .入力チェック = CInt(node.Attributes("入力チェック").Value)
            End If
            If node.Attributes("ボタン使用") IsNot Nothing Then
                .ボタン使用 = CInt(node.Attributes("ボタン使用").Value)
            End If
            If node.Attributes("列名") IsNot Nothing Then
                .DB列名 = CStr(node.Attributes("列名").Value)
            End If
            If node.Attributes("項目変数") IsNot Nothing Then
                .項目変数 = CStr(node.Attributes("項目変数").Value)
            End If
            If node.Attributes("区切り文字") IsNot Nothing Then
                .区切り文字 = CInt(node.Attributes("区切り文字").Value)
            End If
            If node.Attributes("入力可否") IsNot Nothing Then
                .入力可否 = CInt(node.Attributes("入力可否").Value)
            End If

            If node.Attributes("マスター検索") IsNot Nothing Then
                .マスター検索 = CInt(node.Attributes("マスター検索").Value)
                For Each childNode2 As XmlNode In node.ChildNodes
                    If childNode2.Name.StartsWith("コード検索") Then
                        'マスター検索の実装
                        .マスター検索項目.コード検索 = childNode2.Attributes("ID").Value
                        .マスター検索項目.コード検索枝番 = CInt(childNode2.Attributes("枝番").Value)
                        '子要素にある引数と戻り値を取得
                        For Each childnode As XmlNode In childNode2.ChildNodes
                            If childnode.Name.StartsWith("引数") Then
                                .マスター検索項目.引数.Add(childnode.Attributes(0).Name, childnode.Attributes(0).Value)
                            End If
                            If childnode.Name.StartsWith("受取") Then
                                .マスター検索項目.戻り値.Add(childnode.Attributes(0).Value)
                            End If
                        Next
                    End If
                Next
            End If

            If node.Attributes("マスター取得") IsNot Nothing Then
                .マスター取得 = CInt(node.Attributes("マスター取得").Value)
                For Each childNode2 As XmlNode In node.ChildNodes
                    If childNode2.Name.StartsWith("マスター取得") Then
                        '子要素にある引数と戻り値を取得
                        For Each childnode As XmlNode In childNode2.ChildNodes
                            If childnode.Name.StartsWith("取得データ") Then
                                .マスター取得項目.取得データ = childnode.InnerText.Replace(vbCrLf, " ").Trim
                            End If
                            If childnode.Name.StartsWith("反映先") Then
                                .マスター取得項目.反映先 = childnode.InnerText.Replace(vbCrLf, " ").Trim
                            End If
                        Next
                    End If
                Next
            End If
            If node.Attributes("計算式") IsNot Nothing Then
                .計算式 = CInt(node.Attributes("計算式").Value)
                For Each childNode2 As XmlNode In node.ChildNodes
                    If childNode2.Name.StartsWith("計算式") Then
                        '子要素にある引数と戻り値を取得
                        For Each childnode As XmlNode In childNode2.ChildNodes
                            If childnode.Name.StartsWith("取得データ") Then
                                .計算式項目.取得データ = childnode.InnerText.Replace(vbCrLf, " ").Trim
                            End If
                            If childnode.Name.StartsWith("反映先") Then
                                .計算式項目.反映先 = childnode.InnerText.Replace(vbCrLf, " ").Trim
                            End If
                        Next
                    End If
                Next
            End If
            For I1 As Integer = 0 To node.ChildNodes.Count - 1
                If node.ChildNodes(I1).Name.StartsWith("項目") Then
                    .項目.Add(node.ChildNodes(I1).InnerText)
                    Continue For
                End If

                If node.ChildNodes(I1).Name.StartsWith("PARM") Then
                    .デフォルト値.Add(node.ChildNodes(I1).Attributes("デフォルト").Value)
                    .置換文字列.Add(node.ChildNodes(I1).InnerText)
                    Continue For
                End If
                If node.ChildNodes(I1).Name.StartsWith("条件句") Then
                    .条件句 = node.ChildNodes(I1).InnerText
                    Continue For
                End If
            Next
        End With

        conditionList.Add(条件項目)

    End Sub
End Class
