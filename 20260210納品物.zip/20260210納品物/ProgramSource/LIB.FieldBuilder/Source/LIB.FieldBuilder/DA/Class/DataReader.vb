﻿Public Class DataReader
    Inherits DataHandlerBase
    Implements IDataReader

#Region "インターフェイスメソッド"

    Private Sub InitializeControlInfo(ByVal jokenParam As ExpandItemParam)

    End Sub

#End Region

#Region "データ取得処理"

    ''' <summary>
    ''' テーブルに列を設定する
    ''' </summary>
    ''' <param name="reader">reader</param>
    ''' <param name="table">datatable</param>
    ''' <remarks></remarks>
    Private Sub SetUpTable(ByVal reader As DbDataReader, ByRef table As DataTable)

        Dim dc As DataColumn
        For i As Integer = 0 To reader.FieldCount - 1
            dc = New DataColumn(reader.GetName(i), reader(i).GetType)
            table.Columns.Add(dc)
        Next

    End Sub

    ''' <summary>
    ''' 行データを設定する
    ''' </summary>
    ''' <param name="reader"></param>
    ''' <param name="table"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Private Function MakeNewDataRow(ByVal reader As DbDataReader, ByVal table As DataTable) As DataRow

        Dim dr As DataRow
        dr = table.NewRow()
        For i As Integer = 0 To reader.FieldCount - 1
            dr(reader.GetName(i)) = reader.GetValue(i)
        Next
        Return dr

    End Function

#End Region

#Region "パラメータ"
    Private Function GetParameter(ByVal jokenindex As Integer,
                                  ByVal paramKey As ExpandItemParam,
                                  ByVal value As Object,
                                  ByRef paramInfo As ParamInfoList) As String

        Dim newParam As New OSK.X1.DataAccess.ParamInfo
        With newParam
            .Name = "Param" & CStr(paramInfo.Count)
            If paramKey.FieldBuilder(jokenindex).属性 = ExpandItemParam.属性型.数値 Then
                .Type = DbType.Decimal
                .Size = 0
                .Precision = CType(paramKey.FieldBuilder(jokenindex).桁数, Byte)
                .Scale = CType(paramKey.FieldBuilder(jokenindex).小数, Byte)
                .Value = value
            ElseIf paramKey.FieldBuilder(jokenindex).属性 = ExpandItemParam.属性型.日付 OrElse
                   paramKey.FieldBuilder(jokenindex).属性 = ExpandItemParam.属性型.日付_年月 OrElse
                   paramKey.FieldBuilder(jokenindex).属性 = ExpandItemParam.属性型.日付_年度 Then
                .Type = DbType.Decimal
                .Size = 0
                .Precision = CType(paramKey.FieldBuilder(jokenindex).桁数, Byte)
                .Scale = 0
                .Value = value
            Else
                .Type = DbType.String
                .Size = paramKey.FieldBuilder(jokenindex).桁数
                .Precision = 0
                .Scale = 0
                If paramKey.FieldBuilder(jokenindex).置換文字列(0).StartsWith("%%") And
                        paramKey.FieldBuilder(jokenindex).置換文字列(0).EndsWith("%%") Then
                    .Value = "'%" & CStr(value) & "%'"
                ElseIf paramKey.FieldBuilder(jokenindex).置換文字列(0).EndsWith("%%") Then
                    .Value = "'" & CStr(value) & "%'"
                ElseIf paramKey.FieldBuilder(jokenindex).置換文字列(0).StartsWith("%%") Then
                    .Value = "'%" & CStr(value) & "'"
                Else
                    .Value = "'" & CStr(value) & "'"
                End If

            End If
        End With

        'paramInfo.Add(newParam)

        'Return "?"
        'バインド変数を使用すると、XMLで自由に設定できる条件指定位置に
        '対応できなくなるため、SQLに直接値を埋め込む形で対応する。
        Return newParam.Value.ToString
    End Function

#End Region

#Region "データの取得"

#Region "インターフェイスメソッド"

    Private Function 任意項目変換(ByVal 任意項目 As String) As String
        '文字列の場合シングルコーテーション付与
        Dim 変換 As String = 任意項目

        '数値判定
        If IsNumeric(変換) Then
            If 変換.Length > 1 AndAlso 変換.StartsWith("0") Then
                Return "'" & 変換 & "'"
            End If
        Else
            Return "'" & 変換 & "'"
        End If

        Return 変換
    End Function

#End Region

#End Region

#Region "データの取得(FieldBuilder)"

#Region "インターフェイスメソッド"

    ''' <summary>
    ''' データの取得を行う
    ''' </summary>
    ''' <param name="settingInfo">システム共通設定情報</param>
    ''' <param name="jokenParam">パラメータ</param>
    ''' <returns>取得データ</returns>
    ''' <remarks></remarks>
    Public Function ReadData_ExpandItem(ByVal settingInfo As System.Collections.IDictionary,
                                    ByVal jokenParam As ExpandItemParam) As DataTable Implements IDataReader.ReadData_ExpandItem

        InitializeControlInfo(jokenParam)

        Initialize(settingInfo)

        SetUpDAC()

        Using connection As DbConnection = OpenConnection()

            'データの取得
            Dim table As DataTable = ReadData_拡張(connection, jokenParam)

            CloseConnection(connection)

            Return table

        End Using

    End Function

#End Region

#Region "データ取得処理"

    Private Function ReadData_拡張(ByVal connection As DbConnection,
                                   ByVal jokenParam As ExpandItemParam) As DataTable

        Dim table As New DataTable

        Dim result As Boolean

        result = ReadDataImpl_拡張(connection, jokenParam, table)

        Return table

    End Function

    Private Function ReadDataImpl_拡張(ByVal connection As DbConnection,
                                       ByVal jokenParam As ExpandItemParam,
                                       ByRef table As DataTable) As Boolean

        Dim dataTable As New DataTable
        Dim newTable As New DataTable

        Dim readLebelIndex As Integer = 1

        Dim sql As String = ""
        Dim parameter As ParamInfoList = New OSK.X1.DataAccess.ParamInfoList
        Dim hasRows As Boolean = False
        Dim command As DbCommand = Nothing
        MakeSQL_Expand(CType(jokenParam, ExpandItemParam), sql, parameter, readLebelIndex)

        Dim reader As DbDataReader = DataAccess.GetDataReader(connection, sql, parameter, hasRows, command)

        'データが存在した時
        If hasRows = True Then
            SetUpTable(reader, dataTable)
            Dim dr As DataRow = MakeNewDataRow(reader, dataTable)
            dataTable.Rows.Add(dr)
        End If

        '解放
        DataAccess.CancelCommand(command)
        DataAccess.CloseReader(reader)

        table = dataTable

        Return hasRows

    End Function

#End Region

#Region "ＳＱＬ文作成"

    Private Sub MakeSQL_Expand(ByVal param As ExpandItemParam,
                                ByRef sql As String,
                                ByRef paramInfo As OSK.X1.DataAccess.ParamInfoList,
                                ByVal readLebel As Integer)

        '◆◇◆SQL文作成◇◆◇
        Dim CdecResult As Decimal = 0
        Dim addsql As Boolean = False
        Dim st As New System.Text.StringBuilder
        Dim WKSQL As New Text.StringBuilder

        '-- 選択リストの定義
        WKSQL.Append(param.取得用SQL)

        Dim Key As String = "任意項目"
        Dim 置換対象 As String = Key
        For item As Integer = 1 To param.任意項目.Count
            Key = "任意項目" & CStr(item)
            置換対象 = "%" & Key & "%"
            If WKSQL.ToString.IndexOf(置換対象) <> -1 Then
                WKSQL.Replace(置換対象, 任意項目変換(CStr(param.任意項目.Item(Key))))
            End If
        Next

        Dim nextindex As Integer = 0
        Dim paramstr As String = "@{0}"
        Dim searchword As String = ""
        Dim SQLWhere As New System.Text.StringBuilder
        For i As Integer = 0 To param.FieldBuilder.Count - 1
            nextindex = 0　'対象条件が変わったら先頭から検索
            searchword = String.Format(paramstr, (i + 1).ToString)
            Do
                SQLWhere.Clear()
                nextindex = WKSQL.ToString.IndexOf(searchword, nextindex)
                If nextindex = -1 Then Exit Do

                SQLWhere.Append(GetParameter(i, param, param.FieldBuilder(i).FieldBuilder, paramInfo))

                WKSQL.Replace(searchword, SQLWhere.ToString, nextindex, searchword.Length)
            Loop
        Next
        st.Append(WKSQL.ToString)

        st.Append(QueryWrapper.AddUR())
        sql = st.ToString
    End Sub

#End Region

#End Region

End Class
