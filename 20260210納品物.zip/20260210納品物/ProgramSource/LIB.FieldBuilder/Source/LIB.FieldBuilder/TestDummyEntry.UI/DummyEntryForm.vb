﻿Imports System.Security
Imports OSK.X1.Foundation.ProgramLoad.UserInterface

Public Class DummyEntryForm
    Inherits DesignFormBase
    Implements IDummyEntryForm

    'Private _form As OSK.X1.CUS.A99999.LIB900.UI.KensakuForm
    Private _引渡条件 As IDictionary = New Hashtable
    Private _変更 As Boolean = False
    Private _loader As ILocalLoader

    Public Sub New()

        ' この呼び出しは、Windows フォーム デザイナで必要です。
        InitializeComponent()
    End Sub

    Public Sub SetUpForm() Implements IDummyEntryForm.SetUpForm

        Dim preText As String = "エスケープ対象：　<　>　&　""　' <= >="
        Dim xmlText As String = SecurityElement.Escape(preText)
        Me.Text = "汎用画面照会テスト用プログラム"
        Me.ShowDialog()

    End Sub

    Public Overrides Sub LoadImpl(ByVal sender As Object, ByVal e As System.EventArgs)

        MyBase.LoadImpl(sender, e)
        AddHandler edaban.InputNumericalControl.Change, AddressOf edaban_Changed

    End Sub


    Private Sub 内訳_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles 検索.Click

        Dim result As Boolean = False
        Dim paraminfo As IDictionary = New Hashtable

        Dim PGID As String = ""
        Select Case Me.PGIDの指定.Value
            Case 1
                PGID = "OSK.X1.OTS.G00600"
            Case 2
                PGID = "OSK.X1.OTS.A01400"
            Case 3
                PGID = "OSK.X1.OTS.A01700"
        End Select
        PGID = "OSK.X1.OTS.A02800"

        If 再読込.CheckState = CheckState.Checked Then
            _loader = Nothing
        End If

        SetparamInfo(paraminfo)
        If _loader Is Nothing Then
            _loader = New ProgramLoad.UserInterface.LocalLoader
            _loader.Startup(Me, PGID, CInt(edaban.Value))
        End If
        _loader.Run(paraminfo)

        If paraminfo.Contains("@RET1") Then
            戻り値１.TextValue = CType(paraminfo.Item("@RET1"), String)
        End If
        If paraminfo.Contains("@RET2") Then
            戻り値２.TextValue = CType(paraminfo.Item("@RET2"), String)
        End If

        If paraminfo.Contains("再表示区分") Then
            If CBool(paraminfo.Item("再表示区分")) = True Then
                再表示区分.CheckState = CheckState.Checked
            Else
                再表示区分.CheckState = CheckState.Unchecked
            End If
        End If
    End Sub

    Private Sub SetparamInfo(ByRef paraminfo As IDictionary)

        paraminfo.Item("再表示区分") = 再表示区分.CheckState = CheckState.Checked

        If 検索１PARM1.TextValue.TrimEnd <> "" Then
            paraminfo.Item("項目1PARM1") = 検索１PARM1.TextValue.TrimEnd
            If 検索１PARM3.Text.TrimEnd <> "" Then
                paraminfo.Item("項目1PARM2") = 検索１PARM2.Text.TrimEnd
            End If
            If 検索１PARM3.Text.TrimEnd <> "" Then
                paraminfo.Item("項目1PARM3") = 検索１PARM3.Text.TrimEnd
            End If
            If 検索１PARM4.Text.TrimEnd <> "" Then
                paraminfo.Item("項目1PARM4") = 検索１PARM4.Text.TrimEnd
            End If
            If 検索１PARM5.Text.TrimEnd <> "" Then
                paraminfo.Item("項目1PARM5") = 検索１PARM5.Text.TrimEnd
            End If
        End If

        If 検索２PARM1.TextValue.TrimEnd <> "" Then
            paraminfo.Item("項目2PARM1") = 検索２PARM1.TextValue.TrimEnd
            If 検索２PARM2.Text.TrimEnd <> "" Then
                paraminfo.Item("項目2PARM2") = 検索２PARM2.Text.TrimEnd
            End If
            If 検索２PARM3.Text.TrimEnd <> "" Then
                paraminfo.Item("項目2PARM3") = 検索２PARM3.Text.TrimEnd
            End If
            If 検索２PARM4.Text.TrimEnd <> "" Then
                paraminfo.Item("項目2PARM4") = 検索２PARM4.Text.TrimEnd
            End If
            If 検索２PARM5.Text.TrimEnd <> "" Then
                paraminfo.Item("項目2PARM5") = 検索２PARM5.Text.TrimEnd
            End If
        End If

        If 検索３PARM1.TextValue.TrimEnd <> "" Then
            paraminfo.Item("項目3PARM1") = 検索３PARM1.TextValue.TrimEnd
            If 検索３PARM2.Text.TrimEnd <> "" Then
                paraminfo.Item("項目3PARM2") = 検索３PARM2.Text.TrimEnd
            End If
            If 検索３PARM3.Text.TrimEnd <> "" Then
                paraminfo.Item("項目3PARM3") = 検索３PARM3.Text.TrimEnd
            End If
            If 検索３PARM4.Text.TrimEnd <> "" Then
                paraminfo.Item("項目3PARM4") = 検索３PARM4.Text.TrimEnd
            End If
            If 検索３PARM5.Text.TrimEnd <> "" Then
                paraminfo.Item("項目3PARM5") = 検索３PARM5.Text.TrimEnd
            End If
        End If

        If 検索４PARM1.TextValue.TrimEnd <> "" Then
            paraminfo.Item("項目4PARM1") = 検索４PARM1.TextValue.TrimEnd
            If 検索４PARM2.Text.TrimEnd <> "" Then
                paraminfo.Item("項目4PARM2") = 検索４PARM2.Text.TrimEnd
            End If
            If 検索４PARM3.Text.TrimEnd <> "" Then
                paraminfo.Item("項目4PARM3") = 検索４PARM3.Text.TrimEnd
            End If
            If 検索４PARM4.Text.TrimEnd <> "" Then
                paraminfo.Item("項目4PARM4") = 検索４PARM4.Text.TrimEnd
            End If
            If 検索４PARM5.Text.TrimEnd <> "" Then
                paraminfo.Item("項目4PARM5") = 検索４PARM5.Text.TrimEnd
            End If
        End If

        If 検索５PARM1.TextValue.TrimEnd <> "" Then
            paraminfo.Item("項目5PARM1") = 検索５PARM1.TextValue.TrimEnd
            If 検索５PARM2.Text.TrimEnd <> "" Then
                paraminfo.Item("項目5PARM2") = 検索５PARM2.Text.TrimEnd
            End If
            If 検索５PARM3.Text.TrimEnd <> "" Then
                paraminfo.Item("項目5PARM3") = 検索５PARM3.Text.TrimEnd
            End If
            If 検索５PARM4.Text.TrimEnd <> "" Then
                paraminfo.Item("項目5PARM4") = 検索５PARM4.Text.TrimEnd
            End If
            If 検索５PARM5.Text.TrimEnd <> "" Then
                paraminfo.Item("項目5PARM5") = 検索５PARM5.Text.TrimEnd
            End If
        End If

        If 任意項目1.TextValue.TrimEnd <> "" Then
            paraminfo.Item("任意項目1") = 任意項目1.TextValue
        End If
        If 任意項目2.TextValue.TrimEnd <> "" Then
            paraminfo.Item("任意項目2") = 任意項目2.TextValue
        End If
        If 任意項目3.TextValue.TrimEnd <> "" Then
            paraminfo.Item("任意項目3") = 任意項目3.TextValue
        End If
        If 任意項目4.TextValue.TrimEnd <> "" Then
            paraminfo.Item("任意項目4") = 任意項目4.TextValue
        End If
        If 任意項目5.TextValue.TrimEnd <> "" Then
            paraminfo.Item("任意項目5") = 任意項目5.TextValue
        End If
        '引渡条件 = New Hashtable

        '引渡条件.Add(IKensakuForm.引渡条件型.再表示区分.ToString, False)

    End Sub

    Private Sub edaban_Changed(sender As Object, e As EventArgs)
        _loader = Nothing
    End Sub

End Class
