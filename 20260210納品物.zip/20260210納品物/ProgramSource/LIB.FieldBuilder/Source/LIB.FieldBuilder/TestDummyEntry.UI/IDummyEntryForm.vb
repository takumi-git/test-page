﻿Public Interface IDummyEntryForm
    Inherits IInsideJob

    ''' <summary>
    ''' 初期処理を行なう
    ''' </summary>
    ''' <remarks></remarks>
    Sub SetUpForm()

End Interface
