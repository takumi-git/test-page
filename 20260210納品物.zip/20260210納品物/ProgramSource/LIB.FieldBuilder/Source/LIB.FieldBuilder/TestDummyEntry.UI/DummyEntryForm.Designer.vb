﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class DummyEntryForm
    Inherits OSK.X1.Foundation.UIDesign.UserInterface.DesignFormBase

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Windows フォーム デザイナで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナで必要です。
    'Windows フォーム デザイナを使用して変更できます。  
    'コード エディタを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim Item1 As OSK.X1.Foundation.Controls.GroupOptionImpl.Item = New OSK.X1.Foundation.Controls.GroupOptionImpl.Item()
        Dim Item2 As OSK.X1.Foundation.Controls.GroupOptionImpl.Item = New OSK.X1.Foundation.Controls.GroupOptionImpl.Item()
        Dim Item3 As OSK.X1.Foundation.Controls.GroupOptionImpl.Item = New OSK.X1.Foundation.Controls.GroupOptionImpl.Item()
        Me.検索 = New OSK.X1.Foundation.SimpleControl.CommandButton()
        Me.再表示区分 = New OSK.X1.Foundation.SimpleControl.CheckBox()
        Me.検索１PARM1 = New OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemName()
        Me.検索２PARM1 = New OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemName()
        Me.検索３PARM1 = New OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemName()
        Me.Panel1 = New OSK.X1.Foundation.SimpleControl.Panel(Me.components)
        Me.Label5 = New OSK.X1.Foundation.SimpleControl.Label()
        Me.検索５PARM5 = New OSK.X1.Foundation.SimpleControl.InputText()
        Me.検索５PARM4 = New OSK.X1.Foundation.SimpleControl.InputText()
        Me.検索４PARM5 = New OSK.X1.Foundation.SimpleControl.InputText()
        Me.検索４PARM4 = New OSK.X1.Foundation.SimpleControl.InputText()
        Me.検索３PARM5 = New OSK.X1.Foundation.SimpleControl.InputText()
        Me.検索３PARM4 = New OSK.X1.Foundation.SimpleControl.InputText()
        Me.検索２PARM5 = New OSK.X1.Foundation.SimpleControl.InputText()
        Me.検索２PARM4 = New OSK.X1.Foundation.SimpleControl.InputText()
        Me.検索１PARM5 = New OSK.X1.Foundation.SimpleControl.InputText()
        Me.検索１PARM4 = New OSK.X1.Foundation.SimpleControl.InputText()
        Me.Label4 = New OSK.X1.Foundation.SimpleControl.Label()
        Me.Label3 = New OSK.X1.Foundation.SimpleControl.Label()
        Me.Label2 = New OSK.X1.Foundation.SimpleControl.Label()
        Me.Label1 = New OSK.X1.Foundation.SimpleControl.Label()
        Me.検索５PARM3 = New OSK.X1.Foundation.SimpleControl.InputText()
        Me.検索５PARM2 = New OSK.X1.Foundation.SimpleControl.InputText()
        Me.検索５PARM1 = New OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemName()
        Me.検索４PARM3 = New OSK.X1.Foundation.SimpleControl.InputText()
        Me.検索４PARM2 = New OSK.X1.Foundation.SimpleControl.InputText()
        Me.検索４PARM1 = New OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemName()
        Me.検索３PARM3 = New OSK.X1.Foundation.SimpleControl.InputText()
        Me.検索３PARM2 = New OSK.X1.Foundation.SimpleControl.InputText()
        Me.検索２PARM3 = New OSK.X1.Foundation.SimpleControl.InputText()
        Me.検索２PARM2 = New OSK.X1.Foundation.SimpleControl.InputText()
        Me.検索１PARM3 = New OSK.X1.Foundation.SimpleControl.InputText()
        Me.検索１PARM2 = New OSK.X1.Foundation.SimpleControl.InputText()
        Me.戻り値１ = New OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemName()
        Me.戻り値２ = New OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemName()
        Me.edaban = New OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputNumericalWithItemName()
        Me.Panel2 = New OSK.X1.Foundation.SimpleControl.Panel(Me.components)
        Me.任意項目5 = New OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemName()
        Me.任意項目4 = New OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemName()
        Me.任意項目3 = New OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemName()
        Me.任意項目2 = New OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemName()
        Me.任意項目1 = New OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemName()
        Me.PGIDの指定 = New OSK.X1.Foundation.SimpleControl.GroupOption()
        Me.再読込 = New OSK.X1.Foundation.SimpleControl.CheckBox()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        '検索
        '
        Me.検索.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.検索.FocusBackColor = System.Drawing.Color.Empty
        Me.検索.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.検索.Image = Nothing
        Me.検索.Location = New System.Drawing.Point(131, 423)
        Me.検索.Name = "検索"
        Me.検索.NextByDownKey = False
        Me.検索.NextByEnterKey = False
        Me.検索.NextByTabKey = False
        Me.検索.RemarkString = Nothing
        Me.検索.Size = New System.Drawing.Size(217, 34)
        Me.検索.TabIndex = 8
        Me.検索.Text = "検索"
        Me.検索.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        '再表示区分
        '
        Me.再表示区分.CheckState = System.Windows.Forms.CheckState.Unchecked
        Me.再表示区分.DrawFocusFrame = True
        Me.再表示区分.FocusBackColor = System.Drawing.Color.Empty
        Me.再表示区分.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.再表示区分.IndeterminateText = ""
        Me.再表示区分.Location = New System.Drawing.Point(6, 423)
        Me.再表示区分.Name = "再表示区分"
        Me.再表示区分.RemarkString = Nothing
        Me.再表示区分.Size = New System.Drawing.Size(100, 19)
        Me.再表示区分.TabIndex = 7
        Me.再表示区分.TabStop = False
        Me.再表示区分.Text = "再表示区分"
        Me.再表示区分.UncheckedText = ""
        '
        '検索１PARM1
        '
        Me.検索１PARM1.AllowBottomPosition = True
        Me.検索１PARM1.AutoResizeInputControl = True
        Me.検索１PARM1.BackColor = System.Drawing.Color.Transparent
        Me.検索１PARM1.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.検索１PARM1.GroupNo = 0
        Me.検索１PARM1.Indent = 0
        Me.検索１PARM1.InnerSpace = 3
        Me.検索１PARM1.InputAreaFont = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.検索１PARM1.InputControlReadOnly = False
        Me.検索１PARM1.InputControlSize = New System.Drawing.Size(82, 19)
        Me.検索１PARM1.InputTextImeMode = OSK.X1.Foundation.Controls.InputText.ImeModeType.NoControl
        Me.検索１PARM1.InputType = OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemName.InputTypeList.全文字入力可
        Me.検索１PARM1.ItemName = "項目１"
        Me.検索１PARM1.ItemNameAreaHeight = 19
        Me.検索１PARM1.ItemNameAreaWidth = 100
        Me.検索１PARM1.ItemNameBorderColor = System.Drawing.SystemColors.Window
        Me.検索１PARM1.ItemNameBorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.検索１PARM1.ItemNameFont = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.検索１PARM1.ItemNameTextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Equal
        Me.検索１PARM1.Location = New System.Drawing.Point(3, 134)
        Me.検索１PARM1.MaxLength = 10
        Me.検索１PARM1.MaxLengthMode = OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CharCount
        Me.検索１PARM1.Name = "検索１PARM1"
        Me.検索１PARM1.RemarkString = Nothing
        Me.検索１PARM1.Size = New System.Drawing.Size(188, 19)
        Me.検索１PARM1.SubGroupNo = 0
        Me.検索１PARM1.TabIndex = 2
        Me.検索１PARM1.TextValue = ""
        Me.検索１PARM1.ZeroFill = False
        Me.検索１PARM1.ZeroFillAlways = False
        '
        '検索２PARM1
        '
        Me.検索２PARM1.AllowBottomPosition = True
        Me.検索２PARM1.AutoResizeInputControl = True
        Me.検索２PARM1.BackColor = System.Drawing.Color.Transparent
        Me.検索２PARM1.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.検索２PARM1.GroupNo = 0
        Me.検索２PARM1.Indent = 0
        Me.検索２PARM1.InnerSpace = 3
        Me.検索２PARM1.InputAreaFont = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.検索２PARM1.InputControlReadOnly = False
        Me.検索２PARM1.InputControlSize = New System.Drawing.Size(82, 19)
        Me.検索２PARM1.InputTextImeMode = OSK.X1.Foundation.Controls.InputText.ImeModeType.NoControl
        Me.検索２PARM1.InputType = OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemName.InputTypeList.全文字入力可
        Me.検索２PARM1.ItemName = "項目２"
        Me.検索２PARM1.ItemNameAreaHeight = 19
        Me.検索２PARM1.ItemNameAreaWidth = 100
        Me.検索２PARM1.ItemNameBorderColor = System.Drawing.SystemColors.Window
        Me.検索２PARM1.ItemNameBorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.検索２PARM1.ItemNameFont = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.検索２PARM1.ItemNameTextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Equal
        Me.検索２PARM1.Location = New System.Drawing.Point(3, 159)
        Me.検索２PARM1.MaxLength = 10
        Me.検索２PARM1.MaxLengthMode = OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CharCount
        Me.検索２PARM1.Name = "検索２PARM1"
        Me.検索２PARM1.RemarkString = Nothing
        Me.検索２PARM1.Size = New System.Drawing.Size(188, 19)
        Me.検索２PARM1.SubGroupNo = 0
        Me.検索２PARM1.TabIndex = 7
        Me.検索２PARM1.TextValue = ""
        Me.検索２PARM1.ZeroFill = False
        Me.検索２PARM1.ZeroFillAlways = False
        '
        '検索３PARM1
        '
        Me.検索３PARM1.AllowBottomPosition = True
        Me.検索３PARM1.AutoResizeInputControl = True
        Me.検索３PARM1.BackColor = System.Drawing.Color.Transparent
        Me.検索３PARM1.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.検索３PARM1.GroupNo = 0
        Me.検索３PARM1.Indent = 0
        Me.検索３PARM1.InnerSpace = 3
        Me.検索３PARM1.InputAreaFont = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.検索３PARM1.InputControlReadOnly = False
        Me.検索３PARM1.InputControlSize = New System.Drawing.Size(82, 19)
        Me.検索３PARM1.InputTextImeMode = OSK.X1.Foundation.Controls.InputText.ImeModeType.NoControl
        Me.検索３PARM1.InputType = OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemName.InputTypeList.全文字入力可
        Me.検索３PARM1.ItemName = "項目３"
        Me.検索３PARM1.ItemNameAreaHeight = 19
        Me.検索３PARM1.ItemNameAreaWidth = 100
        Me.検索３PARM1.ItemNameBorderColor = System.Drawing.SystemColors.Window
        Me.検索３PARM1.ItemNameBorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.検索３PARM1.ItemNameFont = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.検索３PARM1.ItemNameTextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Equal
        Me.検索３PARM1.Location = New System.Drawing.Point(3, 184)
        Me.検索３PARM1.MaxLength = 10
        Me.検索３PARM1.MaxLengthMode = OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CharCount
        Me.検索３PARM1.Name = "検索３PARM1"
        Me.検索３PARM1.RemarkString = Nothing
        Me.検索３PARM1.Size = New System.Drawing.Size(188, 19)
        Me.検索３PARM1.SubGroupNo = 0
        Me.検索３PARM1.TabIndex = 12
        Me.検索３PARM1.TextValue = ""
        Me.検索３PARM1.ZeroFill = False
        Me.検索３PARM1.ZeroFillAlways = False
        '
        'Panel1
        '
        Me.Panel1.CausesValidation = False
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.検索５PARM5)
        Me.Panel1.Controls.Add(Me.検索５PARM4)
        Me.Panel1.Controls.Add(Me.検索４PARM5)
        Me.Panel1.Controls.Add(Me.検索４PARM4)
        Me.Panel1.Controls.Add(Me.検索３PARM5)
        Me.Panel1.Controls.Add(Me.検索３PARM4)
        Me.Panel1.Controls.Add(Me.検索２PARM5)
        Me.Panel1.Controls.Add(Me.検索２PARM4)
        Me.Panel1.Controls.Add(Me.検索１PARM5)
        Me.Panel1.Controls.Add(Me.検索１PARM4)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.検索５PARM3)
        Me.Panel1.Controls.Add(Me.検索５PARM2)
        Me.Panel1.Controls.Add(Me.検索５PARM1)
        Me.Panel1.Controls.Add(Me.検索４PARM3)
        Me.Panel1.Controls.Add(Me.検索４PARM2)
        Me.Panel1.Controls.Add(Me.検索４PARM1)
        Me.Panel1.Controls.Add(Me.検索３PARM3)
        Me.Panel1.Controls.Add(Me.検索３PARM2)
        Me.Panel1.Controls.Add(Me.検索２PARM3)
        Me.Panel1.Controls.Add(Me.検索２PARM2)
        Me.Panel1.Controls.Add(Me.検索１PARM3)
        Me.Panel1.Controls.Add(Me.検索１PARM2)
        Me.Panel1.Controls.Add(Me.検索３PARM1)
        Me.Panel1.Controls.Add(Me.検索２PARM1)
        Me.Panel1.Controls.Add(Me.検索１PARM1)
        Me.Panel1.Location = New System.Drawing.Point(9, 75)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(629, 272)
        Me.Panel1.TabIndex = 3
        Me.Panel1.Title = "引数"
        Me.Panel1.TitleVisible = True
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label5.Location = New System.Drawing.Point(3, 62)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(597, 19)
        Me.Label5.TabIndex = 105
        Me.Label5.Tag = "@Form@"
        Me.Label5.Text = "２コード範囲指定の場合は、１：範囲 2：From（メイン） 3：From（サブ） 4：To（メイン） 5：To（サブ）"
        '
        '検索５PARM5
        '
        Me.検索５PARM5.AutoResize = True
        Me.検索５PARM5.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.検索５PARM5.FocusBackColor = System.Drawing.Color.Empty
        Me.検索５PARM5.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.検索５PARM5.Insert = False
        Me.検索５PARM5.Location = New System.Drawing.Point(515, 234)
        Me.検索５PARM5.MaxLength = 10
        Me.検索５PARM5.Name = "検索５PARM5"
        Me.検索５PARM5.RemarkString = Nothing
        Me.検索５PARM5.Size = New System.Drawing.Size(100, 19)
        Me.検索５PARM5.TabIndex = 26
        Me.検索５PARM5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        '検索５PARM4
        '
        Me.検索５PARM4.AutoResize = True
        Me.検索５PARM4.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.検索５PARM4.FocusBackColor = System.Drawing.Color.Empty
        Me.検索５PARM4.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.検索５PARM4.Insert = False
        Me.検索５PARM4.Location = New System.Drawing.Point(409, 234)
        Me.検索５PARM4.MaxLength = 10
        Me.検索５PARM4.Name = "検索５PARM4"
        Me.検索５PARM4.RemarkString = Nothing
        Me.検索５PARM4.Size = New System.Drawing.Size(100, 19)
        Me.検索５PARM4.TabIndex = 25
        Me.検索５PARM4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        '検索４PARM5
        '
        Me.検索４PARM5.AutoResize = True
        Me.検索４PARM5.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.検索４PARM5.FocusBackColor = System.Drawing.Color.Empty
        Me.検索４PARM5.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.検索４PARM5.Insert = False
        Me.検索４PARM5.Location = New System.Drawing.Point(515, 209)
        Me.検索４PARM5.MaxLength = 10
        Me.検索４PARM5.Name = "検索４PARM5"
        Me.検索４PARM5.RemarkString = Nothing
        Me.検索４PARM5.Size = New System.Drawing.Size(100, 19)
        Me.検索４PARM5.TabIndex = 21
        Me.検索４PARM5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        '検索４PARM4
        '
        Me.検索４PARM4.AutoResize = True
        Me.検索４PARM4.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.検索４PARM4.FocusBackColor = System.Drawing.Color.Empty
        Me.検索４PARM4.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.検索４PARM4.Insert = False
        Me.検索４PARM4.Location = New System.Drawing.Point(409, 209)
        Me.検索４PARM4.MaxLength = 10
        Me.検索４PARM4.Name = "検索４PARM4"
        Me.検索４PARM4.RemarkString = Nothing
        Me.検索４PARM4.Size = New System.Drawing.Size(100, 19)
        Me.検索４PARM4.TabIndex = 20
        Me.検索４PARM4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        '検索３PARM5
        '
        Me.検索３PARM5.AutoResize = True
        Me.検索３PARM5.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.検索３PARM5.FocusBackColor = System.Drawing.Color.Empty
        Me.検索３PARM5.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.検索３PARM5.Insert = False
        Me.検索３PARM5.Location = New System.Drawing.Point(515, 184)
        Me.検索３PARM5.MaxLength = 10
        Me.検索３PARM5.Name = "検索３PARM5"
        Me.検索３PARM5.RemarkString = Nothing
        Me.検索３PARM5.Size = New System.Drawing.Size(100, 19)
        Me.検索３PARM5.TabIndex = 16
        Me.検索３PARM5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        '検索３PARM4
        '
        Me.検索３PARM4.AutoResize = True
        Me.検索３PARM4.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.検索３PARM4.FocusBackColor = System.Drawing.Color.Empty
        Me.検索３PARM4.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.検索３PARM4.Insert = False
        Me.検索３PARM4.Location = New System.Drawing.Point(409, 184)
        Me.検索３PARM4.MaxLength = 10
        Me.検索３PARM4.Name = "検索３PARM4"
        Me.検索３PARM4.RemarkString = Nothing
        Me.検索３PARM4.Size = New System.Drawing.Size(100, 19)
        Me.検索３PARM4.TabIndex = 15
        Me.検索３PARM4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        '検索２PARM5
        '
        Me.検索２PARM5.AutoResize = True
        Me.検索２PARM5.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.検索２PARM5.FocusBackColor = System.Drawing.Color.Empty
        Me.検索２PARM5.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.検索２PARM5.Insert = False
        Me.検索２PARM5.Location = New System.Drawing.Point(515, 159)
        Me.検索２PARM5.MaxLength = 10
        Me.検索２PARM5.Name = "検索２PARM5"
        Me.検索２PARM5.RemarkString = Nothing
        Me.検索２PARM5.Size = New System.Drawing.Size(100, 19)
        Me.検索２PARM5.TabIndex = 11
        Me.検索２PARM5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        '検索２PARM4
        '
        Me.検索２PARM4.AutoResize = True
        Me.検索２PARM4.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.検索２PARM4.FocusBackColor = System.Drawing.Color.Empty
        Me.検索２PARM4.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.検索２PARM4.Insert = False
        Me.検索２PARM4.Location = New System.Drawing.Point(409, 159)
        Me.検索２PARM4.MaxLength = 10
        Me.検索２PARM4.Name = "検索２PARM4"
        Me.検索２PARM4.RemarkString = Nothing
        Me.検索２PARM4.Size = New System.Drawing.Size(100, 19)
        Me.検索２PARM4.TabIndex = 10
        Me.検索２PARM4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        '検索１PARM5
        '
        Me.検索１PARM5.AutoResize = True
        Me.検索１PARM5.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.検索１PARM5.FocusBackColor = System.Drawing.Color.Empty
        Me.検索１PARM5.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.検索１PARM5.Insert = False
        Me.検索１PARM5.Location = New System.Drawing.Point(515, 134)
        Me.検索１PARM5.MaxLength = 10
        Me.検索１PARM5.Name = "検索１PARM5"
        Me.検索１PARM5.RemarkString = Nothing
        Me.検索１PARM5.Size = New System.Drawing.Size(100, 19)
        Me.検索１PARM5.TabIndex = 6
        Me.検索１PARM5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        '検索１PARM4
        '
        Me.検索１PARM4.AutoResize = True
        Me.検索１PARM4.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.検索１PARM4.FocusBackColor = System.Drawing.Color.Empty
        Me.検索１PARM4.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.検索１PARM4.Insert = False
        Me.検索１PARM4.Location = New System.Drawing.Point(409, 134)
        Me.検索１PARM4.MaxLength = 10
        Me.検索１PARM4.Name = "検索１PARM4"
        Me.検索１PARM4.RemarkString = Nothing
        Me.検索１PARM4.Size = New System.Drawing.Size(100, 19)
        Me.検索１PARM4.TabIndex = 5
        Me.検索１PARM4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label4.Location = New System.Drawing.Point(3, 106)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(294, 19)
        Me.Label4.TabIndex = 104
        Me.Label4.Tag = "@Form@"
        Me.Label4.Text = "日付以外 0:から、1:以上、2:以下、3:のみ、4:全件　　"
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label3.Location = New System.Drawing.Point(3, 84)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(294, 19)
        Me.Label3.TabIndex = 103
        Me.Label3.Tag = "@Form@"
        Me.Label3.Text = "日付　　　 0:から、1:以前、2:以降、3:のみ、4:全件　　"
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label2.Location = New System.Drawing.Point(3, 40)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(271, 19)
        Me.Label2.TabIndex = 102
        Me.Label2.Tag = "@Form@"
        Me.Label2.Text = "範囲指定の場合は、１：範囲 2：From 3：To"
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.Label1.Location = New System.Drawing.Point(3, 18)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(271, 19)
        Me.Label1.TabIndex = 101
        Me.Label1.Tag = "@Form@"
        Me.Label1.Text = "各項目の初期値を指定可能"
        '
        '検索５PARM3
        '
        Me.検索５PARM3.AutoResize = True
        Me.検索５PARM3.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.検索５PARM3.FocusBackColor = System.Drawing.Color.Empty
        Me.検索５PARM3.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.検索５PARM3.Insert = False
        Me.検索５PARM3.Location = New System.Drawing.Point(303, 234)
        Me.検索５PARM3.MaxLength = 10
        Me.検索５PARM3.Name = "検索５PARM3"
        Me.検索５PARM3.RemarkString = Nothing
        Me.検索５PARM3.Size = New System.Drawing.Size(100, 19)
        Me.検索５PARM3.TabIndex = 24
        Me.検索５PARM3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        '検索５PARM2
        '
        Me.検索５PARM2.AutoResize = True
        Me.検索５PARM2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.検索５PARM2.FocusBackColor = System.Drawing.Color.Empty
        Me.検索５PARM2.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.検索５PARM2.Insert = False
        Me.検索５PARM2.Location = New System.Drawing.Point(197, 234)
        Me.検索５PARM2.MaxLength = 10
        Me.検索５PARM2.Name = "検索５PARM2"
        Me.検索５PARM2.RemarkString = Nothing
        Me.検索５PARM2.Size = New System.Drawing.Size(100, 19)
        Me.検索５PARM2.TabIndex = 23
        Me.検索５PARM2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        '検索５PARM1
        '
        Me.検索５PARM1.AllowBottomPosition = True
        Me.検索５PARM1.AutoResizeInputControl = True
        Me.検索５PARM1.BackColor = System.Drawing.Color.Transparent
        Me.検索５PARM1.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.検索５PARM1.GroupNo = 0
        Me.検索５PARM1.Indent = 0
        Me.検索５PARM1.InnerSpace = 3
        Me.検索５PARM1.InputAreaFont = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.検索５PARM1.InputControlReadOnly = False
        Me.検索５PARM1.InputControlSize = New System.Drawing.Size(82, 19)
        Me.検索５PARM1.InputTextImeMode = OSK.X1.Foundation.Controls.InputText.ImeModeType.NoControl
        Me.検索５PARM1.InputType = OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemName.InputTypeList.全文字入力可
        Me.検索５PARM1.ItemName = "項目５"
        Me.検索５PARM1.ItemNameAreaHeight = 19
        Me.検索５PARM1.ItemNameAreaWidth = 100
        Me.検索５PARM1.ItemNameBorderColor = System.Drawing.SystemColors.Window
        Me.検索５PARM1.ItemNameBorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.検索５PARM1.ItemNameFont = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.検索５PARM1.ItemNameTextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Equal
        Me.検索５PARM1.Location = New System.Drawing.Point(3, 234)
        Me.検索５PARM1.MaxLength = 10
        Me.検索５PARM1.MaxLengthMode = OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CharCount
        Me.検索５PARM1.Name = "検索５PARM1"
        Me.検索５PARM1.RemarkString = Nothing
        Me.検索５PARM1.Size = New System.Drawing.Size(188, 19)
        Me.検索５PARM1.SubGroupNo = 0
        Me.検索５PARM1.TabIndex = 22
        Me.検索５PARM1.TextValue = ""
        Me.検索５PARM1.ZeroFill = False
        Me.検索５PARM1.ZeroFillAlways = False
        '
        '検索４PARM3
        '
        Me.検索４PARM3.AutoResize = True
        Me.検索４PARM3.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.検索４PARM3.FocusBackColor = System.Drawing.Color.Empty
        Me.検索４PARM3.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.検索４PARM3.Insert = False
        Me.検索４PARM3.Location = New System.Drawing.Point(303, 209)
        Me.検索４PARM3.MaxLength = 10
        Me.検索４PARM3.Name = "検索４PARM3"
        Me.検索４PARM3.RemarkString = Nothing
        Me.検索４PARM3.Size = New System.Drawing.Size(100, 19)
        Me.検索４PARM3.TabIndex = 19
        Me.検索４PARM3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        '検索４PARM2
        '
        Me.検索４PARM2.AutoResize = True
        Me.検索４PARM2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.検索４PARM2.FocusBackColor = System.Drawing.Color.Empty
        Me.検索４PARM2.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.検索４PARM2.Insert = False
        Me.検索４PARM2.Location = New System.Drawing.Point(197, 209)
        Me.検索４PARM2.MaxLength = 10
        Me.検索４PARM2.Name = "検索４PARM2"
        Me.検索４PARM2.RemarkString = Nothing
        Me.検索４PARM2.Size = New System.Drawing.Size(100, 19)
        Me.検索４PARM2.TabIndex = 18
        Me.検索４PARM2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        '検索４PARM1
        '
        Me.検索４PARM1.AllowBottomPosition = True
        Me.検索４PARM1.AutoResizeInputControl = True
        Me.検索４PARM1.BackColor = System.Drawing.Color.Transparent
        Me.検索４PARM1.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.検索４PARM1.GroupNo = 0
        Me.検索４PARM1.Indent = 0
        Me.検索４PARM1.InnerSpace = 3
        Me.検索４PARM1.InputAreaFont = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.検索４PARM1.InputControlReadOnly = False
        Me.検索４PARM1.InputControlSize = New System.Drawing.Size(82, 19)
        Me.検索４PARM1.InputTextImeMode = OSK.X1.Foundation.Controls.InputText.ImeModeType.NoControl
        Me.検索４PARM1.InputType = OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemName.InputTypeList.全文字入力可
        Me.検索４PARM1.ItemName = "項目４"
        Me.検索４PARM1.ItemNameAreaHeight = 19
        Me.検索４PARM1.ItemNameAreaWidth = 100
        Me.検索４PARM1.ItemNameBorderColor = System.Drawing.SystemColors.Window
        Me.検索４PARM1.ItemNameBorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.検索４PARM1.ItemNameFont = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.検索４PARM1.ItemNameTextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Equal
        Me.検索４PARM1.Location = New System.Drawing.Point(3, 209)
        Me.検索４PARM1.MaxLength = 10
        Me.検索４PARM1.MaxLengthMode = OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CharCount
        Me.検索４PARM1.Name = "検索４PARM1"
        Me.検索４PARM1.RemarkString = Nothing
        Me.検索４PARM1.Size = New System.Drawing.Size(188, 19)
        Me.検索４PARM1.SubGroupNo = 0
        Me.検索４PARM1.TabIndex = 17
        Me.検索４PARM1.TextValue = ""
        Me.検索４PARM1.ZeroFill = False
        Me.検索４PARM1.ZeroFillAlways = False
        '
        '検索３PARM3
        '
        Me.検索３PARM3.AutoResize = True
        Me.検索３PARM3.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.検索３PARM3.FocusBackColor = System.Drawing.Color.Empty
        Me.検索３PARM3.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.検索３PARM3.Insert = False
        Me.検索３PARM3.Location = New System.Drawing.Point(303, 184)
        Me.検索３PARM3.MaxLength = 10
        Me.検索３PARM3.Name = "検索３PARM3"
        Me.検索３PARM3.RemarkString = Nothing
        Me.検索３PARM3.Size = New System.Drawing.Size(100, 19)
        Me.検索３PARM3.TabIndex = 14
        Me.検索３PARM3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        '検索３PARM2
        '
        Me.検索３PARM2.AutoResize = True
        Me.検索３PARM2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.検索３PARM2.FocusBackColor = System.Drawing.Color.Empty
        Me.検索３PARM2.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.検索３PARM2.Insert = False
        Me.検索３PARM2.Location = New System.Drawing.Point(197, 184)
        Me.検索３PARM2.MaxLength = 10
        Me.検索３PARM2.Name = "検索３PARM2"
        Me.検索３PARM2.RemarkString = Nothing
        Me.検索３PARM2.Size = New System.Drawing.Size(100, 19)
        Me.検索３PARM2.TabIndex = 13
        Me.検索３PARM2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        '検索２PARM3
        '
        Me.検索２PARM3.AutoResize = True
        Me.検索２PARM3.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.検索２PARM3.FocusBackColor = System.Drawing.Color.Empty
        Me.検索２PARM3.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.検索２PARM3.Insert = False
        Me.検索２PARM3.Location = New System.Drawing.Point(303, 159)
        Me.検索２PARM3.MaxLength = 10
        Me.検索２PARM3.Name = "検索２PARM3"
        Me.検索２PARM3.RemarkString = Nothing
        Me.検索２PARM3.Size = New System.Drawing.Size(100, 19)
        Me.検索２PARM3.TabIndex = 9
        Me.検索２PARM3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        '検索２PARM2
        '
        Me.検索２PARM2.AutoResize = True
        Me.検索２PARM2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.検索２PARM2.FocusBackColor = System.Drawing.Color.Empty
        Me.検索２PARM2.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.検索２PARM2.Insert = False
        Me.検索２PARM2.Location = New System.Drawing.Point(197, 159)
        Me.検索２PARM2.MaxLength = 10
        Me.検索２PARM2.Name = "検索２PARM2"
        Me.検索２PARM2.RemarkString = Nothing
        Me.検索２PARM2.Size = New System.Drawing.Size(100, 19)
        Me.検索２PARM2.TabIndex = 8
        Me.検索２PARM2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        '検索１PARM3
        '
        Me.検索１PARM3.AutoResize = True
        Me.検索１PARM3.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.検索１PARM3.FocusBackColor = System.Drawing.Color.Empty
        Me.検索１PARM3.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.検索１PARM3.Insert = False
        Me.検索１PARM3.Location = New System.Drawing.Point(303, 134)
        Me.検索１PARM3.MaxLength = 10
        Me.検索１PARM3.Name = "検索１PARM3"
        Me.検索１PARM3.RemarkString = Nothing
        Me.検索１PARM3.Size = New System.Drawing.Size(100, 19)
        Me.検索１PARM3.TabIndex = 4
        Me.検索１PARM3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        '検索１PARM2
        '
        Me.検索１PARM2.AutoResize = True
        Me.検索１PARM2.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.検索１PARM2.FocusBackColor = System.Drawing.Color.Empty
        Me.検索１PARM2.Font = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.検索１PARM2.Insert = False
        Me.検索１PARM2.Location = New System.Drawing.Point(197, 134)
        Me.検索１PARM2.MaxLength = 10
        Me.検索１PARM2.Name = "検索１PARM2"
        Me.検索１PARM2.RemarkString = Nothing
        Me.検索１PARM2.Size = New System.Drawing.Size(100, 19)
        Me.検索１PARM2.TabIndex = 3
        Me.検索１PARM2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        '戻り値１
        '
        Me.戻り値１.AllowBottomPosition = True
        Me.戻り値１.AutoResizeInputControl = True
        Me.戻り値１.BackColor = System.Drawing.Color.Transparent
        Me.戻り値１.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.戻り値１.GroupNo = 0
        Me.戻り値１.Indent = 0
        Me.戻り値１.InnerSpace = 3
        Me.戻り値１.InputAreaFont = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.戻り値１.InputControlReadOnly = False
        Me.戻り値１.InputControlSize = New System.Drawing.Size(82, 19)
        Me.戻り値１.InputTextImeMode = OSK.X1.Foundation.Controls.InputText.ImeModeType.NoControl
        Me.戻り値１.InputType = OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemName.InputTypeList.全文字入力可
        Me.戻り値１.ItemName = "戻り値１"
        Me.戻り値１.ItemNameAreaHeight = 19
        Me.戻り値１.ItemNameAreaWidth = 100
        Me.戻り値１.ItemNameBorderColor = System.Drawing.SystemColors.Window
        Me.戻り値１.ItemNameBorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.戻り値１.ItemNameFont = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.戻り値１.ItemNameTextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Equal
        Me.戻り値１.Location = New System.Drawing.Point(9, 362)
        Me.戻り値１.MaxLength = 10
        Me.戻り値１.MaxLengthMode = OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CharCount
        Me.戻り値１.Name = "戻り値１"
        Me.戻り値１.RemarkString = Nothing
        Me.戻り値１.Size = New System.Drawing.Size(188, 19)
        Me.戻り値１.SubGroupNo = 0
        Me.戻り値１.TabIndex = 5
        Me.戻り値１.TabStop = False
        Me.戻り値１.TextValue = ""
        Me.戻り値１.ZeroFill = False
        Me.戻り値１.ZeroFillAlways = False
        '
        '戻り値２
        '
        Me.戻り値２.AllowBottomPosition = True
        Me.戻り値２.AutoResizeInputControl = True
        Me.戻り値２.BackColor = System.Drawing.Color.Transparent
        Me.戻り値２.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.戻り値２.GroupNo = 0
        Me.戻り値２.Indent = 0
        Me.戻り値２.InnerSpace = 3
        Me.戻り値２.InputAreaFont = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.戻り値２.InputControlReadOnly = False
        Me.戻り値２.InputControlSize = New System.Drawing.Size(82, 19)
        Me.戻り値２.InputTextImeMode = OSK.X1.Foundation.Controls.InputText.ImeModeType.NoControl
        Me.戻り値２.InputType = OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemName.InputTypeList.全文字入力可
        Me.戻り値２.ItemName = "戻り値２"
        Me.戻り値２.ItemNameAreaHeight = 19
        Me.戻り値２.ItemNameAreaWidth = 100
        Me.戻り値２.ItemNameBorderColor = System.Drawing.SystemColors.Window
        Me.戻り値２.ItemNameBorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.戻り値２.ItemNameFont = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.戻り値２.ItemNameTextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Equal
        Me.戻り値２.Location = New System.Drawing.Point(9, 387)
        Me.戻り値２.MaxLength = 10
        Me.戻り値２.MaxLengthMode = OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CharCount
        Me.戻り値２.Name = "戻り値２"
        Me.戻り値２.RemarkString = Nothing
        Me.戻り値２.Size = New System.Drawing.Size(188, 19)
        Me.戻り値２.SubGroupNo = 0
        Me.戻り値２.TabIndex = 6
        Me.戻り値２.TabStop = False
        Me.戻り値２.TextValue = ""
        Me.戻り値２.ZeroFill = False
        Me.戻り値２.ZeroFillAlways = False
        '
        'edaban
        '
        Me.edaban.AllowBottomPosition = True
        Me.edaban.AutoResizeInputControl = True
        Me.edaban.BackColor = System.Drawing.Color.Transparent
        Me.edaban.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.edaban.GroupNo = 0
        Me.edaban.Indent = 0
        Me.edaban.InnerSpace = 3
        Me.edaban.InputAreaFont = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.edaban.InputControlReadOnly = False
        Me.edaban.InputControlSize = New System.Drawing.Size(88, 19)
        Me.edaban.ItemName = "枝番"
        Me.edaban.ItemNameAreaHeight = 19
        Me.edaban.ItemNameAreaWidth = 80
        Me.edaban.ItemNameBorderColor = System.Drawing.SystemColors.Window
        Me.edaban.ItemNameBorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.edaban.ItemNameFont = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.edaban.ItemNameTextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Equal
        Me.edaban.Location = New System.Drawing.Point(9, 50)
        Me.edaban.Minus = "-"
        Me.edaban.Name = "edaban"
        Me.edaban.RemarkString = Nothing
        Me.edaban.Size = New System.Drawing.Size(171, 19)
        Me.edaban.SubGroupNo = 0
        Me.edaban.TabIndex = 2
        Me.edaban.Value = New Decimal(New Integer() {0, 0, 0, 0})
        Me.edaban.カンマ表示 = True
        Me.edaban.スピンボタンの値 = Nothing
        Me.edaban.スピンボタンの表示 = False
        Me.edaban.ゼロ表示 = True
        Me.edaban.マイナス入力 = False
        Me.edaban.マイナス入力時の色 = System.Drawing.SystemColors.WindowText
        Me.edaban.小数桁数 = 0
        Me.edaban.整数桁数 = 9
        Me.edaban.最大値 = New Decimal(New Integer() {-469762049, -590869294, 5421010, 393216})
        Me.edaban.最小値 = New Decimal(New Integer() {-469762049, -590869294, 5421010, -2147090432})
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.任意項目5)
        Me.Panel2.Controls.Add(Me.任意項目4)
        Me.Panel2.Controls.Add(Me.任意項目3)
        Me.Panel2.Controls.Add(Me.任意項目2)
        Me.Panel2.Controls.Add(Me.任意項目1)
        Me.Panel2.Location = New System.Drawing.Point(644, 75)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(268, 272)
        Me.Panel2.TabIndex = 4
        Me.Panel2.Title = "任意項目"
        Me.Panel2.TitleVisible = True
        '
        '任意項目5
        '
        Me.任意項目5.AllowBottomPosition = True
        Me.任意項目5.AutoResizeInputControl = True
        Me.任意項目5.BackColor = System.Drawing.Color.Transparent
        Me.任意項目5.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.任意項目5.GroupNo = 0
        Me.任意項目5.Indent = 0
        Me.任意項目5.InnerSpace = 3
        Me.任意項目5.InputAreaFont = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.任意項目5.InputControlReadOnly = False
        Me.任意項目5.InputControlSize = New System.Drawing.Size(82, 19)
        Me.任意項目5.InputTextImeMode = OSK.X1.Foundation.Controls.InputText.ImeModeType.NoControl
        Me.任意項目5.InputType = OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemName.InputTypeList.全文字入力可
        Me.任意項目5.ItemName = "項目５"
        Me.任意項目5.ItemNameAreaHeight = 19
        Me.任意項目5.ItemNameAreaWidth = 100
        Me.任意項目5.ItemNameBorderColor = System.Drawing.SystemColors.Window
        Me.任意項目5.ItemNameBorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.任意項目5.ItemNameFont = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.任意項目5.ItemNameTextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Equal
        Me.任意項目5.Location = New System.Drawing.Point(9, 118)
        Me.任意項目5.MaxLength = 10
        Me.任意項目5.MaxLengthMode = OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CharCount
        Me.任意項目5.Name = "任意項目5"
        Me.任意項目5.RemarkString = Nothing
        Me.任意項目5.Size = New System.Drawing.Size(188, 19)
        Me.任意項目5.SubGroupNo = 0
        Me.任意項目5.TabIndex = 19
        Me.任意項目5.TextValue = ""
        Me.任意項目5.ZeroFill = False
        Me.任意項目5.ZeroFillAlways = False
        '
        '任意項目4
        '
        Me.任意項目4.AllowBottomPosition = True
        Me.任意項目4.AutoResizeInputControl = True
        Me.任意項目4.BackColor = System.Drawing.Color.Transparent
        Me.任意項目4.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.任意項目4.GroupNo = 0
        Me.任意項目4.Indent = 0
        Me.任意項目4.InnerSpace = 3
        Me.任意項目4.InputAreaFont = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.任意項目4.InputControlReadOnly = False
        Me.任意項目4.InputControlSize = New System.Drawing.Size(82, 19)
        Me.任意項目4.InputTextImeMode = OSK.X1.Foundation.Controls.InputText.ImeModeType.NoControl
        Me.任意項目4.InputType = OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemName.InputTypeList.全文字入力可
        Me.任意項目4.ItemName = "項目４"
        Me.任意項目4.ItemNameAreaHeight = 19
        Me.任意項目4.ItemNameAreaWidth = 100
        Me.任意項目4.ItemNameBorderColor = System.Drawing.SystemColors.Window
        Me.任意項目4.ItemNameBorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.任意項目4.ItemNameFont = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.任意項目4.ItemNameTextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Equal
        Me.任意項目4.Location = New System.Drawing.Point(9, 93)
        Me.任意項目4.MaxLength = 10
        Me.任意項目4.MaxLengthMode = OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CharCount
        Me.任意項目4.Name = "任意項目4"
        Me.任意項目4.RemarkString = Nothing
        Me.任意項目4.Size = New System.Drawing.Size(188, 19)
        Me.任意項目4.SubGroupNo = 0
        Me.任意項目4.TabIndex = 18
        Me.任意項目4.TextValue = ""
        Me.任意項目4.ZeroFill = False
        Me.任意項目4.ZeroFillAlways = False
        '
        '任意項目3
        '
        Me.任意項目3.AllowBottomPosition = True
        Me.任意項目3.AutoResizeInputControl = True
        Me.任意項目3.BackColor = System.Drawing.Color.Transparent
        Me.任意項目3.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.任意項目3.GroupNo = 0
        Me.任意項目3.Indent = 0
        Me.任意項目3.InnerSpace = 3
        Me.任意項目3.InputAreaFont = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.任意項目3.InputControlReadOnly = False
        Me.任意項目3.InputControlSize = New System.Drawing.Size(82, 19)
        Me.任意項目3.InputTextImeMode = OSK.X1.Foundation.Controls.InputText.ImeModeType.NoControl
        Me.任意項目3.InputType = OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemName.InputTypeList.全文字入力可
        Me.任意項目3.ItemName = "項目３"
        Me.任意項目3.ItemNameAreaHeight = 19
        Me.任意項目3.ItemNameAreaWidth = 100
        Me.任意項目3.ItemNameBorderColor = System.Drawing.SystemColors.Window
        Me.任意項目3.ItemNameBorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.任意項目3.ItemNameFont = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.任意項目3.ItemNameTextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Equal
        Me.任意項目3.Location = New System.Drawing.Point(9, 68)
        Me.任意項目3.MaxLength = 10
        Me.任意項目3.MaxLengthMode = OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CharCount
        Me.任意項目3.Name = "任意項目3"
        Me.任意項目3.RemarkString = Nothing
        Me.任意項目3.Size = New System.Drawing.Size(188, 19)
        Me.任意項目3.SubGroupNo = 0
        Me.任意項目3.TabIndex = 17
        Me.任意項目3.TextValue = ""
        Me.任意項目3.ZeroFill = False
        Me.任意項目3.ZeroFillAlways = False
        '
        '任意項目2
        '
        Me.任意項目2.AllowBottomPosition = True
        Me.任意項目2.AutoResizeInputControl = True
        Me.任意項目2.BackColor = System.Drawing.Color.Transparent
        Me.任意項目2.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.任意項目2.GroupNo = 0
        Me.任意項目2.Indent = 0
        Me.任意項目2.InnerSpace = 3
        Me.任意項目2.InputAreaFont = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.任意項目2.InputControlReadOnly = False
        Me.任意項目2.InputControlSize = New System.Drawing.Size(82, 19)
        Me.任意項目2.InputTextImeMode = OSK.X1.Foundation.Controls.InputText.ImeModeType.NoControl
        Me.任意項目2.InputType = OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemName.InputTypeList.全文字入力可
        Me.任意項目2.ItemName = "項目２"
        Me.任意項目2.ItemNameAreaHeight = 19
        Me.任意項目2.ItemNameAreaWidth = 100
        Me.任意項目2.ItemNameBorderColor = System.Drawing.SystemColors.Window
        Me.任意項目2.ItemNameBorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.任意項目2.ItemNameFont = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.任意項目2.ItemNameTextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Equal
        Me.任意項目2.Location = New System.Drawing.Point(9, 43)
        Me.任意項目2.MaxLength = 10
        Me.任意項目2.MaxLengthMode = OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CharCount
        Me.任意項目2.Name = "任意項目2"
        Me.任意項目2.RemarkString = Nothing
        Me.任意項目2.Size = New System.Drawing.Size(188, 19)
        Me.任意項目2.SubGroupNo = 0
        Me.任意項目2.TabIndex = 16
        Me.任意項目2.TextValue = ""
        Me.任意項目2.ZeroFill = False
        Me.任意項目2.ZeroFillAlways = False
        '
        '任意項目1
        '
        Me.任意項目1.AllowBottomPosition = True
        Me.任意項目1.AutoResizeInputControl = True
        Me.任意項目1.BackColor = System.Drawing.Color.Transparent
        Me.任意項目1.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.任意項目1.GroupNo = 0
        Me.任意項目1.Indent = 0
        Me.任意項目1.InnerSpace = 3
        Me.任意項目1.InputAreaFont = New System.Drawing.Font("ＭＳ ゴシック", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.任意項目1.InputControlReadOnly = False
        Me.任意項目1.InputControlSize = New System.Drawing.Size(82, 19)
        Me.任意項目1.InputTextImeMode = OSK.X1.Foundation.Controls.InputText.ImeModeType.NoControl
        Me.任意項目1.InputType = OSK.X1.Foundation.SmartControl.InputTextWithItemName.InputTextWithItemName.InputTypeList.全文字入力可
        Me.任意項目1.ItemName = "項目１"
        Me.任意項目1.ItemNameAreaHeight = 19
        Me.任意項目1.ItemNameAreaWidth = 100
        Me.任意項目1.ItemNameBorderColor = System.Drawing.SystemColors.Window
        Me.任意項目1.ItemNameBorderStyle = OSK.X1.Foundation.Controls.Label.BorderStyleType.[Single]
        Me.任意項目1.ItemNameFont = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.任意項目1.ItemNameTextAlign = OSK.X1.Foundation.Controls.Label.HorizontalAlignmentType.Equal
        Me.任意項目1.Location = New System.Drawing.Point(9, 18)
        Me.任意項目1.MaxLength = 10
        Me.任意項目1.MaxLengthMode = OSK.X1.Foundation.Controls.InputText.MaxLengthModeType.CharCount
        Me.任意項目1.Name = "任意項目1"
        Me.任意項目1.RemarkString = Nothing
        Me.任意項目1.Size = New System.Drawing.Size(188, 19)
        Me.任意項目1.SubGroupNo = 0
        Me.任意項目1.TabIndex = 15
        Me.任意項目1.TextValue = ""
        Me.任意項目1.ZeroFill = False
        Me.任意項目1.ZeroFillAlways = False
        '
        'PGIDの指定
        '
        Me.PGIDの指定.AutoWidth = True
        Me.PGIDの指定.BorderStyle = OSK.X1.Foundation.Controls.GroupOption.BorderStyleType.Normal
        Me.PGIDの指定.FocusBackColor = System.Drawing.Color.Empty
        Me.PGIDの指定.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.PGIDの指定.ItemCount = 3
        Item1.Enabled = True
        Item1.Text = "伝票検索"
        Item1.Visible = True
        Item2.Enabled = True
        Item2.Text = "画面照会"
        Item2.Visible = True
        Item3.Enabled = True
        Item3.Text = "マトリクス照会"
        Item3.Visible = True
        Me.PGIDの指定.Items = New OSK.X1.Foundation.Controls.GroupOptionImpl.Item() {Item1, Item2, Item3}
        Me.PGIDの指定.Location = New System.Drawing.Point(12, -6)
        Me.PGIDの指定.Name = "PGIDの指定"
        Me.PGIDの指定.RemarkString = Nothing
        Me.PGIDの指定.Size = New System.Drawing.Size(278, 50)
        Me.PGIDの指定.TabIndex = 0
        Me.PGIDの指定.TabStop = False
        Me.PGIDの指定.Title = ""
        Me.PGIDの指定.Value = 3
        '
        '再読込
        '
        Me.再読込.CheckState = System.Windows.Forms.CheckState.Unchecked
        Me.再読込.DrawFocusFrame = True
        Me.再読込.FocusBackColor = System.Drawing.Color.Empty
        Me.再読込.Font = New System.Drawing.Font("MS UI Gothic", 10.5!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(128, Byte))
        Me.再読込.IndeterminateText = ""
        Me.再読込.Location = New System.Drawing.Point(306, 25)
        Me.再読込.Name = "再読込"
        Me.再読込.RemarkString = Nothing
        Me.再読込.Size = New System.Drawing.Size(100, 19)
        Me.再読込.TabIndex = 1
        Me.再読込.TabStop = False
        Me.再読込.Text = "再読込"
        Me.再読込.UncheckedText = ""
        '
        'DummyEntryForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(925, 477)
        Me.Controls.Add(Me.再読込)
        Me.Controls.Add(Me.PGIDの指定)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.edaban)
        Me.Controls.Add(Me.戻り値２)
        Me.Controls.Add(Me.戻り値１)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.再表示区分)
        Me.Controls.Add(Me.検索)
        Me.Name = "DummyEntryForm"
        Me.Text = "Form1"
        Me.Panel1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents 検索 As OSK.X1.Foundation.SimpleControl.CommandButton
    Friend WithEvents 再表示区分 As SimpleControl.CheckBox
    Friend WithEvents 検索１PARM1 As SmartControl.InputTextWithItemName.InputTextWithItemName
    Friend WithEvents 検索２PARM1 As SmartControl.InputTextWithItemName.InputTextWithItemName
    Friend WithEvents 検索３PARM1 As SmartControl.InputTextWithItemName.InputTextWithItemName
    Friend WithEvents Panel1 As SimpleControl.Panel
    Friend WithEvents 検索５PARM3 As SimpleControl.InputText
    Friend WithEvents 検索５PARM2 As SimpleControl.InputText
    Friend WithEvents 検索５PARM1 As SmartControl.InputTextWithItemName.InputTextWithItemName
    Friend WithEvents 検索４PARM3 As SimpleControl.InputText
    Friend WithEvents 検索４PARM2 As SimpleControl.InputText
    Friend WithEvents 検索４PARM1 As SmartControl.InputTextWithItemName.InputTextWithItemName
    Friend WithEvents 検索３PARM3 As SimpleControl.InputText
    Friend WithEvents 検索３PARM2 As SimpleControl.InputText
    Friend WithEvents 検索２PARM3 As SimpleControl.InputText
    Friend WithEvents 検索２PARM2 As SimpleControl.InputText
    Friend WithEvents 検索１PARM3 As SimpleControl.InputText
    Friend WithEvents 検索１PARM2 As SimpleControl.InputText
    Friend WithEvents Label2 As SimpleControl.Label
    Friend WithEvents Label1 As SimpleControl.Label
    Friend WithEvents 戻り値１ As SmartControl.InputTextWithItemName.InputTextWithItemName
    Friend WithEvents 戻り値２ As SmartControl.InputTextWithItemName.InputTextWithItemName
    Friend WithEvents Label3 As SimpleControl.Label
    Friend WithEvents Label4 As SimpleControl.Label
    Friend WithEvents edaban As SmartControl.InputTextWithItemName.InputNumericalWithItemName
    Friend WithEvents Panel2 As SimpleControl.Panel
    Friend WithEvents 任意項目5 As SmartControl.InputTextWithItemName.InputTextWithItemName
    Friend WithEvents 任意項目4 As SmartControl.InputTextWithItemName.InputTextWithItemName
    Friend WithEvents 任意項目3 As SmartControl.InputTextWithItemName.InputTextWithItemName
    Friend WithEvents 任意項目2 As SmartControl.InputTextWithItemName.InputTextWithItemName
    Friend WithEvents 任意項目1 As SmartControl.InputTextWithItemName.InputTextWithItemName
    Friend WithEvents PGIDの指定 As SimpleControl.GroupOption
    Friend WithEvents 再読込 As SimpleControl.CheckBox
    Friend WithEvents 検索５PARM5 As SimpleControl.InputText
    Friend WithEvents 検索５PARM4 As SimpleControl.InputText
    Friend WithEvents 検索４PARM5 As SimpleControl.InputText
    Friend WithEvents 検索４PARM4 As SimpleControl.InputText
    Friend WithEvents 検索３PARM5 As SimpleControl.InputText
    Friend WithEvents 検索３PARM4 As SimpleControl.InputText
    Friend WithEvents 検索２PARM5 As SimpleControl.InputText
    Friend WithEvents 検索２PARM4 As SimpleControl.InputText
    Friend WithEvents 検索１PARM5 As SimpleControl.InputText
    Friend WithEvents 検索１PARM4 As SimpleControl.InputText
    Friend WithEvents Label5 As SimpleControl.Label
End Class
