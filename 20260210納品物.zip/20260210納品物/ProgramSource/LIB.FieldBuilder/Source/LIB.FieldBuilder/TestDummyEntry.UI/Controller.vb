﻿Public Class Controller
    Inherits JobBase

    Private _entryForm As IDummyEntryForm

    ''' <summary>
    ''' 起動処理
    ''' </summary>
    ''' <param name="paramInfo">パラメータ情報
    ''' 他のプログラムから呼ばれたときに何かしら値が入ってくるもの。</param>
    ''' <remarks></remarks>
    Public Overrides Sub Run(ByVal paramInfo As System.Collections.IDictionary)

        _entryForm = Factory(Of IDummyEntryForm).CreateInstance(Me, "DummyEntryForm")
        _entryForm.SetUpForm()

    End Sub

End Class
